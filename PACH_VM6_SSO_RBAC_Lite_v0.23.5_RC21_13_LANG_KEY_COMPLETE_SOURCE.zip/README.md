---
title: AZBlink Directory
description: LDAP-backed directory service with QR provisioning and optional Authentik SSO
type: overview
product: azblink-directory
status: current
updated: 2026-10-08
---

# AZBlink Directory

LDAP-backed directory service with QR-based provisioning and optional Authentik SSO integration.

## Quick Start (Development)

```bash
cd deploy/dev
cp .env.example .env
docker compose up --build
```

**Services:**
| Service | URL |
|---------|-----|
| UI | http://localhost:8081/ |
| API | http://localhost:8081/api |
| API Docs | http://localhost:8081/api/docs |

**Test Login:** `mei` / `password123`

See [deploy/dev/README.md](deploy/dev/README.md) for full credentials and setup.

## Repository Structure

```
azblink-AD/
├── src/                # Source code
│   ├── backend/        # FastAPI application
│   ├── frontend/       # React admin UI (Vite + shadcn/ui)
│   └── cli/            # CLI tools (directoryctl)
│
├── deploy/             # Deployment configs
│   ├── dev/            # Development environment
│   │   ├── README.md           # Quick start + credentials
│   │   ├── DEPLOYMENT_SPEC.md  # Full technical spec
│   │   ├── ldap/bootstrap.ldif # Bootstrap users (7)
│   │   └── seed/               # Demo data seeder (50+ users)
│   └── prod/           # Production (future)
│
├── tests/              # Integration tests
│
└── docs/               # Documentation
    ├── architecture/   # Architecture spec, ARDs, SOP (source of truth)
    ├── knowledge/      # Libraries and patterns reference
    ├── plans/          # Design documents
    └── reports/        # Investigation and status reports
```

## Spec-Driven Development

1. **Read the spec:** [docs/architecture/README.md](docs/architecture/README.md), versioned per [docs/architecture/SOP.md](docs/architecture/SOP.md)

## Key Concepts

- **Dual Auth Planes:** LDAP for UC (always), Authentik for SSO (optional)
- **QR Provisioning:** QR#1 (UC core) + QR#2 (SSO profile)
- **Break-glass:** Emergency access when OIDC is down

## Critical Documentation

| Document | Purpose |
|----------|---------|
| [docs/architecture/README.md](docs/architecture/README.md) | Architecture specification (source of truth) |
| [docs/architecture/SOP.md](docs/architecture/SOP.md) | How the spec and ARDs are versioned |
| [deploy/dev/README.md](deploy/dev/README.md) | **Dev setup, credentials, commands** |
| [deploy/dev/DEPLOYMENT_SPEC.md](deploy/dev/DEPLOYMENT_SPEC.md) | Full deployment technical spec |
| [CLAUDE.md](CLAUDE.md) | AI assistant instructions |

## Preseed Accounts (Dev)

| Account | Credentials | Purpose |
|---------|-------------|---------|
| LDAP Admin | `cn=admin,dc=azblink,dc=com` / `adminpassword` | Direct LDAP operations |
| Web Admin | `mei` / `password123` | The only seeded web admin (Authentik `IT-Admins`) |
| Bootstrap Users | 7 users / `password123` | Core test users. Not web admins, including LDAP `IT-Admins` robert and alex |
| Authentik Admin | `akadmin` / `AUTHENTIK_BOOTSTRAP_PASSWORD` in `deploy/dev/.env` | Authentik at http://localhost:9000/ |
| Demo Users | 51 users / `demo123` | Realistic org data |

Full details in [deploy/dev/README.md](deploy/dev/README.md).
