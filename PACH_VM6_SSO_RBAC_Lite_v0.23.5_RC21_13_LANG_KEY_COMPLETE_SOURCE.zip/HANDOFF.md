# HANDOFF

_Last updated: 2026-10-08 (Cloudflare Access, PR #348, on top of session 5's credential rotation)_

## RESOLVED 2026-10-08: dev Authentik was public with known credentials

**Cloudflare Access now gates `authentik.keithmoc.dev`** to the owner's email. `/if/admin/`, `/api/v3/`,
the flow executor, the flows and `/application/o/authorize/` all answer 302 to `keithm.cloudflareaccess.com`.
Only OIDC discovery (`/application/o/azblink-directory/.well-known/`) and `/application/o/token/` are
bypassed, because the admin UI fetches them cross-origin. Docker-internal `http://authentik-server:9000` is
unaffected, including the SafeNest relay. See spec §06 §6.2. Pitfall: an Access app that carries both an
Allow and a Bypass+Everyone policy bypasses everything, because Bypass is evaluated first. The dev admin
credentials were rotated on 2026-10-06 and the `safenest-dev` client secret on 2026-10-07 (details below).

### Session 5: dev credential rotation (not in git: `.env` is gitignored)

Reported 2026-10-03 by SafeNest: `https://authentik.keithmoc.dev` (Cloudflare tunnel) served the
admin UI and `/api/v3/` while `deploy/dev/.env` used the committed placeholder superuser token and
the documented `akadmin` password.

- **2026-10-06 ~15:28Z** `AUTHENTIK_BOOTSTRAP_TOKEN`, `AUTHENTIK_API_TOKEN`, `AUTHENTIK_BOOTSTRAP_PASSWORD`
  rotated live (Admin API `set_key` / `set_password`) and in `deploy/dev/.env` (mode 600; backup
  `deploy/dev/.env.bak-20261006152834` holds the old placeholders). `docker compose up -d` recreated
  authentik-server/worker and directory-api. Placeholder → 403, also on the public URL. The akadmin
  web login now uses the new `AUTHENTIK_BOOTSTRAP_PASSWORD`, not `adminpassword`.
- **2026-10-07 21:06Z** owner decision (relayed by SafeNest): `safenest-dev` client secret rotated
  (PATCH `client_secret` only; all other provider fields diffed unchanged), new value written to
  `azb-safenest/.env` `AUTHENTIK_CLIENT_SECRET=`. Wrong secret → `invalid_client`; new → passes
  client auth. Tokens issued before the rotation were **not** revoked (offered to SafeNest).
- **Resolved 2026-10-08:** Cloudflare Access is in front of the tunnel (above). The headless relay
  needed no bypass: it only uses the docker-internal URL.

Scripts used (session scratchpad, not in repo): `rotate_dev_authentik.py`, `rotate_sn_secret.py`,
`secret_probe.py`, `run_tests.sh` under
`/tmp/claude-1000/-home-keith--WORKSPACES--azb-azblink-directory-and-identity-stack/492bf56d-07f7-4fbe-a952-d0a939671cee/scratchpad/`.

## Goal

Let **SafeNest** (sibling repo `~/_WORKSPACES_/azb-safenest`) log in through azb-AD's
Authentik with its own login form: the **headless first-party client** pattern, decided in
**ARD-018** (accepted). Plan, gaps and decisions:
`docs/reports/2026-09-25-safenest-headless-login-gap-report.md`.

**All ARD-018 implementing items have shipped** (spec 1.16.0, markers AS-BUILT). Session 4 ran as a
durable run: state, decisions (D1–D19, each with rule / worst case / revert) and evidence are
in `runs/20261002-safenest-e3-e5-g20/` (`PLAN.md`, `JOURNAL.md`, `agents/` = the E5 adversarial
review).

## Current Progress

| PR | Item | State |
|----|------|-------|
| #336 | **E3** shared `headless-first-party-auth` flow; MFA fail-closed test (G3 verified) | merged `6a64d34` |
| #337 | **G20** prod registration: `env.j2` renders `AUTHENTIK_FIRST_PARTY_CLIENTS`; `authentik-seed` already ran on prod | merged `5ee8f3b` |
| #338 | **E5** lockout + trusted proxies; `/security-review` fix (login guard); spec 1.16.0, markers → AS-BUILT, ARD-018 amendment | merged `16a80bd` |

### Local dev state (not in git)

- `deploy/dev/.env`: `AUTHENTIK_FIRST_PARTY_CLIENTS` has `safenest-dev`.
- Authentik dev: headless flow + E5 lockout seeded; tenant `reputation_upper_limit` 0;
  `authentik-server` recreated with `AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS=127.0.0.1/32,::1/128`.
- SafeNest dev users created via the API (D18): `john.resident`, `staff.member`, `admin.user`,
  `visitor.guest` in `safenest-dev-{resident,staff,admin,visitor}` (passwords = SafeNest's
  `docs/TESTING_GUIDE.md`). Revert: `DELETE /api/users/<uid>`, `DELETE /api/groups/<cn>`.

### SafeNest coordination

Peer is now `azb-safenest-a9` (was `-d9`; find with `ListAgents`). It has all shas, the dev users
and the E5 throttle mapping (SafeNest `d971787`). As of 2026-10-07 21:06Z it has the rotated
`safenest-dev` secret in its `.env` and is re-running its live relay test, then switching SafeNest
dev from LDAP login to the relay. Nothing owed unless it reports a failure or asks to revoke the
pre-rotation tokens. Never send any secret over the session channel.

## What Worked

- **Adversarial review before building security code**: a red-team and an independent architect,
  read-only, each writing `agents/<name>.md`. The red-team found the pre-staged-session bypass the
  architect missed; a live scratch-flow probe settled it in one run.
- **Live probe + mutation for every security claim**: scratch flows/users via the Admin API, then
  remove the control and watch the test fail (`probe_toctou.py`, `probe_stale_plan.py`, `mutate_e5.py`
  patterns, in JOURNAL).
- Stacking PRs, then `git rebase --onto origin/main <old-parent>` after each squash-merge.
- Ansible render check: `ansible-playbook` with `connection: local` + dev inventory, then
  `docker compose --env-file <rendered> config <service>` to see what the container really gets.
- Secret handling: read secrets in-process from `.env`, compare without printing, write with an
  atomic `os.replace` keeping the file mode.
- Proving a client secret: `refresh_token` grant with a bogus token. Wrong secret → `invalid_client`,
  right secret → `invalid_grant` (Authentik returns 400, not 401).

## What Didn't Work

- The search hook blocks Bash `for` loops, heredocs piped to commands, `sed -n '/re/p'`: write a
  scratchpad `.py` and run it. Advisors share the scratchpad: one overwrote `ak.py` (use unique names).
- Accepted ARDs reject any edit above `## Amendments` (arch-guard `ard-immutability`), including the
  summary line's PR list. Put PR pointers in the README ARD table or an amendment.
- Authentik gotchas from this session are now in `.claude/rules/authentik.md` (deny-stage-once-per-session,
  reputation semantics, trusted proxies, binding filters, CSRF, admin device 405).
- Search hook (session 5) also blocks `find`, `rg`, `awk`, and some inline `python3 -c`/heredocs:
  scratchpad `.py` files always pass. `ctx-router` code_search had no index (degraded).
- `client_credentials` cannot verify a client secret: Authentik returns `invalid_grant` for every
  secret, valid or not.
- The 2026-10-03 `rotate_dev_authentik.py` (old scratchpad `7ae1a9a4-…`) restores the old `.env` if
  `set_password` fails after `set_key` succeeded, losing the new token. The session-5 copy fixes it;
  don't reuse the old one.

## Next Steps

1. **Wait for SafeNest's relay test result** (peer `azb-safenest-a9`). If it fails at code exchange
   (502), check the `.env` line matches the live provider secret (compare in-process, never print).
2. **Owner:** export the new `AUTHENTIK_API_TOKEN` (from `deploy/dev/.env`) in the shell profile.
   `tests/conftest.py` falls back to the dead placeholder, so Authentik tests fail without it.
3. ~~**Owner:** decide on Cloudflare Access for `authentik.keithmoc.dev`.~~ Done 2026-10-08 (#348, top section).
4. Post-rotation test run (2026-10-06): 827 passed, 13 skipped; 3 failed + 4 errors, none from the
   rotation: `/api/audit/events` shape and 2 `/metrics` tests pass in isolation (order-dependent);
   `test_sip_ring_e2e.py` errors on missing LDAP user `alanl`. Worth a look.
5. Grafana won't start: host port 3001 is held by `safenest-backend-dev`. Remap one of them.
6. **Owner decisions now open** (gap report G22–G24, ARD-018 amendment):
   - G22 throttle the brand `default-authentication-flow` too (admin web login would inherit a
     no-heal block).
   - G23 parallel requests: LDAP `pwdMaxFailure` margin (≥ 3 + 8 × replicas + 1) needs an ARD amendment.
   - G24 set ppolicy `pwdFailureCountInterval` (e.g. 3600) so LDAP forgets before reputation rows expire.
7. Possibly: extend `POST /api/users/{uid}/unlock` to also delete Authentik reputation rows (today a
   runbook in spec 08). Not done: it touches a surface outside ARD-018's sections.

## Carried forward

- `docs/architecture/decisions/**`, `README.md`, `CHANGELOG.md` are on no surface glob (ARD status drift).
- G18 (no building-scoped admin) blocks SafeNest phase 3.
- G7 prod tunnel issuer for new providers; relays are not supported through the tunnel.
- Manual UI pass after `@base-ui/react` 1.8 (#306). Dependabot #319–#325 (#321–#325 need
  `just lock-backend`). i18n Phase 2 O1–O3; issue #102; 7 old stashes.
