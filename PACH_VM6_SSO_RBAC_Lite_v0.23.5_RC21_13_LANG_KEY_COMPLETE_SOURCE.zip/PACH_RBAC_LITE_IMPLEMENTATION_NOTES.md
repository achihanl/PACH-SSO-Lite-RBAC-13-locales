# PACH-STD-IAM-001 — VM6 RBAC Lite implementation notes (v0.21.0 development)

## Scope of this development source

This is a **development candidate**, built incrementally from the provided VM6 v0.20.0 complete archive, not a deployment-certified or fully validated release. Original OpenLDAP, Authentik, existing group RBAC, and first-party building/client onboarding are preserved.

New work:

- General-purpose `pach_applications` PostgreSQL catalogue; distinct from `first_party_clients`.
- Idempotent, insert-only registration of all ten existing PACH service entries (no roles or credentials granted).
- Single `pach_application_roles` assignment per LDAP username and application. Missing/disabled roles return no access.
- Management REST endpoints under `/api/applications`, guarded by existing `system_configuration` or `user_management` permissions.
- Authenticated user's `/api/applications/me/roles` endpoint for retrieving role assignments; foreign client tokens are rejected.
- `/configuration/applications` administration UI in English, Traditional Chinese and Simplified Chinese.
- Migration `032_pach_applications.sql`, mirrored in SQLAlchemy table definitions.

### API contract

| Method | Path | Access |
|---|---|---|
| GET | `/api/applications` | system_configuration |
| POST | `/api/applications` | system_configuration |
| PATCH | `/api/applications/{application_id}` | system_configuration |
| GET | `/api/applications/me/roles` | authenticated human identity |
| GET | `/api/applications/users/{uid}/roles` | user_management |
| PUT | `/api/applications/{application_id}/users/{uid}` | user_management |
| DELETE | `/api/applications/{application_id}/users/{uid}` | user_management |

POST request example:

```json
{"application_id":"partner-crm", "display_name":"Partner CRM", "auth_method":"oidc", "supported_roles":["admin","user","viewer"]}
```

PUT role assignment example:

```json
{"role":"user"}
```

- Registrations are **metadata only**: they DO NOT automatically provision Authentik providers, LDAP service credentials, or perform SIP/XMPP onboarding. Configure an actual OIDC/SAML/LDAP integration by the existing supported admin mechanism.
- `auth_method` is the selected *primary* authentication approach in this initial implementation. Applications with multiple protocol entry points can use the other VM6 integrations independently; a multi-method catalog can be a later backward-compatible extension.
- Application role names are case-sensitive and selected from that application's supported list. No application-specific permissions reside in VM6.
- User-level API access requires existing backend permission checks; do not forward an end-user token from an untrusted client to other services.
- The administrative API does not provide an unrestricted machine-to-machine read of arbitrary users' assignments. Applications should obtain the authenticated user's assignments using a verified bearer token or add a separately reviewed scoped service API in a future phase.

## Deployment sequence

1. Preserve a copy of the original v0.20.0 deployment and PostgreSQL backup.
2. Run the existing migration tool against `migrations/` in dry-run mode, then in apply mode after review.
3. Rebuild backend and frontend; Vite/TanStack Router generates `routeTree.gen.ts` from new route files during build.
4. Register required applications using the UI/API. No roles are assigned by default.
5. Configure supported LDAP/OIDC/SAML clients through established VM6 mechanisms. Test each relying VM separately.
6. Verify role assignment, revocation, disabled-app denial, administrator separation, and token-expiration behavior.

## Open items / validation limitations

- The development container does not have `psycopg2`, a configured PostgreSQL/LDAP/Authentik stack, or frontend node_modules, so integration and frontend build tests were not executed. A Python syntax/static consistency check was run; this does not substitute for deployment validation.
- Existing frozen contract baselines (`tests/contract/openapi.baseline.json`, guard snapshots) were not rewritten blindly. The VM6 maintainer must intentionally accept the seven new operations in the contract snapshots after generating the OpenAPI schema in the normal test environment.
- No automatic authentication client provisioning, signed cross-application role claims, or per-VM authorization-enforcement helpers have been implemented in this first code increment. The ten built-in application catalogue records are registered on startup, without provisioning credentials. They require coordinated application-level tests and explicit integration decisions.
- Reassignment must be reflected on next authorization fetch; each application must avoid indefinitely caching role grants. Local application resource permissions remain the VM's responsibility.
