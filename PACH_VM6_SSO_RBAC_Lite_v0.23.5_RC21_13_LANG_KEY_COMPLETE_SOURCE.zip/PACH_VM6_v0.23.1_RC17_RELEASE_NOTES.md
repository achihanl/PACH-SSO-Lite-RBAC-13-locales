# PACH VM6 SSO & RBAC Lite — v0.23.1 RC17

Baseline: v0.23.0 RC16.

Translated 46 additional Settings keys for each of the ten added languages (460 entries), concentrating on unsaved change warnings, system settings, security options, audit navigation and labels. Existing locale entries retained.

Coverage: 899 / 1062 keys per added language. Remaining Settings keys: 163.

The historical PACH Master Terminology v25.9 is the terminology reference. All new translations remain drafts requiring native-language approval. No authentication, RBAC or API functionality changed. Full frontend and RTL visual tests remain outstanding.
