# Code Review Guidelines

## Always Check

### Security
- LDAP filter construction uses parameterized queries, never string interpolation
- No secrets, tokens, or passwords in code (check for hardcoded values beyond dev defaults)
- Auth bypass: all new API routes go through `oidc_verify` dependency (except health/public endpoints)
- HMAC validation: QR signing uses constant-time comparison (`hmac.compare_digest`)
- Rate limiting: new public-facing endpoints have rate limits applied
- Error responses don't leak internal paths, stack traces, or LDAP DNs to clients

### Architecture Compliance
- Single-LDAP invariant: no references to a second LDAP or "UED LDAP"
- Dual auth plane separation: UC/LDAP bind (Plane A) never depends on Authentik availability
- Two-layer component rules: primitives in `packages/azblink-ui/primitives/` use CSS Modules + tokens only, feature components in `src/components/features/` use Tailwind only
- No hardcoded `font-size`, `line-height`, `font-weight` in CSS Modules — must use `var(--token)` references
- No components created in `src/frontend/src/components/ui/` (deleted directory)
- New React components import primitives from `@azblink/ui`, not from relative paths to primitives

### Test Coverage
- New API endpoints must have corresponding integration tests in `tests/`
- Tests run against real Docker stack — no mocking of LDAP, PostgreSQL, or Authentik
- New frontend components that handle user actions should have error boundary coverage

### Database
- Migrations must be backward-compatible (additive only, no column drops without migration path)
- Migration file numbering follows existing sequence in `migrations/`
- SQL uses parameterized queries, never f-string interpolation

## Style

- Backend: prefer early returns over nested conditionals
- Backend: use structured logging, not f-string interpolation in log calls
- Frontend: prefer `cn()` merge for className composition
- Frontend: use `data-slot` attribute pattern in primitives
- TypeScript: prefer strict types over `any` — use `unknown` if type is truly unknown

## Skip

- Formatting-only changes (handled by linters)
- Changes to `deploy/dev/.env.example` (contains only dev defaults, not real secrets)
- Generated route tree files (`routeTree.gen.ts`)
- Lock files (`package-lock.json`, `pnpm-lock.yaml`)
- Changes in `_ARCHIVE_/` (historical, not active code)
