"""Activity type mapping — pure data, zero side-effect imports.

Maps unified-audit `event_type` values (see orgdb.list_unified_audit) to
frontend-friendly activity types. Non-QR events must never collapse onto a
`qr-*` type — unrecognized types fall back to the neutral ACTIVITY_TYPE_DEFAULT.

Kept in its own module (no fastapi/db/orgdb imports) so it can be imported
in-process for unit tests without triggering main.py's module-level DB setup.
"""

ACTIVITY_TYPE_MAP = {
    "qr-consumed": "qr-consumed",
    "qr-generated": "qr-generated",
    "qr-expired": "qr-expired",
    "qr-revoked": "qr-expired",
    "user-terminated": "user-terminated",
    "user-created": "user-created",
    "sso-enrolled": "sso-enrolled",
    "login": "login",
    "config-change": "config-change",
    "admin-action": "admin-action",
    "device-provisioned": "provisioning",
    "device-revoked": "provisioning",
    "device-extended": "provisioning",
}
ACTIVITY_TYPE_DEFAULT = "activity"
