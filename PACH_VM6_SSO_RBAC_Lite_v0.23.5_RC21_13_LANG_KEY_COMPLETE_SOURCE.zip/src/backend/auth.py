"""auth.py — the Authentik OIDC auth ladder.

Extracted verbatim from main.py. Behaviour is unchanged, including the fail-open
paths documented below; this move is about making the ladder importable and
testable on its own, not about changing what it does.

The ladder, weakest to strongest:

    require_user            valid OIDC bearer token
    require_admin           + membership of OIDC_ADMIN_GROUP  (bootstrap/UC only)
    require_permission(p)   + RBAC permission p, admin group as fallback
    require_directory_read  + ANY management permission, admin group as fallback

A client-scoped service principal (ARD-019) holds none of these: every guard
above answers it 403. Only the nine routes guarded by require_scope_or_* admit
it, and they hand the route its ClientScope so the target checks in
routers/_client_scope.py can run.

DEGRADED-STORE POSTURE — ruled by ARD-012, not an accident of exception handling.

  * Account locks are ENFORCED during a PostgreSQL outage. The check reads
    through to the Redis mirror (account_lock_mirror), and when neither store can
    answer it fails CLOSED with 503. Previously this swallowed the exception and
    continued, so an explicitly locked account holding the OIDC admin-group claim
    regained admin access for the whole outage.
  * RBAC lookup still falls through to the OIDC admin-group check, deliberately
    (ARD-012 §3). Group membership rides in the verified token and needs no
    store, which is what keeps an outage recoverable at all given ARD-002 removed
    breakglass.
  * The audit and IP-auto-block write paths still fail open, deliberately
    (ARD-012 §3): failing a request because a write failed turns a degraded audit
    trail into a denial of service.

Every degraded path logs once on transition — never silence, never per request
(ARD-012 §4). tests/unit/test_auth_fail_open.py pins all of it.
"""
from __future__ import annotations

import hashlib
import logging
import time
from typing import Any, Dict, Iterable, NamedTuple, Optional

import jwt
from fastapi import Depends, Header, HTTPException, Request, Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

import account_lock_mirror
from config import (
    DEV_AUTH_TOKEN,
    OIDC_ADMIN_GROUP,
    OIDC_GROUPS_CLAIM,
    OIDC_SERVICE_PERMISSIONS,
    ClientScope,
)
from db import first_party
from degraded import DegradedSite
from deps import ORGDB, authentik_client, ip_block_redis
from oidc_verify import OIDCInfraError, verify_bearer_token
from rate_limit import get_client_ip

logger = logging.getLogger(__name__)

# ARD-012 §4 — one warning entering degraded mode, one info on recovery, never a
# line per request. Four of these sites were fully silent and two logged per
# occurrence, which is why the posture went undecided for so long: degradation
# nobody can observe is indistinguishable from correct operation.
_lock_check_site = DegradedSite("check_account_locked", logger)
_auth_audit_site = DegradedSite("record_auth_failure", logger)
_ip_block_site = DegradedSite("count_failures_by_ip/block_ip", logger)
_rbac_site = DegradedSite("get_user_permissions", logger)
_directory_read_site = DegradedSite("require_directory_read/get_user_permissions", logger)

# DS-1/DS-2: Security thresholds for auto-lock and auto-block
AUTH_FAILURE_WINDOW_MINUTES = 15       # Sliding window for counting auth failures
IP_BLOCK_FAILURE_THRESHOLD = 20        # Per-IP failures before auto-block (NAT-friendly)
IP_BLOCK_DURATION_HOURS = 1            # Duration of auto-block on threshold breach

# DS-1: Token-hash dedup window — same bad token within N seconds counts once.
# - Fixes parallel-fanout lockout (dashboard mount fires 5 requests; a single
#   stale token would otherwise record 5 failures and instantly trip the lock).
# - Preserves brute-force defense: distinct tokens are still each counted.
# - Prefers Redis for worker-independence; falls back to in-memory dict if
#   Redis is unavailable (still correct for single-worker dev/test).
AUTH_FAILURE_DEDUP_SECONDS = 10
_AUTH_FAILURE_DEDUP_MAX = 512                    # Max in-memory cache size
_auth_failure_dedup: Dict[str, float] = {}       # fallback: sha256[:16] -> monotonic ts

# Claims returned by the dev/test bypass. Single-sourced here because the
# WebSocket handler needs exactly the same principal as the REST ladder; they
# were duplicated while both lived in main.py.
DEV_AUTH_CLAIMS: Dict[str, Any] = {
    "sub": "dev-admin",
    "uid": "dev-admin",
    "preferred_username": "dev-admin",
    "email": "admin@dev.local",
    "groups": [OIDC_ADMIN_GROUP],
}

# Directory-operator permissions: holding ANY of these marks a user as an
# operator who may read directory data (users, orgs, profiles). Self-service
# users (no management permission) use the /api/me* endpoints instead.
_MANAGEMENT_PERMISSIONS = {
    "user_management",
    "org_management",
    "device_provisioning",
    "audit_log_access",
    "system_configuration",
}


def _auth_failure_dedup_hit(token_fp: str) -> bool:
    """Return True if this fingerprint was already recorded within the window.

    - Redis path: SET NX EX — atomic, shared across uvicorn workers.
    - Fallback: module-level dict with bounded eviction (dev/test only).
    """
    if ip_block_redis is not None:
        try:
            ok = ip_block_redis.set(
                f"auth_fail_dedup:{token_fp}",
                "1",
                nx=True,
                ex=AUTH_FAILURE_DEDUP_SECONDS,
            )
            return not ok  # ok=True means we set it (first hit); None means dupe
        except Exception:
            pass  # fall through to in-memory
    now_mono = time.monotonic()
    last_seen = _auth_failure_dedup.get(token_fp)
    _auth_failure_dedup[token_fp] = now_mono
    if len(_auth_failure_dedup) > _AUTH_FAILURE_DEDUP_MAX:
        cutoff = now_mono - AUTH_FAILURE_DEDUP_SECONDS
        for _k in [k for k, v in _auth_failure_dedup.items() if v < cutoff]:
            _auth_failure_dedup.pop(_k, None)
    return last_seen is not None and (now_mono - last_seen) < AUTH_FAILURE_DEDUP_SECONDS


def _claims_from_auth_header(
    request: Request, authorization: Optional[str], allow_scoped: bool = False,
) -> Dict[str, Any]:
    """Extract and verify OIDC claims from Authorization header.

    Authentik OIDC is the sole auth path — no JWT fallback, no breakglass.
    DEV_AUTH_TOKEN bypass for dev/test only (never set in production).

    DS-1: After successful verification, rejects locked accounts (HTTP 403).
    DS-1: On failure, counts attempts and auto-locks when threshold exceeded.
    ARD-019: a scoped principal gets 403 unless the route admits it (allow_scoped).
    """
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing Bearer token")
    token = authorization.split(" ", 1)[1].strip()

    # Dev/test bypass — accepts a fixed token with admin claims
    if DEV_AUTH_TOKEN and token == DEV_AUTH_TOKEN:
        return dict(DEV_AUTH_CLAIMS)

    try:
        claims = verify_bearer_token(token)
    except OIDCInfraError as e:
        # OIDC provider unreachable (Authentik starting up, network issue).
        # Do NOT record as auth failure — this is infrastructure, not a bad token.
        # Do NOT count toward account lock or IP block thresholds.
        logger.warning("OIDC infrastructure unavailable: %s", e)
        raise HTTPException(503, "Authentication service temporarily unavailable") from e
    except Exception as e:
        client_ip = get_client_ip(request)
        user_agent = request.headers.get("user-agent")
        expired = isinstance(e, jwt.ExpiredSignatureError)

        # DS-1 dedup: suppress repeated accounting for the same bad token
        # within AUTH_FAILURE_DEDUP_SECONDS. Still returns 401 so the client
        # knows to refresh — only the audit/lock/IP-block side effects skip.
        token_fp = hashlib.sha256(token.encode("utf-8", "ignore")).hexdigest()[:16]
        if _auth_failure_dedup_hit(token_fp):
            logger.warning("Invalid bearer token: %s", e)
            raise HTTPException(401, "Invalid token") from None

        # H4: the username on a signature-invalid token is attacker-controlled.
        # Record it for audit only (never as an authenticated fact), and DO NOT
        # auto-lock that account — doing so let an attacker lock any victim
        # (incl. admins) by naming them in a forged token. In this architecture
        # Authentik performs password auth; a bad token here is not evidence of a
        # password-guessing attempt against the named user. Abuse control for
        # bad-token floods is IP-based blocking (below), spoof-resistant via H5.
        # Account lock remains an explicit admin action (the account_locks
        # endpoints) and is still enforced post-verification.
        username = None
        try:
            unverified = jwt.decode(token, options={"verify_signature": False})
            username = unverified.get("preferred_username") or unverified.get("sub")
        except Exception:
            pass

        # ARD-012 §3: this write path stays fail-open by decision. Failing the
        # request because an audit write failed converts a degraded audit trail
        # into a denial of service.
        try:
            ORGDB.record_auth_failure(
                client_ip=client_ip,
                endpoint=request.url.path,
                failure_reason="expired_token" if expired else "invalid_token",
                username=username,  # audit trail only — NOT used to auto-lock
                user_agent=user_agent,
            )
            _auth_audit_site.recover()
        except Exception as exc:
            _auth_audit_site.enter(exc)

        # DS-2: Auto-block IP after threshold. Also fail-open by ARD-012 §3 —
        # abuse control is a heuristic, not an administrator's explicit decision.
        # An expired token passed signature verification, so our IdP minted it (a
        # tab waking with a stale token): never abuse evidence, never counted.
        try:
            ip_failure_count = 0 if expired else ORGDB.count_failures_by_ip(
                client_ip, window_minutes=AUTH_FAILURE_WINDOW_MINUTES
            )
            if ip_failure_count >= IP_BLOCK_FAILURE_THRESHOLD:
                ORGDB.block_ip(
                    client_ip, duration_hours=IP_BLOCK_DURATION_HOURS,
                    reason="repeated_auth_failures",
                )
                logger.warning(
                    "IP %s auto-blocked after %d failures in %dmin window",
                    client_ip, ip_failure_count, AUTH_FAILURE_WINDOW_MINUTES,
                )
            _ip_block_site.recover()
        except Exception as exc:
            _ip_block_site.enter(exc)

        logger.warning("Invalid bearer token: %s", e)
        raise HTTPException(401, "Invalid token") from None

    if _foreign_service_token(claims):
        logger.warning("Refused token minted via service client %s for %s", claims.get("azp"), claims.get("preferred_username"))
        raise HTTPException(401, "Invalid token")

    # DS-1: Check account lock AFTER successful token verification
    uid = claims.get("preferred_username") or claims.get("sub")
    if uid:
        _enforce_account_lock(uid)

    if not allow_scoped and client_scope(claims):
        raise HTTPException(403, "Insufficient permissions")
    return claims


def _locked_response(locked_until: Optional[str]) -> HTTPException:
    return HTTPException(
        403,
        detail={
            "ok": False,
            "error": "ACCOUNT_LOCKED",
            "detail": f"Account locked until {locked_until}. Contact your administrator.",
            "locked_until": locked_until,
        },
    )


def _enforce_account_lock(uid: str) -> None:
    """Deny a locked principal, reading through to the Redis mirror (ARD-012 §1).

    PostgreSQL is authoritative. When its read raises we fall back to the mirror,
    and when the mirror cannot answer either — no Redis, Redis unreachable, or the
    completeness sentinel absent — lock state is genuinely unknowable and the
    request is denied with 503 rather than admitted.

    That last branch is the whole point of the ARD. The previous code swallowed
    the exception and continued, so an explicitly locked account holding the OIDC
    admin-group claim regained admin access for the duration of any PostgreSQL
    outage.
    """
    try:
        is_locked, locked_until = ORGDB.check_account_locked(uid)
    except Exception as exc:
        _lock_check_site.enter(exc, uid=uid)
        verdict, locked_until = account_lock_mirror.read_lock(uid)
        if verdict == account_lock_mirror.LOCKED:
            raise _locked_response(locked_until) from None
        if verdict == account_lock_mirror.UNKNOWN:
            # Both stores unreachable, or the mirror cannot claim completeness.
            # Fail closed: a miss here is indistinguishable from "never mirrored".
            raise HTTPException(
                503, "Authorization state is temporarily unavailable"
            ) from None
        return  # mirror is complete and says this principal is not locked
    _lock_check_site.recover()
    if is_locked:
        raise _locked_response(locked_until)


def _in_admin_group(claims: Dict[str, Any]) -> bool:
    """True when the verified token carries OIDC_ADMIN_GROUP (str or list claim)."""
    groups = claims.get(OIDC_GROUPS_CLAIM)
    if isinstance(groups, str):
        groups = [groups]
    return OIDC_ADMIN_GROUP in (groups or [])


def _principal_uid(claims: Dict[str, Any]) -> Optional[str]:
    """RBAC key for the caller.

    - OIDC `sub` is a hashed id (Authentik hashed_user_id) — not an LDAP uid.
    - preferred_username (= Authentik username = LDAP uid) is preferred.
    """
    return claims.get("preferred_username") or claims.get("uid") or claims.get("sub")


def _foreign_service_token(claims: Dict[str, Any]) -> bool:
    """True for a token minted through a service client for anyone but its own generated account (B2).

    The seed's access policy stops Authentik minting one; this refuses it should
    a provider lack that policy. Scoped principals come from the registry (env plus
    clients onboarded at runtime, ARD-022). The test-only client is in neither.
    """
    azp = claims.get("azp")
    return ((azp in OIDC_SERVICE_PERMISSIONS or first_party.scope_of(azp) is not None)
            and claims.get("preferred_username") != f"ak-{azp}-client_credentials")


def _service_permissions(claims: Dict[str, Any]) -> frozenset[str]:
    """Static RBAC grants for an API-to-API caller (OIDC_SERVICE_PERMISSIONS).

    - Only Authentik's provider-generated account `ak-<azp>-client_credentials`
      qualifies — a human's app-password token minted via the same provider
      carries its own username and gets nothing extra.
    - Needs no store, so service callers are unaffected by a PostgreSQL outage.
    """
    azp = claims.get("azp")
    if azp in OIDC_SERVICE_PERMISSIONS and claims.get("preferred_username") == f"ak-{azp}-client_credentials":
        return OIDC_SERVICE_PERMISSIONS[azp]
    return frozenset()


def client_scope(claims: Dict[str, Any]) -> Optional[ClientScope]:
    """The first-party client a scoped service principal is bound to (ARD-019), else None.

    The binding comes from the registry: env plus clients onboarded at runtime (ARD-022).

    Same identity check as _service_permissions: `azp` and the provider-generated
    username must both match, so a human's token via the same provider is not scoped.
    """
    azp = claims.get("azp")
    scope = first_party.scope_of(azp)
    if scope and claims.get("preferred_username") == f"ak-{azp}-client_credentials":
        return scope
    return None


def assert_can_confer(claims: Dict[str, Any], permissions: Iterable[str]) -> None:
    """Refuse to confer RBAC permissions the caller does not itself hold.

    - Anti-escalation guard for every write that grants permissions: setting a
      group's permissions, or adding a principal to a group that carries them.
    - Admin group: unbounded (it is the RBAC superuser).
    - Otherwise requested ⊆ caller's own permissions, else 403.
    - Fails CLOSED (503) when the RBAC store is unreachable — unlike the read
      ladder's ARD-012 §3 fall-through, a grant must never proceed unverified.
    """
    wanted = set(permissions)
    if not wanted or _in_admin_group(claims):
        return
    uid = _principal_uid(claims)
    try:
        held = set(ORGDB.get_user_permissions(uid)) if uid else set()
    except Exception:
        logger.warning("RBAC lookup failed for grant check uid=%s; refusing", uid, exc_info=True)
        raise HTTPException(503, "Authorization state is temporarily unavailable") from None
    missing = wanted - held - _service_permissions(claims)
    if missing:
        raise HTTPException(403, f"Cannot grant permissions you do not hold: {', '.join(sorted(missing))}")


def assert_can_take_over(claims: Dict[str, Any], uid: str) -> None:
    """Refuse a credential or identity write on a user who holds more than the caller (review finding 5).

    - A password reset, an unsuspend (new password) or a mail change hands the
      caller that account, so it is a grant of everything the account holds.
    - Admin group: unbounded. Otherwise the target may hold no RBAC permission
      the caller lacks, and must not be in OIDC_ADMIN_GROUP, else 403.
    - Fails CLOSED (503) when either store cannot answer, like assert_can_confer.
    """
    if _in_admin_group(claims):
        return
    caller = _principal_uid(claims)
    try:
        target_perms = set(ORGDB.get_user_permissions(uid))
        held = set(ORGDB.get_user_permissions(caller)) if caller else set()
        if authentik_client is None:
            raise RuntimeError("Authentik admin API not configured")
        target_is_admin = authentik_client.in_group(uid, OIDC_ADMIN_GROUP)
    except Exception:
        logger.warning("takeover check failed for uid=%s; refusing", uid, exc_info=True)
        raise HTTPException(503, "Authorization state is temporarily unavailable") from None
    if target_is_admin or target_perms - held - _service_permissions(claims):
        raise HTTPException(403, "Cannot change the credentials of a user who holds permissions you do not hold")


# Declaration only: puts `securitySchemes.HTTPBearer` + per-operation `security`
# into the OpenAPI document (Swagger "Authorize"). auto_error=False — the raw
# header below still drives verification, so runtime behaviour is unchanged.
_BEARER = HTTPBearer(
    auto_error=False,
    description="Authentik OIDC access token (user PKCE login, or client_credentials for services).",
)


def require_user(
    request: Request,
    authorization: Optional[str] = Header(default=None),
    _bearer: Optional[HTTPAuthorizationCredentials] = Security(_BEARER),
) -> Dict[str, Any]:
    """Require a valid OIDC Bearer token."""
    return _claims_from_auth_header(request, authorization)


def require_admin(claims: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
    """Require OIDC admin group membership.

    Intentionally used only for bootstrap/UC validation endpoints that need
    admin-level access without granular RBAC (FIRA ARCH-01). All other
    admin endpoints use require_permission() for fine-grained RBAC.
    """
    if not _in_admin_group(claims):
        raise HTTPException(403, "Admin group required")
    return claims


def require_permission(permission: str):
    """RBAC permission check — requires OIDC auth.

    Checks: group RBAC -> admin fallback -> deny.
    """
    def dependency(claims: Dict[str, Any] = Depends(require_user)):
        _check_permission(claims, permission)
        return claims
    return Depends(dependency)


def _check_permission(claims: Dict[str, Any], permission: str) -> None:
    if permission in _service_permissions(claims):
        return
    uid = _principal_uid(claims)
    if uid:
        # ARD-012 §3: RBAC falls through to the OIDC admin group on purpose.
        # Group membership arrives in the verified token and needs no store,
        # which is what keeps a PostgreSQL outage recoverable under ARD-002's
        # no-breakglass rule.
        try:
            user_permissions = ORGDB.get_user_permissions(uid)
            _rbac_site.recover()
            if permission in user_permissions:
                return
        except Exception as exc:
            _rbac_site.enter(exc, uid=uid)
            logger.warning("RBAC lookup failed for uid=%s, falling through to admin check", uid)
    # Admin group membership is always a valid fallback
    if _in_admin_group(claims):
        return
    raise HTTPException(403, "Insufficient permissions")


def require_directory_read(
    request: Request,
    authorization: Optional[str] = Header(default=None),
    _bearer: Optional[HTTPAuthorizationCredentials] = Security(_BEARER),
) -> Dict[str, Any]:
    """Authorize a directory read (C1, Model A — one deployment per tenant).

    Restricts directory-wide / arbitrary-target reads to directory operators
    (any management permission) or admins, so a self-service user cannot
    enumerate the directory (users, orgs, groups) or read another user's
    devices/stats or org-profile config. Does NOT gate the self-service
    /api/me* endpoints, which scope to the caller's own identity.

    Verified: C1 deny-path (non-admin → 403) covered by
    tests/test_rbac.py::TestC1DirectoryReadAuthz (ARD-009). Aggregate-browse
    endpoints moved behind this gate per the ARD-009 amendment (address-book
    visibility resolved to operator-only).
    """
    claims = _claims_from_auth_header(request, authorization)
    _check_directory_read(claims)
    return claims


def _check_directory_read(claims: Dict[str, Any]) -> None:
    if _service_permissions(claims) & _MANAGEMENT_PERMISSIONS:
        return
    uid = _principal_uid(claims)
    if uid:
        # ARD-012 §3 — same deliberate fall-through as require_permission.
        try:
            permissions = set(ORGDB.get_user_permissions(uid))
            _directory_read_site.recover()
            if permissions & _MANAGEMENT_PERMISSIONS:
                return
        except Exception as exc:
            _directory_read_site.enter(exc, uid=uid)
            logger.warning("directory-read RBAC lookup failed for uid=%s", uid)
    if _in_admin_group(claims):
        return
    raise HTTPException(403, "Directory read requires an operator role")


class Caller(NamedTuple):
    """Who called one of ARD-019's nine routes: `scope` is None for every unscoped caller."""

    claims: Dict[str, Any]
    scope: Optional[ClientScope]


def _scoped_or(check):
    def dependency(
        request: Request,
        authorization: Optional[str] = Header(default=None),
        _bearer: Optional[HTTPAuthorizationCredentials] = Security(_BEARER),
    ) -> Caller:
        claims = _claims_from_auth_header(request, authorization, allow_scoped=True)
        scope = client_scope(claims)
        if scope:
            # Verified claims only: the per-azp rate limit keys on this (ARD-019 §6).
            request.state.scoped_azp = claims["azp"]
            return Caller(claims, scope)
        check(claims)
        return Caller(claims, None)
    return dependency


def require_scope_or_permission(permission: str):
    """ARD-019: a scoped principal, else require_permission(permission)."""
    return Depends(_scoped_or(lambda claims: _check_permission(claims, permission)))


# Same, else require_directory_read.
require_scope_or_directory_read = _scoped_or(_check_directory_read)


def verify_ws_token(token: str | None) -> Dict[str, Any] | None:
    """Verify a WebSocket auth token. Returns claims dict or None on failure.

    The WebSocket carries its token as a query param rather than a header, so it
    cannot reuse the Depends() ladder. It admits what require_admin admits on
    the REST and SSE feeds: the admin group, never a locked account (review
    finding 6). Shares DEV_AUTH_CLAIMS with the REST path so the two cannot drift.
    """
    if not token:
        return None
    if DEV_AUTH_TOKEN and token == DEV_AUTH_TOKEN:
        return dict(DEV_AUTH_CLAIMS)
    try:
        claims = verify_bearer_token(token)
    except Exception:
        return None
    if client_scope(claims) or _foreign_service_token(claims) or not _in_admin_group(claims):
        return None
    uid = claims.get("preferred_username") or claims.get("sub")
    try:
        if uid:
            _enforce_account_lock(uid)
    except HTTPException:
        return None
    return claims
