"""config.py

- Environment config (pydantic-free, plain os.getenv — read at import time)
- Startup validation: UC provisioning completeness, dev-auth-bypass safety
- setup_logging(): structured JSON stdout logging + request-id injection (ARD-008)
"""

import contextvars
import json
import logging
import os
import re
import sys
from datetime import datetime, timezone
from typing import Iterable, NamedTuple

LDAP_URI = os.getenv("LDAP_URI", "ldap://127.0.0.1:389")
LDAP_BASE_DN = os.getenv("LDAP_BASE_DN", "dc=example,dc=com")
LDAP_TENANT = os.getenv("LDAP_TENANT", "example")

# Service account for directory manager (NOT end-user)
LDAP_BIND_DN = os.getenv("LDAP_BIND_DN", "cn=admin,dc=example,dc=com")
LDAP_BIND_PW = os.getenv("LDAP_BIND_PW", "adminpassword")

OU_ORG = f"ou=org,{LDAP_BASE_DN}"
OU_PEOPLE = f"ou=people,{LDAP_BASE_DN}"
OU_GROUPS = f"ou=groups,{LDAP_BASE_DN}"

# Provisioned LDAP client accounts (client-provisioning feature) live here.
OU_CLIENTS = os.getenv("LDAP_CLIENTS_OU", f"ou=clients,{LDAP_BASE_DN}")

# If you enable ldaps / startTLS later
LDAP_USE_SSL = os.getenv("LDAP_USE_SSL", "false").lower() == "true"

# ----------------------------
# Directory Portal DB (PostgreSQL)
# ----------------------------
# PostgreSQL everywhere (dev + prod). Keep Authentik on the same Postgres *server*,
# but use a separate database/schema + DB user for clean separation.
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg2://azblink_directory:azblink_directory@127.0.0.1:5432/azblink_directory",
)

# ----------------------------
# Device provision token limits
# ----------------------------
DEVICE_PROVISION_MAX_EXTEND_SEC = int(os.getenv("DEVICE_PROVISION_MAX_EXTEND_SEC", "86400"))

# ----------------------------
# LDAP client inventory (settings: clients bound to platform OpenLDAP)
# ----------------------------
# Path (inside the API container) to slapd's olcLogFile stats log. The OpenLDAP
# data volume is mounted read-only here. No fail-fast: the collector degrades
# gracefully (empty inventory) if the file is missing/unreadable.
LDAP_STATS_LOG_PATH = os.getenv("LDAP_STATS_LOG_PATH", "/var/lib/ldap/slapd-stats.log")
# Classification hints — CSV of "service:cidr" (e.g. "asterisk:192.168.122.0/24").
LDAP_KNOWN_SERVICE_CIDRS = os.getenv("LDAP_KNOWN_SERVICE_CIDRS", "")

# TLS endpoints whose certificate expiry the service probe exports (CSV of
# host:port, e.g. "auth.example.com:443,openldap:636"). Empty = none probed.
TLS_EXPIRY_TARGETS = [t.strip() for t in os.getenv("TLS_EXPIRY_TARGETS", "").split(",") if t.strip()]

# The relay path as a relay sees it (ARD-021 §3): the public name, the CA relays
# trust, and the listeners as CSV of kind=ip:port, kind one of authentik, api,
# ldaps (e.g. "authentik=10.0.0.5:443,api=10.0.0.5:8443,ldaps=10.0.0.5:636").
# docker-compose.tls.yml sets the first two. Empty targets = not probed.
def _pairs(raw: str) -> list[tuple[str, str]]:
    """CSV of name=value -> [(name, value)]; entries without '=' are dropped."""
    return [(name, value) for name, value in (t.strip().split("=", 1) for t in raw.split(",") if "=" in t)]


RELAY_PATH_HOST = os.getenv("RELAY_PATH_HOST", "").strip()
RELAY_PATH_CA = os.getenv("RELAY_PATH_CA", "").strip()
RELAY_PATH_TARGETS = _pairs(os.getenv("RELAY_PATH_TARGETS", ""))

# Service probes that depend on which compose files and profile run: the admin UI
# is directory-ui (dev) or directory-ui-prod (prod), and the browser edge exists
# only with docker-compose.tls.yml. Each compose file sets what it adds; the
# rest of the probe list is fixed in observability.py.
UI_PROBE_URL = os.getenv("UI_PROBE_URL", "http://directory-ui:5173/").strip()
EDGE_PROBE_TARGETS = _pairs(os.getenv("EDGE_PROBE_TARGETS", ""))  # CSV of name=url

# ----------------------------
# Authentik / OIDC (sole auth path for admin UI)
# ----------------------------
OIDC_ISSUER = os.getenv("OIDC_ISSUER", "")
OIDC_DISCOVERY_URL = os.getenv("OIDC_DISCOVERY_URL", "")
OIDC_AUDIENCE = os.getenv("OIDC_AUDIENCE", "azblink-directory")
OIDC_GROUPS_CLAIM = os.getenv("OIDC_GROUPS_CLAIM", "groups")
OIDC_ADMIN_GROUP = os.getenv("OIDC_ADMIN_GROUP", "IT-Admins")
# Comma-separated list of accepted issuers (for multi-URL setups:
# Docker-internal + Cloudflare tunnel). Falls back to OIDC_ISSUER if unset.
# Both with and without trailing slash are accepted — Authentik includes a
# trailing slash in the JWT `iss` claim, but env config may omit it.
_raw_issuers = [s.strip() for s in os.getenv("OIDC_ACCEPTED_ISSUERS", "").split(",") if s.strip()]
OIDC_ACCEPTED_ISSUERS: list[str] = []
for _iss in _raw_issuers:
    _stripped = _iss.rstrip("/")
    OIDC_ACCEPTED_ISSUERS.append(_stripped)
    OIDC_ACCEPTED_ISSUERS.append(_stripped + "/")

# Accepted `aud` values (CSV). Defaults to OIDC_AUDIENCE alone. Add the client_id
# of each confidential service provider so its client_credentials tokens verify.
OIDC_ACCEPTED_AUDIENCES: list[str] = [
    s.strip() for s in os.getenv("OIDC_ACCEPTED_AUDIENCES", "").split(",") if s.strip()
] or [OIDC_AUDIENCE]

# API-to-API RBAC: "client_id:perm|perm,client_id:perm". A service principal
# (Authentik's generated `ak-<client_id>-client_credentials` account) has no LDAP
# entry, so it cannot join an RBAC group — its permissions are declared here.
OIDC_SERVICE_PERMISSIONS: dict[str, frozenset[str]] = {
    _cid.strip(): frozenset(p.strip() for p in _perms.split("|") if p.strip())
    for _cid, _, _perms in (
        e.partition(":") for e in os.getenv("OIDC_SERVICE_PERMISSIONS", "").split(",") if ":" in e
    )
}

# ----------------------------
# Authentik Admin API (session/token revocation on user termination)
# ----------------------------
AUTHENTIK_API_URL = os.getenv("AUTHENTIK_API_URL", "")
AUTHENTIK_API_TOKEN = os.getenv("AUTHENTIK_API_TOKEN", "")

# Headless first-party clients (ARD-018): the same JSON the Authentik seed reads,
# {client_id: [redirect_uri, ...]}. The directory only needs the ids: groups named
# `<client_id>-*` are that client's role groups and sync into Authentik.
FIRST_PARTY_CLIENT_IDS: tuple[str, ...] = tuple(
    sorted(json.loads(os.getenv("AUTHENTIK_FIRST_PARTY_CLIENTS", "").strip() or "{}"))
)

_ROLE = re.compile(r"^[a-z0-9]+$")


class ClientScope(NamedTuple):
    """ARD-019: the one first-party client a scoped service principal may write."""

    client_id: str
    roles: frozenset[str]


def assert_first_party_ids_not_nested(ids: Iterable[str]) -> None:
    """Refuse `safenest` beside `safenest-a1`: `<a>-*` groups would match both (ARD-019 §1)."""
    ids = sorted(ids)
    nested = [(a, b) for a in ids for b in ids if b.startswith(f"{a}-")]
    if nested:
        raise RuntimeError(f"first-party client ids nest: {nested}; one id may not start with another's '<id>-'")


def parse_service_client_scopes(
    raw: str, first_party_ids: Iterable[str], service_permissions: dict[str, frozenset[str]],
) -> dict[str, ClientScope]:
    """OIDC_SERVICE_CLIENT_SCOPES: "svc:first_party:role|role,…" (ARD-019, owner decision 4).

    Startup refuses an unregistered first-party client, a principal that also holds
    RBAC permissions (an empty `svc:` permission entry is fine), or a missing/bad role.
    """
    first_party = set(first_party_ids)
    scopes: dict[str, ClientScope] = {}
    for entry in (e.strip() for e in raw.split(",") if e.strip()):
        svc, client_id, roles_raw = (p.strip() for p in (entry.split(":") + ["", ""])[:3])
        roles = frozenset(r.strip() for r in roles_raw.split("|") if r.strip())
        if not svc or client_id not in first_party:
            raise RuntimeError(f"OIDC_SERVICE_CLIENT_SCOPES {entry!r}: {client_id!r} is not in AUTHENTIK_FIRST_PARTY_CLIENTS")
        if not roles or not all(_ROLE.match(r) for r in roles):
            raise RuntimeError(f"OIDC_SERVICE_CLIENT_SCOPES {entry!r}: needs roles matching {_ROLE.pattern}, '|'-separated")
        if service_permissions.get(svc):
            raise RuntimeError(f"OIDC_SERVICE_CLIENT_SCOPES {svc!r} also holds OIDC_SERVICE_PERMISSIONS; a principal is one or the other")
        scopes[svc] = ClientScope(client_id, roles)
    return scopes


assert_first_party_ids_not_nested(FIRST_PARTY_CLIENT_IDS)
OIDC_SERVICE_CLIENT_SCOPES = parse_service_client_scopes(
    os.getenv("OIDC_SERVICE_CLIENT_SCOPES", ""), FIRST_PARTY_CLIENT_IDS, OIDC_SERVICE_PERMISSIONS)

# ----------------------------
# UC Server (SIP/XMPP session termination) — stub until API spec available
# ----------------------------
UC_SERVER_API_URL = os.getenv("UC_SERVER_API_URL", "")
UC_SERVER_API_TOKEN = os.getenv("UC_SERVER_API_TOKEN", "")

# ----------------------------
# Dev/test auth bypass (NEVER set in production)
# ----------------------------
# When set, a Bearer token matching this value bypasses OIDC verification
# and returns admin claims. Used for integration tests against the Docker stack
# where no real Authentik instance is available.
DEV_AUTH_TOKEN = os.getenv("DEV_AUTH_TOKEN", "")

# ----------------------------
# Deployment environment guard
# ----------------------------
# ENVIRONMENT=production must never run with the DEV_AUTH_TOKEN bypass enabled.
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")

# Environments where the DEV_AUTH_TOKEN bypass is permitted.
_DEV_ENVIRONMENTS = {"development", "dev", "test", "ci"}

# API docs (/api/docs, /api/redoc, /api/openapi.json) — on in dev environments,
# off elsewhere unless DOCS_ENABLED=1. Production exposure belongs behind an
# Authentik ForwardAuth (integrators group), not on the open LAN.
DOCS_ENABLED = os.getenv("DOCS_ENABLED", "1" if ENVIRONMENT in _DEV_ENVIRONMENTS else "0") == "1"


def assert_dev_token_safe(dev_token: str, environment: str) -> None:
    """Refuse startup when the dev auth bypass is enabled outside a dev environment.

    - DEV_AUTH_TOKEN grants full admin claims to anyone holding the token
    - default-deny: any environment NOT in _DEV_ENVIRONMENTS (production, prod,
      staging, typos, empty string) refuses to start while the token is set
    """
    if dev_token and environment.lower().strip() not in _DEV_ENVIRONMENTS:
        raise RuntimeError(
            "DEV_AUTH_TOKEN is set while ENVIRONMENT=%r is not a recognized dev "
            "environment — this would allow full authentication bypass. "
            "Unset DEV_AUTH_TOKEN to start." % environment
        )


# Known development defaults that must never survive into a real deployment.
# Mirrors the values baked into config defaults / .env.example / compose.
_INSECURE_DEFAULT_LDAP_PW = "adminpassword"
_INSECURE_DEFAULT_DB_USERINFO = "azblink_directory:azblink_directory@"
_INSECURE_DEFAULT_AUTHENTIK_TOKEN = "dev-authentik-api-token"
_INSECURE_DEFAULT_QR_SECRET = "dev_signing_secret_change_in_prod"

# Demo identities that must never appear in a non-dev directory. The dev demo
# bootstrap (bootstrap.demo.ldif) + seed roster are gated behind
# docker-compose.dev.yml; these canonical uids are the runtime tripwire for a
# prod volume that a prior demo-seeded deploy polluted. See assert_no_demo_identities.
_DEMO_IDENTITY_UIDS = frozenset(
    {"robert", "alex", "sarah", "james", "mei", "kevin", "laura"}
)


def _ldap_host(ldap_uri: str) -> str:
    """Extract the host portion of an ldap[s]:// URI (best-effort, stdlib-free)."""
    rest = ldap_uri.split("://", 1)[-1]
    hostport = rest.split("/", 1)[0]
    # strip credentials if present, then take host (handles ipv6 [::1] loosely)
    hostport = hostport.rsplit("@", 1)[-1]
    if hostport.startswith("["):
        return hostport[1 : hostport.find("]")] if "]" in hostport else hostport
    return hostport.rsplit(":", 1)[0] if ":" in hostport else hostport


_LOOPBACK_HOSTS = {"localhost", "127.0.0.1", "::1", ""}
# ARD-021 §3: plaintext :389 stays on the stack's docker network for the API, so
# the compose service name counts as local. Anything else still needs TLS.
_PLAINTEXT_LDAP_OK_HOSTS = _LOOPBACK_HOSTS | {"openldap"}


def assert_production_config_safe(
    environment: str,
    *,
    ldap_bind_pw: str,
    database_url: str,
    ldap_use_ssl: bool,
    ldap_uri: str,
    authentik_api_token: str,
    org_qr_signing_secret: str = "",
) -> None:
    """Refuse startup when a non-dev deployment runs on known-insecure defaults.

    Default-deny, mirroring assert_dev_token_safe: enforcement fires for any
    environment NOT in _DEV_ENVIRONMENTS (production, prod, staging, typos,
    empty). Dev environments are exempt so the Docker dev stack keeps working
    on its throwaway defaults.

    Caveat (documented, not fixed here): if a production deploy forgets to set
    ENVIRONMENT at all, it defaults to "development" and these checks are
    skipped — operators MUST set ENVIRONMENT=production. This mirrors the
    existing dev-token guard's limitation.

    Checks (H6 secret hygiene + H2 transport):
    - LDAP bind password left at the shipped default
    - PostgreSQL DSN left at the default user==password credentials
    - Authentik admin API token left at the dev default
    - ORG_QR_SIGNING_SECRET left at the shipped default
    - Plaintext LDAP (no SSL, ldap:// scheme) to a host other than loopback or
      the compose `openldap` service (ARD-021 §3)
    """
    if environment.lower().strip() in _DEV_ENVIRONMENTS:
        return

    violations = []
    if ldap_bind_pw == _INSECURE_DEFAULT_LDAP_PW:
        violations.append("LDAP_BIND_PW is the shipped default 'adminpassword'")
    if _INSECURE_DEFAULT_DB_USERINFO in database_url:
        violations.append("DATABASE_URL uses the default azblink_directory credentials")
    if authentik_api_token == _INSECURE_DEFAULT_AUTHENTIK_TOKEN:
        violations.append("AUTHENTIK_API_TOKEN is the dev default 'dev-authentik-api-token'")
    if org_qr_signing_secret == _INSECURE_DEFAULT_QR_SECRET:
        violations.append(
            "ORG_QR_SIGNING_SECRET is the shipped default "
            "'dev_signing_secret_change_in_prod' — QR/device tokens would be forgeable"
        )
    plaintext_ldap = (not ldap_use_ssl) and not ldap_uri.startswith("ldaps://")
    if plaintext_ldap and _ldap_host(ldap_uri) not in _PLAINTEXT_LDAP_OK_HOSTS:
        violations.append(
            "LDAP transport is plaintext (ldap://, LDAP_USE_SSL=false) to a "
            "non-loopback host — bind password and UC credentials would cross "
            "the wire in the clear; set LDAP_USE_SSL=true or use ldaps://"
        )

    if violations:
        raise RuntimeError(
            "Refusing to start in ENVIRONMENT=%r with insecure defaults:\n  - %s\n"
            "Override these before deploying." % (environment, "\n  - ".join(violations))
        )


def assert_no_demo_identities(environment: str, conn) -> list[str]:
    """Non-bricking prod tripwire: report which canonical demo identities exist.

    Runs in the app lifespan (LDAP reachable), NOT at import time. Despite the
    "assert_" name this NEVER raises and NEVER blocks startup — the caller logs
    CRITICAL and exposes a health flag, then keeps serving. Crash-looping here
    would brick an in-place prod upgrade converge of an already-polluted volume;
    the Ansible preflight gate + ldap_admin.yml purge are the enforcing layers.

    - Returns [] for dev environments (skipped) and for a clean prod directory.
    - Returns the sorted list of demo uids found under ou=people otherwise.
    - Defensive: any LDAP/search error → [] (detection fails open).
    """
    if environment.lower().strip() in _DEV_ENVIRONMENTS:
        return []
    try:
        conn.search(
            OU_PEOPLE,
            "(objectClass=inetOrgPerson)",
            search_scope="SUBTREE",
            attributes=["uid"],
        )
        present = set()
        for entry in conn.entries:
            uid = str(entry.uid) if "uid" in entry else ""
            if uid in _DEMO_IDENTITY_UIDS:
                present.add(uid)
        return sorted(present)
    except Exception:
        return []

# ----------------------------
# Redis (rate limiting, caching)
# ----------------------------
REDIS_URL = os.getenv("REDIS_URL", "redis://127.0.0.1:6379/0")

# ----------------------------
# Trusted reverse proxies (X-Forwarded-For handling) — H5
# ----------------------------
# Comma-separated IPs/CIDRs of reverse proxies allowed to set X-Forwarded-For.
# SECURE DEFAULT: empty → X-Forwarded-For is NOT trusted and the socket peer
# address is used for rate limiting / IP blocking. Set this to your load
# balancer's address(es) so client IPs are derived correctly without letting
# arbitrary clients spoof XFF to evade limits or poison another IP's counters.
TRUSTED_PROXIES = [p.strip() for p in os.getenv("TRUSTED_PROXIES", "").split(",") if p.strip()]

# ----------------------------
# SIP Auth
# ----------------------------
SIP_AUTH_REALM = os.getenv("SIP_AUTH_REALM", "asterisk")

# Widest SIP extension range a profile may hold (end - start + 1). Each PBX gets
# its own disjoint block sized to its capacity, up to this ceiling (ARD-020,
# 2026-10-21 amendment). Ranges wider than this from before it existed stay
# valid until changed.
SIP_RANGE_MAX_SIZE = int(os.getenv("SIP_RANGE_MAX_SIZE", "1000"))

# ----------------------------
# Observability — structured logging (ARD-008 Phase 0)
# ----------------------------
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# Request-scoped correlation ID — set by main.py's request-id middleware,
# read by _RequestIdFilter below so every log record emitted during a
# request's handling (any module, any depth) carries the same id.
request_id_ctx: contextvars.ContextVar[str] = contextvars.ContextVar("request_id", default="-")


class _JsonLogFormatter(logging.Formatter):
    """Renders a log record as one JSON line for stdout → Loki/Alloy ingestion.

    - Fields: ts, level, logger, message, request_id (+ exc_info when present)
    - Never raises — falls back to the stdlib plain-text format on any error,
      so a formatting bug can never take down a request (design invariant).
    """

    def format(self, record: logging.LogRecord) -> str:
        try:
            payload = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
                "request_id": getattr(record, "request_id", "-"),
            }
            if record.exc_info:
                payload["exc_info"] = self.formatException(record.exc_info)
            return json.dumps(payload)
        except Exception:
            return super().format(record)


class _RequestIdFilter(logging.Filter):
    """Injects the active request_id (from the contextvar) onto every record."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.request_id = request_id_ctx.get()
        except Exception:
            record.request_id = "-"
        return True


def setup_logging() -> None:
    """Configure root logging: JSON stdout lines, LOG_LEVEL, request-id injection.

    - Idempotent (clears prior handlers) — safe to call more than once
    - Attaches to the ROOT logger so app `logging.getLogger(__name__)` loggers
      surface consistently. Previously they rode uvicorn's unconfigured root
      logger (no handlers, default WARNING threshold) and were silently dropped.
    """
    level = getattr(logging, LOG_LEVEL.upper(), logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(_JsonLogFormatter())
    handler.addFilter(_RequestIdFilter())

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)


# ----------------------------
# SSO Device Provisioning
# ----------------------------
DEVICE_PROVISION_TTL_SEC = int(os.getenv("DEVICE_PROVISION_TTL_SEC", "2592000"))  # 30 days
DEVICE_PROVISION_MAX_DEFAULT = int(os.getenv("DEVICE_PROVISION_MAX_DEFAULT", "5"))

# ----------------------------
# ucChat core provisioning defaults
# ----------------------------
UCCHAT_XMPP_DOMAIN = os.getenv("UCCHAT_XMPP_DOMAIN", "")
UCCHAT_XMPP_WS_URL = os.getenv("UCCHAT_XMPP_WS_URL", "")
UCCHAT_SIP_DOMAIN = os.getenv("UCCHAT_SIP_DOMAIN", "")
UCCHAT_SIP_WSS_URL = os.getenv("UCCHAT_SIP_WSS_URL", "")

# ----------------------------
# CORS — comma-separated list of allowed origins
# ----------------------------
CORS_ORIGINS = [o.strip() for o in os.environ.get("CORS_ORIGINS", "http://localhost:8081,http://127.0.0.1:8081").split(",") if o.strip()]


# ----------------------------
# Startup validation
# ----------------------------
def _validate_uc_config():
    """Fail fast if UC provisioning config is incomplete."""
    missing = []
    if not UCCHAT_XMPP_DOMAIN:
        missing.append("UCCHAT_XMPP_DOMAIN")
    if not UCCHAT_XMPP_WS_URL:
        missing.append("UCCHAT_XMPP_WS_URL")
    if not UCCHAT_SIP_DOMAIN:
        missing.append("UCCHAT_SIP_DOMAIN")
    if not UCCHAT_SIP_WSS_URL:
        missing.append("UCCHAT_SIP_WSS_URL")
    if missing:
        raise RuntimeError(
            f"UC provisioning requires: {', '.join(missing)}. "
            "Set these environment variables to enable UC services."
        )


_validate_uc_config()

# Guard runs at import time so EVERY entrypoint that imports config is protected,
# not just main.py. Fails fast if the dev auth bypass is enabled outside dev.
assert_dev_token_safe(DEV_AUTH_TOKEN, ENVIRONMENT)

# H6/H2: refuse to start a non-dev deployment on known-insecure defaults
# (default LDAP/DB/Authentik credentials, plaintext LDAP to a remote host).
assert_production_config_safe(
    ENVIRONMENT,
    ldap_bind_pw=LDAP_BIND_PW,
    database_url=DATABASE_URL,
    ldap_use_ssl=LDAP_USE_SSL,
    ldap_uri=LDAP_URI,
    authentik_api_token=AUTHENTIK_API_TOKEN,
    org_qr_signing_secret=os.getenv("ORG_QR_SIGNING_SECRET", ""),
)
