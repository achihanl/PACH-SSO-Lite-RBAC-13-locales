"""Event bus for real-time activity feed delivery.

- asyncio.Queue per subscriber (bounded, drop-on-full)
- Non-blocking broadcast to all connected WebSocket/SSE clients
- Singleton lifecycle managed via init/get functions
- Thread-safe subscriber management

MULTI-WORKER DELIVERY
---------------------
Subscriber queues are necessarily per-process: they hold references to live
WebSocket/SSE connections owned by one uvicorn worker. Fan-out between workers
therefore has to go through something shared, and this module uses a Redis
pub/sub channel.

That is not a theoretical concern. deploy/dev/Dockerfile.api runs
`--workers ${UVICORN_WORKERS:-2}` on the non-reload (production) path, so before
this the platform silently lost events: an admin's WebSocket lived on worker A,
a user created on worker B published to worker B's in-process bus only, and the
admin never saw it. No error, no log line, roughly half the events gone.

Delivery path:
  publish_sync() -> Redis PUBLISH -> every worker's listener -> local queues

When Redis is not configured (or a publish fails), delivery falls back to the
local queues alone. That is correct for single-worker dev and for a Redis
outage; it is the pre-existing behaviour, now the exception rather than the rule.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

ACTIVITY_CHANNEL = "azblink:activity"


class ActivityBus:
    """Pub/sub event bus for broadcasting activity events to connected clients.

    - Each subscriber gets its own asyncio.Queue
    - publish() fans out to all queues (non-blocking, drops on full)
    - subscribe/unsubscribe are safe to call concurrently
    - With Redis configured, fan-out crosses uvicorn workers
    """

    def __init__(
        self,
        max_queue_size: int = 100,
        redis_client: Optional[Any] = None,
        channel: str = ACTIVITY_CHANNEL,
    ):
        self._subscribers: set[asyncio.Queue[Dict[str, Any]]] = set()
        self._max_queue_size = max_queue_size
        self._redis = redis_client
        self._channel = channel
        # Set when a cross-worker publish fails, so the fallback is visible in
        # logs rather than looking like normal operation.
        self._redis_degraded = False

    def subscribe(self) -> asyncio.Queue[Dict[str, Any]]:
        """Create a new subscriber queue. Caller must unsubscribe() when done."""
        queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue(maxsize=self._max_queue_size)
        self._subscribers.add(queue)
        logger.debug("Activity bus: subscriber added (total=%d)", len(self._subscribers))
        return queue

    def unsubscribe(self, queue: asyncio.Queue[Dict[str, Any]]) -> None:
        """Remove a subscriber queue. Idempotent (safe to call multiple times)."""
        self._subscribers.discard(queue)
        logger.debug("Activity bus: subscriber removed (total=%d)", len(self._subscribers))

    def deliver_local(self, event: Dict[str, Any]) -> None:
        """Fan out to this process's subscriber queues only.

        Called by the Redis listener for events from any worker, and directly by
        publish_sync() when Redis is unavailable.

        Uses put_nowait() so it's safe to call from sync code (e.g., the orgdb
        audit recording methods running in FastAPI's threadpool).
        """
        if not self._subscribers:
            return
        dropped = 0
        for queue in list(self._subscribers):  # copy to avoid mutation during iteration
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                dropped += 1
        if dropped:
            logger.warning("Activity bus: dropped event for %d slow subscriber(s)", dropped)

    def publish_sync(self, event: Dict[str, Any]) -> None:
        """Broadcast an event to every worker (synchronous, thread-safe).

        With Redis, publishes to the shared channel and returns — this worker's
        own listener delivers it locally alongside the others, so there is
        exactly one delivery per subscriber and no special case for the
        publishing worker.
        """
        if self._redis is not None:
            try:
                self._redis.publish(self._channel, json.dumps(event))
                if self._redis_degraded:
                    logger.info("Activity bus: Redis fan-out recovered")
                    self._redis_degraded = False
                return
            except Exception:
                if not self._redis_degraded:
                    logger.warning(
                        "Activity bus: Redis publish failed — falling back to "
                        "in-process delivery. Other workers will NOT see events "
                        "until Redis recovers.",
                        exc_info=True,
                    )
                    self._redis_degraded = True
        self.deliver_local(event)

    async def publish(self, event: Dict[str, Any]) -> None:
        """Broadcast event to all subscribers (async wrapper of publish_sync)."""
        self.publish_sync(event)

    async def run_listener(self) -> None:
        """Lifespan task: relay events from the shared channel into local queues.

        No-op when Redis is not configured — publish_sync() then delivers
        locally and this task has nothing to do.

        redis-py's pubsub API is blocking, so get_message runs off the event loop
        via run_in_executor — the same convention as the LDAP collector and the
        service probe. Like those, this must never crash the app.
        """
        if self._redis is None:
            logger.info("Activity bus: no Redis, delivery is in-process only")
            return

        loop = asyncio.get_event_loop()
        pubsub = self._redis.pubsub(ignore_subscribe_messages=True)
        await loop.run_in_executor(None, pubsub.subscribe, self._channel)
        logger.info("Activity bus: listening on %s for cross-worker events", self._channel)
        try:
            while True:
                try:
                    message = await loop.run_in_executor(
                        None, lambda: pubsub.get_message(timeout=1.0)
                    )
                    if not message:
                        continue
                    data = message.get("data")
                    if isinstance(data, bytes):
                        data = data.decode("utf-8", "replace")
                    self.deliver_local(json.loads(data))
                except asyncio.CancelledError:
                    raise
                except Exception:  # noqa: BLE001 — never kill the task
                    logger.warning("Activity bus: listener iteration failed", exc_info=True)
                    await asyncio.sleep(1.0)
        finally:
            try:
                await loop.run_in_executor(None, pubsub.close)
            except Exception:
                pass

    @property
    def subscriber_count(self) -> int:
        """Number of active subscribers."""
        return len(self._subscribers)


# ── Singleton lifecycle ──────────────────────────────────────────────

_activity_bus: ActivityBus | None = None


def init_activity_bus(
    max_queue_size: int = 100,
    redis_client: Optional[Any] = None,
) -> ActivityBus:
    """Initialize the global ActivityBus (call once in FastAPI lifespan)."""
    global _activity_bus
    _activity_bus = ActivityBus(max_queue_size=max_queue_size, redis_client=redis_client)
    return _activity_bus


def get_activity_bus() -> ActivityBus:
    """Get the global ActivityBus instance. Raises RuntimeError if not initialized."""
    if _activity_bus is None:
        raise RuntimeError("ActivityBus not initialized — call init_activity_bus() in lifespan")
    return _activity_bus
