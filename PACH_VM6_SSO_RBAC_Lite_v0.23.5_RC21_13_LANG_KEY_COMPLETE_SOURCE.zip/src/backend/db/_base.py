"""Typing base for the OrgDB mixins.

The mixins in this package are slices of one object, not standalone
repositories — they are never instantiated alone, and OrgDB owns the engine
lifecycle and `connect()`. That is deliberate (see orgdb.py), but it leaves
mypy checking each mixin in isolation, where `self.connect()` resolves to
nothing and every query method reports `attr-defined`.

Declaring the contract the mixins rely on fixes that without introducing a
runtime base class with behaviour: the body is under TYPE_CHECKING, so at
runtime this is an empty class and the MRO is unchanged.
"""
from __future__ import annotations

from typing import TYPE_CHECKING


class DbMixin:
    """What a mixin may assume OrgDB provides."""

    if TYPE_CHECKING:
        from sqlalchemy.engine import Engine

        def connect(self) -> Engine: ...
