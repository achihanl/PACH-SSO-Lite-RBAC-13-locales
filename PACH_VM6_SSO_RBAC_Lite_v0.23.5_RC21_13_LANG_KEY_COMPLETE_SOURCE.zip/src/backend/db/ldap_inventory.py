"""Observed LDAP client sessions and provisioned platform client credentials.

Split out of orgdb.py's OrgDB class; method bodies are unchanged.
Composed back into OrgDB via mixin inheritance, so every existing
ORGDB.<method>() call site is unaffected.
"""
from __future__ import annotations

from typing import Any

from sqlalchemy import delete, func, select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert

from db._base import DbMixin
from db.tables import (
    ldap_clients,
    ldap_provisioned_clients,
)


class LdapInventoryMixin(DbMixin):
    """Observed LDAP client sessions and provisioned platform client credentials."""

    # -----------------
    # LDAP Client Inventory
    # -----------------
    def upsert_ldap_session(
        self, bind_dn: str, source_ip: str, mech: str | None, service: str
    ) -> None:
        """Record a completed LDAP bind session (called by the log collector).

        - INSERT a new (bind_dn, source_ip) row with session_count=1, or
        - ON CONFLICT bump last_seen + session_count and refresh service/mech.
        - Admin-set status/label/acknowledged_* are NOT in set_ → preserved.
        """
        eng = self.connect()
        with eng.begin() as conn:
            insert_status = "acknowledged" if service == "provisioned_client" else "unknown"
            stmt = pg_insert(ldap_clients).values(
                bind_dn=bind_dn,
                source_ip=source_ip,
                service=service,
                status=insert_status,
                last_bind_mech=mech,
                session_count=1,
            )
            stmt = stmt.on_conflict_do_update(
                index_elements=["bind_dn", "source_ip"],
                set_={
                    "last_seen": func.now(),
                    "session_count": ldap_clients.c.session_count + 1,
                    "service": service,
                    "last_bind_mech": mech,
                },
            )
            conn.execute(stmt)

    def list_ldap_clients(
        self,
        status: str | None = None,
        service: str | None = None,
        include_healthcheck: bool = False,
    ) -> list[dict[str, Any]]:
        """List inventoried LDAP clients, most-recent activity first."""
        eng = self.connect()
        stmt = select(ldap_clients)
        if status:
            stmt = stmt.where(ldap_clients.c.status == status)
        if service:
            stmt = stmt.where(ldap_clients.c.service == service)
        if not include_healthcheck:
            stmt = stmt.where(ldap_clients.c.service != "healthcheck")
        stmt = stmt.order_by(ldap_clients.c.last_seen.desc())
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()
        return [dict(r) for r in rows]

    def get_ldap_client(self, client_id: int) -> dict[str, Any] | None:
        """Fetch one inventory row by id, or None."""
        eng = self.connect()
        stmt = select(ldap_clients).where(ldap_clients.c.id == client_id)
        with eng.begin() as conn:
            row = conn.execute(stmt).mappings().first()
        return dict(row) if row else None

    def update_ldap_client(
        self,
        client_id: int,
        status: str | None = None,
        label: str | None = None,
        acked_by: str | None = None,
    ) -> dict[str, Any] | None:
        """Update admin fields. Stamps acknowledged_by/at when status→acknowledged.

        Returns the updated row, or None if the id does not exist.
        """
        eng = self.connect()
        vals: dict[str, Any] = {}
        if status is not None:
            vals["status"] = status
            if status == "acknowledged":
                vals["acknowledged_by"] = acked_by
                vals["acknowledged_at"] = func.now()
        if label is not None:
            vals["label"] = label
        if not vals:
            return self.get_ldap_client(client_id)
        with eng.begin() as conn:
            result = conn.execute(
                update(ldap_clients)
                .where(ldap_clients.c.id == client_id)
                .values(**vals)
            )
            if result.rowcount == 0:
                return None
        return self.get_ldap_client(client_id)

    def delete_ldap_client(self, client_id: int) -> bool:
        """Delete an inventory row. Returns True if a row was deleted."""
        eng = self.connect()
        with eng.begin() as conn:
            result = conn.execute(
                delete(ldap_clients).where(ldap_clients.c.id == client_id)
            )
            return result.rowcount > 0

    # -----------------
    # LDAP Provisioned Client Registry
    # -----------------
    def add_provisioned_client(self, client_id: str, bind_dn: str,
                               label: str | None, created_by: str) -> dict[str, Any]:
        eng = self.connect()
        with eng.begin() as conn:
            stmt = pg_insert(ldap_provisioned_clients).values(
                client_id=client_id, bind_dn=bind_dn, label=label, created_by=created_by,
            )
            # Reclaiming a previously-revoked client_id overwrites its row in one
            # statement (clears revoked_at / last_rotated_at) — no delete-then-insert
            # window that could lose the row on a partial failure.
            stmt = stmt.on_conflict_do_update(
                index_elements=["client_id"],
                set_={"bind_dn": bind_dn, "label": label, "created_by": created_by,
                      "created_at": func.now(), "revoked_at": None,
                      "last_rotated_at": None},
            )
            conn.execute(stmt)
            row = conn.execute(select(ldap_provisioned_clients).where(
                ldap_provisioned_clients.c.client_id == client_id)).mappings().first()
        return dict(row)

    def list_provisioned_clients(self, include_revoked: bool = False) -> list[dict[str, Any]]:
        eng = self.connect()
        stmt = select(ldap_provisioned_clients)
        if not include_revoked:
            stmt = stmt.where(ldap_provisioned_clients.c.revoked_at.is_(None))
        stmt = stmt.order_by(ldap_provisioned_clients.c.created_at.desc())
        with eng.begin() as conn:
            return [dict(r) for r in conn.execute(stmt).mappings().all()]

    def get_provisioned_client(self, client_id: str) -> dict[str, Any] | None:
        eng = self.connect()
        with eng.begin() as conn:
            row = conn.execute(select(ldap_provisioned_clients).where(
                ldap_provisioned_clients.c.client_id == client_id)).mappings().first()
        return dict(row) if row else None

    def mark_provisioned_client_rotated(self, client_id: str) -> None:
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(update(ldap_provisioned_clients)
                         .where(ldap_provisioned_clients.c.client_id == client_id)
                         .values(last_rotated_at=func.now()))

    def revoke_provisioned_client(self, client_id: str) -> None:
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(update(ldap_provisioned_clients)
                         .where(ldap_provisioned_clients.c.client_id == client_id)
                         .values(revoked_at=func.now()))

    def delete_provisioned_client(self, client_id: str) -> None:
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(delete(ldap_provisioned_clients)
                         .where(ldap_provisioned_clients.c.client_id == client_id))

    def is_provisioned_bind_dn(self, bind_dn: str) -> bool:
        """True if `bind_dn` is a live (non-revoked) provisioned client.

        Registry lookup by bind DN. NOTE: the live reconciliation path does NOT
        use this — `classify()` (ldap_activity.py) recognises provisioned clients
        by the structural `ou=clients` DN suffix, DB-free. Kept as a registry
        helper for callers that need a definitive membership check (tests today).
        """
        eng = self.connect()
        with eng.begin() as conn:
            row = conn.execute(select(ldap_provisioned_clients.c.id).where(
                (ldap_provisioned_clients.c.bind_dn == bind_dn) &
                (ldap_provisioned_clients.c.revoked_at.is_(None)))).first()
        return row is not None
