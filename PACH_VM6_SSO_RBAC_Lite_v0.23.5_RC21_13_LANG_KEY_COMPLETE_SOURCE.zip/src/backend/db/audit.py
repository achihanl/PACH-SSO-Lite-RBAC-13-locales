"""Append-only audit trails: lifecycle, admin actions, provisioning, terminations.

Split out of orgdb.py's OrgDB class; method bodies are unchanged.
Composed back into OrgDB via mixin inheritance, so every existing
ORGDB.<method>() call site is unaffected.
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import delete, insert, select, text

from db._base import DbMixin
from db.tables import (
    _publish_activity_event,
    admin_action_audit,
    auth_failure_audit,
    provisioning_audit,
    suspension_events,
    termination_events,
    user_lifecycle_audit,
    utcnow,
)


class AuditMixin(DbMixin):
    """Append-only audit trails: lifecycle, admin actions, provisioning, terminations."""

    # -----------------
    # Termination events
    # -----------------
    def record_termination(
        self,
        user_uid: str,
        user_dn: str | None,
        org_dn: str | None,
        terminated_by: str,
        reason: str,
        actions_taken: dict,
        ldap_disabled: bool | None = None,
        tokens_revoked: int | None = None,
        authentik_sessions_revoked: int | None = None,
        uc_sessions_terminated: int | None = None,
    ) -> int:
        """Record a user termination event. Returns the event ID."""
        import json
        eng = self.connect()
        with eng.begin() as conn:
            result = conn.execute(
                insert(termination_events).values(
                    user_uid=user_uid,
                    user_dn=user_dn,
                    org_dn=org_dn,
                    terminated_by=terminated_by,
                    reason=reason,
                    timestamp=utcnow(),
                    actions_taken=json.dumps(actions_taken),
                    ldap_disabled=ldap_disabled,
                    tokens_revoked=tokens_revoked,
                    authentik_sessions_revoked=authentik_sessions_revoked,
                    uc_sessions_terminated=uc_sessions_terminated,
                )
            )
            return result.inserted_primary_key[0]

    def record_lifecycle_event(
        self,
        user_uid: str,
        action: str,
        performed_by: str = "unknown",
        detail: str | None = None,
    ) -> None:
        """Record a user lifecycle event."""
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(
                insert(user_lifecycle_audit).values(
                    user_uid=user_uid,
                    action=action,
                    performed_by=performed_by,
                    detail=detail,
                    timestamp=utcnow(),
                )
            )
        # Map lifecycle actions to ActivityEvent types
        _type_map = {"created": "user-created", "terminated": "user-terminated"}
        _publish_activity_event({
            "id": f"lc-{user_uid}-{int(utcnow().timestamp())}",
            "type": _type_map.get(action, action),
            "text": f"User {user_uid} {action}",
            "meta": f"By {performed_by}" + (f": {detail}" if detail else ""),
            "time": "just now",
            "timestamp": utcnow().isoformat(),
        })

    def record_suspension_event(
        self,
        user_uid: str,
        action: str,
        performed_by: str = "unknown",
        reason: str | None = None,
        duration_hours: int | None = None,
    ) -> None:
        """Record a suspension or unsuspension event."""
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(
                insert(suspension_events).values(
                    user_uid=user_uid,
                    action=action,
                    performed_by=performed_by,
                    reason=reason,
                    duration_hours=duration_hours,
                    created_at=utcnow(),
                )
            )
        _publish_activity_event({
            "id": f"sus-{user_uid}-{int(utcnow().timestamp())}",
            "type": f"user-{action}",
            "text": f"User {user_uid} {action}",
            "meta": f"By {performed_by}" + (f" — {reason}" if reason else ""),
            "time": "just now",
            "timestamp": utcnow().isoformat(),
        })

    def record_admin_action(
        self,
        actor: str,
        action: str,
        resource_type: str,
        resource_id: str,
        detail: dict[str, Any] | None = None,
    ) -> int:
        """Record an admin CRUD action for audit.

        - actor: OIDC sub/uid of the admin performing the action
        - action: verb (create_user, update_org, delete_group, etc.)
        - resource_type: entity type (user, org, group, settings, profile)
        - resource_id: identifier of the affected resource
        - detail: optional JSON payload with action-specific context
        Returns: row ID of the inserted record
        """
        eng = self.connect()
        with eng.begin() as conn:
            result = conn.execute(
                insert(admin_action_audit).values(
                    actor=actor,
                    action=action,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    detail=json.dumps(detail) if detail else None,
                    timestamp=utcnow(),
                )
            )
            row_id = result.inserted_primary_key[0]
        _publish_activity_event({
            "id": f"admin-{row_id}",
            "type": "sso-enrolled" if action == "sso_enroll" else action.replace("_", "-"),
            "text": f"{action.replace('_', ' ').title()}: {resource_type} {resource_id}",
            "meta": f"By {actor}",
            "time": "just now",
            "timestamp": utcnow().isoformat(),
        })
        return row_id

    def record_provisioning_audit(
        self,
        action: str,
        actor: str,
        target_uid: str,
        *,
        device_id: str | None = None,
        token_hash: str | None = None,
        auth_method: str | None = None,
        platform: str | None = None,
        client_ip: str | None = None,
        detail: dict | None = None,
    ) -> int:
        """Record a device provisioning audit event and publish activity bus event.

        - action: provisioned, consumed, revoked, bulk-revoked, extended
        - actor: uid (self-service) or admin username
        - target_uid: user whose device was affected
        """
        eng = self.connect()
        with eng.begin() as conn:
            result = conn.execute(
                insert(provisioning_audit).values(
                    action=action,
                    actor=actor,
                    target_uid=target_uid,
                    device_id=device_id,
                    token_hash=token_hash,
                    auth_method=auth_method,
                    platform=platform,
                    client_ip=client_ip,
                    detail=json.dumps(detail) if detail else None,
                    timestamp=utcnow(),
                )
            )
            row_id = result.inserted_primary_key[0]
        _title_map = {
            "provisioned": "Device Provisioned (SSO)",
            "consumed": "Device Provisioned (QR)",
            "revoked": "Device Revoked",
            "bulk-revoked": "Bulk Token Revocation",
            "extended": "Token Extended",
        }
        _publish_activity_event({
            "id": f"prov-{row_id}",
            "type": "provisioning",
            "text": f"{_title_map.get(action, action)} — {target_uid}",
            "meta": f"By {actor}" + (f" device={device_id}" if device_id else ""),
            "time": "just now",
            "timestamp": utcnow().isoformat(),
        })
        return row_id

    def purge_audit_before(self, cutoff: datetime) -> dict[str, int]:
        """Delete audit rows older than cutoff from every append-only trail; return per-table counts."""
        trails = (
            (termination_events, termination_events.c.timestamp),
            (auth_failure_audit, auth_failure_audit.c.timestamp),
            (user_lifecycle_audit, user_lifecycle_audit.c.timestamp),
            (admin_action_audit, admin_action_audit.c.timestamp),
            (provisioning_audit, provisioning_audit.c.timestamp),
            (suspension_events, suspension_events.c.created_at),
        )
        eng = self.connect()
        with eng.begin() as conn:
            return {
                table.name: conn.execute(delete(table).where(column < cutoff)).rowcount
                for table, column in trails
            }

    def list_user_lifecycle(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent user lifecycle audit records."""
        eng = self.connect()
        stmt = (
            select(user_lifecycle_audit)
            .order_by(user_lifecycle_audit.c.timestamp.desc())
            .limit(limit)
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()
        return [
            {
                "id": r["id"],
                "user_uid": r["user_uid"],
                "action": r["action"],
                "performed_by": r["performed_by"],
                "detail": r["detail"],
                "timestamp": r["timestamp"].isoformat() if r["timestamp"] else None,
            }
            for r in rows
        ]

    def list_unified_audit(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        time_range: str = "7d",
        category: str = "all",
        search: str = "",
        qr_id: str | None = None,
    ) -> dict[str, Any]:
        """Return paginated, filtered, unified audit events from all audit tables.

        UNION ALL strategy:
        - termination_events -> user-terminated
        - auth_failure_audit -> login (failure)
        - user_lifecycle_audit -> user-created/sso-enrolled/config-change
        - admin_action_audit -> admin CRUD actions (DS-7)
        - provisioning_audit -> device-provisioned/device-revoked/device-extended
        """
        eng = self.connect()
        now = datetime.now(timezone.utc)

        # Time range filter
        time_filters = {
            "today": now - timedelta(days=1),
            "7d": now - timedelta(days=7),
            "30d": now - timedelta(days=30),
            "90d": now - timedelta(days=90),
            "all": None,
        }
        since = time_filters.get(time_range, time_filters["7d"])

        with eng.begin() as conn:
            parts = []
            params: dict[str, Any] = {}

            # --- Termination events ---
            trm_sql = """
                SELECT
                    'AUD-' || LPAD((10000 + te.id)::text, 5, '0') AS id,
                    'user-terminated' AS event_type,
                    te.timestamp AS timestamp,
                    'User Access Terminated' AS title,
                    'All sessions revoked, LDAP disabled' AS description,
                    te.terminated_by AS actor,
                    te.user_uid AS target,
                    'TRM-' || LPAD(te.id::text, 4, '0') AS reference_id,
                    'success' AS result,
                    'user' AS category,
                    NULL::int AS duration_ms,
                    te.org_dn AS organization,
                    NULL AS ip_address,
                    NULL AS device_json,
                    json_build_object(
                        'id', te.id, 'user_uid', te.user_uid, 'user_dn', te.user_dn,
                        'org_dn', te.org_dn, 'terminated_by', te.terminated_by,
                        'reason', te.reason, 'timestamp', te.timestamp,
                        'actions_taken', te.actions_taken,
                        'ldap_disabled', te.ldap_disabled,
                        'tokens_revoked', te.tokens_revoked
                    )::text AS raw_data
                FROM termination_events te
            """
            parts.append(trm_sql)

            # --- Auth failure events ---
            af_sql = """
                SELECT
                    'AUD-' || LPAD((20000 + af.id)::text, 5, '0') AS id,
                    'login' AS event_type,
                    af.timestamp AS timestamp,
                    'Authentication Failed' AS title,
                    'Reason: ' || af.failure_reason AS description,
                    COALESCE(af.username, 'Unknown') AS actor,
                    '—' AS target,
                    'SES-' || LPAD(af.id::text, 4, '0') AS reference_id,
                    'failure' AS result,
                    'auth' AS category,
                    NULL::int AS duration_ms,
                    NULL AS organization,
                    af.client_ip AS ip_address,
                    NULL AS device_json,
                    json_build_object(
                        'id', af.id, 'username', af.username,
                        'failure_reason', af.failure_reason,
                        'timestamp', af.timestamp, 'client_ip', af.client_ip,
                        'user_agent', af.user_agent, 'endpoint', af.endpoint
                    )::text AS raw_data
                FROM auth_failure_audit af
            """
            parts.append(af_sql)

            # --- User lifecycle events ---
            ul_sql = """
                SELECT
                    'AUD-' || LPAD((30000 + ul.id)::text, 5, '0') AS id,
                    CASE ul.action
                        WHEN 'created' THEN 'user-created'
                        WHEN 'suspended' THEN 'user-terminated'
                        WHEN 'unsuspended' THEN 'user-created'
                        WHEN 'password_reset' THEN 'config-change'
                        WHEN 'sso_enrolled' THEN 'sso-enrolled'
                        ELSE 'config-change'
                    END AS event_type,
                    ul.timestamp AS timestamp,
                    CASE ul.action
                        WHEN 'created' THEN 'User Created'
                        WHEN 'suspended' THEN 'User Suspended'
                        WHEN 'unsuspended' THEN 'User Unsuspended'
                        WHEN 'password_reset' THEN 'Password Reset'
                        WHEN 'sso_enrolled' THEN 'SSO Enrolled'
                        ELSE 'User Lifecycle: ' || ul.action
                    END AS title,
                    COALESCE(ul.detail, '') AS description,
                    COALESCE(ul.performed_by, 'System') AS actor,
                    ul.user_uid AS target,
                    'USR-' || LPAD(ul.id::text, 4, '0') AS reference_id,
                    'success' AS result,
                    'user' AS category,
                    NULL::int AS duration_ms,
                    NULL AS organization,
                    NULL AS ip_address,
                    NULL AS device_json,
                    json_build_object(
                        'id', ul.id, 'user_uid', ul.user_uid,
                        'action', ul.action, 'performed_by', ul.performed_by,
                        'detail', ul.detail, 'timestamp', ul.timestamp
                    )::text AS raw_data
                FROM user_lifecycle_audit ul
            """
            parts.append(ul_sql)

            # --- Admin action events ---
            aa_sql = """
                SELECT
                    'AUD-' || LPAD((40000 + aa.id)::text, 5, '0') AS id,
                    'admin-action' AS event_type,
                    aa.timestamp AS timestamp,
                    'Admin: ' || REPLACE(aa.action, '_', ' ') AS title,
                    COALESCE(aa.resource_type || ' ' || aa.resource_id, '') AS description,
                    aa.actor AS actor,
                    aa.resource_id AS target,
                    'ADM-' || LPAD(aa.id::text, 4, '0') AS reference_id,
                    'success' AS result,
                    'admin' AS category,
                    NULL::int AS duration_ms,
                    NULL AS organization,
                    NULL AS ip_address,
                    NULL AS device_json,
                    json_build_object(
                        'id', aa.id, 'actor', aa.actor,
                        'action', aa.action, 'resource_type', aa.resource_type,
                        'resource_id', aa.resource_id, 'detail', aa.detail,
                        'timestamp', aa.timestamp
                    )::text AS raw_data
                FROM admin_action_audit aa
            """
            parts.append(aa_sql)

            # --- Provisioning audit events ---
            pa_sql = """
                SELECT
                    'AUD-' || LPAD((50000 + pa.id)::text, 5, '0') AS id,
                    CASE pa.action
                        WHEN 'provisioned' THEN 'device-provisioned'
                        WHEN 'consumed'    THEN 'device-provisioned'
                        WHEN 'revoked'     THEN 'device-revoked'
                        WHEN 'bulk-revoked' THEN 'device-revoked'
                        WHEN 'extended'    THEN 'device-extended'
                        ELSE 'device-provisioned'
                    END AS event_type,
                    pa.timestamp AS timestamp,
                    CASE pa.action
                        WHEN 'provisioned' THEN 'Device Provisioned (SSO)'
                        WHEN 'consumed'    THEN 'Device Provisioned (QR)'
                        WHEN 'revoked'     THEN 'Device Revoked'
                        WHEN 'bulk-revoked' THEN 'Bulk Token Revocation'
                        WHEN 'extended'    THEN 'Token Extended'
                        ELSE pa.action
                    END AS title,
                    COALESCE(pa.detail->>'description', pa.action || ' for ' || pa.target_uid) AS description,
                    pa.actor AS actor,
                    pa.target_uid AS target,
                    'PRV-' || LPAD(pa.id::text, 4, '0') AS reference_id,
                    'success' AS result,
                    'provisioning' AS category,
                    NULL::int AS duration_ms,
                    NULL AS organization,
                    pa.client_ip AS ip_address,
                    json_build_object('device_id', pa.device_id, 'platform', pa.platform)::text AS device_json,
                    row_to_json(pa.*)::text AS raw_data
                FROM provisioning_audit pa
            """
            parts.append(pa_sql)

            # Combine with UNION ALL
            union_sql = " UNION ALL ".join(parts)

            # Outer query with filtering + pagination
            where_clauses = []
            if since is not None:
                where_clauses.append("unified.timestamp >= :since")
                params["since"] = since
            if category != "all":
                where_clauses.append("unified.category = :category")
                params["category"] = category
            if search:
                where_clauses.append(
                    "(unified.actor ILIKE :search OR unified.target ILIKE :search "
                    "OR unified.reference_id ILIKE :search OR unified.description ILIKE :search)"
                )
                params["search"] = f"%{search}%"
            if qr_id:
                where_clauses.append("unified.reference_id ILIKE :qr_id")
                params["qr_id"] = f"%{qr_id}%"

            where_sql = (" WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

            # Count query
            count_sql = f"SELECT COUNT(*) FROM ({union_sql}) unified {where_sql}"
            total = conn.execute(text(count_sql), params).scalar() or 0

            # Data query with pagination
            offset = (page - 1) * page_size
            params["limit"] = page_size
            params["offset"] = offset
            data_sql = (
                f"SELECT * FROM ({union_sql}) unified {where_sql} "
                f"ORDER BY unified.timestamp DESC NULLS LAST "
                f"LIMIT :limit OFFSET :offset"
            )
            rows = conn.execute(text(data_sql), params).mappings().all()

        events = []
        for r in rows:
            device = None
            if r["device_json"]:
                try:
                    device = json.loads(r["device_json"])
                except Exception:
                    pass
            raw = {}
            if r["raw_data"]:
                try:
                    raw = json.loads(r["raw_data"])
                except Exception:
                    pass

            events.append({
                "id": r["id"],
                "event_type": r["event_type"],
                "timestamp": r["timestamp"].isoformat() if r["timestamp"] else None,
                "title": r["title"],
                "description": r["description"] or "",
                "actor": r["actor"] or "System",
                "target": r["target"] or "—",
                "reference_id": r["reference_id"],
                "result": r["result"],
                "category": r["category"],
                "duration_ms": r["duration_ms"],
                "organization": r["organization"],
                "ip_address": r["ip_address"],
                "device": device,
                "raw_data": raw,
            })

        return {
            "events": events,
            "pagination": {
                "page": page,
                "page_size": page_size,
                "total_events": total,
                "total_pages": math.ceil(total / page_size) if total > 0 else 1,
            },
        }

    def list_terminations(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent termination events."""
        eng = self.connect()
        stmt = (
            select(termination_events)
            .order_by(termination_events.c.timestamp.desc())
            .limit(limit)
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()
        return [
            {
                "id": r["id"],
                "user_uid": r["user_uid"],
                "user_dn": r["user_dn"],
                "org_dn": r["org_dn"],
                "terminated_by": r["terminated_by"],
                "reason": r["reason"],
                "timestamp": r["timestamp"].isoformat() if r["timestamp"] else None,
                "actions_taken": r["actions_taken"],
                "ldap_disabled": r["ldap_disabled"],
                "tokens_revoked": r["tokens_revoked"],
            }
            for r in rows
        ]

    def list_auth_failures(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent auth failure records."""
        eng = self.connect()
        stmt = (
            select(auth_failure_audit)
            .order_by(auth_failure_audit.c.timestamp.desc())
            .limit(limit)
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()
        return [
            {
                "id": r["id"],
                "username": r["username"],
                "failure_reason": r["failure_reason"],
                "client_ip": r["client_ip"],
                "user_agent": r["user_agent"],
                "endpoint": r["endpoint"],
                "timestamp": r["timestamp"].isoformat() if r["timestamp"] else None,
            }
            for r in rows
        ]
