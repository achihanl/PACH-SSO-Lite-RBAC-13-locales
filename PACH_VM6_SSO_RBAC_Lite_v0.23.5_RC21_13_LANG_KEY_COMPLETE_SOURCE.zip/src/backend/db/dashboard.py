"""Read-only aggregates for the dashboard and the compliance alert computation.

Split out of orgdb.py's OrgDB class; method bodies are unchanged.
Composed back into OrgDB via mixin inheritance, so every existing
ORGDB.<method>() call site is unaffected.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from typing import Any

from sqlalchemy import func, or_, select, text

from db._base import DbMixin
from db.tables import (
    device_provisions,
    utcnow,
)


class DashboardMixin(DbMixin):
    """Read-only aggregates for the dashboard and the compliance alert computation."""

    def get_user_stats(self, uid: str) -> dict[str, Any]:
        """Aggregate stats for a user: device count."""
        eng = self.connect()
        with eng.begin() as conn:
            # Active devices = consumed tokens with device_id
            device_count = conn.execute(
                select(func.count())
                .select_from(device_provisions)
                .where(device_provisions.c.uid == uid)
                .where(device_provisions.c.consumed_by_device_id.isnot(None))
            ).scalar() or 0

        return {
            "active_devices": device_count,
        }

    def get_dashboard_stats_db(self) -> dict[str, Any]:
        """Dashboard aggregate stats from PostgreSQL.

        - pending_provisions: active, unexpired device provision tokens
        """
        eng = self.connect()
        now = datetime.now(timezone.utc)
        with eng.begin() as conn:
            pending = conn.execute(
                select(func.count())
                .select_from(device_provisions)
                .where(
                    device_provisions.c.used_at.is_(None),
                    device_provisions.c.status == "active",
                    or_(
                        device_provisions.c.expires_at.is_(None),
                        device_provisions.c.expires_at > now,
                    ),
                )
            ).scalar() or 0
        return {
            "pending_provisions": pending,
        }

    def get_dashboard_chart_data(self, period: str = "7d") -> dict[str, Any]:
        """Provisioning chart time-series data.

        - Returns device provision events bucketed by period
        - Replaces old QR issuance audit chart
        """
        eng = self.connect()
        now = datetime.now(timezone.utc)
        period_config = {
            "24h": {"days": 1, "trunc": "hour", "fmt": "HH24:00"},
            "7d": {"days": 7, "trunc": "day", "fmt": "YYYY-MM-DD"},
            "30d": {"days": 30, "trunc": "day", "fmt": "YYYY-MM-DD"},
        }
        cfg = period_config.get(period, period_config["7d"])
        cutoff = now - timedelta(days=cfg["days"])
        sql = text("""
            SELECT
                TO_CHAR(DATE_TRUNC(:trunc, dp.issued_at), :fmt) AS day,
                COUNT(*) AS generated,
                COUNT(*) FILTER (WHERE dp.used_at IS NOT NULL) AS consumed
            FROM device_provisions dp
            WHERE dp.issued_at >= :cutoff
            GROUP BY 1
            ORDER BY 1
        """)
        with eng.begin() as conn:
            rows = conn.execute(sql, {
                "trunc": cfg["trunc"],
                "fmt": cfg["fmt"],
                "cutoff": cutoff,
            }).mappings().all()
        return {
            "data": [{"day": r["day"], "generated": r["generated"], "consumed": r["consumed"]} for r in rows],
            "period": period,
        }

    def compute_compliance_alerts(self) -> dict[str, Any]:
        """Compute compliance alerts from device_provisions (device_provisions).

        Alert types:
        - expired-unused: status='active' AND expires_at < NOW() (expiry is read-time)
        - multi-issue: user has 3+ active non-expired tokens
        - stale-active: active token past 80% of TTL
        - cross-user-device: device consumed tokens for 2+ users
        - high-failure-rate: user has >3 non-consumed tokens in 30 days
        """
        eng = self.connect()
        now = utcnow()
        alerts: list[dict[str, Any]] = []
        summary: dict[str, int] = {
            "expired-unused": 0,
            "multi-issue": 0,
            "stale-active": 0,
            "cross-user-device": 0,
            "high-failure-rate": 0,
        }
        alert_id = 0

        with eng.begin() as conn:
            # 1. expired-unused
            rows = conn.execute(text("""
                SELECT token_hash, uid, issued_at, expires_at
                FROM device_provisions
                WHERE status = 'active' AND expires_at < NOW()
                ORDER BY expires_at DESC LIMIT 100
            """)).mappings().all()
            summary["expired-unused"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "expired-unused",
                    "severity": "warning",
                    "subject_uid": r["uid"],
                    "subject_device_id": None,
                    "description": "Token expired without being consumed",
                    "detected_at": now.isoformat(),
                    "evidence": {"token_hash": r["token_hash"]},
                    "recommended_action": "Re-provision this user's device",
                })

            # 3. multi-issue
            rows = conn.execute(text("""
                SELECT uid, COUNT(*) as cnt
                FROM device_provisions
                WHERE status = 'active' AND expires_at > NOW()
                GROUP BY uid HAVING COUNT(*) > 2
            """)).mappings().all()
            summary["multi-issue"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "multi-issue",
                    "severity": "warning",
                    "subject_uid": r["uid"],
                    "subject_device_id": None,
                    "description": f"User has {r['cnt']} active tokens simultaneously",
                    "detected_at": now.isoformat(),
                    "evidence": {"active_count": int(r["cnt"])},
                    "recommended_action": "Revoke older tokens to reduce exposure",
                })

            # 4. stale-active
            rows = conn.execute(text("""
                SELECT token_hash, uid, issued_at, expires_at
                FROM device_provisions
                WHERE status = 'active' AND expires_at > NOW()
                AND (EXTRACT(EPOCH FROM NOW() - issued_at))
                  > 0.8 * (EXTRACT(EPOCH FROM expires_at - issued_at))
                ORDER BY expires_at ASC LIMIT 100
            """)).mappings().all()
            summary["stale-active"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "stale-active",
                    "severity": "low",
                    "subject_uid": r["uid"],
                    "subject_device_id": None,
                    "description": "Token is past 80% of its TTL without consumption",
                    "detected_at": now.isoformat(),
                    "evidence": {"token_hash": r["token_hash"]},
                    "recommended_action": "Extend or revoke this token",
                })

            # 5. cross-user-device
            rows = conn.execute(text("""
                SELECT consumed_by_device_id, COUNT(DISTINCT uid) as user_count,
                       array_agg(DISTINCT uid) as users
                FROM device_provisions
                WHERE consumed_by_device_id IS NOT NULL
                GROUP BY consumed_by_device_id
                HAVING COUNT(DISTINCT uid) > 1
            """)).mappings().all()
            summary["cross-user-device"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "cross-user-device",
                    "severity": "critical",
                    "subject_uid": None,
                    "subject_device_id": r["consumed_by_device_id"],
                    "description": f"Device consumed tokens for {r['user_count']} different users",
                    "detected_at": now.isoformat(),
                    "evidence": {"users": list(r["users"]), "device_id": r["consumed_by_device_id"]},
                    "recommended_action": "Investigate shared device usage",
                })

            # 6. high-failure-rate
            rows = conn.execute(text("""
                SELECT uid, COUNT(*) as fail_count
                FROM device_provisions
                WHERE status NOT IN ('used', 'consumed')
                AND issued_at > NOW() - INTERVAL '30 days'
                GROUP BY uid HAVING COUNT(*) > 3
            """)).mappings().all()
            summary["high-failure-rate"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "high-failure-rate",
                    "severity": "warning",
                    "subject_uid": r["uid"],
                    "subject_device_id": None,
                    "description": f"User has {r['fail_count']} unconsumed tokens in 30 days",
                    "detected_at": now.isoformat(),
                    "evidence": {"fail_count": int(r["fail_count"])},
                    "recommended_action": "Check user's provisioning workflow",
                })

        return {"alerts": alerts, "summary": summary}
