"""PACH RBAC Lite application catalogue and one role per user per application.

No application-specific privileges are stored here. DB transactions enforce
atomic registration/role changes, and absent/disabled apps are default-deny.
"""
from __future__ import annotations
import hashlib
from sqlalchemy import select, delete, update, func
from sqlalchemy.dialects.postgresql import insert as pg_insert
from db._base import DbMixin
from db.tables import pach_applications, pach_application_roles, pach_application_auth_clients


class ApplicationsMixin(DbMixin):
    def list_pach_applications(self):
        with self.connect().begin() as conn:
            return [dict(r) for r in conn.execute(select(pach_applications).order_by(pach_applications.c.application_id)).mappings()]

    def get_pach_application(self, app_id):
        with self.connect().begin() as conn:
            r = conn.execute(select(pach_applications).where(pach_applications.c.application_id == app_id)).mappings().first()
            return dict(r) if r else None

    def create_pach_application(self, app_id, display_name, auth_method, roles):
        with self.connect().begin() as conn:
            conn.execute(pach_applications.insert().values(
                application_id=app_id, display_name=display_name, auth_method=auth_method,
                supported_roles=roles, enabled=True))
        return self.get_pach_application(app_id)

    def update_pach_application(self, app_id, display_name=None, enabled=None):
        values = {"updated_at": func.now()}
        if display_name is not None:
            values["display_name"] = display_name
        if enabled is not None:
            values["enabled"] = enabled
        with self.connect().begin() as conn:
            result = conn.execute(update(pach_applications).where(pach_applications.c.application_id == app_id).values(**values))
            if not result.rowcount:
                return None
        return self.get_pach_application(app_id)

    def assign_pach_role(self, uid, app_id, role):
        # Lock the application row to prevent a concurrent disable changing
        # its state between validation and assignment.
        with self.connect().begin() as conn:
            app = conn.execute(select(pach_applications).where(pach_applications.c.application_id == app_id).with_for_update()).mappings().first()
            if not app or not app["enabled"]:
                raise ValueError("Application is not enabled")
            if role not in app["supported_roles"]:
                raise ValueError("Role is not supported by this application")
            conn.execute(pg_insert(pach_application_roles).values(
                user_uid=uid, application_id=app_id, role=role
            ).on_conflict_do_update(
                index_elements=["user_uid", "application_id"],
                set_={"role": role, "assigned_at": func.now()}
            ))
        return {"user_uid": uid, "application_id": app_id, "role": role}

    def revoke_pach_role(self, uid, app_id):
        with self.connect().begin() as conn:
            result = conn.execute(delete(pach_application_roles).where(
                (pach_application_roles.c.user_uid == uid) &
                (pach_application_roles.c.application_id == app_id)))
            return bool(result.rowcount)

    def list_pach_user_roles(self, uid):
        stmt = select(pach_application_roles.c.application_id, pach_application_roles.c.role).join(
            pach_applications, pach_applications.c.application_id == pach_application_roles.c.application_id
        ).where((pach_application_roles.c.user_uid == uid) & (pach_applications.c.enabled.is_(True))).order_by(pach_application_roles.c.application_id)
        with self.connect().begin() as conn:
            return [dict(r) for r in conn.execute(stmt).mappings()]

    def seed_pach_core_applications(self):
        """Register platform applications without granting any user access.

        Insert-only: never overwrite administrator edits, disabled state or
        custom role sets. This is metadata, not SSO client provisioning.
        """
        builtins = [
            ("uc-core", "UC Core", "ldap"),
            ("web-ceg", "Web Customer Engagement Gateway", "oidc"),
            ("mail", "Mail", "ldap"),
            ("bothub", "BotHub & AI Gateway", "oidc"),
            ("secureedge", "SecureEdge", "oidc"),
            ("identity", "Identity & Directory", "oidc"),
            ("doc-share", "Doc Share", "oidc"),
            ("omni-ceg", "Omni-CEG", "oidc"),
            ("ai-service", "AI Service Node", "oidc"),
            ("community-cms", "Community CMS", "oidc"),
        ]
        with self.connect().begin() as conn:
            for app_id, display_name, auth_method in builtins:
                conn.execute(pg_insert(pach_applications).values(
                    application_id=app_id, display_name=display_name,
                    auth_method=auth_method,
                    supported_roles=["admin", "operator", "user", "viewer"],
                    enabled=True,
                ).on_conflict_do_nothing(index_elements=["application_id"]))

    def get_pach_auth_client(self, app_id):
        with self.connect().begin() as conn:
            row = conn.execute(select(pach_application_auth_clients).where(
                pach_application_auth_clients.c.application_id == app_id)).mappings().first()
            return dict(row) if row else None

    def reserve_pach_auth_client(self, app_id, method, redirect_uris):
        """Reserve a stable namespace BEFORE touching remote Authentik/LDAP.

        A pending record allows an identical request to resume a failed attempt.
        Never modify redirect URIs after first reservation: takeover-resistant
        URI changes need a separate reviewed workflow.
        """
        client_id = (f"pach-app-{app_id}" if method == "oidc" else
                     f"pach-{app_id[:30]}-{hashlib.sha256(app_id.encode()).hexdigest()[:10]}")
        with self.connect().begin() as conn:
            app = conn.execute(select(pach_applications).where(
                pach_applications.c.application_id == app_id).with_for_update()).mappings().first()
            if not app or not app["enabled"]:
                raise ValueError("Application does not exist or is disabled")
            if app["auth_method"] != method:
                raise ValueError("Authentication method differs from registered application")
            row = conn.execute(select(pach_application_auth_clients).where(
                pach_application_auth_clients.c.application_id == app_id).with_for_update()).mappings().first()
            if row:
                if row["auth_method"] != method or row["redirect_uris"] != redirect_uris:
                    raise ValueError("Authentication registration is immutable; use a reviewed change process")
                return dict(row), False
            conn.execute(pach_application_auth_clients.insert().values(
                application_id=app_id, client_id=client_id, auth_method=method,
                redirect_uris=redirect_uris, status="pending"))
        return self.get_pach_auth_client(app_id), True

    def finish_pach_auth_client(self, app_id):
        with self.connect().begin() as conn:
            conn.execute(update(pach_application_auth_clients).where(
                pach_application_auth_clients.c.application_id == app_id).values(
                status="ready", updated_at=func.now()))

    def list_ready_pach_oidc_clients(self):
        """Only enabled, provisioned OIDC clients are trusted for dynamic JWT allowlisting.

        Fails closed if the database is unavailable; the caller can retain its
        existing static issuer/audience allowlist for legacy applications.
        """
        stmt = select(pach_application_auth_clients.c.client_id).join(
            pach_applications,
            pach_applications.c.application_id == pach_application_auth_clients.c.application_id
        ).where(
            (pach_application_auth_clients.c.auth_method == "oidc") &
            (pach_application_auth_clients.c.status == "ready") &
            (pach_applications.c.enabled.is_(True))
        )
        with self.connect().begin() as conn:
            return [r[0] for r in conn.execute(stmt)]

    def get_pach_application_role_for_client(self, uid, app_id, client_id):
        """Single authorization snapshot: client binding + app state + user role.

        A token for one application cannot read another application's assignment.
        Returns None for no role; raises ValueError for an untrusted client or
        disabled/incomplete application. Database errors propagate to fail closed.
        """
        with self.connect().begin() as conn:
            row = conn.execute(
                select(pach_applications.c.application_id,
                       pach_application_auth_clients.c.client_id)
                .join(pach_application_auth_clients,
                      pach_application_auth_clients.c.application_id == pach_applications.c.application_id)
                .where(
                    (pach_applications.c.application_id == app_id) &
                    (pach_applications.c.enabled.is_(True)) &
                    (pach_application_auth_clients.c.client_id == client_id) &
                    (pach_application_auth_clients.c.auth_method == "oidc") &
                    (pach_application_auth_clients.c.status == "ready")
                )
            ).first()
            if row is None:
                raise ValueError("Application client is not registered, ready, or enabled")
            role = conn.execute(
                select(pach_application_roles.c.role).where(
                    (pach_application_roles.c.application_id == app_id) &
                    (pach_application_roles.c.user_uid == uid)
                )
            ).scalar_one_or_none()
            return role
