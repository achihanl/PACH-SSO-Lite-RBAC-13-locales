"""First-party client registry (ARD-022): the env clients plus those onboarded at runtime.

- Env (`AUTHENTIK_FIRST_PARTY_CLIENTS`, `OIDC_SERVICE_CLIENT_SCOPES`) is the deploy's
  registry, checked at startup (config.py). Rows in `first_party_clients` are added by
  `POST /api/clients/onboard`, checked there. On a clash the env entry wins.
- Readers never touch PostgreSQL per request: they read an in-process snapshot,
  reloaded every REFRESH_SEC and right after an onboard in this process. Another worker
  sees a new client within REFRESH_SEC. While PostgreSQL is down the last snapshot
  stays (env-only before the first load), so a scoped principal needs no store per
  call (ARD-019 §8).
- No module-level `from config import`: importing config at test collection freezes
  its env defaults (repo notes). Config is read inside refresh().
"""
from __future__ import annotations

import logging
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Iterator, Optional
from uuid import uuid4

from sqlalchemy import func, select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert

from db._base import DbMixin
from db.tables import config_template_assignments, config_templates, first_party_clients, profile_services

logger = logging.getLogger(__name__)

REFRESH_SEC = 10.0
# Advisory lock keys (hashtext) for the onboard call's two read-modify-writes.
UID_BLOCK_LOCK = "client-uid-blocks"
GROUP_FILTER_LOCK = "ldap-source-group-filter"


class ClientRegistryMixin(DbMixin):
    """Rows of `first_party_clients`."""

    def list_first_party_clients(self) -> list[dict[str, Any]]:
        with self.connect().connect() as conn:
            rows = conn.execute(select(first_party_clients).order_by(first_party_clients.c.client_id))
            return [dict(r._mapping) for r in rows]

    def add_first_party_client(self, client_id: str, service_client_id: str, roles: list[str],
                               redirect_uris: list[str], actor: str, relay_ip: Any = ...) -> None:
        """Insert the row, or update roles and redirect URIs of an existing one (onboard is idempotent).

        `relay_ip` is written only when given (None clears it); left out, a repeat keeps it.
        """
        values: dict[str, Any] = {"roles": "|".join(roles), "redirect_uris": redirect_uris}
        if relay_ip is not ...:
            values["relay_ip"] = relay_ip
        stmt = pg_insert(first_party_clients).values(
            client_id=client_id, service_client_id=service_client_id, created_by=actor, **values)
        with self.connect().begin() as conn:
            conn.execute(stmt.on_conflict_do_update(index_elements=["client_id"], set_=values))

    def ensure_relay_ip_column(self) -> None:
        """migrations/031 at startup: create_all never adds a column to an existing table."""
        with self.connect().begin() as conn:
            conn.execute(text("ALTER TABLE first_party_clients ADD COLUMN IF NOT EXISTS relay_ip VARCHAR(15)"))

    def template_assigned_to(self, org_dn: str) -> Optional[dict[str, Any]]:
        """The profile assigned to exactly this org (no walk up to ancestors), else None."""
        stmt = (select(config_templates)
                .join(config_template_assignments, config_template_assignments.c.template_id == config_templates.c.id)
                .where(func.lower(config_template_assignments.c.org_dn) == org_dn.lower()))
        with self.connect().connect() as conn:
            row = conn.execute(stmt).mappings().first()
        return dict(row) if row else None

    def free_sip_start(self) -> int:
        """First SIP extension above every profile's SIP range.

        Unlocked: a race with another onboard is caught by the SIP range check, which
        runs under its own advisory lock (SipRangeOverlap, 409; a repeat resumes).
        """
        with self.connect().connect() as conn:
            sip_end = conn.execute(select(func.coalesce(func.max(profile_services.c.counter_end), 0))
                                   .where(profile_services.c.service_type == "sip")).scalar()
        return int(sip_end) + 1

    def create_client_profile(self, name: str, description: str, actor: str, uid_block: int) -> dict[str, Any]:
        """An active profile whose UID range is the next `uid_block` numbers above every profile's range.

        Reading the maximum and inserting run in one transaction under an advisory lock,
        so two concurrent onboards never pick the same block.
        """
        template_id = str(uuid4())
        with self.connect().begin() as conn:
            conn.execute(text("SELECT pg_advisory_xact_lock(hashtext(:k))"), {"k": UID_BLOCK_LOCK})
            start = int(conn.execute(select(func.coalesce(func.max(config_templates.c.uid_range_end), 0))).scalar()) + 1
            conn.execute(config_templates.insert().values(
                id=template_id, name=name, description=description, template_type="custom", status="active",
                created_by=actor, updated_by=actor, uid_range_start=start, uid_range_end=start + uid_block - 1,
                next_uid_number=start, max_devices_per_user=5))
        with self.connect().connect() as conn:
            return dict(conn.execute(select(config_templates).where(config_templates.c.id == template_id)).mappings().one())

    @contextmanager
    def advisory_lock(self, key: str) -> Iterator[None]:
        """Hold a transaction-scoped advisory lock on `key` for the block (serialises read-modify-writes)."""
        with self.connect().begin() as conn:
            conn.execute(text("SELECT pg_advisory_xact_lock(hashtext(:k))"), {"k": key})
            yield


@dataclass(frozen=True)
class Snapshot:
    """The merged registry: first-party ids and the scope of each scoped service client."""

    first_party_ids: tuple[str, ...] = ()
    scopes: dict[str, Any] = field(default_factory=dict)  # service client id -> config.ClientScope


_lock = threading.Lock()
_db: Optional[ClientRegistryMixin] = None
_snapshot: Optional[Snapshot] = None
_loaded_at = 0.0


def bind(db: ClientRegistryMixin) -> None:
    """Point the cache at the process's OrgDB (OrgDB.init, at startup). Unbound = env only (unit tests)."""
    global _db, _loaded_at
    _db, _loaded_at = db, 0.0


def merge(env_ids, env_scopes: dict, rows: list[dict]) -> Snapshot:
    """Env plus rows. A row whose id nests with another id is skipped and logged; env scopes win."""
    from config import ClientScope

    ids, scopes = set(env_ids), dict(env_scopes)
    for row in rows:
        cid, svc = row["client_id"], row["service_client_id"]
        if cid not in env_ids:
            clash = [o for o in ids if o == cid or o.startswith(f"{cid}-") or cid.startswith(f"{o}-")]
            if clash:
                logger.error("first_party_clients row %s skipped: nests with %s", cid, clash)
                continue
        ids.add(cid)
        if svc not in scopes:  # an env scope for this principal wins
            scopes[svc] = ClientScope(cid, frozenset(r for r in row["roles"].split("|") if r))
    return Snapshot(tuple(sorted(ids)), scopes)


def refresh() -> Snapshot:
    """Reload from PostgreSQL now. Raises when the store cannot answer."""
    global _snapshot, _loaded_at
    from config import FIRST_PARTY_CLIENT_IDS, OIDC_SERVICE_CLIENT_SCOPES

    rows = _db.list_first_party_clients() if _db is not None else []
    snap = merge(FIRST_PARTY_CLIENT_IDS, OIDC_SERVICE_CLIENT_SCOPES, rows)
    with _lock:
        _snapshot, _loaded_at = snap, time.monotonic()
    return snap


def current() -> Snapshot:
    """The registry as of the last load (at most REFRESH_SEC old while PostgreSQL answers)."""
    global _snapshot, _loaded_at
    if _snapshot is not None and time.monotonic() - _loaded_at < REFRESH_SEC:
        return _snapshot
    try:
        return refresh()
    except Exception:
        logger.warning("first-party client registry reload failed; keeping the last one", exc_info=True)
        with _lock:
            if _snapshot is None:
                from config import FIRST_PARTY_CLIENT_IDS, OIDC_SERVICE_CLIENT_SCOPES
                _snapshot = merge(FIRST_PARTY_CLIENT_IDS, OIDC_SERVICE_CLIENT_SCOPES, [])
            _loaded_at = time.monotonic()  # retry after REFRESH_SEC, not on every request
        return _snapshot


def first_party_ids() -> tuple[str, ...]:
    return current().first_party_ids


def scope_of(service_client_id: Optional[str]):
    """The ClientScope bound to this service client id, else None."""
    return current().scopes.get(service_client_id) if service_client_id else None
