"""Device provisioning — one-time tokens and the devices they become.

Split out of orgdb.py's OrgDB class; method bodies are unchanged.
Composed back into OrgDB via mixin inheritance, so every existing
ORGDB.<method>() call site is unaffected.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from typing import Any

from sqlalchemy import func, insert, or_, select, update
from sqlalchemy.exc import IntegrityError

from db._base import DbMixin
from db.tables import (
    device_provisions,
    utcnow,
)


class DevicesMixin(DbMixin):
    """Device provisioning — one-time tokens and the devices they become."""

    # -----------------
    # Provision tokens
    # -----------------
    def record_provision_token(self, token_hash: str, uid: str, profile_id: str, expires_at: datetime) -> None:
        """Insert/replace an active token hash."""
        eng = self.connect()
        with eng.begin() as conn:
            # Upsert behavior: try insert, else update.
            try:
                conn.execute(
                    insert(device_provisions).values(
                        token_hash=token_hash,
                        uid=uid,
                        profile_id=profile_id,
                        issued_at=utcnow(),
                        expires_at=expires_at,
                        used_at=None,
                        status="active",
                    )
                )
            except IntegrityError:
                conn.execute(
                    update(device_provisions)
                    .where(device_provisions.c.token_hash == token_hash)
                    .values(
                        uid=uid,
                        profile_id=profile_id,
                        issued_at=utcnow(),
                        expires_at=expires_at,
                        used_at=None,
                        status="active",
                    )
                )

    def mark_provision_token_used(self, token_hash: str) -> None:
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(
                update(device_provisions)
                .where((device_provisions.c.token_hash == token_hash) & (device_provisions.c.status == "active"))
                .values(used_at=utcnow(), status="used")
            )

    def get_provision_token(self, token_hash: str) -> dict[str, Any] | None:
        eng = self.connect()
        with eng.begin() as conn:
            row = conn.execute(
                select(device_provisions).where(device_provisions.c.token_hash == token_hash)
            ).mappings().first()
        return dict(row) if row else None

    def update_provision_token_device(
        self,
        token_hash: str,
        device_id: str | None = None,
        client_ip: str | None = None,
        platform: str | None = None,
        version: str | None = None,
    ) -> None:
        """Update provision token with device consumption info.

        Called after successful token validation to record device details.
        All parameters are optional - only provided values are updated.
        """
        eng = self.connect()
        with eng.begin() as conn:
            update_vals = {}
            if device_id is not None:
                update_vals["consumed_by_device_id"] = device_id
            if client_ip is not None:
                update_vals["consumed_from_ip"] = client_ip
            if platform is not None:
                update_vals["client_platform"] = platform
            if version is not None:
                update_vals["client_version"] = version

            if update_vals:
                conn.execute(
                    update(device_provisions)
                    .where(device_provisions.c.token_hash == token_hash)
                    .values(**update_vals)
                )

    # -----------------
    # SSO Device Provisioning
    # -----------------
    def count_active_device_provisions(
        self, uid: str, exclude_device_id: str | None = None
    ) -> int:
        """Count active device provisions for a user.

        - Only counts status='active' provisions that haven't expired
        - Optionally excludes a specific device_id (for re-provisioning)
        """
        eng = self.connect()
        with eng.begin() as conn:
            conditions = [
                device_provisions.c.uid == uid,
                device_provisions.c.status == "active",
                device_provisions.c.expires_at > utcnow(),
            ]
            if exclude_device_id:
                conditions.append(
                    device_provisions.c.consumed_by_device_id != exclude_device_id
                )
            row = conn.execute(
                select(func.count()).select_from(device_provisions).where(*conditions)
            ).scalar()
            return row or 0

    def upsert_device_provision(
        self,
        uid: str,
        device_id: str,
        profile_id: str,
        expires_at: datetime,
        sealed_payload: bytes,
        public_key_hash: str,
        client_platform: str | None = None,
        client_version: str | None = None,
        app_name: str | None = None,
        client_ip: str | None = None,
    ) -> str:
        """Insert or update a device provision record.

        - Upserts keyed on (uid, device_id)
        - Returns the token_hash for the record
        """
        # M4: use CSPRNG randomness for the record key, not a hash of
        # device_id+uid+unix-seconds (all low-entropy/attacker-influenced, which
        # made the key predictable/forgeable for a known uid). The record is
        # still upserted on (uid, consumed_by_device_id); this value is an opaque
        # identifier, not reconstructed from inputs anywhere.
        import secrets
        token_hash = secrets.token_hex(32)

        eng = self.connect()
        with eng.begin() as conn:
            # Try update first (existing device re-provisioning)
            result = conn.execute(
                update(device_provisions)
                .where(
                    (device_provisions.c.uid == uid)
                    & (device_provisions.c.consumed_by_device_id == device_id)
                )
                .values(
                    token_hash=token_hash,
                    profile_id=profile_id,
                    issued_at=utcnow(),
                    expires_at=expires_at,
                    used_at=None,
                    status="active",
                    sealed_payload=sealed_payload,
                    public_key_hash=public_key_hash,
                    client_platform=client_platform,
                    client_version=client_version,
                    app_name=app_name,
                    consumed_from_ip=client_ip,
                )
            )
            if result.rowcount == 0:
                # New device — insert
                conn.execute(
                    insert(device_provisions).values(
                        token_hash=token_hash,
                        uid=uid,
                        profile_id=profile_id,
                        issued_at=utcnow(),
                        expires_at=expires_at,
                        used_at=None,
                        status="active",
                        consumed_by_device_id=device_id,
                        sealed_payload=sealed_payload,
                        public_key_hash=public_key_hash,
                        client_platform=client_platform,
                        client_version=client_version,
                        app_name=app_name,
                        consumed_from_ip=client_ip,
                    )
                )
        return token_hash

    def revoke_device_provision(self, uid: str, device_id: str) -> bool:
        """Revoke a device provision. Returns True if found and revoked."""
        eng = self.connect()
        with eng.begin() as conn:
            result = conn.execute(
                update(device_provisions)
                .where(
                    (device_provisions.c.uid == uid)
                    & (device_provisions.c.consumed_by_device_id == device_id)
                    & (device_provisions.c.status == "active")
                )
                .values(status="revoked", used_at=utcnow())
            )
            return result.rowcount > 0

    def validate_and_consume_token(self, token_hash: str) -> tuple[bool, str, dict]:
        """Validate a provision token and mark it consumed if valid.

        Uses atomic check-and-update to prevent race conditions where the same
        token could be consumed twice under high concurrency.

        Returns: (valid, error_message, token_data)

        Error messages:
        - "TOKEN_NOT_FOUND": Token doesn't exist
        - "TOKEN_ALREADY_CONSUMED": Token was already used
        - "TOKEN_EXPIRED": Token has expired
        - "": No error, token is valid
        """
        eng = self.connect()
        now = utcnow()  # Capture once to avoid race between check and update

        # Atomic check-and-update: only update if status is active and not expired
        with eng.begin() as conn:
            result = conn.execute(
                update(device_provisions)
                .where(
                    (device_provisions.c.token_hash == token_hash)
                    & (device_provisions.c.status == "active")
                    & (device_provisions.c.expires_at > now)
                )
                .values(used_at=now, status="consumed")
            )

            if result.rowcount == 1:
                # Success - fetch updated token data
                token = self.get_provision_token(token_hash)
                return True, "", token

        # Atomic update failed - determine why
        token = self.get_provision_token(token_hash)
        if not token:
            return False, "TOKEN_NOT_FOUND", {}

        if token.get("status") != "active":
            return False, "TOKEN_ALREADY_CONSUMED", token

        # Must be expired
        return False, "TOKEN_EXPIRED", token

    def revoke_tokens_for_user(self, uid: str) -> tuple[int, list[str]]:
        """Revoke all active provision tokens for a user.

        Returns (count_revoked, list_of_token_hashes).
        """
        eng = self.connect()
        with eng.begin() as conn:
            # Get hashes before revoking
            hashes_result = conn.execute(
                select(device_provisions.c.token_hash).where(
                    (device_provisions.c.uid == uid) &
                    (device_provisions.c.status == "active")
                )
            )
            token_hashes = [r[0] for r in hashes_result]

            if not token_hashes:
                return 0, []

            result = conn.execute(
                update(device_provisions)
                .where(
                    (device_provisions.c.uid == uid) &
                    (device_provisions.c.status == "active")
                )
                .values(status="revoked_terminated", used_at=utcnow())
            )
            return result.rowcount, token_hashes

    def bulk_revoke_tokens(self, token_hashes: list[str], revoked_by: str = "admin") -> dict[str, Any]:
        """Revoke multiple provision tokens by hash.

        - Only active, non-expired tokens are revoked
        - Already consumed/expired/revoked tokens are skipped with reason
        - Returns { revoked_count, skipped_count, errors: [{ token_hash, reason }] }
        """
        eng = self.connect()
        now = utcnow()
        revoked = 0
        skipped = 0
        errors: list[dict[str, str]] = []

        with eng.begin() as conn:
            for h in token_hashes:
                row = conn.execute(
                    select(device_provisions).where(device_provisions.c.token_hash == h)
                ).mappings().first()

                if row is None:
                    skipped += 1
                    errors.append({"token_hash": h, "reason": "not_found"})
                    continue

                if row["status"] != "active":
                    skipped += 1
                    errors.append({"token_hash": h, "reason": f"status_{row['status']}"})
                    continue

                if row["expires_at"] and row["expires_at"].replace(tzinfo=timezone.utc) < now:
                    skipped += 1
                    errors.append({"token_hash": h, "reason": "already_expired"})
                    continue

                conn.execute(
                    update(device_provisions)
                    .where(device_provisions.c.token_hash == h)
                    .values(status="revoked", used_at=now)
                )
                revoked += 1

        return {
            "revoked_count": revoked,
            "skipped_count": skipped,
            "errors": errors,
        }

    def extend_token_expiry(self, token_hash: str, extend_seconds: int, max_ttl_sec: int) -> dict[str, Any]:
        """Extend expiry of an active provision token.

        - Only active, non-expired tokens can be extended
        - Capped: (new_expires_at - issued_at) must not exceed max_ttl_sec
        - Returns { token_hash, new_expires_at } or raises ValueError
        """
        eng = self.connect()
        now = utcnow()

        with eng.begin() as conn:
            row = conn.execute(
                select(device_provisions).where(device_provisions.c.token_hash == token_hash)
            ).mappings().first()

            if row is None:
                raise ValueError("TOKEN_NOT_FOUND")

            if row["status"] != "active":
                raise ValueError(f"TOKEN_NOT_ACTIVE:{row['status']}")

            expires_at = row["expires_at"]
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            if expires_at < now:
                raise ValueError("TOKEN_EXPIRED")

            new_expires = expires_at + timedelta(seconds=extend_seconds)
            issued_at = row["issued_at"]
            if issued_at.tzinfo is None:
                issued_at = issued_at.replace(tzinfo=timezone.utc)

            total_ttl = (new_expires - issued_at).total_seconds()
            if total_ttl > max_ttl_sec:
                raise ValueError(f"EXCEEDS_MAX_TTL:{int(total_ttl)}>{max_ttl_sec}")

            conn.execute(
                update(device_provisions)
                .where(device_provisions.c.token_hash == token_hash)
                .values(expires_at=new_expires)
            )

        return {
            "token_hash": token_hash,
            "new_expires_at": new_expires.isoformat(),
        }

    def list_provisioned_devices(
        self, limit: int = 50, offset: int = 0, search: str = "",
        date_range: str = "30d", platform: str = "",
    ) -> tuple[list[dict[str, Any]], int]:
        """List devices that consumed provision tokens.

        - Queries device_provisions WHERE consumed_by_device_id IS NOT NULL
        - Returns (devices, total_count)
        """
        eng = self.connect()
        now = datetime.now(timezone.utc)
        conditions = [device_provisions.c.consumed_by_device_id.isnot(None)]

        if date_range != "all":
            days_map = {"7d": 7, "30d": 30, "90d": 90}
            days = days_map.get(date_range, 30)
            # Use COALESCE(used_at, issued_at) — SSO-provisioned devices have
            # used_at=NULL until a legacy consume step fires, but they are
            # valid devices with an issued_at timestamp. Without this, SSO
            # devices (now the primary flow) never appear in the list.
            cutoff = now - timedelta(days=days)
            conditions.append(
                func.coalesce(
                    device_provisions.c.used_at,
                    device_provisions.c.issued_at,
                ) >= cutoff
            )

        if search:
            conditions.append(
                or_(
                    device_provisions.c.consumed_by_device_id.ilike(f"%{search}%"),
                    device_provisions.c.uid.ilike(f"%{search}%"),
                )
            )

        if platform:
            conditions.append(device_provisions.c.client_platform == platform)

        count_stmt = select(func.count()).select_from(device_provisions)
        for cond in conditions:
            count_stmt = count_stmt.where(cond)

        data_stmt = (
            select(device_provisions)
            .order_by(
                func.coalesce(device_provisions.c.used_at, device_provisions.c.issued_at).desc(),
                device_provisions.c.token_hash.desc()  # PK tiebreaker — device_provisions has no `id` column; replaces prior buggy .c.id reference that raised AttributeError
            )
            .limit(limit)
            .offset(offset)
        )
        for cond in conditions:
            data_stmt = data_stmt.where(cond)

        with eng.begin() as conn:
            total = conn.execute(count_stmt).scalar() or 0
            rows = conn.execute(data_stmt).mappings().all()

        devices = []
        for r in rows:
            devices.append({
                "device_id": r["consumed_by_device_id"],
                "platform": r["client_platform"],
                "client_version": r["client_version"],
                "app_name": r["app_name"],
                "ip_address": r["consumed_from_ip"],
                "user_uid": r["uid"],
                "user_display_name": r["uid"],
                "consumed_at": r["used_at"].isoformat() if r["used_at"] else None,
                "token_hash": r["token_hash"],
                "token_status": r["status"],
            })
        return devices, total

    def get_device_token_history(self, device_id: str) -> list[dict[str, Any]]:
        """Get all tokens consumed by a specific device."""
        eng = self.connect()
        stmt = (
            select(device_provisions)
            .where(device_provisions.c.consumed_by_device_id == device_id)
            .order_by(device_provisions.c.used_at.desc())
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()

        return [
            {
                "token_hash": r["token_hash"],
                "user_uid": r["uid"],
                "consumed_at": r["used_at"].isoformat() if r["used_at"] else None,
                "status": r["status"],
                "platform": r["client_platform"],
                "client_version": r["client_version"],
                "app_name": r["app_name"],
            }
            for r in rows
        ]

    def list_devices_for_user(self, uid: str) -> list[dict[str, Any]]:
        """Return devices that consumed provision tokens for a specific user."""
        eng = self.connect()
        stmt = (
            select(
                device_provisions.c.consumed_by_device_id,
                device_provisions.c.client_platform,
                device_provisions.c.client_version,
                device_provisions.c.consumed_from_ip,
                device_provisions.c.used_at,
                device_provisions.c.status,
            )
            .where(device_provisions.c.uid == uid)
            .where(device_provisions.c.consumed_by_device_id.isnot(None))
            .order_by(device_provisions.c.used_at.desc())
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()

        devices = []
        for r in rows:
            devices.append({
                "device_id": r["consumed_by_device_id"],
                "platform": r["client_platform"] or "",
                "client_version": r["client_version"] or "",
                "ip_address": r["consumed_from_ip"] or "",
                "consumed_at": r["used_at"].isoformat() if r["used_at"] else None,
                "status": r["status"],
            })
        return devices

    def get_pending_provisions(self) -> list[dict[str, Any]]:
        """Active, unexpired provision tokens not yet consumed.

        - Used by /api/provisions/pending dashboard card
        - Returns rows with id, uid, expires_at for each pending token
        """
        eng = self.connect()
        now = datetime.now(timezone.utc)
        stmt = (
            select(
                device_provisions.c.token_hash,
                device_provisions.c.uid,
                device_provisions.c.expires_at,
            )
            .where(
                device_provisions.c.used_at.is_(None),
                device_provisions.c.status == "active",
                or_(
                    device_provisions.c.expires_at.is_(None),
                    device_provisions.c.expires_at > now,
                ),
            )
            .order_by(device_provisions.c.expires_at.asc())
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()
        return [
            {
                "id": r["token_hash"],
                "uid": r["uid"],
                "expires_at": r["expires_at"].isoformat() if r["expires_at"] else None,
            }
            for r in rows
        ]
