"""Authentik Admin API v3 client for session/token lifecycle.

- Revoke user sessions on termination
- Revoke OAuth2 access/refresh tokens on termination
- Used by termination endpoint in main.py
- Create a first-party client's providers and applications at onboarding (ARD-022)

Authentik API: https://docs.goauthentik.io/developer-docs/api/
Gotcha: end_session does NOT revoke tokens — must explicit DELETE.
"""

from __future__ import annotations

import json
import logging
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote
from typing import Any, Dict, Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

logger = logging.getLogger(__name__)

LDAP_SOURCE_SLUG = "azblink-ldap"  # created by the Authentik seed (ARD-007)


class AuthentikError(Exception):
    """Raised when Authentik API call fails."""
    pass


class AuthentikClient:
    """Client for Authentik Admin API v3.

    - Stateless — no session caching
    - Used for admin operations (revocation, not auth)
    """

    def __init__(self, api_url: str, api_token: str):
        self.api_url = api_url.rstrip("/") if api_url else ""
        self.api_token = api_token

    @property
    def configured(self) -> bool:
        """Whether the client has valid connection info."""
        return bool(self.api_url and self.api_token)

    def _api_request(
        self, method: str, path: str, body: Optional[Dict] = None
    ) -> Optional[Dict[str, Any]]:
        """Make authenticated request to Authentik Admin API."""
        if not self.configured:
            raise AuthentikError("Authentik client not configured")

        url = f"{self.api_url}{path}"
        data = json.dumps(body).encode("utf-8") if body else None
        req = Request(url, data=data, method=method)
        req.add_header("Authorization", f"Bearer {self.api_token}")
        req.add_header("Accept", "application/json")
        if data:
            req.add_header("Content-Type", "application/json")

        try:
            with urlopen(req, timeout=10) as resp:
                if resp.status == 204:
                    return None
                return json.loads(resp.read().decode("utf-8"))
        except HTTPError as e:
            # Already gone: a session DELETE cascades to its access tokens.
            if method == "DELETE" and e.code == 404:
                return None
            raise AuthentikError(
                f"Authentik API {method} {path} returned {e.code}: {e.reason}"
            ) from e
        except URLError as e:
            raise AuthentikError(f"Authentik API unreachable: {e.reason}") from e
        # A read timeout or reset mid-response (OSError) and a non-JSON body
        # (ValueError) are Authentik failures too: callers catch only AuthentikError.
        except (OSError, ValueError) as e:
            raise AuthentikError(f"Authentik API {method} {path} failed: {type(e).__name__}") from e

    def _find_user_pk(self, username: str) -> Optional[int]:
        """Find Authentik user PK by username: quoted, exact match only.

        Unquoted, urllib dropped everything after a '#', so `keith#1` looked up
        `keith`, and suspending it revoked keith's sessions and tokens (review finding 14).
        """
        user = self._user(username)
        return user["pk"] if user else None

    def revoke_user_sessions(self, username: str, pk: Optional[int] = None) -> Dict[str, Any]:
        """Revoke all Authentik sessions for a user.

        - Finds user PK by username unless the caller already has it
        - Lists every page of the user's AuthenticatedSession objects, then deletes them
        - 2026.5 ignores `?user=<pk>` here and lists everyone's sessions, so the
          filter is `user__username` and each row's `user` must still be `pk`
        """
        try:
            pk = pk if pk is not None else self._find_user_pk(username)
            if pk is None:
                return {"user_found": False, "sessions_revoked": 0}

            session_list, page = [], 1
            while page:
                sessions = self._api_request(
                    "GET",
                    f"/api/v3/core/authenticated_sessions/?user__username={quote(username)}&page={page}",
                ) or {}
                session_list += [s for s in sessions.get("results", []) if s.get("user") == pk]
                page = (sessions.get("pagination") or {}).get("next") or 0

            for session in session_list:
                # 2026.5 keys sessions on `uuid`; there is no `pk`.
                self._api_request(
                    "DELETE",
                    f"/api/v3/core/authenticated_sessions/{session['uuid']}/",
                )

            logger.info(
                "Revoked %d Authentik sessions for user %s", len(session_list), username
            )
            return {"user_found": True, "sessions_revoked": len(session_list)}
        except AuthentikError:
            raise
        except Exception as e:
            raise AuthentikError(f"Failed to revoke sessions: {e}") from e

    def revoke_user_tokens(self, username: str, pk: Optional[int] = None) -> Dict[str, Any]:
        """Revoke all OAuth2 access and refresh tokens for a user.

        - Finds user PK by username unless the caller already has it
        - Lists both kinds at once, then deletes every access token, then every
          refresh token: a surviving refresh token keeps minting access tokens (ARD-019 §7)
        """
        try:
            pk = pk if pk is not None else self._find_user_pk(username)
            if pk is None:
                return {"user_found": False, "tokens_revoked": 0}

            kinds = ("access_tokens", "refresh_tokens")
            with ThreadPoolExecutor(max_workers=len(kinds)) as pool:
                listed = list(pool.map(
                    lambda kind: self._api_request("GET", f"/api/v3/oauth2/{kind}/?user={pk}&page_size=500"), kinds))
            token_list = []
            for kind, tokens in zip(kinds, listed, strict=True):
                for token in tokens.get("results", []) if tokens else []:
                    self._api_request("DELETE", f"/api/v3/oauth2/{kind}/{token['pk']}/")
                    token_list.append(token)

            logger.info(
                "Revoked %d OAuth2 tokens for user %s", len(token_list), username
            )
            return {"user_found": True, "tokens_revoked": len(token_list)}
        except AuthentikError:
            raise
        except Exception as e:
            raise AuthentikError(f"Failed to revoke tokens: {e}") from e

    def terminate_user_access(self, username: str) -> Dict[str, Any]:
        """Full termination — revoke sessions + tokens, side by side, from one user lookup.

        Called by the user termination and suspend endpoints.
        """
        pk = self._find_user_pk(username)
        if pk is None:
            return {"user_found": False, "sessions_revoked": 0, "tokens_revoked": 0}
        with ThreadPoolExecutor(max_workers=2) as pool:
            sessions_job = pool.submit(self.revoke_user_sessions, username, pk)
            tokens_job = pool.submit(self.revoke_user_tokens, username, pk)
            sessions, tokens = sessions_job.result(), tokens_job.result()
        return {
            "user_found": sessions["user_found"],
            "sessions_revoked": sessions["sessions_revoked"],
            "tokens_revoked": tokens["tokens_revoked"],
        }

    def in_group(self, username: str, group: str) -> bool:
        """Whether the Authentik user `username` is a direct member of `group` (False if no such user)."""
        result = self._api_request("GET", f"/api/v3/core/users/?username={quote(username)}") or {}
        users = [u for u in result.get("results", []) if u.get("username") == username]
        return any(g.get("name") == group for u in users for g in u.get("groups_obj") or [])

    def trigger_ldap_sync(self, slug: str = LDAP_SOURCE_SLUG) -> None:
        """Queue an immediate sync of the LDAP source (ARD-018 decision 16).

        A first-party client's role change reaches its tokens at the next
        refresh only after Authentik has re-read the group. Schedules carry the
        source pk as rel_obj_id, not the slug.
        """
        source = self._api_request("GET", f"/api/v3/sources/ldap/{quote(slug)}/")
        if not source:
            raise AuthentikError(f"LDAP source {slug} not found")
        schedules = self._api_request("GET", "/api/v3/tasks/schedules/?page_size=200") or {}
        sync = [s for s in schedules.get("results", [])
                if str(s.get("rel_obj_id")) == str(source["pk"])
                and "sync" in (s.get("actor_name") or "").lower()]
        if not sync:
            raise AuthentikError(f"no sync schedule for LDAP source {slug}")
        # A send while a sync is running is dropped (seen live on 2026.5): the
        # running sync may have read the group before this change. Wait it out.
        # ponytail: fixed 2 s poll, 120 s cap; a webhook would beat polling if syncs get long.
        for _ in range(60):
            status = self._api_request("GET", f"/api/v3/sources/ldap/{quote(slug)}/sync/status/") or {}
            if not status.get("is_running"):
                break
            time.sleep(2)
        self._api_request("POST", f"/api/v3/tasks/schedules/{sync[0]['id']}/send/")
        logger.info("Triggered Authentik LDAP source sync (%s)", slug)

    def delete_group(self, name: str) -> bool:
        """Delete the Authentik group with this name, ignoring case; False if absent.

        The LDAP source never deletes groups (`delete_not_found_objects` is off
        for users' sake), so a deleted client role group is removed here (G16).
        LDAP matches cns case-insensitively and `openldap-cn` names the copy with
        the cn's own case, while `?name=` is case-sensitive: look up with
        `?search=` (contains, any case) and keep only whole-name matches.
        """
        # ponytail: one page of 100; a name contained in more groups than that could miss its copy.
        result = self._api_request(
            "GET", f"/api/v3/core/groups/?search={quote(name)}&page_size=100") or {}
        match = [g for g in result.get("results", []) if (g.get("name") or "").lower() == name.lower()]
        for group in match:
            self._api_request("DELETE", f"/api/v3/core/groups/{group['pk']}/")
        if match:
            logger.info("Deleted Authentik group %s", name)
        return bool(match)

    def _user(self, username: str) -> Optional[Dict[str, Any]]:
        """The Authentik user with exactly this username, or None."""
        result = self._api_request("GET", f"/api/v3/core/users/?username={quote(username)}") or {}
        return next((u for u in result.get("results", []) if u.get("username") == username), None)

    def set_active(self, username: str, active: bool) -> bool:
        """Set the user's `is_active`; False if the user is not in Authentik.

        An inactive user cannot sign in. The LDAP source never writes `is_active`
        for OpenLDAP entries, so a sync does not undo it.
        """
        user = self._user(username)
        if not user:
            return False
        if user.get("is_active") != active:
            self._api_request("PATCH", f"/api/v3/core/users/{user['pk']}/", {"is_active": active})
            logger.info("Set Authentik is_active=%s for user %s", active, username)
        return True

    def revoke_app_passwords(self, username: str) -> int:
        """Delete the user's app passwords: each one mints tokens without the LDAP password."""
        result = self._api_request(
            "GET", f"/api/v3/core/tokens/?user__username={quote(username)}&intent=app_password&page_size=500") or {}
        mine = [t for t in result.get("results", [])
                if t.get("intent") == "app_password" and (t.get("user_obj") or {}).get("username") == username]
        for token in mine:
            self._api_request("DELETE", f"/api/v3/core/tokens/{quote(token['identifier'])}/")
        if mine:
            logger.info("Revoked %d Authentik app passwords for user %s", len(mine), username)
        return len(mine)

    def clear_reputation(self, username: str) -> int:
        """Delete the username's reputation rows and its LDAP bind budget (spec 08 unblock runbook)."""
        removed = 0
        for identifier in (username, f"ldap-bind-budget:{username.lower()}"):
            result = self._api_request(
                "GET", f"/api/v3/policies/reputation/scores/?identifier={quote(identifier)}&page_size=500") or {}
            for row in result.get("results", []):
                if row.get("identifier", "").lower() == identifier.lower():
                    self._api_request("DELETE", f"/api/v3/policies/reputation/scores/{row['pk']}/")
                    removed += 1
        if removed:
            logger.info("Cleared %d Authentik reputation rows for %s", removed, username)
        return removed

    # ── First-party client onboarding (ARD-022) ─────────────────────────────
    # The same objects authentik-seed's ensure_first_party_client and
    # ensure_service_client build for env clients (deploy/dev/authentik-seed/
    # seed_authentik.py); the seed's container is not importable from here.

    def _get(self, path: str) -> Optional[Dict[str, Any]]:
        """GET, or None on 404."""
        try:
            return self._api_request("GET", path)
        except AuthentikError as e:
            if " returned 404" in str(e):
                return None
            raise

    def _obj(self, method: str, path: str, body: Optional[Dict] = None) -> Dict[str, Any]:
        """A request that must answer with an object."""
        result = self._api_request(method, path, body)
        if not isinstance(result, dict):
            raise AuthentikError(f"Authentik API {method} {path} returned no object")
        return result

    def existing_clients(self, ids: list) -> list:
        """Those of `ids` that already name an OAuth2 provider or an application slug in Authentik."""
        taken = []
        for cid in ids:
            found = (self._api_request("GET", f"/api/v3/providers/oauth2/?client_id={quote(cid)}") or {}).get("results", [])
            if any(p.get("client_id") == cid for p in found) or self._get(f"/api/v3/core/applications/{quote(cid)}/"):
                taken.append(cid)
        return taken

    def _flow_pk(self, designation: str, preferred: str) -> str:
        flows = (self._api_request("GET", f"/api/v3/flows/instances/?designation={designation}") or {}).get("results", [])
        if not flows:
            raise AuthentikError(f"no {designation} flow")
        return next((f["pk"] for f in flows if preferred in f.get("slug", "")), flows[0]["pk"])

    def _provider_base(self) -> Dict[str, Any]:
        """Fields every client provider shares: flows, signing key, the four scope mappings."""
        mappings = (self._api_request("GET", "/api/v3/propertymappings/all/?page_size=200") or {}).get("results", [])
        scopes = [m["pk"] for m in mappings if m.get("managed") in SCOPE_MAPPINGS]
        if len(scopes) != len(SCOPE_MAPPINGS):
            raise AuthentikError("scope mappings missing")
        keys = (self._api_request("GET", "/api/v3/crypto/certificatekeypairs/") or {}).get("results", [])
        key = next((k["pk"] for k in keys if "self-signed" in k.get("name", "").lower()), keys[0]["pk"] if keys else None)
        return {
            "authorization_flow": self._flow_pk("authorization", "implicit-consent"),
            "invalidation_flow": self._flow_pk("invalidation", "default-invalidation"),
            "signing_key": key,
            "property_mappings": scopes,
            "client_type": "confidential",
            "sub_mode": "hashed_user_id",
            "include_claims_in_id_token": True,
            "access_token_validity": "minutes=15",
        }

    def _ensure_provider_and_app(self, data: Dict[str, Any]) -> Optional[str]:
        """Create or converge the provider `data["client_id"]` and its application (slug = client_id).

        Converges redirect URIs, grant types and the authentication flow; the secret is
        Authentik's and never rotated. Returns the client secret only when this call created
        the provider: directory admins are not Authentik superusers, so a repeat must not echo it.
        """
        cid = data["client_id"]
        found = (self._api_request("GET", f"/api/v3/providers/oauth2/?client_id={quote(cid)}") or {}).get("results", [])
        provider = next((p for p in found if p.get("client_id") == cid), None)
        created = provider is None
        if provider is None:
            provider = self._obj("POST", "/api/v3/providers/oauth2/", data)
            logger.info("Created Authentik provider %s", cid)
        else:
            patch = {k: data[k] for k in ("grant_types", "authentication_flow") if k in data and provider.get(k) != data[k]}
            if {u.get("url") for u in provider.get("redirect_uris", [])} != {u["url"] for u in data["redirect_uris"]}:
                patch["redirect_uris"] = data["redirect_uris"]
            if patch:
                provider = self._obj("PATCH", f"/api/v3/providers/oauth2/{provider['pk']}/", patch)
        # Retrieve by slug: `?slug=` does not filter results on 2026.5 (rules/authentik.md).
        # policy_engine_mode `all`, as the seed's apps (#397): no later binding can outvote the access policy.
        app = self._get(f"/api/v3/core/applications/{quote(cid)}/")
        if app is None:
            self._api_request("POST", "/api/v3/core/applications/", {
                "name": cid, "slug": cid, "provider": provider["pk"], "policy_engine_mode": "all"})
            logger.info("Created Authentik application %s", cid)
        elif app.get("policy_engine_mode") != "all":
            self._api_request("PATCH", f"/api/v3/core/applications/{quote(cid)}/", {"policy_engine_mode": "all"})
        return provider.get("client_secret") if created else None

    def ensure_first_party_client(self, client_id: str, redirect_uris: list) -> Optional[str]:
        """Login client (ARD-018): headless flow, code + refresh only, `<client_id>-*` members only.

        Raises AuthentikError when the shared headless flow is missing: authentik-seed creates it.
        """
        flow = self._get(f"/api/v3/flows/instances/{HEADLESS_FLOW_SLUG}/")
        if flow is None:
            raise AuthentikError(f"flow {HEADLESS_FLOW_SLUG} missing; run authentik-seed")
        secret = self._ensure_provider_and_app({
            **self._provider_base(),
            "name": client_id,
            "client_id": client_id,
            "authentication_flow": flow["pk"],
            "redirect_uris": [{"matching_mode": "strict", "url": u} for u in redirect_uris],
            "refresh_token_validity": "days=7",
            "grant_types": ["authorization_code", "refresh_token"],
        })
        self._ensure_app_policy(client_id, f"{client_id}: member of {client_id}-*",
                                f"return any(g.name.startswith({client_id + '-'!r}) for g in request.user.ak_groups.all())")
        return secret

    def _ensure_app_policy(self, slug: str, name: str, expression: str) -> None:
        """Bind the expression policy `name` to application `slug` (create or converge); errors deny."""
        app = self._obj("GET", f"/api/v3/core/applications/{quote(slug)}/")
        found = (self._api_request("GET", f"/api/v3/policies/expression/?name={quote(name)}") or {}).get("results", [])
        policy = next((p for p in found if p.get("name") == name), None)
        if policy is None:
            policy = self._obj("POST", "/api/v3/policies/expression/", {"name": name, "expression": expression})
        elif policy.get("expression") != expression:
            self._api_request("PATCH", f"/api/v3/policies/expression/{policy['pk']}/", {"expression": expression})
        bindings = (self._api_request("GET", f"/api/v3/policies/bindings/?policy={policy['pk']}") or {}).get("results", [])
        if not any(b.get("target") == app["pk"] for b in bindings):
            self._api_request("POST", "/api/v3/policies/bindings/", {
                "policy": policy["pk"], "target": app["pk"], "order": 0, "enabled": True, "negate": False,
                "timeout": 30, "failure_result": False})

    def ensure_pach_application_oidc(self, client_id: str, redirect_uris: list[str]) -> Optional[str]:
        """Provision a general PACH application, without first-party group/SIP/XMPP flows.

        All successfully authenticated directory users MAY complete OIDC login,
        but the application MUST separately enforce VM6 per-application roles.
        This is deliberately not the ARD-022 first-party scoped client method.
        A returned secret is shown only on initial provider creation.
        """
        secret = self._ensure_provider_and_app({
            **self._provider_base(),
            "name": client_id,
            "client_id": client_id,
            "redirect_uris": [{"matching_mode": "strict", "url": u} for u in redirect_uris],
            "refresh_token_validity": "days=7",
            "grant_types": ["authorization_code", "refresh_token"],
        })
        self._ensure_app_policy(
            client_id, f"{client_id}: authenticated human",
            "return request.user.is_authenticated and not request.user.is_anonymous",
        )
        return secret

    def ensure_service_client(self, client_id: str) -> Optional[str]:
        """API-to-API client (ARD-017): client_credentials only, so its account is `ak-<client_id>-client_credentials`.

        Its application admits only that account: without the policy the same grant
        mints a token for any user's app password (audit B2, the seed's twin).
        """
        secret = self._ensure_provider_and_app({
            **self._provider_base(),
            "name": client_id,
            "client_id": client_id,
            "redirect_uris": [],
            "grant_types": ["client_credentials"],
        })
        account = f"ak-{client_id}-client_credentials"
        self._ensure_app_policy(client_id, f"{client_id}: only {account}", f"return request.user.username == {account!r}")
        return secret

    def ensure_ldap_group_sync(self, client_id: str, slug: str = LDAP_SOURCE_SLUG) -> bool:
        """Add `(cn=<client_id>-*)` to the LDAP source's group filter; True if it changed.

        Keeps every term already there: the seed and this call each add their own clients.
        """
        source = self._api_request("GET", f"/api/v3/sources/ldap/{quote(slug)}/") or {}
        ids = set(GROUP_FILTER_TERM.findall(source.get("group_object_filter") or ""))
        if client_id in ids and source.get("sync_groups"):
            return False
        # 2026.5 validates a PATCH with sync_groups against the body alone: the group
        # mappings must be sent even when the source already has them.
        group_mappings = source.get("group_property_mappings") or [
            m["pk"] for m in (self._api_request("GET", "/api/v3/propertymappings/all/?page_size=200") or {}).get("results", [])
            if m.get("managed") == "goauthentik.io/sources/ldap/openldap-cn"]
        patch: Dict[str, Any] = {
            "group_object_filter": ldap_group_filter(ids | {client_id}),
            "sync_groups": True,
            "additional_group_dn": "ou=groups",
            "group_membership_field": "member",
            "group_property_mappings": group_mappings,
        }
        self._api_request("PATCH", f"/api/v3/sources/ldap/{quote(slug)}/", patch)
        logger.info("LDAP source %s now syncs %s-* groups", slug, client_id)
        return True


HEADLESS_FLOW_SLUG = "headless-first-party-auth"  # created by the Authentik seed (ARD-018)
SCOPE_MAPPINGS = frozenset({
    "goauthentik.io/providers/oauth2/scope-openid",
    "goauthentik.io/providers/oauth2/scope-profile",
    "goauthentik.io/providers/oauth2/scope-email",
    "goauthentik.io/providers/oauth2/scope-offline_access",
})
GROUP_FILTER_TERM = re.compile(r"\(cn=([a-z0-9-]+)-\*\)")


def ldap_group_filter(client_ids) -> str:
    """The LDAP source's group filter: one `cn=<client_id>-*` term per client (ARD-018, seed's twin)."""
    terms = "".join(f"(cn={c}-*)" for c in sorted(client_ids))
    return f"(&(objectClass=groupOfNames)(|{terms}))"


def run_in_background(fn, *args) -> None:
    """Fire-and-forget: a slow or absent Authentik never blocks a directory write."""
    def _run() -> None:
        try:
            fn(*args)
        except Exception as e:  # noqa: BLE001 — logged, never raised into the request
            logger.warning("Authentik call %s failed: %s", getattr(fn, "__name__", fn), e)
    threading.Thread(target=_run, daemon=True).start()
