"""Redis mirror of account-lock state, so lock enforcement survives a
PostgreSQL outage (ARD-012 §1–§2).

PostgreSQL stays authoritative. Each active lock is additionally held in Redis
under `azblink:account_lock:<uid>` with a TTL covering the lock duration, and
`check_account_locked` reads through to the mirror when the PostgreSQL read
raises. A mirror hit means locked and denies exactly as it does today.

THE COMPLETENESS SENTINEL IS THE LOAD-BEARING PART. A positive-only cache may be
treated as authoritative only if every lock reached it — otherwise a miss reads
as "not locked" and the hole ARD-012 closes reappears one layer down. So the
mirror is trusted only while `azblink:account_lock:synced` is present.

Where this departs from ARD-012 as written, and why
---------------------------------------------------
ARD-012 §1 assumes locks are "issued normally" through code and propagate to the
mirror on write. They are not: `OrgDB.lock_account()` has no production caller.
ARD-009/H4 deliberately removed the auto-lock path (it let an attacker lock any
victim by naming them in a forged token) and no admin lock endpoint replaced it,
so today the only way a row enters `account_locks` is out-of-band SQL — which
dual-write can never observe.

A sentinel set once at startup would therefore assert a completeness the mirror
does not have, which is exactly the failure §2 exists to prevent. So the sentinel
carries a TTL refreshed by each successful full re-sync:

    re-sync succeeds  → SET sentinel EX (2 × interval)
    re-sync stops     → sentinel expires → mirror untrusted → fail closed
    mirror write fails → sentinel deleted immediately

Staleness is then bounded by one re-sync interval instead of being unbounded, and
the failure direction is "deny and make the operator notice" rather than "admit
silently". Dual-write is still implemented, because it is correct the moment a
lock endpoint exists and it narrows the window to ~zero for locks issued in-code.
Recorded as an append-only amendment on ARD-012.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Optional, Tuple

from degraded import DegradedSite

logger = logging.getLogger(__name__)

KEY_PREFIX = "azblink:account_lock:"
# Deliberately OUTSIDE KEY_PREFIX. Inside it, the sentinel would be scanned as a
# lock key and `read_lock("synced")` would report a user named `synced` locked.
SENTINEL_KEY = "azblink:account_lock_mirror:synced"

# One minute between full re-syncs; the sentinel outlives two of them so a single
# slow or skipped pass does not flap the mirror into "untrusted".
RESYNC_INTERVAL_SECONDS = 60
SENTINEL_TTL_SECONDS = 2 * RESYNC_INTERVAL_SECONDS

# Verdicts from a mirror read.
LOCKED = "locked"
NOT_LOCKED = "not_locked"
UNKNOWN = "unknown"

_mirror_site = DegradedSite("account_lock_mirror", logger)


def _redis() -> Optional[Any]:
    """The shared client from deps, imported lazily to avoid a cycle.

    deps imports orgdb which imports db.*, and db.security dual-writes through
    here; importing deps at module scope would close that loop.
    """
    try:
        from deps import ip_block_redis
    except Exception:  # pragma: no cover — import-time failure only
        return None
    return ip_block_redis


def _ttl_for(locked_until: datetime) -> int:
    """Seconds until the lock expires, floored at 1s so SETEX stays valid."""
    if locked_until.tzinfo is None:
        locked_until = locked_until.replace(tzinfo=timezone.utc)
    delta = (locked_until - datetime.now(timezone.utc)).total_seconds()
    return max(1, int(delta))


def invalidate_sentinel(reason: str) -> None:
    """Drop the completeness claim. The mirror is not trusted until a re-sync."""
    client = _redis()
    if client is None:
        return
    try:
        client.delete(SENTINEL_KEY)
        logger.warning("account-lock mirror sentinel cleared: %s", reason)
    except Exception:
        # Nothing more we can do; a sentinel we cannot delete will expire on its
        # own within SENTINEL_TTL_SECONDS, which is why it carries a TTL at all.
        logger.warning("account-lock mirror sentinel could not be cleared: %s", reason)


def mirror_lock(username: str, locked_until: datetime) -> bool:
    """Write one lock to the mirror. Clears the sentinel on failure."""
    client = _redis()
    if client is None:
        return False
    try:
        client.setex(f"{KEY_PREFIX}{username}", _ttl_for(locked_until), locked_until.isoformat())
        return True
    except Exception as exc:
        invalidate_sentinel(f"mirror write failed for {username}: {exc.__class__.__name__}")
        return False


def mirror_unlock(username: str) -> bool:
    """Remove one lock from the mirror. Clears the sentinel on failure.

    A failed delete is the dangerous direction for availability — the mirror would
    keep denying a user who is no longer locked — so it invalidates too, which
    makes the next PostgreSQL outage fail closed rather than deny one principal on
    stale data.
    """
    client = _redis()
    if client is None:
        return False
    try:
        client.delete(f"{KEY_PREFIX}{username}")
        return True
    except Exception as exc:
        invalidate_sentinel(f"mirror delete failed for {username}: {exc.__class__.__name__}")
        return False


def read_lock(username: str) -> Tuple[str, Optional[str]]:
    """Read lock state from the mirror.

    Returns (LOCKED, locked_until_iso) | (NOT_LOCKED, None) | (UNKNOWN, None).

    UNKNOWN whenever the mirror cannot be trusted: no Redis, Redis unreachable, or
    the sentinel absent. The caller must treat UNKNOWN as "lock state unknowable"
    and fail closed — never as "not locked".
    """
    client = _redis()
    if client is None:
        return UNKNOWN, None
    try:
        # Sentinel and value in one round trip, so the window in which the
        # sentinel expires between the two reads is as small as we can make it.
        pipe = client.pipeline()
        pipe.exists(SENTINEL_KEY)
        pipe.get(f"{KEY_PREFIX}{username}")
        sentinel, value = pipe.execute()
    except Exception as exc:
        _mirror_site.enter(exc, username=username)
        return UNKNOWN, None
    _mirror_site.recover()
    if not sentinel:
        return UNKNOWN, None
    if value:
        return LOCKED, value if isinstance(value, str) else value.decode("utf-8", "replace")
    return NOT_LOCKED, None


def resync(orgdb: Any) -> bool:
    """Rebuild the mirror from PostgreSQL and refresh the sentinel.

    Returns True when the mirror is complete as of this call. Any failure leaves
    the sentinel untouched so it expires on its own — we never extend a
    completeness claim we could not verify.
    """
    client = _redis()
    if client is None:
        return False
    try:
        active = orgdb.list_active_locks()
    except Exception as exc:
        logger.warning(
            "account-lock mirror re-sync skipped: PostgreSQL unreachable (%s)",
            exc.__class__.__name__,
        )
        return False

    try:
        desired = {f"{KEY_PREFIX}{row['username']}": row["locked_until"] for row in active}
        stale = [
            key
            for key in client.scan_iter(match=f"{KEY_PREFIX}*", count=500)
            if key not in desired
        ]
        pipe = client.pipeline()
        for key, locked_until in desired.items():
            pipe.setex(key, _ttl_for(locked_until), locked_until.isoformat())
        if stale:
            pipe.delete(*stale)
        pipe.setex(SENTINEL_KEY, SENTINEL_TTL_SECONDS, datetime.now(timezone.utc).isoformat())
        pipe.execute()
    except Exception as exc:
        logger.warning(
            "account-lock mirror re-sync failed: Redis unreachable (%s); sentinel left to expire",
            exc.__class__.__name__,
        )
        return False

    logger.debug("account-lock mirror re-synced: %d active lock(s)", len(desired))
    return True


async def run_resync_loop(orgdb: Any, interval: int = RESYNC_INTERVAL_SECONDS) -> None:
    """Refresh the mirror and its sentinel forever. Started from main's lifespan.

    Runs the synchronous re-sync on a worker thread so a slow PostgreSQL read
    cannot stall the event loop. Catches everything: this task failing must never
    take the app down, and a failed pass simply lets the sentinel expire — which
    is the safe direction, because an unrefreshed sentinel means the mirror stops
    being trusted rather than silently going stale.
    """
    import asyncio

    while True:
        try:
            await asyncio.to_thread(resync, orgdb)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 — belt and braces; resync catches its own
            logger.warning("account-lock mirror re-sync loop iteration failed", exc_info=True)
        await asyncio.sleep(interval)
