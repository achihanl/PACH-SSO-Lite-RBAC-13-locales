# PACH VM6 v0.23.2 RC18 — cumulative locale expansion

Baseline: v0.23.1 RC17.

Added 63 Settings keys × 10 languages = 630 new locale entries, focusing on LDAP client lists, onboarding controls, and provisioned client secrets. All previously localized entries are unchanged.

Current coverage: 962 / 1062 English keys per newer language. Remaining 100 keys per newer language, all in Settings. See JSON coverage for exact remaining keys.

All language values are draft translations unless independently approved in the cumulative PACH Master Terminology glossary. The existing glossary approvals and Concept ID mappings are retained without modifications. Protocol tokens LDAP, SIP, URI, OIDC, and Bind DN remain technical identifiers.

Validation: zero placeholder mismatches, complete locale resource structure, no changes to RBAC Lite / SSO code, and baseline source preserved. No native-speaker audit, frontend build, Arabic RTL browser test, or live Authentik/OpenLDAP/PostgreSQL integration test was executed in this increment.
