# _ARCHIVE_ — Scheduled for deletion 2026-03-21

**Created:** 2026-03-06
**Delete after:** 2026-03-21 (15-day retention)

## Why

Pre-March content superseded by single-LDAP architecture (PR #12), Authentik OIDC auth (PR #13), and Authentik dev stack (PR #14). These files are no longer referenced by active code or current plans.

## Contents

| Original Location | Description |
|-------------------|-------------|
| `docs/archive/` | 48 files — v1.0 specs, old implementation plans, Jan design docs |
| `docs/plans/2026-02-*` | 57 files — February plans (UED sync, groups, settings, etc.) |
| `docs/plans/sessions/2026-02-*` | 9 files — February session artifacts |
| `docs/reports/` | 2 files — UED/SSO analysis reports |
| `docs/domains/split-panel-migrations.md` | 1 file — old migration domain doc |
| `docs/api/` | 3 files — Jan 25 OpenAPI specs + frontend contracts |
| `new-migration-ui/` | 19 files — HTML screenshots + migration specs |
| `.cursor/rules/` | 2 files — old workflow .mdc files |

## Recovery

Any file can be recovered from git history:

    git log --all -- <original-path>
    git show <commit>:<original-path>

## Deletion

On or after 2026-03-21:

    rm -rf _ARCHIVE_/
    # Edit .dockerignore to remove _ARCHIVE_/ line
    git add -A && git commit -m "chore: remove _ARCHIVE_ after 15-day retention"
