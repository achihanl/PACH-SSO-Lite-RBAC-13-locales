# Audit Log — React Migration Spec

## 1. Component Tree

```
AuditLogPage/
├── AuditPageHeader
│   ├── PageTitle ("Audit Log")
│   ├── FilterContextBanner          ← conditional: shown when ?qr=QR-XXXX in URL
│   │   ├── FilterIcon (funnel SVG)
│   │   ├── FilterText ("Filtered by QR: QR-2026-0156")
│   │   └── ClearFilterButton
│   └── HeaderActions
│       ├── SearchInput              → BaseUI Input w/ startEnhancer
│       └── ExportButton             → BaseUI Button KIND.secondary
│
├── AuditFilterBar
│   ├── TimeRangeSelect              → BaseUI Select (Today | 7d | 30d | 90d | Custom)
│   ├── EventTypeSelect              → BaseUI Select (All | QR | User | Auth | Config)
│   ├── FilterChips                  → custom toggle chip group
│   │   ├── FilterChip[qr-generated]
│   │   ├── FilterChip[qr-consumed]
│   │   ├── FilterChip[qr-expired]
│   │   └── FilterChip[user-events]
│   └── LiveIndicator                ← pulsing green dot + "Live updates"
│
├── AuditGrid                        ← CSS Grid: 1fr 380px (collapses at 1100px)
│   ├── AuditTableContainer
│   │   ├── TableHeader
│   │   │   ├── TitleBlock ("Activity Log · 1,247 events")
│   │   │   └── RefreshButton        → BaseUI Button KIND.tertiary
│   │   ├── AuditTable
│   │   │   ├── AuditTableHead       ← sticky header row
│   │   │   └── AuditTableBody       ← scrollable, max-height viewport calc
│   │   │       └── AuditRow[]       ← per-event row (repeated)
│   │   │           ├── TimestampCell
│   │   │           ├── EventCell
│   │   │           │   ├── EventIcon        ← colored icon per event type
│   │   │           │   ├── EventTitle
│   │   │           │   └── EventDescription
│   │   │           ├── ActorCell
│   │   │           ├── TargetCell
│   │   │           └── ReferenceCell        ← clickable QR/TRM/USR/CFG/SES ID
│   │   └── Pagination
│   │       ├── PaginationInfo ("Showing 1-20 of 1,247")
│   │       └── PaginationControls
│   │           ├── PrevButton
│   │           ├── PageNumbers[]
│   │           └── NextButton
│   │
│   └── AuditDetailPanel             ← sticky sidebar, conditional render
│       ├── DetailHeader
│       │   ├── DetailIcon           ← large 48px event icon
│       │   ├── DetailTitle + EventID
│       │   └── CloseButton
│       └── DetailContent            ← scrollable sections
│           ├── DetailSection[Event Details]
│           │   └── DetailGrid → DetailItem[] (timestamp, type, result, duration)
│           ├── DetailSection[Actor & Target]
│           │   └── DetailGrid → DetailItem[] (actor, target, org, IP)
│           ├── CrossReference       ← "View in QR Codes page →" link
│           ├── DetailSection[Device Information]
│           │   └── DetailGrid → DetailItem[] (device, OS, app ver, UA)
│           ├── DetailSection[Provisioning Details]
│           │   └── DetailGrid.full → DetailItem
│           └── JsonViewer           ← <pre> block with syntax-highlighted JSON
│
└── ToastProvider                    → BaseUI Toaster
```

## 2. TypeScript Types

```ts
// --- Event Types ---
type AuditEventType =
  | 'qr-generated'
  | 'qr-consumed'
  | 'qr-scanned'
  | 'qr-expired'
  | 'qr-revoked'
  | 'user-created'
  | 'user-terminated'
  | 'sso-enrolled'
  | 'config-change'
  | 'login';

type EventCategory = 'qr' | 'user' | 'auth' | 'config';
type TimeRange = 'today' | '7d' | '30d' | '90d' | 'custom';
type EventResult = 'success' | 'failure' | 'warning';

// --- Reference ID discriminated by prefix ---
type ReferenceId = `QR-${string}` | `TRM-${string}` | `USR-${string}` | `CFG-${string}` | `SES-${string}`;

// --- Core Event Model ---
interface AuditEvent {
  id: string;               // "AUD-2026-04521"
  eventType: AuditEventType;
  timestamp: string;         // ISO 8601
  title: string;             // "QR Code Consumed"
  description: string;       // "Provisioning completed on iPhone 15 Pro"
  actor: string;             // "Sarah Kim" | "System"
  target: string;            // "Alice Chen" | "Engineering" | "—"
  referenceId?: ReferenceId; // "QR-2026-0156"
  result: EventResult;
  durationMs?: number;       // 1200
  organization?: string;
  ipAddress?: string;
  device?: DeviceInfo;
  provisioning?: string[];   // ["xmpp", "sip", "sso"]
  qrId?: string;             // cross-ref to QR Codes page
  rawData: Record<string, unknown>; // full event JSON
}

interface DeviceInfo {
  model: string;       // "iPhone 15 Pro"
  os: string;          // "iOS 18.2"
  appVersion?: string; // "3.2.1 (456)"
  userAgent?: string;  // "Azblink/3.2.1 iOS/18.2"
}

// --- Pagination ---
interface PaginationState {
  page: number;
  pageSize: number;    // 20
  totalEvents: number; // 1247
  totalPages: number;  // 63
}

// --- Filter State ---
interface AuditFilters {
  timeRange: TimeRange;
  customDateRange?: { start: string; end: string };
  eventCategory: EventCategory | 'all';
  activeChips: Set<string>;  // toggled filter chip IDs
  searchQuery: string;
  qrIdFilter?: string;       // from URL param ?qr=
}
```

## 3. Event Type → Visual Config Map

Each event type maps to a distinct icon + color pair. Consumed from prototype CSS.

| Event Type | Icon | BG Token (Tailwind) | FG Token (Tailwind) | Prototype CSS Class |
|---|---|---|---|---|
| `qr-generated` | Plus (M12 6v6…) | `bg-blue-500/10` | `text-blue-500` | `.qr-generated` |
| `qr-consumed` | Check (M5 13l4 4L19 7) | `bg-green-500/10` | `text-green-500` | `.qr-consumed` |
| `qr-scanned` | QR grid icon | `bg-green-500/10` | `text-green-500` | `.qr-consumed` (reused) |
| `qr-expired` | Clock (M12 8v4l3 3…) | `bg-zinc-500/10` | `text-zinc-400` | `.qr-expired` |
| `qr-revoked` | Ban circle (M18.364…) | `bg-red-500/10` | `text-red-500` | `.qr-revoked` |
| `user-created` | User+ (M18 9v3…) | `bg-purple-500/10` | `text-purple-500` | `.user-created` |
| `user-terminated` | User- (M13 7…M21 12h-6) | `bg-red-500/10` | `text-red-500` | `.user-terminated` |
| `sso-enrolled` | Key (M15 7a2 2…) | `bg-cyan-500/10` | `text-cyan-500` | `.sso-enrolled` |
| `config-change` | Gear (M10.325…) | `bg-amber-500/10` | `text-amber-500` | `.config-change` |
| `login` | Login arrow (M11 16l-4-4…) | `bg-indigo-500/10` | `text-indigo-500` | `.login` |

Helper:

```ts
const EVENT_CONFIG: Record<AuditEventType, { icon: ComponentType; bgClass: string; fgClass: string }> = {
  'qr-generated':    { icon: PlusIcon,     bgClass: 'bg-blue-500/10',   fgClass: 'text-blue-500' },
  'qr-consumed':     { icon: CheckIcon,    bgClass: 'bg-green-500/10',  fgClass: 'text-green-500' },
  'qr-scanned':      { icon: QrCodeIcon,   bgClass: 'bg-green-500/10',  fgClass: 'text-green-500' },
  'qr-expired':      { icon: ClockIcon,    bgClass: 'bg-zinc-500/10',   fgClass: 'text-zinc-400' },
  'qr-revoked':      { icon: BanIcon,      bgClass: 'bg-red-500/10',    fgClass: 'text-red-500' },
  'user-created':    { icon: UserPlusIcon, bgClass: 'bg-purple-500/10', fgClass: 'text-purple-500' },
  'user-terminated': { icon: UserMinusIcon,bgClass: 'bg-red-500/10',    fgClass: 'text-red-500' },
  'sso-enrolled':    { icon: KeyIcon,      bgClass: 'bg-cyan-500/10',   fgClass: 'text-cyan-500' },
  'config-change':   { icon: CogIcon,      bgClass: 'bg-amber-500/10',  fgClass: 'text-amber-500' },
  'login':           { icon: LoginIcon,    bgClass: 'bg-indigo-500/10', fgClass: 'text-indigo-500' },
};
```

## 4. BaseUI Component Mapping

| Prototype Element | BaseUI Component | Props / Notes |
|---|---|---|
| `<select class="filter-select">` | `Select` | `size="compact"`, `options` array, `onChange` |
| Search input | `Input` | `startEnhancer={SearchIcon}`, `placeholder`, debounce 300ms |
| Export button | `Button` | `kind={KIND.secondary}`, `startEnhancer={DownloadIcon}` |
| Refresh button | `Button` | `kind={KIND.tertiary}`, icon-only, `shape={SHAPE.circle}` |
| Filter chips | Custom `ToggleChip` | Not a standard BaseUI component — build as button group |
| Pagination | Custom | BaseUI has no pagination — build with `Button` for page numbers |
| Detail close | `Button` | `kind={KIND.tertiary}`, `shape={SHAPE.circle}`, `size={SIZE.mini}` |
| Toast | `toaster.positive()` | From BaseUI `Toaster` |
| JSON viewer | `<pre>` + custom | Use `react-json-view-lite` or hand-rolled with Tailwind mono styling |

## 5. State Architecture

```ts
// --- Page-level state ---
const [events, setEvents] = useState<AuditEvent[]>([]);
const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
const [pagination, setPagination] = useState<PaginationState>({
  page: 1, pageSize: 20, totalEvents: 0, totalPages: 0
});
const [filters, setFilters] = useState<AuditFilters>({
  timeRange: '7d',
  eventCategory: 'all',
  activeChips: new Set(['qr-generated', 'qr-consumed', 'qr-expired', 'user-events']),
  searchQuery: '',
  qrIdFilter: undefined,
});

// --- Derived ---
const selectedEvent = useMemo(
  () => events.find(e => e.id === selectedEventId) ?? null,
  [events, selectedEventId]
);
const showDetailPanel = selectedEventId !== null;

// --- URL sync ---
// Read ?qr= on mount → set filters.qrIdFilter + filters.searchQuery
useEffect(() => {
  const qr = new URLSearchParams(location.search).get('qr');
  if (qr) setFilters(f => ({ ...f, qrIdFilter: qr, searchQuery: qr }));
}, []);
```

### Data Flow

```
URL ?qr=X ──→ filters.qrIdFilter ──→ FilterContextBanner (visible)
                                   ──→ searchQuery pre-filled
                                   ──→ rows with matching ref get .highlighted

TimeRangeSelect ──→ filters.timeRange ──→ API refetch
EventTypeSelect ──→ filters.eventCategory ──→ API refetch
FilterChips     ──→ filters.activeChips ──→ client-side row filter
SearchInput     ──→ filters.searchQuery (debounced) ──→ API refetch

AuditRow click  ──→ selectedEventId ──→ detail panel renders
ReferenceCell click ──→ router.push('/qr-codes?qr=${qrId}')
CrossReference click ──→ router.push('/qr-codes?qr=${qrId}')
```

## 6. Cross-Page Navigation Contract

### Audit Log → QR Codes

| Trigger | Action |
|---|---|
| Click `.audit-ref` with QR-prefixed ID | `router.push('/qr-codes?qr=${qrId}')` |
| Click `.cross-ref` in detail panel | `router.push('/qr-codes?qr=${qrId}')` |

### QR Codes → Audit Log

| Trigger | Action |
|---|---|
| "View in Audit Log" button on QR detail | `router.push('/audit-log?qr=${qrId}')` |
| Timeline "View full audit log" link | `router.push('/audit-log?qr=${qrId}')` |

### URL Parameter Contract

```
/audit-log?qr=QR-2026-0156
  → Shows FilterContextBanner with "Filtered by QR: QR-2026-0156"
  → Pre-fills search box
  → Highlights matching rows with blue bg

/qr-codes?qr=QR-2026-0156
  → Selects matching QR row
  → Opens detail panel
```

### Shared Reference ID Prefixes

| Prefix | Entity | Links To |
|---|---|---|
| `QR-` | QR Code | `/qr-codes?qr=` |
| `TRM-` | Termination | `/audit-log?ref=` (no cross-page, detail only) |
| `USR-` | User | `/users?id=` (future) |
| `CFG-` | Config | Non-linkable (detail only) |
| `SES-` | Session | Non-linkable (detail only) |

## 7. Key Interaction Behaviors

### Row Selection
- Click row → `setSelectedEventId(row.id)` → detail panel opens
- Selected row gets `border-left: 3px solid blue-500`, elevated background
- Only one row selected at a time
- Closing detail panel deselects

### QR ID Filter (URL-driven)
- On mount: parse `?qr=` → set filter state → highlight matching rows
- "Clear filter" button → remove URL param, clear highlights, reset search
- Highlighted rows get `bg-blue-500/10` independent of selection

### Filter Chips (Client-Side)
- Each chip toggles independently (Set add/delete)
- Active chip: `bg-blue-500/10 border-blue-500 text-blue-500`
- Inactive chip: `bg-zinc-800 border-zinc-700 text-zinc-400`
- Chips filter **client-side** within already-fetched page data

### Live Indicator
- Pulsing green dot (CSS animation, 2s infinite)
- Decorative only in Phase 1 — no WebSocket yet
- Phase 2: connect to SSE/WS, prepend new events to list

### Pagination
- Server-side pagination: page + pageSize sent as query params
- Active page: `bg-blue-500 text-white`
- Ellipsis button non-interactive
- Prev/Next disabled at bounds

### Search
- Debounced 300ms
- Sends to API as query param
- Clears qrIdFilter if user modifies search manually

## 8. Responsive Behavior

| Breakpoint | Layout Change |
|---|---|
| > 1100px | 2-col grid: table (1fr) + detail panel (380px) |
| ≤ 1100px | 1-col: detail panel moves below table or becomes a sheet/drawer |
| ≤ 900px | Filter bar wraps; chips move to second row |
| ≤ 768px | Table grid collapses: hide Actor + Reference columns; show in row expansion |
| ≤ 500px | Full mobile: filter selects stack vertically; pagination simplified (prev/next only) |

### Table Column Visibility

```ts
// Responsive column config
const COLUMNS = [
  { key: 'timestamp',  label: 'Timestamp',  minWidth: 0 },    // always visible
  { key: 'event',      label: 'Event',      minWidth: 0 },    // always visible
  { key: 'actor',      label: 'Actor',      minWidth: 768 },  // hidden < 768
  { key: 'target',     label: 'Target',     minWidth: 768 },  // hidden < 768
  { key: 'reference',  label: 'Reference',  minWidth: 900 },  // hidden < 900
];
```

## 9. Stripped Elements Reference

Elements removed from prototype → content-only HTML:

| Element | Prototype Lines | Reason |
|---|---|---|
| Sidebar (`<aside class="sidebar">`) | 439–527 | App shell — provided by layout |
| Topbar (`<header class="topbar">`) | 531–558 | App shell — page header extracted as component |
| `.app-container` wrapper | 437, 1043 | App shell flex container |
| Theme CSS variables (`:root`) | 11–48 | Replaced by Tailwind config |
| Font imports (Google Fonts) | 7–9 | Handled by app-level `<head>` |
| Body/global resets | 50–58 | App-level CSS |
| Sidebar CSS | 62–108 | App shell |
| `.main-content` CSS | 110 | App shell |
| Topbar CSS | 112–119 | App shell |
| Color-bearing CSS properties | Throughout | Mapped to Tailwind classes in Section 3 |
| Scrollbar CSS | 402–406 | App-level global styles |

## 10. Shared Components (with QR Codes Page)

These components are identical or near-identical across both pages and should be extracted to a shared `/components/` directory:

| Component | Used In | Notes |
|---|---|---|
| `SearchInput` | QR Codes header, Audit Log header | Same BaseUI Input config |
| `StatusBadge` / `EventIcon` | QR status badges, Audit event icons | Same color token map |
| `DetailSection` | QR detail panel, Audit detail panel | Same section title + grid layout |
| `DetailItem` | Both detail panels | Same label/value pair with mono variant |
| `CrossReference` | Audit detail → QR page | One-way currently, but pattern is reusable |
| `JsonViewer` | Audit detail raw data | Could be reused for QR raw config |
| `ToastProvider` | Both pages | Single app-level provider |
| `Pagination` | Audit Log only (QR page uses virtual scroll) | Standalone component |
| Button variants | Both pages | BaseUI Button with consistent kind/size mapping |

## 11. Migration Phases

### Phase 1: Scaffold (Day 1)
- [ ] Create `AuditLogPage.tsx` with route `/audit-log`
- [ ] Wire URL param parsing (`?qr=`)
- [ ] Set up `@tanstack/react-query` for event fetching
- [ ] Stub all state (filters, selection, pagination)

### Phase 2: Table (Day 1–2)
- [ ] `AuditFilterBar` with BaseUI Select + custom FilterChips
- [ ] `AuditTable` with grid layout matching 5-col spec
- [ ] `AuditRow` with EventIcon color mapping
- [ ] Row click → selection state
- [ ] Pagination controls

### Phase 3: Detail Panel (Day 2–3)
- [ ] `AuditDetailPanel` with sticky positioning
- [ ] `DetailSection` / `DetailItem` (extract shared with QR page)
- [ ] `CrossReference` component with router navigation
- [ ] `JsonViewer` with syntax highlighting
- [ ] Close button deselects row

### Phase 4: Filters & Search (Day 3)
- [ ] `SearchInput` with debounce
- [ ] `FilterContextBanner` with URL-driven QR filter
- [ ] Filter chips toggle → client-side filtering
- [ ] Time range / event type selects → API refetch
- [ ] `LiveIndicator` (decorative)

### Phase 5: Cross-Page & Polish (Day 4)
- [ ] Wire bidirectional navigation (Audit ↔ QR Codes)
- [ ] Row highlighting for URL-filtered results
- [ ] Export button → API call + toast feedback
- [ ] Responsive breakpoints (table column hiding, grid collapse)
- [ ] Keyboard navigation: arrow keys for row selection, Escape to close panel
- [ ] `data-testid` attributes from `data-component` annotations

## 12. Differences from QR Codes Page

| Aspect | QR Codes Page | Audit Log Page |
|---|---|---|
| **Data model** | QR codes with status lifecycle | Heterogeneous events (9+ types) |
| **Table columns** | 5 (user, status, device, created, actions) | 5 (timestamp, event, actor, target, ref) |
| **Row identity** | QR ID (`QR-2026-XXXX`) | Event ID (`AUD-2026-XXXXX`) |
| **Filtering** | Tab-based status filter | Multi-axis: time + category + chips + search |
| **Pagination** | No (virtual scroll candidate) | Yes, server-side 20/page |
| **Detail panel** | QR preview + provisioning checklist | Event JSON + cross-reference + device |
| **Stats row** | Yes (4 stat cards) | No |
| **Live updates** | No | Yes (indicator, future WebSocket) |
| **URL contract** | `?qr=` (inbound from Audit) | `?qr=` (inbound from QR Codes) |
| **Primary action** | Generate QR modal | Export (download) |
| **Color palette** | 4 status colors | 10 event type colors |
