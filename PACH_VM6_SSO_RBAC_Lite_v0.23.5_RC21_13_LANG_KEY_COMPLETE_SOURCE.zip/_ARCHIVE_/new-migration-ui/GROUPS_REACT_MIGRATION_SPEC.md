# Group Management — React Migration Spec

> **Target stack**: React 18+ · BaseUI (Uber) · Tailwind CSS · Lucide icons  
> **Source**: `groups-content-only.html` (layout-stripped prototype)  
> **Assumption**: Host app provides sidebar, topbar, routing, auth context, and toast system.

---

## 1. Component Tree

```
<GroupManagementPage>                       ← route-level page component
├── <PageHeader />                          ← title + search + "Create Group" CTA
│   ├── <SearchInput />                     ← BaseUI Input w/ ⌘K shortcut
│   └── <Button>Create Group</Button>       ← BaseUI Button
│
├── <GroupsGrid>                            ← CSS Grid split-panel (1fr 420px)
│   ├── <GroupList>                          ← left panel
│   │   ├── <ListHeader />                  ← count + filter tabs
│   │   │   └── <FilterTabs />              ← BaseUI SegmentedControl
│   │   └── <GroupRow />[]                  ← virtualized list (react-window)
│   │       ├── <GroupTypeIcon />           ← colored icon per type
│   │       ├── <GroupMeta />               ← name + description
│   │       ├── <MemberCount />             ← icon + count
│   │       └── <GroupTypeBadge />          ← security/distribution/department/project
│   │
│   └── <GroupDetailPanel>                  ← right panel
│       ├── <PanelHeader />                 ← large icon, name, subtitle, Edit + Delete
│       ├── <GroupDetailsSection />         ← 2×2 info grid (DN, type, created, modified)
│       │   └── <InfoItem />[]             ← label + value card
│       ├── <MembersSection />             ← member list + add button
│       │   ├── <MemberItem />[]           ← avatar, name, email, role badge, remove
│       │   └── <AddMemberButton />        ← dashed border CTA
│       └── <PermissionsSection />         ← permission toggles
│           └── <PermissionItem />[]       ← icon + name + desc + toggle
│
├── <CreateGroupModal />                    ← BaseUI Modal
│   ├── <FormField label="Group Name" />   ← BaseUI Input
│   ├── <FormField label="Description" />  ← BaseUI Input
│   ├── <FormField label="Group Type" />   ← BaseUI Select
│   └── <FormField label="Parent Org" />   ← BaseUI Select
│
└── <AddMembersModal />                     ← BaseUI Modal
    ├── <SearchInput />                     ← filter user list
    └── <SelectableUserList />             ← checkbox list
        └── <SelectableUserItem />[]       ← avatar + info + Checkbox
```

---

## 2. Component → BaseUI + Tailwind Mapping

| Prototype Element | React Component | BaseUI Primitive | Tailwind Notes |
|---|---|---|---|
| `.search-box` | `<SearchInput />` | `Input` w/ `startEnhancer` (icon) + `endEnhancer` (kbd) | `w-65` fixed, ring on focus |
| `.filter-tabs` | `<FilterTabs />` | `SegmentedControl` or `ButtonGroup` | `bg-surface-tertiary p-1 rounded-lg` |
| `.group-row` | `<GroupRow />` | Custom `<li>` (needs click + selection + left-border) | `hover:bg-surface-tertiary` + `border-l-3 border-accent-primary` when selected |
| `.group-type-badge` | `<GroupTypeBadge />` | `Tag` with `KIND.custom` | Map type→color: `security`=danger, `distribution`=primary, `department`=purple, `project`=success |
| `.group-icon` | `<GroupTypeIcon />` | Custom div (no BaseUI equiv) | `w-10 h-10 rounded-lg flex items-center justify-center` + type→bg/fg color |
| `.panel-icon` | Same pattern, larger | — | `w-14 h-14 rounded-xl` |
| `.info-item` | `<InfoItem />` | Custom card | `bg-surface-tertiary rounded-lg p-3` |
| `.info-value.mono` | — | — | `font-mono text-xs` |
| `.member-item` | `<MemberItem />` | Custom row (needs hover-reveal remove button) | `hover:bg-surface-overlay group` |
| `.member-role` | — | `Tag` with `KIND.custom` | `owner`=amber, `admin`=purple, `member`=default |
| `.member-remove` | — | `Button` `kind={KIND.tertiary}` `size={SIZE.mini}` | `opacity-0 group-hover:opacity-100` |
| `.member-avatar` | — | `Avatar` with `overrides` for gradient bg | Use `name` prop for initials |
| `.add-member-btn` | `<AddMemberButton />` | Custom button (dashed border pattern) | `border-dashed border-border-default hover:border-accent-primary hover:bg-accent-primary/10` |
| `.toggle` | — | `Checkbox` with `checkmarkType={STYLE_TYPE.toggle}` | Green when checked |
| `.permission-icon` | — | Custom div | `w-8 h-8 rounded-md` + `granted`=success, `denied`=danger |
| `.btn-primary` | — | `Button` `kind={KIND.primary}` | — |
| `.btn-secondary` | — | `Button` `kind={KIND.secondary}` | — |
| `.btn-danger` | — | `Button` `kind={KIND.tertiary}` + danger overrides | `bg-danger/10 text-danger hover:bg-danger/20` |
| `.btn-ghost` | — | `Button` `kind={KIND.tertiary}` | — |
| `.modal-overlay` | — | `Modal` with `ROLE.dialog` | Backdrop blur via `overrides.Backdrop` |
| `.form-input` | — | `Input` | — |
| `.form-select` | — | `Select` | — |
| Toast system | — | `toaster` from BaseUI (or host app's) | — |

---

## 3. State Architecture

### 3.1 Page-level State

```typescript
// URL state (query params or route)
interface GroupManagementRoute {
  filter: 'all' | 'security' | 'distribution' | 'department' | 'project';
  groupId?: string;         // selected group → detail panel
  search?: string;          // search query
}

// Server state (react-query / SWR)
interface GroupListQuery {
  queryKey: ['groups', { filter, search, page }];
  // GET /api/admin/groups?type={filter}&q={search}
}

interface GroupDetailQuery {
  queryKey: ['group', groupId];
  // GET /api/admin/groups/{groupId}
  // includes: members[], permissions[], metadata
}
```

### 3.2 Modal State Machine

```
                  ┌──────────┐
            ┌────►│  closed  │◄───────────────────┐
            │     └────┬─────┘                    │
            │          │ openCreate()              │ close()
            │          ▼                           │
            │     ┌──────────┐                ┌───┴────────┐
            │     │ create   │                │ create     │
            │     │ _group   │                │ _group     │
            │     └──────────┘                └────────────┘
            │
            │     openAddMembers(groupId)
            │          │
            │          ▼
            │     ┌──────────────┐
            └─────┤ add_members  │
                  └──────────────┘
```

```typescript
type ModalState =
  | { type: 'closed' }
  | { type: 'create_group' }
  | { type: 'add_members'; groupId: string; groupName: string };
```

### 3.3 Permission Toggle (Optimistic Update)

```typescript
// Mutation: PATCH /api/admin/groups/{groupId}/permissions
interface UpdatePermissionMutation {
  input: {
    permission: string;   // e.g. 'user_management'
    enabled: boolean;
  };
}

// Optimistic: toggle in cache immediately, rollback on error
// Invalidates: ['group', groupId]
```

---

## 4. API Contracts

### 4.1 Groups List

```typescript
// GET /api/admin/groups?type={filter}&q={search}&page={n}
interface GroupListResponse {
  groups: Array<{
    id: string;
    name: string;
    description: string;
    type: 'security' | 'distribution' | 'department' | 'project';
    memberCount: number;
    dn: string;
  }>;
  total: number;
  page: number;
  pageSize: number;
}
```

### 4.2 Group Detail

```typescript
// GET /api/admin/groups/{groupId}
interface GroupDetailResponse {
  id: string;
  name: string;
  description: string;
  type: 'security' | 'distribution' | 'department' | 'project';
  dn: string;                              // LDAP distinguished name
  parentOrg: string | null;
  createdAt: string;                       // ISO timestamp
  modifiedAt: string;                      // ISO timestamp
  members: Array<{
    id: string;
    name: string;
    email: string;
    initials: string;
    avatarGradient: [string, string];      // or computed from name hash
    role: 'owner' | 'admin' | 'member';
  }>;
  permissions: Array<{
    key: string;                           // 'user_management' | 'qr_provisioning' | 'audit_log' | 'system_config'
    name: string;
    description: string;
    enabled: boolean;
  }>;
}
```

### 4.3 Create Group

```typescript
// POST /api/admin/groups
interface CreateGroupMutation {
  input: {
    name: string;                           // required
    description: string;
    type: 'security' | 'distribution' | 'department' | 'project';
    parentOrgId: string | null;
  };
  output: {
    id: string;
    dn: string;
  };
}
// Invalidates: ['groups']
```

### 4.4 Add Members

```typescript
// POST /api/admin/groups/{groupId}/members
interface AddMembersMutation {
  input: {
    userIds: string[];                     // batch add
  };
  output: {
    added: number;
    skipped: number;                       // already in group
  };
}
// Invalidates: ['group', groupId]
```

### 4.5 Remove Member

```typescript
// DELETE /api/admin/groups/{groupId}/members/{userId}
// Invalidates: ['group', groupId]
```

### 4.6 Update Permission

```typescript
// PATCH /api/admin/groups/{groupId}/permissions
interface UpdatePermissionMutation {
  input: {
    permission: string;
    enabled: boolean;
  };
}
// Optimistic update → rollback on failure
```

### 4.7 Delete Group

```typescript
// DELETE /api/admin/groups/{groupId}
// Requires confirmation in UI before calling
// Invalidates: ['groups'], removes ['group', groupId] from cache
```

### 4.8 Search Users (for Add Members modal)

```typescript
// GET /api/admin/users/search?q={query}&excludeGroup={groupId}
interface UserSearchResponse {
  users: Array<{
    id: string;
    name: string;
    email: string;
    initials: string;
    avatarGradient: [string, string];
  }>;
}
```

---

## 5. Token Contract (Tailwind ↔ App Theme)

The content-only HTML uses `--grp-*` CSS custom properties. Map to your existing design system:

```javascript
// tailwind.config.js — extend theme
module.exports = {
  theme: {
    extend: {
      colors: {
        'grp-text-primary':    'var(--your-text-primary)',
        'grp-text-secondary':  'var(--your-text-secondary)',
        'grp-text-muted':      'var(--your-text-muted)',
        'grp-surface':         'var(--your-bg-surface)',
        'grp-surface-raised':  'var(--your-bg-surface-raised)',
        'grp-surface-tertiary':'var(--your-bg-surface-tertiary)',
        'grp-surface-overlay': 'var(--your-bg-surface-overlay)',
        'grp-border-subtle':   'var(--your-border-subtle)',
        'grp-border-default':  'var(--your-border-default)',
        'grp-accent-primary':  'var(--your-accent-primary)',
        'grp-danger':          'var(--your-danger)',
        'grp-success':         'var(--your-success)',
        'grp-warning':         'var(--your-warning)',
        'grp-purple':          'var(--your-purple)',
      }
    }
  }
};
```

**Or** skip the indirection — use existing Tailwind utilities directly. The `--grp-*` tokens exist solely as a reference map.

**Group type → color mapping** (critical for consistency across components):

| Type | Icon bg | Icon fg | Badge bg | Badge fg | Tailwind class prefix |
|---|---|---|---|---|---|
| `security` | `danger/10` | `danger` | `danger/10` | `danger` | `text-red-500 bg-red-500/10` |
| `distribution` | `primary/10` | `primary` | `primary/10` | `primary` | `text-blue-500 bg-blue-500/10` |
| `department` | `purple/10` | `purple` | `purple/10` | `purple` | `text-purple-500 bg-purple-500/10` |
| `project` | `success/10` | `success` | `success/10` | `success` | `text-green-500 bg-green-500/10` |

Extract to a `GROUP_TYPE_STYLES` constant map:

```typescript
// constants.ts
export const GROUP_TYPE_STYLES = {
  security:     { bg: 'bg-red-500/10',    fg: 'text-red-500',    label: 'Security' },
  distribution: { bg: 'bg-blue-500/10',   fg: 'text-blue-500',   label: 'Distribution' },
  department:   { bg: 'bg-purple-500/10',  fg: 'text-purple-500', label: 'Department' },
  project:      { bg: 'bg-green-500/10',  fg: 'text-green-500',  label: 'Project' },
} as const;

export const MEMBER_ROLE_STYLES = {
  owner:  { bg: 'bg-amber-500/10',  fg: 'text-amber-500',  label: 'Owner' },
  admin:  { bg: 'bg-purple-500/10', fg: 'text-purple-500', label: 'Admin' },
  member: { bg: 'bg-zinc-700',      fg: 'text-zinc-400',   label: 'Member' },
} as const;
```

---

## 6. Integration Checklist

### What the host app provides (don't rebuild):
- [ ] Sidebar navigation
- [ ] Top-level layout shell
- [ ] Auth context (current admin user)
- [ ] Toast/notification system
- [ ] Routing (`/admin/groups`, `/admin/groups/:id`)
- [ ] API client configuration (base URL, auth headers)
- [ ] Modal portal root

### What this feature owns:
- [ ] `<GroupManagementPage />` — route component
- [ ] All child components in the tree above
- [ ] Keyboard shortcut registration (`⌘K` → search, `Esc` → close modals)
- [ ] Data fetching for group list + detail + user search
- [ ] Optimistic permission toggle updates

---

## 7. BaseUI Override Patterns

```tsx
// Modal — backdrop blur
<Modal overrides={{
  Backdrop: { style: { backdropFilter: 'blur(4px)' } },
  Dialog: { style: ({ $theme }) => ({
    borderRadius: $theme.borders.radius400,
    border: `1px solid ${$theme.colors.borderOpaque}`,
  })},
}}>

// SegmentedControl — filter tabs
<SegmentedControl overrides={{
  Root: { style: { backgroundColor: 'var(--surface-tertiary)' } },
  Active: { style: { backgroundColor: 'var(--surface-overlay)', boxShadow: '0 1px 2px rgba(0,0,0,0.3)' } },
}}>

// Input — search
<Input
  startEnhancer={<SearchIcon size={18} />}
  endEnhancer={<Kbd>⌘K</Kbd>}
  overrides={{
    Root: { style: { width: '260px' } },
  }}
/>

// Select — group type (Create Group modal)
<Select
  options={[
    { label: 'Security Group', id: 'security' },
    { label: 'Distribution List', id: 'distribution' },
    { label: 'Department', id: 'department' },
    { label: 'Project Team', id: 'project' },
  ]}
/>

// Checkbox toggle — permissions
<Checkbox
  checked={permission.enabled}
  checkmarkType={STYLE_TYPE.toggle}
  onChange={handlePermissionToggle}
  overrides={{
    Toggle: { style: ({ $checked }) => ({
      backgroundColor: $checked ? 'var(--success)' : 'var(--surface-overlay)',
    })},
  }}
/>
```

---

## 8. Critical Behaviors to Preserve

| Behavior | Implementation Note |
|---|---|
| **Selected group = URL state** | `groupId` in route params → detail panel renders. Deep-linkable. |
| **Filter tabs = URL state** | `?filter=security` → tab active + list filtered server-side. |
| **⌘K → focus search** | `useEffect` with `keydown` listener. Dedupe with host app's command palette if one exists. |
| **Esc → close modals** | BaseUI Modal handles natively. |
| **Hover-reveal remove button** | `member-remove` is `opacity-0` → `group-hover:opacity-100`. Only appears on row hover. |
| **Permission toggle = optimistic** | Toggle switch immediately, PATCH in background, rollback on failure. Permission icon (granted/denied) must also flip. |
| **Add Members = debounced search** | Search input in modal → 300ms debounce → `GET /api/admin/users/search?q=...&excludeGroup={groupId}` |
| **Checkbox selection in modal** | Track `selectedUserIds: Set<string>` as local modal state. "Add Selected" disabled when empty. |
| **Delete group = confirmation** | Use `window.confirm()` or a confirmation dialog before `DELETE`. Never one-click. |
| **DN display = monospace** | The `info-value.mono` class → `font-family: 'JetBrains Mono'` / `font-mono`. |

---

## 9. File Structure

```
src/features/group-management/
├── GroupManagementPage.tsx            ← route entry, layout grid
├── components/
│   ├── PageHeader.tsx
│   ├── SearchInput.tsx                ← shared w/ user-management (extract to shared/)
│   ├── GroupList/
│   │   ├── GroupList.tsx              ← virtualized list container
│   │   ├── GroupRow.tsx
│   │   ├── GroupTypeIcon.tsx          ← colored icon per type
│   │   ├── GroupTypeBadge.tsx         ← colored pill per type
│   │   └── FilterTabs.tsx            ← shared pattern w/ user-management
│   ├── GroupDetail/
│   │   ├── GroupDetailPanel.tsx
│   │   ├── PanelHeader.tsx
│   │   ├── GroupDetailsSection.tsx    ← 2×2 info grid
│   │   ├── InfoItem.tsx              ← label + value card
│   │   ├── MembersSection.tsx        ← member list + add CTA
│   │   ├── MemberItem.tsx            ← avatar + info + role + remove
│   │   ├── AddMemberButton.tsx       ← dashed border CTA
│   │   ├── PermissionsSection.tsx    ← toggle list
│   │   └── PermissionItem.tsx        ← icon + name + desc + toggle
│   └── Modals/
│       ├── CreateGroupModal.tsx
│       └── AddMembersModal.tsx
│           └── SelectableUserItem.tsx
├── hooks/
│   ├── useGroups.ts                  ← react-query: list + detail
│   ├── useGroupMutations.ts          ← create, delete, add/remove members
│   ├── usePermissions.ts             ← optimistic toggle mutation
│   ├── useUserSearch.ts              ← debounced search for add-member modal
│   └── useKeyboardShortcuts.ts       ← shared w/ user-management
├── types.ts                          ← Group, Member, Permission, GroupType
└── constants.ts                      ← GROUP_TYPE_STYLES, MEMBER_ROLE_STYLES, FILTER_OPTIONS
```

### Shared components (extract to `src/shared/`):

| Component | Used By |
|---|---|
| `SearchInput` | GroupManagement, UserManagement |
| `FilterTabs` | GroupManagement, UserManagement |
| `InfoItem` | GroupDetailPanel, UserDetailPanel |
| `useKeyboardShortcuts` | Both pages |

---

## 10. Migration Order

| Phase | Components | Depends On |
|---|---|---|
| **1. Shell** | `GroupManagementPage`, `PageHeader`, `SearchInput` | Host app layout + routing |
| **2. List** | `GroupList`, `GroupRow`, `GroupTypeIcon`, `GroupTypeBadge`, `FilterTabs` | `useGroups` hook, groups API |
| **3. Detail: Metadata** | `GroupDetailPanel`, `PanelHeader`, `GroupDetailsSection`, `InfoItem` | Group detail API |
| **4. Detail: Members** | `MembersSection`, `MemberItem`, `AddMemberButton` | Group detail API (members array) |
| **5. Detail: Permissions** | `PermissionsSection`, `PermissionItem` (with toggle) | Permissions PATCH API |
| **6. Create Group** | `CreateGroupModal` | Create group POST API |
| **7. Add Members** | `AddMembersModal`, `SelectableUserItem`, `useUserSearch` | User search API, add members API |
| **8. Polish** | Keyboard shortcuts, optimistic updates, delete confirmation, toast integration | All above |

Ship phases 1-4 first for visibility. Phases 5-7 unlock mutations. Phase 8 is UX polish.

---

## 11. Cross-Feature Relationships

```
┌─────────────────────┐       ┌─────────────────────┐
│  User Management    │       │  Group Management   │
│  (qr-admin)         │       │  (groups)           │
│                     │       │                     │
│  UserDetailPanel    │──────►│  "Member of" link   │  ← User's groups shown in user detail
│                     │       │                     │
│  TerminationModal   │──────►│  Auto-remove from   │  ← Terminated user removed from groups
│                     │       │  all groups         │
│                     │       │                     │
│  QR Provisioning    │◄──────│  Permissions toggle │  ← Group permissions gate QR access
└─────────────────────┘       └─────────────────────┘
```

Groups control who can do what in the system. The `qr_provisioning` permission toggle on a security group directly affects which admins can generate QR codes in the User Management page. This means:

1. **Permission changes should invalidate user session cache** — if an admin loses `qr_provisioning` permission mid-session, the QR Generation button should become disabled.
2. **User termination should cascade** — the termination API should handle group membership cleanup server-side, but the Groups UI should reflect the change via cache invalidation.
3. **"Member of" in User Detail** — the user detail panel (from the QR admin spec) should show which groups a user belongs to, with links to the group detail panel.
