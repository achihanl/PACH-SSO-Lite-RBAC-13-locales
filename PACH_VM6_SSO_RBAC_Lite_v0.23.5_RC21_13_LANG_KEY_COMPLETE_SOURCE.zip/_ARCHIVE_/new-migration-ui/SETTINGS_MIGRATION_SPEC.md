# Settings — React Migration Spec

## 1. Page Layout (ASCII)

Only page in the system using **sticky sidebar nav + vertically scrolling sections**.
No master-detail, no table, no cards — pure form-driven settings with
IntersectionObserver-powered scroll-spy.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Settings                                    [Reset to Defaults] [Save All]│
├──────────────────────────────────────────────────────────────────────────────┤
│                                                        max-width: 1200px   │
│  ┌──────────────┐  ┌──────────────────────────────────────────────────────┐│
│  │               │  │ ┌────────────────────────────────────────────────┐  ││
│  │ ● LDAP  ◄────┤  │ │  LDAP Connection                   ● Connected│  ││
│  │ ○ Email      │  │ │  Configure the connection...   [Test Connection]│  ││
│  │ ○ Security   │  │ ├────────────────────────────────────────────────┤  ││
│  │ ○ Audit      │  │ │  ┌─────────────┐  ┌─────────────┐            │  ││
│  │ ○ API Keys   │  │ │  │ LDAP Server │  │ Base DN     │            │  ││
│  │ ○ Admins     │  │ │  └─────────────┘  └─────────────┘            │  ││
│  │ ○ Branding   │  │ │  ┌─────────────┐  ┌─────────────┐            │  ││
│  │ ○ Danger     │  │ │  │ Bind DN     │  │ Bind Pass   │            │  ││
│  │               │  │ │  └─────────────┘  └─────────────┘            │  ││
│  │  sticky       │  │ │                                              │  ││
│  │  top: 88px    │  │ │  ┌────────────────────────────────────────┐  │  ││
│  │               │  │ │  │ Verify SSL Certificate          [═══] │  │  ││
│  │  240px        │  │ │  │ Enable Connection Pooling       [═══] │  │  ││
│  │               │  │ │  └────────────────────────────────────────┘  │  ││
│  │               │  │ └────────────────────────────────────────────────┘  ││
│  │               │  │                                                     ││
│  │               │  │ ┌────────────────────────────────────────────────┐  ││
│  │               │  │ │  Email / SMTP               [Send Test Email] │  ││
│  │               │  │ │  ...                                          │  ││
│  │               │  │ └────────────────────────────────────────────────┘  ││
│  │               │  │                                                     ││
│  │               │  │ ┌────────────────────────────────────────────────┐  ││
│  │               │  │ │  Security                                     │  ││
│  │               │  │ │  ...                                          │  ││
│  │               │  │ └────────────────────────────────────────────────┘  ││
│  │               │  │                                                     ││
│  │               │  │ ┌────────────────────────────────────────────────┐  ││
│  │               │  │ │  Audit & Logging                              │  ││
│  │               │  │ │  ...                                          │  ││
│  │               │  │ └────────────────────────────────────────────────┘  ││
│  │               │  │                                                     ││
│  │               │  │ ┌────────────────────────────────────────────────┐  ││
│  │               │  │ │  API Keys                  [+ Generate New Key]│  ││
│  │               │  │ │  ...                                          │  ││
│  │               │  │ └────────────────────────────────────────────────┘  ││
│  │               │  │                                                     ││
│  │               │  │ ┌────────────────────────────────────────────────┐  ││
│  │               │  │ │  Administrators               [+ Invite Admin]│  ││
│  │               │  │ │  ...                                          │  ││
│  │               │  │ └────────────────────────────────────────────────┘  ││
│  │               │  │                                                     ││
│  │               │  │ ┌────────────────────────────────────────────────┐  ││
│  │               │  │ │  Branding                                     │  ││
│  │               │  │ │  ...                                          │  ││
│  │               │  │ └────────────────────────────────────────────────┘  ││
│  │               │  │                                                     ││
│  │               │  │ ┌────────────────────────────────────────────────┐  ││
│  │               │  │ │  ⚠ Danger Zone                                │  ││
│  │               │  │ │  ...                                          │  ││
│  │               │  │ └────────────────────────────────────────────────┘  ││
│  └──────────────┘  └──────────────────────────────────────────────────────┘│
│      240px                              1fr                                │
└────────────────────────────────────────────────────────────────────────────┘
```

## 2. Settings Section Anatomy (ASCII)

Every section follows the same skeleton. This is the reusable `SettingsSection` component.

```
┌──────────────────────────────────────────────────────────────────────┐
│  SECTION HEADER                                                      │
│  ┌──────────────────────────────────┐  ┌──────────────────────────┐ │
│  │  Title (16px semibold)           │  │  Header Actions          │ │
│  │  Description (13px muted)        │  │  (status, test btn, etc) │ │
│  └──────────────────────────────────┘  └──────────────────────────┘ │
│──────────────────────────────── border ─────────────────────────────│
│  SECTION BODY (padding: 24px)                                        │
│                                                                      │
│  ┌───────────────────┐  ┌───────────────────┐   ← form-row (2-col) │
│  │  Form Group       │  │  Form Group       │                       │
│  │  Label            │  │  Label            │                       │
│  │  [Input/Select]   │  │  [Input/Select]   │                       │
│  │  Hint text        │  │  Hint text        │                       │
│  └───────────────────┘  └───────────────────┘                       │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────────┐ │
│  │  Toggle Label                                           [═══] │ │  ← toggle-row
│  │  Toggle description text                                      │ │
│  └────────────────────────────────────────────────────────────────┘ │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

## 3. Unique UI Patterns (ASCII)

### 3a. Retention Radio Cards (Audit section)

```
┌─────────────────────────────────────────────────────┐
│  (●) 90 Days                                         │  ← .selected: blue border + blue bg
│      Standard retention for compliance requirements  │
├─────────────────────────────────────────────────────┤
│  ( ) 1 Year                                          │  ← default: subtle border
│      Extended retention for audit requirements       │
├─────────────────────────────────────────────────────┤
│  ( ) Forever                                         │
│      Never delete audit logs (storage costs apply)   │
└─────────────────────────────────────────────────────┘

Radio state:
  (●) selected → border: blue-500, bg: blue-500/10, inner dot: blue-500 opacity:1
  ( ) default  → border: zinc-600, bg: transparent, inner dot: opacity:0
```

### 3b. API Key Display

```
┌──────────────────────────────────────────────────────────────────┐
│  ak_live_7f4d8e9a2b1c3d5e6f7g8h9i0j••••••••••••    [📋] [🗑]  │
│                                                      copy revoke│
└──────────────────────────────────────────────────────────────────┘
  Created: Jan 15, 2026 by Sarah Kim          Last used: Feb 1, 2026
```

### 3c. Admin List Item

```
┌──────────────────────────────────────────────────────────────────┐
│  ┌────┐                                                          │
│  │ SK │  Sarah Kim                                      OWNER   │
│  └────┘  sarah.kim@example.com                          (amber) │
│  avatar                                                          │
│  (gradient)                                                      │
├──────────────────────────────────────────────────────────────────┤
│  ┌────┐                                                          │
│  │ MD │  Mark Davis                                     ADMIN   │
│  └────┘  mark.davis@example.com                         (blue)  │
└──────────────────────────────────────────────────────────────────┘
```

### 3d. Danger Zone Card

```
┌──────────────────────────────────────────────────────────────────┐
│  border: 1px solid red-500/30                                    │
│                                                                  │
│  🗑  Purge All QR Codes                                         │
│                                                                  │
│  This will invalidate all pending QR codes and clear the QR      │
│  history. Users with pending codes will need new ones generated. │
│                                                                  │
│  [Purge All QR Codes]  ← btn-danger                             │
└──────────────────────────────────────────────────────────────────┘
```

### 3e. Status Indicator

```
  ┌────────────────┐
  │ ✓ Connected    │  ← healthy:  green bg/text
  └────────────────┘
  ┌────────────────┐
  │ ⚠ Degraded     │  ← warning:  amber bg/text
  └────────────────┘
  ┌────────────────┐
  │ ✗ Disconnected │  ← error:    red bg/text
  └────────────────┘
```

## 4. Responsive Collapse (ASCII)

```
DESKTOP (>800px):                         MOBILE (≤800px):
┌──────────┬─────────────────┐            ┌───────────────────────────┐
│  Nav     │   Sections      │            │  [LDAP] [Email] [Sec] ▶  │  ← horizontal scroll
│  240px   │   (scrolling)   │            │  (overflow-x: auto)      │
│  sticky  │                 │            ├───────────────────────────┤
│          │                 │            │  Sections (full width)    │
│          │                 │            │                           │
│          │                 │            │  form-row → 1fr (stacked) │
└──────────┴─────────────────┘            └───────────────────────────┘
```

## 5. Component Tree

```
SettingsPage/
├── SettingsPageHeader
│   ├── PageTitle ("Settings")
│   └── HeaderActions
│       ├── ResetDefaultsButton      → BaseUI Button KIND.secondary
│       └── SaveAllButton            → BaseUI Button KIND.primary
│
├── SettingsLayout                    ← CSS Grid: 240px 1fr, max-w 1200px
│   ├── SettingsNav                   ← sticky sidebar
│   │   └── SettingsNavItem[]         ← 8 items with icons
│   │       ├── NavIcon (SVG)
│   │       └── NavLabel
│   │
│   └── SettingsContent               ← vertical section stack
│       ├── LdapSection
│       │   ├── SectionHeader
│       │   │   ├── TitleBlock (title + desc)
│       │   │   ├── StatusIndicator   ← healthy | warning | error
│       │   │   └── TestButton        ← dashed border action
│       │   └── SectionBody
│       │       ├── FormRow[] (serverUrl, baseDn, bindDn, bindPassword, etc.)
│       │       │   └── FormGroup[]   → BaseUI FormControl + Input
│       │       └── ToggleRow[] (verifySsl, connectionPooling)
│       │
│       ├── EmailSection
│       │   ├── SectionHeader (title + TestEmailButton)
│       │   └── SectionBody
│       │       ├── FormRow[] (smtpHost, smtpPort, username, password, from*)
│       │       │   └── FormGroup[]   → BaseUI FormControl + Input/Select
│       │       └── ToggleRow (useTls)
│       │
│       ├── SecuritySection
│       │   ├── SectionHeader (title only)
│       │   └── SectionBody
│       │       ├── FormRow (sessionTimeout, maxLoginAttempts)
│       │       │   └── FormGroup[]   → BaseUI FormControl + Select
│       │       └── ToggleRow[] (requireMfa, ipAllowlist, auditApiRequests)
│       │
│       ├── AuditSection
│       │   ├── SectionHeader (title only)
│       │   └── SectionBody
│       │       ├── RetentionGroup
│       │       │   └── RetentionOption[] (90d, 1yr, forever)
│       │       │       ├── RadioIndicator
│       │       │       └── RetentionInfo (title + desc)
│       │       └── ToggleRow[] (siemExport, includeUserDetails)
│       │
│       ├── ApiKeysSection
│       │   ├── SectionHeader (title + GenerateKeyButton)
│       │   └── SectionBody
│       │       └── ApiKeyDisplay[]
│       │           ├── ApiKeyValue (masked)
│       │           ├── ApiKeyActions (copy + revoke)
│       │           └── ApiKeyMeta (created + last used)
│       │
│       ├── AdminsSection
│       │   ├── SectionHeader (title + InviteAdminButton)
│       │   └── SectionBody
│       │       └── AdminList
│       │           └── AdminItem[]
│       │               ├── AdminAvatar (initials + gradient)
│       │               ├── AdminInfo (name + email)
│       │               └── AdminRoleBadge (owner | admin)
│       │
│       ├── BrandingSection
│       │   ├── SectionHeader (title only)
│       │   └── SectionBody
│       │       ├── FormRow (companyName, supportEmail)
│       │       ├── FormRow.full (qrEmailFooter textarea)
│       │       └── ToggleRow (includeLogoInEmails)
│       │
│       └── DangerZoneSection
│           ├── SectionHeader (title in red)
│           └── SectionBody
│               └── DangerAction[]
│                   ├── DangerHeader (icon + title)
│                   ├── DangerDesc
│                   └── DangerButton  → BaseUI Button btn-danger
│
└── ToastProvider                     → BaseUI Toaster
```

## 6. TypeScript Types

```ts
// --- Connection Status ---
type ConnectionStatus = 'healthy' | 'warning' | 'error' | 'unknown';

// --- LDAP Settings ---
interface LdapSettings {
  serverUrl: string;           // "ldaps://ldap.example.com:636"
  baseDn: string;              // "dc=example,dc=com"
  bindDn: string;              // "cn=admin,dc=example,dc=com"
  bindPassword: string;        // masked in UI
  userSearchBase: string;      // "ou=users,dc=example,dc=com"
  groupSearchBase: string;     // "ou=groups,dc=example,dc=com"
  verifySsl: boolean;
  connectionPooling: boolean;
  status: ConnectionStatus;    // derived from last test
}

// --- Email Settings ---
interface EmailSettings {
  smtpHost: string;            // "smtp.example.com"
  smtpPort: 25 | 465 | 587;
  username: string;
  password: string;            // masked
  fromAddress: string;         // "noreply@example.com"
  fromName: string;            // "Azblink Directory"
  useTls: boolean;
}

// --- Security Settings ---
interface SecuritySettings {
  sessionTimeoutMinutes: 15 | 30 | 60 | 240 | 480;
  maxLoginAttempts: 0 | 3 | 5 | 10;  // 0 = unlimited
  requireMfa: boolean;
  ipAllowlist: boolean;
  auditApiRequests: boolean;
}

// --- Audit Settings ---
type RetentionPolicy = '90' | '365' | 'forever';

interface AuditSettings {
  retentionPolicy: RetentionPolicy;
  siemExport: boolean;
  includeUserDetails: boolean;
}

// --- API Key ---
interface ApiKey {
  id: string;
  prefix: string;              // "ak_live_7f4d..."
  maskedKey: string;           // "ak_live_7f4d8e9a...••••••"
  createdAt: string;           // ISO 8601
  createdBy: string;           // "Sarah Kim"
  lastUsedAt: string | null;   // ISO 8601 or null
}

// --- Administrator ---
type AdminRole = 'owner' | 'admin';
type AvatarGradient = 'indigo-purple' | 'blue-cyan' | 'green-teal';

interface Administrator {
  id: string;
  name: string;                // "Sarah Kim"
  initials: string;            // "SK"
  email: string;
  role: AdminRole;
  avatarGradient: AvatarGradient;
}

// --- Branding Settings ---
interface BrandingSettings {
  companyName: string;         // "Example Corp"
  supportEmail: string;        // "support@example.com"
  qrEmailFooter: string;
  includeLogoInEmails: boolean;
}

// --- Aggregate Settings Model ---
interface AllSettings {
  ldap: LdapSettings;
  email: EmailSettings;
  security: SecuritySettings;
  audit: AuditSettings;
  branding: BrandingSettings;
}

// --- Danger Actions ---
type DangerActionId = 'purge-qr' | 'reset-settings';

interface DangerAction {
  id: DangerActionId;
  title: string;
  description: string;
  confirmText: string;         // "Are you sure? This cannot be undone."
}
```

## 7. Color Map

### Status Indicator

| Status | BG | FG | Icon |
|---|---|---|---|
| `healthy` | `bg-green-500/10` | `text-green-500` | Checkmark |
| `warning` | `bg-amber-500/10` | `text-amber-500` | Warning triangle |
| `error` | `bg-red-500/10` | `text-red-500` | X circle |

### Admin Role Badge

| Role | BG | FG |
|---|---|---|
| `owner` | `bg-amber-500/10` | `text-amber-500` |
| `admin` | `bg-blue-500/10` | `text-blue-500` |

### Admin Avatar Gradients

| Key | Gradient |
|---|---|
| `indigo-purple` | `from-indigo-500 to-purple-500` |
| `blue-cyan` | `from-blue-500 to-cyan-500` |
| `green-teal` | `from-green-500 to-teal-500` |

### Retention Option

| State | Border | BG | Radio |
|---|---|---|---|
| `selected` | `border-blue-500` | `bg-blue-500/10` | Blue dot visible |
| `default` | `border-zinc-700` | `transparent` | Dot hidden |

### Danger Zone

| Element | Value |
|---|---|
| Card border | `border-red-500/30` |
| Title color | `text-red-500` |
| Section title | `text-red-500` |
| Button | `bg-red-500/10 text-red-500 border-red-500/30` |

### Test Button (dashed)

| State | Border | FG | BG |
|---|---|---|---|
| Default | `border-dashed border-zinc-600` | `text-zinc-500` | `transparent` |
| Hover | `border-dashed border-blue-500` | `text-blue-500` | `bg-blue-500/10` |

## 8. BaseUI Component Mapping

| Prototype Element | BaseUI Component | Props / Notes |
|---|---|---|
| Text inputs | `Input` | `overrides` for mono font on LDAP/SMTP fields |
| Password inputs | `Input` | `type="password"`, toggle visibility button |
| Select dropdowns | `Select` | `options` array, `value`, `onChange` |
| Textarea | `Textarea` | `overrides` for min-height 100px |
| Toggle switches | `Checkbox` | `checkmarkType={STYLE_TYPE.toggle}` |
| Save All button | `Button` | `kind={KIND.primary}` |
| Reset button | `Button` | `kind={KIND.secondary}` |
| Test buttons | Custom | No BaseUI equivalent — build with styled `<button>` |
| Danger buttons | `Button` | Custom `overrides` for red styling |
| Retention radios | `RadioGroup` + `Radio` | Custom `overrides` for card-style layout |
| Toast notifications | `toaster` | From BaseUI `Toaster` |
| Settings nav | Custom | No BaseUI equivalent — use scroll-spy hook |

## 9. State Architecture

```ts
// --- Form state (single flat object, PATCH on save) ---
const [settings, setSettings] = useState<AllSettings>(DEFAULT_SETTINGS);
const [dirtyFields, setDirtyFields] = useState<Set<string>>(new Set());
const [isSaving, setIsSaving] = useState(false);

// --- Section data (separate queries) ---
const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
const [admins, setAdmins] = useState<Administrator[]>([]);

// --- UI state ---
const [activeSection, setActiveSection] = useState<string>('ldap');   // scroll-spy driven
const [ldapStatus, setLdapStatus] = useState<ConnectionStatus>('healthy');

// --- Dirty tracking ---
function updateField(path: string, value: unknown) {
  setSettings(prev => set(prev, path, value));  // lodash set
  setDirtyFields(prev => new Set(prev).add(path));
}
```

### Data Flow

```
Input change ──→ updateField('ldap.serverUrl', val) ──→ settings + dirtyFields

[Save All] ──→ PATCH /api/settings { ...dirtyPaths } ──→ clear dirtyFields + toast

[Reset to Defaults] ──→ confirm dialog ──→ PUT /api/settings/reset ──→ reload all

[Test Connection] ──→ POST /api/settings/ldap/test ──→ update ldapStatus + toast

[Generate API Key] ──→ POST /api/keys ──→ prepend to apiKeys[] + show full key once

[Revoke API Key] ──→ confirm dialog ──→ DELETE /api/keys/:id ──→ remove from apiKeys[]

[Invite Admin] ──→ modal with email + role ──→ POST /api/admins/invite ──→ toast

Scroll ──→ IntersectionObserver ──→ setActiveSection ──→ nav highlight
```

## 10. Scroll-Spy Behavior

```
IntersectionObserver setup:
  - Observe all .settings-section elements
  - rootMargin: "-88px 0px -60% 0px" (offset for sticky topbar)
  - threshold: 0

On intersect:
  - Find topmost visible section
  - Set activeSection → highlights matching nav item
  - Does NOT scroll (passive observation only)

Nav click:
  - element.scrollIntoView({ behavior: 'smooth', block: 'start' })
  - Override activeSection immediately (don't wait for observer)

URL hash (optional):
  - /settings#security → scroll to security section on mount
  - Update hash on scroll-spy change
```

## 11. Cross-Page Navigation Contract

### From Other Pages → Settings

| Source | Trigger | URL | Behavior |
|---|---|---|---|
| Org Profiles QR Settings | "Edit global QR settings" | `/settings#audit` | Scroll to audit section |
| Dashboard LDAP widget | "Configure" link | `/settings#ldap` | Scroll to LDAP section |
| Any page (sidebar) | Settings nav item | `/settings` | Default (scroll to top) |

### From Settings → Other Pages

| Trigger | Target | URL |
|---|---|---|
| Audit section "View logs" | Audit Log page | `/audit-log` |
| Danger zone "Purge QR" result | QR Codes page | `/qr-codes` (redirect after action) |

## 12. Shared Components (with other pages)

| Component | Used In | Notes |
|---|---|---|
| `ToggleRow` | Settings (×10), Org Profiles (config toggles) | **Extract as shared** — same label+desc+toggle pattern |
| `StatusIndicator` | Settings (LDAP), Dashboard (system health) | Same healthy/warning/error pill |
| `StatusBadge` | Settings (admin role), QR Codes (QR status), Org Profiles (profile badge) | Same pill pattern, different color map per context |
| `ToastProvider` | All pages | Single app-level provider |
| `FormGroup` / `FormRow` | Settings (all sections), Org Profiles (create modal) | **Extract as shared** — 2-col grid with label+input+hint |
| Button variants | All pages | Consistent kind/size mapping |

**New shared primitives this page introduces:**
- `ToggleRow` — label + description + toggle switch in a bordered row
- `StatusIndicator` — colored pill with icon for connection/system status
- `RetentionRadioGroup` — card-style radio selection (reusable for any exclusive-choice pattern)
- `DangerAction` — red-bordered destructive action card with confirmation
- `ApiKeyDisplay` — masked key with copy/revoke actions
- `TestButton` — dashed-border action button for connection/email testing

## 13. Differences from All Other Pages

| Aspect | QR Codes | Audit Log | Org Profiles | **Settings** |
|---|---|---|---|---|
| **Layout** | Table + detail | Table + detail | Card list + detail | **Nav + scrolling sections** |
| **Navigation** | Status tabs | Time filter | Card selection | **Scroll-spy + sticky nav** |
| **Primary data** | QR records | Event records | Profile configs | **Key/value settings** |
| **Form density** | Low (modal) | None | Medium (modal) | **High (inline everywhere)** |
| **Save pattern** | Per-action | Read-only | Per-action | **Batch save all** |
| **Detail panel** | Conditional | Conditional | Always visible | **None (sections ARE detail)** |
| **Real-time** | No | Live indicator | No | **LDAP status polling** |
| **Danger actions** | None | None | None | **Yes (purge, reset)** |
| **Grid split** | 1fr + 380px | 1fr + 380px | 340px + 1fr | **240px + 1fr** |

## 14. Migration Phases

### Phase 1: Scaffold + Nav (Day 1)
- [ ] Create `SettingsPage.tsx` with route `/settings`
- [ ] `SettingsLayout` grid (240px + 1fr)
- [ ] `SettingsNav` with 8 nav items
- [ ] Scroll-spy hook (IntersectionObserver)
- [ ] URL hash scroll-to on mount
- [ ] Settings data fetch with `@tanstack/react-query`

### Phase 2: Form Sections — LDAP, Email, Security (Day 1–2)
- [ ] `SettingsSection` wrapper (header + body)
- [ ] `FormRow` + `FormGroup` (extract as shared)
- [ ] `ToggleRow` component (extract as shared)
- [ ] LDAP section with `StatusIndicator` + `TestButton`
- [ ] Email section with `TestButton`
- [ ] Security section with selects + toggles
- [ ] Dirty field tracking

### Phase 3: Audit, API Keys, Admins, Branding (Day 2–3)
- [ ] `RetentionRadioGroup` for audit retention
- [ ] `ApiKeyDisplay` with copy/revoke
- [ ] `AdminList` with `AdminItem` (avatar + role badge)
- [ ] Branding section with textarea
- [ ] Generate API Key action → POST
- [ ] Invite Admin action → modal or POST

### Phase 4: Danger Zone + Save/Reset (Day 3)
- [ ] `DangerAction` cards with confirmation dialogs
- [ ] Save All → PATCH with dirty fields only
- [ ] Reset to Defaults → confirm → PUT
- [ ] Toast feedback for all actions
- [ ] Test Connection / Test Email → POST + status update

### Phase 5: Polish (Day 3–4)
- [ ] Responsive: 800px grid collapse, nav → horizontal scroll
- [ ] Form-row → single column on mobile
- [ ] Keyboard nav: Tab through inputs, Escape to cancel
- [ ] `data-testid` from `data-component` annotations
- [ ] Password visibility toggle on LDAP/SMTP fields
- [ ] Unsaved changes warning on page leave
