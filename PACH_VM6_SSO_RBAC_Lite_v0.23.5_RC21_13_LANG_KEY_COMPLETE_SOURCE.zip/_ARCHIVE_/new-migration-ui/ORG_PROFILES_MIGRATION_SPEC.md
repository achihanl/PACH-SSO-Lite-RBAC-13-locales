# Org Profiles — React Migration Spec

## 1. Page Layout (ASCII)

This is the only page in the system using a **card-based master-detail** pattern
(vs the table-based master-detail on QR Codes and Audit Log).

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Organization Profiles                        [Import] [+ Create Profile]  │
│  Reusable provisioning configurations for organizations                    │
├──────────────────┬──────────────────────────────────────────────────────────┤
│                  │                                                          │
│  ALL PROFILES    │  ┌──────────────────────────────────────────────────┐   │
│  · 4 profiles    │  │  🛡  Standard Profile         [Clone] [Edit]    │   │
│                  │  │      Default provisioning template               │   │
│  ┌────────────┐  │  ├──────────────────────────────────────────────────┤   │
│  │ 🛡 Standard │  │  │  Configuration │ Usage │ History                │   │
│  │  Profile    │  │  ├──────────────────────────────────────────────────┤   │
│  │  DEFAULT    │◀─┤  │                                                 │   │
│  │  4 orgs     │  │  │  ▣ XMPP Configuration                  [═══]  │   │
│  │  189 users  │  │  │  ┌─────────────────────────────────────────┐   │   │
│  │  ✓XM ✓SIP   │  │  │  │ Domain        uc.example.com           │   │   │
│  │  ✓SSO       │  │  │  │ WebSocket     wss://uc.example.com/... │   │   │
│  └────────────┘  │  │  │ Conference    conference.uc.example.com │   │   │
│                  │  │  │ Resource      Enabled                   │   │   │
│  ┌────────────┐  │  │  └─────────────────────────────────────────┘   │   │
│  │ ☎ UC Only  │  │  │                                                 │   │
│  │  ACTIVE    │  │  │  ☎ SIP Configuration                     [═══]  │   │
│  │  2 orgs    │  │  │  ┌─────────────────────────────────────────┐   │   │
│  │  45 users  │  │  │  │ Domain        sip.example.com           │   │   │
│  │  ✓XM ✓SIP  │  │  │  │ WebSocket     wss://sip.example.com/ws │   │   │
│  │  ✗SSO      │  │  │  │ Transport     WSS (Secure)             │   │   │
│  └────────────┘  │  │  │ SRTP          Required                 │   │   │
│                  │  │  └─────────────────────────────────────────┘   │   │
│  ┌────────────┐  │  │                                                 │   │
│  │ 👥 External│  │  │  🔑 SSO Configuration (OIDC)              [═══]  │   │
│  │  Contract. │  │  │  ┌─────────────────────────────────────────┐   │   │
│  │  ACTIVE    │  │  │  │ Provider      Authentik                 │   │   │
│  │  1 org     │  │  │  │ Issuer URL    https://auth.example...   │   │   │
│  │  12 users  │  │  │  │ Client ID     azblink-mobile            │   │   │
│  └────────────┘  │  │  │ Scopes        openid profile email...   │   │   │
│                  │  │  │ PKCE          Required                  │   │   │
│  ┌────────────┐  │  │  └─────────────────────────────────────────┘   │   │
│  │ 🧪 Test    │  │  │                                                 │   │
│  │  Environm. │  │  │  ⬡ QR Code Settings                             │   │
│  │  DRAFT     │  │  │  ┌─────────────────────────────────────────┐   │   │
│  │  0 orgs    │  │  │  │ Default Validity   1 hour               │   │   │
│  │  0 users   │  │  │  │ One-Time Use       Enabled              │   │   │
│  └────────────┘  │  │  │ Auto-Email         Disabled             │   │   │
│                  │  │  │ Deep Link          azblink://           │   │   │
│                  │  │  └─────────────────────────────────────────┘   │   │
│                  │                                                          │
│   340px fixed    │                    1fr fluid                             │
└──────────────────┴──────────────────────────────────────────────────────────┘
```

## 2. Profile Card Anatomy (ASCII)

```
┌──────────────────────────────────────┐
│  ┌──────┐                 ┌────────┐ │
│  │ ICON │                 │ BADGE  │ │  ← badge: Default | Active | Draft
│  └──────┘                 └────────┘ │
│                                      │
│  Profile Title                       │  ← 15px semibold
│  Description text here...            │  ← 13px muted
│                                      │
│  🏢 4 orgs    👥 189 users           │  ← stats row
│  ─────────────────────────────────── │  ← border-top separator
│  ✓ XMPP   ✓ SIP   ✓ SSO            │  ← feature flags (enabled/disabled)
└──────────────────────────────────────┘

States:
  default    → no border highlight
  :hover     → border-color elevates
  .selected  → border-color: blue-500, bg: elevated
```

## 3. Detail Panel Tabs (ASCII)

```
TAB: Configuration                TAB: Usage                      TAB: History
─────────────────────             ──────────────                   ───────────────

[4 config sections]               ┌───────┬───────┬───────┐       ┌─────────────────────┐
                                  │   4   │  189  │  156  │       │ Feb 1, 10:15 AM     │
Each section:                     │ Orgs  │ Users │  QRs  │       │ SSO scopes updated  │
┌───────────────────┐             └───────┴───────┴───────┘       │ by Sarah Kim        │
│ Icon Title  [═══] │ ← toggle                                   ├─────────────────────┤
├───────────────────┤             Assigned Organizations          │ Jan 28, 3:42 PM     │
│ Label     Value   │             ┌──────────────────────┐       │ QR validity changed │
│ Label     Value   │             │ 🏢 Engineering       │       │ from 4h to 1h       │
│ Label     Value   │             │    ou=Engineering...  │       ├─────────────────────┤
│ Label     Value   │             │              42 users │       │ Jan 15, 9:00 AM     │
└───────────────────┘             ├──────────────────────┤       │ Profile created     │
                                  │ 🏢 Sales             │       │ by Sarah Kim        │
4 sections:                       │    ou=Sales...        │       └─────────────────────┘
 1. XMPP (blue icon)             │              28 users │
 2. SIP  (green icon)            ├──────────────────────┤
 3. SSO  (cyan icon)             │ 🏢 Finance           │
 4. QR Settings (amber icon)     │              12 users │
                                  └──────────────────────┘
```

## 4. Create Profile Modal (ASCII)

```
┌──────────────────────────────────────────────────────┐
│  Create Organization Profile                    [✕]  │
├──────────────────────────────────────────────────────┤
│                                                      │
│  Profile Name *                                      │
│  ┌────────────────────────────────────────────────┐  │
│  │ e.g., Standard Profile                        │  │
│  └────────────────────────────────────────────────┘  │
│                                                      │
│  Description                                         │
│  ┌────────────────────────────────────────────────┐  │
│  │ Brief description of this profile's purpose   │  │
│  │                                                │  │
│  └────────────────────────────────────────────────┘  │
│                                                      │
│  ┌────────────────────────────────────────────────┐  │
│  │ 💬 XMPP Configuration                      ▼  │  │  ← collapsible, open by default
│  ├────────────────────────────────────────────────┤  │
│  │  XMPP Domain                                  │  │
│  │  ┌──────────────────────────────────────────┐ │  │
│  │  │ uc.example.com                           │ │  │
│  │  └──────────────────────────────────────────┘ │  │
│  │  WebSocket URL                                │  │
│  │  ┌──────────────────────────────────────────┐ │  │
│  │  │ wss://uc.example.com/xmpp-websocket     │ │  │
│  │  └──────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────┘  │
│                                                      │
│  ┌────────────────────────────────────────────────┐  │
│  │ ☎ SIP Configuration                        ▶  │  │  ← collapsed
│  └────────────────────────────────────────────────┘  │
│                                                      │
│  ┌────────────────────────────────────────────────┐  │
│  │ 🔑 SSO Configuration                       ▶  │  │  ← collapsed
│  └────────────────────────────────────────────────┘  │
│                                                      │
├──────────────────────────────────────────────────────┤
│                              [Cancel] [Create Profile]│
└──────────────────────────────────────────────────────┘

Max-width: 560px
Max-height: 90vh (body scrolls)
```

## 5. Responsive Collapse (ASCII)

```
DESKTOP (>900px):                         MOBILE (≤900px):
┌─────────┬───────────────────┐           ┌───────────────────────┐
│  Cards  │   Detail Panel    │           │  Cards (max-h: 400px) │
│  340px  │      1fr          │           │  (scrollable list)    │
│         │                   │           ├───────────────────────┤
│         │                   │           │  Detail Panel         │
│         │                   │           │  (full width below)   │
└─────────┴───────────────────┘           └───────────────────────┘

Usage stats at ≤600px:
┌───────┬───────┬───────┐  →  ┌───────────────┐
│ Orgs  │ Users │ QRs   │     │ Organizations │
└───────┴───────┴───────┘     │ Total Users   │
                               │ QRs Generated │
                               └───────────────┘
```

## 6. Component Tree

```
OrgProfilesPage/
├── OrgProfilesPageHeader
│   ├── PageTitle ("Organization Profiles" + subtitle)
│   └── HeaderActions
│       ├── ImportButton              → BaseUI Button KIND.secondary
│       └── CreateProfileButton       → BaseUI Button KIND.primary
│
├── ProfilesGrid                      ← CSS Grid: 340px 1fr
│   ├── ProfilesListContainer
│   │   ├── ListHeader ("All Profiles · N profiles")
│   │   └── ProfilesList              ← scrollable card list
│   │       └── ProfileCard[]         ← per-profile (repeated)
│   │           ├── ProfileCardHeader
│   │           │   ├── ProfileCardIcon   ← default (blue) | custom (purple)
│   │           │   └── ProfileBadge      ← Default | Active | Draft
│   │           ├── ProfileCardTitle
│   │           ├── ProfileCardDesc
│   │           ├── ProfileCardStats      ← orgs count + users count
│   │           └── FeatureFlags          ← XMPP | SIP | SSO (enabled/disabled)
│   │
│   └── ProfileDetailPanel            ← right panel, content changes with selection
│       ├── DetailHeader
│       │   ├── ProfileIcon (56px)
│       │   ├── ProfileTitle + Subtitle
│       │   └── DetailActions
│       │       ├── CloneButton       → BaseUI Button KIND.secondary SIZE.compact
│       │       └── EditButton        → BaseUI Button KIND.secondary SIZE.compact
│       ├── ProfileTabs               ← BaseUI Tabs or custom tab strip
│       │   ├── Tab[config] "Configuration"
│       │   ├── Tab[usage]  "Usage"
│       │   └── Tab[history] "History"
│       └── TabContent
│           ├── ConfigTab
│           │   └── ConfigSection[] (×4)
│           │       ├── SectionHeader
│           │       │   ├── SectionIcon (colored)
│           │       │   ├── SectionTitle
│           │       │   └── ToggleSwitch  → custom or BaseUI Checkbox toggle
│           │       └── ConfigCard
│           │           └── ConfigRow[]
│           │               ├── ConfigLabel
│           │               └── ConfigValue  ← .mono | .success | .warning
│           ├── UsageTab
│           │   ├── UsageStats (3-col grid)
│           │   │   └── UsageStat[] (×3)
│           │   │       ├── StatValue
│           │   │       └── StatLabel
│           │   └── AssignedOrgsList
│           │       └── AssignedOrgRow[]
│           │           ├── OrgIcon
│           │           ├── OrgInfo (name + DN)
│           │           └── OrgUserCount
│           └── HistoryTab
│               └── HistoryList
│                   └── HistoryEntry[]
│                       ├── Timestamp
│                       └── Description
│
├── CreateProfileModal                → BaseUI Modal
│   ├── ModalHeader (title + close)
│   ├── ModalBody
│   │   ├── FormGroup[name]           → BaseUI FormControl + Input
│   │   ├── FormGroup[description]    → BaseUI FormControl + Textarea
│   │   └── CollapsibleSection[] (×3)
│   │       ├── CollapsibleHeader (icon + title + chevron)
│   │       └── CollapsibleContent
│   │           └── FormGroup[] (domain, websocketUrl, etc.)
│   └── ModalFooter
│       ├── CancelButton              → BaseUI Button KIND.secondary
│       └── CreateButton              → BaseUI Button KIND.primary
│
└── ToastProvider                     → BaseUI Toaster
```

## 7. TypeScript Types

```ts
// --- Profile Status ---
type ProfileStatus = 'active' | 'draft' | 'archived';
type ProfileType = 'default' | 'custom';
type FeatureKey = 'xmpp' | 'sip' | 'sso';

// --- Config Section Types ---
interface XmppConfig {
  enabled: boolean;
  domain: string;                // "uc.example.com"
  websocketUrl: string;          // "wss://uc.example.com/xmpp-websocket"
  conferenceServer?: string;     // "conference.uc.example.com"
  resourceBinding: boolean;
}

interface SipConfig {
  enabled: boolean;
  domain: string;                // "sip.example.com"
  websocketUrl: string;          // "wss://sip.example.com/ws"
  transport: 'wss' | 'ws' | 'tcp' | 'udp';
  srtpRequired: boolean;
}

interface SsoConfig {
  enabled: boolean;
  provider: string;              // "Authentik"
  issuerUrl: string;             // "https://auth.example.com/application/o/mobile/"
  clientId: string;              // "azblink-mobile"
  scopes: string;                // "openid profile email groups"
  pkceRequired: boolean;
}

interface QrSettings {
  defaultValidityMinutes: number;  // 60
  oneTimeUse: boolean;
  autoEmailOnCreate: boolean;
  deepLinkScheme: string;          // "azblink://"
}

// --- Core Profile Model ---
interface OrgProfile {
  id: string;                    // UUID or slug
  name: string;                  // "Standard Profile"
  description: string;
  type: ProfileType;             // "default" | "custom"
  status: ProfileStatus;         // "active" | "draft" | "archived"
  xmpp: XmppConfig;
  sip: SipConfig;
  sso: SsoConfig;
  qrSettings: QrSettings;
  assignedOrgs: AssignedOrg[];
  usageStats: UsageStats;
  history: HistoryEntry[];
  createdAt: string;             // ISO 8601
  updatedAt: string;
}

interface AssignedOrg {
  name: string;                  // "Engineering"
  dn: string;                   // "ou=Engineering,ou=org,dc=example,dc=com"
  userCount: number;
}

interface UsageStats {
  orgCount: number;
  totalUsers: number;
  qrsGenerated: number;
}

interface HistoryEntry {
  timestamp: string;             // ISO 8601
  description: string;           // "SSO scopes updated by Sarah Kim"
  actor: string;                 // "Sarah Kim"
  field?: string;                // "sso.scopes"
  oldValue?: string;
  newValue?: string;
}

// --- Create Profile Form ---
interface CreateProfileForm {
  name: string;
  description: string;
  xmpp: { domain: string; websocketUrl: string };
  sip: { domain: string; websocketUrl: string };
  sso: { issuerUrl: string; clientId: string; scopes: string };
}

// --- Feature Flag Display ---
interface FeatureFlag {
  key: FeatureKey;
  label: string;       // "XMPP" | "SIP" | "SSO"
  enabled: boolean;
}
```

## 8. Config Section → Color Map

| Section | Section Icon BG | Section Icon FG | Toggle Active | Value `.success` | Value `.warning` |
|---|---|---|---|---|---|
| XMPP | `bg-blue-500/10` | `text-blue-500` | `bg-green-500` | `text-green-500` | — |
| SIP | `bg-green-500/10` | `text-green-500` | `bg-green-500` | `text-green-500` | — |
| SSO (OIDC) | `bg-cyan-500/10` | `text-cyan-500` | `bg-green-500` | `text-green-500` | — |
| QR Settings | `bg-amber-500/10` | `text-amber-500` | — (no toggle) | `text-green-500` | `text-amber-500` |

### Profile Card Icon + Badge Colors

| Profile Type | Icon BG | Icon FG | Badge Variant |
|---|---|---|---|
| `default` | `bg-blue-500/10` | `text-blue-500` | `bg-blue-500/10 text-blue-500` |
| `custom` | `bg-purple-500/10` | `text-purple-500` | — |

| Badge Status | BG | FG |
|---|---|---|
| `Default` | `bg-blue-500/10` | `text-blue-500` |
| `Active` | `bg-green-500/10` | `text-green-500` |
| `Draft` | `bg-amber-500/10` | `text-amber-500` |

### Feature Flag Colors

| State | FG Token | Icon |
|---|---|---|
| `enabled` | `text-green-500` | Checkmark (M5 13l4 4L19 7) |
| `disabled` | `text-zinc-500` | X mark (M6 18L18 6M6 6l12 12) |

## 9. BaseUI Component Mapping

| Prototype Element | BaseUI Component | Props / Notes |
|---|---|---|
| Profile tabs | `Tabs` / `Tab` | `activeKey`, `onChange`, `overrides` for dark theme |
| Create modal | `Modal` | `isOpen`, `onClose`, `size={SIZE.default}` |
| Profile name input | `FormControl` + `Input` | `label`, `required`, `error` |
| Description textarea | `FormControl` + `Textarea` | `overrides` for min-height |
| Config form inputs | `Input` | `overrides` for mono font |
| Toggle switches | `Checkbox` | `checkmarkType={STYLE_TYPE.toggle}` |
| Import button | `Button` | `kind={KIND.secondary}`, `startEnhancer` |
| Create button | `Button` | `kind={KIND.primary}`, `startEnhancer` |
| Clone / Edit buttons | `Button` | `kind={KIND.secondary}`, `size={SIZE.compact}` |
| Collapsible sections | Custom `Accordion` | BaseUI has no accordion — build with state + CSS |
| Toasts | `toaster.positive()` | From BaseUI `Toaster` |

## 10. State Architecture

```ts
// --- Page-level state ---
const [profiles, setProfiles] = useState<OrgProfile[]>([]);
const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);
const [activeTab, setActiveTab] = useState<'config' | 'usage' | 'history'>('config');
const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
const [createForm, setCreateForm] = useState<CreateProfileForm>(EMPTY_FORM);

// --- Derived ---
const selectedProfile = useMemo(
  () => profiles.find(p => p.id === selectedProfileId) ?? null,
  [profiles, selectedProfileId]
);

// --- Collapsible state (modal only) ---
const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['xmpp']));
```

### Data Flow

```
ProfileCard click ──→ selectedProfileId ──→ detail panel re-renders
                                         ──→ activeTab resets to 'config'

Tab click ──→ activeTab ──→ tab content switches

Toggle switch ──→ PATCH /api/profiles/:id ──→ optimistic update in profiles[]

Create Profile ──→ POST /api/profiles ──→ append to profiles[]
                                        ──→ select new profile
                                        ──→ close modal + toast

Clone Profile ──→ POST /api/profiles (copy payload) ──→ same as create

Edit Profile ──→ opens modal pre-filled ──→ PUT /api/profiles/:id
```

## 11. Interaction Behaviors

### Profile Selection
- Click card → `setSelectedProfileId(card.id)` → detail panel updates
- Selected card: `border-color: blue-500`, `bg: elevated`
- Tab resets to `config` on profile switch
- First profile auto-selected on mount

### Toggle Switches
- Each config section (XMPP, SIP, SSO) has an independent toggle
- Toggle fires optimistic PATCH to API
- Disabled section: config card content dims (opacity 0.5) but stays visible
- Feature flags on profile card update immediately

### Collapsible Sections (Modal)
- XMPP open by default; SIP and SSO collapsed
- Click header → toggle open/close
- Chevron rotates 180° when open
- Content uses `display: none/block` (no animation in Phase 1)

### Create Profile Flow
```
[+ Create Profile] ──→ Modal opens
                       ├── Fill name (required) + description
                       ├── Expand/fill XMPP/SIP/SSO sections
                       └── [Create Profile] button
                            ├── Validates name non-empty
                            ├── POST /api/profiles
                            ├── Close modal
                            ├── Toast: "Profile Created"
                            └── Auto-select new profile in list
```

### Clone Profile Flow
```
[Clone] ──→ POST /api/profiles { ...selectedProfile, name: "Copy of X" }
         ──→ Append to list
         ──→ Auto-select clone
         ──→ Toast: "Profile Cloned"
```

## 12. Cross-Page Navigation Contract

### From Other Pages → Org Profiles

| Source | Trigger | URL | Behavior |
|---|---|---|---|
| QR Codes detail | "Profile: Standard" link | `/org-profiles?profile=standard` | Auto-select profile |
| Dashboard | Profile widget link | `/org-profiles` | No selection override |

### From Org Profiles → Other Pages

| Trigger | Target | URL |
|---|---|---|
| Click org in Usage tab | Organizations page | `/organizations?org=${orgDn}` (future) |
| Profile config references QR settings | QR settings | `/settings#qr` (future) |

### URL Parameter Contract

```
/org-profiles?profile=standard
  → Auto-selects matching profile by id/slug
  → Opens Configuration tab by default
```

## 13. Responsive Behavior

| Breakpoint | Layout Change |
|---|---|
| > 900px | 2-col grid: cards (340px) + detail panel (1fr) |
| ≤ 900px | 1-col: card list (max-height 400px, scrollable) + detail below |
| ≤ 600px | Usage stats grid → single column |
| ≤ 500px | Modal full-width; header actions stack |

## 14. Stripped Elements Reference

| Element | Prototype Lines | Reason |
|---|---|---|
| Sidebar (`<aside class="sidebar">`) | 447–535 | App shell |
| Topbar (`<header class="topbar">`) | 539–558 | Page header extracted as component |
| `.app-container` wrapper | 445, 1021 | App shell flex container |
| Theme CSS variables (`:root`) | 11–46 | Replaced by Tailwind config |
| Font imports (Google Fonts) | 7–9 | App-level `<head>` |
| Body/global resets | 48–56 | App-level CSS |
| Sidebar CSS | 61–106 | App shell |
| `.main-content` CSS | 108 | App shell |
| Topbar CSS | 110–118 | App shell |
| Scrollbar CSS | 437–441 | App-level global styles |
| All color-bearing CSS | Throughout | Mapped to Tailwind in Section 8 |

## 15. Shared Components (with QR Codes + Audit Log)

| Component | Used In | Notes |
|---|---|---|
| `ConfigCard` / `ConfigRow` | Org Profiles (detail), QR detail (future) | Same label/value grid pattern |
| `ToggleSwitch` | Org Profiles sections | Could reuse on Settings page |
| `StatusBadge` | QR status, Profile badge | Same pill pattern, different color map |
| `FeatureFlags` | Profile cards | Unique to this page but pattern is reusable |
| `ToastProvider` | All pages | Single app-level provider |
| `Modal` (BaseUI) | QR generate modal, Create Profile modal | Shared BaseUI config |
| Button variants | All pages | Consistent kind/size mapping |
| `CollapsibleSection` | Create Profile modal | Reusable accordion primitive |

**New shared primitives this page introduces:**
- `ConfigCard` + `ConfigRow` — key/value display card (reuse in Settings page)
- `CollapsibleSection` — accordion with icon + chevron (reuse in create/edit modals)
- `ToggleSwitch` — section-level enable/disable toggle

## 16. Differences from QR Codes + Audit Log Pages

| Aspect | QR Codes | Audit Log | Org Profiles |
|---|---|---|---|
| **Master layout** | Table rows | Table rows | **Card list** |
| **Detail trigger** | Row click | Row click | **Card click** |
| **Detail content** | QR preview + checklist | Event JSON + cross-ref | **Tabbed config viewer** |
| **Tabs** | None | None | **3 tabs: Config/Usage/History** |
| **Primary action** | Generate QR (modal) | Export (download) | **Create Profile (modal)** |
| **Form complexity** | Simple (user + validity) | None | **Multi-section with collapsibles** |
| **Toggle controls** | None | None | **Per-section enable/disable** |
| **Data volume** | ~100s of QRs | ~1000s of events | **~10s of profiles (no pagination)** |
| **Real-time** | No | Live indicator | **No** |
| **Grid split** | 1fr + 380px | 1fr + 380px | **340px + 1fr** (cards left) |

## 17. Migration Phases

### Phase 1: Scaffold + List (Day 1)
- [ ] Create `OrgProfilesPage.tsx` with route `/org-profiles`
- [ ] Wire URL param parsing (`?profile=`)
- [ ] `ProfilesListContainer` with `ProfileCard[]`
- [ ] Card click → selection state
- [ ] Profile data fetch with `@tanstack/react-query`

### Phase 2: Detail Panel + Tabs (Day 1–2)
- [ ] `ProfileDetailPanel` with `DetailHeader`
- [ ] `ProfileTabs` (BaseUI `Tabs` or custom)
- [ ] `ConfigTab` with 4 `ConfigSection` components
- [ ] `ConfigCard` + `ConfigRow` (extract as shared)
- [ ] `ToggleSwitch` for section enable/disable

### Phase 3: Usage + History Tabs (Day 2)
- [ ] `UsageTab` with `UsageStats` grid + `AssignedOrgsList`
- [ ] `HistoryTab` with `HistoryEntry[]`
- [ ] Tab content switches on click

### Phase 4: Create/Edit Modal (Day 2–3)
- [ ] `CreateProfileModal` with BaseUI `Modal`
- [ ] `CollapsibleSection` component (XMPP open, SIP/SSO collapsed)
- [ ] Form validation (name required)
- [ ] POST on submit → close + toast + auto-select
- [ ] Clone action → prefilled modal

### Phase 5: Polish (Day 3)
- [ ] Responsive breakpoints (900px grid collapse, 600px stats)
- [ ] Keyboard nav: arrow keys for card list, Escape to close modal
- [ ] `data-testid` attributes from `data-component` annotations
- [ ] Optimistic toggle updates with rollback on error
- [ ] URL param `?profile=` auto-selection on mount
