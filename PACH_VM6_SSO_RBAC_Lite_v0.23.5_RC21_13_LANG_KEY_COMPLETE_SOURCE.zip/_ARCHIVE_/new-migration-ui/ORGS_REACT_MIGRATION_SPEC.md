# Organization Management — React Migration Spec

> **Target stack**: React 18+ · BaseUI (Uber) · Tailwind CSS · Lucide icons  
> **Source**: `orgs-content-only.html` (layout-stripped prototype)  
> **Assumption**: Host app provides sidebar, topbar, routing, auth context, and toast system.

---

## 1. Component Tree

```
<OrgManagementPage>                            ← route-level page component
├── <PageHeader />                             ← title + "Import LDAP" + "Add Organization" CTA
│   └── <Button>Add Organization</Button>      ← BaseUI Button (primary)
│
├── <OrgGrid>                                  ← CSS Grid split-panel (320px 1fr)
│   ├── <OrgTree>                              ← left panel (collapsible hierarchy)
│   │   ├── <TreeHeader />                     ← "Organization Tree" label + refresh button
│   │   └── <TreeNode />[]                     ← recursive tree nodes
│   │       ├── <TreeExpandToggle />           ← chevron, rotates 90deg when expanded
│   │       ├── <OrgNodeIcon />                ← colored icon per node type
│   │       ├── <TreeNodeLabel />              ← name + meta (user count / DN)
│   │       └── <SSOBadge />                   ← "SSO" / "No SSO" pill
│   │
│   └── <OrgDetailPanel>                       ← right panel (tabbed)
│       ├── <PanelHeader />                    ← large icon, name, DN, Edit button
│       ├── <DetailTabs />                     ← BaseUI Tabs (4 tabs)
│       │
│       ├── <OverviewTab>                      ← tab-id: "overview"
│       │   ├── <StatsRow />                   ← 4-up stat cards (users, provisioned, pending, sub-orgs)
│       │   │   └── <StatCard />[]             ← value + label
│       │   ├── <OrgDetailsSection />          ← 2×2 info grid (DN, key, created, modified)
│       │   │   └── <InfoItem />[]             ← label + value card
│       │   └── <ChildOrgsSection />           ← list of child org cards (clickable → navigate)
│       │       └── <ChildOrgItem />[]         ← icon + name + user count
│       │
│       ├── <SSOConfigTab>                     ← tab-id: "sso"
│       │   ├── <SSOStatusCard />              ← icon + title + desc + toggle
│       │   ├── <OIDCConfigSection />          ← full-width info grid (issuer, client_id, scopes, pkce)
│       │   │   ├── <InfoItem />[]
│       │   │   └── <EditButton />             ← opens edit SSO modal
│       │   └── <EndpointsSection />           ← full-width info grid (auth, token, userinfo)
│       │       └── <InfoItem />[]
│       │
│       ├── <UsersTab>                         ← tab-id: "users"
│       │   └── <OrgUserList />                ← table with header + rows
│       │       ├── <UserListHeader />         ← column labels (User, Status, Provisioned)
│       │       └── <OrgUserRow />[]           ← avatar + name + status badge + date
│       │
│       └── <ProvisioningTab>                  ← tab-id: "provisioning"
│           ├── <UCConfigSection />            ← full-width info grid (tenant, domains, WSS URLs)
│           │   └── <InfoItem />[]
│           └── <QRSettingsSection />          ← config list with toggle switches
│               └── <QRSettingItem />[]        ← icon + label + value + optional toggle
│
├── <CreateOrgModal />                         ← BaseUI Modal
│   ├── <FormField label="Organization Name" />  ← BaseUI Input
│   ├── <FormField label="Organization Key" />   ← BaseUI Input (mono font) + hint
│   ├── <FormField label="Parent Organization" /> ← BaseUI Select (tree as flat list)
│   └── <FormField label="Enable SSO" />          ← Toggle + helper text
│
└── <EditSSOModal />                           ← BaseUI Modal (future, stub in Phase 2)
    ├── <FormField label="Issuer URL" />
    ├── <FormField label="Client ID" />
    ├── <FormField label="Scopes" />
    └── <FormField label="PKCE Required" />       ← Toggle
```

---

## 2. Component → BaseUI + Tailwind Mapping

| Prototype Element | React Component | BaseUI Primitive | Tailwind Notes |
|---|---|---|---|
| `.tree-item` | `<TreeNode />` | Custom `<div>` (recursive, needs click + selected + expand) | `hover:bg-surface-tertiary`, `border-l-3 border-accent-primary` when selected |
| `.tree-expand` | `<TreeExpandToggle />` | Custom `<button>` | `w-5 h-5 transition-transform`, `rotate-90` when expanded, `invisible` for leaves |
| `.tree-icon` | `<OrgNodeIcon />` | Custom div | `w-8 h-8 rounded-md flex items-center justify-center` + type→bg/fg color |
| `.tree-badge.sso` | `<SSOBadge />` | `Tag` with `KIND.custom` | `text-[10px] px-1.5 py-0.5 rounded-lg` green vs muted |
| `.panel-tabs` | `<DetailTabs />` | `Tabs` / `Tab` (with overrides) | Bottom border indicator, bg-tertiary background |
| `.stat-card` | `<StatCard />` | Custom div | `bg-surface-tertiary rounded-md p-3.5 text-center` |
| `.info-item` | `<InfoItem />` | Custom div | `bg-surface-tertiary rounded-md p-3` — **shared with Groups & Users** |
| `.sso-status-card` | `<SSOStatusCard />` | Custom div + `Checkbox` (toggle variant) | `flex items-center gap-4 p-4 bg-surface-tertiary rounded-md` |
| `.toggle` | Toggle switch | `Checkbox` with `checkmarkType={STYLE_TYPE.toggle}` | Override width/height to 44×24 |
| `.config-item` | `<ConfigItem />` / `<QRSettingItem />` | Custom div | `flex items-center justify-between p-3.5 bg-surface-tertiary rounded-md` |
| `.user-list` | `<OrgUserList />` | Custom table (`<div>` grid) | `grid grid-cols-[2fr_1fr_1fr]`, header row with elevated bg |
| `.status-badge` | `<StatusBadge />` | `Tag` with `KIND.custom` | Map: active=success, pending=warning, inactive=muted — **shared with Users page** |
| `.modal` | `<CreateOrgModal />` | `Modal` + `ModalHeader` + `ModalBody` + `ModalFooter` | `max-w-[520px]` |
| `.form-input` | Form fields | `Input` / `Select` | `.mono` variant via `font-mono text-[13px]` |
| `select` (Parent Org) | Parent org picker | `Select` with `options` from tree data (flattened) | Include DN in option label for disambiguation |

---

## 3. State Architecture

### 3.1 URL State (searchParams / route params)

| Param | Type | Purpose |
|---|---|---|
| `orgId` | `string` | Selected organization → drives detail panel |
| `tab` | `'overview' \| 'sso' \| 'users' \| 'provisioning'` | Active detail tab (default: `overview`) |

### 3.2 Server State (react-query / SWR)

| Cache Key | Endpoint | Notes |
|---|---|---|
| `['orgTree']` | `GET /api/admin/orgs/tree` | Full tree structure (flat list with `parentId` or nested) |
| `['org', orgId]` | `GET /api/admin/orgs/{orgId}` | Org detail: DN, key, stats, dates, SSO config, UC config |
| `['org', orgId, 'users']` | `GET /api/admin/orgs/{orgId}/users` | Paginated user list with status + provisioned date |
| `['org', orgId, 'children']` | Derived from tree | Filter tree for `parentId === orgId` (no extra fetch) |

### 3.3 Client State

| State | Scope | Purpose |
|---|---|---|
| `expandedNodes: Set<string>` | `OrgTree` (useState) | Which tree nodes are expanded. Persisted to `sessionStorage`. |
| `modalState` | Page-level (useReducer) | `'closed' \| 'create_org' \| 'edit_sso'` |
| `ssoToggleOptimistic` | `SSOConfigTab` | Optimistic toggle → rollback on mutation failure |

### 3.4 State Machine: Modal

```
closed ──→ create_org ──→ success (close + invalidate tree)
  │                   └──→ error (show inline, keep modal open)
  └──→ edit_sso ──→ success (close + invalidate org detail)
                └──→ error (show inline, keep modal open)
```

---

## 4. Data Types

```typescript
/* ── Node type → drives icon color + tree badge logic ── */
type OrgNodeType = 'root' | 'org' | 'dept' | 'team';

/* ── Tree node (recursive) ── */
interface OrgTreeNode {
  id: string;
  name: string;
  key: string;                   // e.g. "eng" — used in DN
  dn: string;                    // e.g. "ou=Engineering,ou=org,dc=example,dc=com"
  type: OrgNodeType;
  parentId: string | null;
  userCount: number;
  ssoEnabled: boolean;
  children: OrgTreeNode[];       // server returns nested; flatten on client if needed
}

/* ── Org detail (fetched on selection) ── */
interface OrgDetail {
  id: string;
  name: string;
  key: string;
  dn: string;
  type: OrgNodeType;
  ssoEnabled: boolean;
  createdAt: string;             // ISO 8601
  modifiedAt: string;

  /* Overview stats */
  stats: {
    totalUsers: number;
    provisioned: number;
    pending: number;
    subOrgs: number;
  };

  /* SSO config (null if ssoEnabled === false) */
  ssoConfig: SSOConfig | null;

  /* UC provisioning config */
  ucConfig: UCConfig;

  /* QR settings (org-level overrides) */
  qrSettings: QRSettings;
}

interface SSOConfig {
  issuerUrl: string;
  clientId: string;
  scopes: string;                // space-separated
  pkceRequired: boolean;
  endpoints: {
    authorization: string;
    token: string;
    userInfo: string;
  };
}

interface UCConfig {
  tenant: string;
  xmppDomain: string;
  xmppWebSocketUrl: string;
  sipDomain: string;
  sipWebSocketUrl: string;
}

interface QRSettings {
  defaultValidityMinutes: number;
  oneTimeTokenEnabled: boolean;
  autoEmailOnCreation: boolean;
}

/* ── User row in Users tab ── */
interface OrgUser {
  id: string;
  name: string;
  initials: string;
  avatarGradient: [string, string]; // start + end hex
  status: 'active' | 'pending' | 'inactive';
  provisionedAt: string | null;     // ISO 8601 or null if pending
}
```

---

## 5. API Contracts

### 5.1 Org Tree

```
GET /api/admin/orgs/tree
→ 200: { tree: OrgTreeNode[] }    // root-level nodes with nested children
```

### 5.2 Org Detail

```
GET /api/admin/orgs/{orgId}
→ 200: OrgDetail
```

### 5.3 Org Users

```
GET /api/admin/orgs/{orgId}/users?page=1&limit=20&status=active|pending
→ 200: { users: OrgUser[], total: number, page: number, hasMore: boolean }
```

### 5.4 Create Organization

```
POST /api/admin/orgs
Body: {
  name: string,
  key: string,                    // lowercase, no spaces — validated client + server
  parentId: string | null,        // null = root-level org
  ssoEnabled: boolean
}
→ 201: { id: string, dn: string, createdAt: string }
→ 409: { error: 'ORG_KEY_CONFLICT', existing: string }
```

### 5.5 Update SSO Config

```
PATCH /api/admin/orgs/{orgId}/sso
Body: SSOConfig (partial — only changed fields)
→ 200: SSOConfig (full, updated)
```

### 5.6 Toggle SSO

```
PATCH /api/admin/orgs/{orgId}
Body: { ssoEnabled: boolean }
→ 200: { ssoEnabled: boolean }
```

**Optimistic UI**: Toggle flips immediately → status card icon/title update → toast. On failure: revert toggle + show error toast.

### 5.7 Update QR Settings

```
PATCH /api/admin/orgs/{orgId}/qr-settings
Body: QRSettings (partial)
→ 200: QRSettings (full, updated)
```

**Optimistic UI**: Same pattern as SSO toggle — flip immediately, rollback on error.

### 5.8 Import LDAP

```
POST /api/admin/orgs/import-ldap
Body: { /* TBD — depends on LDAP source config */ }
→ 202: { jobId: string }   // async job
```

---

## 6. Token Contract (--org-* → Tailwind)

| CSS Custom Property | Semantic | Tailwind Mapping |
|---|---|---|
| `--org-text-primary` | Primary text | `text-foreground` or `text-zinc-50` |
| `--org-text-secondary` | Label text | `text-muted-foreground` or `text-zinc-400` |
| `--org-text-muted` | Hint/meta text | `text-zinc-500` |
| `--org-surface` | Page bg | `bg-background` or `bg-zinc-950` |
| `--org-surface-raised` | Card/panel bg | `bg-card` or `bg-zinc-900` |
| `--org-surface-tertiary` | Nested card bg | `bg-zinc-800/50` |
| `--org-surface-overlay` | Elevated/hover bg | `bg-zinc-800` |
| `--org-border-subtle` | Low-contrast | `border-border/50` or `border-zinc-800` |
| `--org-border-default` | Medium-contrast | `border-border` or `border-zinc-700` |
| `--org-accent-primary` | Blue (interactive) | `text-blue-500` / `bg-blue-500` |
| `--org-accent-indigo` | Root node | `text-indigo-400` / `bg-indigo-400/10` |
| `--org-accent-purple` | Org nodes | `text-purple-400` / `bg-purple-400/10` |
| `--org-accent-cyan` | Team/child nodes | `text-cyan-400` / `bg-cyan-400/10` |
| `--org-success` | Green (SSO on, active) | `text-green-500` / `bg-green-500/10` |
| `--org-warning` | Amber (pending) | `text-amber-500` / `bg-amber-500/10` |
| `--org-danger` | Red (destructive) | `text-red-500` / `bg-red-500/10` |

---

## 7. Constants

```typescript
/* ── Org node type → icon color mapping ── */
export const ORG_NODE_STYLES = {
  root: { bg: 'bg-indigo-400/10', fg: 'text-indigo-400', icon: Globe },
  org:  { bg: 'bg-purple-400/10', fg: 'text-purple-400', icon: Building2 },
  dept: { bg: 'bg-blue-400/10',   fg: 'text-blue-400',   icon: Building },
  team: { bg: 'bg-cyan-400/10',   fg: 'text-cyan-400',   icon: Users },
} as const;

/* ── User status → badge styles ── */
export const STATUS_STYLES = {
  active:   { bg: 'bg-green-500/10', fg: 'text-green-500' },
  pending:  { bg: 'bg-amber-500/10', fg: 'text-amber-500' },
  inactive: { bg: 'bg-zinc-800',     fg: 'text-zinc-500' },
} as const;

/* ── Detail panel tabs ── */
export const ORG_TABS = [
  { id: 'overview',     label: 'Overview' },
  { id: 'sso',          label: 'SSO Configuration' },
  { id: 'users',        label: 'Users' },
  { id: 'provisioning', label: 'Provisioning' },
] as const;
```

---

## 8. Critical UX Behaviors

### 8.1 Tree Selection = URL State

Selected `orgId` lives in route params (`/admin/orgs/:orgId`). Clicking a tree node navigates — enables deep linking, browser back, and bookmarkable detail views.

### 8.2 Tab = URL State

Active tab lives in `?tab=sso`. Navigating to `/admin/orgs/eng?tab=users` opens Users tab directly. Useful for linking from User Management ("view org" → opens with users tab).

### 8.3 Tree Expand/Collapse

- **State**: `expandedNodes: Set<string>` in `OrgTree` component
- **Persist**: `sessionStorage` so refreshing keeps expansion state
- **Default**: Auto-expand path to selected node on initial load (walk ancestors of `orgId` from URL)
- **Chevron**: Rotate 90° transition. Hidden (`invisible`) for leaf nodes.
- **Children indentation**: `ml-7` + `border-l border-border/50` visual connector line

### 8.4 SSO Toggle — Optimistic with Cascading Side Effects

This is the **highest-risk interaction** on the page:

1. Admin flips SSO toggle → optimistic: icon goes green/gray, title changes, toast fires
2. `PATCH /api/admin/orgs/{orgId} { ssoEnabled }` fires
3. **On success**: Invalidate tree cache (SSO badge on tree node must update)
4. **On failure**: Revert toggle, revert icon/title, show error toast
5. **Side effect**: If SSO disabled, all future QR codes for this org exclude SSO block. **Existing provisioned users are unaffected** — clarify in confirmation dialog before disabling.

```
⚠️ Disable SSO for Engineering?

Users already provisioned with SSO will keep their access.
New QR codes will only include UC configuration.

[Cancel]  [Disable SSO]
```

### 8.5 QR Settings Toggles — Optimistic

Same pattern as SSO: toggle immediately, `PATCH` in background, rollback on error. The `config-item-value` text ("Enabled (Recommended)" / "Disabled") must update in sync with toggle state.

### 8.6 Child Org Click → Navigate

Child org items in the Overview tab are clickable. Clicking navigates to that org's detail: `setSelectedOrgId(childId)` → URL updates → tree auto-expands to show child → detail panel re-renders.

### 8.7 User Row Click → Cross-Feature Navigate

Clicking a user row in the Users tab navigates to User Management detail: `/admin/users/:userId`. This is a cross-feature link — the host app's router handles it.

### 8.8 DN Display — Always Monospace

All DN values (tree meta, panel subtitle, info items) use `font-mono text-xs` (JetBrains Mono). These are copy-on-click targets — add a tiny clipboard icon on hover.

### 8.9 Import LDAP — Async Job

The "Import LDAP" button triggers an async job. Pattern:
1. Click → confirmation modal ("This will sync org structure from LDAP. Continue?")
2. `POST /api/admin/orgs/import-ldap` → returns `jobId`
3. Poll or WebSocket for job status
4. On complete: invalidate tree cache, show success toast with diff summary ("Added 3 orgs, updated 2")

---

## 9. BaseUI Override Patterns

### 9.1 Tabs (Detail Panel)

```tsx
<Tabs
  activeKey={activeTab}
  onChange={({ activeKey }) => setTab(activeKey)}
  overrides={{
    TabList: {
      style: {
        backgroundColor: 'var(--org-surface-tertiary)',
        paddingLeft: '20px',
        borderBottom: '1px solid var(--org-border-subtle)',
      },
    },
    Tab: {
      style: ({ $active }) => ({
        color: $active ? 'var(--org-text-primary)' : 'var(--org-text-muted)',
        borderBottom: $active ? '2px solid var(--org-accent-primary)' : '2px solid transparent',
        paddingTop: '12px',
        paddingBottom: '12px',
        ':hover': { color: 'var(--org-text-secondary)' },
      }),
    },
  }}
>
```

### 9.2 Toggle (SSO + QR Settings)

```tsx
<Checkbox
  checked={ssoEnabled}
  onChange={(e) => handleSSOToggle(e.target.checked)}
  checkmarkType={STYLE_TYPE.toggle}
  overrides={{
    Toggle: {
      style: ({ $checked }) => ({
        width: '44px',
        height: '24px',
        backgroundColor: $checked ? 'var(--org-success)' : 'var(--org-surface-overlay)',
      }),
    },
    ToggleTrack: {
      style: ({ $checked }) => ({
        backgroundColor: $checked ? 'var(--org-success)' : 'var(--org-surface-overlay)',
      }),
    },
  }}
/>
```

### 9.3 Select (Parent Org in Create Modal)

```tsx
<Select
  options={flattenedOrgs.map(org => ({
    label: org.name,
    id: org.id,
    description: org.dn, // show DN as secondary text
  }))}
  placeholder="Root (dc=example,dc=com)"
  overrides={{
    ControlContainer: {
      style: {
        backgroundColor: 'var(--org-surface-tertiary)',
        borderColor: 'var(--org-border-subtle)',
      },
    },
    OptionContent: {
      style: { fontFamily: "'Outfit', sans-serif" },
    },
  }}
/>
```

---

## 10. File Structure

```
src/features/org-management/
├── OrgManagementPage.tsx
├── components/
│   ├── PageHeader.tsx
│   ├── OrgTree/
│   │   ├── OrgTree.tsx               ← container: tree-header + scrollable tree
│   │   ├── TreeNode.tsx              ← recursive node component
│   │   ├── TreeExpandToggle.tsx      ← chevron button (expand/collapse)
│   │   ├── OrgNodeIcon.tsx           ← colored icon per type
│   │   └── SSOBadge.tsx              ← "SSO" / "No SSO" pill
│   ├── OrgDetail/
│   │   ├── OrgDetailPanel.tsx        ← container: header + tabs + content
│   │   ├── PanelHeader.tsx           ← large icon, name, DN, edit button
│   │   ├── DetailTabs.tsx            ← BaseUI Tabs wrapper
│   │   ├── OverviewTab.tsx           ← stats + details + children
│   │   ├── SSOConfigTab.tsx          ← status card + OIDC config + endpoints
│   │   ├── UsersTab.tsx              ← user list table
│   │   ├── ProvisioningTab.tsx       ← UC config + QR settings
│   │   ├── StatsRow.tsx              ← 4-up stat cards
│   │   ├── ChildOrgItem.tsx          ← clickable child org card
│   │   ├── OrgUserRow.tsx            ← single user row in Users tab
│   │   ├── SSOStatusCard.tsx         ← icon + info + toggle
│   │   └── QRSettingItem.tsx         ← config item with optional toggle
│   └── Modals/
│       ├── CreateOrgModal.tsx
│       └── EditSSOModal.tsx          ← stub for Phase 2
├── hooks/
│   ├── useOrgTree.ts                 ← fetches tree, manages expansion state
│   ├── useOrgDetail.ts              ← fetches org detail by ID
│   ├── useOrgUsers.ts               ← paginated users for selected org
│   ├── useOrgMutations.ts           ← create org, toggle SSO, update QR settings
│   └── useTreeExpansion.ts          ← expand/collapse state + sessionStorage persistence
├── types.ts                          ← all interfaces from §4
└── constants.ts                      ← ORG_NODE_STYLES, STATUS_STYLES, ORG_TABS
```

---

## 11. Shared Components (extract to `src/shared/`)

| Component | Used By | Notes |
|---|---|---|
| `<InfoItem />` | OrgManagement, GroupManagement, UserManagement | label + value card, `.mono` variant |
| `<StatusBadge />` | OrgManagement (users tab), UserManagement | active/pending/inactive status pill |
| `<Toggle />` | OrgManagement (SSO, QR settings), GroupManagement (permissions) | BaseUI Checkbox toggle wrapper with standard overrides |
| `<ConfigItem />` | OrgManagement (QR settings, child orgs), could be reused | icon + label + value + optional right element |

---

## 12. Integration Contract

**Host app provides:**
- Sidebar navigation, layout shell
- Auth context (current admin's permissions)
- Toast/notification system
- Routing: `/admin/orgs`, `/admin/orgs/:orgId`, `/admin/orgs/:orgId?tab=sso`
- API client configuration
- Modal portal root

**Feature owns:**
- `OrgManagementPage` route component + all children
- Data fetching for org tree, org detail, org users
- Tree expansion state management
- Tab state management (URL-synced)

---

## 13. Cross-Feature Relationships

```
┌──────────────────────────────────┐
│       Organization Management     │
│                                  │
│  ssoEnabled toggle ──────────────┼──► QR Generation (User Mgmt)
│  │                               │    If SSO disabled for org,
│  │                               │    QR codes EXCLUDE sso block
│  │                               │
│  ucConfig (domains, WSS URLs) ───┼──► QR payload composition
│  │                               │    UC config → ucConfig block
│  │                               │
│  qrSettings (validity, OTT) ─────┼──► QR Generation defaults
│  │                               │    Pre-fills validity dropdown
│  │                               │
│  Users tab → row click ──────────┼──► /admin/users/:userId
│  │                               │    Cross-feature navigation
│  │                               │
│  Child org click ────────────────┼──► /admin/orgs/:childId
│                                  │    Intra-feature navigation
└──────────────────────────────────┘

Groups → Orgs:
  - Group's parentOrgId links to an org → "Parent Org" field in group detail

Users → Orgs:
  - User's org membership → "Organization" field in user detail links here
  - User termination → no org-level cascade (user is removed from LDAP OU server-side)

Orgs → Provisioning flow:
  - When admin generates QR for user in org X:
    1. Fetch org X's ucConfig → populate UC block
    2. Check org X's ssoEnabled → conditionally include SSO block
    3. Use org X's qrSettings.defaultValidityMinutes as pre-selected validity
```

---

## 14. Migration Order (Phased)

### Phase 1: Shell + Tree (Week 1)
1. **Shell**: `OrgManagementPage`, `PageHeader`
2. **Tree**: `OrgTree`, `TreeNode` (recursive), `TreeExpandToggle`, `OrgNodeIcon`, `SSOBadge`
3. **Hook**: `useOrgTree`, `useTreeExpansion` (sessionStorage persistence)

### Phase 2: Detail Panel — Metadata (Week 1–2)
4. **Detail container**: `OrgDetailPanel`, `PanelHeader`, `DetailTabs`
5. **Overview tab**: `OverviewTab`, `StatsRow`, `StatCard`, `OrgDetailsSection`, `ChildOrgsSection`, `ChildOrgItem`
6. **Hook**: `useOrgDetail`

### Phase 3: Detail Panel — SSO (Week 2)
7. **SSO tab**: `SSOConfigTab`, `SSOStatusCard`, OIDC info grid, Endpoints info grid
8. **SSO toggle**: Optimistic mutation + tree badge cache invalidation + confirmation dialog for disable
9. **Hook**: `useOrgMutations` (SSO toggle, SSO config update)

### Phase 4: Detail Panel — Users + Provisioning (Week 2–3)
10. **Users tab**: `UsersTab`, `OrgUserList`, `OrgUserRow` (with cross-feature navigation)
11. **Provisioning tab**: `ProvisioningTab`, UC config info grid, `QRSettingItem` with toggles
12. **Hook**: `useOrgUsers` (paginated)

### Phase 5: Modals + Polish (Week 3)
13. **Create Org**: `CreateOrgModal` (name + key + parent select + SSO toggle)
14. **Edit SSO**: `EditSSOModal` (stub — inputs for issuer, client ID, scopes, PKCE)
15. **Import LDAP**: Async job flow (confirmation → poll → toast)
16. **Polish**: Keyboard shortcuts (arrow keys for tree nav), copy-on-click for DNs, auto-expand to selected node on load

---

## 15. Key Risks & Gotchas

| Risk | Impact | Mitigation |
|---|---|---|
| **Recursive tree rendering** perf with 100+ nodes | Janky expand/collapse | Virtualize with `react-arborist` or flatten + indent. Memoize `TreeNode` aggressively. |
| **SSO toggle side effects** not obvious | Admin disables SSO, doesn't realize future QRs are affected | Confirmation dialog with explicit consequence text (see §8.4) |
| **Stale tree after SSO toggle** | Tree badge shows "SSO" but org SSO is now off | Invalidate `['orgTree']` cache on SSO toggle mutation success |
| **Parent org select** in Create Modal needs current tree | Stale if another admin added orgs | Use tree cache; add "refresh" option in select dropdown |
| **DN values truncation** on narrow panels | Long DNs unreadable | `word-break: break-all` (already in prototype) + copy-on-click |
| **Tab + orgId URL sync** race condition | User clicks tree node while tab change is in-flight | Tab resets to `overview` on org change (deliberate UX choice) |
