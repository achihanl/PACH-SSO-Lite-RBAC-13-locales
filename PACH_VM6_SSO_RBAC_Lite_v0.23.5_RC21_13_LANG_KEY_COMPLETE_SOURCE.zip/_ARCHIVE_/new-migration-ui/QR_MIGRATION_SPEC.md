# QR Code Management — React Migration Spec

> **Source**: `qr-codes-content-only.html`
> **Target**: React (BaseUI + Tailwind CSS)
> **Scope**: Content only — no layout shell (sidebar, topbar, app-container)

---

## 1. Component Tree

```
QRCodesPage/
├── QRPageHeader                    ← page title + actions bar
│   ├── SearchInput                 ← BaseUI Input w/ startEnhancer
│   ├── DateRangeSelect             ← BaseUI Select
│   ├── Button[BulkGenerate]        ← BaseUI Button KIND.secondary
│   └── Button[GenerateQR]         ← BaseUI Button KIND.primary
│
├── StatsRow                        ← 4-col grid
│   └── StatCard × 4               ← card with icon, value, label, trend
│
├── QRGrid                          ← 2-col grid (list + detail)
│   ├── QRListPanel                 ← left column
│   │   ├── ListHeader
│   │   │   ├── ListTitle + Count
│   │   │   └── FilterTabs          ← BaseUI ButtonGroup or custom tabs
│   │   └── QRTable                 ← virtualized if >100 rows
│   │       ├── QRTableHeader       ← sticky header row
│   │       └── QRTableRow × N      ← selectable rows
│   │           ├── UserCell        ← avatar + name + org
│   │           ├── StatusBadge     ← consumed|pending|expired|revoked
│   │           ├── DeviceCell
│   │           ├── TimeCell
│   │           └── RowActions      ← icon buttons, visible on hover
│   │
│   └── QRDetailPanel               ← right column (sticky)
│       ├── PanelHeader
│       │   ├── QRPreview           ← QR code SVG thumbnail
│       │   ├── UserSummary         ← name, email, QR ID
│       │   └── PanelActions        ← Resend / Regenerate buttons
│       └── PanelContent            ← scrollable
│           ├── InfoSection[QR Details]
│           │   └── InfoGrid        ← 2-col key/value pairs
│           ├── InfoSection[Device]
│           │   └── InfoGrid
│           ├── ProvisionChecklist  ← XMPP / SIP / SSO status
│           └── ActivityTimeline    ← vertical event timeline
│               └── TimelineItem × N
│
├── GenerateQRModal                 ← BaseUI Modal
│   ├── UserSelect                  ← BaseUI Select (async search)
│   ├── ValidityPicker              ← BaseUI SegmentedControl or ButtonGroup
│   └── DeliveryMethodSelect       ← BaseUI Select
│
└── ToastProvider                   ← BaseUI Toaster (singleton)
```

---

## 2. Component Decomposition Map

### 2.1 Page-Level

| Component | Source Element | BaseUI Mapping | Tailwind Layout | Notes |
|---|---|---|---|---|
| `QRCodesPage` | `<div class="content-area">` | — | Container, `p-6` | Route component, owns all state |
| `QRPageHeader` | `<div class="page-header">` | — | `flex items-center justify-between flex-wrap gap-4 pb-6` | Slots into existing layout's content header |

### 2.2 Stats Row

| Component | Source Element | BaseUI Mapping | Tailwind Layout | Props |
|---|---|---|---|---|
| `StatsRow` | `<div class="stats-row">` | — | `grid grid-cols-4 gap-4 mb-6` (responsive: `grid-cols-2`, `grid-cols-1`) | `stats: StatData[]` |
| `StatCard` | `<div class="stat-card">` | `Card` | `p-5 rounded-xl` | `{ icon, value, label, trend?, variant }` |
| `StatTrend` | `<span class="stat-trend">` | — | `flex items-center gap-1 text-xs font-medium` | `{ direction: 'up'|'down', value: string }` |

**Type:**
```ts
type StatData = {
  icon: ReactNode;
  value: number;
  label: string;
  variant: 'blue' | 'green' | 'amber' | 'red';
  trend?: { direction: 'up' | 'down'; value: string };
};
```

### 2.3 QR Grid (Master-Detail)

| Component | Source Element | BaseUI Mapping | Tailwind Layout | Notes |
|---|---|---|---|---|
| `QRGrid` | `<div class="qr-grid">` | — | `grid grid-cols-[1fr_420px] gap-6` | Collapses to single-col `<1100px` via `@container` or media query |
| `QRListPanel` | `<div class="qr-list-container">` | `Card` | `flex flex-col overflow-hidden` | Contains header + scrollable table |
| `QRDetailPanel` | `<div class="qr-detail-panel">` | `Card` | `flex flex-col overflow-hidden sticky top-20` | Shows selected row's details |

### 2.4 List & Table

| Component | Source Element | BaseUI Mapping | Tailwind Layout | Props |
|---|---|---|---|---|
| `ListHeader` | `<div class="list-header">` | — | `flex items-center justify-between p-4 px-5 border-b` | title, count, filter tabs |
| `FilterTabs` | `<div class="filter-tabs">` | `ButtonGroup` (SIZE.mini) | `flex gap-1 p-1 rounded-lg bg-muted` | `{ tabs, activeTab, onChange }` |
| `QRTable` | `<div class="qr-table">` | — | `w-full` | Consider `@tanstack/react-table` for sorting/filtering |
| `QRTableHeader` | `<div class="qr-table-header">` | — | `grid grid-cols-[2fr_100px_120px_100px_80px] gap-4 px-5 py-3 sticky top-0` | Column labels |
| `QRTableRow` | `<div class="qr-table-row">` | — | Same grid, `px-5 py-3.5 cursor-pointer hover:bg-muted border-b` | `{ qr: QRCode, selected, onClick }` |

**Type:**
```ts
type QRStatus = 'consumed' | 'pending' | 'expired' | 'revoked';

type QRCode = {
  id: string;              // "QR-2026-0156"
  user: {
    name: string;
    org: string;
    initials: string;
    avatarGradient: [string, string];
  };
  status: QRStatus;
  device: string | null;
  createdAt: string;       // ISO timestamp
  consumedAt?: string;
  validity: number;        // minutes
  generatedBy: string;
  deviceInfo?: {
    name: string;
    os: string;
    appVersion: string;
    ip: string;
  };
  provisioning: ProvisionItem[];
  timeline: TimelineEvent[];
};
```

### 2.5 Detail Panel Sub-Components

| Component | Source Element | BaseUI Mapping | Tailwind Notes | Props |
|---|---|---|---|---|
| `QRPreview` | `<div class="panel-qr-code">` | — | `w-[100px] h-[100px] bg-white rounded-lg flex-shrink-0` | `{ qrData: string }` — render with `qrcode` lib |
| `UserSummary` | `<div class="panel-qr-details">` | — | — | `{ name, org, email, qrId }` |
| `MonoTag` | `<span class="panel-qr-id">` | `Tag` (closeable: false) | `font-mono text-xs bg-muted px-2 py-1 rounded` | QR ID display |
| `InfoSection` | `<div class="section">` | — | `mb-6` | `{ title: string, children }` |
| `InfoGrid` | `<div class="info-grid">` | — | `grid grid-cols-2 gap-3` | — |
| `InfoItem` | `<div class="info-item">` | — | `p-3 rounded-lg bg-muted` | `{ label, value, format?, semantic? }` |
| `ProvisionChecklist` | `<div class="provision-includes">` | — | `flex flex-col gap-2` | `{ items: ProvisionItem[] }` |
| `ActivityTimeline` | `<div class="timeline">` | — | `relative` (with `::before` pseudo vertical line) | `{ events: TimelineEvent[] }` |
| `TimelineItem` | `<div class="timeline-item">` | — | `flex gap-4 py-3` | `{ icon, title, meta, time, eventType }` |

**Types:**
```ts
type ProvisionItem = {
  service: 'xmpp' | 'sip' | 'sso';
  label: string;
  status: 'registered' | 'enrolled' | 'failed' | 'pending';
};

type TimelineEvent = {
  type: 'generated' | 'sent' | 'consumed' | 'expired' | 'revoked';
  title: string;
  meta: string;
  timestamp: string; // "10:23:42"
};
```

### 2.6 Modal

| Component | Source Element | BaseUI Mapping | Tailwind Notes | Notes |
|---|---|---|---|---|
| `GenerateQRModal` | `<div class="modal-overlay">` | `Modal` | — | `{ isOpen, onClose, onGenerate }` |
| `UserSelect` | `<select>` (user) | `Select` (searchable, async) | — | Fetch from user API |
| `ValidityPicker` | `<div class="validity-options">` | `SegmentedControl` or `ButtonGroup` | `flex gap-2` | `{ options, selected, onChange }` |
| `DeliverySelect` | `<select>` (delivery) | `Select` | — | Static options |

### 2.7 Shared / Utility

| Component | Source Element | BaseUI Mapping | Tailwind Notes |
|---|---|---|---|
| `StatusBadge` | `<span class="qr-status">` | `Tag` or custom | `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium` |
| `UserAvatar` | `<div class="qr-user-avatar">` | `Avatar` | `w-9 h-9 rounded-full` — gradient background via inline style |
| `IconButton` | `<button class="qr-action-btn">` | `Button` (KIND.tertiary, SIZE.mini) | `w-7 h-7` |
| `SearchInput` | `<div class="search-box">` | `Input` with `startEnhancer={<SearchIcon />}` | — |
| `ToastProvider` | `<div class="toast-container">` | `toaster` (from `baseui/toast`) | — |

---

## 3. Status Color Token Map

The prototype uses hardcoded CSS colors. Map these to your design system's semantic tokens:

| Status | Prototype CSS | Tailwind Mapping | Usage |
|---|---|---|---|
| `consumed` | `bg: rgba(34,197,94,0.1)`, `color: #22c55e` | `bg-green-500/10 text-green-500` | Badge bg + text, timeline icon, info-value |
| `pending` | `bg: rgba(245,158,11,0.1)`, `color: #f59e0b` | `bg-amber-500/10 text-amber-500` | Badge, timeline icon |
| `expired` | `bg: #18181b`, `color: #71717a` | `bg-zinc-800 text-zinc-500` | Badge, timeline icon |
| `revoked` | `bg: rgba(239,68,68,0.1)`, `color: #ef4444` | `bg-red-500/10 text-red-500` | Badge, timeline icon |
| `generated` | `bg: rgba(59,130,246,0.1)`, `color: #3b82f6` | `bg-blue-500/10 text-blue-500` | Timeline icon only |
| `sent` | `bg: rgba(168,85,247,0.1)`, `color: #a855f7` | `bg-purple-500/10 text-purple-500` | Timeline icon only |

**Recommendation:** Create a `statusConfig` lookup:

```ts
const STATUS_CONFIG: Record<QRStatus, { bg: string; text: string; dot: string; icon: ComponentType }> = {
  consumed: { bg: 'bg-green-500/10', text: 'text-green-500', dot: 'bg-green-500', icon: CheckCircleIcon },
  pending:  { bg: 'bg-amber-500/10', text: 'text-amber-500', dot: 'bg-amber-500', icon: ClockIcon },
  expired:  { bg: 'bg-zinc-800',     text: 'text-zinc-500',  dot: 'bg-zinc-500',  icon: XCircleIcon },
  revoked:  { bg: 'bg-red-500/10',   text: 'text-red-500',   dot: 'bg-red-500',   icon: ShieldOffIcon },
};
```

---

## 4. State Architecture

```
┌─────────────────────────────────────────────────┐
│  QRCodesPage (route-level state owner)          │
│                                                 │
│  State:                                         │
│  ├── qrCodes: QRCode[]        ← API data        │
│  ├── selectedId: string|null  ← row selection    │
│  ├── filterTab: 'all'|status  ← active filter    │
│  ├── searchQuery: string      ← debounced        │
│  ├── dateRange: DateRange     ← select value      │
│  ├── isGenerateOpen: boolean  ← modal state       │
│  └── stats: StatData[]        ← derived/API       │
│                                                 │
│  Derived:                                        │
│  ├── filteredQRs = filter(qrCodes, tab, search)  │
│  └── selectedQR = qrCodes.find(id)               │
│                                                 │
│  Actions (API mutations):                        │
│  ├── generateQR(userId, validity, delivery)      │
│  ├── resendQR(qrId)                              │
│  ├── regenerateQR(qrId)                          │
│  └── navigateToAudit(qrId)   ← router.push       │
└─────────────────────────────────────────────────┘
```

**Data fetching:** Use `@tanstack/react-query` or your existing pattern. The table data, stats, and detail panel all derive from the same `qrCodes` query. Detail panel device info + timeline may require a secondary query keyed on `selectedId`.

---

## 5. Interaction Behavior Spec

| Interaction | Current (HTML) | React Implementation |
|---|---|---|
| Row selection | `classList.add('selected')` | `selectedId` state → conditional `data-selected` or className |
| Filter tabs | Manual DOM toggle | `filterTab` state → filter `qrCodes` array |
| Search | No-op (static) | `searchQuery` state → debounced 300ms → filter or API param |
| Date range | No-op (static) | `dateRange` state → API param → refetch |
| Generate modal | `classList.add('active')` | `isGenerateOpen` state → BaseUI `Modal isOpen` |
| Validity picker | Manual selected class | Local state in modal → `SegmentedControl` `activeKey` |
| Toast | DOM injection | `toaster.positive()` from BaseUI |
| Audit log link | `window.location.href` | `router.push('/audit-log?qr=${qrId}')` |
| Row hover actions | CSS `opacity: 0` → `1` on hover | Same CSS, or use `group-hover:opacity-100` in Tailwind |

---

## 6. Responsive Breakpoints

| Breakpoint | Layout Change |
|---|---|
| `≥1100px` | Full 2-col grid (list + detail panel) |
| `<1100px` | Single column — detail panel below list OR opens as a slide-over |
| `≥900px` | Stats: 4 columns |
| `<900px` | Stats: 2 columns |
| `<500px` | Stats: 1 column, search collapses to icon trigger |

---

## 7. Data Attributes for E2E Testing

The content-only HTML includes `data-*` attributes for component identification. Preserve these as `data-testid` in React:

```
data-component="QRTable"       → data-testid="qr-table"
data-qr-id="QR-2026-0156"      → data-testid="qr-row-QR-2026-0156"
data-status="consumed"          → data-testid="status-badge-consumed"
data-action="resend"            → data-testid="btn-resend"
data-action="regenerate"        → data-testid="btn-regenerate"
data-action="audit"             → data-testid="btn-audit-link"
```

---

## 8. Migration Checklist

```
Phase 1: Scaffold
  [ ] Create QRCodesPage route component
  [ ] Wire up API hooks (list QRs, stats)
  [ ] Implement StatsRow + StatCard

Phase 2: Table
  [ ] QRListPanel with FilterTabs
  [ ] QRTable with QRTableRow (selection state)
  [ ] StatusBadge + UserAvatar shared components
  [ ] SearchInput with debounced filtering

Phase 3: Detail Panel
  [ ] QRDetailPanel with InfoGrid sections
  [ ] ProvisionChecklist
  [ ] ActivityTimeline
  [ ] Cross-link to Audit Log page

Phase 4: Actions
  [ ] GenerateQRModal (BaseUI Modal + form)
  [ ] Resend / Regenerate API mutations
  [ ] Toast notifications
  [ ] Bulk generate flow (stub or implement)

Phase 5: Polish
  [ ] Responsive breakpoints
  [ ] Keyboard navigation (arrow keys for row selection)
  [ ] Empty states (no QRs, no results, no selection)
  [ ] Loading skeletons for table + detail panel
```

---

## 9. Files to Strip (NOT Migrated)

These are present in the original `qr-codes.html` but are part of the app shell and should **not** be in the page component:

| Element | Lines | Reason |
|---|---|---|
| `<aside class="sidebar">` | 419–507 | App-level `<AppShell>` owns this |
| `<header class="topbar">` | 511–541 | App-level `<TopBar>` owns this |
| `<div class="app-container">` | 417 | App-level layout wrapper |
| `body` / `:root` CSS vars | 11–56 | Global theme layer |
| Sidebar CSS (`.sidebar`, `.nav-*`) | 61–106 | App shell styles |
| Topbar CSS (`.topbar`, `.main-content`) | 108–127 | App shell styles |
| Scrollbar CSS | 401–404 | Global styles |
| Font imports | 7–9 | Global `<head>` |

All of these already exist in your React app's layout. The content-only HTML starts at the `<div class="page-header">` and ends at the toast container.
