# QR Provisioning Admin — React Migration Spec

> **Target stack**: React 18+ · BaseUI (Uber) · Tailwind CSS · Lucide icons  
> **Source**: `qr-admin-content-only.html` (layout-stripped prototype)  
> **Assumption**: Host app provides sidebar, topbar, routing, auth context, and toast system.

---

## 1. Component Tree

```
<UserManagementPage>                    ← route-level page component
├── <PageHeader />                      ← title + search + "Add User" CTA
│   ├── <SearchInput />                 ← BaseUI Input w/ ⌘K shortcut
│   └── <Button>Add User</Button>       ← BaseUI Button
│
├── <UsersGrid>                         ← CSS Grid split-panel (1fr 400px)
│   ├── <UserList>                      ← left panel
│   │   ├── <ListHeader />              ← count + filter tabs
│   │   │   └── <FilterTabs />          ← BaseUI SegmentedControl or ButtonGroup
│   │   └── <UserRow />[]               ← virtualized list (react-window)
│   │       ├── <Avatar />              ← BaseUI Avatar w/ gradient bg
│   │       ├── <UserMeta />            ← name + email
│   │       └── <StatusBadge />         ← active/pending/inactive
│   │
│   └── <UserDetailPanel>               ← right panel
│       ├── <PanelHeader />             ← avatar, name, action buttons
│       ├── <ProvisioningStatus />      ← 2-col grid of StatusCard
│       │   └── <StatusCard />          ← UC / SSO status
│       ├── <QRHistory />               ← list of QRHistoryItem
│       │   └── <QRHistoryItem />       ← icon + date + status + audit link
│       └── <DangerZone />              ← terminate button
│
├── <QRGenerationModal />               ← BaseUI Modal
│   ├── <QRCodeDisplay />               ← actual QR (use `qrcode.react`)
│   ├── <ValiditySelector />            ← BaseUI SegmentedControl
│   ├── <ExpiryBanner />                ← computed absolute time
│   ├── <ProvisioningIncludes />        ← checklist
│   ├── <DeliveryOptions />             ← 4-button grid
│   └── <OneTimeWarning />              ← amber callout
│
├── <TerminationModal />                ← BaseUI Modal
│   ├── <TerminationPreview />          ← checkbox list w/ counts
│   └── <TerminationReasonInput />      ← BaseUI Textarea (required)
│
└── <TerminationSuccessModal />         ← BaseUI Modal
    ├── <SuccessIcon />
    ├── <TerminationLog />              ← timestamp list
    └── <AuditDownloadButton />
```

---

## 2. Component → BaseUI + Tailwind Mapping

| Prototype Element | React Component | BaseUI Primitive | Tailwind Notes |
|---|---|---|---|
| `.search-box` | `<SearchInput />` | `Input` w/ `startEnhancer` (icon) + `endEnhancer` (kbd) | `w-70` fixed, ring on focus |
| `.filter-tabs` | `<FilterTabs />` | `SegmentedControl` or `ButtonGroup` | `bg-surface-raised p-1 rounded-lg` |
| `.user-row` | `<UserRow />` | Custom `<li>` (not BaseUI — needs row click + selection) | `hover:bg-surface-raised` + `border-l-3 border-accent-primary` when selected |
| `.status-badge` | `<StatusBadge />` | `Tag` with `KIND.custom` | Map variant→color: `active`=success, `pending`=warning, `inactive`=muted |
| `.btn-primary` | — | `Button` `kind={KIND.primary}` | — |
| `.btn-secondary` | — | `Button` `kind={KIND.secondary}` | — |
| `.btn-danger` | — | `Button` `kind={KIND.tertiary}` + danger overrides | `bg-danger/10 text-danger hover:bg-danger/20` |
| `.modal-overlay` | — | `Modal` with `ROLE.dialog` | Backdrop blur via `overrides.Backdrop` |
| `.status-card` | `<StatusCard />` | Custom card (no BaseUI equivalent) | `bg-surface-raised border border-subtle rounded-lg p-3.5` |
| `.qr-history` | `<QRHistory />` | Custom list | Reuse `<ListItem>` pattern or custom |
| `.validity-option` | `<ValiditySelector />` | `SegmentedControl` | Selected state = `bg-accent-primary text-white` |
| `.delivery-btn` | `<DeliveryButton />` | `Button` `shape={SHAPE.square}` + `kind={KIND.secondary}` | `flex-col gap-1.5` override |
| `.termination-checkbox` | — | `Checkbox` with `checkmarkType={STYLE_TYPE.toggle}` or default | `accent-danger` |
| `.termination-reason textarea` | — | `Textarea` w/ required validation | — |
| Toast system | — | `toaster` from BaseUI (or host app's) | — |

---

## 3. State Architecture

### 3.1 Page-level State

```typescript
// URL state (query params or route)
interface UserManagementRoute {
  filter: 'all' | 'active' | 'pending';  // tab selection
  userId?: string;                         // selected user → detail panel
  search?: string;                         // search query
}

// Server state (react-query / SWR)
interface UserListQuery {
  queryKey: ['users', { filter, search, page }];
  // GET /api/admin/users?status={filter}&q={search}
}

interface UserDetailQuery {
  queryKey: ['user', userId];
  // GET /api/admin/users/{userId}
  // includes: provisioningStatus, qrHistory, ssoStatus
}
```

### 3.2 Modal State Machine

```
                    ┌──────────┐
              ┌────►│  closed  │◄──────────────────┐
              │     └────┬─────┘                    │
              │          │ openQR()                  │ close()
              │          ▼                           │
              │     ┌──────────┐   regenerate()  ┌──┴───────┐
              │     │ qr_open  │────────────────►│ qr_open  │
              │     └──────────┘                 └──────────┘
              │
              │     openTermination()
              │          │
              │          ▼
              │     ┌──────────────┐  confirm()  ┌─────────────┐
              └─────│ term_confirm │────────────►│ term_success │
                    └──────────────┘             └─────────────┘
```

```typescript
type ModalState =
  | { type: 'closed' }
  | { type: 'qr_generation'; userId: string; validity: 15 | 60 | 240 | 1440 }
  | { type: 'termination_confirm'; userId: string; userName: string }
  | { type: 'termination_success'; auditId: string; log: TerminationLogEntry[] };
```

### 3.3 QR Generation Flow

```typescript
// Mutation: POST /api/admin/users/{userId}/qr
interface GenerateQRMutation {
  input: { validityMinutes: number };
  output: {
    token: string;         // one-time token
    qrDataUrl: string;     // or raw payload for qrcode.react
    expiresAt: string;     // ISO timestamp
    deepLink: string;      // azblink://provision?token=...
    includes: ('uc' | 'sso')[];
  };
}

// Delivery actions (fire-and-forget mutations)
// POST /api/admin/users/{userId}/qr/{token}/deliver
interface DeliverQRMutation {
  input: { method: 'email' | 'sms'; };
}
```

### 3.4 Termination Flow

```typescript
// Mutation: POST /api/admin/users/{userId}/terminate
interface TerminateMutation {
  input: {
    reason: string;                    // required
    actions: {
      disableLdap: true;               // always true, not toggleable
      revokeUc: boolean;
      revokeSso: boolean;
      invalidateQr: boolean;
    };
  };
  output: {
    auditId: string;
    log: Array<{
      action: string;
      completedAt: string;             // ISO timestamp
      status: 'success' | 'failed' | 'queued';
    }>;
  };
}
```

---

## 4. Token Contract (Tailwind ↔ App Theme)

The content-only HTML uses `--qr-*` CSS custom properties. In your Tailwind config, map these to your existing design system tokens:

```javascript
// tailwind.config.js — extend theme
module.exports = {
  theme: {
    extend: {
      colors: {
        // Map to whatever your app's token names are
        'qr-text-primary':    'var(--your-text-primary)',
        'qr-text-secondary':  'var(--your-text-secondary)',
        'qr-text-muted':      'var(--your-text-muted)',
        'qr-surface':         'var(--your-bg-surface)',
        'qr-surface-raised':  'var(--your-bg-surface-raised)',
        'qr-surface-overlay': 'var(--your-bg-surface-overlay)',
        'qr-border-subtle':   'var(--your-border-subtle)',
        'qr-border-default':  'var(--your-border-default)',
        'qr-accent-primary':  'var(--your-accent-primary)',
        'qr-success':         'var(--your-success)',
        'qr-warning':         'var(--your-warning)',
        'qr-danger':          'var(--your-danger)',
      }
    }
  }
};
```

**Or** (better if your app already has these tokens): just use your existing Tailwind utility classes directly and skip the `--qr-*` indirection entirely. The HTML prototype's token names exist solely as a reference map.

---

## 5. Integration Checklist

### What the host app provides (don't rebuild):
- [ ] Sidebar navigation
- [ ] Top-level layout shell
- [ ] Auth context (current admin user)
- [ ] Toast/notification system
- [ ] Routing (`/admin/users`, `/admin/users/:id`)
- [ ] API client configuration (base URL, auth headers)
- [ ] Modal portal root

### What this feature owns:
- [ ] `<UserManagementPage />` — route component
- [ ] All child components in the tree above
- [ ] QR code generation (use `qrcode.react` for client-side rendering)
- [ ] Keyboard shortcut registration (`⌘K` → search, `Esc` → close modals)
- [ ] Data fetching for user list + detail + QR history

---

## 6. BaseUI Override Patterns

BaseUI's override API is your primary styling escape hatch. Key overrides needed:

```tsx
// Modal — backdrop blur
<Modal overrides={{
  Backdrop: { style: { backdropFilter: 'blur(4px)' } },
  Dialog: { style: ({ $theme }) => ({
    borderRadius: $theme.borders.radius400,
    border: `1px solid ${$theme.colors.borderOpaque}`,
  })},
}}>

// SegmentedControl — validity selector
<SegmentedControl overrides={{
  Root: { style: { backgroundColor: 'var(--surface-raised)' } },
  Active: { style: { backgroundColor: 'var(--accent-primary)' } },
}}>

// Input — search with keyboard hint
<Input
  startEnhancer={<SearchIcon size={18} />}
  endEnhancer={<Kbd>⌘K</Kbd>}
  overrides={{
    Root: { style: { width: '280px' } },
  }}
/>
```

---

## 7. Critical Behaviors to Preserve

| Behavior | Implementation Note |
|---|---|
| **Absolute expiry time** ("4:30 PM today") | Compute on QR generation, not relative countdown. `expiresAt` from API → `format(expiresAt, 'h:mm a')` + "today" / date. |
| **One-time use warning** | Always visible in QR modal. Not dismissible. |
| **Termination reason required** | `<Textarea>` with form-level validation. Disable confirm button until non-empty. |
| **Selected user = URL state** | `userId` in route params → detail panel renders. No local-only selection state. |
| **Filter tabs = URL state** | `?filter=pending` → tab active + list filtered server-side. |
| **⌘K → focus search** | `useEffect` with `keydown` listener. Dedupe with host app's command palette if one exists. |
| **Esc → close modals** | BaseUI Modal handles this natively. |
| **QR consumed status polling** | After generating QR, poll `GET /api/admin/qr/{token}/status` every 5s until consumed or expired. Update UI optimistically. |

---

## 8. File Structure

```
src/features/user-management/
├── UserManagementPage.tsx          ← route entry, layout grid
├── components/
│   ├── PageHeader.tsx
│   ├── SearchInput.tsx
│   ├── UserList/
│   │   ├── UserList.tsx            ← virtualized list container
│   │   ├── UserRow.tsx
│   │   ├── FilterTabs.tsx
│   │   └── StatusBadge.tsx
│   ├── UserDetail/
│   │   ├── UserDetailPanel.tsx
│   │   ├── PanelHeader.tsx
│   │   ├── ProvisioningStatus.tsx
│   │   ├── StatusCard.tsx
│   │   ├── QRHistory.tsx
│   │   ├── QRHistoryItem.tsx
│   │   └── DangerZone.tsx
│   └── Modals/
│       ├── QRGenerationModal.tsx
│       ├── QRCodeDisplay.tsx
│       ├── ValiditySelector.tsx
│       ├── DeliveryOptions.tsx
│       ├── TerminationModal.tsx
│       └── TerminationSuccessModal.tsx
├── hooks/
│   ├── useUsers.ts                 ← react-query: list + detail
│   ├── useQRGeneration.ts          ← mutation + polling
│   ├── useTermination.ts           ← mutation
│   └── useKeyboardShortcuts.ts
├── types.ts                        ← shared interfaces
└── constants.ts                    ← validity options, status enums
```

---

## 9. Migration Order

| Phase | Components | Depends On |
|---|---|---|
| **1. Shell** | `UserManagementPage`, `PageHeader`, `SearchInput` | Host app layout + routing |
| **2. List** | `UserList`, `UserRow`, `FilterTabs`, `StatusBadge` | `useUsers` hook, API endpoint |
| **3. Detail** | `UserDetailPanel`, `StatusCard`, `QRHistory` | User detail API |
| **4. QR Flow** | `QRGenerationModal`, `ValiditySelector`, `DeliveryOptions` | QR generation API |
| **5. Termination** | `TerminationModal`, `TerminationSuccessModal` | Termination API |
| **6. Polish** | Keyboard shortcuts, toast integration, QR status polling | All above |

Each phase is independently demoable. Ship phase 1-3 first for admin visibility, then 4-5 for provisioning actions.
