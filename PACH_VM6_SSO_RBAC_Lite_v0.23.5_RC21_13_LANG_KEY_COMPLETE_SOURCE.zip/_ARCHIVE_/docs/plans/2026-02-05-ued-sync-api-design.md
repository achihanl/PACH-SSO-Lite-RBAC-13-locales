# UED Sync API Architecture Design

> Config-driven LDAP synchronization service for multi-tenant UC (XMPP/SIP) provisioning, designed with Temporal migration path.

## Context

- **Problem:** AZBlink Directory needs to provision users to multiple UC deployments (potentially dozens), each with its own LDAP and potentially different schemas
- **Current state:** Schema is hardcoded in sync logic; schema changes require code changes and redeployment
- **Goal:** Dynamic schema configuration so schema changes don't require code redeployment

## Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Architecture | Separate microservice (Option B) | Decoupled from AZBlink Directory; horizontally scalable |
| Schema storage | PostgreSQL in AZBlink Directory | Single source of truth; no new infrastructure |
| Schema passing | In request payload | Stateless service; no config sync needed |
| LDAP operations | Generic, schema-driven | Worker code rarely changes; schema is config |
| Async processing | Deferred (Temporal-ready) | Start simple; clear migration path when needed |
| Service communication | REST/HTTP | Simple; can add message queue later |

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  AZBlink Directory (This Repo)                                              │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  PostgreSQL                                                           │  │
│  │  ┌─────────────────────────────────────────────────────────────────┐  │  │
│  │  │  uc_tenant_configs                                              │  │  │
│  │  │  - tenant_id, name, ldap_uri, bind_dn, bind_pw (encrypted)      │  │  │
│  │  │  - provisioning_schema (JSONB), auth_schema (JSONB)             │  │  │
│  │  │  - enabled, created_at, updated_at                              │  │  │
│  │  └─────────────────────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  UC Sync Client Module (src/backend/uc_sync_client.py)               │  │
│  │  - Fetches tenant config from DB                                     │  │
│  │  - Calls UED Sync API with schema + user data                        │  │
│  │  - Handles responses, logs audit events                              │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ HTTPS (mTLS in prod)
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  UED Sync API (Separate Service/Repo)                                       │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  REST Endpoints                                                       │  │
│  │  POST /api/v1/sync/user          (create/update/delete)              │  │
│  │  POST /api/v1/sync/user/suspend  (suspend/unsuspend)                 │  │
│  │  POST /api/v1/sync/user/password (password change)                   │  │
│  │  POST /api/v1/sync/auth/validate (test bind)                         │  │
│  │  GET  /api/v1/health             (health check)                      │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  Generic LDAP Operations Module                                       │  │
│  │  - Parses schema config from request                                  │  │
│  │  - Builds DN from template                                            │  │
│  │  - Maps user attributes per schema                                    │  │
│  │  - Executes LDAP add/modify/delete/search/bind                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                  ┌─────────────────┼─────────────────┐
                  ▼                 ▼                 ▼
           [Tenant A LDAP]   [Tenant B LDAP]   [Tenant N LDAP]
            XMPP/SIP #1       XMPP/SIP #2       XMPP/SIP #N
```

## Schema Configuration Data Structure

### Tenant Config Table (AZBlink Directory)

```sql
-- migrations/XXX_uc_tenant_configs.sql
CREATE TABLE uc_tenant_configs (
    tenant_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL UNIQUE,
    description     TEXT,

    -- LDAP Connection
    ldap_uri        VARCHAR(512) NOT NULL,  -- ldaps://ldap.example.com:636
    ldap_base_dn    VARCHAR(512) NOT NULL,  -- dc=example,dc=com
    ldap_bind_dn    VARCHAR(512) NOT NULL,  -- cn=sync,ou=services,dc=example,dc=com
    ldap_bind_pw    TEXT NOT NULL,          -- Encrypted with app key
    ldap_use_ssl    BOOLEAN DEFAULT TRUE,
    ldap_timeout_ms INTEGER DEFAULT 5000,

    -- Schema Configuration (JSONB for flexibility)
    provisioning_schema JSONB NOT NULL,
    auth_schema         JSONB NOT NULL,

    -- Operational
    enabled         BOOLEAN DEFAULT TRUE,
    sync_api_url    VARCHAR(512),           -- Override if tenant has dedicated sync API
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_uc_tenant_configs_enabled ON uc_tenant_configs(enabled) WHERE enabled = TRUE;
```

### Provisioning Schema (JSONB)

```json
{
  "version": "1.0",
  "user": {
    "dn_template": "uid={uid},ou=people,{base_dn}",
    "object_classes": ["inetOrgPerson", "posixAccount", "shadowAccount"],
    "attribute_map": {
      "uid": "{username}",
      "cn": "{display_name}",
      "sn": "{last_name}",
      "givenName": "{first_name}",
      "mail": "{email}",
      "telephoneNumber": "{phone}",
      "uidNumber": "{employee_id}",
      "gidNumber": "1000",
      "homeDirectory": "/home/{username}",
      "loginShell": "/bin/bash"
    },
    "required_fields": ["username", "display_name", "email"],
    "optional_fields": ["first_name", "last_name", "phone", "employee_id"],
    "password_attribute": "userPassword",
    "password_hash": "SSHA"
  },
  "suspension": {
    "method": "attribute",
    "attribute": "pwdAccountLockedTime",
    "suspended_value": "000001010000Z",
    "active_value": null
  },
  "deletion": {
    "method": "hard_delete",
    "soft_delete_attribute": null
  }
}
```

### Authentication Schema (JSONB)

```json
{
  "version": "1.0",
  "search": {
    "base_dn": "ou=people,{base_dn}",
    "filter_template": "(uid={username})",
    "scope": "subtree"
  },
  "bind": {
    "dn_template": "uid={username},ou=people,{base_dn}"
  },
  "return_attributes": ["uid", "cn", "mail", "memberOf", "telephoneNumber"],
  "group_membership": {
    "attribute": "memberOf",
    "extract_cn": true
  }
}
```

## UED Sync API Contract

### Base URL

```
Production: https://ued-sync.internal.example.com/api/v1
Development: http://localhost:8090/api/v1
```

### Authentication

Service-to-service authentication via:
- **Development:** Shared secret in `X-API-Key` header
- **Production:** mTLS with client certificate validation

### Endpoints

#### POST /api/v1/sync/user

Unified endpoint for create/update/delete user operations.

**Request:**

```json
{
  "operation": "create",  // "create" | "update" | "delete"
  "request_id": "uuid-for-idempotency",
  "ldap": {
    "uri": "ldaps://ldap.example.com:636",
    "base_dn": "dc=example,dc=com",
    "bind_dn": "cn=sync,ou=services,dc=example,dc=com",
    "bind_pw": "encrypted-or-vault-ref",
    "use_ssl": true,
    "timeout_ms": 5000
  },
  "schema": {
    "dn_template": "uid={uid},ou=people,{base_dn}",
    "object_classes": ["inetOrgPerson", "posixAccount"],
    "attribute_map": {
      "uid": "{username}",
      "cn": "{display_name}",
      "mail": "{email}"
    },
    "password_attribute": "userPassword",
    "password_hash": "SSHA"
  },
  "user": {
    "username": "alice",
    "display_name": "Alice Smith",
    "email": "alice@example.com",
    "password": "initial-password-or-null"
  }
}
```

**Response (Success):**

```json
{
  "ok": true,
  "request_id": "uuid-for-idempotency",
  "operation": "create",
  "dn": "uid=alice,ou=people,dc=example,dc=com",
  "attributes_set": ["uid", "cn", "mail", "objectClass"],
  "timestamp": "2026-02-05T10:30:00Z"
}
```

**Response (Error):**

```json
{
  "ok": false,
  "request_id": "uuid-for-idempotency",
  "error": {
    "code": "LDAP_ALREADY_EXISTS",
    "message": "Entry uid=alice,ou=people,dc=example,dc=com already exists",
    "ldap_result_code": 68,
    "retryable": false
  }
}
```

#### POST /api/v1/sync/user/suspend

Suspend or unsuspend a user account.

**Request:**

```json
{
  "operation": "suspend",  // "suspend" | "unsuspend"
  "request_id": "uuid",
  "ldap": { /* connection config */ },
  "schema": {
    "method": "attribute",
    "attribute": "pwdAccountLockedTime",
    "suspended_value": "000001010000Z",
    "active_value": null
  },
  "user": {
    "dn": "uid=alice,ou=people,dc=example,dc=com"
  }
}
```

#### POST /api/v1/sync/user/password

Change user password.

**Request:**

```json
{
  "request_id": "uuid",
  "ldap": { /* connection config */ },
  "schema": {
    "password_attribute": "userPassword",
    "password_hash": "SSHA"
  },
  "user": {
    "dn": "uid=alice,ou=people,dc=example,dc=com",
    "new_password": "new-secure-password"
  }
}
```

#### POST /api/v1/sync/auth/validate

Test user authentication (LDAP bind test).

**Request:**

```json
{
  "request_id": "uuid",
  "ldap": { /* connection config */ },
  "schema": {
    "search": {
      "base_dn": "ou=people,{base_dn}",
      "filter_template": "(uid={username})",
      "scope": "subtree"
    },
    "return_attributes": ["uid", "cn", "mail", "memberOf"]
  },
  "credentials": {
    "username": "alice",
    "password": "user-password"
  }
}
```

**Response (Success):**

```json
{
  "ok": true,
  "request_id": "uuid",
  "authenticated": true,
  "user": {
    "dn": "uid=alice,ou=people,dc=example,dc=com",
    "attributes": {
      "uid": "alice",
      "cn": "Alice Smith",
      "mail": "alice@example.com",
      "memberOf": ["cn=developers,ou=groups,dc=example,dc=com"]
    }
  }
}
```

### Error Codes

| Code | HTTP Status | Retryable | Description |
|------|-------------|-----------|-------------|
| `LDAP_CONNECT_FAILED` | 503 | Yes | Cannot connect to LDAP server |
| `LDAP_BIND_FAILED` | 401 | No | Service account bind failed |
| `LDAP_ALREADY_EXISTS` | 409 | No | Entry already exists (create) |
| `LDAP_NOT_FOUND` | 404 | No | Entry not found (update/delete) |
| `LDAP_INVALID_DN` | 400 | No | Malformed DN |
| `LDAP_CONSTRAINT_VIOLATION` | 400 | No | Schema constraint violation |
| `LDAP_TIMEOUT` | 504 | Yes | Operation timed out |
| `SCHEMA_INVALID` | 400 | No | Invalid schema configuration |
| `SCHEMA_MISSING_FIELD` | 400 | No | Required field missing in user data |

## Integration with AZBlink Directory

### UC Sync Client Module

New module in AZBlink Directory backend:

```
src/backend/
├── uc_sync_client.py    # NEW: Client for UED Sync API
├── uc_tenant_db.py      # NEW: Tenant config CRUD
└── main.py              # Add UC sync triggers to user lifecycle
```

### User Lifecycle Integration Points

| Event in AZBlink | UC Sync Action | Endpoint |
|------------------|----------------|----------|
| User created | Provision to all enabled tenants | `POST /sync/user` (create) |
| User updated | Update in all enabled tenants | `POST /sync/user` (update) |
| User deleted | Delete from all enabled tenants | `POST /sync/user` (delete) |
| User suspended | Suspend in all enabled tenants | `POST /sync/user/suspend` |
| User unsuspended | Unsuspend in all enabled tenants | `POST /sync/user/suspend` |
| Password reset | Update password in all tenants | `POST /sync/user/password` |

### Sync Client Code Pattern

```python
# src/backend/uc_sync_client.py
"""
Client for UED Sync API - provisions users to external UC LDAP directories.
- Fetches tenant configs from local database
- Calls UED Sync API with schema + user data
- Handles failures with retry and logging
"""

import httpx
from typing import Optional
from .uc_tenant_db import UCTenantDB
from .config import UED_SYNC_API_URL, UED_SYNC_API_KEY

class UCSyncClient:
    def __init__(self, tenant_db: UCTenantDB):
        self.tenant_db = tenant_db
        self.http = httpx.Client(
            base_url=UED_SYNC_API_URL,
            headers={"X-API-Key": UED_SYNC_API_KEY},
            timeout=10.0
        )

    async def sync_user_create(self, user_data: dict, tenant_ids: Optional[list] = None):
        """Provision user to UC tenants.

        Args:
            user_data: User attributes from AZBlink Directory
            tenant_ids: Specific tenants, or None for all enabled

        Returns:
            dict: {tenant_id: {"ok": bool, "error": str|None}}
        """
        tenants = self.tenant_db.get_enabled_tenants(tenant_ids)
        results = {}

        for tenant in tenants:
            request = {
                "operation": "create",
                "request_id": f"{user_data['uid']}-{tenant.tenant_id}-create",
                "ldap": tenant.ldap_config,
                "schema": tenant.provisioning_schema["user"],
                "user": self._map_user_fields(user_data, tenant.provisioning_schema)
            }

            try:
                resp = self.http.post("/api/v1/sync/user", json=request)
                results[tenant.tenant_id] = resp.json()
            except httpx.RequestError as e:
                results[tenant.tenant_id] = {
                    "ok": False,
                    "error": {"code": "SYNC_API_UNREACHABLE", "message": str(e)}
                }

        return results

    def _map_user_fields(self, user_data: dict, schema: dict) -> dict:
        """Map AZBlink user fields to tenant schema fields."""
        field_map = {
            "uid": "username",
            "cn": "display_name",
            "mail": "email",
            "givenName": "first_name",
            "sn": "last_name",
            "telephoneNumber": "phone"
        }
        # Reverse map + apply
        return {field_map.get(k, k): v for k, v in user_data.items()}
```

### Admin UI for Tenant Management

New section in AZBlink Directory admin UI:

```
/settings/uc-tenants           # List/manage UC tenants
/settings/uc-tenants/new       # Add new UC tenant
/settings/uc-tenants/{id}      # Edit tenant config + schema
/settings/uc-tenants/{id}/test # Test connection + provision test user
```

## Temporal Migration Path

When async processing becomes necessary, the migration is straightforward:

### Current (Option B)

```
AZBlink Directory → HTTP → UED Sync API → LDAP
```

### Future (Option D with Temporal)

```
AZBlink Directory → Start Workflow → Temporal → Activities → LDAP
```

### Migration Steps

1. **Extract activities from UED Sync API:**
   ```python
   # activities/ldap_activities.py
   @activity.defn
   async def ldap_add_user(ldap_config: dict, schema: dict, user: dict) -> dict:
       # Same logic as current /sync/user endpoint
       pass

   @activity.defn
   async def ldap_modify_user(...): pass

   @activity.defn
   async def ldap_delete_user(...): pass
   ```

2. **Create workflow definitions:**
   ```python
   # workflows/user_provisioning.py
   @workflow.defn
   class UserProvisioningWorkflow:
       @workflow.run
       async def run(self, user_data: dict, tenant_configs: list[dict]):
           results = []
           for tenant in tenant_configs:
               result = await workflow.execute_activity(
                   ldap_add_user,
                   args=[tenant["ldap"], tenant["schema"], user_data],
                   start_to_close_timeout=timedelta(seconds=30),
                   retry_policy=RetryPolicy(maximum_attempts=3)
               )
               results.append(result)
           return results
   ```

3. **Update AZBlink Directory client:**
   ```python
   # Before: HTTP call
   result = sync_client.sync_user_create(user_data)

   # After: Start workflow
   handle = await temporal_client.start_workflow(
       UserProvisioningWorkflow.run,
       args=[user_data, tenant_configs],
       id=f"provision-{user_data['uid']}",
       task_queue="uc-sync"
   )
   ```

### When to Migrate

Trigger points for Temporal migration:

| Signal | Implication |
|--------|-------------|
| Need multi-step provisioning | Create user → Create mailbox → Add to groups → Notify |
| Need compensating transactions | Rollback partial provisioning on failure |
| Hitting scale limits | Dozens of tenants, need async fan-out |
| Need visibility | Built-in Temporal UI for workflow debugging |
| Need durable retries | Long-running operations with automatic retry |

## Security Considerations

### Credential Management

| Environment | Approach |
|-------------|----------|
| Development | Bind passwords in `.env` file |
| Production | HashiCorp Vault or AWS Secrets Manager |

### Network Security

| Requirement | Implementation |
|-------------|----------------|
| Service-to-service auth | mTLS with client certificates |
| LDAP connections | LDAPS (TLS) required in production |
| Secret transit | Passwords encrypted at rest, decrypted at sync time |

### Audit Trail

```sql
-- Audit table for sync operations
CREATE TABLE uc_sync_audit (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       UUID REFERENCES uc_tenant_configs(tenant_id),
    operation       VARCHAR(50) NOT NULL,  -- create, update, delete, suspend, password
    user_uid        VARCHAR(255) NOT NULL,
    request_id      VARCHAR(255),
    success         BOOLEAN NOT NULL,
    error_code      VARCHAR(50),
    error_message   TEXT,
    duration_ms     INTEGER,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_uc_sync_audit_tenant ON uc_sync_audit(tenant_id, created_at);
CREATE INDEX idx_uc_sync_audit_user ON uc_sync_audit(user_uid, created_at);
```

## Development & Deployment

### UED Sync API Repository Structure

```
ued-sync-api/
├── src/
│   ├── main.py              # FastAPI app
│   ├── config.py            # Environment config
│   ├── ldap_ops.py          # Generic LDAP operations
│   ├── schema_parser.py     # Schema config parsing
│   └── routes/
│       ├── sync.py          # /sync/* endpoints
│       └── health.py        # /health endpoint
├── tests/
│   ├── conftest.py
│   ├── test_ldap_ops.py
│   └── test_sync_routes.py
├── deploy/
│   ├── Dockerfile
│   └── docker-compose.yml   # For local dev with test LDAP
├── requirements.txt
└── README.md
```

### Local Development Setup

```bash
# Start test LDAP + Sync API
cd ued-sync-api
docker-compose up -d

# Run tests
pytest

# Sync API available at http://localhost:8090
```

### Integration Testing

Test flow from AZBlink Directory:

1. Configure test tenant pointing to local LDAP
2. Create user in AZBlink Directory
3. Verify user appears in test LDAP
4. Update user, verify LDAP updated
5. Delete user, verify LDAP entry removed

## Implementation Phases

### Phase 1: Foundation (Week 1-2)

- [ ] Create `uc_tenant_configs` table in AZBlink Directory
- [ ] Build tenant config CRUD in `uc_tenant_db.py`
- [ ] Create UED Sync API skeleton with `/health` endpoint
- [ ] Implement generic LDAP operations module

### Phase 2: Core Sync (Week 3-4)

- [ ] Implement `POST /sync/user` (create/update/delete)
- [ ] Implement `POST /sync/user/suspend`
- [ ] Implement `POST /sync/user/password`
- [ ] Build UC Sync Client in AZBlink Directory
- [ ] Integration tests with test LDAP

### Phase 3: Integration (Week 5-6)

- [ ] Wire user lifecycle events to UC Sync Client
- [ ] Add audit logging
- [ ] Build admin UI for tenant management
- [ ] End-to-end testing with real UC LDAP

### Phase 4: Production Hardening (Week 7-8)

- [ ] mTLS setup for service-to-service auth
- [ ] Vault integration for credential management
- [ ] Monitoring and alerting
- [ ] Documentation and runbooks

## Resolved Design Decisions

### 1. Credential Storage

**Decision:** Start with encrypted DB columns, migrate to Vault later.

**Rationale:** No new infrastructure needed; sufficient security for < 10 tenants initially.

**Implementation:**
```python
# Use Fernet symmetric encryption
from cryptography.fernet import Fernet

ENCRYPTION_KEY = os.environ["UC_CREDENTIAL_KEY"]  # 32-byte base64
cipher = Fernet(ENCRYPTION_KEY)

# Store
encrypted = cipher.encrypt(bind_password.encode())

# Retrieve
decrypted = cipher.decrypt(encrypted).decode()
```

**Migration trigger:** Add Vault when exceeding 10+ tenants, needing automatic rotation, or compliance requires it.

---

### 2. Failure Handling

**Decision:** Async retry queue using PostgreSQL (non-blocking).

**Rationale:** LDAP operations can be slow; blocking UI during retries = bad UX.

**Flow:**
```
User action → Immediate attempt → If success → Done
                                → If fail → Queue for retry
                                                ↓
                                    Background worker (polls every 30s)
                                    Exponential backoff, max 3 attempts
                                                ↓
                                    On final failure → Alert admin
```

**Queue table:**
```sql
CREATE TABLE uc_sync_queue (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       UUID NOT NULL REFERENCES uc_tenant_configs(tenant_id),
    operation       VARCHAR(50) NOT NULL,
    user_uid        VARCHAR(255) NOT NULL,
    payload         JSONB NOT NULL,
    attempts        INTEGER DEFAULT 0,
    max_attempts    INTEGER DEFAULT 3,
    next_attempt_at TIMESTAMPTZ DEFAULT NOW(),
    last_error      TEXT,
    status          VARCHAR(20) DEFAULT 'pending',  -- pending, processing, failed
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_uc_sync_queue_pending
    ON uc_sync_queue(next_attempt_at)
    WHERE status = 'pending';
```

---

### 3. Partial Success UI Behavior

**Decision:** Show success with per-tenant status details.

**Rationale:** Admins need transparency; hiding failures leads to data inconsistency surprises.

**UI Pattern:**
```
┌─────────────────────────────────────────────────────────┐
│ ✓ User "alice" created                                  │
│                                                         │
│ UC Sync Status:                                         │
│   ✓ Acme Corp LDAP      Provisioned                    │
│   ✓ Partner LDAP        Provisioned                    │
│   ⚠ Legacy System       Queued for retry (conn timeout)│
│                                                         │
│ [View Details]                                          │
└─────────────────────────────────────────────────────────┘
```

**Status states:**
| Icon | Status | Meaning |
|------|--------|---------|
| ✓ | `provisioned` | Success |
| ⏳ | `pending` | In queue, not attempted |
| 🔄 | `retrying` | Failed, will retry |
| ⚠ | `failed` | Max retries exhausted |

---

### 4. Schema Validation

**Decision:** Validate strictly, reject invalid operations.

**Rationale:** Invalid schema is a configuration error, not runtime. Fail fast prevents corrupt LDAP entries.

**Validation points:**

| Check | When | Action |
|-------|------|--------|
| Schema structure valid | Tenant config save | Reject save with specific errors |
| Required fields in user data | Sync request | Reject request (400) |
| DN template valid | Sync request | Reject request (400) |
| LDAP connection works | Tenant config save | Warn, allow save (test button) |

**Error response example:**
```json
{
  "ok": false,
  "error": {
    "code": "SCHEMA_INVALID",
    "message": "Schema validation failed",
    "details": [
      "Missing required field 'object_classes' in provisioning.user",
      "Invalid DN template: missing {base_dn} placeholder"
    ]
  }
}
```

---

*Design created: 2026-02-05*
*Status: Approved - Ready for implementation planning*
