# Group Detail Panel: Tabs Migration

**Date:** 2026-02-09
**Status:** Design approved, ready for implementation

## Problem

The group detail panel currently uses scrolling vertical sections for Info, Members, and Permissions. This creates two issues:

- **Members list is height-constrained** (`max-h-52`) causing scroll-within-scroll, a UX anti-pattern
- **No room to grow** — future sections (Activity Log, Audit Trail) would degrade the scrolling experience

## Decision

Migrate from scrolling sections to a **tabbed interface** matching the org detail panel (`DetailTabs.tsx`). This establishes a consistent pattern: entities with management actions use tabs; profile views use scrolling sections.

| Panel | Pattern | Rationale |
|-------|---------|-----------|
| User Detail | Scrolling sections | Read-heavy profile, all info benefits from at-a-glance scanning |
| Org Detail | Tabs (4) | Distinct feature domains (Overview, SSO, Users, Provisioning) |
| **Group Detail** | **Tabs (3)** | **Interactive management (Members, Permissions) + future extensibility** |

## Tab Design

### Layout

```
┌─────────────────────────────────┐
│  PanelHeader (icon, name, btns) │  ← fixed, unchanged
├─────────────────────────────────┤
│  [Overview] [Members] [Perms]   │  ← TabsList variant="underline"
├─────────────────────────────────┤
│                                 │
│  <TabsContent>                  │  ← flex-1 overflow-y-auto
│    (active tab content)         │
│                                 │
└─────────────────────────────────┘
```

### Tabs

| Tab | Default | Content | Key benefit |
|-----|---------|---------|-------------|
| **Overview** | Yes | Info grid (DN, Type, Created, Modified) | Orients user; future: summary stats, metadata |
| **Members** | No | Full-height member list + Add Member CTA | No more `max-h-52` constraint; 50+ members scroll naturally |
| **Permissions** | No | ToggleCard list (4-8 toggles, growing) | Clean separation of read vs write |

### Tab state

- Default: `"overview"` (consistent with org detail)
- Managed via `activeTab` + `onTabChange` props (parent can sync to URL `?tab=`)
- Type: `type GroupTab = 'overview' | 'members' | 'permissions'`

## File Structure

Following the org-management pattern:

| File | Action | Role |
|------|--------|------|
| `GroupDetailPanel.tsx` | **Modify** | Remove inline sections, render PanelHeader + GroupDetailTabs |
| `GroupDetailTabs.tsx` | **Create** | Tab container (mirrors `DetailTabs.tsx`) |
| `OverviewTab.tsx` | **Create** | Extracted from `InfoSection` |
| `MembersTab.tsx` | **Create** | Extracted from `MembersSection` + mutation hooks |
| `PermissionsTab.tsx` | **Create** | Extracted from `PermissionsSection` + mutation hooks |
| `MemberRow.tsx` | Unchanged | Used by MembersTab |
| `PermissionToggle.tsx` | Unchanged | Used by PermissionsTab |
| `GroupTypeBadge.tsx` | Unchanged | Used by OverviewTab |
| `group-type-config.ts` | Unchanged | Used by GroupDetailPanel (header) |

## What Changes

### `GroupDetailPanel.tsx`

- `InfoSection`, `MembersSection`, `PermissionsSection` functions **removed** (moved to tab files)
- `GroupDetailContent` renders `PanelHeader` + `GroupDetailTabs` instead of scrolling div
- `GroupDetailSkeleton` updated to show tab skeleton layout
- `PanelHeader` stays in this file (it's above the tabs)
- Props interface unchanged

### New `GroupDetailTabs.tsx`

```tsx
// Mirrors org-management/DetailTabs.tsx pattern exactly
interface GroupDetailTabsProps {
  group: GroupDetail;
  activeTab: GroupTab;
  onTabChange: (tab: GroupTab) => void;
  onAddMember?: (cn: string) => void;
}
```

### Members tab gains

- **Full remaining panel height** (no `max-h-52`)
- Count header inside tab content
- "Add Member" CTA at bottom of list
- Mutation hooks (`useRemoveMember`, `useUpdateMemberRole`) move here

### Permissions tab gains

- `<fieldset>` semantic wrapper preserved for a11y
- `useUpdateGroupPermissions` hook moves here
- Room for future permission categories

## What Doesn't Change

- `PanelHeader` (icon, name, description, Edit/Delete buttons)
- `GroupDetailPanelProps` interface
- Data fetching via `useSuspenseQuery` in `GroupDetailContent`
- All existing primitives (`MemberRow`, `PermissionToggle`, `GroupTypeBadge`)
- Import path from parent page

## Alternatives Considered

1. **Keep scrolling sections** — rejected because Members list outgrows `max-h-52` and future sections have nowhere to go
2. **Hybrid (fixed info + tabs for Members/Permissions only)** — rejected because it introduces a novel pattern not used elsewhere in the app

## Implementation Notes

- Use `@azblink/ui` Tabs with `variant="underline"` (same as org)
- Tab content wrapper: `flex-1 overflow-y-auto px-5 py-5` (same as org)
- No URL sync needed initially (can be added later like org)
- Skeleton should show tab header + placeholder content
