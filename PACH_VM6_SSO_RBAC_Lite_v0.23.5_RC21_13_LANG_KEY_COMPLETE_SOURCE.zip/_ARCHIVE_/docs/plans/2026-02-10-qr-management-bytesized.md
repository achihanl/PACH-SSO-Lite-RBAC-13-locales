# QR Code Management — Byte-Sized Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Migrate the flat QR generator page to a split-panel master-detail "QR Code Management" page with enriched list, stats, detail panel, and generate modal.

**Architecture:** Two new backend endpoints (`GET /api/qr/codes`, `GET /api/qr/stats`) join `qr_issuance_audit` with `provision_tokens` and enrich via LDAP. Frontend follows the `GroupManagementPage` split-panel pattern with URL-driven state (TanStack Router), page-scoped modal state (`useReducer`), and TanStack Query for data fetching.

**Tech Stack:** FastAPI + SQLAlchemy Core (backend), React 19 + TanStack Router + TanStack Query + @azblink/ui + Tailwind CSS 4 (frontend)

---

## Task 1: Add QR Management Types

**Files:**
- Create: `src/frontend/src/types/qr-management.ts`
- Modify: `src/frontend/src/types/index.ts`

**Step 1: Create the types file**

Create `src/frontend/src/types/qr-management.ts`:

```typescript
/**
 * QR Code Management domain types
 * - QRCodeListItem: enriched item from GET /api/qr/codes
 * - QRStats: aggregate stats from GET /api/qr/stats
 * - QRFilter/QRDateRange: URL search param types
 * - QRManagementSearchParams: TanStack Router validateSearch shape
 */

import type { ISOTimestamp, UID, DN } from './api';

/** QR token lifecycle status — derived server-side from consumed flag, token_status, and expiry */
export type QRStatus = 'consumed' | 'pending' | 'expired' | 'revoked';

/** Filter tab options (includes 'all' for no filter) */
export type QRFilter = 'all' | QRStatus;

/** Date range presets for list and stats queries */
export type QRDateRange = '7d' | '30d' | '90d' | 'all';

/** Enriched QR code list item from GET /api/qr/codes */
export interface QRCodeListItem {
  id: number;
  token_hash: string;
  user_uid: UID;
  user_display_name: string;
  user_org: string;
  org_dn: DN;
  status: QRStatus;
  device_info: string | null;
  client_platform: string | null;
  issued_at: ISOTimestamp;
  expires_at: ISOTimestamp;
  consumed_at: ISOTimestamp | null;
  issued_by: string;
}

/** Paginated response from GET /api/qr/codes */
export interface QRCodesResponse {
  ok: true;
  codes: QRCodeListItem[];
  total: number;
  limit: number;
  offset: number;
}

/** Aggregate stats from GET /api/qr/stats */
export interface QRStats {
  ok: true;
  total_generated: number;
  consumed: number;
  pending: number;
  expired_unused: number;
}

/** URL search params for the QR Management page — all state lives in the URL */
export interface QRManagementSearchParams {
  qrId?: string;
  filter?: QRFilter;
  search?: string;
  dateRange?: QRDateRange;
  page?: number;
  pageSize?: number;
}

/** Query params sent to GET /api/qr/codes */
export interface QRCodesQueryParams {
  limit?: number;
  offset?: number;
  search?: string;
  status?: string;
  date_range?: string;
  sort?: string;
  order?: 'asc' | 'desc';
}
```

**Step 2: Export from types barrel**

Add to `src/frontend/src/types/index.ts` after the audit export line:

```typescript
export * from './qr-management';
```

**Step 3: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors related to qr-management types.

**Step 4: Commit**

```bash
git add src/frontend/src/types/qr-management.ts src/frontend/src/types/index.ts
git commit -m "$(cat <<'EOF'
feat(qr-management): add domain types for QR code management (Phase 0, Task 1)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: Add QR Management Query Keys

**Files:**
- Modify: `src/frontend/src/lib/queries/keys.ts`

**Step 1: Add qrCodes section to queryKeys**

In `src/frontend/src/lib/queries/keys.ts`, add after the `audit` section (before `health`):

```typescript
  // QR Code Management
  qrCodes: {
    list: (params: Record<string, unknown>) => ['qr', 'codes', params] as const,
    stats: (dateRange: string) => ['qr', 'stats', dateRange] as const,
    all: ['qr'] as const,
  },
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 3: Commit**

```bash
git add src/frontend/src/lib/queries/keys.ts
git commit -m "$(cat <<'EOF'
feat(qr-management): add query keys for QR code list and stats (Phase 0, Task 2)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: Create QR Status Config

**Files:**
- Create: `src/frontend/src/components/features/qr-management/qr-status-config.ts`

**Step 1: Create the status config file**

Create `src/frontend/src/components/features/qr-management/qr-status-config.ts`:

```typescript
/**
 * QR status visual config — icon, color, background, dot, label per QRStatus.
 * Follows group-management/group-type-config.ts pattern.
 * Used by QRStatusBadge (list rows) and QRDetailPanel (header).
 */
import { CheckCircle2, Clock, AlertCircle, ShieldOff } from 'lucide-react';
import type { QRStatus } from '@/types/qr-management';

export interface QRStatusConfig {
  icon: typeof CheckCircle2;
  color: string;
  bg: string;
  dot: string;
  label: string;
}

export const qrStatusConfig: Record<QRStatus, QRStatusConfig> = {
  consumed: {
    icon: CheckCircle2,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    dot: 'bg-emerald-400',
    label: 'Consumed',
  },
  pending: {
    icon: Clock,
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    dot: 'bg-amber-400',
    label: 'Pending',
  },
  expired: {
    icon: AlertCircle,
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    dot: 'bg-red-400',
    label: 'Expired',
  },
  revoked: {
    icon: ShieldOff,
    color: 'text-gray-400',
    bg: 'bg-gray-500/10',
    dot: 'bg-gray-400',
    label: 'Revoked',
  },
};
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/qr-management/qr-status-config.ts
git commit -m "$(cat <<'EOF'
feat(qr-management): add QR status visual config (Phase 0, Task 3)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: Backend — Add `list_qr_codes()` to orgdb.py

**Files:**
- Modify: `src/backend/orgdb.py`

**Step 1: Add the `list_qr_codes` method**

Add after `list_qr_issuance_for_user` method (after line ~644) in `src/backend/orgdb.py`:

```python
    def list_qr_codes(
        self,
        limit: int = 50,
        offset: int = 0,
        search: str = "",
        status: str = "",
        date_range: str = "7d",
        sort: str = "issued_at",
        order: str = "desc",
    ) -> tuple[list[dict[str, Any]], int]:
        """Return enriched QR codes for the management page.

        - LEFT JOIN qr_issuance_audit with provision_tokens on token_hash
        - Status derivation: consumed → consumed, revoked → revoked, expired → expired, else → pending
        - Filtering by status, date_range, search
        - Returns (rows, total_count)
        """
        eng = self.connect()
        j = qr_issuance_audit.outerjoin(
            provision_tokens,
            qr_issuance_audit.c.token_hash == provision_tokens.c.token_hash,
        )
        base_cols = [
            qr_issuance_audit,
            provision_tokens.c.status.label("token_status"),
            provision_tokens.c.consumed_by_device_id,
            provision_tokens.c.client_platform,
        ]

        # Build WHERE conditions
        conditions = []
        now = datetime.now(timezone.utc)

        # Date range filter
        if date_range != "all":
            days_map = {"7d": 7, "30d": 30, "90d": 90}
            days = days_map.get(date_range, 7)
            from datetime import timedelta
            cutoff = now - timedelta(days=days)
            conditions.append(qr_issuance_audit.c.issued_at >= cutoff)

        # Search filter
        if search:
            from sqlalchemy import or_
            conditions.append(
                or_(
                    qr_issuance_audit.c.user_uid.ilike(f"%{search}%"),
                    qr_issuance_audit.c.token_hash.ilike(f"{search}%"),
                )
            )

        # Count total (before status filter, since status is derived post-query)
        count_stmt = select(func.count()).select_from(j)
        for cond in conditions:
            count_stmt = count_stmt.where(cond)

        # Sort
        sort_col_map = {
            "issued_at": qr_issuance_audit.c.issued_at,
            "user_uid": qr_issuance_audit.c.user_uid,
        }
        sort_col = sort_col_map.get(sort, qr_issuance_audit.c.issued_at)
        sort_expr = sort_col.desc() if order == "desc" else sort_col.asc()

        # Main query (fetch more than limit if status filtering, then trim)
        # For status filter: we over-fetch and filter in Python since status is derived
        fetch_limit = limit * 4 if status else limit
        fetch_offset = 0 if status else offset

        data_stmt = (
            select(*base_cols)
            .select_from(j)
            .order_by(sort_expr)
            .limit(fetch_limit)
            .offset(fetch_offset)
        )
        for cond in conditions:
            data_stmt = data_stmt.where(cond)

        with eng.begin() as conn:
            total = conn.execute(count_stmt).scalar() or 0
            rows = conn.execute(data_stmt).mappings().all()

        # Derive status and build result
        results = []
        for r in rows:
            expires_at = r["expires_at"]
            if expires_at and expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)

            if r["consumed"]:
                display_status = "consumed"
            elif r["token_status"] in ("revoked_terminated", "revoked"):
                display_status = "revoked"
            elif expires_at and expires_at < now:
                display_status = "expired"
            else:
                display_status = "pending"

            # Apply status filter (post-derivation)
            if status and display_status != status:
                continue

            # Build device info string
            device_info = None
            platform = r["client_platform"]
            device_id = r["consumed_by_device_id"]
            if platform and device_id:
                device_info = f"{platform} ({device_id[:8]})"
            elif platform:
                device_info = platform
            elif device_id:
                device_info = f"Device {device_id[:8]}"

            results.append({
                "id": r["id"],
                "token_hash": r["token_hash"],
                "user_uid": r["user_uid"],
                "org_dn": r["org_dn"],
                "status": display_status,
                "device_info": device_info,
                "client_platform": r["client_platform"],
                "issued_at": r["issued_at"].isoformat() if r["issued_at"] else None,
                "expires_at": r["expires_at"].isoformat() if r["expires_at"] else None,
                "consumed_at": r["consumed_at"].isoformat() if r["consumed_at"] else None,
                "issued_by": r["issued_by"],
            })

        # If status-filtered, adjust total and paginate in Python
        if status:
            total = len(results)
            results = results[offset : offset + limit]

        return results, total
```

**Step 2: Verify backend starts without import errors**

Run: `cd src/backend && python -c "from orgdb import OrgDB; print('OK')"`
Expected: `OK`

**Step 3: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "$(cat <<'EOF'
feat(qr-management): add list_qr_codes method to orgdb (Phase 1, Task 4)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: Backend — Add `get_qr_stats()` to orgdb.py

**Files:**
- Modify: `src/backend/orgdb.py`

**Step 1: Add the `get_qr_stats` method**

Add after `list_qr_codes` method in `src/backend/orgdb.py`:

```python
    def get_qr_stats(self, date_range: str = "7d") -> dict[str, int]:
        """Return aggregate QR statistics for the management page.

        - total_generated: COUNT(*)
        - consumed: COUNT where consumed = true
        - pending: COUNT where not consumed, not revoked, not expired
        - expired_unused: COUNT where not consumed, expired, not revoked
        """
        eng = self.connect()
        j = qr_issuance_audit.outerjoin(
            provision_tokens,
            qr_issuance_audit.c.token_hash == provision_tokens.c.token_hash,
        )

        now = datetime.now(timezone.utc)
        conditions = []

        if date_range != "all":
            from datetime import timedelta
            days_map = {"7d": 7, "30d": 30, "90d": 90}
            days = days_map.get(date_range, 7)
            cutoff = now - timedelta(days=days)
            conditions.append(qr_issuance_audit.c.issued_at >= cutoff)

        # Fetch all rows and derive stats in Python (same derivation logic as list)
        data_stmt = (
            select(
                qr_issuance_audit.c.consumed,
                qr_issuance_audit.c.expires_at,
                provision_tokens.c.status.label("token_status"),
            )
            .select_from(j)
        )
        for cond in conditions:
            data_stmt = data_stmt.where(cond)

        with eng.begin() as conn:
            rows = conn.execute(data_stmt).mappings().all()

        stats = {"total_generated": 0, "consumed": 0, "pending": 0, "expired_unused": 0}
        for r in rows:
            stats["total_generated"] += 1
            expires_at = r["expires_at"]
            if expires_at and expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)

            if r["consumed"]:
                stats["consumed"] += 1
            elif r["token_status"] in ("revoked_terminated", "revoked"):
                pass  # revoked — not counted in pending or expired
            elif expires_at and expires_at < now:
                stats["expired_unused"] += 1
            else:
                stats["pending"] += 1

        return stats
```

**Step 2: Verify backend starts without import errors**

Run: `cd src/backend && python -c "from orgdb import OrgDB; print('OK')"`
Expected: `OK`

**Step 3: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "$(cat <<'EOF'
feat(qr-management): add get_qr_stats method to orgdb (Phase 1, Task 5)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: Backend — Add `GET /api/qr/codes` Endpoint

**Files:**
- Modify: `src/backend/main.py`

**Step 1: Add the endpoint**

Add BEFORE the existing `/api/users/{uid}/qrcode` endpoint in `src/backend/main.py` (this is important to avoid path capture issues). Look for the `# QR Provisioning` section and add before it:

```python
# ----------------------------
# QR Code Management (Admin)
# ----------------------------
@app.get("/api/qr/codes")
def api_qr_codes(
    limit: int = 50,
    offset: int = 0,
    search: str = "",
    status: str = "",
    date_range: str = "7d",
    sort: str = "issued_at",
    order: str = "desc",
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Enriched QR code list for the management page.

    - Joins qr_issuance_audit with provision_tokens
    - Enriches with LDAP user display names and org names
    - Supports search, status filter, date range, sort, pagination
    """
    limit = min(limit, 200)
    codes, total = ORGDB.list_qr_codes(
        limit=limit,
        offset=offset,
        search=search,
        status=status,
        date_range=date_range,
        sort=sort,
        order=order,
    )

    # Batch LDAP user lookup for display names and orgs
    unique_uids = list({c["user_uid"] for c in codes})
    user_cache: Dict[str, Dict[str, Any]] = {}
    for uid in unique_uids:
        try:
            user = get_user(uid)
            if user:
                user_cache[uid] = user
        except Exception:
            pass  # LDAP lookup failed — skip enrichment for this user

    # Enrich each code with user display name and org
    for code in codes:
        uid = code["user_uid"]
        user = user_cache.get(uid)
        if user:
            code["user_display_name"] = user.get("displayName", uid)
            # Extract org name from org_dn (last ou= component)
            org_dn = code.get("org_dn", "")
            if org_dn:
                ou_parts = [p.split("=")[1] for p in org_dn.split(",") if p.startswith("ou=")]
                code["user_org"] = ou_parts[0] if ou_parts else ""
            else:
                code["user_org"] = ""
        else:
            code["user_display_name"] = uid
            code["user_org"] = ""

    return {"ok": True, "codes": codes, "total": total, "limit": limit, "offset": offset}


@app.get("/api/qr/stats")
def api_qr_stats(
    date_range: str = "7d",
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Aggregate QR statistics for the management page stats row."""
    stats = ORGDB.get_qr_stats(date_range=date_range)
    return {"ok": True, **stats}
```

**Step 2: Verify the API starts without errors**

Run: `just logs` or check that hot reload picks up the change.
Expected: No import errors. Endpoints appear in `/api/docs`.

**Step 3: Smoke test the new endpoints**

Run (with stack running):
```bash
# Get auth token
TOKEN=$(curl -s http://localhost:8081/api/auth/login -H 'Content-Type: application/json' -d '{"username":"mei","password":"password123"}' | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))")

# Test /api/qr/codes
curl -s http://localhost:8081/api/qr/codes -H "Authorization: Bearer $TOKEN" | python3 -m json.tool | head -20

# Test /api/qr/stats
curl -s http://localhost:8081/api/qr/stats -H "Authorization: Bearer $TOKEN" | python3 -m json.tool
```

Expected: `{"ok": true, "codes": [...], "total": N, ...}` and `{"ok": true, "total_generated": N, ...}`

**Step 4: Commit**

```bash
git add src/backend/main.py
git commit -m "$(cat <<'EOF'
feat(qr-management): add GET /api/qr/codes and /api/qr/stats endpoints (Phase 1, Task 6)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 7: Frontend — Create Query Hooks

**Files:**
- Create: `src/frontend/src/lib/queries/qr-management.ts`

**Step 1: Create the query hooks file**

Create `src/frontend/src/lib/queries/qr-management.ts`:

```typescript
/**
 * TanStack Query options for QR Code Management endpoints
 * - qrCodesQueryOptions: enriched QR list from GET /api/qr/codes
 * - qrStatsQueryOptions: aggregate stats from GET /api/qr/stats
 * - useRegenerateQR: compound mutation (revoke + generate)
 */

import { queryOptions, useMutation, useQueryClient } from '@tanstack/react-query';
import { getApi } from '../api-client';
import { queryKeys } from './keys';
import type { QRCodesResponse, QRCodesQueryParams, QRStats } from '@/types/qr-management';
import { toast } from 'sonner';

/** Paginated enriched QR code list */
export const qrCodesQueryOptions = (params: QRCodesQueryParams = {}) =>
  queryOptions({
    queryKey: queryKeys.qrCodes.list(params as Record<string, unknown>),
    queryFn: () =>
      getApi().get<QRCodesResponse>('/qr/codes', {
        limit: params.limit,
        offset: params.offset,
        search: params.search,
        status: params.status,
        date_range: params.date_range,
        sort: params.sort,
        order: params.order,
      }),
    staleTime: 30_000,
  });

/** Aggregate QR stats for the stats row */
export const qrStatsQueryOptions = (dateRange: string = '7d') =>
  queryOptions({
    queryKey: queryKeys.qrCodes.stats(dateRange),
    queryFn: () =>
      getApi().get<QRStats>('/qr/stats', { date_range: dateRange }),
    staleTime: 15_000,
  });

/** Compound mutation: revoke all tokens for user, then generate new QR */
export function useRegenerateQR() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ uid, ttlSec }: { uid: string; ttlSec: number }) => {
      // Step 1: Revoke existing tokens
      await getApi().post<{ ok: boolean }>(`/users/${uid}/qrcode/revoke`);
      // Step 2: Generate new QR
      return getApi().get<{ ok: boolean }>(`/users/${uid}/qrcode`, { ttl_sec: ttlSec });
    },
    onSuccess: (_data, variables) => {
      // Invalidate all QR management queries
      queryClient.invalidateQueries({ queryKey: queryKeys.qrCodes.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.userQR(variables.uid) });
      queryClient.invalidateQueries({ queryKey: queryKeys.userQRHistory(variables.uid) });
      toast.success(`QR regenerated for ${variables.uid}`);
    },
    onError: () => {
      toast.error('Failed to regenerate QR code');
    },
  });
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 3: Commit**

```bash
git add src/frontend/src/lib/queries/qr-management.ts
git commit -m "$(cat <<'EOF'
feat(qr-management): add query hooks for QR codes list, stats, and regenerate (Phase 1, Task 7)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 8: Frontend — Create Modal State Machine

**Files:**
- Create: `src/frontend/src/components/features/qr-management/useModalState.ts`

**Step 1: Create the modal state file**

Create `src/frontend/src/components/features/qr-management/useModalState.ts`:

```typescript
/**
 * Modal state machine for the QR Management page.
 * - Tracks which modal is open and target user/token
 * - State transitions: closed → generate_qr | regenerate_confirm | revoke_confirm
 * - Page-scoped via useReducer (not global Zustand)
 */
import { useReducer, useCallback } from 'react';

export type QRModalKind =
  | 'closed'
  | 'generate_qr'
  | 'regenerate_confirm'
  | 'revoke_confirm';

export interface QRModalState {
  kind: QRModalKind;
  targetUid: string | null;
  targetTokenHash: string | null;
}

type QRModalAction =
  | { type: 'OPEN_GENERATE' }
  | { type: 'OPEN_REGENERATE'; uid: string }
  | { type: 'OPEN_REVOKE'; uid: string; tokenHash: string }
  | { type: 'CLOSE' };

const initialState: QRModalState = { kind: 'closed', targetUid: null, targetTokenHash: null };

function modalReducer(_state: QRModalState, action: QRModalAction): QRModalState {
  switch (action.type) {
    case 'OPEN_GENERATE':
      return { kind: 'generate_qr', targetUid: null, targetTokenHash: null };
    case 'OPEN_REGENERATE':
      return { kind: 'regenerate_confirm', targetUid: action.uid, targetTokenHash: null };
    case 'OPEN_REVOKE':
      return { kind: 'revoke_confirm', targetUid: action.uid, targetTokenHash: action.tokenHash };
    case 'CLOSE':
      return initialState;
    default:
      return initialState;
  }
}

/** Page-scoped modal state with dispatch helpers */
export function useQRModalState() {
  const [state, dispatch] = useReducer(modalReducer, initialState);

  const openGenerate = useCallback(() => dispatch({ type: 'OPEN_GENERATE' }), []);
  const openRegenerate = useCallback((uid: string) => dispatch({ type: 'OPEN_REGENERATE', uid }), []);
  const openRevoke = useCallback(
    (uid: string, tokenHash: string) => dispatch({ type: 'OPEN_REVOKE', uid, tokenHash }),
    [],
  );
  const close = useCallback(() => dispatch({ type: 'CLOSE' }), []);

  return { state, openGenerate, openRegenerate, openRevoke, close };
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/qr-management/useModalState.ts
git commit -m "$(cat <<'EOF'
feat(qr-management): add modal state machine for QR page (Phase 1, Task 8)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 9: Frontend — Create QRStatusBadge Component

**Files:**
- Create: `src/frontend/src/components/features/qr-management/QRStatusBadge.tsx`

**Step 1: Create the component**

Create `src/frontend/src/components/features/qr-management/QRStatusBadge.tsx`:

```tsx
/**
 * Status badge for QR codes — renders a Badge with status-specific icon, color, and dot.
 * Uses qr-status-config.ts for visual mapping.
 */
import { Badge, cn } from '@azblink/ui';
import { qrStatusConfig } from './qr-status-config';
import type { QRStatus } from '@/types/qr-management';

interface QRStatusBadgeProps {
  status: QRStatus;
  className?: string;
}

export function QRStatusBadge({ status, className }: QRStatusBadgeProps) {
  const config = qrStatusConfig[status];
  const Icon = config.icon;

  return (
    <Badge
      variant="outline"
      className={cn('gap-1.5 font-medium', config.color, config.bg, className)}
      data-testid={`qr-status-${status}`}
    >
      <span className={cn('h-1.5 w-1.5 rounded-full', config.dot)} />
      {config.label}
    </Badge>
  );
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/qr-management/QRStatusBadge.tsx
git commit -m "$(cat <<'EOF'
feat(qr-management): add QRStatusBadge component (Phase 1, Task 9)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 10: Frontend — Create PageHeader Component

**Files:**
- Create: `src/frontend/src/components/features/qr-management/PageHeader.tsx`

**Step 1: Create the component**

Create `src/frontend/src/components/features/qr-management/PageHeader.tsx`:

```tsx
/**
 * Page header for QR Code Management — title, search, date range, generate button.
 * - SearchInput reuses the pattern from user-management
 * - DateRangeSelect is a simple native <select>
 * - Cmd+K focus handled by parent page via ref forwarding
 */
import { QrCode, Search, Plus } from 'lucide-react';
import { Button, Input, cn } from '@azblink/ui';
import type { QRDateRange } from '@/types/qr-management';

interface PageHeaderProps {
  search: string;
  onSearchChange: (value: string) => void;
  dateRange: QRDateRange;
  onDateRangeChange: (value: QRDateRange) => void;
  onGenerateQR: () => void;
  searchInputRef?: React.RefObject<HTMLInputElement | null>;
}

const dateRangeOptions: { value: QRDateRange; label: string }[] = [
  { value: '7d', label: 'Last 7 days' },
  { value: '30d', label: 'Last 30 days' },
  { value: '90d', label: 'Last 90 days' },
  { value: 'all', label: 'All time' },
];

export function PageHeader({
  search,
  onSearchChange,
  dateRange,
  onDateRangeChange,
  onGenerateQR,
  searchInputRef,
}: PageHeaderProps) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[var(--color-accent)]/10">
          <QrCode className="h-5 w-5 text-[var(--color-accent)]" />
        </div>
        <div>
          <h1 className="text-xl font-semibold text-text">QR Code Management</h1>
          <p className="text-sm text-muted-foreground">Generate and manage provisioning QR codes</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            ref={searchInputRef}
            placeholder="Search users or tokens..."
            className="pl-10 w-[240px]"
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            aria-label="Search QR codes"
          />
        </div>

        {/* Date range */}
        <select
          value={dateRange}
          onChange={(e) => onDateRangeChange(e.target.value as QRDateRange)}
          className="h-9 rounded-md border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] px-3 text-sm text-text"
          aria-label="Date range"
        >
          {dateRangeOptions.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>

        {/* Generate QR */}
        <Button onClick={onGenerateQR}>
          <Plus className="h-4 w-4 mr-2" />
          Generate QR
        </Button>
      </div>
    </div>
  );
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/qr-management/PageHeader.tsx
git commit -m "$(cat <<'EOF'
feat(qr-management): add PageHeader with search, date range, and generate button (Phase 1, Task 10)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 11: Frontend — Create StatsRow Component

**Files:**
- Create: `src/frontend/src/components/features/qr-management/StatsRow.tsx`

**Step 1: Create the component**

Create `src/frontend/src/components/features/qr-management/StatsRow.tsx`:

```tsx
/**
 * Stats row for QR Code Management — 4 StatCards showing aggregate QR metrics.
 * Fetches from GET /api/qr/stats via useSuspenseQuery.
 */
import { Suspense } from 'react';
import { useSuspenseQuery } from '@tanstack/react-query';
import { QrCode, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { StatCard } from '@/components/features/stat-card';
import { qrStatsQueryOptions } from '@/lib/queries/qr-management';
import type { QRDateRange } from '@/types/qr-management';

interface StatsRowProps {
  dateRange: QRDateRange;
}

export function StatsRow({ dateRange }: StatsRowProps) {
  return (
    <Suspense fallback={<StatsRowSkeleton />}>
      <StatsRowContent dateRange={dateRange} />
    </Suspense>
  );
}

function StatsRowContent({ dateRange }: StatsRowProps) {
  const { data } = useSuspenseQuery(qrStatsQueryOptions(dateRange));

  return (
    <div
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      aria-live="polite"
    >
      <StatCard
        label="Total Generated"
        value={data.total_generated}
        icon={<QrCode className="h-5 w-5" />}
      />
      <StatCard
        label="Consumed"
        value={data.consumed}
        icon={<CheckCircle2 className="h-5 w-5" />}
      />
      <StatCard
        label="Pending"
        value={data.pending}
        icon={<Clock className="h-5 w-5" />}
      />
      <StatCard
        label="Expired Unused"
        value={data.expired_unused}
        icon={<AlertCircle className="h-5 w-5" />}
      />
    </div>
  );
}

function StatsRowSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="h-[100px] rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] animate-pulse" />
      ))}
    </div>
  );
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/qr-management/StatsRow.tsx
git commit -m "$(cat <<'EOF'
feat(qr-management): add StatsRow with 4 aggregate metric cards (Phase 2, Task 11)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 12: Frontend — Create QRRow Component

**Files:**
- Create: `src/frontend/src/components/features/qr-management/QRRow.tsx`

**Step 1: Create the component**

Create `src/frontend/src/components/features/qr-management/QRRow.tsx`:

```tsx
/**
 * QR list row — displays a single QR code entry with user info, status, device, and time.
 * - Avatar with initials + gradient
 * - QRStatusBadge
 * - Hover action: audit log link
 * - Selected state via aria-current
 */
import { ExternalLink } from 'lucide-react';
import { cn } from '@azblink/ui';
import { QRStatusBadge } from './QRStatusBadge';
import { getInitials } from '@/lib/utils/user-helpers';
import type { QRCodeListItem } from '@/types/qr-management';

interface QRRowProps {
  code: QRCodeListItem;
  isSelected: boolean;
  onSelect: () => void;
}

/** Format relative time (e.g., "2h ago", "3d ago") */
function formatRelativeTime(isoDate: string): string {
  const now = Date.now();
  const then = new Date(isoDate).getTime();
  const diffMs = now - then;
  const diffMin = Math.floor(diffMs / 60_000);
  if (diffMin < 1) return 'just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 30) return `${diffDay}d ago`;
  return new Date(isoDate).toLocaleDateString();
}

export function QRRow({ code, isSelected, onSelect }: QRRowProps) {
  const initials = getInitials(code.user_display_name || code.user_uid);

  return (
    <button
      onClick={onSelect}
      aria-current={isSelected ? 'true' : undefined}
      data-testid={`qr-row-${code.id}`}
      className={cn(
        'group w-full grid grid-cols-[1fr_100px_120px_80px] items-center gap-3 px-4 py-3 text-left transition-colors border-b border-[var(--color-border-subtle)]',
        isSelected
          ? 'bg-[var(--color-accent)]/5 border-l-2 border-l-[var(--color-accent)]'
          : 'hover:bg-[var(--color-bg-secondary)]',
      )}
    >
      {/* User cell */}
      <div className="flex items-center gap-3 min-w-0">
        <div className="h-8 w-8 rounded-full bg-[var(--color-accent)] flex items-center justify-center flex-shrink-0">
          <span className="text-xs font-medium text-[var(--color-accent-foreground)]">
            {initials}
          </span>
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium text-text truncate">
            {code.user_display_name || code.user_uid}
          </p>
          <p className="text-xs text-muted-foreground truncate">{code.user_org}</p>
        </div>
      </div>

      {/* Status */}
      <div>
        <QRStatusBadge status={code.status} />
      </div>

      {/* Device */}
      <div className="text-sm text-muted-foreground truncate">
        {code.device_info || '—'}
      </div>

      {/* Time + hover action */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground">
          {formatRelativeTime(code.issued_at)}
        </span>
        <a
          href={`/provisioning/tokens?search=${code.token_hash.slice(0, 12)}`}
          onClick={(e) => e.stopPropagation()}
          className="opacity-0 group-hover:opacity-100 transition-opacity"
          aria-label="View in audit log"
          title="View in audit log"
        >
          <ExternalLink className="h-3.5 w-3.5 text-muted-foreground hover:text-text" />
        </a>
      </div>
    </button>
  );
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/qr-management/QRRow.tsx
git commit -m "$(cat <<'EOF'
feat(qr-management): add QRRow list item component (Phase 2, Task 12)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 13: Frontend — Create QRList Component

**Files:**
- Create: `src/frontend/src/components/features/qr-management/QRList.tsx`

**Step 1: Create the component**

Create `src/frontend/src/components/features/qr-management/QRList.tsx`:

```tsx
/**
 * QR code list panel — left side of the split-panel layout.
 * - Filter tabs (All / Pending / Consumed / Expired / Revoked)
 * - Scrollable list of QRRow components
 * - Pagination controls
 * - Empty state when no results
 */
import { Tabs } from '@azblink/ui';
import { QRRow } from './QRRow';
import type { QRCodeListItem, QRFilter } from '@/types/qr-management';

interface QRListProps {
  codes: QRCodeListItem[];
  totalCount: number;
  selectedQRId: string | undefined;
  filter: QRFilter;
  onFilterChange: (filter: QRFilter) => void;
  onSelectQR: (tokenHash: string) => void;
  page: number;
  pageSize: number;
  onPageChange: (page: number) => void;
}

const filterTabs: { value: QRFilter; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'pending', label: 'Pending' },
  { value: 'consumed', label: 'Consumed' },
  { value: 'expired', label: 'Expired' },
  { value: 'revoked', label: 'Revoked' },
];

export function QRList({
  codes,
  totalCount,
  selectedQRId,
  filter,
  onFilterChange,
  onSelectQR,
  page,
  pageSize,
  onPageChange,
}: QRListProps) {
  const totalPages = Math.ceil(totalCount / pageSize);

  return (
    <div
      className="flex flex-col h-full rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)]"
      data-testid="qr-table"
    >
      {/* Header + filter tabs */}
      <div className="px-4 pt-4 pb-2 border-b border-[var(--color-border-subtle)]">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-medium text-text">
            QR Codes
            <span className="ml-2 text-muted-foreground" aria-live="polite">
              ({totalCount})
            </span>
          </h2>
        </div>
        <Tabs
          value={filter}
          onValueChange={(v) => onFilterChange(v as QRFilter)}
          variant="underline"
        >
          {filterTabs.map((tab) => (
            <Tabs.Item key={tab.value} value={tab.value}>
              {tab.label}
            </Tabs.Item>
          ))}
        </Tabs>
      </div>

      {/* Scrollable list */}
      <div className="flex-1 overflow-y-auto min-h-0">
        {codes.length === 0 ? (
          <QRListEmpty filter={filter} />
        ) : (
          codes.map((code) => (
            <QRRow
              key={code.id}
              code={code}
              isSelected={selectedQRId === code.token_hash}
              onSelect={() => onSelectQR(code.token_hash)}
            />
          ))
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-2 border-t border-[var(--color-border-subtle)]">
          <span className="text-xs text-muted-foreground">
            Page {page + 1} of {totalPages}
          </span>
          <div className="flex gap-1">
            <button
              onClick={() => onPageChange(Math.max(0, page - 1))}
              disabled={page === 0}
              className="px-2 py-1 text-xs rounded border border-[var(--color-border-subtle)] text-text disabled:opacity-40"
            >
              Prev
            </button>
            <button
              onClick={() => onPageChange(Math.min(totalPages - 1, page + 1))}
              disabled={page >= totalPages - 1}
              className="px-2 py-1 text-xs rounded border border-[var(--color-border-subtle)] text-text disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/** Skeleton for Suspense fallback */
export function QRListSkeleton() {
  return (
    <div className="flex flex-col h-full rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)]">
      <div className="px-4 pt-4 pb-2 border-b border-[var(--color-border-subtle)]">
        <div className="h-5 w-24 bg-muted animate-pulse rounded mb-3" />
        <div className="h-8 w-full bg-muted animate-pulse rounded" />
      </div>
      <div className="flex-1 p-2 space-y-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-14 bg-muted animate-pulse rounded" />
        ))}
      </div>
    </div>
  );
}

function QRListEmpty({ filter }: { filter: QRFilter }) {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-2 text-[var(--color-text-muted)] py-12">
      <svg className="h-10 w-10 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h2M4 12h2m10-8h.01M4 20h2" />
      </svg>
      <p className="text-sm">
        {filter === 'all' ? 'No QR codes generated yet' : `No ${filter} QR codes`}
      </p>
    </div>
  );
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors. Note: Tabs component API may need adjustment based on actual @azblink/ui Tabs signature — verify during visual testing.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/qr-management/QRList.tsx
git commit -m "$(cat <<'EOF'
feat(qr-management): add QRList panel with filter tabs and pagination (Phase 2, Task 13)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 14: Frontend — Create QRDetailPanel Component

**Files:**
- Create: `src/frontend/src/components/features/qr-management/QRDetailPanel.tsx`

**Step 1: Create the component**

Create `src/frontend/src/components/features/qr-management/QRDetailPanel.tsx`:

```tsx
/**
 * QR code detail panel — right side of the split-panel layout.
 * - Panel header: QR preview placeholder, user summary, action buttons
 * - Info sections: QR Details, Device (via DetailGrid + FieldCard)
 * - Provision checklist: XMPP/SIP/SSO status
 * - Activity timeline: from user's qr_history
 */
import { useQuery } from '@tanstack/react-query';
import { RefreshCw, Send, QrCode, CheckCircle2, XCircle } from 'lucide-react';
import { Button, Badge, DetailGrid, FieldCard, cn } from '@azblink/ui';
import { QRStatusBadge } from './QRStatusBadge';
import { getInitials } from '@/lib/utils/user-helpers';
import { queryKeys } from '@/lib/queries/keys';
import { getApi } from '@/lib/api-client';
import { toast } from 'sonner';
import type { QRCodeListItem } from '@/types/qr-management';

interface QRDetailPanelProps {
  code: QRCodeListItem;
  onRegenerate: (uid: string) => void;
}

export function QRDetailPanel({ code, onRegenerate }: QRDetailPanelProps) {
  const initials = getInitials(code.user_display_name || code.user_uid);

  // Fetch user QR history for timeline
  const { data: historyData } = useQuery({
    queryKey: queryKeys.userQRHistory(code.user_uid),
    queryFn: () =>
      getApi().get<{ ok: boolean; history: Array<{ id: number; issued_at: string; expires_at: string; status: string; consumed_at: string | null; device_info: string | null }> }>(
        `/users/${code.user_uid}/qr_history`,
      ),
    staleTime: 30_000,
  });

  const handleResend = () => {
    toast.info('Resend is coming soon');
  };

  // Time-to-provision: consumed_at - issued_at
  const timeToProvision =
    code.consumed_at && code.issued_at
      ? formatDuration(new Date(code.consumed_at).getTime() - new Date(code.issued_at).getTime())
      : null;

  return (
    <div className="flex flex-col h-full overflow-y-auto" data-testid="qr-detail-panel">
      {/* Panel header */}
      <div className="px-6 py-5 border-b border-[var(--color-border-subtle)]">
        <div className="flex items-start gap-4">
          {/* QR Preview placeholder */}
          <div className="h-16 w-16 rounded-lg bg-[var(--color-bg-secondary)] flex items-center justify-center flex-shrink-0">
            <QrCode className="h-8 w-8 text-muted-foreground opacity-50" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-[var(--color-accent)] flex items-center justify-center">
                <span className="text-xs font-medium text-[var(--color-accent-foreground)]">{initials}</span>
              </div>
              <div>
                <h2 className="text-base font-semibold text-text">{code.user_display_name || code.user_uid}</h2>
                <p className="text-sm text-muted-foreground">{code.user_org}</p>
              </div>
            </div>
            <div className="mt-2 flex items-center gap-2">
              <QRStatusBadge status={code.status} />
              <Badge variant="outline" className="text-xs font-mono">
                {code.token_hash.slice(0, 12)}...
              </Badge>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 mt-4">
          <Button variant="outline" size="sm" onClick={() => onRegenerate(code.user_uid)}>
            <RefreshCw className="h-3.5 w-3.5 mr-1.5" />
            Regenerate
          </Button>
          <Button variant="ghost" size="sm" onClick={handleResend}>
            <Send className="h-3.5 w-3.5 mr-1.5" />
            Resend
          </Button>
        </div>
      </div>

      {/* QR Details section */}
      <div className="px-6 py-4 border-b border-[var(--color-border-subtle)]">
        <h3 className="text-sm font-medium text-text mb-3">QR Details</h3>
        <DetailGrid columns={2}>
          <FieldCard label="Status" value={code.status} />
          <FieldCard label="Issued By" value={code.issued_by} />
          <FieldCard label="Created" value={formatDate(code.issued_at)} />
          <FieldCard label="Expires" value={formatDate(code.expires_at)} />
          {code.consumed_at && (
            <FieldCard label="Consumed" value={formatDate(code.consumed_at)} />
          )}
          {timeToProvision && (
            <FieldCard label="Time to Provision" value={timeToProvision} />
          )}
        </DetailGrid>
      </div>

      {/* Device section (only if device info exists) */}
      {(code.device_info || code.client_platform) && (
        <div className="px-6 py-4 border-b border-[var(--color-border-subtle)]">
          <h3 className="text-sm font-medium text-text mb-3">Device</h3>
          <DetailGrid columns={2}>
            {code.device_info && <FieldCard label="Device" value={code.device_info} />}
            {code.client_platform && <FieldCard label="Platform" value={code.client_platform} />}
          </DetailGrid>
        </div>
      )}

      {/* Provision checklist */}
      <div className="px-6 py-4 border-b border-[var(--color-border-subtle)]">
        <h3 className="text-sm font-medium text-text mb-3">Provision Checklist</h3>
        <div className="space-y-2">
          <ProvisionItem label="XMPP Credentials" included />
          <ProvisionItem label="SIP Credentials" included />
          <ProvisionItem label="SSO Profile" included={false} />
        </div>
      </div>

      {/* Activity timeline */}
      <div className="px-6 py-4">
        <h3 className="text-sm font-medium text-text mb-3">Activity Timeline</h3>
        {historyData?.history && historyData.history.length > 0 ? (
          <div className="space-y-3">
            {historyData.history.slice(0, 5).map((entry) => (
              <TimelineEntry
                key={entry.id}
                status={entry.status}
                date={entry.issued_at}
                consumedAt={entry.consumed_at}
                deviceInfo={entry.device_info}
              />
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No activity yet</p>
        )}
      </div>
    </div>
  );
}

function ProvisionItem({ label, included }: { label: string; included: boolean }) {
  return (
    <div className="flex items-center gap-2">
      {included ? (
        <CheckCircle2 className="h-4 w-4 text-emerald-400" />
      ) : (
        <XCircle className="h-4 w-4 text-gray-400" />
      )}
      <span className={cn('text-sm', included ? 'text-text' : 'text-muted-foreground')}>
        {label}
      </span>
      {!included && (
        <Badge variant="outline" className="text-[10px] ml-auto">Optional</Badge>
      )}
    </div>
  );
}

function TimelineEntry({
  status,
  date,
  consumedAt,
  deviceInfo,
}: {
  status: string;
  date: string;
  consumedAt: string | null;
  deviceInfo: string | null;
}) {
  const eventLabel = status === 'consumed'
    ? 'QR consumed'
    : status === 'revoked'
      ? 'Token revoked'
      : status === 'expired'
        ? 'Token expired'
        : 'QR generated';

  return (
    <div className="flex gap-3">
      <div className="flex flex-col items-center">
        <div className="h-2 w-2 rounded-full bg-[var(--color-border-subtle)] mt-1.5" />
        <div className="flex-1 w-px bg-[var(--color-border-subtle)]" />
      </div>
      <div className="pb-3">
        <p className="text-sm text-text">{eventLabel}</p>
        <p className="text-xs text-muted-foreground">{formatDate(date)}</p>
        {consumedAt && (
          <p className="text-xs text-muted-foreground">Consumed: {formatDate(consumedAt)}</p>
        )}
        {deviceInfo && (
          <p className="text-xs text-muted-foreground">{deviceInfo}</p>
        )}
      </div>
    </div>
  );
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

function formatDuration(ms: number): string {
  const sec = Math.floor(ms / 1000);
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ${sec % 60}s`;
  const hr = Math.floor(min / 60);
  return `${hr}h ${min % 60}m`;
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors. Note: DetailGrid/FieldCard API may need adjustment per actual @azblink/ui exports — verify during visual testing.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/qr-management/QRDetailPanel.tsx
git commit -m "$(cat <<'EOF'
feat(qr-management): add QRDetailPanel with info grid, checklist, and timeline (Phase 2, Task 14)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 15: Frontend — Create QRManagementPage (Page Orchestrator)

**Files:**
- Create: `src/frontend/src/components/features/qr-management/QRManagementPage.tsx`

**Step 1: Create the page component**

Create `src/frontend/src/components/features/qr-management/QRManagementPage.tsx`:

```tsx
/**
 * Top-level QR Code Management page — resizable split-panel master-detail layout.
 * - Left panel: QR list with search + filter tabs (drag handle to resize)
 * - Right panel: QR detail panel (QRDetailPanel)
 * - URL search params drive selection: ?qrId=abc123&filter=all&search=&dateRange=7d
 * - Cmd+K to focus search input
 * - Generate/Regenerate modals wired via useQRModalState
 * - Panel width persists to localStorage (key: panel-width:qr-management)
 */
import { useCallback, useEffect, useRef, Suspense } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { QrCode } from 'lucide-react';
import { PageHeader } from './PageHeader';
import { StatsRow } from './StatsRow';
import { QRList, QRListSkeleton } from './QRList';
import { QRDetailPanel } from './QRDetailPanel';
import { useQRModalState } from './useModalState';
import { qrCodesQueryOptions } from '@/lib/queries/qr-management';
import { useResizablePanel } from '@/hooks/use-resizable-panel';
import { ResizeHandle } from '@/components/layout/resize-handle';
import type { QRManagementSearchParams, QRFilter, QRDateRange } from '@/types/qr-management';

export { type QRManagementSearchParams };

interface QRManagementPageProps {
  searchParams: QRManagementSearchParams;
}

export function QRManagementPage({ searchParams }: QRManagementPageProps) {
  const {
    qrId,
    filter = 'all',
    search = '',
    dateRange = '7d',
  } = searchParams;
  const page = searchParams.page ?? 0;
  const pageSize = searchParams.pageSize ?? 50;
  const navigate = useNavigate();
  const searchRef = useRef<HTMLInputElement>(null);
  const modal = useQRModalState();
  const {
    leftWidth,
    containerRef,
    handleMouseDown: handleResizeMouseDown,
    handleDoubleClick: handleResizeDoubleClick,
    isDragging,
    nudge,
  } = useResizablePanel({
    storageKey: 'panel-width:qr-management',
    defaultLeftWidth: 0,
    minLeftWidth: 280,
    minRightWidth: 340,
  });

  // Cmd+K / Ctrl+K to focus search
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, []);

  const updateSearchParams = useCallback(
    (updates: Partial<QRManagementSearchParams>) => {
      navigate({
        to: '/provisioning/qr-codes',
        search: (prev: Record<string, unknown>) => ({
          ...prev,
          ...updates,
        }),
        replace: true,
      });
    },
    [navigate],
  );

  const handleSelectQR = useCallback(
    (tokenHash: string) => updateSearchParams({ qrId: tokenHash }),
    [updateSearchParams],
  );

  const handleFilterChange = useCallback(
    (f: QRFilter) => updateSearchParams({ filter: f, page: 0 }),
    [updateSearchParams],
  );

  const handleSearchChange = useCallback(
    (s: string) => updateSearchParams({ search: s || undefined, page: 0 }),
    [updateSearchParams],
  );

  const handleDateRangeChange = useCallback(
    (dr: QRDateRange) => updateSearchParams({ dateRange: dr, page: 0 }),
    [updateSearchParams],
  );

  const handlePageChange = useCallback(
    (p: number) => updateSearchParams({ page: p }),
    [updateSearchParams],
  );

  const handleRegenerate = useCallback(
    (uid: string) => modal.openRegenerate(uid),
    [modal],
  );

  return (
    <div className="flex flex-col gap-6 flex-1 min-h-0">
      <PageHeader
        search={search}
        onSearchChange={handleSearchChange}
        dateRange={dateRange as QRDateRange}
        onDateRangeChange={handleDateRangeChange}
        onGenerateQR={modal.openGenerate}
        searchInputRef={searchRef}
      />

      <StatsRow dateRange={dateRange as QRDateRange} />

      {/* Split panel: resizable left (list) | right (detail) */}
      <div ref={containerRef} className="flex flex-1 min-h-0">
        {/* Left panel: QR list */}
        <div
          style={leftWidth > 0 ? { width: leftWidth } : undefined}
          className="shrink-0 min-w-0 w-full lg:w-auto"
        >
          <Suspense fallback={<QRListSkeleton />}>
            <QRListPanel
              selectedQRId={qrId}
              filter={filter as QRFilter}
              search={search}
              dateRange={dateRange as QRDateRange}
              page={page}
              pageSize={pageSize}
              onSelectQR={handleSelectQR}
              onFilterChange={handleFilterChange}
              onPageChange={handlePageChange}
            />
          </Suspense>
        </div>

        {/* Resize handle (desktop only) */}
        <ResizeHandle
          className="hidden lg:flex"
          onMouseDown={handleResizeMouseDown}
          onDoubleClick={handleResizeDoubleClick}
          isDragging={isDragging}
          onNudge={nudge}
        />

        {/* Right panel: QR detail */}
        <div className="hidden lg:flex flex-1 min-w-0 flex-col rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden">
          <Suspense fallback={<QRDetailSkeleton />}>
            <QRDetailPanelWrapper
              qrId={qrId}
              filter={filter as QRFilter}
              search={search}
              dateRange={dateRange as QRDateRange}
              page={page}
              pageSize={pageSize}
              onRegenerate={handleRegenerate}
            />
          </Suspense>
        </div>
      </div>

      {/* TODO: Modals will be wired in a subsequent task */}
    </div>
  );
}

/** Suspense-wrapped QR list with data fetching */
function QRListPanel({
  selectedQRId,
  filter,
  search,
  dateRange,
  page,
  pageSize,
  onSelectQR,
  onFilterChange,
  onPageChange,
}: {
  selectedQRId: string | undefined;
  filter: QRFilter;
  search: string;
  dateRange: QRDateRange;
  page: number;
  pageSize: number;
  onSelectQR: (tokenHash: string) => void;
  onFilterChange: (f: QRFilter) => void;
  onPageChange: (page: number) => void;
}) {
  const { data } = useSuspenseQuery(
    qrCodesQueryOptions({
      limit: pageSize,
      offset: page * pageSize,
      search: search || undefined,
      status: filter !== 'all' ? filter : undefined,
      date_range: dateRange,
      sort: 'issued_at',
      order: 'desc',
    }),
  );

  return (
    <QRList
      codes={data.codes}
      totalCount={data.total}
      selectedQRId={selectedQRId}
      filter={filter}
      onFilterChange={onFilterChange}
      onSelectQR={onSelectQR}
      page={page}
      pageSize={pageSize}
      onPageChange={onPageChange}
    />
  );
}

/** Wrapper that resolves selected code from list data */
function QRDetailPanelWrapper({
  qrId,
  filter,
  search,
  dateRange,
  page,
  pageSize,
  onRegenerate,
}: {
  qrId: string | undefined;
  filter: QRFilter;
  search: string;
  dateRange: QRDateRange;
  page: number;
  pageSize: number;
  onRegenerate: (uid: string) => void;
}) {
  const { data } = useSuspenseQuery(
    qrCodesQueryOptions({
      limit: pageSize,
      offset: page * pageSize,
      search: search || undefined,
      status: filter !== 'all' ? filter : undefined,
      date_range: dateRange,
      sort: 'issued_at',
      order: 'desc',
    }),
  );

  const selectedCode = qrId
    ? data.codes.find((c) => c.token_hash === qrId)
    : undefined;

  if (!selectedCode) {
    return <EmptyDetailPanel />;
  }

  return <QRDetailPanel code={selectedCode} onRegenerate={onRegenerate} />;
}

function EmptyDetailPanel() {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-2 text-[var(--color-text-muted)]">
      <QrCode className="h-12 w-12 opacity-30" />
      <p className="text-sm">Select a QR code to view details</p>
    </div>
  );
}

function QRDetailSkeleton() {
  return (
    <div className="p-6 space-y-4">
      <div className="flex gap-4">
        <div className="h-16 w-16 rounded-lg bg-muted animate-pulse" />
        <div className="space-y-2 flex-1">
          <div className="h-5 w-32 bg-muted animate-pulse rounded" />
          <div className="h-4 w-24 bg-muted animate-pulse rounded" />
        </div>
      </div>
      <div className="h-px bg-[var(--color-border-subtle)]" />
      <div className="grid grid-cols-2 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-16 bg-muted animate-pulse rounded" />
        ))}
      </div>
    </div>
  );
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/qr-management/QRManagementPage.tsx
git commit -m "$(cat <<'EOF'
feat(qr-management): add QRManagementPage split-panel orchestrator (Phase 2, Task 15)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 16: Frontend — Create Route File

**Files:**
- Create: `src/frontend/src/routes/provisioning/qr-codes.tsx`

**Step 1: Create the route file**

Create `src/frontend/src/routes/provisioning/qr-codes.tsx`:

```tsx
/**
 * QR Code Management page — /provisioning/qr-codes
 * Split-panel master-detail layout for QR code management.
 * URL search params: ?qrId, ?filter, ?search, ?dateRange, ?page, ?pageSize
 */
import { createFileRoute } from '@tanstack/react-router';
import {
  QRManagementPage,
  type QRManagementSearchParams,
} from '@/components/features/qr-management/QRManagementPage';
import type { QRFilter, QRDateRange } from '@/types/qr-management';

const validFilters: QRFilter[] = ['all', 'consumed', 'pending', 'expired', 'revoked'];
const validDateRanges: QRDateRange[] = ['7d', '30d', '90d', 'all'];

export const Route = createFileRoute('/provisioning/qr-codes')({
  validateSearch: (search: Record<string, unknown>): QRManagementSearchParams => ({
    qrId: (search.qrId as string) || undefined,
    filter: validFilters.includes(search.filter as QRFilter)
      ? (search.filter as QRFilter)
      : 'all',
    search: (search.search as string) || undefined,
    dateRange: validDateRanges.includes(search.dateRange as QRDateRange)
      ? (search.dateRange as QRDateRange)
      : '7d',
    page: search.page != null ? Number(search.page) || 0 : undefined,
    pageSize: search.pageSize != null ? Number(search.pageSize) || undefined : undefined,
  }),
  component: QRCodesPage,
});

function QRCodesPage() {
  const searchParams = Route.useSearch();
  return <QRManagementPage searchParams={searchParams} />;
}
```

**Step 2: Regenerate the route tree**

Run: `cd src/frontend && npx @tanstack/router-cli generate`
Expected: Route tree regenerated with new `/provisioning/qr-codes` route.

**Step 3: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 4: Commit**

```bash
git add src/frontend/src/routes/provisioning/qr-codes.tsx src/frontend/src/routeTree.gen.ts
git commit -m "$(cat <<'EOF'
feat(qr-management): add /provisioning/qr-codes route (Phase 2, Task 16)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 17: Visual Smoke Test

**Step 1: Start the dev stack (if not already running)**

Run: `just up-bg` (or verify with `just ps`)

**Step 2: Open the new page in a browser**

Navigate to: `http://localhost:8081/provisioning/qr-codes`

**Step 3: Verify**

- Page header renders with title, search, date range, generate button
- Stats row shows 4 cards (may show 0 if no QR codes exist)
- Left panel shows QR list (or empty state)
- Right panel shows "Select a QR code to view details"
- Resize handle works between panels
- Cmd+K focuses search input

**Step 4: Fix any visual issues found**

If the Tabs component API doesn't match (e.g., `Tabs.Item` vs `TabsTrigger`), adjust the import in `QRList.tsx`. Similarly for DetailGrid/FieldCard props.

**Step 5: Commit any fixes**

```bash
git add -A
git commit -m "$(cat <<'EOF'
fix: address visual issues from QR management smoke test

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 18: Frontend — Create GenerateQRModal

**Files:**
- Create: `src/frontend/src/components/features/qr-management/modals/GenerateQRModal.tsx`

**Step 1: Create the modal**

Create `src/frontend/src/components/features/qr-management/modals/GenerateQRModal.tsx`:

```tsx
/**
 * Generate QR modal — select a user, validity period, and delivery method.
 * - User select: async search via usersQueryOptions
 * - Validity: reuses pattern from user-management
 * - Delivery: Display only (email/SMS stubbed)
 * - On submit: useGenerateQR mutation → invalidate QR codes + stats
 */
import { useState, Suspense } from 'react';
import { useSuspenseQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Dialog, Input, cn } from '@azblink/ui';
import { Search, QrCode } from 'lucide-react';
import { usersQueryOptions } from '@/lib/queries/users';
import { useGenerateQR } from '@/lib/queries/qr-generation';
import { queryKeys } from '@/lib/queries/keys';
import { getInitials } from '@/lib/utils/user-helpers';
import { toast } from 'sonner';
import type { User } from '@/types';

interface GenerateQRModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: (uid: string) => void;
}

const TTL_OPTIONS = [
  { label: '1 hour', seconds: 3600 },
  { label: '4 hours', seconds: 14400 },
  { label: '24 hours', seconds: 86400 },
  { label: '7 days', seconds: 604800 },
];

export function GenerateQRModal({ open, onOpenChange, onSuccess }: GenerateQRModalProps) {
  const [selectedUid, setSelectedUid] = useState<string | null>(null);
  const [ttlSec, setTtlSec] = useState(3600);
  const [userSearch, setUserSearch] = useState('');
  const generateQR = useGenerateQR();
  const queryClient = useQueryClient();

  const handleSubmit = () => {
    if (!selectedUid) {
      toast.error('Please select a user');
      return;
    }

    generateQR.mutate(
      { uid: selectedUid, ttlSec },
      {
        onSuccess: () => {
          // Invalidate QR management queries
          queryClient.invalidateQueries({ queryKey: queryKeys.qrCodes.all });
          toast.success(`QR code generated for ${selectedUid}`);
          onSuccess?.(selectedUid);
          handleClose();
        },
      },
    );
  };

  const handleClose = () => {
    setSelectedUid(null);
    setTtlSec(3600);
    setUserSearch('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <Dialog.Content className="sm:max-w-[480px]">
        <Dialog.Header>
          <Dialog.Title className="flex items-center gap-2">
            <QrCode className="h-5 w-5" />
            Generate QR Code
          </Dialog.Title>
          <Dialog.Description>
            Generate a provisioning QR code for a user
          </Dialog.Description>
        </Dialog.Header>

        <div className="space-y-4 py-4">
          {/* User select */}
          <div>
            <label className="text-sm font-medium text-text mb-1.5 block">User</label>
            <div className="relative mb-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search users..."
                className="pl-10"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                autoFocus
              />
            </div>
            <Suspense fallback={<UserListSkeleton />}>
              <UserPicker
                search={userSearch}
                selectedUid={selectedUid}
                onSelect={setSelectedUid}
              />
            </Suspense>
          </div>

          {/* Validity */}
          <div>
            <label className="text-sm font-medium text-text mb-1.5 block">Validity</label>
            <div className="grid grid-cols-2 gap-2">
              {TTL_OPTIONS.map((opt) => (
                <button
                  key={opt.seconds}
                  type="button"
                  onClick={() => setTtlSec(opt.seconds)}
                  className={cn(
                    'px-3 py-2 rounded-md border text-sm transition-colors',
                    ttlSec === opt.seconds
                      ? 'border-[var(--color-accent)] bg-[var(--color-accent)]/10 text-text'
                      : 'border-[var(--color-border-subtle)] text-muted-foreground hover:bg-[var(--color-bg-secondary)]',
                  )}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <Dialog.Footer>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!selectedUid || generateQR.isPending}
          >
            {generateQR.isPending ? 'Generating...' : 'Generate QR'}
          </Button>
        </Dialog.Footer>
      </Dialog.Content>
    </Dialog>
  );
}

function UserPicker({
  search,
  selectedUid,
  onSelect,
}: {
  search: string;
  selectedUid: string | null;
  onSelect: (uid: string) => void;
}) {
  const { data } = useSuspenseQuery(usersQueryOptions());
  const users = data.users || [];

  const filtered = users.filter(
    (u) =>
      u.uid.toLowerCase().includes(search.toLowerCase()) ||
      u.displayName?.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="max-h-[160px] overflow-y-auto rounded-md border border-[var(--color-border-subtle)]">
      {filtered.length === 0 ? (
        <p className="p-3 text-sm text-muted-foreground">No users found</p>
      ) : (
        filtered.slice(0, 20).map((user) => (
          <UserOption
            key={user.uid}
            user={user}
            isSelected={user.uid === selectedUid}
            onSelect={() => onSelect(user.uid)}
          />
        ))
      )}
    </div>
  );
}

function UserOption({
  user,
  isSelected,
  onSelect,
}: {
  user: User;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const initials = getInitials(user.displayName || user.uid);
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        'w-full flex items-center gap-3 px-3 py-2 text-left transition-colors',
        isSelected ? 'bg-[var(--color-accent)]/10' : 'hover:bg-[var(--color-bg-secondary)]',
      )}
    >
      <div className="h-7 w-7 rounded-full bg-[var(--color-accent)] flex items-center justify-center">
        <span className="text-[10px] font-medium text-[var(--color-accent-foreground)]">{initials}</span>
      </div>
      <div className="min-w-0">
        <p className="text-sm font-medium text-text truncate">{user.displayName || user.uid}</p>
        <p className="text-xs text-muted-foreground truncate">{user.mail}</p>
      </div>
    </button>
  );
}

function UserListSkeleton() {
  return (
    <div className="space-y-2 max-h-[160px]">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="h-10 bg-muted animate-pulse rounded" />
      ))}
    </div>
  );
}
```

**Step 2: Wire modal into QRManagementPage**

In `QRManagementPage.tsx`, add the import and render the modal. Add after the `{/* TODO: Modals will be wired in a subsequent task */}` comment:

```tsx
// Import at top of file:
import { GenerateQRModal } from './modals/GenerateQRModal';

// Replace the TODO comment with:
      <GenerateQRModal
        open={modal.state.kind === 'generate_qr'}
        onOpenChange={(open) => { if (!open) modal.close(); }}
      />
```

**Step 3: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: No errors.

**Step 4: Visual test**

Navigate to `http://localhost:8081/provisioning/qr-codes`, click "Generate QR", verify modal opens.

**Step 5: Commit**

```bash
git add src/frontend/src/components/features/qr-management/modals/GenerateQRModal.tsx src/frontend/src/components/features/qr-management/QRManagementPage.tsx
git commit -m "$(cat <<'EOF'
feat(qr-management): add GenerateQRModal with user select and validity picker (Phase 3, Task 18)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 19: Add Route Redirect from Old QR Generator

**Files:**
- Modify: `src/frontend/src/routes/provisioning/qr-generator.tsx`

**Step 1: Replace the old page with a redirect**

Replace the entire content of `src/frontend/src/routes/provisioning/qr-generator.tsx`:

```tsx
/**
 * Legacy QR Generator route — redirects to /provisioning/qr-codes.
 * Preserves ?uid param if present (mapped to search query).
 */
import { createFileRoute, redirect } from '@tanstack/react-router';

export const Route = createFileRoute('/provisioning/qr-generator')({
  beforeLoad: ({ search }) => {
    const uid = (search as Record<string, unknown>).uid as string | undefined;
    throw redirect({
      to: '/provisioning/qr-codes',
      search: uid ? { search: uid } : {},
    });
  },
});
```

**Step 2: Regenerate route tree**

Run: `cd src/frontend && npx @tanstack/router-cli generate`

**Step 3: Verify redirect works**

Navigate to `http://localhost:8081/provisioning/qr-generator` — should redirect to `/provisioning/qr-codes`.
Navigate to `http://localhost:8081/provisioning/qr-generator?uid=mei` — should redirect to `/provisioning/qr-codes?search=mei`.

**Step 4: Commit**

```bash
git add src/frontend/src/routes/provisioning/qr-generator.tsx src/frontend/src/routeTree.gen.ts
git commit -m "$(cat <<'EOF'
feat(qr-management): redirect /provisioning/qr-generator to /provisioning/qr-codes (Phase 6, Task 19)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 20: Accessibility + data-testid + DRY Audit

**Files:**
- Modify: Multiple QR management files as needed

**Step 1: Verify accessibility attributes**

Check the following in each component:
- `aria-current="true"` on selected QRRow — already implemented
- `aria-live="polite"` on stats counts — already in StatsRow
- `aria-live="polite"` on list count — already in QRList
- `aria-label` on search input — already in PageHeader
- `aria-label` on audit link icon — already in QRRow

**Step 2: Verify data-testid attributes**

Check:
- `data-testid="qr-table"` on QRList — done
- `data-testid="qr-row-{id}"` on QRRow — done
- `data-testid="qr-status-{status}"` on QRStatusBadge — done
- `data-testid="qr-detail-panel"` on QRDetailPanel — done

**Step 3: DRY audit**

Verify:
- No local `getInitials()` — using `@/lib/utils/user-helpers` import
- No hardcoded color values — all using CSS custom properties or Tailwind token bridge
- No duplicated status derivation logic — all on backend

**Step 4: Fix any issues found**

Apply fixes as needed.

**Step 5: Commit**

```bash
git add -A
git commit -m "$(cat <<'EOF'
fix(qr-management): accessibility, data-testid, and DRY audit (Phase 6, Task 20)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 21: Integration Test — Backend Endpoints

**Files:**
- Create: `tests/test_qr_management.py`

**Step 1: Write the test**

Create `tests/test_qr_management.py`:

```python
"""Integration tests for QR Code Management endpoints.

- GET /api/qr/codes — enriched QR list
- GET /api/qr/stats — aggregate QR stats
- Both require admin auth
"""
import pytest
import requests

BASE = "http://localhost:8081/api"


def get_admin_token():
    """Login as admin user and return JWT token."""
    r = requests.post(f"{BASE}/auth/login", json={
        "username": "mei",
        "password": "password123",
    })
    assert r.status_code == 200
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def admin_token():
    return get_admin_token()


@pytest.fixture(scope="module")
def auth_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


class TestQRCodes:
    """Tests for GET /api/qr/codes."""

    def test_returns_200_with_codes_array(self, auth_headers):
        r = requests.get(f"{BASE}/qr/codes", headers=auth_headers)
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert isinstance(body["codes"], list)
        assert "total" in body
        assert "limit" in body
        assert "offset" in body

    def test_pagination_params(self, auth_headers):
        r = requests.get(f"{BASE}/qr/codes", headers=auth_headers, params={
            "limit": 5, "offset": 0,
        })
        assert r.status_code == 200
        body = r.json()
        assert body["limit"] == 5
        assert body["offset"] == 0

    def test_status_filter(self, auth_headers):
        r = requests.get(f"{BASE}/qr/codes", headers=auth_headers, params={
            "status": "consumed",
        })
        assert r.status_code == 200
        body = r.json()
        for code in body["codes"]:
            assert code["status"] == "consumed"

    def test_date_range_filter(self, auth_headers):
        r = requests.get(f"{BASE}/qr/codes", headers=auth_headers, params={
            "date_range": "30d",
        })
        assert r.status_code == 200
        assert r.json()["ok"] is True

    def test_requires_admin(self):
        r = requests.get(f"{BASE}/qr/codes")
        assert r.status_code in (401, 403)


class TestQRStats:
    """Tests for GET /api/qr/stats."""

    def test_returns_200_with_stats(self, auth_headers):
        r = requests.get(f"{BASE}/qr/stats", headers=auth_headers)
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert "total_generated" in body
        assert "consumed" in body
        assert "pending" in body
        assert "expired_unused" in body

    def test_date_range_param(self, auth_headers):
        r = requests.get(f"{BASE}/qr/stats", headers=auth_headers, params={
            "date_range": "all",
        })
        assert r.status_code == 200
        assert r.json()["ok"] is True

    def test_requires_admin(self):
        r = requests.get(f"{BASE}/qr/stats")
        assert r.status_code in (401, 403)
```

**Step 2: Run the test**

Run: `just test-quick -- tests/test_qr_management.py -v`
Expected: All tests pass (or fail with clear reasons if the stack needs QR data seeded first).

**Step 3: Fix any failures**

If tests fail due to missing seed data, that's acceptable — the structure/schema tests should still pass.

**Step 4: Commit**

```bash
git add tests/test_qr_management.py
git commit -m "$(cat <<'EOF'
test(qr-management): add integration tests for /api/qr/codes and /api/qr/stats (Phase 5, Task 21)

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 22: Final Code Review

**Step 1: Run full TypeScript check**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No errors.

**Step 2: Run existing tests**

Run: `just test-quick`
Expected: No regressions.

**Step 3: Review checklist**

- [ ] All new files have JSDoc/file-level comments
- [ ] No hardcoded colors in CSS — all using tokens
- [ ] No duplicate `getInitials()` or similar helpers
- [ ] All imports resolve correctly
- [ ] Backend endpoints return correct shapes
- [ ] Old route redirects to new route
- [ ] Query keys follow existing naming pattern
- [ ] Modal state machine follows existing pattern
- [ ] `require_admin` on both new endpoints
- [ ] Accessibility attributes present

**Step 4: Commit any final fixes**

```bash
git add -A
git commit -m "$(cat <<'EOF'
fix(qr-management): final review fixes

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## File Manifest

### New Files (15)

| # | File | Phase | Task |
|---|------|-------|------|
| 1 | `src/frontend/src/types/qr-management.ts` | 0 | 1 |
| 2 | `src/frontend/src/components/features/qr-management/qr-status-config.ts` | 0 | 3 |
| 3 | `src/frontend/src/components/features/qr-management/useModalState.ts` | 1 | 8 |
| 4 | `src/frontend/src/components/features/qr-management/QRStatusBadge.tsx` | 1 | 9 |
| 5 | `src/frontend/src/components/features/qr-management/PageHeader.tsx` | 1 | 10 |
| 6 | `src/frontend/src/components/features/qr-management/StatsRow.tsx` | 2 | 11 |
| 7 | `src/frontend/src/components/features/qr-management/QRRow.tsx` | 2 | 12 |
| 8 | `src/frontend/src/components/features/qr-management/QRList.tsx` | 2 | 13 |
| 9 | `src/frontend/src/components/features/qr-management/QRDetailPanel.tsx` | 2 | 14 |
| 10 | `src/frontend/src/components/features/qr-management/QRManagementPage.tsx` | 2 | 15 |
| 11 | `src/frontend/src/routes/provisioning/qr-codes.tsx` | 2 | 16 |
| 12 | `src/frontend/src/lib/queries/qr-management.ts` | 1 | 7 |
| 13 | `src/frontend/src/components/features/qr-management/modals/GenerateQRModal.tsx` | 3 | 18 |
| 14 | `tests/test_qr_management.py` | 5 | 21 |

### Modified Files (4)

| # | File | Task |
|---|------|------|
| 1 | `src/frontend/src/types/index.ts` | 1 |
| 2 | `src/frontend/src/lib/queries/keys.ts` | 2 |
| 3 | `src/backend/orgdb.py` | 4, 5 |
| 4 | `src/backend/main.py` | 6 |

### Redirect File (1)

| # | File | Task |
|---|------|------|
| 1 | `src/frontend/src/routes/provisioning/qr-generator.tsx` | 19 |
