# Reusable DataTable + Server-Side Pagination — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a full-stack reusable DataTable system with TanStack Table + standalone Pagination primitive, backed by server-side pagination on GET /api/users and GET /api/groups.

**Architecture:** Two composable UI pieces in @azblink/ui: (1) `<Pagination>` — standalone pagination controls usable by both DataTable and existing split-panel lists, and (2) `<DataTable>` — TanStack Table wrapper rendering through existing Table primitives with all features opt-in via props. Backend adds `limit/offset/search/status/sort/order` to list endpoints with in-memory pagination (Python list slicing).

**Tech Stack:** TanStack Table v8, TanStack Query v5, TanStack Router, React 19, Tailwind CSS 4, @azblink/ui (CSS Modules + design tokens), FastAPI (Python backend), LDAP

**Design doc:** `docs/plans/2026-02-09-reusable-datatable-design.md`

---

## Task 1: Add PaginatedResponse Types

**Files:**
- Modify: `src/frontend/src/types/api.ts`

**Step 1: Add generic pagination types**

Append to `src/frontend/src/types/api.ts` (after the existing `isApiError` function, before EOF):

```typescript
/** Generic paginated response base — backends return total + hasMore alongside data */
export interface PaginationMeta {
  ok: boolean;
  total: number;
  hasMore: boolean;
}

/** Paginated users response from GET /api/users */
export interface PaginatedUsersResponse extends PaginationMeta {
  users: import('./user').User[];
}

/** Paginated groups response from GET /api/groups */
export interface PaginatedGroupsResponse extends PaginationMeta {
  groups: import('./group').GroupListItem[];
}

/** Common query params for paginated list endpoints */
export interface PaginationParams {
  limit?: number;
  offset?: number;
  search?: string;
  sort?: string;
  order?: 'asc' | 'desc';
}
```

**Step 2: Export from types/index.ts**

Add to `src/frontend/src/types/index.ts`:

```typescript
export type { PaginationMeta, PaginatedUsersResponse, PaginatedGroupsResponse, PaginationParams } from './api';
```

**Step 3: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No new errors (2 pre-existing errors OK)

**Step 4: Commit**

```bash
git add src/frontend/src/types/api.ts src/frontend/src/types/index.ts
git commit -m "feat(types): add PaginationMeta, PaginatedUsersResponse, PaginatedGroupsResponse types"
```

---

## Task 2: Backend — Add Pagination to GET /api/users

**Files:**
- Modify: `src/backend/main.py` (lines 1077-1102: `api_users` function)
- Test: `tests/test_users.py`

**Context:** The existing `api_users()` at line 1077 accepts `q` and `status` params, calls `list_users()`, applies in-memory filtering, and returns `{"ok": True, "users": [...]}` with no pagination. Follow the pattern from `api_orgs_users()` at line 763 which already has `limit/offset/total/hasMore`.

**Step 1: Write backend test**

Add to `tests/test_users.py`:

```python
class TestUserListPagination:
    """GET /api/users with pagination, sorting, and filtering."""

    def test_default_returns_all_users(self, client):
        """Without limit param, return all users (backward compatible)."""
        resp = client.get("/api/users")
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert "users" in data
        assert "total" in data

    def test_pagination_limit_offset(self, client):
        """limit/offset returns a page slice with total and hasMore."""
        resp = client.get("/api/users?limit=2&offset=0")
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert len(data["users"]) <= 2
        assert isinstance(data["total"], int)
        assert isinstance(data["hasMore"], bool)
        if data["total"] > 2:
            assert data["hasMore"] is True

    def test_pagination_offset_beyond_total(self, client):
        """Offset beyond total returns empty page."""
        resp = client.get("/api/users?limit=10&offset=99999")
        assert resp.status_code == 200
        data = resp.json()
        assert data["users"] == []
        assert data["hasMore"] is False

    def test_search_filter(self, client):
        """search param filters by uid, displayName, mail (case-insensitive)."""
        resp = client.get("/api/users?search=mei&limit=50")
        assert resp.status_code == 200
        data = resp.json()
        # At least the seed user 'mei' should match
        assert data["total"] >= 1
        for u in data["users"]:
            name_match = "mei" in u.get("uid", "").lower() or \
                         "mei" in u.get("displayName", "").lower() or \
                         "mei" in u.get("mail", "").lower()
            assert name_match, f"User {u['uid']} does not match search 'mei'"

    def test_status_filter(self, client):
        """status param filters by accountStatus."""
        resp = client.get("/api/users?status=active&limit=50")
        assert resp.status_code == 200
        data = resp.json()
        for u in data["users"]:
            assert u["accountStatus"] == "active"

    def test_sort_ascending(self, client):
        """sort + order params control result ordering."""
        resp = client.get("/api/users?sort=uid&order=asc&limit=50")
        assert resp.status_code == 200
        data = resp.json()
        uids = [u["uid"] for u in data["users"]]
        assert uids == sorted(uids, key=str.lower)

    def test_sort_descending(self, client):
        """sort=uid&order=desc returns reverse order."""
        resp = client.get("/api/users?sort=uid&order=desc&limit=50")
        assert resp.status_code == 200
        data = resp.json()
        uids = [u["uid"] for u in data["users"]]
        assert uids == sorted(uids, key=str.lower, reverse=True)
```

**Step 2: Run tests to verify they fail**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack && just test-quick -- tests/test_users.py::TestUserListPagination -v`
Expected: FAIL (no `total` in response yet)

**Step 3: Implement pagination in api_users()**

Replace the `api_users` function in `src/backend/main.py` (line 1077-1102):

```python
@app.get("/api/users")
def api_users(
    q: Optional[str] = None,
    search: Optional[str] = None,
    status: Optional[str] = None,
    limit: Optional[int] = None,
    offset: int = 0,
    sort: str = "displayName",
    order: str = "asc",
    claims: Dict[str, Any] = Depends(require_user),
):
    """List users with optional filtering, sorting, and pagination.

    - q/search: case-insensitive substring search on uid, displayName, mail (q is alias for backward compat)
    - status: filter by accountStatus (active, pending, suspended, terminated)
    - limit: items per page (omit for all results — backward compatible)
    - offset: skip N items (default 0)
    - sort: field to sort by (uid, displayName, mail, accountStatus; default displayName)
    - order: asc or desc (default asc)
    """
    users = list_users()

    # Apply search filter (support both 'q' and 'search' params)
    search_term = search or q
    if search_term:
        q_lower = search_term.lower()
        users = [
            u for u in users
            if q_lower in u.get("uid", "").lower()
            or q_lower in u.get("displayName", "").lower()
            or q_lower in u.get("mail", "").lower()
        ]

    if status and status in ("active", "pending", "suspended", "terminated"):
        users = [u for u in users if u.get("accountStatus") == status]

    # Sort
    sort_key = sort if sort in ("uid", "displayName", "mail", "accountStatus") else "displayName"
    reverse = order.lower() == "desc"
    users.sort(key=lambda u: (u.get(sort_key) or "").lower(), reverse=reverse)

    total = len(users)

    # Paginate (only if limit is explicitly provided — backward compatible)
    if limit is not None:
        limit = min(max(1, limit), 200)  # clamp 1-200
        paginated = users[offset:offset + limit]
        return {
            "ok": True,
            "users": paginated,
            "total": total,
            "hasMore": (offset + limit) < total,
        }

    # No limit = return all (backward compatible)
    return {"ok": True, "users": users, "total": total, "hasMore": False}
```

**Step 4: Run tests to verify they pass**

Run: `just test-quick -- tests/test_users.py::TestUserListPagination -v`
Expected: All PASS

**Step 5: Also run the existing user tests to verify no regression**

Run: `just test-quick -- tests/test_users.py -v`
Expected: All PASS (backward compatible — no `limit` = full list)

**Step 6: Commit**

```bash
git add src/backend/main.py tests/test_users.py
git commit -m "feat(api): add pagination, sorting, search to GET /api/users"
```

---

## Task 3: Backend — Add Pagination to GET /api/groups

**Files:**
- Modify: `src/backend/main.py` (lines 802-847: `api_groups` function)
- Test: `tests/test_org_groups.py` (or wherever group tests live)

**Context:** Same pattern as Task 2. The existing `api_groups()` at line 802 accepts `type` and `search` params with LDAP + PostgreSQL enrichment.

**Step 1: Write backend test**

Add to the appropriate groups test file:

```python
class TestGroupListPagination:
    """GET /api/groups with pagination and sorting."""

    def test_default_returns_all_groups(self, client):
        """Without limit, returns all groups with total."""
        resp = client.get("/api/groups")
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert "groups" in data
        assert "total" in data

    def test_pagination_limit_offset(self, client):
        """limit/offset returns a page slice."""
        resp = client.get("/api/groups?limit=2&offset=0")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["groups"]) <= 2
        assert isinstance(data["total"], int)
        assert isinstance(data["hasMore"], bool)

    def test_sort_by_cn(self, client):
        """sort=cn&order=asc returns alphabetically sorted groups."""
        resp = client.get("/api/groups?sort=cn&order=asc&limit=50")
        assert resp.status_code == 200
        data = resp.json()
        cns = [g["cn"] for g in data["groups"]]
        assert cns == sorted(cns, key=str.lower)

    def test_search_and_paginate(self, client):
        """search + limit works together."""
        resp = client.get("/api/groups?search=admin&limit=10")
        assert resp.status_code == 200
        data = resp.json()
        for g in data["groups"]:
            text = (g["cn"] + " " + (g.get("description") or "")).lower()
            assert "admin" in text
```

**Step 2: Run tests — expected FAIL**

Run: `just test-quick -- tests/test_org_groups.py::TestGroupListPagination -v`

**Step 3: Implement pagination in api_groups()**

Replace the `api_groups` function in `src/backend/main.py` (line 802-847):

```python
@app.get("/api/groups")
def api_groups(
    group_type: Optional[str] = Query(None, alias="type"),
    search: Optional[str] = None,
    limit: Optional[int] = None,
    offset: int = 0,
    sort: str = "cn",
    order: str = "asc",
    claims: Dict[str, Any] = Depends(require_user),
):
    """List groups with enriched Postgres metadata, optional filtering, sorting, pagination.

    - type: filter by group_type (case-insensitive)
    - search: substring match on cn or description (case-insensitive)
    - limit: items per page (omit for all — backward compatible)
    - offset: skip N items (default 0)
    - sort: field to sort by (cn, group_type, member_count; default cn)
    - order: asc or desc (default asc)
    """
    ldap_groups = list_groups()
    pg_profiles = ORGDB.list_group_profiles()
    pg_by_cn = {p["cn"]: p for p in pg_profiles}

    enriched = []
    for g in ldap_groups:
        cn = g["cn"]
        profile = pg_by_cn.get(cn)
        member_count = len([m for m in g.get("members", []) if m != LDAP_BIND_DN])
        item = {
            "cn": cn,
            "dn": g["dn"],
            "description": g.get("description", ""),
            "group_type": profile["group_type"] if profile else "distribution",
            "member_count": member_count,
            "permissions": list(profile["permissions"]) if profile and profile.get("permissions") else [],
            "created_at": profile["created_at"].isoformat() if profile and profile.get("created_at") else None,
            "updated_at": profile["updated_at"].isoformat() if profile and profile.get("updated_at") else None,
        }
        enriched.append(item)

    # Apply type filter
    if group_type:
        gt_lower = group_type.lower()
        enriched = [g for g in enriched if g["group_type"].lower() == gt_lower]

    # Apply search filter
    if search:
        q = search.lower()
        enriched = [
            g for g in enriched
            if q in g["cn"].lower() or q in (g["description"] or "").lower()
        ]

    # Sort
    sort_key = sort if sort in ("cn", "group_type", "member_count", "description") else "cn"
    reverse = order.lower() == "desc"
    if sort_key == "member_count":
        enriched.sort(key=lambda g: g.get("member_count", 0), reverse=reverse)
    else:
        enriched.sort(key=lambda g: (g.get(sort_key) or "").lower(), reverse=reverse)

    total = len(enriched)

    # Paginate (only if limit provided — backward compatible)
    if limit is not None:
        limit = min(max(1, limit), 200)
        paginated = enriched[offset:offset + limit]
        return {
            "ok": True,
            "groups": paginated,
            "total": total,
            "hasMore": (offset + limit) < total,
        }

    return {"ok": True, "groups": enriched, "total": total, "hasMore": False}
```

**Step 4: Run tests — expected PASS**

Run: `just test-quick -- tests/test_org_groups.py::TestGroupListPagination -v`

**Step 5: Run full group test suite for regression**

Run: `just test-quick -- tests/test_org_groups.py -v`

**Step 6: Commit**

```bash
git add src/backend/main.py tests/test_org_groups.py
git commit -m "feat(api): add pagination, sorting, search to GET /api/groups"
```

---

## Task 4: Install TanStack Table

**Files:**
- Modify: `src/frontend/packages/azblink-ui/package.json`

**Step 1: Install @tanstack/react-table in the @azblink/ui package**

```bash
cd src/frontend/packages/azblink-ui && npm install @tanstack/react-table
```

**Step 2: Verify installation**

```bash
cd src/frontend && npx tsc --noEmit
```
Expected: No new errors

**Step 3: Commit**

```bash
git add src/frontend/packages/azblink-ui/package.json src/frontend/package-lock.json
git commit -m "chore(deps): add @tanstack/react-table to @azblink/ui"
```

---

## Task 5: Create Pagination Primitive

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/Pagination/Pagination.tsx`
- Create: `src/frontend/packages/azblink-ui/primitives/Pagination/Pagination.module.css`
- Create: `src/frontend/packages/azblink-ui/primitives/Pagination/index.ts`
- Modify: `src/frontend/packages/azblink-ui/index.ts`

**Context:** Standalone pagination controls with two modes: full (for DataTable — page numbers, showing X of Y) and compact (for split-panel lists — prev/next only). Uses design tokens. Accessible with `<nav aria-label="Pagination">`.

**Step 1: Create Pagination.module.css**

Create `src/frontend/packages/azblink-ui/primitives/Pagination/Pagination.module.css`:

```css
/**
 * Pagination controls — compact and full modes.
 * Token-driven styling matching Table primitive conventions.
 */

.pagination {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-4);
  padding: var(--space-3) var(--space-4);
  font-size: var(--text-sm);
  color: var(--color-text-muted);
  border-top: 1px solid var(--color-border-subtle);
}

.pagination.compact {
  justify-content: center;
  gap: var(--space-3);
  padding: var(--space-2) var(--space-3);
}

.pageInfo {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  white-space: nowrap;
}

.controls {
  display: flex;
  align-items: center;
  gap: var(--space-1);
}

.pageButton {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 2rem;
  height: 2rem;
  padding: 0 var(--space-2);
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-md);
  background: transparent;
  color: var(--color-text-primary);
  font-size: var(--text-sm);
  cursor: pointer;
  transition: all var(--transition-fast);
}

.pageButton:hover:not(:disabled) {
  background: var(--color-bg-hover);
  border-color: var(--color-border-default);
}

.pageButton:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.pageButton.active {
  background: var(--color-primary);
  color: var(--color-on-primary);
  border-color: var(--color-primary);
}

.pageSizeSelect {
  height: 2rem;
  padding: 0 var(--space-6) 0 var(--space-2);
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-md);
  background: transparent;
  color: var(--color-text-primary);
  font-size: var(--text-sm);
  cursor: pointer;
  appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236b7280' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right var(--space-2) center;
}

.pageSizeSelect:hover {
  border-color: var(--color-border-default);
}
```

**Step 2: Create Pagination.tsx**

Create `src/frontend/packages/azblink-ui/primitives/Pagination/Pagination.tsx`:

```tsx
/**
 * Standalone pagination controls — usable by DataTable or split-panel lists.
 * - Full mode: page numbers, "Showing X–Y of Z", page size selector
 * - Compact mode: prev/next buttons, "Page N of M", page size selector
 * - Accessible: <nav aria-label="Pagination">, aria-current on active page
 */
import { useMemo } from 'react';
import { cn } from '../../utils/cn';
import styles from './Pagination.module.css';

export interface PaginationProps {
  /** Current page index (0-based) */
  pageIndex: number;
  /** Items per page */
  pageSize: number;
  /** Total item count (from server or client) */
  totalCount: number;
  /** Available page size options */
  pageSizes?: number[];
  /** Callbacks */
  onPageChange: (pageIndex: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  /** Compact mode for narrow panels (hides page numbers, shows Page X of Y) */
  compact?: boolean;
  className?: string;
}

const DEFAULT_PAGE_SIZES = [10, 25, 50, 100];

export function Pagination({
  pageIndex,
  pageSize,
  totalCount,
  pageSizes = DEFAULT_PAGE_SIZES,
  onPageChange,
  onPageSizeChange,
  compact = false,
  className,
}: PaginationProps) {
  const pageCount = Math.max(1, Math.ceil(totalCount / pageSize));
  const canPrev = pageIndex > 0;
  const canNext = pageIndex < pageCount - 1;
  const startItem = totalCount === 0 ? 0 : pageIndex * pageSize + 1;
  const endItem = Math.min((pageIndex + 1) * pageSize, totalCount);

  /** Generate visible page numbers with ellipsis */
  const pageNumbers = useMemo(() => {
    if (compact || pageCount <= 7) {
      return Array.from({ length: pageCount }, (_, i) => i);
    }
    const pages: (number | 'ellipsis')[] = [];
    pages.push(0);
    if (pageIndex > 2) pages.push('ellipsis');
    for (let i = Math.max(1, pageIndex - 1); i <= Math.min(pageCount - 2, pageIndex + 1); i++) {
      pages.push(i);
    }
    if (pageIndex < pageCount - 3) pages.push('ellipsis');
    if (pageCount > 1) pages.push(pageCount - 1);
    return pages;
  }, [pageIndex, pageCount, compact]);

  if (totalCount === 0) return null;

  return (
    <nav
      aria-label="Pagination"
      className={cn(styles.pagination, compact && styles.compact, className)}
    >
      {/* Info text */}
      {!compact && (
        <span className={styles.pageInfo}>
          Showing {startItem}–{endItem} of {totalCount}
        </span>
      )}

      {compact && (
        <span className={styles.pageInfo}>
          Page {pageIndex + 1} of {pageCount}
        </span>
      )}

      {/* Page controls */}
      <div className={styles.controls}>
        {!compact && (
          <button
            className={styles.pageButton}
            onClick={() => onPageChange(0)}
            disabled={!canPrev}
            aria-label="First page"
          >
            ««
          </button>
        )}
        <button
          className={styles.pageButton}
          onClick={() => onPageChange(pageIndex - 1)}
          disabled={!canPrev}
          aria-label="Previous page"
        >
          ‹
        </button>

        {!compact && pageNumbers.map((page, i) =>
          page === 'ellipsis' ? (
            <span key={`ellipsis-${i}`} className={styles.pageInfo}>…</span>
          ) : (
            <button
              key={page}
              className={cn(styles.pageButton, page === pageIndex && styles.active)}
              onClick={() => onPageChange(page)}
              aria-current={page === pageIndex ? 'page' : undefined}
              aria-label={`Page ${page + 1}`}
            >
              {page + 1}
            </button>
          )
        )}

        <button
          className={styles.pageButton}
          onClick={() => onPageChange(pageIndex + 1)}
          disabled={!canNext}
          aria-label="Next page"
        >
          ›
        </button>
        {!compact && (
          <button
            className={styles.pageButton}
            onClick={() => onPageChange(pageCount - 1)}
            disabled={!canNext}
            aria-label="Last page"
          >
            »»
          </button>
        )}
      </div>

      {/* Page size selector */}
      <select
        className={styles.pageSizeSelect}
        value={pageSize}
        onChange={(e) => {
          onPageSizeChange(Number(e.target.value));
          onPageChange(0); // reset to first page
        }}
        aria-label="Items per page"
      >
        {pageSizes.map((size) => (
          <option key={size} value={size}>
            {size} / page
          </option>
        ))}
      </select>
    </nav>
  );
}
```

**Step 3: Create index.ts**

Create `src/frontend/packages/azblink-ui/primitives/Pagination/index.ts`:

```typescript
export { Pagination } from './Pagination';
export type { PaginationProps } from './Pagination';
```

**Step 4: Export from package index**

Add to `src/frontend/packages/azblink-ui/index.ts` (after Table exports, around line 44):

```typescript
export { Pagination } from './primitives/Pagination';
export type { PaginationProps } from './primitives/Pagination';
```

**Step 5: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No new errors

**Step 6: Commit**

```bash
git add src/frontend/packages/azblink-ui/primitives/Pagination/ src/frontend/packages/azblink-ui/index.ts
git commit -m "feat(ui): add Pagination primitive with compact and full modes"
```

---

## Task 6: Create DataTable Component

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/DataTable/DataTable.tsx`
- Create: `src/frontend/packages/azblink-ui/primitives/DataTable/DataTableColumnHeader.tsx`
- Create: `src/frontend/packages/azblink-ui/primitives/DataTable/DataTable.module.css`
- Create: `src/frontend/packages/azblink-ui/primitives/DataTable/index.ts`
- Modify: `src/frontend/packages/azblink-ui/index.ts`

**Context:** Wraps TanStack Table with all features opt-in via props. Renders through existing Table/TableHeader/TableBody/TableRow/TableHead/TableCell primitives. Uses Pagination from Task 5.

**Step 1: Create DataTable.module.css**

Create `src/frontend/packages/azblink-ui/primitives/DataTable/DataTable.module.css`:

```css
/**
 * DataTable styles — minimal, delegates to Table primitives.
 */

.wrapper {
  display: flex;
  flex-direction: column;
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-lg);
  overflow: hidden;
}

.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  border-bottom: 1px solid var(--color-border-subtle);
}

.tableContainer {
  flex: 1;
  overflow: auto;
}

.stickyHeader thead {
  position: sticky;
  top: 0;
  z-index: 1;
  background: var(--color-bg-primary);
}

.sortHeader {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  cursor: pointer;
  user-select: none;
}

.sortHeader:hover {
  color: var(--color-text-primary);
}

.sortIcon {
  width: 0.875rem;
  height: 0.875rem;
  opacity: 0.4;
}

.sortIcon.active {
  opacity: 1;
  color: var(--color-primary);
}

.emptyState {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 12rem;
  color: var(--color-text-muted);
  font-size: var(--text-sm);
}

.checkboxCell {
  width: 2.5rem;
  text-align: center;
}
```

**Step 2: Create DataTableColumnHeader.tsx**

Create `src/frontend/packages/azblink-ui/primitives/DataTable/DataTableColumnHeader.tsx`:

```tsx
/**
 * Sortable column header for DataTable.
 * - Renders sort arrows (▲/▼) based on current sort state
 * - Clickable to toggle sort direction
 * - Non-sortable columns render as plain text
 */
import type { Column } from '@tanstack/react-table';
import { cn } from '../../utils/cn';
import styles from './DataTable.module.css';

interface DataTableColumnHeaderProps<TData, TValue> {
  column: Column<TData, TValue>;
  title: string;
  className?: string;
}

export function DataTableColumnHeader<TData, TValue>({
  column,
  title,
  className,
}: DataTableColumnHeaderProps<TData, TValue>) {
  if (!column.getCanSort()) {
    return <span className={className}>{title}</span>;
  }

  const sorted = column.getIsSorted();

  return (
    <button
      className={cn(styles.sortHeader, className)}
      onClick={() => column.toggleSorting(sorted === 'asc')}
      aria-label={`Sort by ${title}`}
    >
      {title}
      <span className={cn(styles.sortIcon, sorted && styles.active)}>
        {sorted === 'asc' ? '▲' : sorted === 'desc' ? '▼' : '⇅'}
      </span>
    </button>
  );
}
```

**Step 3: Create DataTable.tsx**

Create `src/frontend/packages/azblink-ui/primitives/DataTable/DataTable.tsx`:

```tsx
/**
 * Reusable data table powered by TanStack Table.
 * - Renders through existing Table/TableRow/TableHead/TableCell primitives
 * - All features opt-in via props: pagination, sorting, column visibility, row selection
 * - Supports both client-side and server-side (manual) modes
 */
import {
  useReactTable,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  flexRender,
  type ColumnDef,
  type PaginationState,
  type SortingState,
  type VisibilityState,
  type RowSelectionState,
  type OnChangeFn,
  type Row,
} from '@tanstack/react-table';
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from '../Table';
import { Pagination } from '../Pagination';
import { Skeleton } from '../Skeleton';
import { cn } from '../../utils/cn';
import styles from './DataTable.module.css';

export interface DataTableProps<TData> {
  /** TanStack Table column definitions */
  columns: ColumnDef<TData, unknown>[];
  /** Data array (current page if server-side) */
  data: TData[];

  /** ---- Pagination (opt-in) ---- */
  pagination?: PaginationState;
  onPaginationChange?: OnChangeFn<PaginationState>;
  /** Total row count for server-side pagination */
  rowCount?: number;
  /** Server-driven pagination (disables client-side slicing) */
  manualPagination?: boolean;
  pageSizes?: number[];

  /** ---- Sorting (opt-in) ---- */
  sorting?: SortingState;
  onSortingChange?: OnChangeFn<SortingState>;
  manualSorting?: boolean;

  /** ---- Column visibility (opt-in) ---- */
  columnVisibility?: VisibilityState;
  onColumnVisibilityChange?: OnChangeFn<VisibilityState>;

  /** ---- Row selection (opt-in) ---- */
  rowSelection?: RowSelectionState;
  onRowSelectionChange?: OnChangeFn<RowSelectionState>;
  enableRowSelection?: boolean | ((row: Row<TData>) => boolean);

  /** ---- Layout ---- */
  stickyHeader?: boolean;
  toolbar?: React.ReactNode;
  emptyState?: React.ReactNode;
  isLoading?: boolean;
  className?: string;
}

export function DataTable<TData>({
  columns,
  data,
  pagination,
  onPaginationChange,
  rowCount,
  manualPagination = false,
  pageSizes,
  sorting,
  onSortingChange,
  manualSorting = false,
  columnVisibility,
  onColumnVisibilityChange,
  rowSelection,
  onRowSelectionChange,
  enableRowSelection,
  stickyHeader = false,
  toolbar,
  emptyState,
  isLoading = false,
  className,
}: DataTableProps<TData>) {
  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    // Pagination
    ...(pagination && !manualPagination ? { getPaginationRowModel: getPaginationRowModel() } : {}),
    ...(pagination ? { onPaginationChange, state: { pagination } } : {}),
    ...(manualPagination ? { manualPagination: true, rowCount } : {}),
    // Sorting
    ...(sorting !== undefined ? { getSortedRowModel: !manualSorting ? getSortedRowModel() : undefined } : {}),
    ...(sorting !== undefined ? { onSortingChange, state: { ...table?.getState?.(), sorting } } : {}),
    ...(manualSorting ? { manualSorting: true } : {}),
    // Column visibility
    ...(columnVisibility !== undefined ? { onColumnVisibilityChange, state: { columnVisibility } } : {}),
    // Row selection
    ...(enableRowSelection ? { enableRowSelection, onRowSelectionChange } : {}),
    ...(rowSelection !== undefined ? { state: { rowSelection } } : {}),
    // Merge all state
    state: {
      ...(pagination ? { pagination } : {}),
      ...(sorting !== undefined ? { sorting } : {}),
      ...(columnVisibility !== undefined ? { columnVisibility } : {}),
      ...(rowSelection !== undefined ? { rowSelection } : {}),
    },
  });

  const totalCount = manualPagination ? (rowCount ?? 0) : table.getFilteredRowModel().rows.length;

  return (
    <div className={cn(styles.wrapper, className)}>
      {toolbar && <div className={styles.toolbar}>{toolbar}</div>}

      <div className={cn(styles.tableContainer, stickyHeader && styles.stickyHeader)}>
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <TableHead key={header.id} style={{ width: header.getSize() !== 150 ? header.getSize() : undefined }}>
                    {header.isPlaceholder
                      ? null
                      : flexRender(header.column.columnDef.header, header.getContext())}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: pagination?.pageSize ?? 5 }).map((_, i) => (
                <TableRow key={`skeleton-${i}`}>
                  {columns.map((_, j) => (
                    <TableCell key={j}>
                      <Skeleton className="h-4 w-full" />
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : table.getRowModel().rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length}>
                  <div className={styles.emptyState}>
                    {emptyState ?? 'No results.'}
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() ? 'selected' : undefined}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {pagination && (
        <Pagination
          pageIndex={pagination.pageIndex}
          pageSize={pagination.pageSize}
          totalCount={totalCount}
          pageSizes={pageSizes}
          onPageChange={(page) =>
            onPaginationChange?.({ ...pagination, pageIndex: page })
          }
          onPageSizeChange={(size) =>
            onPaginationChange?.({ pageIndex: 0, pageSize: size })
          }
        />
      )}
    </div>
  );
}
```

> **Note to implementer:** The `state` merging above is a simplified version. TanStack Table's `useReactTable` accepts a single `state` object. Build it cleanly by constructing the state object before passing it. See the TanStack Table docs on controlled state: the pattern is to build a single `state` prop that merges all controlled states.

**Step 4: Create index.ts**

Create `src/frontend/packages/azblink-ui/primitives/DataTable/index.ts`:

```typescript
export { DataTable } from './DataTable';
export type { DataTableProps } from './DataTable';
export { DataTableColumnHeader } from './DataTableColumnHeader';
```

**Step 5: Export from package index**

Add to `src/frontend/packages/azblink-ui/index.ts` (after Pagination exports):

```typescript
export { DataTable, DataTableColumnHeader } from './primitives/DataTable';
export type { DataTableProps } from './primitives/DataTable';
```

**Step 6: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No new errors (fix any type issues the implementer finds)

**Step 7: Commit**

```bash
git add src/frontend/packages/azblink-ui/primitives/DataTable/ src/frontend/packages/azblink-ui/index.ts
git commit -m "feat(ui): add DataTable component wrapping TanStack Table with all features opt-in"
```

---

## Task 7: Update Frontend Query Hooks

**Files:**
- Modify: `src/frontend/src/lib/queries/keys.ts`
- Modify: `src/frontend/src/lib/queries/users.ts`
- Modify: `src/frontend/src/lib/queries/groups.ts`

**Step 1: Update query keys to include pagination params**

In `src/frontend/src/lib/queries/keys.ts`, change the `users` and `groups` keys:

```typescript
// Replace:
users: ['users'] as const,
// With:
users: ['users'] as const,
usersList: (params: Record<string, unknown>) => ['users', 'list', params] as const,

// Replace:
groups: ['groups'] as const,
// With:
groups: ['groups'] as const,
groupsList: (params: Record<string, unknown>) => ['groups', 'list', params] as const,
```

**Step 2: Add paginated query to users.ts**

Add to `src/frontend/src/lib/queries/users.ts`:

```typescript
import type { PaginatedUsersResponse, PaginationParams } from '@/types';

export interface UserQueryParams extends PaginationParams {
  status?: string;
}

/** Paginated user list — params drive server-side filtering/sorting/pagination */
export const paginatedUsersQueryOptions = (params: UserQueryParams = {}) =>
  queryOptions({
    queryKey: queryKeys.usersList(params),
    queryFn: () =>
      getApi().get<PaginatedUsersResponse>('/users', {
        limit: params.limit,
        offset: params.offset,
        search: params.search,
        status: params.status,
        sort: params.sort,
        order: params.order,
      }),
    staleTime: 30_000,
  });
```

> **Note:** The existing `usersQueryOptions()` (line 10-15) stays as-is for backward compatibility. Components migrate to `paginatedUsersQueryOptions` when they're ready.

**Step 3: Add paginated query to groups.ts**

Add to `src/frontend/src/lib/queries/groups.ts`:

```typescript
import type { PaginatedGroupsResponse, PaginationParams } from '@/types';

export interface GroupQueryParams extends PaginationParams {
  type?: string;
}

/** Paginated group list — params drive server-side filtering/sorting/pagination */
export const paginatedGroupsQueryOptions = (params: GroupQueryParams = {}) =>
  queryOptions({
    queryKey: queryKeys.groupsList(params),
    queryFn: () =>
      getApi().get<PaginatedGroupsResponse>('/groups', {
        limit: params.limit,
        offset: params.offset,
        search: params.search,
        type: params.type,
        sort: params.sort,
        order: params.order,
      }),
    staleTime: 30_000,
  });
```

**Step 4: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit`

**Step 5: Commit**

```bash
git add src/frontend/src/lib/queries/keys.ts src/frontend/src/lib/queries/users.ts src/frontend/src/lib/queries/groups.ts
git commit -m "feat(queries): add paginatedUsersQueryOptions and paginatedGroupsQueryOptions"
```

---

## Task 8: Wire Server-Side Pagination to User Management

**Files:**
- Modify: `src/frontend/src/components/features/user-management/UserManagementPage.tsx`
- Modify: `src/frontend/src/components/features/user-management/UserList.tsx`
- Modify: `src/frontend/src/routes/directory/users/index.tsx` (route search params)

**Context:** Currently UserManagementPage loads ALL users via `usersQueryOptions()`, then `filterUsers()` does client-side filtering. We're switching to server-side: the page passes `search/filter/page/pageSize` as URL search params, the query hook sends them to the backend, and `<Pagination compact>` goes at the bottom of UserList.

**Step 1: Update route search params**

In `src/frontend/src/routes/directory/users/index.tsx`, add `page` and `pageSize` to the search params validation. Check the existing validateSearch and add the new params. The route should accept: `userId`, `filter`, `search`, `page`, `pageSize`.

**Step 2: Update UserManagementSearchParams type**

In `UserManagementPage.tsx`, update the interface:

```typescript
export interface UserManagementSearchParams {
  userId?: string;
  filter?: UserFilter;
  search?: string;
  page?: number;
  pageSize?: number;
}
```

**Step 3: Replace client-side filtering with server-side query**

In `UserManagementPage.tsx`:
1. Remove the `filterUsers()` function (lines 38-60)
2. Replace `UserListPanel` to use `paginatedUsersQueryOptions` instead of `usersQueryOptions` + `useMemo`
3. Pass `page`, `pageSize`, `totalCount` to `UserList`

```typescript
function UserListPanel({
  selectedUserId,
  filter,
  search,
  page,
  pageSize,
  onSelectUser,
  onFilterChange,
  onPageChange,
  onPageSizeChange,
}: {
  selectedUserId: string | undefined;
  filter: UserFilter;
  search: string;
  page: number;
  pageSize: number;
  onSelectUser: (uid: string) => void;
  onFilterChange: (f: UserFilter) => void;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
}) {
  const { data } = useSuspenseQuery(
    paginatedUsersQueryOptions({
      limit: pageSize,
      offset: page * pageSize,
      search: search || undefined,
      status: filter !== 'all' ? filter : undefined,
      sort: 'displayName',
      order: 'asc',
    })
  );

  return (
    <UserList
      users={data.users}
      totalCount={data.total}
      selectedUserId={selectedUserId}
      filter={filter}
      onFilterChange={onFilterChange}
      onSelectUser={onSelectUser}
      page={page}
      pageSize={pageSize}
      onPageChange={onPageChange}
      onPageSizeChange={onPageSizeChange}
    />
  );
}
```

**Step 4: Add Pagination to UserList**

In `UserList.tsx`, add the Pagination component at the bottom (inside the outer flex-col div, after the scrollable list):

```tsx
import { Pagination } from '@azblink/ui';

// Add to props:
interface UserListProps {
  users: User[];
  totalCount: number;  // NEW
  selectedUserId: string | undefined;
  filter: UserFilter;
  onFilterChange: (filter: UserFilter) => void;
  onSelectUser: (uid: string) => void;
  page: number;         // NEW
  pageSize: number;     // NEW
  onPageChange: (page: number) => void;      // NEW
  onPageSizeChange: (pageSize: number) => void;  // NEW
}

// Add inside the component, after the scrollable list div:
<Pagination
  compact
  pageIndex={page}
  pageSize={pageSize}
  totalCount={totalCount}
  pageSizes={[10, 25, 50]}
  onPageChange={onPageChange}
  onPageSizeChange={onPageSizeChange}
/>
```

**Step 5: Wire pagination callbacks in UserManagementPage**

Add `page` and `pageSize` handling:

```typescript
const page = searchParams.page ?? 0;
const pageSize = searchParams.pageSize ?? 25;

const handlePageChange = useCallback(
  (p: number) => updateSearchParams({ page: p }),
  [updateSearchParams],
);

const handlePageSizeChange = useCallback(
  (ps: number) => updateSearchParams({ pageSize: ps, page: 0 }),
  [updateSearchParams],
);
```

**Step 6: Verify TypeScript compiles + test in browser**

Run: `cd src/frontend && npx tsc --noEmit`
Then manually test: `just browse` and navigate to the users page.

**Step 7: Commit**

```bash
git add src/frontend/src/components/features/user-management/ src/frontend/src/routes/directory/users/
git commit -m "feat(users): wire server-side pagination to user management split-panel"
```

---

## Task 9: Wire Server-Side Pagination to Group Management

**Files:**
- Modify: `src/frontend/src/components/features/group-management/GroupManagementPage.tsx`
- Modify: `src/frontend/src/components/features/group-management/GroupList.tsx`
- Modify: `src/frontend/src/routes/directory/groups/index.tsx`

**Context:** Same pattern as Task 8. Replace client-side `filterGroups()` with `paginatedGroupsQueryOptions()`, add `page/pageSize` to URL search params, add `<Pagination compact>` to GroupList.

**Step 1: Update GroupManagementSearchParams**

```typescript
export interface GroupManagementSearchParams {
  groupId?: string;
  filter?: GroupFilter;
  search?: string;
  page?: number;
  pageSize?: number;
}
```

**Step 2: Replace GroupListPanel with paginated query**

Same pattern as UserListPanel in Task 8:
- Remove `filterGroups()` function
- Use `paginatedGroupsQueryOptions()` with `type` param for filter

**Step 3: Add Pagination to GroupList**

Same pattern as UserList — add `<Pagination compact>` at the bottom.

**Step 4: Wire callbacks**

Same pattern as Task 8.

**Step 5: Verify TypeScript + browser test**

**Step 6: Commit**

```bash
git add src/frontend/src/components/features/group-management/ src/frontend/src/routes/directory/groups/
git commit -m "feat(groups): wire server-side pagination to group management split-panel"
```

---

## Task 10: Refactor Tokens Page to DataTable

**Files:**
- Modify: `src/frontend/src/routes/provisioning/tokens.tsx`

**Context:** Replace the hand-written Table + map with a `<DataTable>` using TanStack Table column definitions. Add client-side sorting + pagination (the audit endpoint doesn't need server-side pagination yet — dataset is bounded).

**Step 1: Define column definitions**

```tsx
import { DataTable, DataTableColumnHeader, Badge } from '@azblink/ui';
import type { ColumnDef } from '@tanstack/react-table';

const columns: ColumnDef<QRIssuanceAuditRecord, unknown>[] = [
  {
    accessorKey: 'token_hash',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Token" />,
    cell: ({ getValue }) => (
      <span className="font-mono text-sm">
        {String(getValue()).slice(0, 8)}...
      </span>
    ),
    enableSorting: false,
  },
  {
    accessorKey: 'user_uid',
    header: ({ column }) => <DataTableColumnHeader column={column} title="User" />,
  },
  {
    accessorKey: 'issued_at',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Issued" />,
    cell: ({ getValue }) => (
      <span className="text-muted-foreground">{formatDate(String(getValue()))}</span>
    ),
  },
  {
    accessorKey: 'expires_at',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Expires" />,
    cell: ({ getValue }) => (
      <span className="text-muted-foreground">{formatDate(String(getValue()))}</span>
    ),
  },
  {
    id: 'status',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Status" />,
    accessorFn: (row) => getStatus(row),
    cell: ({ getValue }) => getStatusBadge(String(getValue())),
  },
  {
    id: 'actions',
    header: '',
    cell: ({ row }) => {
      const status = getStatus(row.original);
      return status === 'active' ? (
        <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
          Revoke
        </Button>
      ) : (
        <span className="text-icon-muted text-sm">—</span>
      );
    },
    enableSorting: false,
  },
];
```

**Step 2: Replace TokensTable with DataTable**

```tsx
function TokensTable({ records }: { records: QRIssuanceAuditRecord[] }) {
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 25 });
  const [sorting, setSorting] = useState<SortingState>([{ id: 'issued_at', desc: true }]);

  return (
    <DataTable
      columns={columns}
      data={records}
      pagination={pagination}
      onPaginationChange={setPagination}
      sorting={sorting}
      onSortingChange={setSorting}
      pageSizes={[10, 25, 50, 100]}
      stickyHeader
      emptyState={
        <EmptyState
          icon={<KeyRound className="h-8 w-8" />}
          title="No tokens issued yet"
          description="Tokens are created when you generate QR codes for users"
        />
      }
    />
  );
}
```

**Step 3: Remove the old TokensTableSkeleton**

DataTable has built-in loading skeletons via `isLoading` prop. Remove the manual skeleton.

**Step 4: Move helper functions (getStatus, getStatusBadge, formatDate) outside the component**

These are pure functions — define them at module level so column definitions can reference them.

**Step 5: Verify TypeScript + browser test**

Run: `cd src/frontend && npx tsc --noEmit`
Browse to `/provisioning/tokens` and verify:
- Table renders with data
- Column headers are clickable for sorting
- Pagination controls appear at the bottom
- Page size selector works

**Step 6: Commit**

```bash
git add src/frontend/src/routes/provisioning/tokens.tsx
git commit -m "refactor(tokens): migrate provisioning tokens page to DataTable"
```

---

## Task 11: Update Docstrings and Cleanup

**Files:**
- Modify: Various files touched in Tasks 1-10

**Step 1: Update file-level docstrings**

Ensure all new/modified files have accurate file-level JSDoc:
- `Pagination.tsx` — ✓ (written in Task 5)
- `DataTable.tsx` — ✓ (written in Task 6)
- `UserManagementPage.tsx` — update docstring to mention server-side pagination
- `GroupManagementPage.tsx` — same
- `UserList.tsx` — update to mention Pagination component
- `GroupList.tsx` — same
- `tokens.tsx` — update to mention DataTable

**Step 2: Remove dead code**

- Delete `src/frontend/src/components/features/user-table.tsx` (confirmed unused in exploration)
- Remove client-side `filterUsers()` and `filterGroups()` functions if not already removed

**Step 3: Verify TypeScript compiles one final time**

Run: `cd src/frontend && npx tsc --noEmit`

**Step 4: Commit**

```bash
git add -A
git commit -m "docs: update docstrings for DataTable + pagination, remove dead code"
```

---

## Task 12: E2E Tests

**Files:**
- Create: `src/frontend/e2e/pagination.spec.ts`

**Context:** Playwright tests against the running dev stack. Test pagination controls on the user management page and DataTable on the tokens page.

**Step 1: Write E2E tests**

```typescript
/**
 * E2E tests for pagination controls and DataTable.
 * - User management: compact pagination in split-panel
 * - Tokens page: DataTable with sorting + pagination
 */
import { test, expect } from '@playwright/test';

const BASE = 'http://localhost:3000';

test.describe('User Management Pagination', () => {
  test.beforeEach(async ({ page }) => {
    // Login first (use seed user mei)
    await page.goto(`${BASE}/login`);
    await page.fill('input[name="username"]', 'mei');
    await page.fill('input[name="password"]', 'password123');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/directory/**');
  });

  test('shows pagination controls at bottom of user list', async ({ page }) => {
    await page.goto(`${BASE}/directory/users`);
    const nav = page.locator('nav[aria-label="Pagination"]');
    await expect(nav).toBeVisible();
  });

  test('page size selector changes results', async ({ page }) => {
    await page.goto(`${BASE}/directory/users?pageSize=10`);
    const nav = page.locator('nav[aria-label="Pagination"]');
    await expect(nav).toBeVisible();
    // Change page size
    const select = nav.locator('select[aria-label="Items per page"]');
    await select.selectOption('25');
    // URL should update
    await expect(page).toHaveURL(/pageSize=25/);
  });

  test('next/prev buttons navigate pages', async ({ page }) => {
    await page.goto(`${BASE}/directory/users?pageSize=1`);
    const nextBtn = page.locator('button[aria-label="Next page"]');
    if (await nextBtn.isEnabled()) {
      await nextBtn.click();
      await expect(page).toHaveURL(/page=1/);
    }
  });
});

test.describe('Tokens DataTable', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${BASE}/login`);
    await page.fill('input[name="username"]', 'mei');
    await page.fill('input[name="password"]', 'password123');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/directory/**');
  });

  test('renders DataTable with sortable headers', async ({ page }) => {
    await page.goto(`${BASE}/provisioning/tokens`);
    // Table should render
    const table = page.locator('[data-slot="table"]');
    await expect(table).toBeVisible();
    // Sort headers should have buttons
    const sortButtons = page.locator('button[aria-label^="Sort by"]');
    const count = await sortButtons.count();
    expect(count).toBeGreaterThan(0);
  });
});
```

**Step 2: Run E2E tests**

Run: `cd src/frontend && npx playwright test e2e/pagination.spec.ts`
Expected: PASS (requires running dev stack — `just up-bg`)

**Step 3: Commit**

```bash
git add src/frontend/e2e/pagination.spec.ts
git commit -m "test(e2e): add Playwright tests for pagination and DataTable"
```

---

## Summary

| Task | What | Backend | Frontend | Tests |
|------|------|---------|----------|-------|
| 1 | PaginatedResponse types | | ✓ | |
| 2 | GET /api/users pagination | ✓ | | ✓ |
| 3 | GET /api/groups pagination | ✓ | | ✓ |
| 4 | Install TanStack Table | | ✓ | |
| 5 | Pagination primitive | | ✓ | |
| 6 | DataTable component | | ✓ | |
| 7 | Query hooks update | | ✓ | |
| 8 | User mgmt pagination | | ✓ | |
| 9 | Group mgmt pagination | | ✓ | |
| 10 | Tokens → DataTable | | ✓ | |
| 11 | Docstrings + cleanup | | ✓ | |
| 12 | E2E tests | | | ✓ |
