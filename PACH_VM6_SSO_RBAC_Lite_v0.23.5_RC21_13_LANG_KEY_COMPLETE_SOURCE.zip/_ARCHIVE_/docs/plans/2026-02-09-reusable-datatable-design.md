# Reusable DataTable + Server-Side Pagination — Design Document

## Goal

Build a full-stack reusable DataTable system: TanStack Table-powered `<DataTable>` component + standalone `<Pagination>` controls in `@azblink/ui`, backed by server-side pagination on `GET /api/users` and `GET /api/groups`.

## Architecture Overview

```
┌─ @azblink/ui ──────────────────────────────────────────────┐
│                                                             │
│  <Pagination>  ← standalone, used by DataTable + lists      │
│  <DataTable>   ← TanStack Table wrapper, renders via        │
│                   existing Table/TableRow/TableHead/etc.     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
         ▲                        ▲
         │                        │
  Split-panel lists         Full-width views
  (UserList, GroupList)     (tokens, audit, user table view)
  keep current row style    real tabular DataTable layout
```

Two composable pieces:
- **`<Pagination>`** — Standalone control bar (prev/next, page numbers, page size selector, "Showing X of Y"). Usable by DataTable internally OR by split-panel lists independently.
- **`<DataTable>`** — Full TanStack Table wrapper. Renders through existing `Table` primitives. All features opt-in via props.

## Component API

### `<Pagination>`

```tsx
interface PaginationProps {
  /** Current page index (0-based) */
  pageIndex: number;
  /** Items per page */
  pageSize: number;
  /** Total item count (from server) */
  totalCount: number;
  /** Available page size options — configurable per instance */
  pageSizes?: number[];
  /** Callbacks */
  onPageChange: (pageIndex: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  /** Optional: compact mode for narrow panels */
  compact?: boolean;
  className?: string;
}
```

**Renders:**
```
Compact (split-panel):   [< Prev] Page 1 of 5 [Next >]  |  10 per page
Full (DataTable):        [<<] [<] 1 2 3 ... 12 [>] [>>]  |  Showing 1–25 of 293  |  25 ▾ per page
```

### `<DataTable>`

```tsx
interface DataTableProps<TData> {
  /** TanStack Table column definitions */
  columns: ColumnDef<TData, unknown>[];
  /** Data array (current page if server-side) */
  data: TData[];

  /** ---- Pagination (opt-in) ---- */
  /** Enable pagination controls. Provide state for controlled mode. */
  pagination?: PaginationState;
  onPaginationChange?: OnChangeFn<PaginationState>;
  /** Total row count for server-side pagination */
  rowCount?: number;
  /** Whether pagination is server-driven (disables client-side slicing) */
  manualPagination?: boolean;
  /** Page size options for this instance */
  pageSizes?: number[];

  /** ---- Sorting (opt-in) ---- */
  sorting?: SortingState;
  onSortingChange?: OnChangeFn<SortingState>;
  /** Whether sorting is server-driven */
  manualSorting?: boolean;

  /** ---- Column visibility (opt-in) ---- */
  columnVisibility?: VisibilityState;
  onColumnVisibilityChange?: OnChangeFn<VisibilityState>;
  /** Show column visibility toggle button */
  enableColumnVisibility?: boolean;

  /** ---- Row selection (opt-in) ---- */
  rowSelection?: RowSelectionState;
  onRowSelectionChange?: OnChangeFn<RowSelectionState>;
  enableRowSelection?: boolean | ((row: Row<TData>) => boolean);

  /** ---- Layout ---- */
  /** Make header sticky (scrollable body) */
  stickyHeader?: boolean;
  /** Optional toolbar slot (search, filters, bulk actions) */
  toolbar?: React.ReactNode;
  /** Empty state when data is empty */
  emptyState?: React.ReactNode;
  /** Loading state */
  isLoading?: boolean;

  className?: string;
}
```

**Rendering:** DataTable renders through the existing `Table`, `TableHeader`, `TableBody`, `TableRow`, `TableHead`, `TableCell` primitives — no duplicate styling.

### Column Definition Pattern (TanStack Table standard)

```tsx
const columns: ColumnDef<User>[] = [
  // Checkbox column (opt-in via enableRowSelection)
  { id: 'select', header: SelectAllCheckbox, cell: SelectRowCheckbox },

  // Data columns
  {
    accessorKey: 'displayName',
    header: 'User',
    cell: ({ row }) => <UserCell user={row.original} />, // avatar + name + email
  },
  {
    accessorKey: 'accountStatus',
    header: 'Status',
    cell: ({ getValue }) => <StatusBadge status={getValue()} />,
  },
  {
    accessorKey: 'orgName',
    header: 'Organization',
  },
  {
    id: 'actions',
    header: '',
    cell: ({ row }) => <RowActions user={row.original} />,
    enableSorting: false,
  },
];
```

## Backend Changes

### `GET /api/users` — Add pagination + server-side filtering

**New query parameters:**

| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `limit` | int | 50 | Items per page (max 200) |
| `offset` | int | 0 | Skip N items |
| `search` | str | "" | Case-insensitive search in uid, displayName, mail |
| `status` | str | "" | Filter by accountStatus: "active", "pending", or "" (all) |
| `sort` | str | "displayName" | Sort field |
| `order` | str | "asc" | Sort direction: "asc" or "desc" |

**New response shape:**

```json
{
  "ok": true,
  "users": [ ... ],
  "total": 293,
  "hasMore": true
}
```

**Backward compatibility:** When no `limit` param is provided, return all users (current behavior). This keeps existing client-side consumers working until migrated.

**Implementation:** In-memory pagination (Python list slicing) — all users are fetched from LDAP, then filtered/sorted/sliced in Python. LDAP paging controls are a future optimization for 1000+ user deployments.

### `GET /api/groups` — Same pattern

| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `limit` | int | 50 | Items per page (max 200) |
| `offset` | int | 0 | Skip N items |
| `search` | str | "" | Search in cn, description |
| `type` | str | "" | Filter by group_type |
| `sort` | str | "cn" | Sort field |
| `order` | str | "asc" | Sort direction |

**Response:** Same shape with `groups` array + `total` + `hasMore`.

## Frontend Data Flow

### Server-Side Pagination Flow (DataTable + Split-Panel Lists)

```
URL search params (?page=2&pageSize=25&search=mei&status=active&sort=displayName&order=asc)
    │
    ▼
TanStack Router route (validates + provides searchParams)
    │
    ▼
Management page (reads searchParams, constructs query options)
    │
    ▼
TanStack Query (queryKey includes all params → automatic refetch on change)
    │
    ▼
Backend (filters + sorts + paginates → returns page + total)
    │
    ▼
DataTable / List (receives current page data + totalCount)
    │
    ▼
Pagination controls (prev/next/page-size → updates URL search params → cycle)
```

### Query Hook Changes

```tsx
// Current (loads everything)
export const usersQueryOptions = () =>
  queryOptions({
    queryKey: queryKeys.users,
    queryFn: () => getApi().get<{ users: User[] }>('/users'),
  });

// New (server-side pagination)
export const usersQueryOptions = (params: UserQueryParams = {}) =>
  queryOptions({
    queryKey: [...queryKeys.users, params],
    queryFn: () => {
      const searchParams = new URLSearchParams();
      if (params.limit) searchParams.set('limit', String(params.limit));
      if (params.offset) searchParams.set('offset', String(params.offset));
      if (params.search) searchParams.set('search', params.search);
      if (params.status) searchParams.set('status', params.status);
      if (params.sort) searchParams.set('sort', params.sort);
      if (params.order) searchParams.set('order', params.order);
      return getApi().get<PaginatedResponse<User>>(
        `/users?${searchParams.toString()}`
      );
    },
    staleTime: 30_000,
  });
```

### Generic Pagination Types

```tsx
// src/frontend/src/types/api.ts
export interface PaginatedResponse<T> {
  ok: boolean;
  total: number;
  hasMore: boolean;
}

// Consumers extend with their own data key:
export interface PaginatedUsersResponse extends PaginatedResponse<User> {
  users: User[];
}
export interface PaginatedGroupsResponse extends PaginatedResponse<GroupListItem> {
  groups: GroupListItem[];
}
```

## File Layout

```
packages/azblink-ui/
  primitives/
    Pagination/
      Pagination.tsx          ← standalone pagination controls
      Pagination.module.css   ← token-driven styles
      index.ts
    DataTable/
      DataTable.tsx           ← TanStack Table wrapper
      DataTableColumnHeader.tsx  ← sortable header with icons
      DataTableToolbar.tsx    ← column visibility toggle, bulk actions slot
      DataTableSkeleton.tsx   ← loading state
      index.ts
    Table/                    ← existing (unchanged)
  index.ts                    ← add exports for Pagination, DataTable

src/frontend/src/
  types/
    api.ts                    ← add PaginatedResponse<T>
  lib/queries/
    users.ts                  ← update with pagination params
    groups.ts                 ← update with pagination params
  components/features/
    user-management/
      UserManagementPage.tsx  ← wire server-side pagination
      UserList.tsx            ← add Pagination to bottom
    group-management/
      GroupManagementPage.tsx ← wire server-side pagination
      GroupList.tsx           ← add Pagination to bottom
  routes/provisioning/
    tokens.tsx                ← refactor to use DataTable

src/backend/
  main.py                     ← add pagination params to endpoints
```

## Consumers

### 1. Provisioning Tokens (Refactor → DataTable)

Current: Hand-written `<Table>` with manual rendering.
After: `<DataTable columns={tokenColumns} data={tokens} pagination={...} sorting={...} />`.
This is the proving ground — existing tabular view migrated to DataTable.

### 2. User Management (Split-Panel List + New DataTable View)

**Left panel (list):** Keep current UserRow visual style. Add `<Pagination compact>` at the bottom. The `filterUsers()` client-side function is removed — server does filtering now.

**Future:** A full-width user directory DataTable view (separate route or toggle) could show more columns (email, org, QR status) with sorting and selection. Not in scope for v1 but the DataTable is ready for it.

### 3. Group Management (Split-Panel List)

Same pattern as users: keep GroupRow style, add `<Pagination compact>` at the bottom, move filtering to server.

## Design Constraints

- **`<DataTable>` must not duplicate styling** — renders through existing Table primitives
- **Pagination state lives in URL search params** — enables bookmarkable pages, browser back/forward
- **All features are opt-in** — a DataTable with just `columns` and `data` works as a plain table
- **Page sizes configurable per instance** — each consumer provides `pageSizes` prop
- **TanStack Table's controlled state pattern** — pagination/sorting/selection state hoisted to parent via `state` + `onChange` props
- **Server-side mode is the primary mode** — `manualPagination` and `manualSorting` default to `true` when pagination/sorting state is provided
- **Backward compatible backend** — endpoints without pagination params return all data

## Accessibility

- Pagination controls use `<nav aria-label="Pagination">`
- Page buttons have `aria-current="page"` for active page
- Sort direction communicated via `aria-sort` on `<th>`
- Row selection checkbox has `aria-label="Select row"` / `aria-label="Select all"`
- Keyboard: Enter/Space to toggle selection, Tab through pagination controls

## Not In Scope (Future)

- LDAP paging controls (SimplePagedResultsControl) — add when >1000 users
- Virtual scrolling (react-window) — add if page sizes >100 cause jank
- Column resizing — nice-to-have, not day-one
- Column reordering (drag-and-drop)
- Inline cell editing
- Export to CSV (add later as toolbar action)
- Infinite scroll mode (alternative to pagination)
