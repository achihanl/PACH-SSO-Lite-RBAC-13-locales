# E2E XMPP Provisioning Test — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Create an end-to-end test that provisions 2 XMPP users through the AD platform, authenticates them to a real XMPP server, exchanges messages, and verifies audit trail.
**Architecture:** Hybrid — AD API for orchestration/audit + direct ldap3 for XMPP LDAP provisioning + slixmpp for messaging
**Tech Stack:** pytest, pytest-asyncio, httpx, ldap3, slixmpp, psycopg2
**Domains:** backend, test

---

### Task 1: Add external LDAP fixture and pytest markers
**domain:** test
**depends_on:** []
**parallel_group:** 1

**Files:**
- Modify: `tests/conftest.py`
- Modify: `pytest.ini` (or `pyproject.toml` / `setup.cfg` — whichever has pytest config)

**Step 1: Check if pytest.ini exists**
```bash
ls tests/pytest.ini pyproject.toml setup.cfg pytest.ini 2>/dev/null
```

**Step 2: Add external_network marker to pytest config**
Add `external_network: tests requiring external network access to 192.168.122.89` to markers.

**Step 3: Add external_ldap_conn fixture to conftest.py**
After the existing `ldap_conn` fixture, add:
```python
@pytest.fixture(scope="session")
def external_ldap_conn():
    """LDAP connection to external XMPP server (192.168.122.89).

    - Used for direct XMPP user provisioning in e2e tests
    - Requires EXTERNAL_LDAP_ADMIN_PASSWORD env var
    - Skips tests if server unreachable
    """
    password = os.getenv("EXTERNAL_LDAP_ADMIN_PASSWORD")
    if not password:
        pytest.skip("EXTERNAL_LDAP_ADMIN_PASSWORD not set")
    host = os.getenv("EXTERNAL_LDAP_HOST", "192.168.122.89")
    port = int(os.getenv("EXTERNAL_LDAP_PORT", "389"))
    base_dn = os.getenv("EXTERNAL_LDAP_BASE_DN", "dc=xmpp-sip-platform,dc=local")
    bind_dn = os.getenv("EXTERNAL_LDAP_BIND_DN", f"cn=Manager,{base_dn}")
    try:
        server = Server(f"ldap://{host}:{port}", get_info=ALL)
        conn = Connection(server, user=bind_dn, password=password, auto_bind=True)
    except Exception as e:
        pytest.skip(f"External LDAP unreachable: {e}")
    yield conn
    conn.unbind()
```

**Step 4: Verify fixture loads**
```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack
EXTERNAL_LDAP_ADMIN_PASSWORD=test pytest tests/conftest.py --collect-only 2>&1 | head -20
```

---

### Task 2: Add slixmpp to test requirements
**domain:** test
**depends_on:** []
**parallel_group:** 1

**Files:**
- Modify: `tests/requirements.txt`

**Step 1: Check current test requirements**
```bash
cat tests/requirements.txt
```

**Step 2: Add slixmpp and pytest-asyncio**
Append `slixmpp` and `pytest-asyncio` (if not already present) to `tests/requirements.txt`.

**Step 3: Install**
```bash
pip install slixmpp pytest-asyncio
```

---

### Task 3: Create the e2e XMPP test file
**domain:** test
**depends_on:** [1, 2]
**parallel_group:** 2

**Files:**
- Create: `tests/test_xmpp_e2e.py`

**Step 1: Create the test file with all test functions**

The test file should contain:

```python
"""End-to-end XMPP provisioning and messaging test.

- Provisions 2 users into real XMPP LDAP (192.168.122.89)
- Registers users in AD Directory for QR/audit tracking
- Generates QR codes and consumes provision tokens
- Authenticates both users to real XMPP server (private.z domain)
- Exchanges messages between users
- Verifies AD platform audit trail (provision_tokens, qr_issuance_audit)

Network requirements:
  - 192.168.122.89:389 (LDAP — user provisioning)
  - 192.168.122.89:5222 (XMPP — authentication + messaging)

Environment variables:
  - EXTERNAL_LDAP_ADMIN_PASSWORD (required)
  - EXTERNAL_LDAP_HOST (default: 192.168.122.89)
"""

import asyncio
import hashlib
import os
import secrets
import ssl
import time
from typing import Optional

import pytest
import slixmpp
from conftest import LDAP_BASE_DN

# External XMPP server constants
XMPP_SERVER_HOST = os.getenv("EXTERNAL_LDAP_HOST", "192.168.122.89")
XMPP_SERVER_PORT = 5222
XMPP_DOMAIN = "private.z"
EXTERNAL_LDAP_BASE_DN = os.getenv("EXTERNAL_LDAP_BASE_DN", "dc=xmpp-sip-platform,dc=local")

# Test user prefix (unique per run to avoid collisions)
_RUN_ID = str(int(time.time()))[-6:]


def _ssha_hash(password: str) -> bytes:
    """Generate SSHA hash for LDAP userPassword (mirrors UED Sync logic)."""
    import hashlib as _hl
    salt = os.urandom(8)
    digest = _hl.sha1(password.encode("utf-8") + salt).digest()
    return b"{SSHA}" + __import__("base64").b64encode(digest + salt)


def _provision_xmpp_user(
    ldap_conn, username: str, password: str, uid_number: int, display_name: str
) -> str:
    """Provision posixAccount in external XMPP LDAP (mirrors xmpp-only schema)."""
    dn = f"uid={username},ou=People,{EXTERNAL_LDAP_BASE_DN}"
    attrs = {
        "objectClass": ["top", "account", "posixAccount"],
        "uid": username,
        "cn": display_name,
        "uidNumber": str(uid_number),
        "gidNumber": "1000",
        "homeDirectory": f"/home/{username}",
        "loginShell": "/bin/bash",
        "userPassword": _ssha_hash(password),
    }
    ldap_conn.add(dn, attributes=attrs)
    assert ldap_conn.result["result"] == 0, (
        f"LDAP add failed for {username}: {ldap_conn.result}"
    )
    return dn


def _delete_xmpp_user(ldap_conn, username: str) -> None:
    """Delete user from external XMPP LDAP (cleanup)."""
    dn = f"uid={username},ou=People,{EXTERNAL_LDAP_BASE_DN}"
    ldap_conn.delete(dn)


class XMPPTestClient(slixmpp.ClientXMPP):
    """XMPP client for e2e testing with auth tracking and message capture."""

    def __init__(self, jid: str, password: str):
        super().__init__(jid, password)
        self.auth_success = asyncio.Event()
        self.auth_failed = asyncio.Event()
        self.received_messages: list[dict] = []
        self._message_event = asyncio.Event()

        self.add_event_handler("session_start", self._on_session_start)
        self.add_event_handler("failed_auth", self._on_failed_auth)
        self.add_event_handler("message", self._on_message)

        # Plugins
        self.register_plugin("xep_0030")  # Service Discovery
        self.register_plugin("xep_0199")  # Ping

        # SSL: disable cert verification for self-signed certs
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE

    async def _on_session_start(self, event):
        self.send_presence()
        await self.get_roster()
        self.auth_success.set()

    def _on_failed_auth(self, event):
        self.auth_failed.set()

    def _on_message(self, msg):
        if msg["type"] in ("chat", "normal") and msg["body"]:
            self.received_messages.append({
                "from": str(msg["from"]),
                "body": msg["body"],
            })
            self._message_event.set()

    async def wait_for_auth(self, timeout: float = 10.0) -> bool:
        """Wait for auth result. Returns True on success, raises on failure/timeout."""
        done, _ = await asyncio.wait(
            [
                asyncio.create_task(self.auth_success.wait()),
                asyncio.create_task(self.auth_failed.wait()),
            ],
            return_when=asyncio.FIRST_COMPLETED,
            timeout=timeout,
        )
        if self.auth_failed.is_set():
            raise AssertionError(f"XMPP auth failed for {self.boundjid.bare}")
        if not self.auth_success.is_set():
            raise TimeoutError(f"XMPP auth timeout for {self.boundjid.bare}")
        return True

    async def wait_for_message(self, timeout: float = 5.0) -> dict:
        """Wait for a message to arrive. Returns the message dict."""
        self._message_event.clear()
        await asyncio.wait_for(self._message_event.wait(), timeout=timeout)
        return self.received_messages[-1]


@pytest.mark.external_network
class TestXmppE2EProvisioning:
    """E2E: AD provisioning → QR → consume → XMPP auth → chat → audit."""

    def _make_usernames(self):
        return f"xmppe2e_{_RUN_ID}_u1", f"xmppe2e_{_RUN_ID}_u2"

    def test_provision_users_to_external_ldap(self, external_ldap_conn):
        """Step 1: Provision 2 posixAccount users into real XMPP LDAP."""
        u1, u2 = self._make_usernames()
        pw1, pw2 = secrets.token_urlsafe(12), secrets.token_urlsafe(12)
        try:
            dn1 = _provision_xmpp_user(external_ldap_conn, u1, pw1, 30001, f"Test User {u1}")
            dn2 = _provision_xmpp_user(external_ldap_conn, u2, pw2, 30002, f"Test User {u2}")
            # Verify entries exist
            external_ldap_conn.search(dn1, "(objectClass=*)")
            assert len(external_ldap_conn.entries) == 1
            external_ldap_conn.search(dn2, "(objectClass=*)")
            assert len(external_ldap_conn.entries) == 1
        finally:
            _delete_xmpp_user(external_ldap_conn, u1)
            _delete_xmpp_user(external_ldap_conn, u2)

    @pytest.mark.asyncio
    async def test_xmpp_auth_and_messaging(self, external_ldap_conn):
        """Step 2: Authenticate to XMPP server and exchange messages."""
        u1, u2 = self._make_usernames()
        pw1 = secrets.token_urlsafe(12)
        pw2 = secrets.token_urlsafe(12)

        # Provision users
        _provision_xmpp_user(external_ldap_conn, u1, pw1, 30003, f"Test {u1}")
        _provision_xmpp_user(external_ldap_conn, u2, pw2, 30004, f"Test {u2}")

        try:
            jid1 = f"{u1}@{XMPP_DOMAIN}"
            jid2 = f"{u2}@{XMPP_DOMAIN}"

            client1 = XMPPTestClient(jid1, pw1)
            client2 = XMPPTestClient(jid2, pw2)

            # Connect both
            client1.connect((XMPP_SERVER_HOST, XMPP_SERVER_PORT))
            client2.connect((XMPP_SERVER_HOST, XMPP_SERVER_PORT))

            await client1.wait_for_auth()
            await client2.wait_for_auth()

            # Allow presence to propagate
            await asyncio.sleep(1)

            # User 1 → User 2
            client1.send_message(mto=jid2, mbody="Hello from user1", mtype="chat")
            msg = await client2.wait_for_message(timeout=5)
            assert msg["body"] == "Hello from user1"

            # User 2 → User 1
            client2.send_message(mto=jid1, mbody="Reply from user2", mtype="chat")
            msg = await client1.wait_for_message(timeout=5)
            assert msg["body"] == "Reply from user2"

            client1.disconnect()
            client2.disconnect()
        finally:
            _delete_xmpp_user(external_ldap_conn, u1)
            _delete_xmpp_user(external_ldap_conn, u2)

    def test_full_platform_flow(self, client, external_ldap_conn, db_conn):
        """Step 3: Full AD platform flow — create users, QR, consume, verify audit."""
        u1, u2 = self._make_usernames()
        pw1 = "TestPass_" + secrets.token_urlsafe(8)
        pw2 = "TestPass_" + secrets.token_urlsafe(8)
        created_uids = []

        try:
            # 3a. Provision into external XMPP LDAP
            _provision_xmpp_user(external_ldap_conn, u1, pw1, 30005, f"E2E User {u1}")
            _provision_xmpp_user(external_ldap_conn, u2, pw2, 30006, f"E2E User {u2}")

            # 3b. Create users in AD Directory (for QR/audit)
            for uid, pw in [(u1, pw1), (u2, pw2)]:
                resp = client.post("/api/users/create", json={
                    "uid": uid,
                    "displayName": f"E2E User {uid}",
                    "mail": f"{uid}@test.local",
                    "mobile": "0000000000",
                    "password": pw,
                    "orgDn": f"ou=org,{LDAP_BASE_DN}",
                })
                assert resp.status_code == 201, f"User create failed: {resp.text}"
                created_uids.append(uid)

            # 3c. Generate QR codes
            qr1 = client.get(f"/api/users/{u1}/qrcode")
            assert qr1.status_code == 200, f"QR gen failed for {u1}: {qr1.text}"
            qr1_data = qr1.json()
            token1 = qr1_data["payload"]["payload"]["uc"]["credentials"]["token"]

            qr2 = client.get(f"/api/users/{u2}/qrcode")
            assert qr2.status_code == 200, f"QR gen failed for {u2}: {qr2.text}"
            qr2_data = qr2.json()
            token2 = qr2_data["payload"]["payload"]["uc"]["credentials"]["token"]

            # 3d. Consume provision tokens
            c1 = client.post("/api/provision/consume", json={
                "token": token1,
                "deviceId": f"e2e-device-{u1}",
                "clientInfo": {"platform": "e2e-test", "version": "1.0"},
            })
            assert c1.status_code == 200, f"Consume failed for {u1}: {c1.text}"
            assert c1.json()["uid"] == u1
            assert c1.json()["config"]["authMethod"] == "ldap_bind"

            c2 = client.post("/api/provision/consume", json={
                "token": token2,
                "deviceId": f"e2e-device-{u2}",
                "clientInfo": {"platform": "e2e-test", "version": "1.0"},
            })
            assert c2.status_code == 200, f"Consume failed for {u2}: {c2.text}"

            # 3e. Verify one-time token enforcement
            c1_dup = client.post("/api/provision/consume", json={"token": token1})
            assert c1_dup.status_code == 409, "Token should be consumed (one-time)"

            # 3f. Verify audit trail: QR issuance
            qr_hist1 = client.get(f"/api/users/{u1}/qr_history")
            assert qr_hist1.status_code == 200
            history = qr_hist1.json()
            assert len(history.get("issuances", history.get("items", []))) >= 1

            # 3g. Verify audit trail: provision token consumed
            token1_hash = hashlib.sha256(token1.encode()).hexdigest()
            with db_conn.cursor() as cur:
                cur.execute(
                    "SELECT status, consumed_by_device_id FROM provision_tokens WHERE token_hash = %s",
                    (token1_hash,),
                )
                row = cur.fetchone()
                assert row is not None, "Provision token not found in DB"
                assert row[0] == "consumed", f"Token status should be consumed, got {row[0]}"
                assert row[1] == f"e2e-device-{u1}"

        finally:
            # Cleanup: external LDAP
            for uid in [u1, u2]:
                try:
                    _delete_xmpp_user(external_ldap_conn, uid)
                except Exception:
                    pass
            # Cleanup: AD LDAP + DB
            from ldap3 import Server, Connection, ALL
            for uid in created_uids:
                dn = f"uid={uid},ou=people,{LDAP_BASE_DN}"
                try:
                    from conftest import LDAP_ADMIN_DN, LDAP_ADMIN_PW
                    s = Server("ldap://localhost:1390", get_info=ALL)
                    c = Connection(s, user=LDAP_ADMIN_DN, password=LDAP_ADMIN_PW, auto_bind=True)
                    c.delete(dn)
                    c.unbind()
                except Exception:
                    pass
                with db_conn.cursor() as cur:
                    cur.execute("DELETE FROM provision_tokens WHERE uid = %s", (uid,))
                    cur.execute("DELETE FROM qr_issuance_audit WHERE user_uid = %s", (uid,))
```

**Step 2: Verify the test collects properly**
```bash
pytest tests/test_xmpp_e2e.py --collect-only
```

Expected: 3 tests collected (all skip without EXTERNAL_LDAP_ADMIN_PASSWORD).

---

### Task 4: Add Justfile recipe and documentation
**domain:** devops
**depends_on:** [3]
**parallel_group:** 3

**Files:**
- Modify: `justfile`
- Modify: `CLAUDE.md` (testing section)

**Step 1: Add justfile recipe**
After the existing `test-all` recipe, add:
```just
# Run XMPP e2e test (requires access to 192.168.122.89)
test-xmpp-e2e:
    EXTERNAL_LDAP_ADMIN_PASSWORD=${EXTERNAL_LDAP_ADMIN_PASSWORD} pytest tests/test_xmpp_e2e.py -v -s -m external_network
```

**Step 2: Add to CLAUDE.md testing section**
Add after the existing test commands:
```markdown
just test-xmpp-e2e     # Run XMPP e2e test (requires external network + EXTERNAL_LDAP_ADMIN_PASSWORD)
```

---

### Task 5: Run the test and verify
**domain:** test
**depends_on:** [3, 4]
**parallel_group:** 4

**Step 1: Set environment and run**
```bash
export EXTERNAL_LDAP_ADMIN_PASSWORD=<actual_password>
just test-xmpp-e2e
```

**Step 2: Verify all 3 tests pass**
Expected output:
- `test_provision_users_to_external_ldap` — PASSED
- `test_xmpp_auth_and_messaging` — PASSED
- `test_full_platform_flow` — PASSED

**Step 3: Run without env var to verify skip behavior**
```bash
unset EXTERNAL_LDAP_ADMIN_PASSWORD
pytest tests/test_xmpp_e2e.py -v
```
Expected: All 3 tests SKIPPED.

**Step 4: Verify existing tests still pass**
```bash
just test-quick
```
Expected: All existing tests still pass (no regression).
