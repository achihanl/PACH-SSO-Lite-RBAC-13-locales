# Groups Management — Implementation Plan

**Date:** 2026-02-08
**Design doc:** `docs/plans/2026-02-08-groups-management-migration.md`
**Reference implementation:** `src/frontend/src/components/features/user-management/`

## Workflow

Each phase: implement → code review → fix findings → next phase.

---

## Phase 0: Schema + API Foundation

**Goal:** Database tables exist, backend CRUD module ready, frontend types defined.

### Step 0.1 — Migration SQL

**Create** `migrations/005_groups_management.sql`

```sql
-- Migration 005: Groups Management (RBAC + enrichment)
-- For existing deployments upgrading in-place.
-- Fresh deployments auto-create via OrgDB.init().

CREATE TABLE IF NOT EXISTS group_profiles (
    cn              TEXT PRIMARY KEY,
    group_type      TEXT NOT NULL DEFAULT 'distribution'
                    CHECK (group_type IN ('security','distribution','department','project')),
    permissions     JSONB NOT NULL DEFAULT '[]',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS group_member_roles (
    group_cn        TEXT NOT NULL REFERENCES group_profiles(cn) ON DELETE CASCADE,
    member_uid      TEXT NOT NULL,
    role            TEXT NOT NULL DEFAULT 'member'
                    CHECK (role IN ('owner','admin','member')),
    assigned_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (group_cn, member_uid)
);

CREATE INDEX IF NOT EXISTS idx_gmr_member ON group_member_roles(member_uid);
```

### Step 0.2 — SQLAlchemy Table Definitions

**Edit** `src/backend/orgdb.py` — add two table definitions at module level (after existing tables, before `OrgDB` class):

```python
group_profiles = Table(
    "group_profiles",
    metadata,
    Column("cn", String(255), primary_key=True),
    Column("group_type", String(50), nullable=False, server_default="distribution"),
    Column("permissions", JSON, nullable=False, server_default="[]"),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("updated_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
)

group_member_roles = Table(
    "group_member_roles",
    metadata,
    Column("group_cn", String(255), ForeignKey("group_profiles.cn", ondelete="CASCADE"), primary_key=True),
    Column("member_uid", String(255), primary_key=True),
    Column("role", String(20), nullable=False, server_default="member"),
    Column("assigned_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
)
```

Note: `metadata.create_all()` in `OrgDB.init()` will auto-create these for fresh deployments.

### Step 0.3 — GroupDB Methods on OrgDB

**Edit** `src/backend/orgdb.py` — add methods to the `OrgDB` class following the existing CRUD pattern (`eng = self.connect()` → `with eng.begin() as conn:`):

| Method | Signature | SQL |
|--------|-----------|-----|
| `get_group_profile(cn)` | `-> dict | None` | `SELECT * FROM group_profiles WHERE cn = :cn` |
| `upsert_group_profile(cn, group_type, permissions)` | `-> dict` | `INSERT ... ON CONFLICT (cn) DO UPDATE`, sets `updated_at = now()` |
| `delete_group_profile(cn)` | `-> bool` | `DELETE FROM group_profiles WHERE cn = :cn` |
| `list_group_profiles()` | `-> list[dict]` | `SELECT * FROM group_profiles ORDER BY cn` |
| `get_member_role(group_cn, member_uid)` | `-> str | None` | `SELECT role FROM group_member_roles WHERE ...` |
| `set_member_role(group_cn, member_uid, role)` | `-> dict` | `INSERT ... ON CONFLICT DO UPDATE SET role = :role` |
| `delete_member_role(group_cn, member_uid)` | `-> bool` | `DELETE FROM group_member_roles WHERE ...` |
| `list_member_roles(group_cn)` | `-> list[dict]` | `SELECT * FROM group_member_roles WHERE group_cn = :group_cn` |
| `get_user_permissions(member_uid)` | `-> list[str]` | `SELECT DISTINCT permissions FROM group_profiles JOIN group_member_roles ON ...` (for RBAC resolution) |

### Step 0.4 — LDAP `description` Support

**Edit** `src/backend/ldap_client.py`:

- `list_groups()` — add `'description'` to `attributes=[...]` list, include in return dict
- `create_group(org_dn, cn, description="")` — add `description` param, include in `conn.add()` attrs when non-empty
- New function `update_group_description(group_dn, description)` — `MODIFY_REPLACE` on `description` attribute

### Step 0.5 — Frontend Types

**Create** `src/frontend/src/types/group.ts`:

```typescript
export type GroupType = 'security' | 'distribution' | 'department' | 'project';
export type MemberRole = 'owner' | 'admin' | 'member';
export type PermissionKey = 'user_management' | 'qr_provisioning' | 'audit_log_access' | 'system_configuration';

export interface GroupListItem {
  cn: string;
  dn: string;
  description: string;
  group_type: GroupType;
  member_count: number;
  permissions: PermissionKey[];
  created_at: string;
  updated_at: string;
}

export interface GroupMember {
  uid: string;
  dn: string;
  displayName: string;
  mail: string;
  role: MemberRole;
}

export interface GroupDetail extends GroupListItem {
  members: GroupMember[];
}
```

**Edit** `src/frontend/src/types/user.ts` — add deprecation comment on existing `Group` interface pointing to `types/group.ts`.

### Step 0.6 — Query Keys

**Edit** `src/frontend/src/lib/queries/keys.ts` — add:

```typescript
group: (cn: string) => ['groups', cn] as const,
groupPermissions: (cn: string) => ['groups', cn, 'permissions'] as const,
userSearch: (query: string) => ['users', 'search', query] as const,
```

### Step 0.7 — Verify

- Run `just test` to confirm no regressions
- Check that `just up` creates the new tables (inspect via `just psql` → `\dt`)

---

## Phase 1: Enhanced List + Detail Endpoints + Split-Panel Shell

**Goal:** Groups page shows split-panel layout with enriched data from joined LDAP + Postgres.

### Step 1.1 — Backend: Enhanced `GET /api/groups`

**Edit** `src/backend/main.py` — `api_groups()`:

- Accept optional query params: `type: str | None = None`, `search: str | None = None`
- Call `list_groups()` for LDAP data
- Call `orgdb.list_group_profiles()` for Postgres enrichment
- Merge by `cn` — for groups without a Postgres profile, use defaults (`group_type='distribution'`, `permissions=[]`, `created_at=None`)
- Apply `type` filter (case-insensitive match on `group_type`)
- Apply `search` filter (substring match on `cn` or `description`)
- Return enriched list

### Step 1.2 — Backend: New `GET /api/groups/{cn}`

**Edit** `src/backend/main.py` — add new endpoint:

- `@app.get("/api/groups/{cn}")` with `require_user`
- Resolve group DN via `find_group_dn(cn)`
- Fetch LDAP attributes (cn, dn, description, members)
- Fetch Postgres profile via `orgdb.get_group_profile(cn)` (use defaults if absent)
- Fetch members via `get_group_members(group_dn)`
- Enrich members with roles from `orgdb.list_member_roles(cn)`
- Return merged `GroupDetail` response

### Step 1.3 — Frontend: `GroupManagementPage.tsx`

**Create** `src/frontend/src/components/features/group-management/GroupManagementPage.tsx`

Follow `UserManagementPage.tsx` pattern exactly:
- Props: `searchParams: { groupId?: string; filter?: string; search?: string }`
- `useNavigate()` + URL state updates
- `useModalState()` (create stub that only has `'closed'` for now)
- Grid layout: `grid grid-cols-1 lg:grid-cols-[1fr_420px]`
- Left: `<Suspense>` → `<GroupList>`
- Right: conditional detail panel (placeholder div for now)
- Cmd+K shortcut via `useRef` + `useEffect`

### Step 1.4 — Frontend: `PageHeader.tsx`

**Create** `src/frontend/src/components/features/group-management/PageHeader.tsx`

- Title: "Groups"
- `SearchInput` (import from user-management or duplicate — decide at implementation time whether to promote to shared)
- "Create Group" button (wired to modal dispatch, no-op for now)
- `searchInputRef` prop for Cmd+K focus

### Step 1.5 — Frontend: `GroupList.tsx`

**Create** `src/frontend/src/components/features/group-management/GroupList.tsx`

- Filter tabs: All / Security / Distribution / Department / Project (using `<Tabs variant="pill">`)
- Count display
- Scrollable list of `<GroupRow>` items
- Empty state
- Skeleton fallback

### Step 1.6 — Frontend: `GroupRow.tsx`

**Create** `src/frontend/src/components/features/group-management/GroupRow.tsx`

- Type-colored icon (Shield for security, Users for distribution, Building for department, Folder for project)
- Group name (`cn`)
- Description (truncated)
- Member count
- `<GroupTypeBadge>` on right

### Step 1.7 — Frontend: `GroupTypeBadge.tsx`

**Create** `src/frontend/src/components/features/group-management/GroupTypeBadge.tsx`

- Color mapping: security=red, distribution=blue, department=purple, project=green
- Uses `<Badge>` from `@azblink/ui`

### Step 1.8 — Frontend: Enhanced Query Hook

**Edit** `src/frontend/src/lib/queries/groups.ts`:

- Update `groupsQueryOptions()` to return `GroupListItem[]` (from `types/group.ts`)
- Add `groupDetailQueryOptions(cn)` → `GET /api/groups/${cn}` returning `GroupDetail`

### Step 1.9 — Frontend: Route Update

**Edit** `src/frontend/src/routes/directory/groups/index.tsx`:

- Add `validateSearch` for `groupId`, `filter`, `search` params
- Replace card grid component with `<GroupManagementPage searchParams={searchParams} />`

### Step 1.10 — Verify

- `just test` for backend regressions
- Manual browser test: navigate to `/directory/groups`, verify split-panel renders, groups load with type badges, filter tabs work, search works, URL updates on selection

---

## Phase 2: Group Detail Panel

**Goal:** Selecting a group shows full detail in the right panel.

### Step 2.1 — Frontend: `GroupDetailPanel.tsx`

**Create** `src/frontend/src/components/features/group-management/GroupDetailPanel.tsx`

Follow `UserDetailPanel.tsx` pattern:
- `useSuspenseQuery(groupDetailQueryOptions(cn))` inside Suspense
- Header: large type-colored icon + group name + Edit/Delete action buttons (no-op for now)
- Info grid (2-col): DN, Type, Created, Modified
- Members section: heading + count + list of `<MemberRow>` + "Add Member" CTA (no-op for now)
- Permissions section: heading + list of `<PermissionToggle>` (read-only for now)

### Step 2.2 — Frontend: `MemberRow.tsx`

**Create** `src/frontend/src/components/features/group-management/MemberRow.tsx`

- Avatar (initials with gradient — reuse `getInitials` helper from user-management)
- Display name + email
- `<MemberRoleBadge>` (owner=amber, admin=purple, member=zinc)
- Remove button (hidden, hover-reveal) — no-op for now
- Role dropdown — no-op for now

### Step 2.3 — Frontend: `MemberRoleBadge.tsx`

**Create** `src/frontend/src/components/features/group-management/MemberRoleBadge.tsx`

- Uses `<Badge>` from `@azblink/ui`
- Color mapping: owner=amber, admin=purple, member=zinc

### Step 2.4 — Frontend: `PermissionToggle.tsx`

**Create** `src/frontend/src/components/features/group-management/PermissionToggle.tsx`

- Label + description text
- Toggle switch (read-only for now, wired in Phase 5)
- Uses native `<input type="checkbox" role="switch">` or `@azblink/ui` Switch if available

### Step 2.5 — Wire Detail Panel into Page

**Edit** `GroupManagementPage.tsx`:
- Import `GroupDetailPanel`
- Render in right panel when `groupId` is selected (inside `<Suspense>`)

### Step 2.6 — Verify

- Manual browser test: select a group, verify detail panel shows info grid, members with roles, permissions section

---

## Phase 3: Create + Delete Groups

**Goal:** Full group lifecycle — create with type/description, edit metadata, delete with confirmation.

### Step 3.1 — Backend: Enhanced `POST /api/groups/create`

**Edit** `src/backend/main.py`:

- Extend `GroupCreateReq` with `description: str = ""` and `group_type: str = "distribution"`
- Validate `group_type` against allowed values
- After `create_group()` in LDAP, call `orgdb.upsert_group_profile(cn, group_type, [])`
- Extract creator UID from JWT claims, call `orgdb.set_member_role(cn, creator_uid, 'owner')`
- Return enriched response

### Step 3.2 — Backend: Enhanced `DELETE /api/groups/{cn}`

**Edit** `src/backend/main.py` — `api_group_delete()`:

- After `delete_group()` in LDAP, call `orgdb.delete_group_profile(cn)` (cascades to member roles)

### Step 3.3 — Backend: New `PATCH /api/groups/{cn}`

**Edit** `src/backend/main.py` — add endpoint:

```python
class GroupUpdateReq(BaseModel):
    description: str | None = None
    group_type: str | None = None
```

- `@app.patch("/api/groups/{cn}")` with `require_admin`
- If `description` provided: call `update_group_description(group_dn, description)` (LDAP)
- If `group_type` provided: validate, then call `orgdb.upsert_group_profile(cn, group_type=group_type)` (Postgres)
- Return updated group detail

### Step 3.4 — Frontend: `useModalState.ts`

**Create** `src/frontend/src/components/features/group-management/useModalState.ts`

States: `'closed' | 'create_group' | 'add_members' | 'delete_confirm'`
Actions: `OPEN_CREATE`, `OPEN_ADD_MEMBERS(cn)`, `OPEN_DELETE(cn)`, `CLOSE`
Dispatch helpers: `openCreate`, `openAddMembers`, `openDelete`, `close`

### Step 3.5 — Frontend: Mutation Hooks

**Create** `src/frontend/src/lib/queries/group-mutations.ts`:

- `useCreateGroup()` — `POST /api/groups/create`, invalidates `queryKeys.groups`
- `useDeleteGroup()` — `DELETE /api/groups/{cn}`, invalidates `queryKeys.groups`
- `useUpdateGroup()` — `PATCH /api/groups/{cn}`, invalidates `queryKeys.groups` and `queryKeys.group(cn)`

### Step 3.6 — Frontend: `CreateGroupModal.tsx`

**Create** `src/frontend/src/components/features/group-management/modals/CreateGroupModal.tsx`

Follow `AddUserModal.tsx` pattern:
- Dialog with form: group name (`cn`), description (Textarea), type (select/dropdown), parent org (select)
- Local `useState` for form fields + error
- `useCreateGroup()` mutation
- Validate: cn required, cn format (alphanumeric + hyphens)
- On success: toast, close modal, optionally select new group

### Step 3.7 — Frontend: `DeleteGroupModal.tsx`

**Create** `src/frontend/src/components/features/group-management/modals/DeleteGroupModal.tsx`

- Confirmation dialog showing group name
- "Type the group name to confirm" input pattern
- `useDeleteGroup()` mutation
- On success: toast, close modal, deselect group

### Step 3.8 — Wire Modals into Page

**Edit** `GroupManagementPage.tsx`:
- Import modal state + modal components
- Wire "Create Group" button to `modal.openCreate()`
- Wire detail panel Delete button to `modal.openDelete(cn)`
- Render modals conditionally

### Step 3.9 — Verify

- `just test` for backend regressions
- Manual test: create group with type/description, verify it appears in list with correct badge, delete group with confirmation

---

## Phase 4: Member Management

**Goal:** Add/remove group members, change member roles.

### Step 4.1 — Backend: Enhanced `GET /api/groups/{cn}/members`

**Edit** `src/backend/main.py` — `api_group_members()`:

- After getting member list from LDAP, enrich each member with `role` from `orgdb.list_member_roles(cn)`
- Members without a role row default to `'member'`
- Return `GroupMember[]` with role field

### Step 4.2 — Backend: New `PATCH /api/groups/{cn}/members/{uid}/role`

**Edit** `src/backend/main.py` — add endpoint:

```python
class GroupMemberRoleReq(BaseModel):
    role: str = Field(..., pattern="^(owner|admin|member)$")
```

- `@app.patch("/api/groups/{cn}/members/{uid}/role")` with `require_admin`
- Validate `role` against allowed values
- Call `orgdb.set_member_role(cn, uid, role)`
- Return updated member

### Step 4.3 — Backend: New `GET /api/users/search`

**Edit** `src/backend/main.py` — add endpoint:

- `@app.get("/api/users/search")` with `require_user`
- Query params: `q: str`, `exclude_group: str | None = None`
- Search LDAP users by `uid`, `displayName`, or `mail` containing `q` (use existing `search_users()` or add new LDAP function)
- If `exclude_group` provided, filter out users who are already members of that group
- Return `{ users: UserSearchResult[] }` with `uid`, `displayName`, `mail`
- Limit results to 20

### Step 4.4 — Backend: Enhanced `POST /api/groups/{cn}/members`

**Edit** `src/backend/main.py` — `api_group_add()`:

- After adding member to LDAP, also call `orgdb.set_member_role(cn, uid, 'member')` to create default role

### Step 4.5 — Backend: Enhanced `DELETE /api/groups/{cn}/members/{uid}`

**Edit** `src/backend/main.py` — `api_group_remove()`:

- After removing member from LDAP, also call `orgdb.delete_member_role(cn, uid)`

### Step 4.6 — Frontend: Member Mutation Hooks

**Create** `src/frontend/src/lib/queries/group-members.ts`:

- `useAddMembers()` — `POST /api/groups/{cn}/members` (called per user in a loop or batch), invalidates `queryKeys.group(cn)` and `queryKeys.groupMembers(cn)`
- `useRemoveMember()` — `DELETE /api/groups/{cn}/members/{uid}`, same invalidation
- `useUpdateMemberRole()` — `PATCH /api/groups/{cn}/members/{uid}/role`, same invalidation
- `useSearchUsers(query, excludeGroup)` — `GET /api/users/search?q=&excludeGroup=`, returns search results

### Step 4.7 — Frontend: `AddMembersModal.tsx`

**Create** `src/frontend/src/components/features/group-management/modals/AddMembersModal.tsx`

- Search input with debounced query (300ms)
- Results list with checkboxes for multi-select
- "Add Selected" button
- Uses `useSearchUsers()` for search + `useAddMembers()` for submission
- Excludes already-member users via `excludeGroup` param
- On success: toast with count, close modal

### Step 4.8 — Frontend: Wire Member Actions

**Edit** `MemberRow.tsx`:
- Role dropdown: `<select>` or custom dropdown, calls `useUpdateMemberRole()` on change
- Remove button: calls `useRemoveMember()` with confirmation

**Edit** `GroupDetailPanel.tsx`:
- "Add Member" CTA wires to `modal.openAddMembers(cn)`

**Edit** `GroupManagementPage.tsx`:
- Import and render `AddMembersModal`

### Step 4.9 — Verify

- `just test` for backend regressions
- Manual test: add member via modal (search + select + add), verify member appears with `member` role, change role to `admin`, remove member

---

## Phase 5: Permissions

**Goal:** RBAC permission toggles functional, `require_permission` decorator enforcing access.

### Step 5.1 — Backend: New `PATCH /api/groups/{cn}/permissions`

**Edit** `src/backend/main.py` — add endpoint:

```python
class GroupPermissionsReq(BaseModel):
    permissions: list[str]

VALID_PERMISSIONS = {'user_management', 'qr_provisioning', 'audit_log_access', 'system_configuration'}
```

- `@app.patch("/api/groups/{cn}/permissions")` with `require_admin`
- Validate all items in `permissions` are in `VALID_PERMISSIONS`
- Call `orgdb.upsert_group_profile(cn, permissions=permissions)`
- Return updated permissions

### Step 5.2 — Backend: `require_permission` Decorator

**Edit** `src/backend/auth.py` (or `main.py` where other auth decorators live):

```python
def require_permission(permission: str):
    def dependency(claims: dict = Depends(require_user)):
        uid = claims.get("uid") or claims.get("sub")
        # Check RBAC
        user_permissions = orgdb.get_user_permissions(uid)
        if permission in user_permissions:
            return claims
        # Fallback to existing admin check
        if not REQUIRE_OIDC_AUTH:
            return claims  # backward compat: non-OIDC mode allows all
        groups = claims.get(OIDC_GROUPS_CLAIM)
        if groups and OIDC_ADMIN_GROUP in groups:
            return claims
        raise HTTPException(403, "Insufficient permissions")
    return dependency
```

### Step 5.3 — Backend: Migrate Group Endpoints to `require_permission`

**Edit** `src/backend/main.py`:

Replace `require_admin` with `require_permission("user_management")` on these group endpoints only:
- `POST /api/groups/create`
- `PATCH /api/groups/{cn}`
- `DELETE /api/groups/{cn}`
- `POST /api/groups/{cn}/members`
- `DELETE /api/groups/{cn}/members/{uid}`
- `PATCH /api/groups/{cn}/members/{uid}/role`
- `PATCH /api/groups/{cn}/permissions`

All other endpoints (user management, QR, etc.) stay on `require_admin` for now.

### Step 5.4 — Frontend: Permission Mutation Hook

**Create** `src/frontend/src/lib/queries/group-permissions.ts`:

- `useUpdateGroupPermissions()` — `PATCH /api/groups/{cn}/permissions`
- Optimistic update: immediately toggle in query cache, roll back on error
- Invalidates `queryKeys.group(cn)`

### Step 5.5 — Frontend: Wire Permission Toggles

**Edit** `PermissionToggle.tsx`:
- Accept `enabled`, `onToggle` props
- Call mutation on toggle

**Edit** `GroupDetailPanel.tsx`:
- Use `useUpdateGroupPermissions()` mutation
- Pass individual toggle handlers to each `<PermissionToggle>`

### Step 5.6 — Verify

- `just test` for backend regressions
- Manual test: toggle permission on a group, verify it persists on reload
- Test RBAC: create non-admin user, add to a group with `user_management` permission, verify they can access user management endpoints
- Test fallback: verify existing admin users still have full access

---

## Phase 6: Polish

**Goal:** Production-ready UX with keyboard shortcuts, accessibility, edge case handling.

### Step 6.1 — Redirect Route

**Create** `src/frontend/src/routes/directory/groups/$cn.tsx`:

```typescript
export const Route = createFileRoute('/directory/groups/$cn')({
  beforeLoad: ({ params }) => {
    throw redirect({ to: '/directory/groups', search: { groupId: params.cn } });
  },
  component: () => null,
});
```

### Step 6.2 — Empty States

**Edit** `GroupDetailPanel.tsx`:
- No group selected: "Select a group to view details" placeholder
- Group has no members: "No members yet — add the first member" CTA

**Edit** `GroupList.tsx`:
- No groups match filter: "No groups found" with suggestion to clear filters
- No groups exist: "No groups yet — create your first group" CTA

### Step 6.3 — Loading Skeletons

- `GroupList`: skeleton rows (pulse animation) matching `GroupRow` dimensions
- `GroupDetailPanel`: skeleton matching info grid + member list + permissions layout

### Step 6.4 — Accessibility

- `role="alert"` on all error containers
- `aria-live="polite"` on dynamic content (member count after add/remove)
- `aria-label` on icon-only buttons (remove member, edit, delete)
- `fieldset`/`legend` for permission toggles group
- Proper `label`/`htmlFor` associations on all form inputs in modals
- Focus management: auto-focus search input in AddMembersModal on open

### Step 6.5 — Keyboard Shortcut Hint

- Show "⌘K" badge in search input (matching user management page)

### Step 6.6 — Shared Component Audit

Evaluate whether to promote shared components:
- `SearchInput` — if identical to user-management version, move to `components/shared/`
- `getInitials()` helper — if used in both MemberRow and UserRow, move to `lib/utils/`

### Step 6.7 — Verify

- `just test` full suite
- Manual browser walkthrough: all CRUD flows, all modals, all error states, keyboard navigation, screen reader spot-check

---

## File Inventory

### New Files (estimated ~18)

| File | Phase |
|------|-------|
| `migrations/005_groups_management.sql` | 0 |
| `src/frontend/src/types/group.ts` | 0 |
| `src/frontend/src/components/features/group-management/GroupManagementPage.tsx` | 1 |
| `src/frontend/src/components/features/group-management/PageHeader.tsx` | 1 |
| `src/frontend/src/components/features/group-management/GroupList.tsx` | 1 |
| `src/frontend/src/components/features/group-management/GroupRow.tsx` | 1 |
| `src/frontend/src/components/features/group-management/GroupTypeBadge.tsx` | 1 |
| `src/frontend/src/components/features/group-management/GroupDetailPanel.tsx` | 2 |
| `src/frontend/src/components/features/group-management/MemberRow.tsx` | 2 |
| `src/frontend/src/components/features/group-management/MemberRoleBadge.tsx` | 2 |
| `src/frontend/src/components/features/group-management/PermissionToggle.tsx` | 2 |
| `src/frontend/src/components/features/group-management/useModalState.ts` | 3 |
| `src/frontend/src/components/features/group-management/modals/CreateGroupModal.tsx` | 3 |
| `src/frontend/src/components/features/group-management/modals/DeleteGroupModal.tsx` | 3 |
| `src/frontend/src/components/features/group-management/modals/AddMembersModal.tsx` | 4 |
| `src/frontend/src/lib/queries/group-mutations.ts` | 3 |
| `src/frontend/src/lib/queries/group-members.ts` | 4 |
| `src/frontend/src/lib/queries/group-permissions.ts` | 5 |
| `src/frontend/src/routes/directory/groups/$cn.tsx` | 6 |

### Modified Files (estimated ~8)

| File | Phase | Changes |
|------|-------|---------|
| `src/backend/orgdb.py` | 0 | Table defs + 9 CRUD methods |
| `src/backend/ldap_client.py` | 0, 4 | `description` support + user search |
| `src/backend/main.py` | 1-5 | 5 new endpoints + 4 enhanced + request models |
| `src/backend/auth.py` | 5 | `require_permission` decorator |
| `src/frontend/src/lib/queries/groups.ts` | 1 | Enhanced return types + detail query |
| `src/frontend/src/lib/queries/keys.ts` | 0 | 3 new query keys |
| `src/frontend/src/types/user.ts` | 0 | Deprecation comment on old `Group` |
| `src/frontend/src/routes/directory/groups/index.tsx` | 1 | Route rewrite with validateSearch |

---

## Risk Considerations

| Risk | Mitigation |
|------|------------|
| LDAP `description` attribute not writable | Test in Phase 0 with `just ldap-users`; OpenLDAP `groupOfNames` schema supports it by default |
| Postgres foreign key cascade deletes role data | Intentional — group deletion should clean up roles. Validate in Phase 3 test. |
| `require_permission` breaks existing admin access | Fallback chain: RBAC → LDAP admin → deny. Test backward compat explicitly in Phase 5. |
| Optimistic permission toggle causes inconsistent UI | Roll back cache on mutation error. Test with network error simulation. |
| LDAP user search performance with large directories | Limit to 20 results + require minimum 2-char query. Paginate if needed later. |
