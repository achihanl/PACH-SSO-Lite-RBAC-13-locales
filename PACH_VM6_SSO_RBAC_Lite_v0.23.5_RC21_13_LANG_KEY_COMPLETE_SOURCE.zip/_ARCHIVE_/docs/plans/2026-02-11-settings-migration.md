# Settings Page Migration — Design Document

**Date:** 2026-02-11
**Branch:** `feat/config-templates` (or new `feat/settings-migration`)
**Spec:** `new-migration-ui/SETTINGS_MIGRATION_SPEC.md`
**HTML Prototype:** `new-migration-ui/settings-content-only.html`
**Workflow rules:** `.cursor/rules/split-panel-migration-workflow.mdc`

---

## 1. Summary

Replace the current read-only system info page at `/configuration/settings` with a full admin settings management page. 9 sections with sticky scroll-spy navigation, inline form editing, dirty field tracking, and batch save. Full backend + frontend vertical slices.

**Current state:** Read-only cards showing system health, auth mode, API config, build info.
**Target state:** Form-driven settings with LDAP/Email/Security config, API key management, admin list, branding, danger zone — plus existing system info absorbed as section 1.

## 2. Layout Paradigm

This is NOT a split-panel master-detail migration. Unique layout:
- `240px` sticky sidebar nav + `1fr` scrolling content area
- `max-width: 1200px` container
- IntersectionObserver-powered scroll-spy for nav highlighting
- URL hash support (`/configuration/settings#security`)
- Responsive: ≤800px collapses to horizontal scroll nav + stacked forms

## 3. Section Map (9 Sections)

| # | Section | Nav Label | Content Source |
|---|---------|-----------|----------------|
| 1 | System Info | System Info | Absorbed from existing page (health + auth + build) |
| 2 | LDAP Connection | LDAP Connection | Spec §1 — forms + StatusIndicator + TestButton |
| 3 | Email / SMTP | Email / SMTP | Spec §1 — forms + TestButton |
| 4 | Security | Security | Spec §1 — selects + toggles |
| 5 | Audit & Logging | Audit & Logging | Spec §3a — RetentionRadioGroup + toggles |
| 6 | API Keys | API Keys | Spec §3b — ApiKeyDisplay + generate/revoke |
| 7 | Administrators | Administrators | Spec §3c — AdminList + invite |
| 8 | Branding | Branding | Spec §1 — forms + textarea + toggle |
| 9 | Danger Zone | Danger Zone | Spec §3d — DangerAction cards |

## 4. Data Architecture

### 4a. PostgreSQL Tables (New)

**`app_settings`** — Key/value settings grouped by section:
```sql
CREATE TABLE app_settings (
  id SERIAL PRIMARY KEY,
  section VARCHAR(50) NOT NULL,      -- 'ldap', 'email', 'security', 'audit', 'branding'
  key VARCHAR(100) NOT NULL,          -- 'serverUrl', 'baseDn', 'smtpHost', etc.
  value TEXT NOT NULL DEFAULT '',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(section, key)
);
```

**`api_keys`** — API key management:
```sql
CREATE TABLE api_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  prefix VARCHAR(20) NOT NULL,        -- 'ak_live_7f4d...' (first 16 chars)
  key_hash VARCHAR(128) NOT NULL,     -- SHA-256 hash of full key
  created_by VARCHAR(100) NOT NULL,   -- admin username
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_used_at TIMESTAMPTZ,
  revoked_at TIMESTAMPTZ              -- NULL = active, set = revoked
);
```

### 4b. Backend Endpoints (New)

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/settings` | Load all settings (grouped by section) |
| PATCH | `/api/settings` | Update changed fields only (dirty fields) |
| PUT | `/api/settings/reset` | Reset all settings to defaults |
| POST | `/api/settings/ldap/test` | Test LDAP connection |
| POST | `/api/settings/email/test` | Send test email |
| GET | `/api/keys` | List API keys (masked) |
| POST | `/api/keys` | Generate new API key (returns full key once) |
| DELETE | `/api/keys/:id` | Revoke API key |
| GET | `/api/admins` | List administrators (reads from LDAP admin group) |
| POST | `/api/admins/invite` | Invite new admin (add to LDAP admin group) |

### 4c. State Management

- **Form state:** `useState<AllSettings>` + `Set<string>` dirty tracking — no Zustand
- **API Keys / Admins:** TanStack Query `useSuspenseQuery` + mutations
- **Active section:** local state from IntersectionObserver (`useScrollSpy` hook)
- **No global store** — single-page form, all state page-scoped

## 5. New @azblink/ui Primitives (Phase 0)

| Primitive | Purpose | Base UI Foundation |
|-----------|---------|-------------------|
| `Select` | Dropdown select for Security/Email fields | `@base-ui-components/react` Select |
| `RadioGroup` | Card-style radio for Audit retention | `@base-ui-components/react` RadioGroup |
| `ToggleRow` | Label + description + Toggle in bordered row | Composes existing `Toggle` primitive |

## 6. File Structure

```
src/frontend/src/
├── components/features/settings/
│   ├── SettingsManagementPage.tsx    # Route-level orchestrator
│   ├── SettingsNav.tsx               # Sticky sidebar nav (9 items)
│   ├── SettingsSection.tsx           # Reusable section wrapper (header + body)
│   ├── FormRow.tsx                   # 2-column form grid
│   ├── FormGroup.tsx                 # Label + input + hint
│   ├── StatusIndicator.tsx           # Colored pill (healthy/warning/error)
│   ├── TestButton.tsx                # Dashed-border test action button
│   ├── sections/
│   │   ├── SystemInfoSection.tsx     # Absorbed from existing page
│   │   ├── LdapSection.tsx
│   │   ├── EmailSection.tsx
│   │   ├── SecuritySection.tsx
│   │   ├── AuditSection.tsx
│   │   ├── ApiKeysSection.tsx
│   │   ├── AdminsSection.tsx
│   │   ├── BrandingSection.tsx
│   │   └── DangerZoneSection.tsx
│   ├── ApiKeyDisplay.tsx             # Masked key + copy/revoke
│   ├── AdminItem.tsx                 # Avatar + name + role badge
│   ├── DangerAction.tsx              # Red-bordered destructive card
│   ├── RetentionRadioGroup.tsx       # Card-style radio (wraps RadioGroup)
│   └── useScrollSpy.ts              # IntersectionObserver hook
│
├── lib/queries/
│   ├── settings.ts                   # GET /api/settings query options
│   ├── settings-mutations.ts         # PATCH, PUT reset, test-connection
│   ├── api-keys.ts                   # API keys query + mutations
│   └── admins.ts                     # Admin list query
│
├── types/
│   └── settings.ts                   # All types from spec §6
│
src/frontend/packages/azblink-ui/primitives/
├── Select/                           # New primitive
│   ├── Select.tsx
│   ├── Select.module.css
│   ├── Select.types.ts
│   └── index.ts
├── RadioGroup/                       # New primitive
│   ├── RadioGroup.tsx
│   ├── RadioGroup.module.css
│   ├── RadioGroup.types.ts
│   └── index.ts
└── ToggleRow/                        # New primitive
    ├── ToggleRow.tsx
    ├── ToggleRow.module.css
    ├── ToggleRow.types.ts
    └── index.ts

src/backend/
├── main.py                           # New settings + api-keys endpoints
└── settingsdb.py                     # Settings PostgreSQL operations

migrations/
└── 005_settings.sql                  # app_settings + api_keys tables
```

## 7. Phase Plan

### Phase 0: Schema + Types + Primitives
- [ ] `migrations/005_settings.sql` — `app_settings` + `api_keys` tables
- [ ] `src/backend/settingsdb.py` — PostgreSQL CRUD for settings
- [ ] `src/frontend/src/types/settings.ts` — all TypeScript types
- [ ] `Select` primitive in @azblink/ui
- [ ] `RadioGroup` primitive in @azblink/ui
- [ ] `ToggleRow` primitive in @azblink/ui
- [ ] Export new primitives from `packages/azblink-ui/index.ts`
- [ ] Query options: `settings.ts`, `api-keys.ts`, `admins.ts`

### Phase 1: Page Shell + System Info Section
- [ ] `SettingsManagementPage.tsx` — page orchestrator
- [ ] `SettingsNav.tsx` — 9-item sticky nav
- [ ] `useScrollSpy.ts` — IntersectionObserver hook
- [ ] `SettingsSection.tsx` — reusable section wrapper
- [ ] `sections/SystemInfoSection.tsx` — absorb existing health + build info
- [ ] Update route `/configuration/settings/index.tsx` to use new page
- [ ] Backend: `GET /api/settings` endpoint
- [ ] URL hash scroll-to on mount

### Phase 2: Form Sections — LDAP, Email, Security
- [ ] `FormRow.tsx` + `FormGroup.tsx` — form layout components
- [ ] `StatusIndicator.tsx` — health pill
- [ ] `TestButton.tsx` — dashed border test action
- [ ] `sections/LdapSection.tsx` with status + test
- [ ] `sections/EmailSection.tsx` with test email
- [ ] `sections/SecuritySection.tsx` with Select + toggles
- [ ] Dirty field tracking (`updateField` helper in page)
- [ ] Backend: `PATCH /api/settings`
- [ ] Backend: `POST /api/settings/ldap/test`
- [ ] Backend: `POST /api/settings/email/test`

### Phase 3: Audit, API Keys, Admins, Branding
- [ ] `RetentionRadioGroup.tsx` — card-style radio using RadioGroup primitive
- [ ] `sections/AuditSection.tsx`
- [ ] `ApiKeyDisplay.tsx` + `sections/ApiKeysSection.tsx`
- [ ] `AdminItem.tsx` + `sections/AdminsSection.tsx`
- [ ] `sections/BrandingSection.tsx`
- [ ] Backend: `GET/POST/DELETE /api/keys`
- [ ] Backend: `GET /api/admins`, `POST /api/admins/invite`

### Phase 4: Danger Zone + Save/Reset + Polish
- [ ] `DangerAction.tsx` + `sections/DangerZoneSection.tsx`
- [ ] Save All → PATCH with dirty fields + toast
- [ ] Reset to Defaults → PUT /api/settings/reset + confirm dialog
- [ ] Toast feedback for all actions
- [ ] Responsive collapse (800px breakpoint)
- [ ] `data-testid` attributes
- [ ] Accessibility (a11y): `role="alert"`, `aria-live`, `htmlFor`+`id`
- [ ] Unsaved changes warning (`beforeunload`)
- [ ] Backend: `PUT /api/settings/reset`

## 8. Type Definitions (from Spec §6)

```ts
type ConnectionStatus = 'healthy' | 'warning' | 'error' | 'unknown';

interface LdapSettings {
  serverUrl: string;
  baseDn: string;
  bindDn: string;
  bindPassword: string;
  userSearchBase: string;
  groupSearchBase: string;
  verifySsl: boolean;
  connectionPooling: boolean;
  status: ConnectionStatus;
}

interface EmailSettings {
  smtpHost: string;
  smtpPort: 25 | 465 | 587;
  username: string;
  password: string;
  fromAddress: string;
  fromName: string;
  useTls: boolean;
}

interface SecuritySettings {
  sessionTimeoutMinutes: 15 | 30 | 60 | 240 | 480;
  maxLoginAttempts: 0 | 3 | 5 | 10;
  requireMfa: boolean;
  ipAllowlist: boolean;
  auditApiRequests: boolean;
}

type RetentionPolicy = '90' | '365' | 'forever';

interface AuditSettings {
  retentionPolicy: RetentionPolicy;
  siemExport: boolean;
  includeUserDetails: boolean;
}

interface ApiKey {
  id: string;
  prefix: string;
  maskedKey: string;
  createdAt: string;
  createdBy: string;
  lastUsedAt: string | null;
}

type AdminRole = 'owner' | 'admin';
type AvatarGradient = 'indigo-purple' | 'blue-cyan' | 'green-teal';

interface Administrator {
  id: string;
  name: string;
  initials: string;
  email: string;
  role: AdminRole;
  avatarGradient: AvatarGradient;
}

interface BrandingSettings {
  companyName: string;
  supportEmail: string;
  qrEmailFooter: string;
  includeLogoInEmails: boolean;
}

interface AllSettings {
  ldap: LdapSettings;
  email: EmailSettings;
  security: SecuritySettings;
  audit: AuditSettings;
  branding: BrandingSettings;
}

type DangerActionId = 'purge-qr' | 'reset-settings';

interface DangerAction {
  id: DangerActionId;
  title: string;
  description: string;
  confirmText: string;
}
```

## 9. Color Map (from Spec §7)

### Status Indicator
| Status | BG | FG | Icon |
|---|---|---|---|
| `healthy` | `bg-green-500/10` | `text-green-500` | Checkmark |
| `warning` | `bg-amber-500/10` | `text-amber-500` | Warning triangle |
| `error` | `bg-red-500/10` | `text-red-500` | X circle |

### Admin Role Badge
| Role | BG | FG |
|---|---|---|
| `owner` | `bg-amber-500/10` | `text-amber-500` |
| `admin` | `bg-blue-500/10` | `text-blue-500` |

### Retention Option (selected vs default)
| State | Border | BG | Radio |
|---|---|---|---|
| `selected` | `border-blue-500` | `bg-blue-500/10` | Blue dot visible |
| `default` | `border-zinc-700` | `transparent` | Dot hidden |

### Danger Zone
| Element | Value |
|---|---|
| Card border | `border-red-500/30` |
| Title | `text-red-500` |
| Button | `bg-red-500/10 text-red-500 border-red-500/30` |

### Test Button (dashed)
| State | Border | FG | BG |
|---|---|---|---|
| Default | `border-dashed border-zinc-600` | `text-zinc-500` | `transparent` |
| Hover | `border-dashed border-blue-500` | `text-blue-500` | `bg-blue-500/10` |

## 10. Estimated Effort

Based on prior migration actuals (users: 12h, groups: 14h) and this being a simpler layout (no split-panel, no RBAC, less relational data):

| Phase | Estimate | Notes |
|-------|----------|-------|
| 0 — Schema + types + 3 primitives | ~2h | 3 primitives is more than usual Phase 0 |
| 1 — Page shell + System Info | ~2h | ScrollSpy is new pattern |
| 2 — LDAP, Email, Security forms | ~3h | Most form-dense phase |
| 3 — Audit, API Keys, Admins, Branding | ~3h | API Keys + Admins have unique UI |
| 4 — Danger Zone + Save/Reset + Polish | ~2h | Danger Zone + responsive + a11y |
| Reviews + fixes | ~2h | Per-phase review discipline |
| **Total** | **~14h** | |

## 11. Risks and Open Questions

- **Backend settings storage vs env vars:** Current LDAP config comes from env vars in `config.py`. The settings page implies these become database-managed. We need a priority chain: database value > env var > default. This is a significant config architecture change.
- **Admin list:** The spec shows admins with avatars/gradients. Currently, the admin concept is just LDAP group membership. We may need to store display preferences (gradient, role label) in Postgres alongside LDAP identity.
- **API key security:** Full key shown only once on generation (spec §3b). Key stored as SHA-256 hash. Prefix stored for display. Standard pattern but needs careful implementation.
- **Settings persistence across deploys:** Docker dev environment resets data with `just reset`. Settings must survive container restarts but may be lost on full reset — acceptable for dev.
