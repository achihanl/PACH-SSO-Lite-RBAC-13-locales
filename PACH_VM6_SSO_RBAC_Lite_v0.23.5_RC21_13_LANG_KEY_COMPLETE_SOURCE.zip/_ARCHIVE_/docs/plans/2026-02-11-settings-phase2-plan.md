# Settings Migration Phase 2: Form Sections + Nav Polish

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build the three form sections (LDAP, Email, Security), polish the nav sidebar into a card panel, add dirty field tracking, and wire settings data loading.

**Architecture:** Each form section is a presentational component receiving its typed settings slice + `onFieldChange` callback. The parent `SettingsManagementPage` owns full `AllSettings` state, dirty tracking, and query integration. Helper components (FormRow, FormGroup, StatusIndicator, TestButton) provide consistent form layout and interaction patterns.

**Tech Stack:** React 19, TypeScript, TanStack Query, @azblink/ui primitives (Input, Select, ToggleRow, Button), Tailwind CSS 4, Lucide icons

---

## Existing Code Context

**Primitives available from `@azblink/ui`:**
- `Input` — `ComponentProps<'input'>` + `hasLeadingIcon?` / `hasTrailingIcon?`
- `Select` — `options: SelectOption[]`, `value?`, `onChange?: (value: string) => void`
- `ToggleRow` — `label`, `description?`, `checked`, `onChange?`, `disabled?`, `name?`
- `Button` — `variant?: ButtonVariant`, `size?: ButtonSize`, `leftIcon?`, `loading?`

**Query helpers in `src/frontend/src/lib/queries/settings.ts`:**
- `settingsQueryOptions()` — `GET /api/settings` → `AllSettings`
- `patchSettings(updates)` — `PATCH /api/settings`
- `testLdapConnection()` — `POST /api/settings/ldap/test`
- `testEmailConnection()` — `POST /api/settings/email/test`

**Types in `src/frontend/src/types/settings.ts`:**
- `LdapSettings` (8 fields + optional `status`)
- `EmailSettings` (7 fields)
- `SecuritySettings` (5 fields)
- `AllSettings` (ldap + email + security + audit + branding)
- `ConnectionStatus` = `'healthy' | 'warning' | 'error' | 'unknown'`

**Current page state (`SettingsManagementPage.tsx`):**
- `useScrollSpy` for nav highlighting
- `SettingsNav` with 9 items (bare `<nav>`, no card wrapper)
- `SystemInfoSection` live, 8 placeholder sections
- Save/Reset buttons disabled
- No data loading, no state management

---

## Task 2.0: Polish SettingsNav Card Wrapper

**Files:**
- Modify: `src/frontend/src/components/features/settings/SettingsNav.tsx`

**Step 1: Wrap nav in card container**

Replace the outer `<nav>` wrapper to match the ListPanel visual pattern (border-subtle, radius-lg, bg-primary, bg-secondary header):

```typescript
/**
 * SettingsNav — 9-item sticky sidebar navigation for settings page.
 * - Card-wrapped with header matching ListPanel visual pattern
 * - IntersectionObserver-driven active section highlighting
 * - Click scrolls to section via useScrollSpy.scrollToSection
 * - Exports SECTION_IDS for reuse across settings components
 */

import {
  Monitor,
  Server,
  Mail,
  Shield,
  ScrollText,
  Key,
  Users,
  Palette,
  AlertTriangle,
  Settings,
} from 'lucide-react';
import type { ComponentType } from 'react';

interface NavItem {
  id: string;
  label: string;
  icon: ComponentType<{ className?: string }>;
}

export const SECTION_IDS = [
  'system-info',
  'ldap',
  'email',
  'security',
  'audit',
  'api-keys',
  'administrators',
  'branding',
  'danger',
] as const;

export type SectionId = (typeof SECTION_IDS)[number];

export const NAV_ITEMS: NavItem[] = [
  { id: 'system-info', label: 'System Info', icon: Monitor },
  { id: 'ldap', label: 'LDAP Connection', icon: Server },
  { id: 'email', label: 'Email / SMTP', icon: Mail },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'audit', label: 'Audit & Logging', icon: ScrollText },
  { id: 'api-keys', label: 'API Keys', icon: Key },
  { id: 'administrators', label: 'Administrators', icon: Users },
  { id: 'branding', label: 'Branding', icon: Palette },
  { id: 'danger', label: 'Danger Zone', icon: AlertTriangle },
];

interface SettingsNavProps {
  activeSection: string;
  onSectionClick: (sectionId: string) => void;
  /** Number of unsaved fields — shown in header when > 0 */
  dirtyCount?: number;
}

export function SettingsNav({ activeSection, onSectionClick, dirtyCount = 0 }: SettingsNavProps) {
  return (
    <nav
      className="sticky top-24 self-start w-60 shrink-0 rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden"
      aria-label="Settings navigation"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--color-border-subtle)] bg-[var(--color-bg-secondary)]">
        <div className="flex items-center gap-2">
          <Settings className="h-4 w-4 text-[var(--color-text-muted)]" />
          <span className="text-sm font-semibold text-text">Settings</span>
        </div>
        {dirtyCount > 0 && (
          <span className="text-xs font-medium text-amber-500">
            {dirtyCount} unsaved
          </span>
        )}
      </div>

      {/* Nav items */}
      <ul className="p-2 space-y-0.5">
        {NAV_ITEMS.map(({ id, label, icon: Icon }) => {
          const isActive = activeSection === id;
          const isDanger = id === 'danger';
          return (
            <li key={id}>
              <button
                type="button"
                onClick={() => onSectionClick(id)}
                className={[
                  'flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-[var(--color-primary-bg)] text-[var(--color-primary)]'
                    : isDanger
                      ? 'text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20'
                      : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-text',
                ]
                  .filter(Boolean)
                  .join(' ')}
                data-section-target={id}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
```

**Step 2: Update SettingsManagementPage to pass dirtyCount**

In `SettingsManagementPage.tsx`, update the `<SettingsNav>` call to pass `dirtyCount={0}` (will be wired to real value in Task 2.6):

```tsx
<SettingsNav
  activeSection={activeSection}
  onSectionClick={scrollToSection}
  dirtyCount={0}
/>
```

**Step 3: Verify in browser**

Visit: `http://localhost:8081/configuration/settings`
Expected: Nav wrapped in bordered card with "Settings" header + gear icon. Items have inner padding. Active item highlighted.

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsNav.tsx src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): polish SettingsNav with card wrapper + dirty count badge (Phase 2)"
```

---

## Task 2.1: FormRow + FormGroup Components

**Files:**
- Create: `src/frontend/src/components/features/settings/FormRow.tsx`
- Create: `src/frontend/src/components/features/settings/FormGroup.tsx`

**Step 1: Write FormRow**

```typescript
/**
 * FormRow — 2-column CSS grid for settings form layout.
 * - Default: 2 equal columns (stacks on mobile)
 * - `full` variant: single column for textarea/full-width fields
 */

import type { ReactNode } from 'react';

interface FormRowProps {
  children: ReactNode;
  /** Single column layout for full-width fields */
  full?: boolean;
}

export function FormRow({ children, full }: FormRowProps) {
  return (
    <div
      className={`grid gap-4 mb-5 last:mb-0 ${full ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'}`}
    >
      {children}
    </div>
  );
}
```

**Step 2: Write FormGroup**

```typescript
/**
 * FormGroup — label + input wrapper with optional hint text.
 * - Pairs with FormRow for 2-column layout
 * - Generates htmlFor + id for a11y label association
 */

import type { ReactNode } from 'react';

interface FormGroupProps {
  /** Field label text */
  label: string;
  /** Show red asterisk */
  required?: boolean;
  /** Help text below the input */
  hint?: string;
  /** HTML id for label-input association */
  htmlFor?: string;
  /** Input/Select/Textarea element */
  children: ReactNode;
}

export function FormGroup({ label, required, hint, htmlFor, children }: FormGroupProps) {
  return (
    <div>
      <label
        htmlFor={htmlFor}
        className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2"
      >
        {label}
        {required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      {children}
      {hint && (
        <p className="text-xs text-[var(--color-text-muted)] mt-1.5">{hint}</p>
      )}
    </div>
  );
}
```

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/settings/FormRow.tsx src/frontend/src/components/features/settings/FormGroup.tsx
git commit -m "feat(settings): FormRow + FormGroup layout components (Phase 2)"
```

---

## Task 2.2: StatusIndicator + TestButton Components

**Files:**
- Create: `src/frontend/src/components/features/settings/StatusIndicator.tsx`
- Create: `src/frontend/src/components/features/settings/TestButton.tsx`

**Step 1: Write StatusIndicator**

```typescript
/**
 * StatusIndicator — colored pill showing connection health status.
 * - healthy: green pill + checkmark
 * - warning: amber pill + alert triangle
 * - error: red pill + X icon
 * - unknown: gray pill + minus icon
 */

import { CheckCircle, AlertTriangle, XCircle, MinusCircle } from 'lucide-react';
import type { ConnectionStatus } from '@/types/settings';

interface StatusIndicatorProps {
  status: ConnectionStatus;
  /** Override default label (e.g., "Connected" instead of "Healthy") */
  label?: string;
}

const STATUS_CONFIG: Record<ConnectionStatus, {
  bg: string;
  text: string;
  icon: typeof CheckCircle;
  defaultLabel: string;
}> = {
  healthy: {
    bg: 'bg-emerald-500/10',
    text: 'text-emerald-500',
    icon: CheckCircle,
    defaultLabel: 'Connected',
  },
  warning: {
    bg: 'bg-amber-500/10',
    text: 'text-amber-500',
    icon: AlertTriangle,
    defaultLabel: 'Warning',
  },
  error: {
    bg: 'bg-red-500/10',
    text: 'text-red-500',
    icon: XCircle,
    defaultLabel: 'Error',
  },
  unknown: {
    bg: 'bg-zinc-500/10',
    text: 'text-zinc-500',
    icon: MinusCircle,
    defaultLabel: 'Unknown',
  },
};

export function StatusIndicator({ status, label }: StatusIndicatorProps) {
  const config = STATUS_CONFIG[status];
  const Icon = config.icon;

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}
      role="status"
    >
      <Icon className="h-3.5 w-3.5" />
      {label ?? config.defaultLabel}
    </span>
  );
}
```

**Step 2: Write TestButton**

```typescript
/**
 * TestButton — dashed-border action button for test-connection and test-email.
 * - Idle: dashed border, muted text
 * - Hover: primary color border/text with subtle bg
 * - Loading: spinner + "Testing..." text, disabled
 */

import { Loader2, Zap } from 'lucide-react';

interface TestButtonProps {
  /** Button label (e.g., "Test Connection", "Send Test Email") */
  label: string;
  /** Click handler */
  onClick: () => void;
  /** Show loading spinner */
  loading?: boolean;
  /** Disable the button */
  disabled?: boolean;
}

export function TestButton({ label, onClick, loading, disabled }: TestButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={loading || disabled}
      className={[
        'inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border border-dashed transition-colors',
        loading || disabled
          ? 'border-[var(--color-border-default)] text-[var(--color-text-muted)] cursor-not-allowed opacity-60'
          : 'border-[var(--color-border-default)] text-[var(--color-text-secondary)] hover:border-[var(--color-primary)] hover:text-[var(--color-primary)] hover:bg-[var(--color-primary-bg)]',
      ].join(' ')}
    >
      {loading ? (
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
      ) : (
        <Zap className="h-3.5 w-3.5" />
      )}
      {loading ? 'Testing...' : label}
    </button>
  );
}
```

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/settings/StatusIndicator.tsx src/frontend/src/components/features/settings/TestButton.tsx
git commit -m "feat(settings): StatusIndicator pill + TestButton components (Phase 2)"
```

---

## Task 2.3: LdapSection

**Files:**
- Create: `src/frontend/src/components/features/settings/sections/LdapSection.tsx`

**Step 1: Write the LDAP section**

```typescript
/**
 * LdapSection — LDAP connection settings form.
 * - 6 text inputs in 3 FormRows (serverUrl, baseDn, bindDn, bindPassword, userSearchBase, groupSearchBase)
 * - 2 ToggleRows (verifySsl, connectionPooling)
 * - Header actions: StatusIndicator + TestButton
 */

import { Input, ToggleRow } from '@azblink/ui';
import type { LdapSettings, ConnectionStatus } from '@/types/settings';
import { SettingsSection } from '../SettingsSection';
import { FormRow } from '../FormRow';
import { FormGroup } from '../FormGroup';
import { StatusIndicator } from '../StatusIndicator';
import { TestButton } from '../TestButton';

interface LdapSectionProps {
  settings: LdapSettings;
  onFieldChange: (key: keyof LdapSettings, value: string | boolean) => void;
  ldapStatus: ConnectionStatus;
  onTestConnection: () => void;
  testingConnection: boolean;
}

export function LdapSection({
  settings,
  onFieldChange,
  ldapStatus,
  onTestConnection,
  testingConnection,
}: LdapSectionProps) {
  return (
    <SettingsSection
      sectionId="ldap"
      title="LDAP Connection"
      description="Configure the LDAP server used for directory authentication and user lookups"
      headerActions={
        <div className="flex items-center gap-3">
          <StatusIndicator status={ldapStatus} />
          <TestButton
            label="Test Connection"
            onClick={onTestConnection}
            loading={testingConnection}
          />
        </div>
      }
    >
      {/* Server + Base DN */}
      <FormRow>
        <FormGroup label="Server URL" htmlFor="ldap-server-url" required>
          <Input
            id="ldap-server-url"
            value={settings.serverUrl}
            onChange={(e) => onFieldChange('serverUrl', e.target.value)}
            placeholder="ldap://ldap.example.com:389"
          />
        </FormGroup>
        <FormGroup label="Base DN" htmlFor="ldap-base-dn" required>
          <Input
            id="ldap-base-dn"
            value={settings.baseDn}
            onChange={(e) => onFieldChange('baseDn', e.target.value)}
            placeholder="dc=example,dc=com"
          />
        </FormGroup>
      </FormRow>

      {/* Bind credentials */}
      <FormRow>
        <FormGroup label="Bind DN" htmlFor="ldap-bind-dn" required>
          <Input
            id="ldap-bind-dn"
            value={settings.bindDn}
            onChange={(e) => onFieldChange('bindDn', e.target.value)}
            placeholder="cn=admin,dc=example,dc=com"
          />
        </FormGroup>
        <FormGroup label="Bind Password" htmlFor="ldap-bind-pw" required>
          <Input
            id="ldap-bind-pw"
            type="password"
            value={settings.bindPassword}
            onChange={(e) => onFieldChange('bindPassword', e.target.value)}
            placeholder="••••••••"
          />
        </FormGroup>
      </FormRow>

      {/* Search bases */}
      <FormRow>
        <FormGroup label="User Search Base" htmlFor="ldap-user-base" hint="Relative to Base DN">
          <Input
            id="ldap-user-base"
            value={settings.userSearchBase}
            onChange={(e) => onFieldChange('userSearchBase', e.target.value)}
            placeholder="ou=people"
          />
        </FormGroup>
        <FormGroup label="Group Search Base" htmlFor="ldap-group-base" hint="Relative to Base DN">
          <Input
            id="ldap-group-base"
            value={settings.groupSearchBase}
            onChange={(e) => onFieldChange('groupSearchBase', e.target.value)}
            placeholder="ou=groups"
          />
        </FormGroup>
      </FormRow>

      {/* Toggles */}
      <div className="mt-6 space-y-0">
        <ToggleRow
          label="Verify SSL Certificates"
          description="Require valid TLS certificates for LDAPS connections"
          checked={settings.verifySsl}
          onChange={(checked) => onFieldChange('verifySsl', checked)}
          name="ldap-verify-ssl"
        />
        <ToggleRow
          label="Connection Pooling"
          description="Reuse LDAP connections for better performance"
          checked={settings.connectionPooling}
          onChange={(checked) => onFieldChange('connectionPooling', checked)}
          name="ldap-connection-pooling"
        />
      </div>
    </SettingsSection>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/sections/LdapSection.tsx
git commit -m "feat(settings): LdapSection with 6 inputs + 2 toggles + test connection (Phase 2)"
```

---

## Task 2.4: EmailSection

**Files:**
- Create: `src/frontend/src/components/features/settings/sections/EmailSection.tsx`

**Step 1: Write the Email section**

```typescript
/**
 * EmailSection — Email/SMTP configuration form.
 * - 5 text inputs + 1 Select (smtpPort) in 3 FormRows
 * - 1 ToggleRow (useTls)
 * - Header action: TestButton for "Send Test Email"
 */

import { Input, Select, ToggleRow } from '@azblink/ui';
import type { EmailSettings } from '@/types/settings';
import { SettingsSection } from '../SettingsSection';
import { FormRow } from '../FormRow';
import { FormGroup } from '../FormGroup';
import { TestButton } from '../TestButton';

const SMTP_PORT_OPTIONS = [
  { value: '25', label: '25 (SMTP)' },
  { value: '465', label: '465 (SMTPS)' },
  { value: '587', label: '587 (Submission)' },
];

interface EmailSectionProps {
  settings: EmailSettings;
  onFieldChange: (key: keyof EmailSettings, value: string | number | boolean) => void;
  onTestEmail: () => void;
  testingEmail: boolean;
}

export function EmailSection({
  settings,
  onFieldChange,
  onTestEmail,
  testingEmail,
}: EmailSectionProps) {
  return (
    <SettingsSection
      sectionId="email"
      title="Email / SMTP"
      description="Configure outgoing email for notifications, QR delivery, and admin invites"
      headerActions={
        <TestButton
          label="Send Test Email"
          onClick={onTestEmail}
          loading={testingEmail}
        />
      }
    >
      {/* Host + Port */}
      <FormRow>
        <FormGroup label="SMTP Host" htmlFor="email-smtp-host" required>
          <Input
            id="email-smtp-host"
            value={settings.smtpHost}
            onChange={(e) => onFieldChange('smtpHost', e.target.value)}
            placeholder="smtp.example.com"
          />
        </FormGroup>
        <FormGroup label="SMTP Port" htmlFor="email-smtp-port">
          <Select
            id="email-smtp-port"
            options={SMTP_PORT_OPTIONS}
            value={String(settings.smtpPort)}
            onChange={(val) => onFieldChange('smtpPort', Number(val))}
          />
        </FormGroup>
      </FormRow>

      {/* Credentials */}
      <FormRow>
        <FormGroup label="Username" htmlFor="email-username">
          <Input
            id="email-username"
            value={settings.username}
            onChange={(e) => onFieldChange('username', e.target.value)}
            placeholder="noreply@example.com"
          />
        </FormGroup>
        <FormGroup label="Password" htmlFor="email-password">
          <Input
            id="email-password"
            type="password"
            value={settings.password}
            onChange={(e) => onFieldChange('password', e.target.value)}
            placeholder="••••••••"
          />
        </FormGroup>
      </FormRow>

      {/* From address/name */}
      <FormRow>
        <FormGroup label="From Address" htmlFor="email-from-addr" required>
          <Input
            id="email-from-addr"
            type="email"
            value={settings.fromAddress}
            onChange={(e) => onFieldChange('fromAddress', e.target.value)}
            placeholder="noreply@example.com"
          />
        </FormGroup>
        <FormGroup label="From Name" htmlFor="email-from-name">
          <Input
            id="email-from-name"
            value={settings.fromName}
            onChange={(e) => onFieldChange('fromName', e.target.value)}
            placeholder="Azblink Directory"
          />
        </FormGroup>
      </FormRow>

      {/* TLS toggle */}
      <div className="mt-6">
        <ToggleRow
          label="Use TLS Encryption"
          description="Encrypt SMTP connections with STARTTLS"
          checked={settings.useTls}
          onChange={(checked) => onFieldChange('useTls', checked)}
          name="email-use-tls"
        />
      </div>
    </SettingsSection>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/sections/EmailSection.tsx
git commit -m "feat(settings): EmailSection with SMTP form + port select + test email (Phase 2)"
```

---

## Task 2.5: SecuritySection

**Files:**
- Create: `src/frontend/src/components/features/settings/sections/SecuritySection.tsx`

**Step 1: Write the Security section**

```typescript
/**
 * SecuritySection — security policy settings.
 * - 2 Select dropdowns (sessionTimeout, maxLoginAttempts)
 * - 3 ToggleRows (requireMfa, ipAllowlist, auditApiRequests)
 */

import { Select, ToggleRow } from '@azblink/ui';
import type { SecuritySettings } from '@/types/settings';
import { SettingsSection } from '../SettingsSection';
import { FormRow } from '../FormRow';
import { FormGroup } from '../FormGroup';

const SESSION_TIMEOUT_OPTIONS = [
  { value: '15', label: '15 minutes' },
  { value: '30', label: '30 minutes' },
  { value: '60', label: '1 hour' },
  { value: '240', label: '4 hours' },
  { value: '480', label: '8 hours' },
];

const MAX_LOGIN_ATTEMPTS_OPTIONS = [
  { value: '0', label: 'Unlimited' },
  { value: '3', label: '3 attempts' },
  { value: '5', label: '5 attempts' },
  { value: '10', label: '10 attempts' },
];

interface SecuritySectionProps {
  settings: SecuritySettings;
  onFieldChange: (key: keyof SecuritySettings, value: number | boolean) => void;
}

export function SecuritySection({ settings, onFieldChange }: SecuritySectionProps) {
  return (
    <SettingsSection
      sectionId="security"
      title="Security"
      description="Session management, login policies, and access controls"
    >
      {/* Selects */}
      <FormRow>
        <FormGroup label="Session Timeout" htmlFor="security-session-timeout">
          <Select
            id="security-session-timeout"
            options={SESSION_TIMEOUT_OPTIONS}
            value={String(settings.sessionTimeoutMinutes)}
            onChange={(val) => onFieldChange('sessionTimeoutMinutes', Number(val))}
          />
        </FormGroup>
        <FormGroup label="Max Login Attempts" htmlFor="security-max-attempts" hint="0 = unlimited">
          <Select
            id="security-max-attempts"
            options={MAX_LOGIN_ATTEMPTS_OPTIONS}
            value={String(settings.maxLoginAttempts)}
            onChange={(val) => onFieldChange('maxLoginAttempts', Number(val))}
          />
        </FormGroup>
      </FormRow>

      {/* Toggles */}
      <div className="mt-6 space-y-0">
        <ToggleRow
          label="Require Multi-Factor Authentication"
          description="Enforce MFA for all administrator accounts"
          checked={settings.requireMfa}
          onChange={(checked) => onFieldChange('requireMfa', checked)}
          name="security-require-mfa"
        />
        <ToggleRow
          label="IP Allowlist"
          description="Restrict admin access to specific IP ranges"
          checked={settings.ipAllowlist}
          onChange={(checked) => onFieldChange('ipAllowlist', checked)}
          name="security-ip-allowlist"
        />
        <ToggleRow
          label="Audit API Requests"
          description="Log all API requests to the audit trail"
          checked={settings.auditApiRequests}
          onChange={(checked) => onFieldChange('auditApiRequests', checked)}
          name="security-audit-api"
        />
      </div>
    </SettingsSection>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/sections/SecuritySection.tsx
git commit -m "feat(settings): SecuritySection with timeout/attempts selects + 3 toggles (Phase 2)"
```

---

## Task 2.6: Wire Sections into Page + Dirty Field Tracking

**Files:**
- Modify: `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`

**Step 1: Add data loading + state management + section wiring**

Replace the entire `SettingsManagementPage.tsx` with:

```typescript
/**
 * SettingsManagementPage — top-level orchestrator for /configuration/settings.
 * - Loads settings via TanStack Query
 * - Local form state with dirty field tracking
 * - Scroll-spy sidebar navigation (240px) + scrollable content (1fr)
 * - URL hash scroll-to on mount
 */

import { useEffect, useState, useCallback } from 'react';
import { useSuspenseQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@azblink/ui';
import { RotateCcw, Save } from 'lucide-react';
import { settingsQueryOptions, testLdapConnection, testEmailConnection } from '@/lib/queries/settings';
import { queryKeys } from '@/lib/queries/keys';
import type { AllSettings, ConnectionStatus } from '@/types/settings';
import { useScrollSpy } from './useScrollSpy';
import { SettingsNav, SECTION_IDS, NAV_ITEMS } from './SettingsNav';
import { SettingsSection } from './SettingsSection';
import { SystemInfoSection } from './sections/SystemInfoSection';
import { LdapSection } from './sections/LdapSection';
import { EmailSection } from './sections/EmailSection';
import { SecuritySection } from './sections/SecuritySection';

export function SettingsManagementPage() {
  const { data: initialSettings } = useSuspenseQuery(settingsQueryOptions());
  const { activeSection, scrollToSection } = useScrollSpy([...SECTION_IDS]);

  // ── Local form state ──────────────────────────────────────────
  const [settings, setSettings] = useState<AllSettings>(initialSettings);
  const [dirtyFields, setDirtyFields] = useState<Set<string>>(new Set());

  // Reset local state when server data changes (after save/reset)
  useEffect(() => {
    setSettings(initialSettings);
    setDirtyFields(new Set());
  }, [initialSettings]);

  /** Update a single field and mark it dirty */
  const updateField = useCallback((section: string, key: string, value: unknown) => {
    setSettings((prev) => ({
      ...prev,
      [section]: { ...prev[section as keyof AllSettings], [key]: value },
    }));
    setDirtyFields((prev) => new Set(prev).add(`${section}.${key}`));
  }, []);

  // ── Connection test state ─────────────────────────────────────
  const [ldapStatus, setLdapStatus] = useState<ConnectionStatus>('unknown');
  const [testingLdap, setTestingLdap] = useState(false);
  const [testingEmail, setTestingEmail] = useState(false);

  const handleTestLdap = useCallback(async () => {
    setTestingLdap(true);
    try {
      const result = await testLdapConnection();
      setLdapStatus(result.status === 'healthy' ? 'healthy' : 'error');
    } catch {
      setLdapStatus('error');
    } finally {
      setTestingLdap(false);
    }
  }, []);

  const handleTestEmail = useCallback(async () => {
    setTestingEmail(true);
    try {
      await testEmailConnection();
    } catch {
      // Email test result shown via toast in Phase 4
    } finally {
      setTestingEmail(false);
    }
  }, []);

  // ── URL hash scroll-to on mount ───────────────────────────────
  useEffect(() => {
    const hash = window.location.hash.replace('#', '');
    if (hash && (SECTION_IDS as readonly string[]).includes(hash)) {
      setTimeout(() => scrollToSection(hash), 100);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const hasDirtyFields = dirtyFields.size > 0;

  // Placeholder sections still needed for Phase 3-4
  const remainingPlaceholders = NAV_ITEMS.filter(
    (item) => !['system-info', 'ldap', 'email', 'security'].includes(item.id),
  );

  return (
    <div className="max-w-[1200px] space-y-6">
      {/* Page header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-text">Settings</h1>
          <p className="text-sm text-text-secondary mt-1">
            Manage system configuration, security, and integrations
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            disabled
            leftIcon={<RotateCcw className="h-4 w-4" />}
          >
            Reset to Defaults
          </Button>
          <Button
            size="sm"
            disabled={!hasDirtyFields}
            leftIcon={<Save className="h-4 w-4" />}
          >
            Save All Changes
          </Button>
        </div>
      </div>

      {/* Layout: sidebar nav + content */}
      <div className="grid grid-cols-[240px_1fr] gap-8">
        <SettingsNav
          activeSection={activeSection}
          onSectionClick={scrollToSection}
          dirtyCount={dirtyFields.size}
        />

        {/* Scrollable content */}
        <div className="space-y-8 min-w-0">
          <SystemInfoSection />

          <LdapSection
            settings={settings.ldap}
            onFieldChange={(key, value) => updateField('ldap', key, value)}
            ldapStatus={ldapStatus}
            onTestConnection={handleTestLdap}
            testingConnection={testingLdap}
          />

          <EmailSection
            settings={settings.email}
            onFieldChange={(key, value) => updateField('email', key, value)}
            onTestEmail={handleTestEmail}
            testingEmail={testingEmail}
          />

          <SecuritySection
            settings={settings.security}
            onFieldChange={(key, value) => updateField('security', key, value)}
          />

          {/* Placeholder sections for Phase 3-4 */}
          {remainingPlaceholders.map((item) => (
            <SettingsSection
              key={item.id}
              sectionId={item.id}
              title={item.label}
              description={`${item.label} configuration — coming in Phase 3-4`}
              danger={item.id === 'danger'}
            >
              <p className="text-sm text-text-secondary italic">
                This section will be implemented in a future phase.
              </p>
            </SettingsSection>
          ))}
        </div>
      </div>
    </div>
  );
}
```

**Step 2: Verify in browser**

Visit: `http://localhost:8081/configuration/settings`
Expected:
- Settings data loads from API (inputs populated with defaults or saved values)
- Changing any field enables "Save All Changes" button
- Nav shows dirty count (e.g., "2 unsaved")
- LDAP Test Connection button fires request, shows spinner, updates status pill
- Scroll-spy highlights correct nav item

**Step 3: Run TypeScript check**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No new errors in settings files

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): wire LDAP/Email/Security sections + dirty field tracking (Phase 2)"
```

---

## Task 2.7: Phase 2 Review

**Step 1: Visual checklist**
- [ ] SettingsNav wrapped in bordered card with "Settings" header
- [ ] Nav shows dirty count badge when fields are modified
- [ ] LDAP section: 6 inputs, 2 toggles, StatusIndicator pill, TestButton
- [ ] Email section: 5 inputs, 1 port Select, 1 toggle, TestButton
- [ ] Security section: 2 Selects (timeout, attempts), 3 toggles
- [ ] FormRow grid: 2 columns on desktop, stacked on mobile
- [ ] Dirty tracking: modify a field → "Save All" button enables, nav shows count
- [ ] Scroll-spy: scroll through sections → nav highlights correct item
- [ ] Test Connection: click → spinner → status pill updates
- [ ] Remaining 5 sections still show as placeholders

**Step 2: Run TypeScript check**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No errors in settings files

**Step 3: Run backend tests**

Run: `pytest tests/test_settings.py -v --tb=short`
Expected: All 13 tests pass (no backend changes in Phase 2)

**Step 4: Dispatch code quality reviewer**

Review all Phase 2 files for:
- Unused imports
- Inconsistent token usage (hardcoded colors vs. `var(--color-*)`)
- Missing a11y attributes (htmlFor/id pairing, aria-labels)
- Type safety (`onFieldChange` key types match settings interfaces)
- DRY violations across the 3 section components

**Step 5: Phase commit (if needed)**

```bash
git add -A
git commit -m "fix(settings): Phase 2 review fixes"
```
