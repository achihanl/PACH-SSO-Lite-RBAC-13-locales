# UED Sync API Integration Design

> AZBlink Directory → UED Sync API for XMPP/SIP provisioning in per-tenant LDAP servers.

**Date:** 2026-02-13
**Status:** Draft
**Depends on:** [azb-ldap-integration](../../../azb-ldap-integration/) (UED Sync API v0.3.0)

---

## Purpose

When user lifecycle events occur in AZBlink Directory (create, update, suspend, unsuspend, terminate, password change), propagate those changes asynchronously to per-tenant UED Sync API instances. Each UED instance provisions XMPP and SIP accounts in its own dedicated OpenLDAP server.

**AZBlink Directory** = identity directory of record (inetOrgPerson in its own OpenLDAP).
**UED Sync API** = UC provisioner (AsteriskSIPUser + XMPP objectClasses in tenant-specific OpenLDAP).

Two distinct LDAP servers with different schemas. AZBlink owns the identity; UED owns the UC accounts.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│  AZBlink Directory                                               │
│                                                                  │
│  ┌────────────┐    ┌──────────────┐    ┌──────────────────────┐  │
│  │ main.py    │───▶│ sync_events  │◀───│ SyncWorker           │  │
│  │ (API routes│    │ (PostgreSQL) │    │ (asyncio background  │  │
│  │  emit      │    │              │    │  task in FastAPI)     │  │
│  │  events)   │    └──────────────┘    └──────────┬───────────┘  │
│  └────────────┘                                   │              │
│                    ┌──────────────┐                │              │
│                    │ tenant_ldap  │────────────────┘              │
│                    │ _configs     │  (fetch config per tenant)    │
│                    │ (PostgreSQL) │                               │
│                    └──────────────┘                               │
└───────────────────────────────────────┬──────────────────────────┘
                                        │ HTTPS + Bearer API Key
                    ┌───────────────────┼───────────────────┐
                    ▼                   ▼                   ▼
            ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
            │ UED Sync API │  │ UED Sync API │  │ UED Sync API │
            │ (Tenant A)   │  │ (Tenant B)   │  │ (Tenant N)   │
            └──────┬───────┘  └──────┬───────┘  └──────┬───────┘
                   ▼                 ▼                  ▼
            [Tenant A LDAP]   [Tenant B LDAP]   [Tenant N LDAP]
```

### Flow

1. Admin action in AZBlink (create user, suspend, etc.) writes to AZBlink's own LDAP
2. API route emits a `sync_event` row in PostgreSQL with event type + payload
3. `SyncWorker` (background asyncio task) polls for pending events
4. Worker fetches tenant config from `tenant_ldap_configs`, builds UED request
5. Worker calls UED Sync API with `LdapConfig` + `ProvisioningSchema` + user data
6. UED executes the LDAP operation against the tenant's UC LDAP
7. Worker marks event `completed` or schedules retry on failure

### Key Properties

- **UED instances are stateless** — all config comes from AZBlink per-request
- **Identical UED Docker images** everywhere — no per-tenant configuration baked in
- **AZBlink is single source of truth** for tenant LDAP configs
- **Zero behavior change** for deployments without UED — feature is opt-in via `tenant_ldap_configs` rows

---

## Deployment Model

- **One UED Sync API instance per tenant** (dedicated)
- **AZBlink forwards LDAP connection details** with each sync request (UED multi-tenant mode)
- **Authentication:** Shared API key per tenant (Bearer token via `X-API-Key` header)

---

## Sync Event Scope

| Event | UED Action | UED Endpoint |
|-------|-----------|--------------|
| `user_created` | Create XMPP + SIP accounts | `POST /api/v1/sync/user` (operation: create) |
| `user_updated` | Update UC attributes | `POST /api/v1/sync/user` (operation: update) |
| `user_suspended` | Suspend UC accounts | `POST /api/v1/sync/user/suspend` (operation: suspend) |
| `user_unsuspended` | Re-enable UC accounts | `POST /api/v1/sync/user/suspend` (operation: unsuspend) |
| `user_terminated` | Delete/disable UC accounts | `POST /api/v1/sync/user` (operation: delete) |
| `password_changed` | Sync password to UC LDAP | `POST /api/v1/sync/user/password` |

**Deferred:** Org moves (not relevant to UC provisioning).

---

## Data Model

### Table: `tenant_ldap_configs`

```sql
CREATE TABLE tenant_ldap_configs (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id        TEXT NOT NULL,
    name             TEXT NOT NULL,
    ued_api_url      TEXT NOT NULL,
    ued_api_key_enc  TEXT NOT NULL,
    ldap_uri         TEXT NOT NULL,
    ldap_base_dn     TEXT NOT NULL,
    ldap_bind_dn     TEXT NOT NULL,
    ldap_bind_pw_enc TEXT NOT NULL,
    ldap_use_ssl     BOOLEAN NOT NULL DEFAULT TRUE,
    ldap_timeout_ms  INTEGER NOT NULL DEFAULT 5000,
    schema_config    JSONB NOT NULL,
    enabled          BOOLEAN NOT NULL DEFAULT TRUE,
    last_sync_at     TIMESTAMPTZ,
    last_error       TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id)
);
```

- `schema_config` stores UED's `ProvisioningSchema` JSON directly (no translation)
- `ued_api_key_enc` and `ldap_bind_pw_enc` are Fernet-encrypted
- `UNIQUE (tenant_id)` — one UED config per tenant

### Table: `sync_events`

```sql
CREATE TABLE sync_events (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id     TEXT NOT NULL REFERENCES tenant_ldap_configs(tenant_id) ON DELETE CASCADE,
    user_uid      TEXT NOT NULL,
    event_type    TEXT NOT NULL,
    payload       JSONB NOT NULL,
    status        TEXT NOT NULL DEFAULT 'pending',
    attempts      INTEGER NOT NULL DEFAULT 0,
    max_attempts  INTEGER NOT NULL DEFAULT 10,
    next_retry_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_error    TEXT,
    request_id    UUID DEFAULT gen_random_uuid(),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at  TIMESTAMPTZ,

    CONSTRAINT valid_status CHECK (status IN ('pending','in_progress','completed','failed'))
);

CREATE INDEX idx_sync_events_pending
    ON sync_events (next_retry_at)
    WHERE status IN ('pending', 'in_progress');

CREATE INDEX idx_sync_events_user_ordering
    ON sync_events (tenant_id, user_uid, created_at)
    WHERE status IN ('pending', 'in_progress');

CREATE INDEX idx_sync_events_completed
    ON sync_events (completed_at)
    WHERE status = 'completed';

CREATE INDEX idx_sync_events_failed
    ON sync_events (created_at DESC)
    WHERE status = 'failed';
```

### Payload Examples

```jsonc
// user_created
{
  "user": {"uid": "j.doe", "cn": "Jane Doe", "mail": "jane@acme.com"},
  "password": "<fernet-encrypted>"
}

// user_updated
{
  "user": {"uid": "j.doe", "dn": "uid=j.doe,ou=people,dc=acme,dc=com"},
  "changes": {"cn": "Jane Smith", "mail": "jane.smith@acme.com"}
}

// user_suspended / user_unsuspended
{
  "user": {"uid": "j.doe", "dn": "uid=j.doe,ou=people,dc=acme,dc=com"}
}

// password_changed
{
  "user": {"uid": "j.doe", "dn": "uid=j.doe,ou=people,dc=acme,dc=com"},
  "new_password": "<fernet-encrypted>"
}
```

Password fields within payloads are Fernet-encrypted individually (rest of payload stays inspectable for debugging).

---

## Encryption Module

### Module: `src/backend/ued_crypto.py`

```python
def encrypt_value(plaintext: str) -> str
def decrypt_value(ciphertext: str) -> str
def encrypt_payload_password(payload: dict) -> dict
def decrypt_payload_password(payload: dict) -> dict
```

- **Key:** `UED_ENCRYPTION_KEY` env var (Fernet-compatible base64 key)
- **Generate:** `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`
- **Startup validation:** If `tenant_ldap_configs` has rows but key is unset → fatal error
- **No UED configs → key is optional** (zero impact for non-UED deployments)
- **Key rotation:** Out of scope for v1

### Where Encryption Happens

| Operation | Encrypt | Decrypt |
|-----------|---------|---------|
| Save tenant config | `POST/PATCH /api/ued/configs` | — |
| Worker fetches config | — | `SyncWorker` at request time |
| Emit `password_changed` event | `emit_sync_event()` | `SyncWorker` at request time |
| API response display | — | Never (redacted as `"••••••••"`) |

---

## Sync Worker

### Lifecycle

Runs as a background `asyncio.Task` started during FastAPI `lifespan`:

```python
async def lifespan(app: FastAPI):
    worker = SyncWorker(poll_interval=5.0)
    task = asyncio.create_task(worker.run())
    yield
    worker.stop()
    await task
```

### Processing Loop

1. `SELECT DISTINCT (tenant_id, user_uid)` from `sync_events` where `status = 'pending'` and `next_retry_at <= now()`, ordered by `created_at ASC`
2. For each `(tenant_id, user_uid)` pair:
   - Select oldest pending event
   - Set `status = 'in_progress'`
   - Fetch tenant config, decrypt secrets
   - Build UED request (`LdapConfig` + `ProvisioningSchema` + payload)
   - POST to UED Sync API
   - **Success:** Set `status = 'completed'`, `completed_at = now()`, update `tenant.last_sync_at`
   - **Failure:** Increment `attempts`. If `>= max_attempts` → `status = 'failed'`. Else → compute `next_retry_at`, set `status = 'pending'`.
3. Sleep `poll_interval` (5 seconds)

### Per-User Ordering Guarantee

For a given `(tenant_id, user_uid)`, only one event processes at a time, in `created_at` order. If the oldest event is `in_progress` or `failed`, newer events for that user are blocked until resolved.

### Backoff Schedule

```
Attempt 0:     5 seconds
Attempt 1:    15 seconds
Attempt 2:    45 seconds
Attempt 3:  ~2.3 minutes  (135s)
Attempt 4:  ~6.8 minutes  (405s)
Attempt 5:  ~20 minutes   (1215s)
Attempt 6+:  1 hour (capped at 3600s)
```

Formula: `min(5 * 3^attempt, 3600)` seconds

### Retention Pruning

Secondary periodic task (runs once per hour):

```sql
DELETE FROM sync_events
WHERE status = 'completed'
  AND completed_at < now() - interval '{retention_days} days';
```

- Default: **90 days** (configurable via `app_settings`)
- **Failed events:** Kept indefinitely until manually resolved
- **Pruning changes** logged to audit trail

---

## Event Emission

### Pattern

Events are emitted **after** AZBlink's own LDAP write succeeds, **before** the HTTP response returns:

```python
async def emit_sync_event(
    tenant_id: str,
    user_uid: str,
    event_type: str,
    payload: dict,
) -> None:
    config = await orgdb.get_tenant_ldap_config(tenant_id)
    if not config or not config.enabled:
        return  # No-op — no UED configured
    await orgdb.insert_sync_event(tenant_id, user_uid, event_type, payload)
```

### Integration Points

| Route | Event |
|-------|-------|
| `POST /api/users/create` | `user_created` |
| `PATCH /api/users/{uid}` | `user_updated` |
| `POST /api/users/{uid}/suspend` | `user_suspended` |
| `POST /api/users/{uid}/unsuspend` | `user_unsuspended` |
| `POST /api/users/{uid}/terminate` | `user_terminated` |
| `POST /api/users/{uid}/reset_password` | `password_changed` |

### Failure Isolation

- If AZBlink LDAP write fails → no sync event emitted (correct)
- If sync event INSERT fails (DB down) → API still returns success for LDAP operation, logs warning
- UED failures are handled asynchronously by the worker — never block the admin API

---

## UED Admin API Endpoints

Admin-only endpoints for managing UED integration:

| Method | Path | Purpose |
|--------|------|---------|
| `GET` | `/api/ued/configs` | List tenant configs (secrets redacted) |
| `POST` | `/api/ued/configs` | Create tenant config |
| `PATCH` | `/api/ued/configs/{id}` | Update config |
| `DELETE` | `/api/ued/configs/{id}` | Remove tenant config |
| `POST` | `/api/ued/configs/{id}/test` | Test UED + LDAP connectivity |
| `GET` | `/api/ued/sync-events` | List sync events (filterable) |
| `POST` | `/api/ued/sync-events/{id}/retry` | Retry a failed event |
| `POST` | `/api/ued/sync-events/retry-all-failed` | Retry all failed events |

### Test Connectivity (`POST /api/ued/configs/{id}/test`)

1. **UED health:** `GET {ued_api_url}/health` with API key
2. **LDAP bind:** Call UED's `POST /api/v1/sync/auth/validate` with dummy search

Returns: `{ ued_reachable: true, ldap_bind_ok: true, errors: [] }`

---

## Implementation Plan

### New Files

| File | Purpose |
|------|---------|
| `src/backend/ued_crypto.py` | Fernet encrypt/decrypt module |
| `src/backend/ued_sync_client.py` | HTTP client wrapping UED Sync API |
| `src/backend/sync_worker.py` | Background asyncio worker |
| `migrations/010_ued_sync.sql` | Schema migration |
| `tests/test_ued_sync.py` | Integration tests |

### Modified Files

| File | Changes |
|------|---------|
| `src/backend/config.py` | Add `UED_ENCRYPTION_KEY` (optional) |
| `src/backend/orgdb.py` | CRUD for `tenant_ldap_configs` + `sync_events` |
| `src/backend/main.py` | `emit_sync_event()` in 6 routes + UED admin endpoints + worker lifespan |
| `src/backend/requirements.txt` | Add `cryptography`, `httpx` |
| `deploy/dev/.env.example` | Add `UED_ENCRYPTION_KEY` |

### Unchanged Files

- `ldap_client.py` — AZBlink's own LDAP operations untouched
- `auth.py` — Authentication unaffected
- `qr_signing.py` — QR provisioning independent
- Frontend — No UI changes (API-only in this phase)

### Build Order

```
1. migrations/010_ued_sync.sql        — Tables first
2. src/backend/ued_crypto.py          — Encryption (standalone, testable)
3. src/backend/config.py              — UED_ENCRYPTION_KEY env var
4. src/backend/orgdb.py               — CRUD for new tables
5. src/backend/ued_sync_client.py     — UED HTTP client
6. src/backend/sync_worker.py         — Background worker
7. src/backend/main.py                — Wire: lifespan + emit calls + admin endpoints
8. tests/test_ued_sync.py             — Integration tests
9. deploy/dev/.env.example            — Document env vars
```

---

## Out of Scope

| Item | Notes |
|------|-------|
| Frontend dashboard | Sync status UI, tenant config management |
| Encryption key rotation | Re-encrypt all stored values |
| Temporal/external worker | Extract worker to separate process |
| Batch initial sync | Seed existing users to new UED instance |
| Multi-UED per tenant | Drop `UNIQUE(tenant_id)` constraint |
| UED schema translation | Adapter layer if formats diverge |

---

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `cryptography` | latest | Fernet symmetric encryption |
| `httpx` | latest | Async HTTP client for UED calls |
