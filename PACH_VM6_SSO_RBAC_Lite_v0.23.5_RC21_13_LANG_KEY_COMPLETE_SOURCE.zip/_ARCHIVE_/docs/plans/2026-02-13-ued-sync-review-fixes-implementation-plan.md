# UED Sync Review Fixes — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Address 9 code review suggestions (S1-S8, C2) to improve test quality, type safety, performance, and documentation in the UED sync integration.

**Architecture:** All changes are surgical fixes to existing files. No new files created. Changes span backend source (3 files), test files (4 files), and one design doc. TDD applies to S3 and S5 (new test code). Other tasks are direct fixes verified by existing tests.

**Tech Stack:** Python 3.12, FastAPI, SQLAlchemy Core, httpx, pytest, cryptography (Fernet)

---

### Task 1: Add clarifying comment on PATCH update filter (S7)

**Files:**
- Modify: `src/backend/main.py:3120`

**Step 1: Add the comment**

Add this comment on the line immediately before line 3120:

```python
    # Filter out None (unset) fields; False/0/"" are valid updates and pass through
    updates = {k: v for k, v in req.model_dump().items() if v is not None}
```

**Step 2: Verify existing tests still pass**

Run: `pytest tests/test_ued_api.py -v --tb=short`
Expected: All pass (no behavior change)

**Step 3: Commit**

```bash
git add src/backend/main.py
git commit -m "fix(S7): add clarifying comment on PATCH update None-filter"
```

---

### Task 2: Update design doc with ON DELETE CASCADE (S8)

**Files:**
- Modify: `docs/plans/2026-02-13-ued-sync-integration-design.md:129`

**Step 1: Fix the SQL example**

Change line 129 from:
```sql
    tenant_id     TEXT NOT NULL REFERENCES tenant_ldap_configs(tenant_id),
```
To:
```sql
    tenant_id     TEXT NOT NULL REFERENCES tenant_ldap_configs(tenant_id) ON DELETE CASCADE,
```

**Step 2: Commit**

```bash
git add docs/plans/2026-02-13-ued-sync-integration-design.md
git commit -m "docs(S8): add ON DELETE CASCADE to design doc SQL example"
```

---

### Task 3: Remove dead code from test_ued_sync_client.py (S2)

**Files:**
- Modify: `tests/test_ued_sync_client.py:1-21`

**Step 1: Remove unused imports and dead helper**

Replace the imports section (lines 4-20) — remove `AsyncMock`, `patch`, `asyncio` imports and the `run_async` function. Keep only what's actually used:

```python
import os
import sys
from pathlib import Path

_backend_path = Path(__file__).parent.parent / "src" / "backend"
if str(_backend_path) not in sys.path:
    sys.path.insert(0, str(_backend_path))

import pytest
import httpx
```

Remove the empty `run_async` function entirely (lines 18-20).

**Step 2: Verify existing tests still pass**

Run: `pytest tests/test_ued_sync_client.py -v --tb=short`
Expected: 4 tests pass (test_build_create_request, test_build_suspend_request, test_build_password_request, test_event_type_to_endpoint_mapping)

**Step 3: Commit**

```bash
git add tests/test_ued_sync_client.py
git commit -m "fix(S2): remove dead run_async helper and unused imports"
```

---

### Task 4: Replace deprecated asyncio.get_event_loop() in tests (S1)

**Files:**
- Modify: `tests/test_sync_worker.py:91,111,131`

**Step 1: Replace all three occurrences**

In `tests/test_sync_worker.py`, replace each occurrence of:
```python
            asyncio.get_event_loop().run_until_complete(
                worker._process_event(sample_event)
            )
```
With:
```python
            asyncio.run(
                worker._process_event(sample_event)
            )
```

Three locations:
- `test_successful_sync` (line 91)
- `test_failed_sync_retries` (line 111)
- `test_disabled_tenant_skipped` (line 131)

**Step 2: Verify tests pass**

Run: `pytest tests/test_sync_worker.py -v --tb=short`
Expected: 7 tests pass (4 backoff + 3 process_event)

**Step 3: Commit**

```bash
git add tests/test_sync_worker.py
git commit -m "fix(S1): replace deprecated asyncio.get_event_loop() with asyncio.run()"
```

---

### Task 5: Fix request_id column type mismatch (S4)

**Files:**
- Modify: `src/backend/orgdb.py:46,295`

**Step 1: Add UUID to the postgresql dialect import**

Change line 46 from:
```python
from sqlalchemy.dialects.postgresql import insert as pg_insert, JSONB
```
To:
```python
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, insert as pg_insert, JSONB
```

**Step 2: Change the column type**

Change line 295 from:
```python
    Column("request_id", String(36), nullable=True),
```
To:
```python
    Column("request_id", PG_UUID(as_uuid=False), nullable=True),
```

**Step 3: Verify tests pass**

Run: `pytest tests/test_ued_orgdb.py -v --tb=short`
Expected: All pass (runtime behavior unchanged — `str(uuid4())` is valid for PostgreSQL UUID)

**Step 4: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "fix(S4): use PostgreSQL UUID type for request_id column (match migration)"
```

---

### Task 6: Cache Fernet instance (C2)

**Files:**
- Modify: `src/backend/ued_crypto.py:15-23`

**Step 1: Rewrite `_get_fernet()` with caching**

Replace the function (lines 15-23) with:

```python
_fernet_cache: Fernet | None = None
_fernet_key_cache: str = ""


def _get_fernet() -> Fernet:
    """Get Fernet instance from UED_ENCRYPTION_KEY env var.

    - Caches instance at module level for performance (2-3 calls per sync event)
    - Auto-invalidates when env var changes (safe for tests using monkeypatch)
    """
    global _fernet_cache, _fernet_key_cache
    key = os.getenv("UED_ENCRYPTION_KEY", "")
    if not key:
        raise RuntimeError(
            "UED_ENCRYPTION_KEY not set. Required for UED sync integration. "
            "Generate with: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
        )
    if key != _fernet_key_cache:
        _fernet_cache = Fernet(key.encode())
        _fernet_key_cache = key
    return _fernet_cache
```

**Step 2: Verify existing crypto tests pass**

Run: `pytest tests/ -k "ued_crypto or ued_orgdb or ued_api" -v --tb=short`
Expected: All pass. The `test_missing_key_raises` test works because `monkeypatch.delenv` changes the env var, causing the cache to invalidate.

**Step 3: Commit**

```bash
git add src/backend/ued_crypto.py
git commit -m "perf(C2): cache Fernet instance in _get_fernet() with auto-invalidation"
```

---

### Task 7: Add offset parameter to sync-events pagination (S5)

**Files:**
- Modify: `src/backend/orgdb.py` — `list_sync_events()` method
- Modify: `src/backend/main.py:3165-3174` — endpoint signature
- Test: `tests/test_ued_orgdb.py` — new test

**Step 1: Write the failing test**

Add to `tests/test_ued_orgdb.py` at the end of `TestSyncEventCRUD`:

```python
    def test_list_sync_events_with_offset(self, orgdb):
        """Verify offset pagination returns correct slice."""
        self._create_tenant(orgdb)
        # Insert 5 events with distinct user_uids
        for i in range(5):
            orgdb.insert_sync_event("sync-tenant", f"offset-user-{i}", "user_created",
                                    {"user": {"uid": f"offset-user-{i}"}})
        # list_sync_events orders by created_at DESC, so newest first
        all_events = orgdb.list_sync_events(tenant_id="sync-tenant")
        assert len(all_events) == 5

        # offset=2, limit=2 should skip the 2 newest and return the next 2
        page = orgdb.list_sync_events(tenant_id="sync-tenant", offset=2, limit=2)
        assert len(page) == 2
        assert page[0]["user_uid"] == all_events[2]["user_uid"]
        assert page[1]["user_uid"] == all_events[3]["user_uid"]
```

**Step 2: Run test to verify it fails**

Run: `pytest tests/test_ued_orgdb.py::TestSyncEventCRUD::test_list_sync_events_with_offset -v --tb=short`
Expected: FAIL — `list_sync_events()` does not accept `offset` parameter

**Step 3: Add offset to OrgDB.list_sync_events()**

In `src/backend/orgdb.py`, modify the `list_sync_events` method (line 2529). Change the signature and add `.offset()`:

```python
    def list_sync_events(self, *, tenant_id: str | None = None,
                         status: str | None = None, user_uid: str | None = None,
                         limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
        """List sync events with optional filters and pagination."""
        eng = self.connect()
        stmt = select(sync_events).order_by(sync_events.c.created_at.desc()).offset(offset).limit(limit)
```

(Rest of method body unchanged.)

**Step 4: Add offset to the API endpoint**

In `src/backend/main.py`, modify `api_ued_sync_events_list` (line 3165):

```python
@app.get("/api/ued/sync-events")
def api_ued_sync_events_list(
    status: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """List sync events with optional filters."""
    return ORGDB.list_sync_events(tenant_id=tenant_id, status=status, user_uid=user_uid, limit=limit, offset=offset)
```

**Step 5: Run test to verify it passes**

Run: `pytest tests/test_ued_orgdb.py::TestSyncEventCRUD::test_list_sync_events_with_offset -v --tb=short`
Expected: PASS

**Step 6: Run all UED tests to verify no regressions**

Run: `pytest tests/test_ued_orgdb.py tests/test_ued_api.py -v --tb=short`
Expected: All pass

**Step 7: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_ued_orgdb.py
git commit -m "feat(S5): add offset parameter to sync-events list endpoint for pagination"
```

---

### Task 8: Rename weak auth test (S6)

**Files:**
- Modify: `tests/test_ued_api.py:135-141`

**Step 1: Rename and fix the test**

Replace `test_requires_auth` (lines 135-141) with:

```python
    def test_endpoint_accessible(self, client):
        """Verify the UED configs endpoint exists and responds.
        Auth enforcement is handled by the require_admin middleware,
        not per-endpoint — in dev mode (REQUIRE_OIDC_AUTH=false) all
        requests pass through without credentials."""
        resp = client.get("/api/ued/configs")
        assert resp.status_code == 200
```

**Step 2: Verify test passes**

Run: `pytest tests/test_ued_api.py::TestTenantConfigAPI::test_endpoint_accessible -v --tb=short`
Expected: PASS

**Step 3: Commit**

```bash
git add tests/test_ued_api.py
git commit -m "fix(S6): rename test_requires_auth to test_endpoint_accessible with honest assertion"
```

---

### Task 9: Add unit tests for UedSyncClient.send() (S3)

**Files:**
- Modify: `tests/test_ued_sync_client.py` — add new test class

**Step 1: Write the 5 send() tests**

Add after the existing `TestUedSyncClient` class in `tests/test_ued_sync_client.py`:

```python
import asyncio
from unittest.mock import AsyncMock, patch, MagicMock


class TestUedSyncClientSend:
    """Tests for UedSyncClient.send() — HTTP call, error handling, response parsing."""

    SEND_KWARGS = {
        "ued_api_url": "https://ued-test:8000",
        "ued_api_key": "test-key",
        "event_type": "user_created",
        "payload": {"user": {"uid": "j.doe", "cn": "Jane"}, "password": "secret"},
        "schema_config": {
            "dn_template": "uid={uid},ou=people,{base_dn}",
            "object_classes": ["top"],
            "attribute_map": {"uid": "{uid}"},
            "required_fields": ["uid"],
            "optional_fields": [],
            "password_attribute": "userPassword",
            "password_hash": "SSHA",
        },
        "ldap_config": {
            "uri": "ldap://test:389",
            "base_dn": "dc=test,dc=com",
            "bind_dn": "cn=admin,dc=test,dc=com",
            "bind_pw": "adminpw",
            "use_ssl": False,
            "timeout_ms": 5000,
        },
        "request_id": "req-send-test",
    }

    def test_send_timeout(self):
        """Timeout -> SyncResult(ok=False, error_code='TIMEOUT', retryable=True)."""
        from ued_sync_client import UedSyncClient

        mock_resp = None  # won't be reached
        async def mock_post(*args, **kwargs):
            raise httpx.TimeoutException("timed out")

        client = UedSyncClient(timeout=1.0)
        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.post = mock_post
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = asyncio.run(client.send(**self.SEND_KWARGS))

        assert result.ok is False
        assert result.error_code == "TIMEOUT"
        assert result.retryable is True

    def test_send_connection_error(self):
        """Connection refused -> SyncResult(ok=False, error_code='CONNECTION_ERROR', retryable=True)."""
        from ued_sync_client import UedSyncClient

        async def mock_post(*args, **kwargs):
            raise httpx.ConnectError("Connection refused")

        client = UedSyncClient(timeout=1.0)
        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.post = mock_post
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = asyncio.run(client.send(**self.SEND_KWARGS))

        assert result.ok is False
        assert result.error_code == "CONNECTION_ERROR"
        assert result.retryable is True

    def test_send_server_error_500(self):
        """HTTP 500 -> retryable=True."""
        from ued_sync_client import UedSyncClient

        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"

        async def mock_post(*args, **kwargs):
            return mock_response

        client = UedSyncClient(timeout=1.0)
        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.post = mock_post
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = asyncio.run(client.send(**self.SEND_KWARGS))

        assert result.ok is False
        assert result.status_code == 500
        assert result.error_code == "HTTP_500"
        assert result.retryable is True

    def test_send_200_ok_false(self):
        """HTTP 200 with ok:false -> extract error fields."""
        from ued_sync_client import UedSyncClient

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "ok": False,
            "request_id": "req-send-test",
            "error": {"code": "LDAP_BIND_FAILED", "message": "Invalid credentials", "retryable": False},
        }

        async def mock_post(*args, **kwargs):
            return mock_response

        client = UedSyncClient(timeout=1.0)
        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.post = mock_post
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = asyncio.run(client.send(**self.SEND_KWARGS))

        assert result.ok is False
        assert result.status_code == 200
        assert result.error_code == "LDAP_BIND_FAILED"
        assert result.error_message == "Invalid credentials"
        assert result.retryable is False

    def test_send_200_ok_true(self):
        """HTTP 200 with ok:true -> success."""
        from ued_sync_client import UedSyncClient

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "ok": True,
            "request_id": "req-send-test",
        }

        async def mock_post(*args, **kwargs):
            return mock_response

        client = UedSyncClient(timeout=1.0)
        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.post = mock_post
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = asyncio.run(client.send(**self.SEND_KWARGS))

        assert result.ok is True
        assert result.status_code == 200
        assert result.request_id == "req-send-test"
        assert result.error_code == ""
        assert result.retryable is False
```

**Step 2: Run the new tests**

Run: `pytest tests/test_ued_sync_client.py::TestUedSyncClientSend -v --tb=short`
Expected: 5 tests pass

**Step 3: Run all tests to verify no regressions**

Run: `pytest tests/test_ued_sync_client.py -v --tb=short`
Expected: 9 tests pass (4 existing + 5 new)

**Step 4: Commit**

```bash
git add tests/test_ued_sync_client.py
git commit -m "test(S3): add 5 unit tests for UedSyncClient.send() method"
```

---

### Task 10: Final verification

**Step 1: Run full test suite**

Run: `pytest tests/ -v --tb=short`
Expected: 339+ tests pass, 0 failures

**Step 2: Commit review suggestions doc to track provenance**

```bash
git add docs/plans/2026-02-13-ued-sync-review-suggestions.md
git commit -m "docs: track UED sync review suggestions (provenance)"
```
