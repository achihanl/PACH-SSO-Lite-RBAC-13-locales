# Repo Cleanup: Archive, Delete, Consolidate

> **Date:** 2026-02-07 | **Status:** COMPLETE

## What changed

### Deleted (no archive)
- `demo/` — old HTML mockups, replaced by `src/frontend/`
- `plan.md` — scratch migration plan (work complete)
- `REACT_IMPLEMENTATION_SPEC.md` — superseded by design system docs
- `baseui-llms.txt` — ephemeral LLM reference, Context7 replaces it
- Empty `.claude/` subdirs (agents, commands, hooks, scripts)

### Archived to `docs/archive/`
- 34 completed/stale plan docs from `docs/plans/`
- 3 milestone files (v1.0-baseline checklist + gap analysis, v1.1-security checklist)
- 2 report files (frontend-backend gap analysis, Phase 1 QR report)
- 7 legacy v1.0 spec files (SPEC.md, LDAP architecture, API mapping, authentik READMEs, etc.)

### Consolidated into `specs/v2.0/`
- `milestones/v2.0-compliance/V1_TO_V2_GAP_ANALYSIS.md` — moved to `specs/v2.0/`
- `docs/specs/APPENDIX_A_LDAP_SCHEMA_ANALYSIS.md` — moved to `specs/v2.0/`
- `docs/specs/APPENDIX_B_LDAP_FEDERATION_UC_INTEGRATION.md` — moved to `specs/v2.0/`

### Removed empty directories
- `milestones/` (all contents archived or moved)
- `docs/specs/` (contents consolidated into specs/v2.0/)
- `docs/reports/` (contents archived)
- `specs/v1.0/` (contents archived)

### Updated
- `CLAUDE.md` — repo structure, implementation status, spec workflow, design doc references

## Result
- `docs/plans/` went from 37 files to 3 (including this one)
- `specs/v2.0/` is now the single source of truth for all v2.0 spec material (8 files)
- Historical docs preserved in `docs/archive/` (46 files) for reference
