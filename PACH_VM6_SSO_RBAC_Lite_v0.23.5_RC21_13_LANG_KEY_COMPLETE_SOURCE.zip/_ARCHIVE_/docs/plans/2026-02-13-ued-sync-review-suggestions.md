# UED Sync Integration — Remaining Review Suggestions

> **Session prompt:** Copy everything below the `---` into a new Claude Code session to address these items.

---

## Context

The UED Sync Integration was implemented across 11 commits on `main`. A final code review identified 8 suggestions (S1–S8) and 1 deferred important item (I2) that were not addressed in the implementation session. All critical and important issues were already fixed.

**Design doc:** `docs/plans/2026-02-13-ued-sync-integration-design.md`
**Implementation plan:** `docs/plans/2026-02-13-ued-sync-implementation-plan.md`

All 333 tests currently pass (40 UED-specific). Do not break any existing tests.

---

## Tasks

### S1. Replace deprecated `asyncio.get_event_loop()` in tests (3 files)

`asyncio.get_event_loop().run_until_complete()` triggers `DeprecationWarning` in Python 3.10+. Replace with `asyncio.run()` or use `@pytest.mark.asyncio` from `pytest-asyncio`.

**Files:**
- `tests/test_sync_worker.py` — lines 91, 111, 131 use `asyncio.get_event_loop().run_until_complete()`
- `tests/test_ued_sync_client.py` — line 20 defines unused `run_async` helper using the same pattern

**Fix:** Replace with `asyncio.run()` (simplest, no new dep) or install `pytest-asyncio` and use `@pytest.mark.asyncio` decorators on the test methods.

---

### S2. Remove dead code: unused `run_async` helper

`tests/test_ued_sync_client.py` lines 18-20 define `run_async()` which is never called. Also unused imports: `AsyncMock`, `patch` from `unittest.mock`.

**Fix:** Delete the `run_async` function and the unused imports (`AsyncMock`, `patch`, `asyncio`).

---

### S3. Add unit tests for `UedSyncClient.send()` method

Only `_build_request()` is tested. The `send()` method has no coverage for:
- HTTP timeout handling → should return `SyncResult(ok=False, error_code="TIMEOUT", retryable=True)`
- Connection errors → `SyncResult(ok=False, error_code="CONNECTION_ERROR", retryable=True)`
- Non-200 status codes (e.g., 500, 429) → retryable classification
- 200 response with `ok: false` → extract error fields from response body
- 200 response with `ok: true` → success path

**File:** `tests/test_ued_sync_client.py`
**Implementation:** `src/backend/ued_sync_client.py` lines 95-131 (`send` method)

**Approach:** Use `respx` (httpx mock library) or `unittest.mock.patch` on `httpx.AsyncClient.post`. Tests should be async — either use `asyncio.run()` or `@pytest.mark.asyncio`.

---

### S4. `request_id` column type mismatch between SQL and SQLAlchemy

**SQL migration** (`migrations/010_ued_sync.sql` line 40): `request_id UUID DEFAULT gen_random_uuid()`
**SQLAlchemy** (`src/backend/orgdb.py` line 295): `Column("request_id", String(36), nullable=True)`

The SQL type is `UUID`, but SQLAlchemy declares `String(36)`. The `insert_sync_event` method generates `str(uuid4())` which works fine for both. This is a cosmetic consistency issue.

**Fix option A:** Change SQLAlchemy to use `Column("request_id", Text, nullable=True)` — matches the string storage pattern and avoids implying a strict 36-char limit.
**Fix option B (better):** Import `UUID` from `sqlalchemy.dialects.postgresql` and use `Column("request_id", UUID(as_uuid=False), nullable=True)` to match the SQL type exactly.

---

### S5. Add `offset` parameter to sync-events list endpoint

`GET /api/ued/sync-events` (`main.py` line 3165) accepts `limit` but no `offset`, preventing pagination through large result sets.

**Fix:** Add `offset: int = 0` query parameter to `api_ued_sync_events_list()` and pass it through to `ORGDB.list_sync_events()`. Also add `offset` parameter to `OrgDB.list_sync_events()` in `orgdb.py` using `.offset(offset)` on the SQLAlchemy query.

**Files:**
- `src/backend/main.py` line 3165 — add `offset` param
- `src/backend/orgdb.py` — `list_sync_events()` method — add `.offset(offset)`
- `tests/test_ued_orgdb.py` — add test for offset pagination

---

### S6. Strengthen `test_requires_auth` test

`tests/test_ued_api.py` line 141: `assert resp.status_code in (200, 401, 403)` — always passes because dev mode returns 200. The test never verifies auth enforcement.

**Fix:** Split into two tests:
1. `test_endpoint_exists` — verify the endpoint responds (any status)
2. `test_requires_auth_in_production` — mark with `@pytest.mark.skipif` when `REQUIRE_OIDC_AUTH` is false, then verify 401/403 without auth headers

Or simpler: just rename the test to `test_endpoint_accessible` with a comment explaining that auth is tested at the middleware level, not per-endpoint.

---

### S7. Add clarifying comment on PATCH update filter

`main.py` line 3120: `updates = {k: v for k, v in req.model_dump().items() if v is not None}`

This correctly handles `enabled=False` (since `False is not None` evaluates to `True`), but the intent is not obvious.

**Fix:** Add a one-line comment:
```python
# Filter out None (unset) fields; False/0/"" are valid updates and pass through
updates = {k: v for k, v in req.model_dump().items() if v is not None}
```

---

### S8. Update design doc: add `ON DELETE CASCADE` to SQL example

The design doc's SQL at line 129 of `docs/plans/2026-02-13-ued-sync-integration-design.md` shows:
```sql
tenant_id TEXT NOT NULL REFERENCES tenant_ldap_configs(tenant_id),
```

But the actual migration has `ON DELETE CASCADE`. Update the design doc to match.

---

### I2 (Deferred). Test connectivity endpoint — add LDAP bind validation

`POST /api/ued/configs/{id}/test` (`main.py` lines 3139-3162) only tests UED health check. The design doc specifies a second step: call UED's `POST /api/v1/sync/auth/validate` to verify LDAP bind. The response always returns `ldap_bind_ok: false`.

**Current code:**
```python
result = {"ued_reachable": False, "ldap_bind_ok": False, "errors": []}
# ... only UED health check implemented ...
return result
```

**Fix:** After the health check succeeds, add a second HTTP call to `{ued_url}/api/v1/sync/auth/validate` with the LDAP config. This is a best-effort enhancement — if UED is unreachable, skip the LDAP test. Mark `ldap_bind_ok` based on the response.

**Note:** This requires a running UED instance to test against. If not available, add the code but mark the LDAP bind step as "skipped" in the response when UED is unreachable.

---

### C2 (Partial — Deferred). Cache Fernet instance in `ued_crypto.py`

`_get_fernet()` creates a new `Fernet()` object on every call. In the worker hot path this happens 2-3 times per event (decrypt API key, decrypt LDAP password, decrypt payload password).

**Current code** (`src/backend/ued_crypto.py` lines 15-23):
```python
def _get_fernet() -> Fernet:
    key = os.getenv("UED_ENCRYPTION_KEY", "")
    if not key:
        raise RuntimeError(...)
    return Fernet(key.encode())
```

**Fix:** Cache using `functools.lru_cache` or a module-level variable. The key doesn't change at runtime. Be careful to NOT break the test `test_missing_key_raises` which uses `monkeypatch.delenv` — the cache must be invalidated when the env var changes.

**Approach:**
```python
_fernet_cache: Fernet | None = None
_fernet_key_cache: str = ""

def _get_fernet() -> Fernet:
    global _fernet_cache, _fernet_key_cache
    key = os.getenv("UED_ENCRYPTION_KEY", "")
    if not key:
        raise RuntimeError(...)
    if key != _fernet_key_cache:
        _fernet_cache = Fernet(key.encode())
        _fernet_key_cache = key
    return _fernet_cache
```

This auto-invalidates when the env var changes (including during tests).

---

## Priority Order

1. **S7** — one-line comment (30 seconds)
2. **S8** — design doc fix (1 minute)
3. **S2** — remove dead code (1 minute)
4. **S1** — fix deprecation warnings (5 minutes)
5. **S4** — request_id type consistency (2 minutes)
6. **C2** — cache Fernet instance (5 minutes)
7. **S5** — add pagination offset (10 minutes, includes OrgDB + API + test)
8. **S3** — add send() unit tests (15 minutes)
9. **S6** — strengthen auth test (5 minutes)
10. **I2** — LDAP bind test endpoint (15 minutes, needs UED awareness)

## Verification

After all changes, run: `pytest tests/ -v --tb=short`
Expected: 333+ passed (more with new tests from S3/S5), 0 failures.
