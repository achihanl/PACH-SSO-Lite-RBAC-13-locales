# SIP + XMPP Profile Provisioning Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Enable admin to create profiles with SIP+XMPP configs, assign profiles during user provisioning, and have users automatically provisioned with real LDAP accounts for SIP/XMPP authentication.

**Architecture:** Profile-linked provisioning enrichment -- bridge config_templates to tenant_ldap_configs, enrich sync event payload with schema-required fields, auto-allocate uidNumber and SIP extension.

**Tech Stack:** Python/FastAPI (sync), PostgreSQL, SQLAlchemy Core, React 19, TanStack Query, TypeScript

**Domains:** backend, frontend, database

---

## Task 1: Database migration
**domain:** database | **depends_on:** [] | **parallel_group:** 1

Create `migrations/012_profile_ued_link.sql`:
- Add `ued_config_id VARCHAR(36) REFERENCES tenant_ldap_configs(id)` to config_templates
- Add counter columns to tenant_ldap_configs: next_uid_number, uid_range_start/end, next_extension, ext_range_start/end
- Update table definitions in orgdb.py

## Task 2: OrgDB atomic allocation methods
**domain:** backend | **depends_on:** [1] | **parallel_group:** 2

Add `allocate_uid_number(config_id)` and `allocate_extension(config_id)` to OrgDB class using UPDATE...RETURNING.

## Task 3: Config template CRUD — expose ued_config_id and schemaName
**domain:** backend | **depends_on:** [1] | **parallel_group:** 2

Extend ConfigTemplateCreate/Update models and format functions to include uedConfigId and resolved schemaName.

## Task 4: enrich_sync_payload function
**domain:** backend | **depends_on:** [2, 3] | **parallel_group:** 3

Create `src/backend/provisioning.py` with pure function that allocates uid_number, extension, generates sip_password based on schema_name.

## Task 5: Wire profileId into api_user_create
**domain:** backend | **depends_on:** [3, 4] | **parallel_group:** 4

Add profileId to UserCreateReq, resolve profile → UED config → enrich sync event payload.

## Task 6: Frontend — send profileId in creation payload
**domain:** frontend | **depends_on:** [5] | **parallel_group:** 5

Add profileId to CreateUserPayload type, include state.profileId in StepQRCode handleGenerate.

## Task 7: Frontend — show provisioning details on StepComplete
**domain:** frontend | **depends_on:** [5, 6] | **parallel_group:** 5

Return provisioning info from backend, extend OnboardingState, display uidNumber/extension/schemaName.

## Task 8: Frontend — show schema badge on StepProfile
**domain:** frontend | **depends_on:** [3, 6] | **parallel_group:** 5

Add uedConfigId/schemaName to ProfileListItem/ProfileDetail types, show schema badge in profile selection.

## Task 9: Integration tests
**domain:** backend | **depends_on:** [5] | **parallel_group:** 6

End-to-end test: profile with UED link → user create → verify enriched sync event with uid_number/extension.

## Task 10: Documentation
**domain:** documentation | **depends_on:** [9] | **parallel_group:** 7

Update CLAUDE.md with provisioning enrichment architecture and migration reference.
