# Settings Migration Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Replace the read-only `/configuration/settings` page with a full admin settings management page — 9 scroll-spy sections, form editing, dirty tracking, batch save, and backend CRUD.

**Architecture:** Sticky sidebar nav (240px) + scrolling content (1fr) with IntersectionObserver scroll-spy. Settings stored as key/value rows in PostgreSQL `app_settings` table with fallback chain (database > env var > default). API keys stored in `api_keys` table with SHA-256 hashed keys. Frontend uses local `useState` for form state + TanStack Query for server data.

**Tech Stack:** FastAPI, SQLAlchemy Core (sync), PostgreSQL, React 19, TanStack Router/Query, @azblink/ui (Base UI + CSS Modules), Tailwind CSS 4

**Design doc:** `docs/plans/2026-02-11-settings-migration.md`
**Spec:** `new-migration-ui/SETTINGS_MIGRATION_SPEC.md`
**HTML prototype:** `new-migration-ui/settings-content-only.html`

---

## Phase 0: Schema + Types + Primitives

### Task 0.1: Database Migration — `app_settings` + `api_keys` Tables

**Files:**
- Create: `migrations/009_settings.sql`

**Step 1: Write the migration SQL**

```sql
-- Migration 009: App settings (key/value) and API keys
-- For existing deployments upgrading in-place.
-- Fresh deployments auto-create via OrgDB.init().

-- App-level settings: key/value grouped by section
CREATE TABLE IF NOT EXISTS app_settings (
    id          SERIAL PRIMARY KEY,
    section     VARCHAR(50) NOT NULL,
    key         VARCHAR(100) NOT NULL,
    value       TEXT NOT NULL DEFAULT '',
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(section, key)
);

CREATE INDEX IF NOT EXISTS idx_app_settings_section
    ON app_settings(section);

-- API keys for programmatic access
CREATE TABLE IF NOT EXISTS api_keys (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    prefix      VARCHAR(30) NOT NULL,
    key_hash    VARCHAR(128) NOT NULL,
    created_by  VARCHAR(100) NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_used_at TIMESTAMPTZ,
    revoked_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_api_keys_active
    ON api_keys(created_at DESC) WHERE revoked_at IS NULL;
```

**Step 2: Verify migration is valid SQL**

Run: `just psql < migrations/009_settings.sql`
Expected: Tables created without errors

**Step 3: Verify tables exist**

Run: `just psql -c "\dt app_settings" && just psql -c "\dt api_keys"`
Expected: Both tables listed

**Step 4: Commit**

```bash
git add migrations/009_settings.sql
git commit -m "feat(settings): add app_settings + api_keys tables (Phase 0)"
```

---

### Task 0.2: Backend Settings DB Module

**Files:**
- Create: `src/backend/settingsdb.py`
- Modify: `src/backend/orgdb.py` (add table definitions to metadata + init)

**Step 1: Write the failing test**

Create: `tests/test_settings.py`

```python
"""Settings API endpoint tests."""

import pytest


class TestSettingsEndpoints:
    """Settings CRUD via /api/settings."""

    def test_get_settings_returns_all_sections(self, client, auth_headers):
        """GET /api/settings returns grouped settings with defaults."""
        resp = client.get("/api/settings", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert "settings" in data
        settings = data["settings"]
        # All 5 sections present
        for section in ("ldap", "email", "security", "audit", "branding"):
            assert section in settings, f"Missing section: {section}"

    def test_get_settings_requires_auth(self, client):
        """GET /api/settings rejects unauthenticated requests."""
        resp = client.get("/api/settings")
        assert resp.status_code in (401, 403)
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_settings.py::TestSettingsEndpoints::test_get_settings_returns_all_sections -v`
Expected: FAIL — 404 (endpoint doesn't exist)

**Step 3: Write settingsdb.py with CRUD operations**

Create: `src/backend/settingsdb.py`

```python
"""
PostgreSQL operations for app settings and API keys.
- Settings: key/value pairs grouped by section (ldap, email, security, audit, branding)
- API Keys: hashed key storage with prefix for display
"""

import hashlib
import json
import logging
import secrets
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from sqlalchemy import (
    Column,
    DateTime,
    Integer,
    MetaData,
    String,
    Table,
    Text,
    create_engine,
    delete,
    select,
    text,
    update,
)
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.engine import Engine

logger = logging.getLogger(__name__)

# Default settings per section (fallback when no DB row exists)
SETTINGS_DEFAULTS: dict[str, dict[str, Any]] = {
    "ldap": {
        "serverUrl": "",
        "baseDn": "",
        "bindDn": "",
        "bindPassword": "",
        "userSearchBase": "",
        "groupSearchBase": "",
        "verifySsl": True,
        "connectionPooling": True,
    },
    "email": {
        "smtpHost": "",
        "smtpPort": 587,
        "username": "",
        "password": "",
        "fromAddress": "",
        "fromName": "Azblink Directory",
        "useTls": True,
    },
    "security": {
        "sessionTimeoutMinutes": 60,
        "maxLoginAttempts": 5,
        "requireMfa": False,
        "ipAllowlist": False,
        "auditApiRequests": True,
    },
    "audit": {
        "retentionPolicy": "90",
        "siemExport": False,
        "includeUserDetails": True,
    },
    "branding": {
        "companyName": "",
        "supportEmail": "",
        "qrEmailFooter": "",
        "includeLogoInEmails": True,
    },
}


def _serialize_value(value: Any) -> str:
    """Serialize a Python value to a string for storage."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    return str(value)


def _deserialize_value(raw: str, default: Any) -> Any:
    """Deserialize a stored string back to its typed Python value."""
    if isinstance(default, bool):
        return raw.lower() in ("true", "1", "yes")
    if isinstance(default, int):
        try:
            return int(raw)
        except ValueError:
            return default
    return raw


class SettingsDB:
    """PostgreSQL operations for app_settings and api_keys tables."""

    def __init__(self, engine: Engine) -> None:
        self.engine = engine

    # ── Settings CRUD ─────────────────────────────────────────────

    def get_all_settings(self) -> dict[str, dict[str, Any]]:
        """Load all settings, merged with defaults."""
        result: dict[str, dict[str, Any]] = {}
        for section, defaults in SETTINGS_DEFAULTS.items():
            result[section] = dict(defaults)  # start from defaults

        # Overlay DB values
        stmt = text("SELECT section, key, value FROM app_settings")
        with self.engine.begin() as conn:
            rows = conn.execute(stmt).mappings().all()

        for row in rows:
            section = row["section"]
            key = row["key"]
            if section in result and key in SETTINGS_DEFAULTS.get(section, {}):
                default = SETTINGS_DEFAULTS[section][key]
                result[section][key] = _deserialize_value(row["value"], default)

        return result

    def update_settings(self, updates: dict[str, dict[str, Any]]) -> None:
        """Upsert changed settings. `updates` is {section: {key: value}}."""
        with self.engine.begin() as conn:
            for section, fields in updates.items():
                for key, value in fields.items():
                    serialized = _serialize_value(value)
                    # Upsert via ON CONFLICT
                    conn.execute(text("""
                        INSERT INTO app_settings (section, key, value, updated_at)
                        VALUES (:section, :key, :value, NOW())
                        ON CONFLICT (section, key)
                        DO UPDATE SET value = :value, updated_at = NOW()
                    """), {"section": section, "key": key, "value": serialized})

    def reset_all_settings(self) -> None:
        """Delete all settings rows (revert to defaults)."""
        with self.engine.begin() as conn:
            conn.execute(text("DELETE FROM app_settings"))

    # ── API Keys CRUD ─────────────────────────────────────────────

    def list_api_keys(self) -> list[dict[str, Any]]:
        """List active (non-revoked) API keys."""
        stmt = text("""
            SELECT id, prefix, created_by, created_at, last_used_at
            FROM api_keys
            WHERE revoked_at IS NULL
            ORDER BY created_at DESC
        """)
        with self.engine.begin() as conn:
            rows = conn.execute(stmt).mappings().all()
        return [dict(r) for r in rows]

    def generate_api_key(self, created_by: str) -> dict[str, Any]:
        """Generate a new API key. Returns full key (shown once)."""
        raw_key = f"ak_live_{secrets.token_hex(24)}"
        prefix = raw_key[:20]
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        key_id = str(uuid4())

        with self.engine.begin() as conn:
            conn.execute(text("""
                INSERT INTO api_keys (id, prefix, key_hash, created_by)
                VALUES (:id, :prefix, :key_hash, :created_by)
            """), {
                "id": key_id,
                "prefix": prefix,
                "key_hash": key_hash,
                "created_by": created_by,
            })

        return {
            "id": key_id,
            "fullKey": raw_key,  # shown once only
            "prefix": prefix,
            "createdBy": created_by,
        }

    def revoke_api_key(self, key_id: str) -> bool:
        """Soft-delete an API key. Returns False if not found."""
        with self.engine.begin() as conn:
            result = conn.execute(text("""
                UPDATE api_keys SET revoked_at = NOW()
                WHERE id = :id AND revoked_at IS NULL
            """), {"id": key_id})
        return result.rowcount > 0
```

**Step 4: Add table auto-creation to orgdb.py init()**

Modify: `src/backend/orgdb.py` — add `app_settings` and `api_keys` to `metadata.create_all()`. Look at the existing `init()` method and add the two new table definitions alongside existing ones.

**Step 5: Run test to verify it passes**

Run: `just test-quick -- tests/test_settings.py::TestSettingsEndpoints -v`
Expected: PASS (after wiring endpoints in Task 0.3)

> **Note:** This task creates the DB module. The endpoint wiring happens in Task 0.3. Run the test after Task 0.3 is complete.

**Step 6: Commit**

```bash
git add src/backend/settingsdb.py
git commit -m "feat(settings): add SettingsDB module for app_settings + api_keys CRUD (Phase 0)"
```

---

### Task 0.3: Backend GET /api/settings Endpoint

**Files:**
- Modify: `src/backend/main.py` (add settings endpoints)

**Step 1: Wire the endpoint in main.py**

Add after the config-templates section (~line 2820):

```python
# ── Settings endpoints ────────────────────────────────────────────
from settingsdb import SettingsDB

# Initialize SettingsDB (reuse ORGDB's engine)
SETTINGS_DB: SettingsDB | None = None

def get_settings_db() -> SettingsDB:
    """Lazy-init SettingsDB with shared engine."""
    global SETTINGS_DB
    if SETTINGS_DB is None:
        SETTINGS_DB = SettingsDB(ORGDB.connect())
    return SETTINGS_DB


@app.get("/api/settings")
def api_get_settings(claims: dict = Depends(require_admin)):
    """Load all settings grouped by section, merged with defaults."""
    db = get_settings_db()
    settings = db.get_all_settings()
    # Mask sensitive fields
    if settings.get("ldap", {}).get("bindPassword"):
        settings["ldap"]["bindPassword"] = "••••••••"
    if settings.get("email", {}).get("password"):
        settings["email"]["password"] = "••••••••"
    return {"ok": True, "settings": settings}
```

**Step 2: Run the test from Task 0.2**

Run: `just test-quick -- tests/test_settings.py::TestSettingsEndpoints -v`
Expected: PASS for both `test_get_settings_returns_all_sections` and `test_get_settings_requires_auth`

**Step 3: Commit**

```bash
git add src/backend/main.py tests/test_settings.py
git commit -m "feat(settings): GET /api/settings endpoint with defaults (Phase 0)"
```

---

### Task 0.4: Backend PATCH /api/settings Endpoint

**Files:**
- Modify: `src/backend/main.py`
- Modify: `tests/test_settings.py`

**Step 1: Write the failing test**

```python
class TestSettingsPatch:
    """PATCH /api/settings — update dirty fields."""

    def test_patch_settings_updates_fields(self, client, auth_headers):
        """PATCH updates specific fields and returns updated settings."""
        resp = client.patch(
            "/api/settings",
            headers=auth_headers,
            json={"branding": {"companyName": "Test Corp"}},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["settings"]["branding"]["companyName"] == "Test Corp"

    def test_patch_settings_preserves_other_fields(self, client, auth_headers):
        """PATCH doesn't clobber fields not in the request."""
        # Set two fields
        client.patch(
            "/api/settings",
            headers=auth_headers,
            json={"branding": {"companyName": "Corp A", "supportEmail": "a@test.com"}},
        )
        # Update only one
        resp = client.patch(
            "/api/settings",
            headers=auth_headers,
            json={"branding": {"companyName": "Corp B"}},
        )
        data = resp.json()
        assert data["settings"]["branding"]["companyName"] == "Corp B"
        assert data["settings"]["branding"]["supportEmail"] == "a@test.com"

    def test_patch_settings_requires_auth(self, client):
        """PATCH rejects unauthenticated requests."""
        resp = client.patch("/api/settings", json={"branding": {"companyName": "X"}})
        assert resp.status_code in (401, 403)
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_settings.py::TestSettingsPatch::test_patch_settings_updates_fields -v`
Expected: FAIL — 405 Method Not Allowed (no PATCH handler)

**Step 3: Add PATCH endpoint to main.py**

```python
from pydantic import BaseModel
from typing import Optional

class SettingsPatchRequest(BaseModel):
    ldap: Optional[dict] = None
    email: Optional[dict] = None
    security: Optional[dict] = None
    audit: Optional[dict] = None
    branding: Optional[dict] = None

@app.patch("/api/settings")
def api_patch_settings(req: SettingsPatchRequest, claims: dict = Depends(require_admin)):
    """Update only the provided setting fields (dirty-field save)."""
    db = get_settings_db()
    updates = {}
    for section in ("ldap", "email", "security", "audit", "branding"):
        section_data = getattr(req, section)
        if section_data:
            updates[section] = section_data
    if updates:
        db.update_settings(updates)
    # Return full settings after update
    settings = db.get_all_settings()
    if settings.get("ldap", {}).get("bindPassword"):
        settings["ldap"]["bindPassword"] = "••••••••"
    if settings.get("email", {}).get("password"):
        settings["email"]["password"] = "••••••••"
    return {"ok": True, "settings": settings}
```

**Step 4: Run tests to verify they pass**

Run: `just test-quick -- tests/test_settings.py::TestSettingsPatch -v`
Expected: PASS (all 3)

**Step 5: Commit**

```bash
git add src/backend/main.py tests/test_settings.py
git commit -m "feat(settings): PATCH /api/settings with dirty-field upsert (Phase 0)"
```

---

### Task 0.5: Backend PUT /api/settings/reset Endpoint

**Files:**
- Modify: `src/backend/main.py`
- Modify: `tests/test_settings.py`

**Step 1: Write the failing test**

```python
class TestSettingsReset:
    """PUT /api/settings/reset — reset all to defaults."""

    def test_reset_clears_custom_settings(self, client, auth_headers):
        """Reset removes all custom settings, returning defaults."""
        # Set a custom value
        client.patch(
            "/api/settings",
            headers=auth_headers,
            json={"branding": {"companyName": "Custom Corp"}},
        )
        # Reset
        resp = client.put("/api/settings/reset", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        # companyName should be back to default (empty string)
        assert data["settings"]["branding"]["companyName"] == ""
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_settings.py::TestSettingsReset -v`
Expected: FAIL — 405 (no PUT handler)

**Step 3: Add PUT reset endpoint**

```python
@app.put("/api/settings/reset")
def api_reset_settings(claims: dict = Depends(require_admin)):
    """Reset all settings to defaults. Destructive — requires admin."""
    db = get_settings_db()
    db.reset_all_settings()
    settings = db.get_all_settings()
    return {"ok": True, "settings": settings}
```

**Step 4: Run test**

Run: `just test-quick -- tests/test_settings.py::TestSettingsReset -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/backend/main.py tests/test_settings.py
git commit -m "feat(settings): PUT /api/settings/reset endpoint (Phase 0)"
```

---

### Task 0.6: Backend API Keys Endpoints

**Files:**
- Modify: `src/backend/main.py`
- Modify: `tests/test_settings.py`

**Step 1: Write the failing tests**

```python
class TestApiKeysEndpoints:
    """API key CRUD: generate, list, revoke."""

    def test_generate_api_key_returns_full_key(self, client, auth_headers):
        """POST /api/keys returns the full key (shown once)."""
        resp = client.post("/api/keys", headers=auth_headers)
        assert resp.status_code == 201
        data = resp.json()
        assert data["ok"] is True
        key_data = data["key"]
        assert key_data["fullKey"].startswith("ak_live_")
        assert len(key_data["fullKey"]) > 20
        assert "id" in key_data

    def test_list_api_keys_masks_key(self, client, auth_headers):
        """GET /api/keys returns keys with prefix only (no full key)."""
        # Generate one first
        client.post("/api/keys", headers=auth_headers)
        resp = client.get("/api/keys", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert len(data["keys"]) >= 1
        for key in data["keys"]:
            assert "fullKey" not in key
            assert "prefix" in key

    def test_revoke_api_key(self, client, auth_headers):
        """DELETE /api/keys/:id soft-deletes the key."""
        # Generate
        gen_resp = client.post("/api/keys", headers=auth_headers)
        key_id = gen_resp.json()["key"]["id"]
        # Revoke
        resp = client.delete(f"/api/keys/{key_id}", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.json()["ok"] is True
        # Verify it's gone from list
        list_resp = client.get("/api/keys", headers=auth_headers)
        key_ids = [k["id"] for k in list_resp.json()["keys"]]
        assert key_id not in key_ids

    def test_revoke_nonexistent_key_returns_404(self, client, auth_headers):
        """DELETE /api/keys/:id returns 404 for unknown key."""
        resp = client.delete("/api/keys/nonexistent-id", headers=auth_headers)
        assert resp.status_code == 404
```

**Step 2: Run test to verify failure**

Run: `just test-quick -- tests/test_settings.py::TestApiKeysEndpoints::test_generate_api_key_returns_full_key -v`
Expected: FAIL — 404

**Step 3: Add API key endpoints to main.py**

```python
@app.get("/api/keys")
def api_list_keys(claims: dict = Depends(require_admin)):
    """List active API keys (masked)."""
    db = get_settings_db()
    keys = db.list_api_keys()
    return {
        "ok": True,
        "keys": [
            {
                "id": str(k["id"]),
                "prefix": k["prefix"],
                "maskedKey": k["prefix"] + "••••••••••••",
                "createdBy": k["created_by"],
                "createdAt": k["created_at"].isoformat() if k.get("created_at") else None,
                "lastUsedAt": k["last_used_at"].isoformat() if k.get("last_used_at") else None,
            }
            for k in keys
        ],
    }


@app.post("/api/keys", status_code=201)
def api_generate_key(claims: dict = Depends(require_admin)):
    """Generate a new API key. Full key returned ONCE."""
    db = get_settings_db()
    actor = extract_actor(claims)
    key_data = db.generate_api_key(created_by=actor)
    return {"ok": True, "key": key_data}


@app.delete("/api/keys/{key_id}")
def api_revoke_key(key_id: str, claims: dict = Depends(require_admin)):
    """Revoke (soft-delete) an API key."""
    db = get_settings_db()
    revoked = db.revoke_api_key(key_id)
    if not revoked:
        raise HTTPException(404, f"API key '{key_id}' not found or already revoked")
    return {"ok": True}
```

**Step 4: Run tests**

Run: `just test-quick -- tests/test_settings.py::TestApiKeysEndpoints -v`
Expected: PASS (all 4)

**Step 5: Commit**

```bash
git add src/backend/main.py tests/test_settings.py
git commit -m "feat(settings): API key endpoints — generate, list, revoke (Phase 0)"
```

---

### Task 0.7: Backend Test Connection Endpoints

**Files:**
- Modify: `src/backend/main.py`
- Modify: `tests/test_settings.py`

**Step 1: Write the failing test**

```python
class TestConnectionTests:
    """Test connection endpoints for LDAP and email."""

    def test_ldap_test_connection_returns_status(self, client, auth_headers):
        """POST /api/settings/ldap/test returns connection status."""
        resp = client.post("/api/settings/ldap/test", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["status"] in ("healthy", "error")

    def test_email_test_returns_status(self, client, auth_headers):
        """POST /api/settings/email/test returns send status."""
        resp = client.post("/api/settings/email/test", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        # Email test may fail (no SMTP configured in dev) but endpoint works
        assert data["status"] in ("sent", "error")
```

**Step 2: Run to verify failure**

Run: `just test-quick -- tests/test_settings.py::TestConnectionTests -v`
Expected: FAIL — 404

**Step 3: Add test endpoints**

```python
@app.post("/api/settings/ldap/test")
def api_test_ldap(claims: dict = Depends(require_admin)):
    """Test LDAP connection using current settings."""
    try:
        conn = get_conn()  # existing ldap_client helper
        conn.unbind()
        return {"ok": True, "status": "healthy", "message": "LDAP connection successful"}
    except Exception as e:
        logger.warning("LDAP test connection failed: %s", e, exc_info=True)
        return {"ok": True, "status": "error", "message": str(e)}


@app.post("/api/settings/email/test")
def api_test_email(claims: dict = Depends(require_admin)):
    """Send a test email using current SMTP settings."""
    # SMTP not configured in dev — return graceful error
    try:
        db = get_settings_db()
        settings = db.get_all_settings()
        smtp_host = settings.get("email", {}).get("smtpHost", "")
        if not smtp_host:
            return {"ok": True, "status": "error", "message": "SMTP host not configured"}
        # TODO: Implement actual SMTP test when email service is available
        return {"ok": True, "status": "error", "message": "Email sending not yet implemented"}
    except Exception as e:
        logger.warning("Email test failed: %s", e, exc_info=True)
        return {"ok": True, "status": "error", "message": str(e)}
```

**Step 4: Run tests**

Run: `just test-quick -- tests/test_settings.py::TestConnectionTests -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/backend/main.py tests/test_settings.py
git commit -m "feat(settings): test-connection endpoints for LDAP and email (Phase 0)"
```

---

### Task 0.8: Frontend TypeScript Types

**Files:**
- Create: `src/frontend/src/types/settings.ts`

**Step 1: Write the types file**

```typescript
/**
 * Settings page type definitions.
 * - AllSettings: aggregate form model for all 5 config sections
 * - ApiKey / Administrator: list items for API Keys and Admins sections
 * - DangerAction: destructive action card config
 * @see new-migration-ui/SETTINGS_MIGRATION_SPEC.md §6
 */

// ── Connection Status ────────────────────────────────────────────
export type ConnectionStatus = 'healthy' | 'warning' | 'error' | 'unknown';

// ── LDAP Settings ────────────────────────────────────────────────
export interface LdapSettings {
  serverUrl: string;
  baseDn: string;
  bindDn: string;
  bindPassword: string;
  userSearchBase: string;
  groupSearchBase: string;
  verifySsl: boolean;
  connectionPooling: boolean;
  status: ConnectionStatus;
}

// ── Email Settings ───────────────────────────────────────────────
export type SmtpPort = 25 | 465 | 587;

export interface EmailSettings {
  smtpHost: string;
  smtpPort: SmtpPort;
  username: string;
  password: string;
  fromAddress: string;
  fromName: string;
  useTls: boolean;
}

// ── Security Settings ────────────────────────────────────────────
export type SessionTimeout = 15 | 30 | 60 | 240 | 480;
export type MaxLoginAttempts = 0 | 3 | 5 | 10;

export interface SecuritySettings {
  sessionTimeoutMinutes: SessionTimeout;
  maxLoginAttempts: MaxLoginAttempts;
  requireMfa: boolean;
  ipAllowlist: boolean;
  auditApiRequests: boolean;
}

// ── Audit Settings ───────────────────────────────────────────────
export type RetentionPolicy = '90' | '365' | 'forever';

export interface AuditSettings {
  retentionPolicy: RetentionPolicy;
  siemExport: boolean;
  includeUserDetails: boolean;
}

// ── Branding Settings ────────────────────────────────────────────
export interface BrandingSettings {
  companyName: string;
  supportEmail: string;
  qrEmailFooter: string;
  includeLogoInEmails: boolean;
}

// ── Aggregate Settings Model ─────────────────────────────────────
export interface AllSettings {
  ldap: LdapSettings;
  email: EmailSettings;
  security: SecuritySettings;
  audit: AuditSettings;
  branding: BrandingSettings;
}

// ── API Key ──────────────────────────────────────────────────────
export interface ApiKey {
  id: string;
  prefix: string;
  maskedKey: string;
  createdAt: string;
  createdBy: string;
  lastUsedAt: string | null;
}

/** Returned only from POST /api/keys (generation) */
export interface ApiKeyGenerated {
  id: string;
  fullKey: string;
  prefix: string;
  createdBy: string;
}

// ── Administrator ────────────────────────────────────────────────
export type AdminRole = 'owner' | 'admin';
export type AvatarGradient = 'indigo-purple' | 'blue-cyan' | 'green-teal';

export interface Administrator {
  id: string;
  name: string;
  initials: string;
  email: string;
  role: AdminRole;
  avatarGradient: AvatarGradient;
}

// ── Danger Actions ───────────────────────────────────────────────
export type DangerActionId = 'purge-qr' | 'reset-settings';

export interface DangerActionConfig {
  id: DangerActionId;
  title: string;
  description: string;
  confirmText: string;
}

// ── API Response Shapes ──────────────────────────────────────────
export interface SettingsResponse {
  ok: boolean;
  settings: AllSettings;
}

export interface ApiKeysResponse {
  ok: boolean;
  keys: ApiKey[];
}

export interface ApiKeyGenerateResponse {
  ok: boolean;
  key: ApiKeyGenerated;
}

export interface ConnectionTestResponse {
  ok: boolean;
  status: 'healthy' | 'sent' | 'error';
  message: string;
}
```

**Step 2: Verify no TypeScript errors**

Run: `cd src/frontend && npx tsc --noEmit src/types/settings.ts`
Expected: No errors

**Step 3: Commit**

```bash
git add src/frontend/src/types/settings.ts
git commit -m "feat(settings): TypeScript types for all settings sections (Phase 0)"
```

---

### Task 0.9: Frontend Query Options

**Files:**
- Create: `src/frontend/src/lib/queries/settings.ts`
- Create: `src/frontend/src/lib/queries/api-keys.ts`

**Step 1: Write settings query options**

```typescript
/**
 * TanStack Query options for settings endpoints.
 * - settingsQueryOptions: GET /api/settings
 * - settingsMutationOptions: PATCH /api/settings
 * - settingsResetMutation: PUT /api/settings/reset
 * - ldapTestMutation / emailTestMutation: POST /api/settings/{service}/test
 */

import { queryOptions } from '@tanstack/react-query';
import type { AllSettings, SettingsResponse, ConnectionTestResponse } from '@/types/settings';

const API_BASE = '/api';

export function settingsQueryOptions() {
  return queryOptions<AllSettings>({
    queryKey: ['settings'],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/settings`);
      if (!res.ok) throw new Error(`Failed to load settings: ${res.status}`);
      const data: SettingsResponse = await res.json();
      return data.settings;
    },
  });
}
```

**Step 2: Write API keys query options**

```typescript
/**
 * TanStack Query options for API key management.
 * - apiKeysQueryOptions: GET /api/keys
 */

import { queryOptions } from '@tanstack/react-query';
import type { ApiKey, ApiKeysResponse } from '@/types/settings';

const API_BASE = '/api';

export function apiKeysQueryOptions() {
  return queryOptions<ApiKey[]>({
    queryKey: ['api-keys'],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/keys`);
      if (!res.ok) throw new Error(`Failed to load API keys: ${res.status}`);
      const data: ApiKeysResponse = await res.json();
      return data.keys;
    },
  });
}
```

**Step 3: Commit**

```bash
git add src/frontend/src/lib/queries/settings.ts src/frontend/src/lib/queries/api-keys.ts
git commit -m "feat(settings): TanStack Query options for settings + API keys (Phase 0)"
```

---

### Task 0.10: @azblink/ui Select Primitive

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/Select/Select.types.ts`
- Create: `src/frontend/packages/azblink-ui/primitives/Select/Select.tsx`
- Create: `src/frontend/packages/azblink-ui/primitives/Select/Select.module.css`
- Create: `src/frontend/packages/azblink-ui/primitives/Select/index.ts`
- Modify: `src/frontend/packages/azblink-ui/index.ts` (add export)

**Context:** Check Base UI docs for Select API before implementing.

**Step 1: Look up Base UI Select component**

Use Context7 to fetch current `@base-ui-components/react` Select docs. If Base UI doesn't have a Select, fall back to a styled native `<select>` with token-based CSS Modules.

**Step 2: Write Select.types.ts**

```typescript
/**
 * Select type definitions.
 * - Styled dropdown select with token-based CSS Modules
 * - Supports controlled/uncontrolled, disabled, multiple sizes
 */

export interface SelectOption {
  value: string;
  label: string;
}

export interface SelectProps {
  /** Available options */
  options: SelectOption[];
  /** Controlled value */
  value?: string;
  /** Default value (uncontrolled) */
  defaultValue?: string;
  /** Callback when selection changes */
  onChange?: (value: string) => void;
  /** Disabled state */
  disabled?: boolean;
  /** Placeholder text when no value selected */
  placeholder?: string;
  /** Additional CSS class */
  className?: string;
  /** Input ID for label association */
  id?: string;
  /** Name attribute for form submission */
  name?: string;
  /** Accessible label */
  'aria-label'?: string;
  /** Test ID */
  'data-testid'?: string;
}
```

**Step 3: Write Select.module.css**

```css
/* Select.module.css — Native <select> with token-based styling */
.root {
  appearance: none;
  width: 100%;
  padding: var(--space-2) var(--space-8) var(--space-2) var(--space-3);
  font-family: var(--font-sans);
  font-size: var(--text-sm);
  line-height: var(--leading-snug);
  color: var(--color-text-primary);
  background-color: var(--color-bg-tertiary);
  border: 1px solid var(--color-border-default);
  border-radius: var(--radius-md);
  cursor: pointer;
  transition: border var(--transition-normal), background var(--transition-normal);
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='none' stroke='%2371717a' stroke-width='2' viewBox='0 0 24 24'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right var(--space-2) center;
  background-size: var(--space-4);
}

.root:hover {
  border-color: var(--color-border-strong);
}

.root:focus {
  outline: 2px solid var(--color-accent);
  outline-offset: 1px;
  border-color: var(--color-accent);
}

.root:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
```

**Step 4: Write Select.tsx**

```typescript
/**
 * Select — native <select> with Azblink token-based styling.
 * - Uses native <select> for maximum a11y and mobile support
 * - Styled via CSS Modules referencing tokens.css
 */
'use client';

import styles from './Select.module.css';
import type { SelectProps } from './Select.types';

export function Select({
  options,
  value,
  defaultValue,
  onChange,
  disabled,
  placeholder,
  className = '',
  id,
  name,
  ...ariaProps
}: SelectProps) {
  const classNames = [styles.root, className].filter(Boolean).join(' ');

  return (
    <select
      value={value}
      defaultValue={defaultValue}
      onChange={(e) => onChange?.(e.target.value)}
      disabled={disabled}
      className={classNames}
      id={id}
      name={name}
      aria-label={ariaProps['aria-label']}
      data-testid={ariaProps['data-testid']}
    >
      {placeholder && (
        <option value="" disabled>
          {placeholder}
        </option>
      )}
      {options.map((opt) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
  );
}
```

**Step 5: Write index.ts barrel**

```typescript
export { Select } from './Select';
export type { SelectProps, SelectOption } from './Select.types';
```

**Step 6: Add export to @azblink/ui index.ts**

Add after the existing `Input` export:

```typescript
export { Select } from './primitives/Select';
export type { SelectProps, SelectOption } from './primitives/Select';
```

**Step 7: Verify build**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No errors

**Step 8: Commit**

```bash
git add src/frontend/packages/azblink-ui/primitives/Select/ src/frontend/packages/azblink-ui/index.ts
git commit -m "feat(@azblink/ui): add Select primitive with token-based styling (Phase 0)"
```

---

### Task 0.11: @azblink/ui RadioGroup Primitive

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/RadioGroup/RadioGroup.types.ts`
- Create: `src/frontend/packages/azblink-ui/primitives/RadioGroup/RadioGroup.tsx`
- Create: `src/frontend/packages/azblink-ui/primitives/RadioGroup/RadioGroup.module.css`
- Create: `src/frontend/packages/azblink-ui/primitives/RadioGroup/index.ts`
- Modify: `src/frontend/packages/azblink-ui/index.ts`

**Step 1: Look up Base UI RadioGroup**

Use Context7 for `@base-ui-components/react` RadioGroup. If available, wrap it. Otherwise build with native `<input type="radio">` + `fieldset`.

**Step 2: Write types, component, CSS Module, barrel, export**

Follow the exact same structure as Task 0.10 (Select). The RadioGroup should:
- Accept `options: RadioOption[]` with `value`, `label`, `description`
- Support controlled `value` + `onChange`
- Use `fieldset` + `legend` for a11y
- Card-style visual (border, padding, selected state with blue highlight)
- CSS Modules with token references

**Step 3: Verify build + commit**

```bash
git add src/frontend/packages/azblink-ui/primitives/RadioGroup/ src/frontend/packages/azblink-ui/index.ts
git commit -m "feat(@azblink/ui): add RadioGroup primitive with card-style options (Phase 0)"
```

---

### Task 0.12: @azblink/ui ToggleRow Primitive

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/ToggleRow/ToggleRow.types.ts`
- Create: `src/frontend/packages/azblink-ui/primitives/ToggleRow/ToggleRow.tsx`
- Create: `src/frontend/packages/azblink-ui/primitives/ToggleRow/ToggleRow.module.css`
- Create: `src/frontend/packages/azblink-ui/primitives/ToggleRow/index.ts`
- Modify: `src/frontend/packages/azblink-ui/index.ts`

**Context:** ToggleRow differs from ToggleCard — no icon badge, simpler bordered row with label + description on left, Toggle switch on right. Used for settings toggles across multiple pages.

**Step 1: Write ToggleRow.types.ts**

```typescript
/**
 * ToggleRow type definitions.
 * - Bordered row: label + description on left, Toggle switch on right
 * - Reusable across Settings, Org Profiles, and any toggle-list UI
 */

export interface ToggleRowProps {
  /** Primary label text */
  label: string;
  /** Secondary description text */
  description?: string;
  /** Controlled checked state */
  checked: boolean;
  /** Callback when toggle is switched */
  onChange?: (checked: boolean) => void;
  /** Disable the toggle */
  disabled?: boolean;
  /** Additional CSS class */
  className?: string;
  /** Form field name */
  name?: string;
  /** Test ID */
  'data-testid'?: string;
}
```

**Step 2: Write ToggleRow.module.css**

```css
/* ToggleRow.module.css — bordered row with label + description + toggle */
.root {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-3) var(--space-4);
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-md);
  transition: border-color var(--transition-normal);
}

.root:not(:last-child) {
  margin-bottom: var(--space-3);
}

.root:hover {
  border-color: var(--color-border-default);
}

.textBlock {
  flex: 1;
  min-width: 0;
  margin-right: var(--space-4);
}

.label {
  font-family: var(--font-sans);
  font-size: var(--text-base);
  font-weight: var(--font-medium);
  line-height: var(--leading-snug);
  color: var(--color-text-primary);
}

.description {
  font-family: var(--font-sans);
  font-size: var(--text-xs);
  line-height: var(--leading-normal);
  color: var(--color-text-muted);
  margin-top: var(--space-0_5);
}
```

**Step 3: Write ToggleRow.tsx**

```typescript
/**
 * ToggleRow — bordered row with label, description, and toggle switch.
 * - Composes the Toggle primitive for the switch element
 * - Reusable: Settings page, Org Profiles, any toggle-list UI
 */
'use client';

import { Toggle } from '../Toggle';
import { cn } from '../../utils/cn';
import styles from './ToggleRow.module.css';
import type { ToggleRowProps } from './ToggleRow.types';

export function ToggleRow({
  label,
  description,
  checked,
  onChange,
  disabled,
  className,
  name,
  ...rest
}: ToggleRowProps) {
  return (
    <div
      className={cn(styles.root, className)}
      data-testid={rest['data-testid']}
    >
      <div className={styles.textBlock}>
        <p className={styles.label}>{label}</p>
        {description && <p className={styles.description}>{description}</p>}
      </div>
      <Toggle
        checked={checked}
        onChange={onChange}
        disabled={disabled}
        size="sm"
        aria-label={label}
        name={name}
      />
    </div>
  );
}
```

**Step 4: Write index.ts + add to @azblink/ui exports**

**Step 5: Verify build + commit**

```bash
git add src/frontend/packages/azblink-ui/primitives/ToggleRow/ src/frontend/packages/azblink-ui/index.ts
git commit -m "feat(@azblink/ui): add ToggleRow primitive — label + desc + toggle (Phase 0)"
```

---

### Task 0.13: Phase 0 Review + Phase Commit

**Step 1: Run all backend tests**

Run: `just test-quick -- tests/test_settings.py -v`
Expected: ALL PASS

**Step 2: Run frontend type check**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No errors

**Step 3: Review checklist**
- [ ] All 3 primitives export from `@azblink/ui`?
- [ ] All types in `types/settings.ts` match spec §6?
- [ ] All backend endpoints return `{"ok": true, ...}`?
- [ ] Sensitive fields (passwords) masked in GET response?
- [ ] No hardcoded colors in CSS Modules (all `var(--token)`)?

**Step 4: Commit phase tag**

```bash
git add -A
git commit -m "feat(settings): complete Phase 0 — schema, types, primitives, queries"
```

---

## Phase 1: Page Shell + System Info Section

### Task 1.1: useScrollSpy Hook

**Files:**
- Create: `src/frontend/src/components/features/settings/useScrollSpy.ts`

**Step 1: Write the scroll-spy hook**

```typescript
/**
 * IntersectionObserver-powered scroll-spy hook.
 * - Observes section elements by data-section-id attribute
 * - Returns the ID of the topmost visible section
 * - Supports nav click override (ignore observer briefly)
 */

import { useEffect, useRef, useState, useCallback } from 'react';

export function useScrollSpy(sectionIds: string[]) {
  const [activeSection, setActiveSection] = useState(sectionIds[0] ?? '');
  const overrideRef = useRef<string | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout>>();

  /** Scroll to a section and override the observer temporarily */
  const scrollToSection = useCallback((sectionId: string) => {
    const el = document.getElementById(`section-${sectionId}`);
    if (!el) return;

    overrideRef.current = sectionId;
    setActiveSection(sectionId);
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });

    // Ignore observer for 600ms (smooth scroll duration)
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      overrideRef.current = null;
    }, 600);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (overrideRef.current) return; // skip during nav click

        // Find topmost visible section
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);

        if (visible.length > 0) {
          const id = visible[0].target.getAttribute('data-section-id');
          if (id) setActiveSection(id);
        }
      },
      {
        rootMargin: '-88px 0px -60% 0px',
        threshold: 0,
      },
    );

    // Observe all sections
    for (const id of sectionIds) {
      const el = document.getElementById(`section-${id}`);
      if (el) observer.observe(el);
    }

    return () => {
      observer.disconnect();
      clearTimeout(timeoutRef.current);
    };
  }, [sectionIds]);

  return { activeSection, scrollToSection };
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/useScrollSpy.ts
git commit -m "feat(settings): useScrollSpy hook with IntersectionObserver (Phase 1)"
```

---

### Task 1.2: SettingsSection Wrapper + SettingsNav

**Files:**
- Create: `src/frontend/src/components/features/settings/SettingsSection.tsx`
- Create: `src/frontend/src/components/features/settings/SettingsNav.tsx`

**Step 1: Write SettingsSection**

```typescript
/**
 * SettingsSection — reusable wrapper for each settings page section.
 * - Header: title + description + optional action slot
 * - Body: padded content area
 * - Adds data-section-id for scroll-spy observation
 */

import type { ReactNode } from 'react';

interface SettingsSectionProps {
  sectionId: string;
  title: string;
  description: string;
  headerActions?: ReactNode;
  children: ReactNode;
  /** Optional red title for danger zone */
  danger?: boolean;
}

export function SettingsSection({
  sectionId,
  title,
  description,
  headerActions,
  children,
  danger,
}: SettingsSectionProps) {
  return (
    <section
      id={`section-${sectionId}`}
      data-section-id={sectionId}
      data-testid={`settings-section-${sectionId}`}
      className="rounded-lg border border-border overflow-hidden bg-surface"
    >
      <div className="flex items-start justify-between px-6 py-5 border-b border-border">
        <div>
          <h2 className={`text-lg font-semibold ${danger ? 'text-red-500' : 'text-text'}`}>
            {title}
          </h2>
          <p className="text-sm text-text-secondary mt-1">{description}</p>
        </div>
        {headerActions && <div className="flex items-center gap-3">{headerActions}</div>}
      </div>
      <div className="p-6">{children}</div>
    </section>
  );
}
```

**Step 2: Write SettingsNav**

Implement the 9-item sticky sidebar nav with icons (use Lucide icons). Each item uses `data-section-target` and highlights when `activeSection` matches.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsSection.tsx src/frontend/src/components/features/settings/SettingsNav.tsx
git commit -m "feat(settings): SettingsSection wrapper + SettingsNav with 9 items (Phase 1)"
```

---

### Task 1.3: SystemInfoSection (Absorb Existing Page)

**Files:**
- Create: `src/frontend/src/components/features/settings/sections/SystemInfoSection.tsx`

**Step 1: Extract system status logic from existing settings page**

Read: `src/frontend/src/routes/configuration/settings/index.tsx`

Move `SystemStatusWrapper`, `StatusIcon`, `StatusSkeleton`, and the Authentication/API Config/Build Info cards into `SystemInfoSection.tsx`. This section wraps them inside a `SettingsSection` component.

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/sections/SystemInfoSection.tsx
git commit -m "feat(settings): SystemInfoSection absorbs existing health + build info (Phase 1)"
```

---

### Task 1.4: SettingsManagementPage + Route Wiring

**Files:**
- Create: `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`
- Modify: `src/frontend/src/routes/configuration/settings/index.tsx`

**Step 1: Write SettingsManagementPage**

The page orchestrator that renders:
- Page header with "Reset to Defaults" and "Save All Changes" buttons
- `SettingsLayout` grid (240px + 1fr)
- `SettingsNav` (left)
- `SettingsContent` with `SystemInfoSection` (right, only section for now)
- Uses `useScrollSpy` hook

**Step 2: Update route file to use new page**

Replace the current `SettingsPage` in `routes/configuration/settings/index.tsx` with an import of `SettingsManagementPage`.

**Step 3: Verify in browser**

Run: `just up-bg` (if not running)
Visit: `http://localhost:8081/configuration/settings`
Expected: New page shell with sticky nav (9 items) and System Info section

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsManagementPage.tsx src/frontend/src/routes/configuration/settings/index.tsx
git commit -m "feat(settings): SettingsManagementPage shell + route wiring (Phase 1)"
```

---

### Task 1.5: URL Hash Scroll-To on Mount

**Files:**
- Modify: `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`

**Step 1: Add hash-based scroll on mount**

```typescript
useEffect(() => {
  const hash = window.location.hash.replace('#', '');
  if (hash && SECTION_IDS.includes(hash)) {
    // Delay to let sections render
    setTimeout(() => scrollToSection(hash), 100);
  }
}, []);
```

**Step 2: Verify**

Visit: `http://localhost:8081/configuration/settings#security`
Expected: Page scrolls to security section (placeholder for now)

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): URL hash scroll-to on mount (Phase 1)"
```

---

### Task 1.6: Phase 1 Review

**Step 1: Visual check**
- [ ] 9 nav items visible, System Info highlighted
- [ ] Sticky nav stays when scrolling
- [ ] System Info section shows health + build info
- [ ] URL hash scroll works

**Step 2: Run type check**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No errors

**Step 3: Phase commit**

```bash
git add -A
git commit -m "feat(settings): complete Phase 1 — page shell, nav, scroll-spy, System Info"
```

---

## Phase 2: Form Sections — LDAP, Email, Security

### Task 2.1: FormRow + FormGroup Components

**Files:**
- Create: `src/frontend/src/components/features/settings/FormRow.tsx`
- Create: `src/frontend/src/components/features/settings/FormGroup.tsx`

**Step 1: Write FormRow (2-column CSS Grid)**

```typescript
/**
 * FormRow — 2-column form grid for settings sections.
 * - Default: 2 equal columns
 * - full variant: single column (for textarea/full-width fields)
 */

import type { ReactNode } from 'react';

interface FormRowProps {
  children: ReactNode;
  full?: boolean;
}

export function FormRow({ children, full }: FormRowProps) {
  return (
    <div
      className={`grid gap-4 mb-5 last:mb-0 ${full ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'}`}
    >
      {children}
    </div>
  );
}
```

**Step 2: Write FormGroup (Label + Input + Hint)**

```typescript
/**
 * FormGroup — label + input wrapper with optional hint text.
 * - Pairs with FormRow for 2-column layout
 * - Generates htmlFor + id for a11y
 */

import type { ReactNode } from 'react';

interface FormGroupProps {
  label: string;
  required?: boolean;
  hint?: string;
  htmlFor?: string;
  children: ReactNode;
}

export function FormGroup({ label, required, hint, htmlFor, children }: FormGroupProps) {
  return (
    <div>
      <label htmlFor={htmlFor} className="block text-sm font-medium text-text-secondary mb-2">
        {label}
        {required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      {children}
      {hint && <p className="text-xs text-text-muted mt-1.5">{hint}</p>}
    </div>
  );
}
```

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/settings/FormRow.tsx src/frontend/src/components/features/settings/FormGroup.tsx
git commit -m "feat(settings): FormRow + FormGroup layout components (Phase 2)"
```

---

### Task 2.2: StatusIndicator + TestButton

**Files:**
- Create: `src/frontend/src/components/features/settings/StatusIndicator.tsx`
- Create: `src/frontend/src/components/features/settings/TestButton.tsx`

**Step 1: Write StatusIndicator**

Colored pill with icon for connection status. Uses the color map from spec §7:
- `healthy`: green-500/10 bg, green-500 text, checkmark icon
- `warning`: amber-500/10 bg, amber-500 text, warning icon
- `error`: red-500/10 bg, red-500 text, X icon

**Step 2: Write TestButton**

Dashed-border action button for test-connection / test-email:
- Default: `border-dashed border-zinc-600 text-zinc-500`
- Hover: `border-blue-500 text-blue-500 bg-blue-500/10`

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/settings/StatusIndicator.tsx src/frontend/src/components/features/settings/TestButton.tsx
git commit -m "feat(settings): StatusIndicator + TestButton components (Phase 2)"
```

---

### Task 2.3: LdapSection

**Files:**
- Create: `src/frontend/src/components/features/settings/sections/LdapSection.tsx`

**Step 1: Write the LDAP section**

Uses: `SettingsSection`, `FormRow`, `FormGroup`, `Input` (from @azblink/ui), `ToggleRow` (from @azblink/ui), `StatusIndicator`, `TestButton`.

6 form fields (serverUrl, baseDn, bindDn, bindPassword, userSearchBase, groupSearchBase) in 3 FormRows, plus 2 ToggleRows (verifySsl, connectionPooling).

Header actions: StatusIndicator + TestButton.

All inputs call `updateField('ldap.fieldName', value)` from parent.

**Step 2: Add to SettingsManagementPage**

Wire LdapSection into the content area after SystemInfoSection.

**Step 3: Verify in browser**

Visit: `http://localhost:8081/configuration/settings`
Expected: LDAP section renders with form fields, toggle rows, status pill, test button

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/settings/sections/LdapSection.tsx src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): LdapSection with forms, toggles, status, test (Phase 2)"
```

---

### Task 2.4: EmailSection

**Files:**
- Create: `src/frontend/src/components/features/settings/sections/EmailSection.tsx`

**Step 1: Write Email section**

5 form fields (smtpHost, smtpPort as Select, username, password, fromAddress, fromName) + 1 ToggleRow (useTls). Header action: TestButton for "Send Test Email".

**Step 2: Add to page + verify + commit**

```bash
git add src/frontend/src/components/features/settings/sections/EmailSection.tsx src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): EmailSection with SMTP form + test email (Phase 2)"
```

---

### Task 2.5: SecuritySection

**Files:**
- Create: `src/frontend/src/components/features/settings/sections/SecuritySection.tsx`

**Step 1: Write Security section**

2 Select fields (sessionTimeout, maxLoginAttempts) + 3 ToggleRows (requireMfa, ipAllowlist, auditApiRequests).

**Step 2: Add to page + verify + commit**

```bash
git add src/frontend/src/components/features/settings/sections/SecuritySection.tsx src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): SecuritySection with selects + toggles (Phase 2)"
```

---

### Task 2.6: Dirty Field Tracking + Settings Data Loading

**Files:**
- Modify: `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`

**Step 1: Wire TanStack Query for settings data**

Add `useSuspenseQuery(settingsQueryOptions())` to load initial settings. Initialize form state from query data.

**Step 2: Implement dirty tracking**

```typescript
const [dirtyFields, setDirtyFields] = useState<Set<string>>(new Set());

function updateField(path: string, value: unknown) {
  setSettings((prev) => {
    // lodash-style set
    const [section, key] = path.split('.');
    return {
      ...prev,
      [section]: { ...(prev as any)[section], [key]: value },
    };
  });
  setDirtyFields((prev) => new Set(prev).add(path));
}
```

**Step 3: Pass updateField to all section components**

**Step 4: Verify dirty tracking**

Change a field → "Save All" button should become active. No changes → disabled.

**Step 5: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): dirty field tracking + settings data loading (Phase 2)"
```

---

### Task 2.7: Phase 2 Review

**Step 1: Visual check**
- [ ] LDAP, Email, Security sections render with correct fields
- [ ] Select dropdowns work for session timeout and SMTP port
- [ ] Toggle rows switch on/off
- [ ] Dirty tracking activates "Save All" button
- [ ] Scroll-spy highlights correct nav item as you scroll

**Step 2: Run all tests**

Run: `just test-quick -- tests/test_settings.py -v && cd src/frontend && npx tsc --noEmit`
Expected: All pass

**Step 3: Phase commit**

```bash
git add -A
git commit -m "feat(settings): complete Phase 2 — LDAP, Email, Security forms + dirty tracking"
```

---

## Phase 3: Audit, API Keys, Admins, Branding

### Task 3.1: RetentionRadioGroup + AuditSection

**Files:**
- Create: `src/frontend/src/components/features/settings/RetentionRadioGroup.tsx`
- Create: `src/frontend/src/components/features/settings/sections/AuditSection.tsx`

**Step 1: Write RetentionRadioGroup**

Card-style radio selection wrapping the RadioGroup primitive. 3 options: 90 Days, 1 Year, Forever.

**Step 2: Write AuditSection**

Uses RetentionRadioGroup + 2 ToggleRows (siemExport, includeUserDetails).

**Step 3: Add to page + verify + commit**

```bash
git add src/frontend/src/components/features/settings/RetentionRadioGroup.tsx src/frontend/src/components/features/settings/sections/AuditSection.tsx src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): AuditSection with retention radio cards + toggles (Phase 3)"
```

---

### Task 3.2: ApiKeyDisplay + ApiKeysSection

**Files:**
- Create: `src/frontend/src/components/features/settings/ApiKeyDisplay.tsx`
- Create: `src/frontend/src/components/features/settings/sections/ApiKeysSection.tsx`
- Create: `src/frontend/src/lib/queries/api-keys-mutations.ts`

**Step 1: Write api-keys-mutations.ts**

Mutation functions for generate (`POST /api/keys`) and revoke (`DELETE /api/keys/:id`).

**Step 2: Write ApiKeyDisplay**

Masked key value + copy button + revoke button. Copy uses `navigator.clipboard.writeText()`.

**Step 3: Write ApiKeysSection**

Uses `useSuspenseQuery(apiKeysQueryOptions())` for key list. Header action: "Generate New Key" button. Renders ApiKeyDisplay[] for each active key.

**Step 4: Add to page + verify + commit**

```bash
git add src/frontend/src/components/features/settings/ApiKeyDisplay.tsx src/frontend/src/components/features/settings/sections/ApiKeysSection.tsx src/frontend/src/lib/queries/api-keys-mutations.ts src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): ApiKeysSection with generate, copy, revoke (Phase 3)"
```

---

### Task 3.3: AdminItem + AdminsSection

**Files:**
- Create: `src/frontend/src/components/features/settings/AdminItem.tsx`
- Create: `src/frontend/src/components/features/settings/sections/AdminsSection.tsx`

**Step 1: Write AdminItem**

Avatar (initials + gradient background) + name + email + role badge. Uses `getInitials()` from `lib/utils/user-helpers.ts` (already exists — DRY!).

Gradient mapping:
- `indigo-purple`: `from-indigo-500 to-purple-500`
- `blue-cyan`: `from-blue-500 to-cyan-500`
- `green-teal`: `from-green-500 to-teal-500`

Role badge uses Badge primitive with amber (owner) or blue (admin).

**Step 2: Write AdminsSection**

For now, render mock admin data (backend admin list endpoint TBD — depends on LDAP group membership implementation). Header action: "Invite Admin" button (placeholder).

**Step 3: Add to page + verify + commit**

```bash
git add src/frontend/src/components/features/settings/AdminItem.tsx src/frontend/src/components/features/settings/sections/AdminsSection.tsx src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): AdminsSection with avatar list + role badges (Phase 3)"
```

---

### Task 3.4: BrandingSection

**Files:**
- Create: `src/frontend/src/components/features/settings/sections/BrandingSection.tsx`

**Step 1: Write BrandingSection**

2 FormRow inputs (companyName, supportEmail) + 1 full FormRow textarea (qrEmailFooter) + 1 ToggleRow (includeLogoInEmails). Uses `Textarea` from @azblink/ui.

**Step 2: Add to page + verify + commit**

```bash
git add src/frontend/src/components/features/settings/sections/BrandingSection.tsx src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): BrandingSection with forms + textarea + toggle (Phase 3)"
```

---

### Task 3.5: Phase 3 Review

**Step 1: Visual check**
- [ ] Retention radio cards highlight selected option
- [ ] API key generates, displays masked, can be copied and revoked
- [ ] Admin list shows avatars with correct gradients + role badges
- [ ] Branding textarea renders with existing content

**Step 2: Run all tests + type check**

Run: `just test-quick -- tests/test_settings.py -v && cd src/frontend && npx tsc --noEmit`
Expected: All pass

**Step 3: Phase commit**

```bash
git add -A
git commit -m "feat(settings): complete Phase 3 — Audit, API Keys, Admins, Branding"
```

---

## Phase 4: Danger Zone + Save/Reset + Polish

### Task 4.1: DangerAction + DangerZoneSection

**Files:**
- Create: `src/frontend/src/components/features/settings/DangerAction.tsx`
- Create: `src/frontend/src/components/features/settings/sections/DangerZoneSection.tsx`

**Step 1: Write DangerAction**

Red-bordered card with icon, title, description, and destructive button. Uses `AlertDialog` from @azblink/ui for confirmation before executing.

Color map: `border-red-500/30`, `text-red-500`, button `bg-red-500/10 text-red-500 border-red-500/30`.

**Step 2: Write DangerZoneSection**

2 DangerActions: "Purge All QR Codes" and "Reset All Settings". Section title uses red text (`danger` prop on SettingsSection).

**Step 3: Add to page + verify + commit**

```bash
git add src/frontend/src/components/features/settings/DangerAction.tsx src/frontend/src/components/features/settings/sections/DangerZoneSection.tsx src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): DangerZoneSection with confirmation dialogs (Phase 4)"
```

---

### Task 4.2: Save All + Reset to Defaults Actions

**Files:**
- Create: `src/frontend/src/lib/queries/settings-mutations.ts`
- Modify: `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`

**Step 1: Write settings-mutations.ts**

```typescript
/**
 * Mutation functions for settings page actions.
 * - patchSettings: PATCH /api/settings (dirty fields only)
 * - resetSettings: PUT /api/settings/reset
 * - testLdapConnection: POST /api/settings/ldap/test
 * - testEmail: POST /api/settings/email/test
 */
```

**Step 2: Wire Save All button**

On click: extract dirty fields from `dirtyFields` Set, build PATCH body, send mutation, on success clear dirty set + show toast.

**Step 3: Wire Reset to Defaults button**

On click: show AlertDialog confirmation → on confirm: PUT /api/settings/reset → on success: reload settings query + clear dirty + toast.

**Step 4: Verify save/reset cycle**

1. Change a field → Save All → verify persisted (refresh page, field retains value)
2. Reset to Defaults → verify fields revert

**Step 5: Commit**

```bash
git add src/frontend/src/lib/queries/settings-mutations.ts src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): Save All + Reset to Defaults with mutations (Phase 4)"
```

---

### Task 4.3: Toast Feedback

**Files:**
- Modify: `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`

**Step 1: Add toast notifications for all actions**

Use existing toast pattern (check how other pages do it — likely a simple toast state + CSS animation). All mutations show success/error toast on completion.

Actions that need toasts:
- Save All → "Settings saved successfully" / "Failed to save settings"
- Reset → "Settings reset to defaults"
- Test LDAP → "LDAP connection successful" / "LDAP connection failed: {message}"
- Test Email → "Test email sent" / "Email test failed: {message}"
- Generate API Key → "API key generated — copy it now, it won't be shown again"
- Revoke API Key → "API key revoked"

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): toast feedback for all settings actions (Phase 4)"
```

---

### Task 4.4: Responsive Collapse

**Files:**
- Modify: `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`
- Modify: `src/frontend/src/components/features/settings/SettingsNav.tsx`

**Step 1: Add responsive breakpoint**

At ≤800px:
- Nav: switches from sticky sidebar to horizontal scrolling pills
- FormRow: collapses from 2-column to 1-column
- Layout: switches from 240px + 1fr grid to single column

Use Tailwind responsive classes: `lg:grid-cols-[240px_1fr]`, `lg:sticky`.

**Step 2: Verify at narrow viewport**

Resize browser to <800px width.
Expected: Nav becomes horizontal scroll, forms stack vertically.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsManagementPage.tsx src/frontend/src/components/features/settings/SettingsNav.tsx
git commit -m "feat(settings): responsive collapse at 800px breakpoint (Phase 4)"
```

---

### Task 4.5: Accessibility + data-testid

**Files:**
- Multiple: all settings components

**Step 1: Add data-testid attributes**

All interactive elements get `data-testid`:
- `settings-nav-{sectionId}` on nav items
- `settings-section-{sectionId}` on sections (already done in SettingsSection)
- `settings-field-{path}` on inputs (e.g., `settings-field-ldap-serverUrl`)
- `settings-toggle-{path}` on toggles
- `settings-btn-save`, `settings-btn-reset`, `settings-btn-test-ldap`, etc.

**Step 2: Add accessibility attributes**

- `role="alert"` on error containers
- `aria-live="polite"` on toast container
- `htmlFor` + `id` pairs on all FormGroup label/input
- `fieldset` + `legend` on retention radio group
- `aria-current="true"` on active nav item

**Step 3: Add beforeunload warning**

```typescript
useEffect(() => {
  const handler = (e: BeforeUnloadEvent) => {
    if (dirtyFields.size > 0) {
      e.preventDefault();
      e.returnValue = '';
    }
  };
  window.addEventListener('beforeunload', handler);
  return () => window.removeEventListener('beforeunload', handler);
}, [dirtyFields.size]);
```

**Step 4: Commit**

```bash
git add -A
git commit -m "feat(settings): data-testid, a11y, unsaved changes warning (Phase 4)"
```

---

### Task 4.6: Final Phase 4 Review

**Step 1: Full test suite**

Run: `just test-quick -- tests/test_settings.py -v`
Expected: ALL PASS

**Step 2: Type check**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No errors

**Step 3: Visual checklist**
- [ ] All 9 sections render correctly
- [ ] Nav scroll-spy highlights as you scroll
- [ ] URL hash scroll-to works (#ldap, #security, etc.)
- [ ] Save All persists changes (reload to verify)
- [ ] Reset to Defaults reverts (with confirmation)
- [ ] Test Connection shows status
- [ ] API key generate → copy → revoke flow works
- [ ] Danger Zone has confirmation dialogs
- [ ] Toast notifications appear for all actions
- [ ] Responsive: <800px shows horizontal nav + stacked forms
- [ ] No unsaved changes warning when clean, shows when dirty

**Step 4: DRY audit**
- [ ] No duplicate helper functions (check `getInitials` usage)
- [ ] No hardcoded colors in CSS Modules
- [ ] No repeated component patterns that should be extracted

**Step 5: Final commit**

```bash
git add -A
git commit -m "feat(settings): complete Phase 4 — Danger Zone, Save/Reset, responsive, a11y"
```

---

## Post-Migration Checklist

- [ ] Update `docs/domains/split-panel-migrations.md` — mark settings as complete, update shared assets registry
- [ ] Update `.cursor/rules/settings-migration-workflow.mdc` with any new learnings
- [ ] Verify legacy `/settings` redirect still works → `/configuration/settings`
- [ ] Cross-page navigation: Org Profiles "Edit global QR settings" → `/configuration/settings#audit`
- [ ] Delete `new-migration-ui/SETTINGS_MIGRATION_SPEC.md` and `settings-content-only.html` (spec consumed)
