# Monorepo Consolidation: azb-ldap-integration → src/ued-sync/

**Date:** 2026-02-13
**Status:** Approved
**Approach:** Copy-and-Integrate (Approach A)

## Motivation

- **Unified deployment:** Single `just up` starts all services from one compose stack
- **Developer experience:** Single git checkout, single CI, shared tooling
- **Simplified architecture:** One product, one repo — reduces mental model overhead

## Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Service boundary | Keep UED Sync as separate container | Preserves independent scaling, stateless worker design |
| Git history | Archive old repo, copy files fresh | Clean monorepo history; old history accessible via archived repo |
| Placement | `src/ued-sync/` (peer to `src/backend/`) | Natural extension of existing `src/{backend,frontend,cli}` pattern |
| Dev stack | Add to existing docker-compose.yml | Single `just up` for full stack |
| Python deps | Keep separate `pyproject.toml`/`uv` | Different dep profiles, different runtimes — no mixing |

## Directory Structure

```
src/ued-sync/                       # UED Sync API (stateless LDAP provisioner)
├── src/ued_sync/                   # FastAPI app source (~1,032 lines)
│   ├── main.py                     # Entry point, middleware setup
│   ├── config.py                   # Settings (API key, rate limits)
│   ├── schema.py                   # LDAP config & schema models, template interpolation
│   ├── ldap_ops.py                 # GenericLdapClient — core LDAP operations
│   ├── auth.py                     # API key authentication
│   ├── logging.py                  # Structured logging (structlog)
│   ├── password_utils.py           # Password hashing (SSHA, MD5, PLAIN)
│   ├── routers/                    # health.py, sync.py, batch.py
│   └── middleware/                 # logging.py, rate_limit.py
├── tests/                          # Unit + API + integration tests (~4,480 lines)
├── e2e/                            # Bruno CLI e2e tests
├── docs/                           # UED-specific design plans, specs
├── scripts/                        # Client generation, verification scripts
├── clients/typescript/             # Generated TypeScript client
├── openspec/                       # OpenAPI spec versioning
├── pyproject.toml                  # uv-managed Python deps
├── uv.lock                         # Frozen dependency lock
├── justfile                        # UED-standalone recipes (preserved for reference)
├── README.md                       # UED Sync specific docs
└── CHANGELOG.md                    # Version history
```

## Docker Compose Integration

New service added to `deploy/dev/docker-compose.yml`:

- **Service name:** `ued-sync`
- **Container:** `azblink-ued-sync`
- **Network:** `azblink-net` (internal, reachable by main backend at `http://ued-sync:8000`)
- **No host port:** Internal-only service, not exposed via Traefik
- **Hot reload:** Source volume mount + uvicorn `--reload`
- **Health check:** HTTP GET to `/health`
- **No LDAP dependency:** Connects to tenant LDAPs specified per-request

### Dockerfile.ued-sync

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY --from=ghcr.io/astral-sh/uv:latest /uv /usr/local/bin/uv
COPY src/ued-sync/pyproject.toml src/ued-sync/uv.lock ./
RUN uv sync --frozen --no-dev
COPY src/ued-sync/src/ ./src/
RUN useradd --create-home --shell /bin/bash appuser && chown -R appuser:appuser /app
USER appuser
ENV PYTHONPATH=/app/src
ENV PYTHONUNBUFFERED=1
EXPOSE 8000
CMD ["/app/.venv/bin/python", "-m", "uvicorn", "ued_sync.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
```

## Justfile Recipes

New recipes added to monorepo `Justfile`:

| Recipe | Purpose |
|--------|---------|
| `ued-logs` | Follow UED Sync container logs |
| `ued-restart` | Restart UED Sync container |
| `ued-rebuild` | Rebuild UED Sync (after dep changes) |
| `ued-test` | Run unit + API tests (mocked LDAP) |
| `ued-test-integration` | Run integration tests (requires LDAP) |
| `ued-test-cov` | Run tests with coverage report |
| `test-all` | Chain `test` + `ued-test` for full project |

## Environment & Configuration

### No code changes needed

The existing `ued_sync_client.py` and `sync_worker.py` read `ued_api_url` and `ued_api_key` per-tenant from the `tenant_ldap_configs` PostgreSQL table. Service discovery is data-driven — no hardcoded URLs.

When creating a tenant config in the admin UI for local dev:
- `ued_api_url`: `http://ued-sync:8000`
- `ued_api_key`: value of `UED_API_KEY` env var

### .env.example additions

```bash
# === UED Sync API (internal service) ===
UED_API_KEY=dev-ued-api-key
UED_ENCRYPTION_KEY=  # Generate: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

## Test Strategy

| Scope | Location | Command | What it tests |
|-------|----------|---------|---------------|
| Main backend | `tests/` | `just test` | Directory API against real Docker stack |
| UED Sync unit/API | `src/ued-sync/tests/` | `just ued-test` | Endpoints with mocked LDAP |
| UED Sync integration | `src/ued-sync/tests/integration/` | `just ued-test-integration` | Real LDAP operations |
| UED Sync e2e | `src/ued-sync/e2e/` | `just ued-test-e2e` | HTTP scenarios via Bruno CLI |
| Full project | — | `just test-all` | Chains `test` + `ued-test` |

Cross-service end-to-end tests (main backend → UED Sync → LDAP) are out of scope for this consolidation.

## Migration Checklist

### Files created

- `deploy/dev/Dockerfile.ued-sync`
- `src/ued-sync/` (entire directory, copied from `azb-ldap-integration`)

### Files modified

- `deploy/dev/docker-compose.yml` — add `ued-sync` service
- `deploy/dev/.env.example` — add UED Sync env vars
- `Justfile` — add `ued-*` recipes + `test-all`
- `CLAUDE.md` — add UED Sync service section, hot reload rules, test commands

### Files NOT modified

- `src/backend/ued_sync_client.py` — per-tenant URL, no changes needed
- `src/backend/sync_worker.py` — reads config from DB, no changes needed
- `src/backend/config.py` — UED Sync has its own config
- `package.json` — npm workspaces are frontend-only

### Copied from azb-ldap-integration

```
src/ued_sync/      → src/ued-sync/src/ued_sync/
tests/             → src/ued-sync/tests/
e2e/               → src/ued-sync/e2e/
docs/              → src/ued-sync/docs/
scripts/           → src/ued-sync/scripts/
clients/           → src/ued-sync/clients/
openspec/          → src/ued-sync/openspec/
pyproject.toml     → src/ued-sync/pyproject.toml
uv.lock            → src/ued-sync/uv.lock
justfile           → src/ued-sync/justfile
README.md          → src/ued-sync/README.md
CHANGELOG.md       → src/ued-sync/CHANGELOG.md
```

### NOT copied

| File | Reason |
|------|--------|
| `.env`, `.env.example` | Env vars move to monorepo `.env.example` |
| `Dockerfile` | Replaced by `deploy/dev/Dockerfile.ued-sync` |
| `docker-compose.yml` | Replaced by service entry in monorepo compose |
| `.git/` | Fresh start — old repo archived |
| `ldap_provision.py`, `test_ldap.py`, `ued_provision.py` | Legacy/superseded scripts |

### Post-migration verification

1. Archive `azb-ldap-integration` on GitHub
2. Update `src/ued-sync/README.md` to note monorepo context
3. `just up` starts all 7 services healthy
4. `just ued-test` passes inside the container
5. Main backend reaches UED Sync at `http://ued-sync:8000/health`

## Hot Reload Rules

| Change Type | Action Required | Command |
|-------------|-----------------|---------|
| `src/ued-sync/src/**/*.py` | None — auto reload | (wait ~1s) |
| `src/ued-sync/pyproject.toml` | Rebuild UED Sync | `just ued-rebuild` |
