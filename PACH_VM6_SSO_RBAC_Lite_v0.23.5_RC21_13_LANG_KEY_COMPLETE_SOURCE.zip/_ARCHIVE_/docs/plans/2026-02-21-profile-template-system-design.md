# Profile Template System — Architecture Design

**Date:** 2026-02-21
**Status:** Approved

## Problem

UED Sync is schema-agnostic — every caller must construct and send the full
`ProvisioningSchema` payload inline. The PJSIP schema registry (built 2026-02-21)
solves this for PJSIP, but two critical gaps remain:

1. **No legacy SIP schema** — 100% of real SIP entries on 192.168.122.89 use
   `AsteriskSIPUser` (chan_sip). Callers must construct 20+ line JSON schemas inline.
2. **No XMPP-only schema** — XMPP auth is just `posixAccount` + `userPassword`
   (LDAP bind), but callers don't know this and over-provision with SIP attributes.
3. **`AstAccountRealmedPassword` broken** — E2E testing proved 80% of manually
   provisioned entries have plaintext instead of `MD5(extension:realm:password)`.
4. **Backend always sends inline schemas** — `tenant_ldap_configs` has no
   `schema_name` support; every tenant stores full inline schema in `schema_config` JSONB.

## Decisions

- **3 built-in schemas**: `pjsip-combined` (existing), `sip-legacy` (new), `xmpp-only` (new)
- **Auto-compute realmed password**: `sip-legacy` includes `prepare_user_data()` that
  computes `MD5(extension:realm:password)` for `AstAccountRealmedPassword`
- **`schema_name` on tenant_ldap_configs**: Backend can reference built-in schemas by name
  instead of storing inline JSON. Mutually exclusive with `schema_config`.
- **No separate templates table**: The registry IS the template system. Custom schemas
  remain possible via inline `schema_config`.
- **Pre-processing hook pattern**: Schema modules can export `prepare_user_data()` for
  derived field computation. Router calls it before `build_attributes()`.

## Architecture

### Schema Registry (Extended)

```
src/ued_sync/schemas/
├── __init__.py        # Registry: get_schema(name), list_schemas()
├── pjsip.py           # pjsip_combined_schema() — existing
├── sip_legacy.py      # sip_legacy_schema() + prepare_user_data() — NEW
└── xmpp.py            # xmpp_standard_schema() — NEW
```

### Data Flow — schema_name Resolution

```
Backend API → tenant_ldap_configs.schema_name = "sip-legacy"
    → Sync Worker reads config, passes schema_name to UED Client
    → UED Client sends {"schema_name": "sip-legacy"} (no inline schema)
    → UED Sync API validates via model_post_init → get_schema("sip-legacy")
    → Router calls prepare_user_data() → auto-computes sip_realmed_password
    → build_attributes() → LDAP write with correct MD5 digest
```

### Backend Integration

```sql
-- migrations/011_ued_schema_name.sql
ALTER TABLE tenant_ldap_configs ADD COLUMN schema_name TEXT;
ALTER TABLE tenant_ldap_configs ALTER COLUMN schema_config DROP NOT NULL;
ALTER TABLE tenant_ldap_configs ADD CONSTRAINT chk_schema_source CHECK (
    schema_config IS NOT NULL OR schema_name IS NOT NULL
);
```

### Error Handling

- Backend validates exactly one schema source (Pydantic model_validator)
- UED validates schema_name resolves (model_post_init → get_schema())
- Unknown schema_name → 422 from UED → sync event marked failed, not retryable
- Backend does NOT validate schema names — allows UED registry to evolve independently

## Files Changed

### New
- `src/ued-sync/src/ued_sync/schemas/sip_legacy.py`
- `src/ued-sync/src/ued_sync/schemas/xmpp.py`
- `src/ued-sync/tests/test_sip_legacy.py`
- `src/ued-sync/tests/integration/test_sip_legacy_provisioning.py`
- `migrations/011_ued_schema_name.sql`

### Modified
- `src/ued-sync/src/ued_sync/schemas/__init__.py`
- `src/ued-sync/src/ued_sync/routers/sync.py`
- `src/ued-sync/tests/test_schema_registry.py`
- `src/backend/orgdb.py`
- `src/backend/main.py`
- `src/backend/ued_sync_client.py`
- `src/backend/sync_worker.py`
