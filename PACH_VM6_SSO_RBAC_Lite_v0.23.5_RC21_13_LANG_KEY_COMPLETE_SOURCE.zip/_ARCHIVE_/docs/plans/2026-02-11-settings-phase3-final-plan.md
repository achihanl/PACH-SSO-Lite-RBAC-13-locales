# Settings Migration — Phase 3 (Final): All Remaining Sections + Save/Reset + Polish

> Consolidates original Phase 3 (Audit, API Keys, Admins, Branding) and Phase 4
> (Danger Zone, Save/Reset, Responsive, A11y) into a single execution phase.

## Overview

- **10 tasks** across 7 batches
- **6 new files** created, **3 existing files** modified
- Backend endpoints already exist for all features (settings CRUD, API keys CRUD)
- All types already defined in `src/frontend/src/types/settings.ts` (Phase 0)
- Query keys already defined in `src/frontend/src/lib/queries/keys.ts`

## Dependencies & Ordering

```
Batch 1: [3.0] Save/Reset + Toasts (foundation — unblocks testing)
Batch 2: [3.1 + 3.2] BrandingSection + AuditSection (parallel, simple)
Batch 3: [3.3 + 3.4] AdminsSection + DangerZoneSection (parallel, medium)
Batch 4: [3.5] ApiKeysSection + query hooks (complex, focused)
Batch 5: [3.6] Wire all 5 sections into SettingsManagementPage
Batch 6: [3.7 + 3.8] Responsive collapse + Accessibility (parallel, polish)
Batch 7: [3.9] Final review (tsc + backend tests + visual scan)
```

---

## Task 3.0 — Save/Reset Mutations + Toast Feedback

**Modifies:** `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`

### Save All Changes button

Wire the existing `patchSettings()` from `lib/queries/settings.ts`:

```tsx
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { patchSettings, resetSettings } from '@/lib/queries/settings';
import { queryKeys } from '@/lib/queries/keys';

// Inside component:
const queryClient = useQueryClient();

const saveMutation = useMutation({
  mutationFn: () => {
    // Build PATCH body from dirty fields — only include changed sections/keys
    const body: Record<string, Record<string, unknown>> = {};
    for (const path of dirtyFields) {
      const [section, key] = path.split('.');
      if (!body[section]) body[section] = {};
      body[section][key] = (settings as Record<string, Record<string, unknown>>)[section][key];
    }
    return patchSettings(body);
  },
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.settings });
    toast.success('Settings saved');
  },
  onError: (err: Error) => {
    toast.error(`Save failed: ${err.message}`);
  },
});
```

Save button wiring:
```tsx
<Button
  size="sm"
  disabled={!hasDirtyFields || saveMutation.isPending}
  loading={saveMutation.isPending}
  leftIcon={<Save className="h-4 w-4" />}
  onClick={() => saveMutation.mutate()}
>
  Save All Changes
</Button>
```

### Reset to Defaults button

Uses `AlertDialog` for confirmation, then calls `resetSettings()`:

```tsx
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction,
} from '@azblink/ui';

const [resetDialogOpen, setResetDialogOpen] = useState(false);

const resetMutation = useMutation({
  mutationFn: resetSettings,
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.settings });
    toast.success('Settings reset to defaults');
    setResetDialogOpen(false);
  },
  onError: (err: Error) => {
    toast.error(`Reset failed: ${err.message}`);
  },
});
```

AlertDialog positioned after the layout grid:
```tsx
<AlertDialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
  <AlertDialogContent>
    <AlertDialogHeader>
      <AlertDialogTitle>Reset All Settings?</AlertDialogTitle>
      <AlertDialogDescription>
        This will reset ALL settings to factory defaults. This cannot be undone.
        Your LDAP, email, security, audit, and branding configuration will be lost.
      </AlertDialogDescription>
    </AlertDialogHeader>
    <AlertDialogFooter>
      <AlertDialogCancel>Cancel</AlertDialogCancel>
      <AlertDialogAction
        onClick={() => resetMutation.mutate()}
        className="bg-red-600 hover:bg-red-700"
      >
        {resetMutation.isPending ? 'Resetting...' : 'Reset to Defaults'}
      </AlertDialogAction>
    </AlertDialogFooter>
  </AlertDialogContent>
</AlertDialog>
```

Reset button:
```tsx
<Button
  variant="outline"
  size="sm"
  onClick={() => setResetDialogOpen(true)}
  leftIcon={<RotateCcw className="h-4 w-4" />}
>
  Reset to Defaults
</Button>
```
(Remove `disabled` — it was a Phase 1/2 placeholder.)

### Toast additions for existing test actions

Update `handleTestLdap`:
```tsx
const handleTestLdap = useCallback(async () => {
  setTestingLdap(true);
  try {
    const result = await testLdapConnection();
    if (result.status === 'healthy') {
      setLdapStatus('healthy');
      toast.success('LDAP connection healthy');
    } else {
      setLdapStatus('error');
      toast.error(`LDAP: ${result.message}`);
    }
  } catch (err) {
    setLdapStatus('error');
    toast.error(`LDAP test failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
  } finally {
    setTestingLdap(false);
  }
}, []);
```

Update `handleTestEmail`:
```tsx
const handleTestEmail = useCallback(async () => {
  setTestingEmail(true);
  try {
    const result = await testEmailConnection();
    if (result.status === 'sent') {
      toast.success('Test email sent');
    } else {
      toast.error(`Email: ${result.message}`);
    }
  } catch (err) {
    toast.error(`Email test failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
  } finally {
    setTestingEmail(false);
  }
}, []);
```

---

## Task 3.1 — BrandingSection

**Creates:** `src/frontend/src/components/features/settings/sections/BrandingSection.tsx`

### Props interface

```tsx
interface BrandingSectionProps {
  settings: BrandingSettings;
  onFieldChange: (key: keyof BrandingSettings, value: string | boolean) => void;
}
```

### Layout

```
┌─────────────────────────────────────────────┐
│ Branding — Customize organization identity  │
├─────────────────────────────────────────────┤
│ ┌─ Company Name ──┐ ┌─ Support Email ────┐ │
│ │ Input            │ │ Input (type=email) │ │
│ └─────────────────┘ └────────────────────┘ │
│ ┌─ QR Email Footer (full width) ─────────┐ │
│ │ Textarea (3 rows)                       │ │
│ │ hint: "Shown at bottom of QR emails"    │ │
│ └─────────────────────────────────────────┘ │
│ ┌─ Include Logo in Emails toggle ────────┐ │
│ └─────────────────────────────────────────┘ │
└─────────────────────────────────────────────┘
```

### Imports

```tsx
import { Input, Textarea, ToggleRow } from '@azblink/ui';
import { SettingsSection } from '../SettingsSection';
import { FormRow } from '../FormRow';
import { FormGroup } from '../FormGroup';
import type { BrandingSettings } from '@/types/settings';
```

---

## Task 3.2 — AuditSection

**Creates:** `src/frontend/src/components/features/settings/sections/AuditSection.tsx`

### Props interface

```tsx
interface AuditSectionProps {
  settings: AuditSettings;
  onFieldChange: (key: keyof AuditSettings, value: string | boolean) => void;
}
```

### Layout

```
┌──────────────────────────────────────────────┐
│ Audit & Logging — Configure log retention    │
├──────────────────────────────────────────────┤
│ ┌─ Log Retention Period ───────────────────┐ │
│ │ RadioGroup (3 options):                  │ │
│ │   ○ 90 days                              │ │
│ │   ○ 1 year                               │ │
│ │   ○ Forever                              │ │
│ │ legend: "How long to retain audit logs"  │ │
│ └──────────────────────────────────────────┘ │
│ ┌─ SIEM Export toggle ─────────────────────┐ │
│ ┌─ Include User Details toggle ────────────┐ │
│ │ desc: "Include user PII in log entries"  │ │
│ └──────────────────────────────────────────┘ │
└──────────────────────────────────────────────┘
```

### RadioGroup options

```tsx
const RETENTION_OPTIONS: RadioOption[] = [
  { value: '90', label: '90 days' },
  { value: '365', label: '1 year' },
  { value: 'forever', label: 'Forever' },
];
```

Use existing `RadioGroup` primitive from `@azblink/ui` directly — no extra wrapper needed.
The `RadioGroup` accepts `legend`, `legendHidden`, `options`, `value`, `onChange`.

---

## Task 3.3 — AdminsSection + AdminItem

**Creates:** `src/frontend/src/components/features/settings/sections/AdminsSection.tsx`

### Props interface

```tsx
interface AdminsSectionProps {
  // No props from AllSettings — admins are standalone data
  // Mock data hardcoded for now (backend admin list endpoint depends on LDAP groups)
}
```

### AdminItem inline component

```tsx
function AdminItem({ admin }: { admin: Administrator }) {
  const gradientMap: Record<AvatarGradient, string> = {
    'indigo-purple': 'from-indigo-500 to-purple-500',
    'blue-cyan': 'from-blue-500 to-cyan-500',
    'green-teal': 'from-green-500 to-teal-500',
  };

  return (
    <div className="flex items-center gap-4 py-3">
      {/* Initials avatar */}
      <div className={`flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br ${gradientMap[admin.avatarGradient]} text-white text-sm font-medium`}>
        {admin.initials}
      </div>
      {/* Name + email */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-text truncate">{admin.name}</p>
        <p className="text-xs text-text-secondary truncate">{admin.email}</p>
      </div>
      {/* Role badge */}
      <Badge variant={admin.role === 'owner' ? 'default' : 'secondary'}>
        {admin.role}
      </Badge>
    </div>
  );
}
```

### Mock data

```tsx
const MOCK_ADMINS: Administrator[] = [
  {
    id: '1', name: 'Mei Chen', initials: 'MC', email: 'mei@azblink.com',
    role: 'owner', avatarGradient: 'indigo-purple',
  },
  {
    id: '2', name: 'Robert Park', initials: 'RP', email: 'robert@azblink.com',
    role: 'admin', avatarGradient: 'blue-cyan',
  },
];
```

### Layout

```
┌────────────────────────────────────────────────────┐
│ Administrators — [Invite Admin] (disabled)         │
├────────────────────────────────────────────────────┤
│  [MC] Mei Chen / mei@azblink.com          [owner]  │
│  ─────────────────────────────────────────────────  │
│  [RP] Robert Park / robert@azblink.com    [admin]  │
└────────────────────────────────────────────────────┘
```

Uses `divide-y` for item separators. Header action: disabled "Invite Admin" button with `UserPlus` icon.

---

## Task 3.4 — DangerZoneSection + DangerAction

**Creates:** `src/frontend/src/components/features/settings/sections/DangerZoneSection.tsx`

### Props interface

```tsx
interface DangerZoneSectionProps {
  onPurgeQrCodes: () => void;
  purgingQrCodes: boolean;
  onResetSettings: () => void;
  resettingSettings: boolean;
}
```

### DangerAction inline component

```tsx
function DangerAction({
  title, description, buttonLabel, onConfirm, loading, confirmTitle, confirmDescription,
}: {
  title: string;
  description: string;
  buttonLabel: string;
  onConfirm: () => void;
  loading: boolean;
  confirmTitle: string;
  confirmDescription: string;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="flex items-start justify-between gap-4 rounded-lg border border-red-200 dark:border-red-900/40 p-4">
      <div>
        <p className="text-sm font-medium text-red-600 dark:text-red-400">{title}</p>
        <p className="text-xs text-text-secondary mt-1">{description}</p>
      </div>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <Button variant="danger" size="sm" onClick={() => setOpen(true)} disabled={loading}>
          {loading ? 'Processing...' : buttonLabel}
        </Button>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{confirmTitle}</AlertDialogTitle>
            <AlertDialogDescription>{confirmDescription}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { onConfirm(); setOpen(false); }}>
              {buttonLabel}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
```

### Two actions

1. **Purge All QR Codes**
   - "Permanently invalidate all issued QR provisioning codes"
   - Backend: `POST /api/qr/purge` (if exists, or placeholder toast for now)
2. **Reset All Settings**
   - "Restore all settings to factory defaults"
   - Reuses the same `resetSettings()` mutation from Task 3.0

Note: DangerZoneSection uses `danger={true}` on its SettingsSection wrapper.

---

## Task 3.5 — ApiKeysSection + Query Hooks

**Creates:**
1. `src/frontend/src/lib/queries/api-keys.ts`
2. `src/frontend/src/components/features/settings/sections/ApiKeysSection.tsx`

### Query hooks (`lib/queries/api-keys.ts`)

```tsx
import { queryOptions } from '@tanstack/react-query';
import { getApi } from '../api-client';
import { queryKeys } from './keys';
import type { ApiKeysResponse, ApiKeyGenerateResponse } from '@/types/settings';

/** GET /api/keys — list active API keys (masked) */
export const apiKeysQueryOptions = () =>
  queryOptions<ApiKeysResponse>({
    queryKey: queryKeys.apiKeys,
    queryFn: () => getApi().get<ApiKeysResponse>('/keys'),
    staleTime: 30_000,
  });

/** POST /api/keys — generate new API key */
export async function generateApiKey(): Promise<ApiKeyGenerateResponse> {
  return getApi().post<ApiKeyGenerateResponse>('/keys');
}

/** DELETE /api/keys/:id — revoke API key */
export async function revokeApiKey(keyId: string): Promise<void> {
  await getApi().delete(`/keys/${keyId}`);
}
```

### ApiKeysSection component

```tsx
interface ApiKeysSectionProps {
  // Self-contained — manages own query + mutations
}
```

### ApiKeyRow inline component

```tsx
function ApiKeyRow({ apiKey, onRevoke, revoking }: {
  apiKey: ApiKey;
  onRevoke: (id: string) => void;
  revoking: boolean;
}) {
  const handleCopy = () => {
    navigator.clipboard.writeText(apiKey.maskedKey);
    toast.info('Key prefix copied');
  };

  return (
    <div className="flex items-center gap-4 py-3">
      <div className="flex-1 min-w-0">
        <code className="text-sm font-mono text-text">{apiKey.maskedKey}</code>
        <p className="text-xs text-text-secondary mt-0.5">
          Created by {apiKey.createdBy} · {new Date(apiKey.createdAt).toLocaleDateString()}
          {apiKey.lastUsedAt && ` · Last used ${new Date(apiKey.lastUsedAt).toLocaleDateString()}`}
        </p>
      </div>
      <Button variant="ghost" size="sm" onClick={handleCopy}>
        <Copy className="h-3.5 w-3.5" />
      </Button>
      <Button variant="danger" size="sm" onClick={() => onRevoke(apiKey.id)} disabled={revoking}>
        Revoke
      </Button>
    </div>
  );
}
```

### One-time key display

After generating a new key, show the full key in a prominent alert with copy button:

```tsx
{newKey && (
  <div className="rounded-lg border border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/20 p-4 mb-4">
    <p className="text-sm font-medium text-amber-800 dark:text-amber-200 mb-2">
      New API key generated — copy it now, it won't be shown again
    </p>
    <div className="flex items-center gap-2">
      <code className="flex-1 text-sm font-mono bg-white dark:bg-black/20 rounded px-3 py-1.5 break-all">
        {newKey.fullKey}
      </code>
      <Button size="sm" onClick={() => { navigator.clipboard.writeText(newKey.fullKey); toast.success('API key copied'); }}>
        <Copy className="h-3.5 w-3.5" />
      </Button>
    </div>
  </div>
)}
```

### Mutations inside the component

```tsx
const queryClient = useQueryClient();

const generateMutation = useMutation({
  mutationFn: generateApiKey,
  onSuccess: (data) => {
    setNewKey(data.key);
    queryClient.invalidateQueries({ queryKey: queryKeys.apiKeys });
    toast.success('API key generated');
  },
  onError: (err: Error) => toast.error(`Generate failed: ${err.message}`),
});

const revokeMutation = useMutation({
  mutationFn: revokeApiKey,
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.apiKeys });
    toast.success('API key revoked');
  },
  onError: (err: Error) => toast.error(`Revoke failed: ${err.message}`),
});
```

Header action: "Generate New Key" button with `Plus` icon.

---

## Task 3.6 — Wire All 5 Sections into Page

**Modifies:** `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`

### Changes

1. Import all 5 new section components
2. Replace `remainingPlaceholders` logic with real section components
3. Wire `BrandingSection` and `AuditSection` with `onFieldChange` callbacks (same pattern as LDAP/Email/Security)
4. `AdminsSection` and `ApiKeysSection` — no props needed (self-contained)
5. `DangerZoneSection` — receives `onPurgeQrCodes`, `purgingQrCodes`, `onResetSettings` (reuses `resetMutation` from Task 3.0), `resettingSettings`

### QR purge handler

```tsx
const handlePurgeQrCodes = useCallback(async () => {
  // TODO: Wire to POST /api/qr/purge when backend endpoint exists
  toast.info('QR code purge not yet implemented');
}, []);
```

### Wiring pattern

```tsx
<AuditSection
  settings={settings.audit}
  onFieldChange={(key, value) => updateField('audit', key, value)}
/>

<ApiKeysSection />

<AdminsSection />

<BrandingSection
  settings={settings.branding}
  onFieldChange={(key, value) => updateField('branding', key, value)}
/>

<DangerZoneSection
  onPurgeQrCodes={handlePurgeQrCodes}
  purgingQrCodes={false}
  onResetSettings={() => setResetDialogOpen(true)}
  resettingSettings={resetMutation.isPending}
/>
```

---

## Task 3.7 — Responsive Collapse

**Modifies:**
- `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`
- `src/frontend/src/components/features/settings/SettingsNav.tsx`

### SettingsManagementPage layout change

```tsx
// Before (Phase 2):
<div className="grid grid-cols-[240px_1fr] gap-8">

// After:
<div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-8">
```

### SettingsNav dual mode

Add a `mode` derived from viewport, or simpler: render both modes and hide with responsive classes.

```tsx
export function SettingsNav({ activeSection, onSectionClick, dirtyCount = 0 }: SettingsNavProps) {
  return (
    <>
      {/* Desktop: card sidebar (hidden on mobile) */}
      <nav
        className="sticky top-24 self-start w-60 shrink-0 rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden hidden lg:block"
        aria-label="Settings navigation"
      >
        {/* ... existing card nav content ... */}
      </nav>

      {/* Mobile: horizontal pill row (hidden on desktop) */}
      <nav
        className="flex overflow-x-auto gap-2 pb-2 lg:hidden"
        aria-label="Settings navigation"
      >
        {NAV_ITEMS.map(({ id, label }) => (
          <button
            key={id}
            type="button"
            onClick={() => onSectionClick(id)}
            className={[
              'shrink-0 rounded-full px-4 py-1.5 text-sm font-medium transition-colors whitespace-nowrap',
              activeSection === id
                ? 'bg-[var(--color-primary-bg)] text-[var(--color-primary)]'
                : 'text-[var(--color-text-secondary)] bg-[var(--color-bg-secondary)] hover:bg-[var(--color-bg-tertiary)]',
            ].join(' ')}
            aria-current={activeSection === id ? 'true' : undefined}
          >
            {label}
          </button>
        ))}
      </nav>
    </>
  );
}
```

Mobile pills: no icons, compact, horizontally scrollable. The `sticky` sidebar behavior is only on `lg:`.

### Header buttons stacking

```tsx
<div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
```

---

## Task 3.8 — Accessibility + data-testid

**Modifies:** Multiple settings files

### aria-current on desktop nav

Add to the existing desktop nav button:
```tsx
aria-current={isActive ? 'true' : undefined}
```

### beforeunload warning

Add to `SettingsManagementPage.tsx`:
```tsx
useEffect(() => {
  const handler = (e: BeforeUnloadEvent) => {
    if (dirtyFields.size > 0) {
      e.preventDefault();
    }
  };
  window.addEventListener('beforeunload', handler);
  return () => window.removeEventListener('beforeunload', handler);
}, [dirtyFields.size]);
```

### data-testid additions

Follow existing convention (`data-testid="settings-..."`) on all interactive elements:

| Element | data-testid |
|---------|-------------|
| Save button | `settings-btn-save` |
| Reset button | `settings-btn-reset` |
| Test LDAP button | `settings-btn-test-ldap` |
| Test Email button | `settings-btn-test-email` |
| Generate API key | `settings-btn-generate-key` |
| Each nav item | `settings-nav-{sectionId}` |
| Each section | `settings-section-{sectionId}` (already exists) |

### fieldset + legend on RadioGroup

The `RadioGroup` primitive already supports `legend` and `legendHidden` props. Ensure `AuditSection` passes:
```tsx
<RadioGroup
  options={RETENTION_OPTIONS}
  value={settings.retentionPolicy}
  onChange={(val) => onFieldChange('retentionPolicy', val)}
  legend="How long to retain audit logs"
  name="audit-retention"
/>
```

---

## Task 3.9 — Final Review

### Checklist

1. **TypeScript:** `npx tsc --noEmit` — 0 settings-related errors
2. **Backend tests:** `pytest tests/test_settings.py -v --tb=short` — all pass
3. **Visual scan:** Sections render correctly with form fields, toggles, selects
4. **Save flow:** Dirty fields → Save → toast → fields reset
5. **Reset flow:** Confirm dialog → Reset → toast → all fields back to defaults
6. **API keys:** Generate → one-time key display → list updated → revoke → toast
7. **Responsive:** Narrow viewport → pills replace sidebar, forms stack
8. **A11y:** aria-current on active nav, aria-describedby on hints, beforeunload warning
9. **No pre-existing regressions:** Confirm the 3 unrelated TS errors haven't changed

---

## File Summary

### New files (6)

| File | Task | Lines (est) |
|------|------|-------------|
| `sections/BrandingSection.tsx` | 3.1 | ~65 |
| `sections/AuditSection.tsx` | 3.2 | ~55 |
| `sections/AdminsSection.tsx` | 3.3 | ~95 |
| `sections/DangerZoneSection.tsx` | 3.4 | ~110 |
| `sections/ApiKeysSection.tsx` | 3.5 | ~140 |
| `lib/queries/api-keys.ts` | 3.5 | ~30 |

### Modified files (3)

| File | Tasks | Changes |
|------|-------|---------|
| `SettingsManagementPage.tsx` | 3.0, 3.6, 3.7, 3.8 | Mutations, toasts, section wiring, responsive grid, beforeunload |
| `SettingsNav.tsx` | 3.7, 3.8 | Dual-mode (sidebar + pills), aria-current, data-testid |
| `settings.ts` (queries) | — | No changes needed (patchSettings, resetSettings already exist) |

### Existing imports used (no changes)

- `@azblink/ui`: Button, Input, Textarea, Select, ToggleRow, RadioGroup, Badge, AlertDialog + parts
- `sonner`: toast
- `lucide-react`: Save, RotateCcw, Plus, Copy, UserPlus, Trash2, AlertTriangle
- Types from `@/types/settings`: AllSettings, BrandingSettings, AuditSettings, Administrator, ApiKey, etc.
- Queries: `settingsQueryOptions`, `patchSettings`, `resetSettings`, `queryKeys`
