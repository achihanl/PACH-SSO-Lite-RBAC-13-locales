# E2E XMPP Provisioning Test — Design

**Date:** 2026-02-25
**Approach:** Hybrid — AD API orchestration + direct LDAP provisioning to 192.168.122.89

## Architecture Decision

Use a hybrid approach:
1. **AD API** for profile management, user creation, QR generation, provision token consumption, and audit trail verification
2. **Direct ldap3** to provision posixAccount entries into 192.168.122.89's LDAP (simulating what UED Sync does with xmpp-only schema)
3. **slixmpp** for XMPP authentication and bidirectional messaging

**Rationale:** Avoids reconfiguring the dev UED Sync container (which would affect other tests), while still testing the complete provisioning pipeline against real infrastructure.

## Corrected API Endpoints (from actual codebase)

| Endpoint | Purpose |
|----------|---------|
| `POST /api/config-templates` | Create XMPP profile |
| `POST /api/users/create` | Create user with profileId |
| `GET /api/users/{uid}/qrcode` | Generate QR code (v2 schema) |
| `POST /api/provision/consume` | Consume provision token |
| `GET /api/users/{uid}/qr_history` | QR issuance history |
| `GET /api/ued/sync-events` | Sync event audit trail |

## Data Flow

```
1. POST /api/config-templates → create XMPP profile (no UED — profile-only)
2. Provision 2 users into 192.168.122.89 LDAP directly (ldap3)
   - posixAccount: uid, cn, uidNumber, userPassword (SSHA)
   - DN: uid={username},ou=People,dc=xmpp-sip-platform,dc=local
3. POST /api/users/create × 2 → register users in AD (for QR issuance)
4. GET /api/users/{uid}/qrcode × 2 → get QR payload + provision token
5. POST /api/provision/consume × 2 → consume tokens, get UC config
6. slixmpp: connect user1@private.z, user2@private.z to 192.168.122.89:5222
7. Exchange messages: user1→user2 "Hello", user2→user1 "Reply"
8. Verify audit: provision_tokens consumed, qr_issuance_audit logged
```

## Components

### tests/test_xmpp_e2e.py
- Main test file with `@pytest.mark.external_network` marker
- Uses `@pytest.mark.asyncio` for slixmpp operations
- try/finally cleanup of LDAP entries and DB records

### tests/conftest.py additions
- `external_ldap_conn` fixture: ldap3 to 192.168.122.89:389
- No XMPP factory fixture needed — use verify-xmpp.py pattern inline

### Key Constants
- XMPP server: 192.168.122.89:5222
- XMPP domain: private.z
- LDAP base: dc=xmpp-sip-platform,dc=local
- LDAP bind: cn=Manager,dc=xmpp-sip-platform,dc=local

## Security
- Passwords: random via secrets.token_urlsafe(16)
- LDAP admin password: from env var EXTERNAL_LDAP_ADMIN_PASSWORD
- SSL verification disabled for self-signed certs (documented)
- Test usernames prefixed with `xmppe2e_` for easy identification/cleanup
