# Provisioning Operations — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Repurpose `/provisioning/tokens` into "Provisioning Operations" — a dashboard + tabbed split-panel page for token lifecycle management, device tracking, and compliance monitoring.

**Architecture:** Extend 2 existing backend endpoints (`GET /api/qr/stats`, `GET /api/qr/codes`), add 5 new endpoints in `main.py` + `orgdb.py`, add 1 migration. Frontend: new types file, new query file, rewrite route file, 12 new feature components in `src/components/features/provisioning-ops/`. All UI state lives in URL search params. Composes existing `@azblink/ui` primitives (DataTable, DetailGrid, FieldCard, Badge, Tabs, AlertDialog, Skeleton, Checkbox).

**Tech Stack:** FastAPI + SQLAlchemy (backend), React 19 + TanStack Router + TanStack Query + @azblink/ui + Tailwind CSS 4 (frontend)

**Design doc:** `docs/plans/2026-02-10-provisioning-ops-design.md`

---

## Task 1: Database Migration — Performance Indexes

**Files:**
- Create: `migrations/007_provisioning_ops_indexes.sql`

**Context:** The compliance queries (Task 7) do GROUP BY on `consumed_by_device_id` and filter on `issued_at`. Without indexes these become full table scans. Existing indexes are on `(uid, status)` and `(expires_at) WHERE status='active'` from migration 004.

**Step 1: Create the migration file**

```sql
-- Migration 007: Provisioning Operations performance indexes
-- For existing deployments upgrading in-place.
-- Fresh deployments auto-create via OrgDB.init().
--
-- Required by: GET /api/provisioning/compliance (6 analytical queries)
-- Required by: GET /api/provisioning/devices (device_id lookups)

CREATE INDEX IF NOT EXISTS idx_pt_device
ON provision_tokens(consumed_by_device_id)
WHERE consumed_by_device_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_pt_issued_at
ON provision_tokens(issued_at DESC);
```

**Step 2: Run the migration**

Run: `just psql < migrations/007_provisioning_ops_indexes.sql`
Expected: `CREATE INDEX` (x2)

**Step 3: Verify indexes exist**

Run: `echo "\di idx_pt_*" | just psql`
Expected: Two rows — `idx_pt_device` and `idx_pt_issued_at`

**Step 4: Commit**

```bash
git add migrations/007_provisioning_ops_indexes.sql
git commit -m "feat(db): add provisioning ops performance indexes (migration 007)"
```

---

## Task 2: Backend — Extend `get_qr_stats()` with 4 New Fields

**Files:**
- Modify: `src/backend/orgdb.py` — method `get_qr_stats` (line ~798)
- Test: `tests/test_provisioning_ops.py` (new file)

**Context:** The existing `get_qr_stats()` returns `total_generated`, `consumed`, `pending`, `expired_unused` + previous-period variants. We add 4 operational metrics: `expiring_24h`, `active_devices`, `stale_active`, `compliance_alert_count`. These query `provision_tokens` directly (not the join).

**Step 1: Write the failing test**

Create file `tests/test_provisioning_ops.py`:

```python
"""Provisioning Operations endpoint tests."""

import hashlib
import secrets
import pytest
from conftest import create_test_user, LDAP_BASE_DN


class TestProvisioningOpsStats:
    """GET /api/qr/stats — extended fields for provisioning ops."""

    def test_stats_includes_ops_fields(self, client, auth_headers):
        """Stats response includes the 4 new provisioning ops fields."""
        resp = client.get("/api/qr/stats?date_range=all", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        # New fields must exist and be integers >= 0
        for field in ("expiring_24h", "active_devices", "stale_active", "compliance_alert_count"):
            assert field in data, f"Missing field: {field}"
            assert isinstance(data[field], int), f"{field} should be int, got {type(data[field])}"
            assert data[field] >= 0, f"{field} should be >= 0"

    def test_stats_expiring_24h_counts_correctly(self, client, db_conn, auth_headers, created_users):
        """expiring_24h counts active tokens expiring within 24h."""
        uid = "ops_stats_test_1"
        create_test_user(client, uid, created_users)

        token_hash = hashlib.sha256(secrets.token_urlsafe(32).encode()).hexdigest()
        with db_conn.cursor() as cur:
            # Token expiring in 12 hours — should be counted
            cur.execute("""
                INSERT INTO provision_tokens (token_hash, uid, profile_id, issued_at, expires_at, status)
                VALUES (%s, %s, 'test', NOW(), NOW() + INTERVAL '12 hours', 'active')
            """, (token_hash, uid))

        resp = client.get("/api/qr/stats?date_range=all", headers=auth_headers)
        data = resp.json()
        assert data["expiring_24h"] >= 1
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestProvisioningOpsStats::test_stats_includes_ops_fields -v`
Expected: FAIL — `KeyError: 'expiring_24h'` (field doesn't exist yet)

**Step 3: Add `auth_headers` fixture if not in conftest**

Check `tests/conftest.py` for an `auth_headers` fixture. If missing, add:

```python
@pytest.fixture
def auth_headers(client):
    """JWT auth headers from seed user login."""
    resp = client.post("/api/auth/login", json={
        "username": "mei", "password": "password123", "remember": False,
    })
    token = resp.json().get("token", "")
    return {"Authorization": f"Bearer {token}"}
```

**Step 4: Implement — extend `get_qr_stats()` in `orgdb.py`**

After line ~879 (just before the `return` in `get_qr_stats`), add the ops queries. The method already has `eng`, `now`, and `cutoff` (when date_range != 'all'):

```python
        # --- Provisioning Ops metrics (from provision_tokens directly) ---
        with eng.begin() as conn:
            # expiring_24h: active tokens expiring within 24 hours
            expiring_24h = conn.execute(
                select(func.count())
                .select_from(provision_tokens)
                .where(
                    provision_tokens.c.status == "active",
                    provision_tokens.c.expires_at > now,
                    provision_tokens.c.expires_at <= now + timedelta(hours=24),
                )
            ).scalar() or 0

            # active_devices: unique devices that consumed tokens (in period if applicable)
            device_q = (
                select(func.count(func.distinct(provision_tokens.c.consumed_by_device_id)))
                .select_from(provision_tokens)
                .where(provision_tokens.c.consumed_by_device_id.isnot(None))
            )
            if date_range != "all":
                device_q = device_q.where(provision_tokens.c.used_at >= cutoff)
            active_devices = conn.execute(device_q).scalar() or 0

            # stale_active: tokens past 80% of TTL, not consumed
            stale_active = conn.execute(text("""
                SELECT COUNT(*) FROM provision_tokens
                WHERE status = 'active' AND expires_at > NOW()
                AND (EXTRACT(EPOCH FROM NOW() - issued_at))
                  > 0.8 * (EXTRACT(EPOCH FROM expires_at - issued_at))
            """)).scalar() or 0

            # compliance_alert_count: simplified count of actionable anomalies
            compliance_alert_count = conn.execute(text("""
                SELECT (
                    -- expired-unused
                    (SELECT COUNT(*) FROM provision_tokens
                     WHERE status = 'active' AND expires_at < NOW())
                    +
                    -- cross-user-device (count devices, not tokens)
                    COALESCE((SELECT COUNT(*) FROM (
                        SELECT consumed_by_device_id FROM provision_tokens
                        WHERE consumed_by_device_id IS NOT NULL
                        GROUP BY consumed_by_device_id
                        HAVING COUNT(DISTINCT uid) > 1
                    ) sub), 0)
                )
            """)).scalar() or 0
```

Then add these to both return paths in `get_qr_stats()`:

```python
        # In the "all" branch:
        return {
            **current,
            "prev_total_generated": None,
            "prev_consumed": None,
            "prev_pending": None,
            "prev_expired_unused": None,
            "expiring_24h": expiring_24h,
            "active_devices": active_devices,
            "stale_active": stale_active,
            "compliance_alert_count": compliance_alert_count,
        }

        # In the date_range branch:
        return {
            **current,
            "prev_total_generated": previous["total_generated"],
            "prev_consumed": previous["consumed"],
            "prev_pending": previous["pending"],
            "prev_expired_unused": previous["expired_unused"],
            "expiring_24h": expiring_24h,
            "active_devices": active_devices,
            "stale_active": stale_active,
            "compliance_alert_count": compliance_alert_count,
        }
```

Add `text` import at top of orgdb.py if not already present:
```python
from sqlalchemy import text
```

**Step 5: Run test to verify it passes**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestProvisioningOpsStats -v`
Expected: 2 PASSED

**Step 6: Commit**

```bash
git add src/backend/orgdb.py tests/test_provisioning_ops.py
git commit -m "feat(api): extend GET /api/qr/stats with provisioning ops metrics"
```

---

## Task 3: Backend — Extend `list_qr_codes()` with Pseudo-Status Filters

**Files:**
- Modify: `src/backend/orgdb.py` — method `list_qr_codes` (line ~692)
- Modify: `src/backend/main.py` — constant `VALID_QR_STATUSES` (line ~1625)
- Test: `tests/test_provisioning_ops.py` (append)

**Context:** The Lifecycle tab needs server-side filtering for compound conditions. Add `expiring_soon` and `active_stable` as pseudo-statuses that map to SQL WHERE clauses. Current status filter does client-side filtering after fetching all rows (for derived statuses). The pseudo-statuses can filter at the SQL level since they're based on `provision_tokens` columns directly.

**Step 1: Write the failing test**

Append to `tests/test_provisioning_ops.py`:

```python
class TestProvisioningOpsLifecycle:
    """GET /api/qr/codes — pseudo-status filters for lifecycle tab."""

    def test_expiring_soon_filter(self, client, db_conn, auth_headers, created_users):
        """status=expiring_soon returns only tokens expiring within 24h."""
        uid = "ops_lifecycle_1"
        create_test_user(client, uid, created_users)

        # Create token expiring in 6 hours
        token_hash = hashlib.sha256(secrets.token_urlsafe(32).encode()).hexdigest()
        with db_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO provision_tokens (token_hash, uid, profile_id, issued_at, expires_at, status)
                VALUES (%s, %s, 'test', NOW(), NOW() + INTERVAL '6 hours', 'active')
            """, (token_hash, uid))
            # Also need audit record for the JOIN
            cur.execute("""
                INSERT INTO qr_issuance_audit (user_uid, org_dn, issued_by, issued_at, token_hash, expires_at, consumed)
                VALUES (%s, %s, 'admin', NOW(), %s, NOW() + INTERVAL '6 hours', false)
            """, (uid, f"ou=test,{LDAP_BASE_DN}", token_hash))

        resp = client.get("/api/qr/codes?status=expiring_soon&date_range=all", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        # Should find our token (or more from prior tests)
        matching = [c for c in data["codes"] if c["token_hash"] == token_hash]
        assert len(matching) == 1

    def test_expiring_soon_not_accepted_returns_422(self, client, auth_headers):
        """Verify expiring_soon is now a valid status (not 422)."""
        resp = client.get("/api/qr/codes?status=expiring_soon", headers=auth_headers)
        assert resp.status_code == 200  # Was 422 before we added it
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestProvisioningOpsLifecycle -v`
Expected: FAIL — 422 "Invalid status: expiring_soon"

**Step 3: Implement — update `VALID_QR_STATUSES` in `main.py`**

```python
# line ~1625
VALID_QR_STATUSES = ("", "consumed", "pending", "expired", "revoked", "expiring_soon", "active_stable")
```

**Step 4: Implement — add pseudo-status handling in `list_qr_codes()` in `orgdb.py`**

In `list_qr_codes`, replace the status filter block (lines ~749-771) with:

```python
        # Pseudo-status filters (server-side, query provision_tokens directly)
        if status == "expiring_soon":
            conditions.append(provision_tokens.c.status == "active")
            conditions.append(provision_tokens.c.expires_at > now)
            conditions.append(provision_tokens.c.expires_at <= now + timedelta(hours=24))
            # Fall through to SQL pagination path (no client-side filtering needed)
            status = ""  # Clear so we use the SQL pagination branch below

        elif status == "active_stable":
            conditions.append(provision_tokens.c.status == "active")
            conditions.append(provision_tokens.c.expires_at > now + timedelta(hours=24))
            status = ""

        # Status filter: exhaustive scan (status is derived post-query)
        if status:
            # ... existing client-side filtering code ...
```

**Step 5: Run test to verify it passes**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestProvisioningOpsLifecycle -v`
Expected: 2 PASSED

**Step 6: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_provisioning_ops.py
git commit -m "feat(api): extend GET /api/qr/codes with pseudo-status filters"
```

---

## Task 4: Backend — `POST /api/provisioning/tokens/bulk-revoke`

**Files:**
- Modify: `src/backend/orgdb.py` — add method `bulk_revoke_tokens`
- Modify: `src/backend/main.py` — add endpoint + Pydantic model
- Test: `tests/test_provisioning_ops.py` (append)

**Context:** Bulk revoke sets `status='revoked'` (not `revoked_terminated` — that's for user termination). Only active, non-expired tokens can be revoked. Capped at 100 tokens per request. Returns partial failure info.

**Step 1: Write the failing test**

Append to `tests/test_provisioning_ops.py`:

```python
class TestBulkRevoke:
    """POST /api/provisioning/tokens/bulk-revoke"""

    def _insert_token(self, db_conn, uid, token_hash, status="active", hours_until_expiry=1):
        with db_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO provision_tokens (token_hash, uid, profile_id, issued_at, expires_at, status)
                VALUES (%s, %s, 'test', NOW(), NOW() + INTERVAL '%s hours', %s)
                ON CONFLICT (token_hash) DO NOTHING
            """, (token_hash, uid, hours_until_expiry, status))

    def test_bulk_revoke_success(self, client, db_conn, auth_headers, created_users):
        """Bulk revoke 2 active tokens."""
        uid = "bulk_revoke_1"
        create_test_user(client, uid, created_users)

        h1 = hashlib.sha256(b"bulk1").hexdigest()
        h2 = hashlib.sha256(b"bulk2").hexdigest()
        self._insert_token(db_conn, uid, h1)
        self._insert_token(db_conn, uid, h2)

        resp = client.post(
            "/api/provisioning/tokens/bulk-revoke",
            json={"token_hashes": [h1, h2]},
            headers=auth_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["revoked_count"] == 2
        assert data["skipped_count"] == 0

    def test_bulk_revoke_skips_expired(self, client, db_conn, auth_headers, created_users):
        """Bulk revoke skips already-expired tokens."""
        uid = "bulk_revoke_2"
        create_test_user(client, uid, created_users)

        h1 = hashlib.sha256(b"bulk_exp1").hexdigest()
        self._insert_token(db_conn, uid, h1, hours_until_expiry=-1)  # Already expired

        resp = client.post(
            "/api/provisioning/tokens/bulk-revoke",
            json={"token_hashes": [h1]},
            headers=auth_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["revoked_count"] == 0
        assert data["skipped_count"] == 1

    def test_bulk_revoke_max_100(self, client, auth_headers):
        """Rejects batches > 100 tokens."""
        hashes = [hashlib.sha256(f"x{i}".encode()).hexdigest() for i in range(101)]
        resp = client.post(
            "/api/provisioning/tokens/bulk-revoke",
            json={"token_hashes": hashes},
            headers=auth_headers,
        )
        assert resp.status_code == 422
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestBulkRevoke::test_bulk_revoke_success -v`
Expected: FAIL — 404 or 405 (endpoint doesn't exist)

**Step 3: Implement — add `bulk_revoke_tokens()` to `orgdb.py`**

Add after `revoke_tokens_for_user` method (line ~548):

```python
    def bulk_revoke_tokens(self, token_hashes: list[str], revoked_by: str = "admin") -> dict[str, Any]:
        """Revoke multiple provision tokens by hash.

        - Only active, non-expired tokens are revoked
        - Already consumed/expired/revoked tokens are skipped with reason
        - Returns { revoked_count, skipped_count, errors: [{ token_hash, reason }] }
        """
        eng = self.connect()
        now = utcnow()
        revoked = 0
        skipped = 0
        errors: list[dict[str, str]] = []

        with eng.begin() as conn:
            for h in token_hashes:
                row = conn.execute(
                    select(provision_tokens).where(provision_tokens.c.token_hash == h)
                ).mappings().first()

                if row is None:
                    skipped += 1
                    errors.append({"token_hash": h, "reason": "not_found"})
                    continue

                if row["status"] != "active":
                    skipped += 1
                    errors.append({"token_hash": h, "reason": f"status_{row['status']}"})
                    continue

                if row["expires_at"] and row["expires_at"].replace(tzinfo=timezone.utc) < now:
                    skipped += 1
                    errors.append({"token_hash": h, "reason": "already_expired"})
                    continue

                conn.execute(
                    update(provision_tokens)
                    .where(provision_tokens.c.token_hash == h)
                    .values(status="revoked", used_at=now)
                )
                revoked += 1

        return {
            "revoked_count": revoked,
            "skipped_count": skipped,
            "errors": errors,
        }
```

**Step 4: Implement — add endpoint to `main.py`**

Add Pydantic model near other request models:

```python
class BulkRevokeReq(BaseModel):
    token_hashes: List[str] = Field(..., min_length=1, max_length=100)
```

Add endpoint after the `api_qr_stats` function (line ~1702):

```python
# ----------------------------
# Provisioning Operations (Admin)
# ----------------------------

@app.post("/api/provisioning/tokens/bulk-revoke")
def api_bulk_revoke_tokens(
    req: BulkRevokeReq,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Bulk revoke provision tokens by hash list.

    - Only active, non-expired tokens are revoked
    - Skips already consumed/expired/revoked (returns per-token reasons)
    - Max 100 tokens per request
    """
    result = ORGDB.bulk_revoke_tokens(
        token_hashes=req.token_hashes,
        revoked_by=claims.get("sub", "admin"),
    )
    return {"ok": True, **result}
```

**Step 5: Run test to verify it passes**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestBulkRevoke -v`
Expected: 3 PASSED

**Step 6: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_provisioning_ops.py
git commit -m "feat(api): add POST /api/provisioning/tokens/bulk-revoke"
```

---

## Task 5: Backend — `POST /api/provisioning/tokens/{hash}/extend`

**Files:**
- Modify: `src/backend/orgdb.py` — add method `extend_token_expiry`
- Modify: `src/backend/main.py` — add endpoint + Pydantic model
- Test: `tests/test_provisioning_ops.py` (append)

**Context:** Extends expiry of active tokens. Capped at `ORG_QR_MAX_TTL_SEC` (86400 = 24h default in `config.py` line 33). Returns 422 if resulting TTL exceeds cap. Only active non-expired tokens can be extended.

**Step 1: Write the failing test**

```python
class TestExtendToken:
    """POST /api/provisioning/tokens/{hash}/extend"""

    def test_extend_active_token(self, client, db_conn, auth_headers, created_users):
        """Extend an active token's expiry."""
        uid = "extend_test_1"
        create_test_user(client, uid, created_users)

        token_hash = hashlib.sha256(b"extend1").hexdigest()
        with db_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO provision_tokens (token_hash, uid, profile_id, issued_at, expires_at, status)
                VALUES (%s, %s, 'test', NOW(), NOW() + INTERVAL '30 minutes', 'active')
                ON CONFLICT (token_hash) DO NOTHING
            """, (token_hash, uid))

        resp = client.post(
            f"/api/provisioning/tokens/{token_hash}/extend",
            json={"extend_seconds": 3600},
            headers=auth_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["token_hash"] == token_hash
        assert "new_expires_at" in data

    def test_extend_consumed_token_fails(self, client, db_conn, auth_headers, created_users):
        """Cannot extend a consumed token."""
        uid = "extend_test_2"
        create_test_user(client, uid, created_users)

        token_hash = hashlib.sha256(b"extend_consumed").hexdigest()
        with db_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO provision_tokens (token_hash, uid, profile_id, issued_at, expires_at, status, used_at)
                VALUES (%s, %s, 'test', NOW(), NOW() + INTERVAL '1 hour', 'consumed', NOW())
                ON CONFLICT (token_hash) DO NOTHING
            """, (token_hash, uid))

        resp = client.post(
            f"/api/provisioning/tokens/{token_hash}/extend",
            json={"extend_seconds": 3600},
            headers=auth_headers,
        )
        assert resp.status_code == 400

    def test_extend_exceeds_max_ttl_fails(self, client, db_conn, auth_headers, created_users):
        """Extend fails when resulting TTL exceeds ORG_QR_MAX_TTL_SEC."""
        uid = "extend_test_3"
        create_test_user(client, uid, created_users)

        token_hash = hashlib.sha256(b"extend_max").hexdigest()
        with db_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO provision_tokens (token_hash, uid, profile_id, issued_at, expires_at, status)
                VALUES (%s, %s, 'test', NOW(), NOW() + INTERVAL '23 hours', 'active')
                ON CONFLICT (token_hash) DO NOTHING
            """, (token_hash, uid))

        # Try to extend by 12 hours — total would exceed 24h max
        resp = client.post(
            f"/api/provisioning/tokens/{token_hash}/extend",
            json={"extend_seconds": 43200},
            headers=auth_headers,
        )
        assert resp.status_code == 422
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestExtendToken::test_extend_active_token -v`
Expected: FAIL — 404/405 (endpoint doesn't exist)

**Step 3: Implement — add `extend_token_expiry()` to `orgdb.py`**

```python
    def extend_token_expiry(self, token_hash: str, extend_seconds: int, max_ttl_sec: int) -> dict[str, Any]:
        """Extend expiry of an active provision token.

        - Only active, non-expired tokens can be extended
        - Capped: (new_expires_at - issued_at) must not exceed max_ttl_sec
        - Returns { token_hash, new_expires_at } or raises ValueError
        """
        eng = self.connect()
        now = utcnow()

        with eng.begin() as conn:
            row = conn.execute(
                select(provision_tokens).where(provision_tokens.c.token_hash == token_hash)
            ).mappings().first()

            if row is None:
                raise ValueError("TOKEN_NOT_FOUND")

            if row["status"] != "active":
                raise ValueError(f"TOKEN_NOT_ACTIVE:{row['status']}")

            expires_at = row["expires_at"]
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            if expires_at < now:
                raise ValueError("TOKEN_EXPIRED")

            new_expires = expires_at + timedelta(seconds=extend_seconds)
            issued_at = row["issued_at"]
            if issued_at.tzinfo is None:
                issued_at = issued_at.replace(tzinfo=timezone.utc)

            total_ttl = (new_expires - issued_at).total_seconds()
            if total_ttl > max_ttl_sec:
                raise ValueError(f"EXCEEDS_MAX_TTL:{int(total_ttl)}>{max_ttl_sec}")

            conn.execute(
                update(provision_tokens)
                .where(provision_tokens.c.token_hash == token_hash)
                .values(expires_at=new_expires)
            )

        return {
            "token_hash": token_hash,
            "new_expires_at": new_expires.isoformat(),
        }
```

**Step 4: Implement — add endpoint to `main.py`**

```python
class ExtendTokenReq(BaseModel):
    extend_seconds: int = Field(..., gt=0, le=604800, description="Seconds to extend")

@app.post("/api/provisioning/tokens/{token_hash}/extend")
def api_extend_token(
    token_hash: str,
    req: ExtendTokenReq,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Extend expiry of an active provision token. Capped at ORG_QR_MAX_TTL_SEC."""
    try:
        result = ORGDB.extend_token_expiry(
            token_hash=token_hash,
            extend_seconds=req.extend_seconds,
            max_ttl_sec=ORG_QR_MAX_TTL_SEC,
        )
    except ValueError as e:
        msg = str(e)
        if "NOT_FOUND" in msg:
            raise HTTPException(404, f"Token not found: {token_hash}")
        if "NOT_ACTIVE" in msg or "EXPIRED" in msg:
            raise HTTPException(400, f"Token cannot be extended: {msg}")
        if "EXCEEDS_MAX_TTL" in msg:
            raise HTTPException(422, f"Extension would exceed max TTL: {msg}")
        raise HTTPException(400, str(e))
    return {"ok": True, **result}
```

**Step 5: Run test to verify it passes**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestExtendToken -v`
Expected: 3 PASSED

**Step 6: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_provisioning_ops.py
git commit -m "feat(api): add POST /api/provisioning/tokens/{hash}/extend"
```

---

## Task 6: Backend — Device Provisioning Endpoints

**Files:**
- Modify: `src/backend/orgdb.py` — add `list_provisioned_devices`, `get_device_token_history`
- Modify: `src/backend/main.py` — add 2 endpoints
- Test: `tests/test_provisioning_ops.py` (append)

**Context:** Device info is optional — only populated when clients send device headers during `POST /api/provision/consume`. These endpoints query `provision_tokens WHERE consumed_by_device_id IS NOT NULL`.

**Step 1: Write the failing test**

```python
class TestDeviceEndpoints:
    """GET /api/provisioning/devices and GET /api/provisioning/devices/{id}/history"""

    def test_list_devices_empty(self, client, auth_headers):
        """Device list returns empty when no device data."""
        resp = client.get("/api/provisioning/devices", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert "devices" in data
        assert isinstance(data["devices"], list)
        assert "total" in data

    def test_list_devices_with_data(self, client, db_conn, auth_headers, created_users):
        """Device list returns tokens with device info."""
        uid = "device_test_1"
        create_test_user(client, uid, created_users)

        token_hash = hashlib.sha256(b"device1").hexdigest()
        with db_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO provision_tokens
                (token_hash, uid, profile_id, issued_at, expires_at, status, used_at,
                 consumed_by_device_id, consumed_from_ip, client_platform, client_version)
                VALUES (%s, %s, 'test', NOW(), NOW() + INTERVAL '1 hour', 'consumed', NOW(),
                        'iPhone14-abc', '192.168.1.100', 'iOS', '1.2.3')
                ON CONFLICT (token_hash) DO NOTHING
            """, (token_hash, uid))

        resp = client.get("/api/provisioning/devices?date_range=all", headers=auth_headers)
        data = resp.json()
        devices = [d for d in data["devices"] if d["device_id"] == "iPhone14-abc"]
        assert len(devices) >= 1
        assert devices[0]["platform"] == "iOS"
        assert devices[0]["user_uid"] == uid

    def test_device_history(self, client, db_conn, auth_headers, created_users):
        """Device history returns all tokens consumed by a device."""
        uid = "device_test_2"
        create_test_user(client, uid, created_users)

        # Insert 2 tokens for same device
        for i in range(2):
            token_hash = hashlib.sha256(f"devhist{i}".encode()).hexdigest()
            with db_conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO provision_tokens
                    (token_hash, uid, profile_id, issued_at, expires_at, status, used_at,
                     consumed_by_device_id, client_platform)
                    VALUES (%s, %s, 'test', NOW(), NOW() + INTERVAL '1 hour', 'consumed', NOW(),
                            'TestDevice-xyz', 'Android')
                    ON CONFLICT (token_hash) DO NOTHING
                """, (token_hash, uid))

        resp = client.get("/api/provisioning/devices/TestDevice-xyz/history", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["device_id"] == "TestDevice-xyz"
        assert len(data["history"]) >= 2
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestDeviceEndpoints::test_list_devices_empty -v`
Expected: FAIL — 404 (endpoint doesn't exist)

**Step 3: Implement — add OrgDB methods**

```python
    def list_provisioned_devices(
        self, limit: int = 50, offset: int = 0, search: str = "",
        date_range: str = "30d", platform: str = "",
    ) -> tuple[list[dict[str, Any]], int]:
        """List devices that consumed provision tokens.

        - Queries provision_tokens WHERE consumed_by_device_id IS NOT NULL
        - Returns (devices, total_count)
        """
        eng = self.connect()
        now = datetime.now(timezone.utc)
        conditions = [provision_tokens.c.consumed_by_device_id.isnot(None)]

        if date_range != "all":
            days_map = {"7d": 7, "30d": 30, "90d": 90}
            days = days_map.get(date_range, 30)
            conditions.append(provision_tokens.c.used_at >= now - timedelta(days=days))

        if search:
            conditions.append(
                or_(
                    provision_tokens.c.consumed_by_device_id.ilike(f"%{search}%"),
                    provision_tokens.c.uid.ilike(f"%{search}%"),
                )
            )

        if platform:
            conditions.append(provision_tokens.c.client_platform == platform)

        count_stmt = select(func.count()).select_from(provision_tokens)
        for cond in conditions:
            count_stmt = count_stmt.where(cond)

        data_stmt = (
            select(provision_tokens)
            .order_by(provision_tokens.c.used_at.desc())
            .limit(limit)
            .offset(offset)
        )
        for cond in conditions:
            data_stmt = data_stmt.where(cond)

        with eng.begin() as conn:
            total = conn.execute(count_stmt).scalar() or 0
            rows = conn.execute(data_stmt).mappings().all()

        devices = []
        for r in rows:
            devices.append({
                "device_id": r["consumed_by_device_id"],
                "platform": r["client_platform"],
                "client_version": r["client_version"],
                "ip_address": r["consumed_from_ip"],
                "user_uid": r["uid"],
                "user_display_name": r["uid"],  # Enriched by endpoint
                "consumed_at": r["used_at"].isoformat() if r["used_at"] else None,
                "token_hash": r["token_hash"],
                "token_status": r["status"],
            })
        return devices, total

    def get_device_token_history(self, device_id: str) -> list[dict[str, Any]]:
        """Get all tokens consumed by a specific device."""
        eng = self.connect()
        stmt = (
            select(provision_tokens)
            .where(provision_tokens.c.consumed_by_device_id == device_id)
            .order_by(provision_tokens.c.used_at.desc())
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()

        return [
            {
                "token_hash": r["token_hash"],
                "user_uid": r["uid"],
                "consumed_at": r["used_at"].isoformat() if r["used_at"] else None,
                "status": r["status"],
                "platform": r["client_platform"],
                "client_version": r["client_version"],
            }
            for r in rows
        ]
```

**Step 4: Implement — add endpoints to `main.py`**

```python
@app.get("/api/provisioning/devices")
def api_list_devices(
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    search: str = "",
    date_range: str = Query("30d"),
    platform: str = "",
    claims: Dict[str, Any] = Depends(require_admin),
):
    """List devices that consumed provision tokens."""
    if date_range not in VALID_QR_DATE_RANGES:
        raise HTTPException(422, f"Invalid date_range: {date_range}")
    devices, total = ORGDB.list_provisioned_devices(
        limit=limit, offset=offset, search=search,
        date_range=date_range, platform=platform,
    )
    return {"ok": True, "devices": devices, "total": total, "limit": limit, "offset": offset}


@app.get("/api/provisioning/devices/{device_id}/history")
def api_device_history(
    device_id: str,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Get provisioning history for a specific device."""
    history = ORGDB.get_device_token_history(device_id)
    return {"ok": True, "device_id": device_id, "history": history}
```

**Step 5: Run test to verify it passes**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestDeviceEndpoints -v`
Expected: 3 PASSED

**Step 6: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_provisioning_ops.py
git commit -m "feat(api): add device provisioning tracking endpoints"
```

---

## Task 7: Backend — `GET /api/provisioning/compliance`

**Files:**
- Modify: `src/backend/orgdb.py` — add method `compute_compliance_alerts`
- Modify: `src/backend/main.py` — add endpoint with 60s cache
- Test: `tests/test_provisioning_ops.py` (append)

**Context:** 6 anomaly types derived from `provision_tokens` + `qr_issuance_audit`. Server-side 60s cache because these queries are expensive. See design doc §4 for SQL and the token status state machine notes.

**Step 1: Write the failing test**

```python
class TestComplianceEndpoint:
    """GET /api/provisioning/compliance"""

    def test_compliance_returns_shape(self, client, auth_headers):
        """Compliance endpoint returns correct response shape."""
        resp = client.get("/api/provisioning/compliance", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert "alerts" in data
        assert isinstance(data["alerts"], list)
        assert "summary" in data
        # Summary should have all 6 alert types
        for alert_type in (
            "expired-unused", "rapid-consumption", "multi-issue",
            "stale-active", "cross-user-device", "high-failure-rate",
        ):
            assert alert_type in data["summary"]
            assert isinstance(data["summary"][alert_type], int)

    def test_compliance_detects_expired_unused(self, client, db_conn, auth_headers, created_users):
        """Compliance detects expired-unused tokens (status=active, expires_at < NOW())."""
        uid = "compliance_test_1"
        create_test_user(client, uid, created_users)

        token_hash = hashlib.sha256(b"compliance_expired").hexdigest()
        with db_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO provision_tokens (token_hash, uid, profile_id, issued_at, expires_at, status)
                VALUES (%s, %s, 'test', NOW() - INTERVAL '2 hours', NOW() - INTERVAL '1 hour', 'active')
                ON CONFLICT (token_hash) DO NOTHING
            """, (token_hash, uid))

        # Wait for cache to expire (or this is the first call)
        import time
        time.sleep(1)

        resp = client.get("/api/provisioning/compliance", headers=auth_headers)
        data = resp.json()
        assert data["summary"]["expired-unused"] >= 1
        # Find the specific alert
        expired_alerts = [a for a in data["alerts"] if a["type"] == "expired-unused"]
        assert len(expired_alerts) >= 1
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestComplianceEndpoint::test_compliance_returns_shape -v`
Expected: FAIL — 404 (endpoint doesn't exist)

**Step 3: Implement — add `compute_compliance_alerts()` to `orgdb.py`**

```python
    def compute_compliance_alerts(self) -> dict[str, Any]:
        """Compute compliance alerts from provision_tokens + qr_issuance_audit.

        Alert types:
        - expired-unused: status='active' AND expires_at < NOW() (expiry is read-time)
        - rapid-consumption: consumed within 60s of issuance
        - multi-issue: user has 3+ active non-expired tokens
        - stale-active: active token past 80% of TTL
        - cross-user-device: device consumed tokens for 2+ users
        - high-failure-rate: user has >3 non-consumed tokens in 30 days
        """
        eng = self.connect()
        now = utcnow()
        alerts: list[dict[str, Any]] = []
        summary: dict[str, int] = {
            "expired-unused": 0,
            "rapid-consumption": 0,
            "multi-issue": 0,
            "stale-active": 0,
            "cross-user-device": 0,
            "high-failure-rate": 0,
        }
        alert_id = 0

        with eng.begin() as conn:
            # 1. expired-unused
            rows = conn.execute(text("""
                SELECT token_hash, uid, issued_at, expires_at
                FROM provision_tokens
                WHERE status = 'active' AND expires_at < NOW()
                ORDER BY expires_at DESC LIMIT 100
            """)).mappings().all()
            summary["expired-unused"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "expired-unused",
                    "severity": "warning",
                    "subject_uid": r["uid"],
                    "subject_device_id": None,
                    "description": f"Token expired without being consumed",
                    "detected_at": now.isoformat(),
                    "evidence": {"token_hash": r["token_hash"]},
                    "recommended_action": "Generate a new QR code for this user",
                })

            # 2. rapid-consumption
            rows = conn.execute(text("""
                SELECT pt.token_hash, pt.uid, pt.used_at, qa.issued_at
                FROM provision_tokens pt
                JOIN qr_issuance_audit qa ON pt.token_hash = qa.token_hash
                WHERE pt.status IN ('used', 'consumed')
                AND pt.used_at IS NOT NULL
                AND EXTRACT(EPOCH FROM pt.used_at - qa.issued_at) < 60
                ORDER BY pt.used_at DESC LIMIT 50
            """)).mappings().all()
            summary["rapid-consumption"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "rapid-consumption",
                    "severity": "warning",
                    "subject_uid": r["uid"],
                    "subject_device_id": None,
                    "description": "Token consumed within 60s of issuance",
                    "detected_at": now.isoformat(),
                    "evidence": {"token_hash": r["token_hash"]},
                    "recommended_action": "Review audit log for this token",
                })

            # 3. multi-issue
            rows = conn.execute(text("""
                SELECT uid, COUNT(*) as cnt
                FROM provision_tokens
                WHERE status = 'active' AND expires_at > NOW()
                GROUP BY uid HAVING COUNT(*) > 2
            """)).mappings().all()
            summary["multi-issue"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "multi-issue",
                    "severity": "warning",
                    "subject_uid": r["uid"],
                    "subject_device_id": None,
                    "description": f"User has {r['cnt']} active tokens simultaneously",
                    "detected_at": now.isoformat(),
                    "evidence": {"active_count": int(r["cnt"])},
                    "recommended_action": "Revoke older tokens to reduce exposure",
                })

            # 4. stale-active
            rows = conn.execute(text("""
                SELECT token_hash, uid, issued_at, expires_at
                FROM provision_tokens
                WHERE status = 'active' AND expires_at > NOW()
                AND (EXTRACT(EPOCH FROM NOW() - issued_at))
                  > 0.8 * (EXTRACT(EPOCH FROM expires_at - issued_at))
                ORDER BY expires_at ASC LIMIT 100
            """)).mappings().all()
            summary["stale-active"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "stale-active",
                    "severity": "low",
                    "subject_uid": r["uid"],
                    "subject_device_id": None,
                    "description": "Token is past 80% of its TTL without consumption",
                    "detected_at": now.isoformat(),
                    "evidence": {"token_hash": r["token_hash"]},
                    "recommended_action": "Extend or revoke this token",
                })

            # 5. cross-user-device
            rows = conn.execute(text("""
                SELECT consumed_by_device_id, COUNT(DISTINCT uid) as user_count,
                       array_agg(DISTINCT uid) as users
                FROM provision_tokens
                WHERE consumed_by_device_id IS NOT NULL
                GROUP BY consumed_by_device_id
                HAVING COUNT(DISTINCT uid) > 1
            """)).mappings().all()
            summary["cross-user-device"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "cross-user-device",
                    "severity": "critical",
                    "subject_uid": None,
                    "subject_device_id": r["consumed_by_device_id"],
                    "description": f"Device consumed tokens for {r['user_count']} different users",
                    "detected_at": now.isoformat(),
                    "evidence": {"users": list(r["users"]), "device_id": r["consumed_by_device_id"]},
                    "recommended_action": "Investigate shared device usage",
                })

            # 6. high-failure-rate
            rows = conn.execute(text("""
                SELECT uid, COUNT(*) as fail_count
                FROM provision_tokens
                WHERE status NOT IN ('used', 'consumed')
                AND issued_at > NOW() - INTERVAL '30 days'
                GROUP BY uid HAVING COUNT(*) > 3
            """)).mappings().all()
            summary["high-failure-rate"] = len(rows)
            for r in rows:
                alert_id += 1
                alerts.append({
                    "id": f"CMP-{alert_id:04d}",
                    "type": "high-failure-rate",
                    "severity": "warning",
                    "subject_uid": r["uid"],
                    "subject_device_id": None,
                    "description": f"User has {r['fail_count']} unconsumed tokens in 30 days",
                    "detected_at": now.isoformat(),
                    "evidence": {"fail_count": int(r["fail_count"])},
                    "recommended_action": "Check user's provisioning workflow",
                })

        return {"alerts": alerts, "summary": summary}
```

**Step 4: Implement — add endpoint with cache to `main.py`**

```python
_compliance_cache: Dict[str, Any] = {"data": None, "expires": 0.0}

@app.get("/api/provisioning/compliance")
def api_compliance(
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Compute compliance alerts from provision data. Cached for 60s."""
    now = time.time()
    if _compliance_cache["data"] and now < _compliance_cache["expires"]:
        return _compliance_cache["data"]
    result = ORGDB.compute_compliance_alerts()
    response = {"ok": True, **result}
    _compliance_cache["data"] = response
    _compliance_cache["expires"] = now + 60
    return response
```

**Step 5: Run test to verify it passes**

Run: `just test-quick -- tests/test_provisioning_ops.py::TestComplianceEndpoint -v`
Expected: 2 PASSED

**Step 6: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_provisioning_ops.py
git commit -m "feat(api): add GET /api/provisioning/compliance with alert detection"
```

---

## Task 8: Frontend — Types

**Files:**
- Create: `src/frontend/src/types/provisioning-ops.ts`
- Modify: `src/frontend/src/types/qr-management.ts` — extend `QRStats`
- Modify: `src/frontend/src/types/index.ts` — add barrel export

**Step 1: Create `provisioning-ops.ts`**

See design doc §4 types section + §5 search params. Complete file:

```typescript
/**
 * Provisioning Operations page types
 * - Compliance alerts, devices, bulk actions, search params
 * - Design: 2026-02-10-provisioning-ops-design.md
 */

import type { ISOTimestamp, UID } from './api';

/* ---- Compliance ---- */

export type ComplianceAlertType =
  | 'expired-unused'
  | 'rapid-consumption'
  | 'multi-issue'
  | 'stale-active'
  | 'cross-user-device'
  | 'high-failure-rate';

export type AlertSeverity = 'critical' | 'warning' | 'low';

export interface ComplianceAlert {
  id: string;
  type: ComplianceAlertType;
  severity: AlertSeverity;
  subject_uid: UID | null;
  subject_device_id: string | null;
  description: string;
  detected_at: ISOTimestamp;
  evidence: Record<string, unknown>;
  recommended_action: string;
}

export type ComplianceSummary = Record<ComplianceAlertType, number>;

export interface ComplianceResponse {
  ok: true;
  alerts: ComplianceAlert[];
  summary: ComplianceSummary;
}

/* ---- Devices ---- */

export interface ProvisionedDevice {
  device_id: string;
  platform: string | null;
  client_version: string | null;
  ip_address: string | null;
  user_uid: UID;
  user_display_name: string;
  consumed_at: ISOTimestamp | null;
  token_hash: string;
  token_status: string;
}

export interface DeviceListResponse {
  ok: true;
  devices: ProvisionedDevice[];
  total: number;
  limit: number;
  offset: number;
}

export interface DeviceHistoryEntry {
  token_hash: string;
  user_uid: UID;
  consumed_at: ISOTimestamp | null;
  status: string;
  platform: string | null;
  client_version: string | null;
}

export interface DeviceHistoryResponse {
  ok: true;
  device_id: string;
  history: DeviceHistoryEntry[];
}

/* ---- Bulk actions ---- */

export interface BulkRevokeRequest {
  token_hashes: string[];
}

export interface BulkRevokeResponse {
  ok: true;
  revoked_count: number;
  skipped_count: number;
  errors: Array<{ token_hash: string; reason: string }>;
}

export interface ExtendTokenRequest {
  extend_seconds: number;
}

export interface ExtendTokenResponse {
  ok: true;
  token_hash: string;
  new_expires_at: ISOTimestamp;
}

/* ---- Page state ---- */

export type OpsTab = 'lifecycle' | 'devices' | 'compliance';
export type OpsDateRange = '7d' | '30d' | '90d' | 'all';

export interface ProvisioningOpsSearchParams {
  tab?: OpsTab;
  tokenHash?: string;
  deviceId?: string;
  alertType?: string;
  filter?: string;
  dateRange?: OpsDateRange;
  search?: string;
  page?: number;
  pageSize?: number;
}
```

**Step 2: Extend `QRStats` in `types/qr-management.ts`**

Add 4 fields before the closing brace of `QRStats` interface (after line ~57):

```typescript
  /** Provisioning ops dashboard metrics */
  expiring_24h: number;
  active_devices: number;
  stale_active: number;
  compliance_alert_count: number;
```

**Step 3: Add barrel export in `types/index.ts`**

Add line after `export * from './qr-management';`:

```typescript
export * from './provisioning-ops';
```

**Step 4: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit --pretty 2>&1 | head -20`
Expected: No errors related to provisioning-ops types (other pre-existing errors OK)

**Step 5: Commit**

```bash
git add src/frontend/src/types/provisioning-ops.ts src/frontend/src/types/qr-management.ts src/frontend/src/types/index.ts
git commit -m "feat(types): add provisioning ops TypeScript types"
```

---

## Task 9: Frontend — Query Keys + Query Options

**Files:**
- Modify: `src/frontend/src/lib/queries/keys.ts` — add `provisioningOps` section
- Create: `src/frontend/src/lib/queries/provisioning-ops.ts`

**Step 1: Add query keys**

In `keys.ts`, add before the `health` section (line ~48):

```typescript
  // Provisioning Operations
  provisioningOps: {
    all: ['provisioning-ops'] as const,
    devices: (params: Record<string, unknown>) =>
      ['provisioning-ops', 'devices', params] as const,
    deviceHistory: (deviceId: string) =>
      ['provisioning-ops', 'devices', deviceId, 'history'] as const,
    compliance: () => ['provisioning-ops', 'compliance'] as const,
  },
```

**Step 2: Create `provisioning-ops.ts` query file**

```typescript
/**
 * TanStack Query options for Provisioning Operations endpoints
 * - devicesQueryOptions: GET /api/provisioning/devices
 * - deviceHistoryQueryOptions: GET /api/provisioning/devices/{id}/history
 * - complianceQueryOptions: GET /api/provisioning/compliance
 * - useBulkRevokeTokens: POST /api/provisioning/tokens/bulk-revoke
 * - useExtendToken: POST /api/provisioning/tokens/{hash}/extend
 */

import { queryOptions, useMutation, useQueryClient } from '@tanstack/react-query';
import { getApi } from '../api-client';
import { queryKeys } from './keys';
import type {
  DeviceListResponse,
  DeviceHistoryResponse,
  ComplianceResponse,
  BulkRevokeResponse,
  ExtendTokenResponse,
} from '@/types/provisioning-ops';
import { toast } from 'sonner';

/** Paginated device list */
export const devicesQueryOptions = (params: {
  limit?: number;
  offset?: number;
  search?: string;
  date_range?: string;
  platform?: string;
} = {}) =>
  queryOptions({
    queryKey: queryKeys.provisioningOps.devices(params as Record<string, unknown>),
    queryFn: () =>
      getApi().get<DeviceListResponse>('/provisioning/devices', {
        limit: params.limit,
        offset: params.offset,
        search: params.search,
        date_range: params.date_range,
        platform: params.platform,
      }),
    staleTime: 30_000,
  });

/** Device provisioning history */
export const deviceHistoryQueryOptions = (deviceId: string) =>
  queryOptions({
    queryKey: queryKeys.provisioningOps.deviceHistory(deviceId),
    queryFn: () =>
      getApi().get<DeviceHistoryResponse>(`/provisioning/devices/${deviceId}/history`),
    staleTime: 30_000,
    enabled: !!deviceId,
  });

/** Compliance alerts (server-side 60s cache) */
export const complianceQueryOptions = () =>
  queryOptions({
    queryKey: queryKeys.provisioningOps.compliance(),
    queryFn: () =>
      getApi().get<ComplianceResponse>('/provisioning/compliance'),
    staleTime: 60_000,
  });

/** Bulk revoke tokens */
export function useBulkRevokeTokens() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (tokenHashes: string[]) =>
      getApi().post<BulkRevokeResponse>('/provisioning/tokens/bulk-revoke', {
        token_hashes: tokenHashes,
      }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.qrCodes.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.provisioningOps.all });
      if (data.skipped_count > 0) {
        toast.warning(
          `${data.revoked_count} of ${data.revoked_count + data.skipped_count} tokens revoked. ${data.skipped_count} skipped.`,
        );
      } else {
        toast.success(`${data.revoked_count} tokens revoked successfully`);
      }
    },
    onError: () => {
      toast.error('Failed to revoke tokens. Please try again.');
    },
  });
}

/** Extend token expiry */
export function useExtendToken() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ tokenHash, extendSeconds }: { tokenHash: string; extendSeconds: number }) =>
      getApi().post<ExtendTokenResponse>(`/provisioning/tokens/${tokenHash}/extend`, {
        extend_seconds: extendSeconds,
      }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.qrCodes.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.provisioningOps.all });
      toast.success(`Token extended. New expiry: ${new Date(data.new_expires_at).toLocaleString()}`);
    },
    onError: () => {
      toast.error('Failed to extend token. It may exceed the maximum TTL.');
    },
  });
}
```

**Step 3: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit --pretty 2>&1 | head -20`
Expected: No new errors

**Step 4: Commit**

```bash
git add src/frontend/src/lib/queries/keys.ts src/frontend/src/lib/queries/provisioning-ops.ts
git commit -m "feat(queries): add provisioning ops query keys and options"
```

---

## Task 10: Frontend — Alert Type Config + Route Rewrite

**Files:**
- Create: `src/frontend/src/components/features/provisioning-ops/alert-type-config.ts`
- Rewrite: `src/frontend/src/routes/provisioning/tokens.tsx`

**Context:** The alert type config follows the pattern from `qr-management/qr-status-config.ts`. The route rewrite follows the pattern from `routes/provisioning/qr-codes.tsx`.

**Step 1: Create alert type config**

```typescript
/**
 * Compliance alert type configuration — icons, colors, severity badges.
 * Pattern: qr-management/qr-status-config.ts
 */

import {
  Clock,
  Zap,
  AlertTriangle,
  Hourglass,
  ShieldAlert,
  TrendingDown,
} from 'lucide-react';
import type { ComplianceAlertType, AlertSeverity } from '@/types';

export interface AlertTypeConfig {
  icon: typeof Clock;
  label: string;
  severity: AlertSeverity;
  badgeVariant: 'error' | 'warning' | 'outline';
  color: string;
  bg: string;
  description: string;
}

export const alertTypeConfig: Record<ComplianceAlertType, AlertTypeConfig> = {
  'expired-unused': {
    icon: Clock,
    label: 'Expired Unused',
    severity: 'warning',
    badgeVariant: 'warning',
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    description: 'Token expired without being consumed by any device',
  },
  'rapid-consumption': {
    icon: Zap,
    label: 'Rapid Consumption',
    severity: 'warning',
    badgeVariant: 'warning',
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    description: 'Token consumed within 60 seconds of issuance — unusually fast',
  },
  'multi-issue': {
    icon: AlertTriangle,
    label: 'Multi-Issue',
    severity: 'warning',
    badgeVariant: 'warning',
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    description: 'User has 3+ active tokens simultaneously — possible over-provisioning',
  },
  'stale-active': {
    icon: Hourglass,
    label: 'Stale Active',
    severity: 'low',
    badgeVariant: 'outline',
    color: 'text-gray-400',
    bg: 'bg-gray-500/10',
    description: 'Token is past 80% of its TTL without consumption — may need attention',
  },
  'cross-user-device': {
    icon: ShieldAlert,
    label: 'Cross-User Device',
    severity: 'critical',
    badgeVariant: 'error',
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    description: 'Device consumed tokens for multiple different users — investigate shared device',
  },
  'high-failure-rate': {
    icon: TrendingDown,
    label: 'High Failure Rate',
    severity: 'warning',
    badgeVariant: 'warning',
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    description: 'User has >3 unconsumed tokens in 30 days — provisioning workflow issue',
  },
};
```

**Step 2: Rewrite route file**

Replace entire contents of `routes/provisioning/tokens.tsx`:

```typescript
/**
 * Provisioning Operations page — /provisioning/tokens
 * Design: 2026-02-10-provisioning-ops-design.md
 */
import { createFileRoute } from '@tanstack/react-router';
import type { ProvisioningOpsSearchParams, OpsTab, OpsDateRange } from '@/types';

const validTabs: OpsTab[] = ['lifecycle', 'devices', 'compliance'];
const validDateRanges: OpsDateRange[] = ['7d', '30d', '90d', 'all'];

export const Route = createFileRoute('/provisioning/tokens')({
  validateSearch: (search: Record<string, unknown>): ProvisioningOpsSearchParams => ({
    tab: validTabs.includes(search.tab as OpsTab)
      ? (search.tab as OpsTab)
      : undefined,
    tokenHash: (search.tokenHash as string) || undefined,
    deviceId: (search.deviceId as string) || undefined,
    alertType: (search.alertType as string) || undefined,
    filter: (search.filter as string) || undefined,
    dateRange: validDateRanges.includes(search.dateRange as OpsDateRange)
      ? (search.dateRange as OpsDateRange)
      : '30d',
    search: (search.search as string) || undefined,
    page: search.page != null ? Number(search.page) || 0 : undefined,
    pageSize: search.pageSize != null ? Number(search.pageSize) || undefined : undefined,
  }),
  component: ProvisioningOpsRoute,
});

function ProvisioningOpsRoute() {
  const searchParams = Route.useSearch();
  // TODO: Replace with <ProvisioningOpsPage searchParams={searchParams} /> in Task 16
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold text-text">Provisioning Operations</h1>
      <p className="text-sm text-muted-foreground mt-2">
        Tab: {searchParams.tab || 'lifecycle'} | Date range: {searchParams.dateRange || '30d'}
      </p>
    </div>
  );
}
```

**Step 3: Regenerate route tree**

Run: `cd src/frontend && npx @tanstack/router-cli generate`
Expected: Route tree updated

**Step 4: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit --pretty 2>&1 | head -20`
Expected: No new errors

**Step 5: Commit**

```bash
git add src/frontend/src/components/features/provisioning-ops/alert-type-config.ts \
        src/frontend/src/routes/provisioning/tokens.tsx
git commit -m "feat(ui): add alert type config and rewrite provisioning ops route"
```

---

## Tasks 11–18: Frontend UI Components

> **Note for executor:** Tasks 11–18 build the React UI components. Each task creates 1–2 files in `src/frontend/src/components/features/provisioning-ops/`. Due to the size of these components, the implementation plan provides the component interface (props, imports, structure) rather than full JSX. The implementing subagent should reference these existing files for exact patterns:
>
> - **Split-panel orchestrator:** `components/features/qr-management/QRManagementPage.tsx`
> - **Detail panel:** `components/features/qr-management/QRDetailPanel.tsx`
> - **List with filters:** `components/features/qr-management/QRList.tsx`
> - **Status config:** `components/features/qr-management/qr-status-config.ts`
> - **Sidebar:** `components/layout/sidebar.tsx`
> - **Resize handle:** `components/layout/resize-handle.tsx`
> - **Hook:** `hooks/use-resizable-panel.ts`

### Task 11: DashboardHeader component

**Create:** `src/frontend/src/components/features/provisioning-ops/DashboardHeader.tsx`

- 6 stat cards in 3x2 grid (desktop) / 2 + expandable (mobile)
- Each card: number, label, visual indicator, click handler
- Props: `stats: QRStats | undefined`, `isLoading: boolean`, `onCardClick: (tab: OpsTab, filter?: string) => void`
- Uses `Skeleton` for loading state
- Reference `qr-management/PageHeader.tsx` for trend indicator pattern

### Task 12: LifecycleTab + LifecycleDetailPanel

**Create:** `src/frontend/src/components/features/provisioning-ops/LifecycleTab.tsx`
**Create:** `src/frontend/src/components/features/provisioning-ops/LifecycleDetailPanel.tsx`

- Left: `DataTable` with 6 columns, `ToggleChipGroup` filters, `Checkbox` bulk selection, bulk action bar
- Right: Token details (`DetailGrid`/`FieldCard`), user info, timeline, action buttons, cross-nav links
- Uses `qrCodesQueryOptions` with pseudo-status support
- Reuses `GenerateQRModal` from `qr-management/modals/GenerateQRModal.tsx`

### Task 13: DevicesTab + DeviceDetailPanel

**Create:** `src/frontend/src/components/features/provisioning-ops/DevicesTab.tsx`
**Create:** `src/frontend/src/components/features/provisioning-ops/DeviceDetailPanel.tsx`

- Left: `DataTable` with device columns, filter chips
- Right: Device summary, provisioning history timeline, shared device warning
- Uses `devicesQueryOptions` and `deviceHistoryQueryOptions`
- Empty state for deployments without device data

### Task 14: ComplianceTab + ComplianceDetailPanel

**Create:** `src/frontend/src/components/features/provisioning-ops/ComplianceTab.tsx`
**Create:** `src/frontend/src/components/features/provisioning-ops/ComplianceDetailPanel.tsx`

- Alert summary strip (horizontal cards per alert type)
- Alert list with severity, type, subject, actions
- `localStorage` dismiss with 24h TTL
- Uses `complianceQueryOptions` and `alertTypeConfig`

### Task 15: ProvisioningOpsPage orchestrator

**Create:** `src/frontend/src/components/features/provisioning-ops/ProvisioningOpsPage.tsx`

- Composes DashboardHeader + Tabs + split-panel (left=tab content, right=detail)
- `useResizablePanel()` with `storageKey: 'panel-width:provisioning-ops'`
- URL search params as state via `navigate({ replace: true })`
- `Suspense` boundaries per data-fetching section
- Modal state machine for bulk revoke AlertDialog + Generate QR modal
- Keyboard shortcuts: `Cmd/Ctrl+K`, `Escape`, arrow keys

### Task 16: Wire route to ProvisioningOpsPage

**Modify:** `src/frontend/src/routes/provisioning/tokens.tsx`

- Replace placeholder with `<ProvisioningOpsPage searchParams={searchParams} />`
- Import from `@/components/features/provisioning-ops/ProvisioningOpsPage`

### Task 17: Sidebar updates

**Modify:** `src/frontend/src/components/layout/sidebar.tsx`

- Rename "QR Generator" → "QR Codes", fix href to `/provisioning/qr-codes`
- Rename "Tokens" → "Provisioning Ops"
- Add compliance alert dot indicator (red for critical, amber for warnings)

### Task 18: Cross-page navigation links

**Modify:** `src/frontend/src/components/features/qr-management/QRDetailPanel.tsx`

- Add "View in Provisioning Ops" link → `/provisioning/tokens?tab=lifecycle&tokenHash=...`
- Uses `KeyRound` icon, amber color, follows existing "View full audit log" pattern

---

## Execution Notes

- **Backend hot reload:** Python changes auto-reload via uvicorn (wait ~1s). No rebuild needed.
- **Frontend hot reload:** Vite HMR handles `.tsx` changes. Run `just ui-routes` after modifying route files.
- **Test stack:** Must be running. Start with `just up-bg` if not already up.
- **Auth for tests:** Use `mei` / `password123` for login. See `conftest.py` fixtures.
- **Test command:** `just test-quick -- <path>::<class>::<method> -v`
