# Audit Log Migration — Design Document

Date: 2026-02-10
Status: Approved
Estimated effort: ~13 hours (5 phases + reviews)

## Context

Migrate the audit log page to the React split-panel architecture established by users and groups migrations. The audit log is read-only, displays heterogeneous events from 4 backend sources, and introduces server-side pagination and bidirectional cross-page navigation with QR codes.

Reference documents:
- Spec: `new-migration-ui/AUDIT_LOG_MIGRATION_SPEC.md`
- Prototype: `new-migration-ui/audit-log-content-only.html`
- Workflow rules: `.cursor/rules/split-panel-migration-workflow.mdc`
- Post-mortem: `docs/domains/split-panel-migrations.md`

## Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Data source | New unified `GET /api/audit/events` | Server-side pagination, filtering, sorting across 4 tables in SQL |
| Phase structure | 5 phases (not 7) | Read-only — no CRUD modals, no relations, no RBAC |
| FilterChip | `@azblink/ui` primitive (`ToggleChipGroup`) | Reusable for future orgs migration |
| JSON viewer | `@azblink/ui` primitive (`CodeBlock`, minimal `<pre>`) | Matches prototype, zero dependencies |
| Cross-page nav | Bidirectional, wired during migration | Completes Audit ↔ QR contract in one pass |
| `qr-scanned` event type | Dropped for v1 | Backend has no scan-vs-consume granularity yet |
| State management | URL search params (no Zustand) | Consistent with prior migrations, enables bookmarking |
| Chip filtering | Client-side within fetched page | Avoids confusing pagination with server-side chip filters |

## Backend — Unified Endpoint

### New endpoint: `GET /api/audit/events`

Query parameters:

| Param | Type | Default | Notes |
|-------|------|---------|-------|
| `page` | int | 1 | 1-indexed |
| `page_size` | int | 20 | Max 100 |
| `time_range` | enum | `7d` | `today`, `7d`, `30d`, `90d`, `all` |
| `category` | enum | `all` | `all`, `qr`, `user`, `auth`, `config` |
| `search` | string | `""` | Searches actor, target, reference_id, description |
| `qr_id` | string? | `null` | Filter to events related to a specific QR code |

Response shape:

```json
{
  "ok": true,
  "events": [
    {
      "id": "AUD-2026-00123",
      "event_type": "qr-generated",
      "timestamp": "2026-02-01T10:23:42Z",
      "title": "QR Code Generated",
      "description": "Valid for 1 hour, sent via email",
      "actor": "Sarah Kim",
      "target": "Alice Chen",
      "reference_id": "QR-2026-0156",
      "result": "success",
      "category": "qr",
      "duration_ms": null,
      "organization": "Engineering",
      "ip_address": "192.168.1.42",
      "device": null,
      "raw_data": { "...": "..." }
    }
  ],
  "pagination": {
    "page": 1,
    "page_size": 20,
    "total_events": 1247,
    "total_pages": 63
  }
}
```

### SQL strategy — UNION ALL with event type derivation

Each source table maps to the unified shape:

| Source Table | → event_type(s) | → actor | → target | → reference_id |
|---|---|---|---|---|
| `qr_issuance_audit` | `qr-generated`, `qr-consumed`, `qr-expired`, `qr-revoked` | `issued_by` | `user_uid` | `QR-` + token_hash prefix |
| `termination_events` | `user-terminated` | `terminated_by` | `user_uid` | `TRM-` + id |
| `auth_failure_audit` | `login` | `username` | `—` | `SES-` + id |
| `user_lifecycle_audit` | `user-created`, `sso-enrolled`, `config-change` | `performed_by` | `user_uid` | `USR-` + id |

QR event type derivation (SQL CASE):
- `consumed_reason = 'admin_revoked'` → `qr-revoked`
- `consumed = True` → `qr-consumed`
- `consumed = False AND expires_at < now()` → `qr-expired`
- Otherwise → `qr-generated`

User lifecycle action mapping:
- `created` → `user-created`
- Other actions → mapped by `action` field value

Device info: LEFT JOIN to `provision_tokens` on `token_hash` for consumed QR events.

Implementation:
- `src/backend/orgdb.py` — New `list_unified_audit()` method
- `src/backend/main.py` — New `GET /api/audit/events` endpoint
- Existing 4 endpoints stay untouched for current consumers

### Performance considerations

- Add `timestamp` indexes on all 4 audit tables if missing
- UNION ALL bounded by `WHERE timestamp > now() - interval` before pagination
- Profile with `EXPLAIN ANALYZE` during Phase 0

## Frontend — TypeScript Types

New types added to `src/frontend/src/types/audit.ts` (existing types kept):

```ts
type AuditEventType =
  | 'qr-generated' | 'qr-consumed'
  | 'qr-expired'   | 'qr-revoked'
  | 'user-created'  | 'user-terminated'
  | 'sso-enrolled'  | 'config-change' | 'login';

type EventCategory = 'qr' | 'user' | 'auth' | 'config';
type TimeRange = 'today' | '7d' | '30d' | '90d' | 'all';
type EventResult = 'success' | 'failure' | 'warning';

interface AuditEvent {
  id: string;
  event_type: AuditEventType;
  timestamp: string;
  title: string;
  description: string;
  actor: string;
  target: string;
  reference_id: string | null;
  result: EventResult;
  category: EventCategory;
  duration_ms: number | null;
  organization: string | null;
  ip_address: string | null;
  device: DeviceInfo | null;
  raw_data: Record<string, unknown>;
}

interface DeviceInfo {
  model: string;
  os: string;
  app_version: string | null;
  user_agent: string | null;
}

interface AuditEventsResponse {
  ok: boolean;
  events: AuditEvent[];
  pagination: {
    page: number;
    page_size: number;
    total_events: number;
    total_pages: number;
  };
}
```

## Frontend — Component Tree

```
src/frontend/src/components/features/audit-management/
├── AuditLogPage.tsx              ← Route orchestrator (split-panel grid)
├── PageHeader.tsx                ← Title + FilterContextBanner + search + export
├── AuditFilterBar.tsx            ← Time/category selects + ToggleChipGroup + LiveIndicator
├── AuditList.tsx                 ← ListPanel wrapper (header, columns, body, footer)
├── AuditRow.tsx                  ← Event row with icon, timestamp, clickable ref
├── AuditDetailPanel.tsx          ← Right panel: sections + CodeBlock + cross-ref
└── audit-event-config.ts         ← EVENT_CONFIG: 9 types → icon + bg/fg classes

src/frontend/src/routes/audit-log/
└── index.tsx                     ← Route with validateSearch

src/frontend/src/lib/queries/
└── audit.ts                      ← Add auditEventsQueryOptions (keep existing hooks)

src/frontend/packages/azblink-ui/primitives/
├── ToggleChipGroup/              ← NEW primitive
└── CodeBlock/                    ← NEW primitive
```

### Reuse inventory

| Component | Source | Status |
|-----------|--------|--------|
| `ListPanel` + sub-components | `@azblink/ui` | Exists |
| `Pagination` | `@azblink/ui` | Exists |
| `Badge` | `@azblink/ui` | Exists |
| `Button` | `@azblink/ui` | Exists |
| `Input` | `@azblink/ui` | Exists |
| `DetailGrid` / `InfoField` | `@azblink/ui` | Exists |
| `ToggleChipGroup` | `@azblink/ui` | **New** |
| `CodeBlock` | `@azblink/ui` | **New** |
| `SearchInput` pattern | `user-management/` | Adapt |
| `audit-event-config.ts` | `audit-management/` | **New** (follows `group-type-config.ts` pattern) |

## State Architecture

### URL search params (source of truth)

```
/audit-log?eventId=AUD-XXX&qr=QR-XXXX&timeRange=7d&category=all&search=alice&page=1&chips=qr-generated,qr-consumed
```

| Param | Drives | Side effect |
|-------|--------|-------------|
| `eventId` | Detail panel open/close | Row selection highlight |
| `qr` | FilterContextBanner + search pre-fill + row highlighting | Query `qr_id` filter |
| `timeRange` | API filter | Resets `page=1` on change |
| `category` | API filter | Resets `page=1` on change |
| `search` | API filter (debounced 300ms) | Resets `page=1` on change |
| `page` | API pagination | Direct server-side |
| `chips` | Client-side row visibility | Comma-separated Set serialization |

### TanStack Query

```ts
auditEventsQueryOptions({
  page, pageSize, timeRange, category, search, qrId
})
// queryKey: ['audit', 'events', { page, timeRange, category, search, qrId, pageSize }]
// staleTime: 15_000
```

### Data flow

```
URL params → validateSearch → AuditLogPage props
  ├── server-side params → auditEventsQueryOptions → API → events[]
  ├── chips param → client-side filter on events[] → visible rows
  ├── eventId param → selectedEvent lookup → AuditDetailPanel
  └── qr param → FilterContextBanner + row highlighting
```

## Cross-Page Navigation

### Bidirectional contract

| Direction | Trigger | Navigation |
|-----------|---------|------------|
| Audit → QR | Click `QR-` reference in table row | `/provisioning/qr-codes?qrId=QR-XXXX` |
| Audit → QR | Click cross-reference in detail panel | `/provisioning/qr-codes?qrId=QR-XXXX` |
| QR → Audit | "View in Audit Log" in QR detail panel | `/audit-log?qr=QR-XXXX` |

### URL parameter contract

```
/audit-log?qr=QR-2026-0156
  → FilterContextBanner: "Filtered by QR: QR-2026-0156"
  → Search box pre-filled
  → Matching rows highlighted with bg-blue-500/10
  → API filtered by qr_id

/provisioning/qr-codes?qrId=QR-2026-0156
  → Selects matching QR row
  → Opens detail panel
```

### Shared reference ID prefixes

| Prefix | Entity | Links to |
|--------|--------|----------|
| `QR-` | QR Code | `/provisioning/qr-codes?qrId=` |
| `TRM-` | Termination | Detail only (no cross-page) |
| `USR-` | User | `/directory/users?userId=` (future) |
| `CFG-` | Config | Detail only |
| `SES-` | Session | Detail only |

## Responsive Breakpoints

| Breakpoint | Layout |
|------------|--------|
| >1100px | 2-col grid: table (1fr) + detail (380px) |
| ≤1100px | 1-col: detail below table |
| ≤768px | Hide Actor + Reference table columns |
| ≤500px | Filter selects stack vertically, pagination simplified (prev/next only) |

## Phase Plan

### Phase 0 — Backend endpoint + types + primitives (~3h)

**Backend:**
- `src/backend/orgdb.py` — Add `list_unified_audit()` with UNION ALL + LEFT JOIN
- `src/backend/main.py` — Add `GET /api/audit/events`

**Frontend types:**
- `src/frontend/src/types/audit.ts` — Add unified types (keep existing)

**Frontend query:**
- `src/frontend/src/lib/queries/audit.ts` — Add `auditEventsQueryOptions`

**New primitives:**
- `src/frontend/packages/azblink-ui/primitives/ToggleChipGroup/`
- `src/frontend/packages/azblink-ui/primitives/CodeBlock/`
- `src/frontend/packages/azblink-ui/index.ts` — Barrel exports

**Event config:**
- `src/frontend/src/components/features/audit-management/audit-event-config.ts`

**Verify:** `just test` passes, endpoint returns data, primitives render.

### Phase 1 — Route + split-panel shell + table (~2h)

**Route:**
- `src/frontend/src/routes/audit-log/index.tsx` — `validateSearch` + component

**Components:**
- `AuditLogPage.tsx` — Split-panel grid, Suspense boundaries
- `AuditList.tsx` — ListPanel (header, columns, body with rows, footer with Pagination)
- `AuditRow.tsx` — Event row (icon, timestamp, event details, actor, target, reference)

**Verify:** Page at `/audit-log`, rows render, row click updates URL, pagination works.

### Phase 2 — Detail panel (~2h)

**Components:**
- `AuditDetailPanel.tsx` — Sticky sidebar with sections:
  - Header: large event icon + title + event ID + close button
  - Event Details: timestamp, type, result, duration (DetailGrid + InfoField)
  - Actor & Target: actor, target, org, IP
  - Cross-reference: link to QR codes page (conditional on `QR-` prefix)
  - Device Information: model, OS, app version, user agent (conditional)
  - Provisioning Details: configs applied (conditional on `qr-consumed`)
  - Raw Event Data: CodeBlock with JSON.stringify

**Verify:** Click row → detail panel, close deselects, cross-ref navigates.

### Phase 3 — Filters & search (~2h)

**Components:**
- `PageHeader.tsx` — Title + FilterContextBanner (conditional on `?qr=`) + search (debounced 300ms) + export button
- `AuditFilterBar.tsx` — Time range select + category select + ToggleChipGroup (4 chips) + LiveIndicator (decorative pulse)

**Behavior:**
- Search debounce 300ms before URL update
- Filter changes reset page=1
- Chips toggle client-side (Set add/delete, serialized as comma-separated URL param)
- QR banner reads `?qr=` on mount, clears on button click
- Live indicator: CSS-only pulse, no WebSocket

**Verify:** All filter combos work, debounce doesn't over-fire, chips toggle rows, QR banner appears from cross-page nav.

### Phase 4 — Cross-page nav + responsive + polish + a11y (~2h)

**Cross-page:**
- `AuditRow.tsx` — `QR-` refs navigate to `/provisioning/qr-codes?qrId=QR-XXXX`
- `AuditDetailPanel.tsx` — Cross-reference navigates to QR codes page
- `QRDetailPanel.tsx` — **Existing file edit:** Add "View in Audit Log" link → `/audit-log?qr=QR-XXXX`

**Responsive:** Column hiding at 768px, grid collapse at 1100px, mobile at 500px.

**Row highlighting:** `?qr=` matching rows get `bg-blue-500/10`.

**Export:** Download current filtered results as CSV.

**Accessibility:**
- `aria-current="true"` on selected row
- `aria-live="polite"` on event count
- `aria-label` on icon-only buttons
- Keyboard: arrow keys for row nav, Escape closes panel, Cmd+K focuses search

**Verify:** Bidirectional QR↔Audit round-trip, responsive breakpoints, keyboard nav, screen reader.

### Reviews + Fixes (~2h)

Per-phase reviews per workflow rules. Fix CRITICAL/IMPORTANT before proceeding. Final cross-cutting review after Phase 4.

## Risks & Mitigations

| Risk | Likelihood | Mitigation |
|---|---|---|
| UNION ALL performance | Medium | Timestamp indexes, bounded WHERE clause, EXPLAIN ANALYZE in Phase 0 |
| QR event type derivation bugs | High | Explicit SQL CASE with comments, backend test per derivation path |
| Silent exception in UNION JOIN | Medium | `logger.warning(...)` on null device where consumed=True |
| Stale query key | High | All 6 params in query key array, TypeScript enforced |
| Double error toast | High | Error handling ONLY in component, never in query options |
| Chip state serialization | Medium | Comma-separated string in URL, parsed to Set in validateSearch |
| Cross-page param mismatch | High | QR uses `qrId`, audit uses `qr` — documented in contract |
| `qr-scanned` absent from backend | High | Dropped for v1, 9 event types only |

## Deferred to Future

- `qr-scanned` event type (needs backend scan-vs-consume granularity)
- Live updates via WebSocket/SSE (LiveIndicator is decorative only in v1)
- `USR-` reference cross-page nav to `/directory/users` (future)
- Custom date range picker for `timeRange=custom`
- Export as PDF/Excel (CSV only in v1)
