# UED Sync Integration — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add async event-driven sync from AZBlink Directory to per-tenant UED Sync API instances for XMPP/SIP provisioning.

**Architecture:** API routes emit sync events to PostgreSQL after LDAP writes. A background asyncio worker polls pending events, fetches per-tenant UED config (with Fernet-encrypted secrets), and POSTs to UED Sync API. Exponential backoff retries with strict per-user ordering.

**Tech Stack:** FastAPI (existing), SQLAlchemy Core (existing pattern), `cryptography` (Fernet), `httpx` (async HTTP), PostgreSQL

**Design Doc:** `docs/plans/2026-02-13-ued-sync-integration-design.md`

---

## Task 1: Database Migration

**Files:**
- Create: `migrations/010_ued_sync.sql`

**Step 1: Write the migration SQL**

```sql
-- migrations/010_ued_sync.sql
-- UED Sync Integration: tenant configs + async sync event queue

BEGIN;

-- Tenant UED connection configs (one per tenant)
CREATE TABLE IF NOT EXISTS tenant_ldap_configs (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id        TEXT NOT NULL,
    name             TEXT NOT NULL,
    ued_api_url      TEXT NOT NULL,
    ued_api_key_enc  TEXT NOT NULL,
    ldap_uri         TEXT NOT NULL,
    ldap_base_dn     TEXT NOT NULL,
    ldap_bind_dn     TEXT NOT NULL,
    ldap_bind_pw_enc TEXT NOT NULL,
    ldap_use_ssl     BOOLEAN NOT NULL DEFAULT TRUE,
    ldap_timeout_ms  INTEGER NOT NULL DEFAULT 5000,
    schema_config    JSONB NOT NULL,
    enabled          BOOLEAN NOT NULL DEFAULT TRUE,
    last_sync_at     TIMESTAMPTZ,
    last_error       TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id)
);

-- Async sync event queue
CREATE TABLE IF NOT EXISTS sync_events (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id     TEXT NOT NULL REFERENCES tenant_ldap_configs(tenant_id) ON DELETE CASCADE,
    user_uid      TEXT NOT NULL,
    event_type    TEXT NOT NULL,
    payload       JSONB NOT NULL,
    status        TEXT NOT NULL DEFAULT 'pending',
    attempts      INTEGER NOT NULL DEFAULT 0,
    max_attempts  INTEGER NOT NULL DEFAULT 10,
    next_retry_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_error    TEXT,
    request_id    UUID DEFAULT gen_random_uuid(),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at  TIMESTAMPTZ,

    CONSTRAINT valid_event_type CHECK (event_type IN (
        'user_created','user_updated','user_suspended',
        'user_unsuspended','user_terminated','password_changed'
    )),
    CONSTRAINT valid_status CHECK (status IN ('pending','in_progress','completed','failed'))
);

-- Worker polling index
CREATE INDEX idx_sync_events_pending
    ON sync_events (next_retry_at)
    WHERE status IN ('pending', 'in_progress');

-- Per-user ordering index
CREATE INDEX idx_sync_events_user_ordering
    ON sync_events (tenant_id, user_uid, created_at)
    WHERE status IN ('pending', 'in_progress');

-- Retention cleanup index
CREATE INDEX idx_sync_events_completed
    ON sync_events (completed_at)
    WHERE status = 'completed';

-- Dashboard: failed events
CREATE INDEX idx_sync_events_failed
    ON sync_events (created_at DESC)
    WHERE status = 'failed';

COMMIT;
```

**Step 2: Verify migration applies cleanly**

Run: `cd deploy/dev && docker compose exec postgres psql -U azblink_directory -f /dev/stdin < ../../migrations/010_ued_sync.sql`
Expected: `COMMIT` with no errors

**Step 3: Verify tables exist**

Run: `cd deploy/dev && docker compose exec postgres psql -U azblink_directory -c "\dt tenant_ldap_configs" -c "\dt sync_events"`
Expected: Both tables listed

**Step 4: Commit**

```bash
git add migrations/010_ued_sync.sql
git commit -m "feat(db): add tenant_ldap_configs and sync_events tables for UED integration"
```

---

## Task 2: Fernet Encryption Module

**Files:**
- Create: `src/backend/ued_crypto.py`
- Create: `tests/test_ued_crypto.py`

**Step 1: Write the failing tests**

```python
# tests/test_ued_crypto.py
"""Tests for UED Fernet encryption module."""

import os
import sys
from pathlib import Path

# Add backend to path (same pattern as conftest.py)
_backend_path = Path(__file__).parent.parent / "src" / "backend"
if str(_backend_path) not in sys.path:
    sys.path.insert(0, str(_backend_path))

import pytest


@pytest.fixture(autouse=True)
def set_encryption_key(monkeypatch):
    """Set a valid Fernet key for all tests."""
    # Generate a deterministic test key (valid Fernet key = 32 bytes base64url)
    from cryptography.fernet import Fernet
    key = Fernet.generate_key().decode()
    monkeypatch.setenv("UED_ENCRYPTION_KEY", key)


class TestEncryptDecrypt:
    def test_roundtrip(self):
        from ued_crypto import encrypt_value, decrypt_value
        plaintext = "my-secret-password"
        ciphertext = encrypt_value(plaintext)
        assert ciphertext != plaintext
        assert decrypt_value(ciphertext) == plaintext

    def test_different_ciphertexts_each_time(self):
        """Fernet includes timestamp+IV, so same plaintext -> different ciphertext."""
        from ued_crypto import encrypt_value
        a = encrypt_value("same")
        b = encrypt_value("same")
        assert a != b

    def test_empty_string(self):
        from ued_crypto import encrypt_value, decrypt_value
        ct = encrypt_value("")
        assert decrypt_value(ct) == ""

    def test_unicode(self):
        from ued_crypto import encrypt_value, decrypt_value
        ct = encrypt_value("pässwörd-日本語")
        assert decrypt_value(ct) == "pässwörd-日本語"

    def test_missing_key_raises(self, monkeypatch):
        monkeypatch.delenv("UED_ENCRYPTION_KEY", raising=False)
        from ued_crypto import encrypt_value
        with pytest.raises(RuntimeError, match="UED_ENCRYPTION_KEY"):
            encrypt_value("test")


class TestPayloadPassword:
    def test_encrypt_password_field(self):
        from ued_crypto import encrypt_payload_password, decrypt_payload_password
        payload = {"user": {"uid": "j.doe"}, "password": "secret123"}
        encrypted = encrypt_payload_password(payload)
        # Original not mutated
        assert payload["password"] == "secret123"
        # Encrypted version differs
        assert encrypted["password"] != "secret123"
        # User data untouched
        assert encrypted["user"]["uid"] == "j.doe"
        # Roundtrip
        decrypted = decrypt_payload_password(encrypted)
        assert decrypted["password"] == "secret123"

    def test_encrypt_new_password_field(self):
        from ued_crypto import encrypt_payload_password, decrypt_payload_password
        payload = {"user": {"uid": "j.doe", "dn": "uid=j.doe,ou=people,dc=ex,dc=com"}, "new_password": "newpass"}
        encrypted = encrypt_payload_password(payload)
        assert encrypted["new_password"] != "newpass"
        decrypted = decrypt_payload_password(encrypted)
        assert decrypted["new_password"] == "newpass"

    def test_no_password_field_noop(self):
        from ued_crypto import encrypt_payload_password
        payload = {"user": {"uid": "j.doe"}}
        encrypted = encrypt_payload_password(payload)
        assert encrypted == payload

    def test_does_not_mutate_input(self):
        from ued_crypto import encrypt_payload_password
        payload = {"user": {"uid": "j.doe"}, "password": "secret"}
        encrypt_payload_password(payload)
        assert payload["password"] == "secret"
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_ued_crypto.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'ued_crypto'`

**Step 3: Write minimal implementation**

```python
# src/backend/ued_crypto.py
"""Fernet encryption for UED tenant secrets (API keys, LDAP bind passwords).

- Encrypts: ued_api_key, ldap_bind_pw, password fields in sync_event payloads
- Key source: UED_ENCRYPTION_KEY env var (Fernet-compatible base64 key)
- Generate key: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
"""

import copy
import os

from cryptography.fernet import Fernet


def _get_fernet() -> Fernet:
    """Get Fernet instance from UED_ENCRYPTION_KEY env var."""
    key = os.getenv("UED_ENCRYPTION_KEY", "")
    if not key:
        raise RuntimeError(
            "UED_ENCRYPTION_KEY not set. Required for UED sync integration. "
            "Generate with: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
        )
    return Fernet(key.encode())


def encrypt_value(plaintext: str) -> str:
    """Encrypt a string -> Fernet token (URL-safe base64 string)."""
    f = _get_fernet()
    return f.encrypt(plaintext.encode("utf-8")).decode("ascii")


def decrypt_value(ciphertext: str) -> str:
    """Decrypt a Fernet token -> plaintext string."""
    f = _get_fernet()
    return f.decrypt(ciphertext.encode("ascii")).decode("utf-8")


def encrypt_payload_password(payload: dict) -> dict:
    """Deep-copy payload, encrypt 'password' or 'new_password' field if present."""
    result = copy.deepcopy(payload)
    for field in ("password", "new_password"):
        if field in result and result[field]:
            result[field] = encrypt_value(result[field])
    return result


def decrypt_payload_password(payload: dict) -> dict:
    """Deep-copy payload, decrypt 'password' or 'new_password' field if present."""
    result = copy.deepcopy(payload)
    for field in ("password", "new_password"):
        if field in result and result[field]:
            result[field] = decrypt_value(result[field])
    return result
```

**Step 4: Run tests to verify they pass**

Run: `pytest tests/test_ued_crypto.py -v`
Expected: All 8 tests PASS

**Step 5: Commit**

```bash
git add src/backend/ued_crypto.py tests/test_ued_crypto.py
git commit -m "feat: add Fernet encryption module for UED tenant secrets"
```

---

## Task 3: Config + Dependencies

**Files:**
- Modify: `src/backend/config.py` (add `UED_ENCRYPTION_KEY` after line 86)
- Modify: `src/backend/requirements.txt` (add 2 packages)
- Modify: `deploy/dev/.env.example` (add UED section)

**Step 1: Add UED_ENCRYPTION_KEY to config.py**

Add after the Redis section (after line 86):

```python
# ----------------------------
# UED Sync Integration (optional)
# ----------------------------
# Fernet encryption key for tenant LDAP secrets at rest.
# Required only when tenant_ldap_configs has rows.
# Generate: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
UED_ENCRYPTION_KEY = os.getenv("UED_ENCRYPTION_KEY", "")
```

**Step 2: Add dependencies to requirements.txt**

Append to `src/backend/requirements.txt`:

```
cryptography>=42.0
httpx>=0.27
```

**Step 3: Add env example**

Append to `deploy/dev/.env.example`:

```
# UED Sync Integration (optional — only needed if connecting to UED Sync API)
# UED_ENCRYPTION_KEY=  # Generate: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

**Step 4: Rebuild API to pick up new deps**

Run: `just api-rebuild`
Expected: Container rebuilds and starts healthy

**Step 5: Verify health**

Run: `just health-check`
Expected: `✓ All systems healthy`

**Step 6: Commit**

```bash
git add src/backend/config.py src/backend/requirements.txt deploy/dev/.env.example
git commit -m "feat: add UED encryption key config and httpx/cryptography deps"
```

---

## Task 4: OrgDB — Table Definitions + CRUD Methods

**Files:**
- Modify: `src/backend/orgdb.py` (add table defs + 8 methods)
- Create: `tests/test_ued_orgdb.py`

**Step 1: Write failing tests for tenant config CRUD**

```python
# tests/test_ued_orgdb.py
"""Tests for UED sync OrgDB methods (tenant configs + sync events)."""

import os
import sys
from pathlib import Path

_backend_path = Path(__file__).parent.parent / "src" / "backend"
if str(_backend_path) not in sys.path:
    sys.path.insert(0, str(_backend_path))

import pytest
import psycopg2


@pytest.fixture(scope="session")
def db_conn():
    """Direct Postgres connection."""
    conn = psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "localhost"),
        port=int(os.getenv("POSTGRES_PORT", "5433")),
        database="azblink_directory",
        user="azblink_directory",
        password="azblink_directory",
    )
    conn.autocommit = True
    yield conn
    conn.close()


@pytest.fixture
def orgdb():
    """OrgDB instance connected to test database."""
    from orgdb import OrgDB
    db_url = os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg2://azblink_directory:azblink_directory@localhost:5433/azblink_directory",
    )
    db = OrgDB(db_url)
    db.init()
    return db


@pytest.fixture(autouse=True)
def cleanup_ued_tables(db_conn):
    """Clean UED tables before each test."""
    with db_conn.cursor() as cur:
        cur.execute("DELETE FROM sync_events")
        cur.execute("DELETE FROM tenant_ldap_configs")
    yield
    with db_conn.cursor() as cur:
        cur.execute("DELETE FROM sync_events")
        cur.execute("DELETE FROM tenant_ldap_configs")


SAMPLE_SCHEMA_CONFIG = {
    "dn_template": "uid={uid},ou=people,{base_dn}",
    "object_classes": ["top", "account", "posixAccount"],
    "attribute_map": {"uid": "{username}", "cn": "{full_name}"},
    "required_fields": ["username", "full_name"],
    "optional_fields": [],
    "password_attribute": "userPassword",
    "password_hash": "SSHA",
}


class TestTenantConfigCRUD:
    def test_create_and_get(self, orgdb):
        config_id = orgdb.create_tenant_ldap_config(
            tenant_id="test-tenant",
            name="Test Tenant UC",
            ued_api_url="https://ued-test:8000",
            ued_api_key_enc="encrypted-key-here",
            ldap_uri="ldap://test:389",
            ldap_base_dn="dc=test,dc=com",
            ldap_bind_dn="cn=admin,dc=test,dc=com",
            ldap_bind_pw_enc="encrypted-pw-here",
            schema_config=SAMPLE_SCHEMA_CONFIG,
        )
        assert config_id is not None

        config = orgdb.get_tenant_ldap_config("test-tenant")
        assert config is not None
        assert config["name"] == "Test Tenant UC"
        assert config["ued_api_url"] == "https://ued-test:8000"
        assert config["enabled"] is True
        assert config["schema_config"] == SAMPLE_SCHEMA_CONFIG

    def test_get_nonexistent_returns_none(self, orgdb):
        assert orgdb.get_tenant_ldap_config("nonexistent") is None

    def test_list_configs(self, orgdb):
        orgdb.create_tenant_ldap_config(
            tenant_id="t1", name="T1", ued_api_url="https://ued1:8000",
            ued_api_key_enc="k1", ldap_uri="ldap://1:389",
            ldap_base_dn="dc=1", ldap_bind_dn="cn=admin,dc=1",
            ldap_bind_pw_enc="pw1", schema_config=SAMPLE_SCHEMA_CONFIG,
        )
        configs = orgdb.list_tenant_ldap_configs()
        assert len(configs) >= 1
        assert any(c["tenant_id"] == "t1" for c in configs)

    def test_update_config(self, orgdb):
        orgdb.create_tenant_ldap_config(
            tenant_id="t-upd", name="Original", ued_api_url="https://old:8000",
            ued_api_key_enc="k", ldap_uri="ldap://1:389",
            ldap_base_dn="dc=1", ldap_bind_dn="cn=admin,dc=1",
            ldap_bind_pw_enc="pw", schema_config=SAMPLE_SCHEMA_CONFIG,
        )
        config = orgdb.get_tenant_ldap_config("t-upd")
        orgdb.update_tenant_ldap_config(config["id"], name="Updated", ued_api_url="https://new:8000")
        updated = orgdb.get_tenant_ldap_config("t-upd")
        assert updated["name"] == "Updated"
        assert updated["ued_api_url"] == "https://new:8000"

    def test_delete_config(self, orgdb):
        orgdb.create_tenant_ldap_config(
            tenant_id="t-del", name="ToDelete", ued_api_url="https://del:8000",
            ued_api_key_enc="k", ldap_uri="ldap://1:389",
            ldap_base_dn="dc=1", ldap_bind_dn="cn=admin,dc=1",
            ldap_bind_pw_enc="pw", schema_config=SAMPLE_SCHEMA_CONFIG,
        )
        config = orgdb.get_tenant_ldap_config("t-del")
        orgdb.delete_tenant_ldap_config(config["id"])
        assert orgdb.get_tenant_ldap_config("t-del") is None


class TestSyncEventCRUD:
    def _create_tenant(self, orgdb, tenant_id="sync-tenant"):
        orgdb.create_tenant_ldap_config(
            tenant_id=tenant_id, name="Sync Test", ued_api_url="https://ued:8000",
            ued_api_key_enc="k", ldap_uri="ldap://1:389",
            ldap_base_dn="dc=1", ldap_bind_dn="cn=admin,dc=1",
            ldap_bind_pw_enc="pw", schema_config=SAMPLE_SCHEMA_CONFIG,
        )

    def test_insert_and_list_pending(self, orgdb):
        self._create_tenant(orgdb)
        orgdb.insert_sync_event(
            tenant_id="sync-tenant",
            user_uid="j.doe",
            event_type="user_created",
            payload={"user": {"uid": "j.doe", "cn": "Jane Doe"}},
        )
        pending = orgdb.list_pending_sync_events(limit=10)
        assert len(pending) >= 1
        evt = pending[0]
        assert evt["user_uid"] == "j.doe"
        assert evt["event_type"] == "user_created"
        assert evt["status"] == "pending"

    def test_mark_in_progress(self, orgdb):
        self._create_tenant(orgdb)
        orgdb.insert_sync_event("sync-tenant", "u1", "user_created", {"user": {"uid": "u1"}})
        pending = orgdb.list_pending_sync_events(limit=10)
        evt_id = pending[0]["id"]
        orgdb.mark_sync_event_in_progress(evt_id)
        # Should not appear in pending list anymore
        still_pending = orgdb.list_pending_sync_events(limit=10)
        pending_ids = [e["id"] for e in still_pending]
        assert evt_id not in pending_ids

    def test_mark_completed(self, orgdb):
        self._create_tenant(orgdb)
        orgdb.insert_sync_event("sync-tenant", "u2", "user_created", {"user": {"uid": "u2"}})
        pending = orgdb.list_pending_sync_events(limit=10)
        evt_id = pending[0]["id"]
        orgdb.mark_sync_event_completed(evt_id)
        evt = orgdb.get_sync_event(evt_id)
        assert evt["status"] == "completed"
        assert evt["completed_at"] is not None

    def test_mark_failed_after_max_attempts(self, orgdb):
        self._create_tenant(orgdb)
        orgdb.insert_sync_event("sync-tenant", "u3", "user_created", {"user": {"uid": "u3"}})
        pending = orgdb.list_pending_sync_events(limit=10)
        evt_id = pending[0]["id"]
        # Simulate max attempts reached
        orgdb.mark_sync_event_retry(evt_id, error="connection refused", attempts=10, max_attempts=10)
        evt = orgdb.get_sync_event(evt_id)
        assert evt["status"] == "failed"

    def test_mark_retry_with_backoff(self, orgdb):
        self._create_tenant(orgdb)
        orgdb.insert_sync_event("sync-tenant", "u4", "user_created", {"user": {"uid": "u4"}})
        pending = orgdb.list_pending_sync_events(limit=10)
        evt_id = pending[0]["id"]
        orgdb.mark_sync_event_retry(evt_id, error="timeout", attempts=2, max_attempts=10)
        evt = orgdb.get_sync_event(evt_id)
        assert evt["status"] == "pending"
        assert evt["attempts"] == 2
        assert evt["last_error"] == "timeout"
        # next_retry_at should be in the future
        from datetime import datetime, timezone
        assert evt["next_retry_at"] > datetime.now(timezone.utc)

    def test_per_user_ordering(self, orgdb):
        """Only oldest pending event per user should be picked up."""
        self._create_tenant(orgdb)
        orgdb.insert_sync_event("sync-tenant", "ordered-user", "user_created", {"user": {"uid": "ordered-user"}})
        orgdb.insert_sync_event("sync-tenant", "ordered-user", "user_updated", {"user": {"uid": "ordered-user"}})
        pending = orgdb.list_pending_sync_events(limit=10)
        user_events = [e for e in pending if e["user_uid"] == "ordered-user"]
        # Should only return the oldest (user_created), not user_updated
        assert len(user_events) == 1
        assert user_events[0]["event_type"] == "user_created"

    def test_list_sync_events_filtered(self, orgdb):
        self._create_tenant(orgdb)
        orgdb.insert_sync_event("sync-tenant", "f1", "user_created", {"user": {"uid": "f1"}})
        orgdb.insert_sync_event("sync-tenant", "f2", "user_suspended", {"user": {"uid": "f2"}})
        all_events = orgdb.list_sync_events(tenant_id="sync-tenant")
        assert len(all_events) >= 2
        by_status = orgdb.list_sync_events(status="pending")
        assert all(e["status"] == "pending" for e in by_status)
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_ued_orgdb.py -v`
Expected: FAIL — `AttributeError: 'OrgDB' object has no attribute 'create_tenant_ldap_config'`

**Step 3: Add table definitions to orgdb.py**

Add the two new SQLAlchemy table definitions after the `api_keys` table (after line 258 in `orgdb.py`), before the `OrgDB` class:

```python
# --- UED Sync Integration ---

tenant_ldap_configs = Table(
    "tenant_ldap_configs", metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", Text, nullable=False, unique=True),
    Column("name", Text, nullable=False),
    Column("ued_api_url", Text, nullable=False),
    Column("ued_api_key_enc", Text, nullable=False),
    Column("ldap_uri", Text, nullable=False),
    Column("ldap_base_dn", Text, nullable=False),
    Column("ldap_bind_dn", Text, nullable=False),
    Column("ldap_bind_pw_enc", Text, nullable=False),
    Column("ldap_use_ssl", Boolean, nullable=False, server_default="true"),
    Column("ldap_timeout_ms", Integer, nullable=False, server_default="5000"),
    Column("schema_config", JSON, nullable=False),
    Column("enabled", Boolean, nullable=False, server_default="true"),
    Column("last_sync_at", DateTime(timezone=True), nullable=True),
    Column("last_error", Text, nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("updated_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
)

sync_events = Table(
    "sync_events", metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", Text, ForeignKey("tenant_ldap_configs.tenant_id", ondelete="CASCADE"), nullable=False),
    Column("user_uid", Text, nullable=False),
    Column("event_type", Text, nullable=False),
    Column("payload", JSON, nullable=False),
    Column("status", Text, nullable=False, server_default="pending"),
    Column("attempts", Integer, nullable=False, server_default="0"),
    Column("max_attempts", Integer, nullable=False, server_default="10"),
    Column("next_retry_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("last_error", Text, nullable=True),
    Column("request_id", String(36), nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("completed_at", DateTime(timezone=True), nullable=True),
)
```

**Step 4: Add CRUD methods to OrgDB class**

Add these methods to the `OrgDB` class (at the end, before any final closing):

```python
    # -----------------
    # UED Tenant LDAP Configs
    # -----------------
    def create_tenant_ldap_config(self, *, tenant_id: str, name: str,
                                   ued_api_url: str, ued_api_key_enc: str,
                                   ldap_uri: str, ldap_base_dn: str,
                                   ldap_bind_dn: str, ldap_bind_pw_enc: str,
                                   schema_config: dict,
                                   ldap_use_ssl: bool = True,
                                   ldap_timeout_ms: int = 5000) -> str:
        """Create a tenant LDAP config. Returns the config ID."""
        eng = self.connect()
        config_id = str(uuid4())
        now = utcnow()
        with eng.connect() as conn:
            conn.execute(tenant_ldap_configs.insert().values(
                id=config_id, tenant_id=tenant_id, name=name,
                ued_api_url=ued_api_url, ued_api_key_enc=ued_api_key_enc,
                ldap_uri=ldap_uri, ldap_base_dn=ldap_base_dn,
                ldap_bind_dn=ldap_bind_dn, ldap_bind_pw_enc=ldap_bind_pw_enc,
                ldap_use_ssl=ldap_use_ssl, ldap_timeout_ms=ldap_timeout_ms,
                schema_config=json.dumps(schema_config),
                created_at=now, updated_at=now,
            ))
            conn.commit()
        return config_id

    def get_tenant_ldap_config(self, tenant_id: str) -> dict[str, Any] | None:
        """Get tenant config by tenant_id. Returns None if not found."""
        eng = self.connect()
        with eng.connect() as conn:
            row = conn.execute(
                select(tenant_ldap_configs).where(tenant_ldap_configs.c.tenant_id == tenant_id)
            ).mappings().first()
            if not row:
                return None
            d = dict(row)
            if isinstance(d.get("schema_config"), str):
                d["schema_config"] = json.loads(d["schema_config"])
            return d

    def get_tenant_ldap_config_by_id(self, config_id: str) -> dict[str, Any] | None:
        """Get tenant config by UUID id."""
        eng = self.connect()
        with eng.connect() as conn:
            row = conn.execute(
                select(tenant_ldap_configs).where(tenant_ldap_configs.c.id == config_id)
            ).mappings().first()
            if not row:
                return None
            d = dict(row)
            if isinstance(d.get("schema_config"), str):
                d["schema_config"] = json.loads(d["schema_config"])
            return d

    def list_tenant_ldap_configs(self) -> list[dict[str, Any]]:
        """List all tenant configs."""
        eng = self.connect()
        with eng.connect() as conn:
            rows = conn.execute(
                select(tenant_ldap_configs).order_by(tenant_ldap_configs.c.created_at.desc())
            ).mappings().all()
            results = []
            for row in rows:
                d = dict(row)
                if isinstance(d.get("schema_config"), str):
                    d["schema_config"] = json.loads(d["schema_config"])
                results.append(d)
            return results

    def update_tenant_ldap_config(self, config_id: str, **kwargs: Any) -> None:
        """Update tenant config fields. Pass only the fields to update."""
        kwargs["updated_at"] = utcnow()
        if "schema_config" in kwargs and isinstance(kwargs["schema_config"], dict):
            kwargs["schema_config"] = json.dumps(kwargs["schema_config"])
        eng = self.connect()
        with eng.connect() as conn:
            conn.execute(
                update(tenant_ldap_configs)
                .where(tenant_ldap_configs.c.id == config_id)
                .values(**kwargs)
            )
            conn.commit()

    def delete_tenant_ldap_config(self, config_id: str) -> None:
        """Delete a tenant config by ID."""
        eng = self.connect()
        with eng.connect() as conn:
            conn.execute(delete(tenant_ldap_configs).where(tenant_ldap_configs.c.id == config_id))
            conn.commit()

    # -----------------
    # UED Sync Events
    # -----------------
    def insert_sync_event(self, tenant_id: str, user_uid: str,
                          event_type: str, payload: dict) -> str:
        """Insert a pending sync event. Returns the event ID."""
        eng = self.connect()
        evt_id = str(uuid4())
        req_id = str(uuid4())
        with eng.connect() as conn:
            conn.execute(sync_events.insert().values(
                id=evt_id, tenant_id=tenant_id, user_uid=user_uid,
                event_type=event_type, payload=json.dumps(payload),
                request_id=req_id,
            ))
            conn.commit()
        return evt_id

    def get_sync_event(self, event_id: str) -> dict[str, Any] | None:
        """Get a single sync event by ID."""
        eng = self.connect()
        with eng.connect() as conn:
            row = conn.execute(
                select(sync_events).where(sync_events.c.id == event_id)
            ).mappings().first()
            if not row:
                return None
            d = dict(row)
            if isinstance(d.get("payload"), str):
                d["payload"] = json.loads(d["payload"])
            return d

    def list_pending_sync_events(self, limit: int = 50) -> list[dict[str, Any]]:
        """List oldest pending event per (tenant_id, user_uid) pair.

        Enforces per-user ordering: only returns the oldest pending event
        for each user, skipping users who have an in_progress event.

        Note: Minor TOCTOU race between blocked-user check and main query is
        acceptable — worst case, a duplicate attempt is caught by the worker's
        idempotent processing and self-heals on the next poll cycle.
        """
        eng = self.connect()
        now = utcnow()
        with eng.connect() as conn:
            # Subquery: users with in_progress events (blocked)
            blocked = select(
                sync_events.c.tenant_id, sync_events.c.user_uid
            ).where(sync_events.c.status == "in_progress").subquery()

            # Main query: oldest pending per user, excluding blocked users
            # Use DISTINCT ON (PostgreSQL) to get one row per (tenant_id, user_uid)
            stmt = (
                select(sync_events)
                .where(
                    sync_events.c.status == "pending",
                    sync_events.c.next_retry_at <= now,
                )
                .order_by(
                    sync_events.c.tenant_id,
                    sync_events.c.user_uid,
                    sync_events.c.created_at.asc(),
                )
                .limit(limit)
            )

            rows = conn.execute(stmt).mappings().all()

            # Filter in Python: one per (tenant_id, user_uid), skip blocked
            blocked_rows = conn.execute(select(blocked)).mappings().all()
            blocked_set = {(r["tenant_id"], r["user_uid"]) for r in blocked_rows}

            seen: set[tuple[str, str]] = set()
            results = []
            for row in rows:
                key = (row["tenant_id"], row["user_uid"])
                if key in blocked_set or key in seen:
                    continue
                seen.add(key)
                d = dict(row)
                if isinstance(d.get("payload"), str):
                    d["payload"] = json.loads(d["payload"])
                results.append(d)
            return results

    def mark_sync_event_in_progress(self, event_id: str) -> None:
        """Mark event as in_progress (being processed by worker)."""
        eng = self.connect()
        with eng.connect() as conn:
            conn.execute(
                update(sync_events)
                .where(sync_events.c.id == event_id)
                .values(status="in_progress")
            )
            conn.commit()

    def mark_sync_event_completed(self, event_id: str) -> None:
        """Mark event as completed."""
        eng = self.connect()
        with eng.connect() as conn:
            conn.execute(
                update(sync_events)
                .where(sync_events.c.id == event_id)
                .values(status="completed", completed_at=utcnow())
            )
            conn.commit()

    def mark_sync_event_retry(self, event_id: str, *, error: str,
                               attempts: int, max_attempts: int) -> None:
        """Mark event for retry with backoff, or failed if max attempts reached."""
        if attempts >= max_attempts:
            status = "failed"
            next_retry = utcnow()
        else:
            status = "pending"
            backoff_secs = min(5 * (3 ** attempts), 3600)
            next_retry = utcnow() + timedelta(seconds=backoff_secs)

        eng = self.connect()
        with eng.connect() as conn:
            conn.execute(
                update(sync_events)
                .where(sync_events.c.id == event_id)
                .values(
                    status=status, attempts=attempts,
                    last_error=error, next_retry_at=next_retry,
                )
            )
            conn.commit()

    def list_sync_events(self, *, tenant_id: str | None = None,
                         status: str | None = None, user_uid: str | None = None,
                         limit: int = 100) -> list[dict[str, Any]]:
        """List sync events with optional filters."""
        eng = self.connect()
        stmt = select(sync_events).order_by(sync_events.c.created_at.desc()).limit(limit)
        if tenant_id:
            stmt = stmt.where(sync_events.c.tenant_id == tenant_id)
        if status:
            stmt = stmt.where(sync_events.c.status == status)
        if user_uid:
            stmt = stmt.where(sync_events.c.user_uid == user_uid)
        with eng.connect() as conn:
            rows = conn.execute(stmt).mappings().all()
            results = []
            for row in rows:
                d = dict(row)
                if isinstance(d.get("payload"), str):
                    d["payload"] = json.loads(d["payload"])
                results.append(d)
            return results

    def update_tenant_last_sync(self, tenant_id: str) -> None:
        """Update last_sync_at and clear last_error for a tenant."""
        eng = self.connect()
        with eng.connect() as conn:
            conn.execute(
                update(tenant_ldap_configs)
                .where(tenant_ldap_configs.c.tenant_id == tenant_id)
                .values(last_sync_at=utcnow(), last_error=None)
            )
            conn.commit()

    def update_tenant_last_error(self, tenant_id: str, error: str) -> None:
        """Update last_error for a tenant."""
        eng = self.connect()
        with eng.connect() as conn:
            conn.execute(
                update(tenant_ldap_configs)
                .where(tenant_ldap_configs.c.tenant_id == tenant_id)
                .values(last_error=error)
            )
            conn.commit()

    def prune_completed_sync_events(self, retention_days: int = 90) -> int:
        """Delete completed sync events older than retention_days. Returns count deleted."""
        eng = self.connect()
        cutoff = utcnow() - timedelta(days=retention_days)
        with eng.connect() as conn:
            result = conn.execute(
                delete(sync_events).where(
                    sync_events.c.status == "completed",
                    sync_events.c.completed_at < cutoff,
                )
            )
            conn.commit()
            return result.rowcount
```

**Step 5: Run tests to verify they pass**

Run: `pytest tests/test_ued_orgdb.py -v`
Expected: All 11 tests PASS

**Step 6: Run full test suite to ensure no regressions**

Run: `just test-quick`
Expected: All existing tests still PASS

**Step 7: Commit**

```bash
git add src/backend/orgdb.py tests/test_ued_orgdb.py
git commit -m "feat(db): add OrgDB CRUD for tenant_ldap_configs and sync_events"
```

---

## Task 5: UED Sync HTTP Client

**Files:**
- Create: `src/backend/ued_sync_client.py`
- Create: `tests/test_ued_sync_client.py`

**Step 1: Write failing tests**

```python
# tests/test_ued_sync_client.py
"""Tests for UED Sync HTTP client (uses httpx mock)."""

import os
import sys
from pathlib import Path

_backend_path = Path(__file__).parent.parent / "src" / "backend"
if str(_backend_path) not in sys.path:
    sys.path.insert(0, str(_backend_path))

import pytest
import httpx
from unittest.mock import AsyncMock, patch
import asyncio


def run_async(coro):
    """Helper to run async code in sync tests."""
    return asyncio.get_event_loop().run_until_complete(coro)


class TestUedSyncClient:
    def test_build_create_request(self):
        from ued_sync_client import UedSyncClient
        client = UedSyncClient()
        req = client._build_request(
            event_type="user_created",
            payload={"user": {"uid": "j.doe", "cn": "Jane"}, "password": "secret"},
            schema_config={
                "dn_template": "uid={uid},ou=people,{base_dn}",
                "object_classes": ["top", "account"],
                "attribute_map": {"uid": "{uid}"},
                "required_fields": ["uid"],
                "optional_fields": [],
                "password_attribute": "userPassword",
                "password_hash": "SSHA",
            },
            ldap_config={
                "uri": "ldap://test:389",
                "base_dn": "dc=test,dc=com",
                "bind_dn": "cn=admin,dc=test,dc=com",
                "bind_pw": "adminpw",
                "use_ssl": False,
                "timeout_ms": 5000,
            },
            request_id="req-123",
        )
        assert req["endpoint"] == "/api/v1/sync/user"
        assert req["body"]["operation"] == "create"
        assert req["body"]["request_id"] == "req-123"
        assert req["body"]["user"]["uid"] == "j.doe"

    def test_build_suspend_request(self):
        from ued_sync_client import UedSyncClient
        client = UedSyncClient()
        req = client._build_request(
            event_type="user_suspended",
            payload={"user": {"uid": "j.doe", "dn": "uid=j.doe,ou=people,dc=test,dc=com"}},
            schema_config={"attribute": "description", "suspended_value": "SUSPENDED", "active_value": ""},
            ldap_config={"uri": "ldap://test:389", "base_dn": "dc=test,dc=com",
                         "bind_dn": "cn=admin", "bind_pw": "pw", "use_ssl": False, "timeout_ms": 5000},
            request_id="req-456",
        )
        assert req["endpoint"] == "/api/v1/sync/user/suspend"
        assert req["body"]["operation"] == "suspend"

    def test_build_password_request(self):
        from ued_sync_client import UedSyncClient
        client = UedSyncClient()
        req = client._build_request(
            event_type="password_changed",
            payload={"user": {"uid": "j.doe", "dn": "uid=j.doe,dc=test"}, "new_password": "newpass"},
            schema_config={"password_attribute": "userPassword", "password_hash": "SSHA"},
            ldap_config={"uri": "ldap://test:389", "base_dn": "dc=test",
                         "bind_dn": "cn=admin", "bind_pw": "pw", "use_ssl": False, "timeout_ms": 5000},
            request_id="req-789",
        )
        assert req["endpoint"] == "/api/v1/sync/user/password"
        assert req["body"]["user"]["new_password"] == "newpass"

    def test_event_type_to_endpoint_mapping(self):
        from ued_sync_client import UedSyncClient
        client = UedSyncClient()
        mappings = {
            "user_created": ("/api/v1/sync/user", "create"),
            "user_updated": ("/api/v1/sync/user", "update"),
            "user_terminated": ("/api/v1/sync/user", "delete"),
            "user_suspended": ("/api/v1/sync/user/suspend", "suspend"),
            "user_unsuspended": ("/api/v1/sync/user/suspend", "unsuspend"),
            "password_changed": ("/api/v1/sync/user/password", None),
        }
        for event_type, (expected_endpoint, _) in mappings.items():
            req = client._build_request(
                event_type=event_type,
                payload={"user": {"uid": "test", "dn": "uid=test,dc=test"}, "new_password": "x", "password": "x"},
                schema_config={"dn_template": "uid={uid},{base_dn}", "object_classes": ["top"],
                               "attribute_map": {}, "required_fields": [], "optional_fields": [],
                               "password_attribute": "userPassword", "password_hash": "SSHA",
                               "attribute": "description", "suspended_value": "SUSPENDED", "active_value": ""},
                ldap_config={"uri": "ldap://t:389", "base_dn": "dc=t", "bind_dn": "cn=a",
                             "bind_pw": "p", "use_ssl": False, "timeout_ms": 5000},
                request_id="r",
            )
            assert req["endpoint"] == expected_endpoint, f"Failed for {event_type}"
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_ued_sync_client.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'ued_sync_client'`

**Step 3: Write implementation**

```python
# src/backend/ued_sync_client.py
"""HTTP client for UED Sync API.

- Maps AZBlink sync event types to UED API endpoints
- Builds request payloads matching UED's Pydantic models
- Async HTTP via httpx with 30s timeout
"""

import logging
from dataclasses import dataclass, field
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# Event type -> (UED endpoint, operation field value)
EVENT_ENDPOINT_MAP: dict[str, tuple[str, str | None]] = {
    "user_created":     ("/api/v1/sync/user", "create"),
    "user_updated":     ("/api/v1/sync/user", "update"),
    "user_terminated":  ("/api/v1/sync/user", "delete"),
    "user_suspended":   ("/api/v1/sync/user/suspend", "suspend"),
    "user_unsuspended": ("/api/v1/sync/user/suspend", "unsuspend"),
    "password_changed": ("/api/v1/sync/user/password", None),
}


@dataclass
class SyncResult:
    """Result from a UED sync call."""
    ok: bool
    status_code: int = 0
    request_id: str = ""
    error_code: str = ""
    error_message: str = ""
    retryable: bool = True


@dataclass
class UedSyncClient:
    """Async HTTP client for UED Sync API."""
    timeout: float = 30.0

    def _build_request(self, *, event_type: str, payload: dict,
                       schema_config: dict, ldap_config: dict,
                       request_id: str) -> dict[str, Any]:
        """Build UED request body from AZBlink sync event."""
        endpoint, operation = EVENT_ENDPOINT_MAP[event_type]

        ldap_body = {
            "uri": ldap_config["uri"],
            "base_dn": ldap_config["base_dn"],
            "bind_dn": ldap_config["bind_dn"],
            "bind_pw": ldap_config["bind_pw"],
            "use_ssl": ldap_config.get("use_ssl", True),
            "timeout_ms": ldap_config.get("timeout_ms", 5000),
        }

        if event_type in ("user_created", "user_updated", "user_terminated"):
            body: dict[str, Any] = {
                "operation": operation,
                "request_id": request_id,
                "ldap": ldap_body,
                "schema": schema_config,
                "user": payload["user"],
            }
            if payload.get("password"):
                body["password"] = payload["password"]

        elif event_type in ("user_suspended", "user_unsuspended"):
            body = {
                "operation": operation,
                "request_id": request_id,
                "ldap": ldap_body,
                "schema": schema_config,
                "user": payload["user"],
            }

        elif event_type == "password_changed":
            body = {
                "request_id": request_id,
                "ldap": ldap_body,
                "schema": schema_config,
                "user": {
                    "dn": payload["user"].get("dn", ""),
                    "new_password": payload.get("new_password", ""),
                },
            }

        else:
            raise ValueError(f"Unknown event type: {event_type}")

        return {"endpoint": endpoint, "body": body}

    async def send(self, *, ued_api_url: str, ued_api_key: str,
                   event_type: str, payload: dict,
                   schema_config: dict, ldap_config: dict,
                   request_id: str) -> SyncResult:
        """Send a sync request to UED Sync API. Returns SyncResult."""
        try:
            req = self._build_request(
                event_type=event_type, payload=payload,
                schema_config=schema_config, ldap_config=ldap_config,
                request_id=request_id,
            )
        except (KeyError, ValueError) as e:
            return SyncResult(ok=False, error_code="BUILD_ERROR",
                              error_message=str(e), retryable=False)

        url = f"{ued_api_url.rstrip('/')}{req['endpoint']}"
        headers = {"X-API-Key": ued_api_key, "Content-Type": "application/json"}

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(url, json=req["body"], headers=headers)

            if resp.status_code == 200:
                data = resp.json()
                return SyncResult(
                    ok=data.get("ok", False),
                    status_code=resp.status_code,
                    request_id=data.get("request_id", request_id),
                    error_code=data.get("error", {}).get("code", "") if not data.get("ok") else "",
                    error_message=data.get("error", {}).get("message", "") if not data.get("ok") else "",
                    retryable=data.get("error", {}).get("retryable", False) if not data.get("ok") else False,
                )
            else:
                return SyncResult(
                    ok=False, status_code=resp.status_code,
                    request_id=request_id,
                    error_code=f"HTTP_{resp.status_code}",
                    error_message=resp.text[:500],
                    retryable=resp.status_code >= 500 or resp.status_code == 429,
                )

        except httpx.TimeoutException:
            return SyncResult(ok=False, error_code="TIMEOUT",
                              error_message="Request timed out", retryable=True)
        except httpx.ConnectError as e:
            return SyncResult(ok=False, error_code="CONNECTION_ERROR",
                              error_message=str(e)[:500], retryable=True)
        except Exception as e:
            logger.exception("Unexpected error calling UED Sync API")
            return SyncResult(ok=False, error_code="UNEXPECTED",
                              error_message=str(e)[:500], retryable=True)
```

**Step 4: Run tests to verify they pass**

Run: `pytest tests/test_ued_sync_client.py -v`
Expected: All 4 tests PASS

**Step 5: Commit**

```bash
git add src/backend/ued_sync_client.py tests/test_ued_sync_client.py
git commit -m "feat: add UED Sync HTTP client with event-to-endpoint mapping"
```

---

## Task 6: Sync Worker

**Files:**
- Create: `src/backend/sync_worker.py`
- Create: `tests/test_sync_worker.py`

**Step 1: Write failing tests**

```python
# tests/test_sync_worker.py
"""Tests for background SyncWorker."""

import os
import sys
from pathlib import Path

_backend_path = Path(__file__).parent.parent / "src" / "backend"
if str(_backend_path) not in sys.path:
    sys.path.insert(0, str(_backend_path))

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone


class TestBackoffCalculation:
    def test_attempt_0(self):
        from sync_worker import compute_backoff_secs
        assert compute_backoff_secs(0) == 5

    def test_attempt_1(self):
        from sync_worker import compute_backoff_secs
        assert compute_backoff_secs(1) == 15

    def test_attempt_2(self):
        from sync_worker import compute_backoff_secs
        assert compute_backoff_secs(2) == 45

    def test_capped_at_3600(self):
        from sync_worker import compute_backoff_secs
        assert compute_backoff_secs(10) == 3600
        assert compute_backoff_secs(20) == 3600


class TestSyncWorkerProcessEvent:
    """Test the _process_event method with mocked dependencies."""

    @pytest.fixture
    def mock_orgdb(self):
        db = MagicMock()
        db.get_tenant_ldap_config.return_value = {
            "id": "cfg-1",
            "tenant_id": "t1",
            "ued_api_url": "https://ued:8000",
            "ued_api_key_enc": "encrypted-key",
            "ldap_uri": "ldap://uc:389",
            "ldap_base_dn": "dc=uc,dc=com",
            "ldap_bind_dn": "cn=admin,dc=uc,dc=com",
            "ldap_bind_pw_enc": "encrypted-pw",
            "ldap_use_ssl": False,
            "ldap_timeout_ms": 5000,
            "schema_config": {
                "dn_template": "uid={uid},ou=people,{base_dn}",
                "object_classes": ["top"],
                "attribute_map": {"uid": "{uid}"},
                "required_fields": ["uid"],
                "optional_fields": [],
                "password_attribute": "userPassword",
                "password_hash": "SSHA",
            },
            "enabled": True,
        }
        return db

    @pytest.fixture
    def sample_event(self):
        return {
            "id": "evt-1",
            "tenant_id": "t1",
            "user_uid": "j.doe",
            "event_type": "user_created",
            "payload": {"user": {"uid": "j.doe", "cn": "Jane Doe"}},
            "status": "pending",
            "attempts": 0,
            "max_attempts": 10,
            "request_id": "req-1",
        }

    def test_successful_sync(self, mock_orgdb, sample_event):
        from sync_worker import SyncWorker
        from ued_sync_client import SyncResult

        mock_client = AsyncMock()
        mock_client.send.return_value = SyncResult(ok=True, status_code=200, request_id="req-1")

        worker = SyncWorker(orgdb=mock_orgdb, ued_client=mock_client, poll_interval=1.0)

        with patch("sync_worker.decrypt_value", side_effect=lambda x: f"decrypted-{x}"):
            asyncio.get_event_loop().run_until_complete(
                worker._process_event(sample_event)
            )

        mock_orgdb.mark_sync_event_completed.assert_called_once_with("evt-1")
        mock_orgdb.update_tenant_last_sync.assert_called_once_with("t1")

    def test_failed_sync_retries(self, mock_orgdb, sample_event):
        from sync_worker import SyncWorker
        from ued_sync_client import SyncResult

        mock_client = AsyncMock()
        mock_client.send.return_value = SyncResult(
            ok=False, error_code="CONNECTION_ERROR",
            error_message="refused", retryable=True,
        )

        worker = SyncWorker(orgdb=mock_orgdb, ued_client=mock_client, poll_interval=1.0)

        with patch("sync_worker.decrypt_value", side_effect=lambda x: f"decrypted-{x}"):
            asyncio.get_event_loop().run_until_complete(
                worker._process_event(sample_event)
            )

        mock_orgdb.mark_sync_event_retry.assert_called_once()
        call_kwargs = mock_orgdb.mark_sync_event_retry.call_args
        assert call_kwargs[0][0] == "evt-1"  # event_id
        assert call_kwargs[1]["attempts"] == 1
        assert "refused" in call_kwargs[1]["error"]

    def test_disabled_tenant_skipped(self, mock_orgdb, sample_event):
        from sync_worker import SyncWorker
        from ued_sync_client import SyncResult

        mock_orgdb.get_tenant_ldap_config.return_value["enabled"] = False
        mock_client = AsyncMock()

        worker = SyncWorker(orgdb=mock_orgdb, ued_client=mock_client, poll_interval=1.0)

        with patch("sync_worker.decrypt_value", side_effect=lambda x: x):
            asyncio.get_event_loop().run_until_complete(
                worker._process_event(sample_event)
            )

        # Should mark failed (non-retryable) since tenant is disabled
        mock_orgdb.mark_sync_event_retry.assert_called_once()
        mock_client.send.assert_not_called()
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_sync_worker.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'sync_worker'`

**Step 3: Write implementation**

```python
# src/backend/sync_worker.py
"""Background async worker for processing UED sync events.

- Polls sync_events table for pending events
- Enforces per-user ordering (one event at a time per user)
- Exponential backoff on failure: min(5 * 3^attempt, 3600) seconds
- Retention pruning: deletes completed events older than configurable days
"""

import asyncio
import logging
from dataclasses import dataclass, field

from ued_crypto import decrypt_value
from ued_sync_client import UedSyncClient

logger = logging.getLogger(__name__)


def compute_backoff_secs(attempt: int) -> int:
    """Compute backoff seconds: min(5 * 3^attempt, 3600)."""
    return min(5 * (3 ** attempt), 3600)


@dataclass
class SyncWorker:
    """Async background worker that processes UED sync events."""
    orgdb: object  # OrgDB instance
    ued_client: UedSyncClient = field(default_factory=UedSyncClient)
    poll_interval: float = 5.0
    retention_days: int = 90
    _running: bool = field(default=False, init=False)

    async def run(self) -> None:
        """Main loop: poll for events, process, sleep."""
        self._running = True
        logger.info("SyncWorker started (poll_interval=%.1fs)", self.poll_interval)
        prune_counter = 0
        while self._running:
            try:
                events = self.orgdb.list_pending_sync_events(limit=50)
                for event in events:
                    if not self._running:
                        break
                    self.orgdb.mark_sync_event_in_progress(event["id"])
                    try:
                        await self._process_event(event)
                    except Exception:
                        logger.exception("Unhandled error processing event %s", event["id"])
                        self.orgdb.mark_sync_event_retry(
                            event["id"],
                            error="unhandled exception",
                            attempts=event["attempts"] + 1,
                            max_attempts=event["max_attempts"],
                        )

                # Prune completed events hourly (every ~720 poll cycles at 5s)
                prune_counter += 1
                if prune_counter >= 720:
                    prune_counter = 0
                    try:
                        pruned = self.orgdb.prune_completed_sync_events(self.retention_days)
                        if pruned > 0:
                            logger.info("Pruned %d completed sync events", pruned)
                    except Exception:
                        logger.exception("Error pruning sync events")

            except Exception:
                logger.exception("Error in SyncWorker poll loop")

            await asyncio.sleep(self.poll_interval)

    def stop(self) -> None:
        """Signal the worker to stop."""
        self._running = False
        logger.info("SyncWorker stopping")

    async def _process_event(self, event: dict) -> None:
        """Process a single sync event: fetch config, call UED, update status."""
        tenant_id = event["tenant_id"]
        event_id = event["id"]

        config = self.orgdb.get_tenant_ldap_config(tenant_id)
        if not config or not config.get("enabled"):
            logger.warning("Tenant %s disabled or missing, marking event %s failed", tenant_id, event_id)
            self.orgdb.mark_sync_event_retry(
                event_id, error=f"Tenant {tenant_id} disabled or not found",
                attempts=event["max_attempts"], max_attempts=event["max_attempts"],
            )
            return

        # Decrypt secrets
        try:
            api_key = decrypt_value(config["ued_api_key_enc"])
            bind_pw = decrypt_value(config["ldap_bind_pw_enc"])
        except Exception as e:
            logger.error("Failed to decrypt secrets for tenant %s: %s", tenant_id, e)
            self.orgdb.mark_sync_event_retry(
                event_id, error=f"Decryption failed: {e}",
                attempts=event["max_attempts"], max_attempts=event["max_attempts"],
            )
            return

        # Decrypt payload password if present
        payload = event["payload"]
        from ued_crypto import decrypt_payload_password
        payload = decrypt_payload_password(payload)

        ldap_config = {
            "uri": config["ldap_uri"],
            "base_dn": config["ldap_base_dn"],
            "bind_dn": config["ldap_bind_dn"],
            "bind_pw": bind_pw,
            "use_ssl": config["ldap_use_ssl"],
            "timeout_ms": config["ldap_timeout_ms"],
        }

        result = await self.ued_client.send(
            ued_api_url=config["ued_api_url"],
            ued_api_key=api_key,
            event_type=event["event_type"],
            payload=payload,
            schema_config=config["schema_config"],
            ldap_config=ldap_config,
            request_id=event["request_id"],
        )

        if result.ok:
            logger.info("Sync event %s completed (user=%s, type=%s)",
                        event_id, event["user_uid"], event["event_type"])
            self.orgdb.mark_sync_event_completed(event_id)
            self.orgdb.update_tenant_last_sync(tenant_id)
        else:
            error_msg = f"{result.error_code}: {result.error_message}"
            logger.warning("Sync event %s failed (attempt %d): %s",
                           event_id, event["attempts"] + 1, error_msg)
            self.orgdb.mark_sync_event_retry(
                event_id, error=error_msg,
                attempts=event["attempts"] + 1,
                max_attempts=event["max_attempts"],
            )
            self.orgdb.update_tenant_last_error(tenant_id, error_msg)
```

**Step 4: Run tests to verify they pass**

Run: `pytest tests/test_sync_worker.py -v`
Expected: All 6 tests PASS

**Step 5: Commit**

```bash
git add src/backend/sync_worker.py tests/test_sync_worker.py
git commit -m "feat: add async SyncWorker with backoff and per-user ordering"
```

---

## Task 7: Wire Into main.py — Event Emission + Lifespan + Admin Endpoints

**Files:**
- Modify: `src/backend/main.py`
- Create: `tests/test_ued_api.py`

This is the largest task. It has three sub-parts: event emission helper, worker lifespan, and admin endpoints.

### Sub-task 7a: Event Emission Helper + Lifespan

**Step 1: Write failing integration test for event emission**

```python
# tests/test_ued_api.py
"""Integration tests for UED sync API endpoints and event emission."""

import os
import sys
from pathlib import Path

_backend_path = Path(__file__).parent.parent / "src" / "backend"
if str(_backend_path) not in sys.path:
    sys.path.insert(0, str(_backend_path))

import pytest
import httpx
import psycopg2


@pytest.fixture(scope="session")
def api_base_url():
    return os.getenv("API_URL", "http://localhost:8081")


@pytest.fixture
def client(api_base_url):
    with httpx.Client(base_url=api_base_url, timeout=30) as c:
        yield c


@pytest.fixture
def auth_headers(client):
    resp = client.post("/api/auth/login", json={
        "username": "mei", "password": "password123", "remember": False,
    })
    token = resp.json().get("token", "")
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="session")
def db_conn():
    conn = psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "localhost"),
        port=int(os.getenv("POSTGRES_PORT", "5433")),
        database="azblink_directory",
        user="azblink_directory",
        password="azblink_directory",
    )
    conn.autocommit = True
    yield conn
    conn.close()


@pytest.fixture(autouse=True)
def cleanup_ued(db_conn):
    """Clean UED tables before and after each test."""
    with db_conn.cursor() as cur:
        cur.execute("DELETE FROM sync_events")
        cur.execute("DELETE FROM tenant_ldap_configs")
    yield
    with db_conn.cursor() as cur:
        cur.execute("DELETE FROM sync_events")
        cur.execute("DELETE FROM tenant_ldap_configs")


@pytest.fixture(autouse=True)
def clear_rate_limits():
    """Clear rate limits."""
    import redis as redis_lib
    host = os.getenv("REDIS_HOST", "localhost")
    port = int(os.getenv("REDIS_PORT", "6380"))
    r = redis_lib.Redis(host=host, port=port, db=0)
    yield
    r.flushdb()
    r.close()


# --- Tenant Config Admin API Tests ---

class TestTenantConfigAPI:
    def test_list_empty(self, client, auth_headers):
        resp = client.get("/api/ued/configs", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.json() == []

    def test_create_and_list(self, client, auth_headers):
        resp = client.post("/api/ued/configs", headers=auth_headers, json={
            "tenant_id": "api-test",
            "name": "API Test Tenant",
            "ued_api_url": "https://ued-test:8000",
            "ued_api_key": "test-api-key-64chars-" + "a" * 44,
            "ldap_uri": "ldap://test:389",
            "ldap_base_dn": "dc=test,dc=com",
            "ldap_bind_dn": "cn=admin,dc=test,dc=com",
            "ldap_bind_pw": "testpassword",
            "schema_config": {
                "dn_template": "uid={uid},ou=people,{base_dn}",
                "object_classes": ["top", "account"],
                "attribute_map": {"uid": "{uid}"},
                "required_fields": ["uid"],
                "optional_fields": [],
                "password_attribute": "userPassword",
                "password_hash": "SSHA",
            },
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["ok"] is True
        assert "id" in data

        # List should contain it
        resp2 = client.get("/api/ued/configs", headers=auth_headers)
        configs = resp2.json()
        assert len(configs) >= 1
        # Secrets should be redacted
        cfg = configs[0]
        assert cfg["ued_api_key_enc"] == "••••••••"
        assert cfg["ldap_bind_pw_enc"] == "••••••••"

    def test_delete_config(self, client, auth_headers):
        resp = client.post("/api/ued/configs", headers=auth_headers, json={
            "tenant_id": "del-test",
            "name": "Delete Test",
            "ued_api_url": "https://ued:8000",
            "ued_api_key": "key" + "a" * 61,
            "ldap_uri": "ldap://t:389",
            "ldap_base_dn": "dc=t",
            "ldap_bind_dn": "cn=a",
            "ldap_bind_pw": "pw",
            "schema_config": {"dn_template": "uid={uid},{base_dn}", "object_classes": ["top"],
                              "attribute_map": {}, "required_fields": [], "optional_fields": [],
                              "password_attribute": "userPassword", "password_hash": "SSHA"},
        })
        config_id = resp.json()["id"]
        resp2 = client.delete(f"/api/ued/configs/{config_id}", headers=auth_headers)
        assert resp2.status_code == 200

    def test_requires_auth(self, client):
        resp = client.get("/api/ued/configs")
        assert resp.status_code in (401, 403)


class TestSyncEventsAPI:
    def test_list_empty(self, client, auth_headers):
        resp = client.get("/api/ued/sync-events", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.json() == []

    def test_retry_nonexistent(self, client, auth_headers):
        resp = client.post("/api/ued/sync-events/nonexistent/retry", headers=auth_headers)
        assert resp.status_code == 404
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_ued_api.py -v`
Expected: FAIL — 404 on `/api/ued/configs`

**Step 3: Add imports, emission helper, lifespan, and admin endpoints to main.py**

Add near top imports (after existing imports around line 56):

```python
from ued_crypto import encrypt_value, encrypt_payload_password
```

Add the lifespan handler **before** the `app = FastAPI(...)` line (before line 71). The existing line 71 must be modified to include the lifespan parameter:

```python
from contextlib import asynccontextmanager
import asyncio

@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    """Start/stop the UED sync background worker."""
    from sync_worker import SyncWorker
    from ued_sync_client import UedSyncClient
    worker = SyncWorker(orgdb=ORGDB, ued_client=UedSyncClient(), poll_interval=5.0)
    task = asyncio.create_task(worker.run())
    yield
    worker.stop()
    await task

# Modify existing FastAPI() call to include lifespan:
app = FastAPI(title="Azblink Directory Backend (OpenLDAP + Org Profile DB)", lifespan=lifespan)
```

Add the `emit_sync_event` helper function (after the QR helper functions, around line 120):

```python
# ----------------------------
# UED Sync Event Emission
# ----------------------------
def emit_sync_event(tenant_id: str, user_uid: str, event_type: str, payload: dict) -> None:
    """Emit a sync event if UED integration is configured for this tenant.

    Called after successful LDAP writes. No-op if no tenant config exists.
    Encrypts password fields before storage. Swallows errors to never block
    the primary API response.
    """
    try:
        config = ORGDB.get_tenant_ldap_config(tenant_id)
        if not config or not config.get("enabled"):
            return
        # Encrypt password fields in payload before DB storage
        if event_type in ("user_created", "password_changed"):
            payload = encrypt_payload_password(payload)
        ORGDB.insert_sync_event(tenant_id, user_uid, event_type, payload)
    except Exception:
        logger.warning("Failed to emit sync event for %s/%s", tenant_id, user_uid, exc_info=True)
```

Add `emit_sync_event` calls to the 6 route handlers. For each route, add the call after the successful operation and before the return statement:

**In `api_user_create` (around line 1255, after lifecycle event recording):**
```python
    emit_sync_event(LDAP_TENANT, req.uid, "user_created", {
        "user": {"uid": req.uid, "cn": req.displayName, "mail": req.mail or ""},
        "password": req.password,
    })
```

**In `api_user_update` (around line 1222, after `res = update_user(...)`):**
```python
    emit_sync_event(LDAP_TENANT, uid, "user_updated", {
        "user": {"uid": uid, "dn": user.get("dn", "")},
        "changes": updates,
    })
```

**In `api_user_suspend` (around line 1389, after lifecycle event recording):**
```python
    emit_sync_event(LDAP_TENANT, uid, "user_suspended", {
        "user": {"uid": uid, "dn": user.get("dn", "")},
    })
```

**In `api_user_unsuspend` (around line 1407, after lifecycle event recording):**
```python
    emit_sync_event(LDAP_TENANT, uid, "user_unsuspended", {
        "user": {"uid": uid, "dn": user.get("dn", "")},
    })
```

**In `api_user_terminate` (around line 1356, after termination recording):**
```python
    emit_sync_event(LDAP_TENANT, uid, "user_terminated", {
        "user": {"uid": uid, "dn": user_dn or ""},
    })
```

**In `api_user_reset_password` (around line 1272, after lifecycle event recording):**
```python
    emit_sync_event(LDAP_TENANT, uid, "password_changed", {
        "user": {"uid": uid, "dn": user.get("dn", "")},
        "new_password": req.newPassword,
    })
```
Note: `emit_sync_event` handles password encryption internally — no need to call `encrypt_payload_password` at call sites.

### Sub-task 7b: UED Admin Endpoints

Add at the end of main.py (before the settings import on line 2843):

```python
# ----------------------------
# UED Sync Admin API
# ----------------------------
from pydantic import BaseModel as _PydanticBase

class TenantConfigCreateReq(_PydanticBase):
    tenant_id: str
    name: str
    ued_api_url: str
    ued_api_key: str  # plaintext — encrypted before storage
    ldap_uri: str
    ldap_base_dn: str
    ldap_bind_dn: str
    ldap_bind_pw: str  # plaintext — encrypted before storage
    schema_config: dict
    ldap_use_ssl: bool = True
    ldap_timeout_ms: int = 5000

class TenantConfigUpdateReq(_PydanticBase):
    name: Optional[str] = None
    ued_api_url: Optional[str] = None
    ued_api_key: Optional[str] = None
    ldap_uri: Optional[str] = None
    ldap_base_dn: Optional[str] = None
    ldap_bind_dn: Optional[str] = None
    ldap_bind_pw: Optional[str] = None
    schema_config: Optional[dict] = None
    ldap_use_ssl: Optional[bool] = None
    ldap_timeout_ms: Optional[int] = None
    enabled: Optional[bool] = None


@app.get("/api/ued/configs")
def api_ued_configs_list(claims: Dict[str, Any] = Depends(require_admin)):
    """List all tenant UED configs (secrets redacted)."""
    configs = ORGDB.list_tenant_ldap_configs()
    for c in configs:
        c["ued_api_key_enc"] = "••••••••"
        c["ldap_bind_pw_enc"] = "••••••••"
    return configs


@app.post("/api/ued/configs", status_code=201)
def api_ued_config_create(req: TenantConfigCreateReq, claims: Dict[str, Any] = Depends(require_admin)):
    """Create a new tenant UED config."""
    config_id = ORGDB.create_tenant_ldap_config(
        tenant_id=req.tenant_id, name=req.name,
        ued_api_url=req.ued_api_url,
        ued_api_key_enc=encrypt_value(req.ued_api_key),
        ldap_uri=req.ldap_uri, ldap_base_dn=req.ldap_base_dn,
        ldap_bind_dn=req.ldap_bind_dn,
        ldap_bind_pw_enc=encrypt_value(req.ldap_bind_pw),
        schema_config=req.schema_config,
        ldap_use_ssl=req.ldap_use_ssl,
        ldap_timeout_ms=req.ldap_timeout_ms,
    )
    return {"ok": True, "id": config_id}


@app.patch("/api/ued/configs/{config_id}")
def api_ued_config_update(config_id: str, req: TenantConfigUpdateReq, claims: Dict[str, Any] = Depends(require_admin)):
    """Update a tenant UED config."""
    existing = ORGDB.get_tenant_ldap_config_by_id(config_id)
    if not existing:
        raise HTTPException(404, "Config not found")
    updates = {k: v for k, v in req.model_dump().items() if v is not None}
    if "ued_api_key" in updates:
        updates["ued_api_key_enc"] = encrypt_value(updates.pop("ued_api_key"))
    if "ldap_bind_pw" in updates:
        updates["ldap_bind_pw_enc"] = encrypt_value(updates.pop("ldap_bind_pw"))
    if updates:
        ORGDB.update_tenant_ldap_config(config_id, **updates)
    return {"ok": True}


@app.delete("/api/ued/configs/{config_id}")
def api_ued_config_delete(config_id: str, claims: Dict[str, Any] = Depends(require_admin)):
    """Delete a tenant UED config."""
    existing = ORGDB.get_tenant_ldap_config_by_id(config_id)
    if not existing:
        raise HTTPException(404, "Config not found")
    ORGDB.delete_tenant_ldap_config(config_id)
    return {"ok": True}


@app.post("/api/ued/configs/{config_id}/test")
def api_ued_config_test(config_id: str, claims: Dict[str, Any] = Depends(require_admin)):
    """Test UED connectivity + LDAP bind for a tenant config."""
    config = ORGDB.get_tenant_ldap_config_by_id(config_id)
    if not config:
        raise HTTPException(404, "Config not found")

    from ued_crypto import decrypt_value as _decrypt
    import httpx as _httpx

    result = {"ued_reachable": False, "ldap_bind_ok": False, "errors": []}

    try:
        api_key = _decrypt(config["ued_api_key_enc"])
        ued_url = config["ued_api_url"].rstrip("/")
        resp = _httpx.get(f"{ued_url}/health", headers={"X-API-Key": api_key}, timeout=10)
        result["ued_reachable"] = resp.status_code == 200
        if resp.status_code != 200:
            result["errors"].append(f"UED health returned {resp.status_code}")
    except Exception as e:
        result["errors"].append(f"UED unreachable: {e}")

    return result


@app.get("/api/ued/sync-events")
def api_ued_sync_events_list(
    status: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,
    limit: int = 100,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """List sync events with optional filters."""
    return ORGDB.list_sync_events(tenant_id=tenant_id, status=status, user_uid=user_uid, limit=limit)


@app.post("/api/ued/sync-events/{event_id}/retry")
def api_ued_sync_event_retry(event_id: str, claims: Dict[str, Any] = Depends(require_admin)):
    """Retry a failed sync event."""
    event = ORGDB.get_sync_event(event_id)
    if not event:
        raise HTTPException(404, "Sync event not found")
    if event["status"] != "failed":
        raise HTTPException(400, "Only failed events can be retried")
    from datetime import datetime, timezone
    ORGDB.mark_sync_event_retry(event_id, error="manual retry", attempts=0, max_attempts=event["max_attempts"])
    return {"ok": True, "event_id": event_id}


@app.post("/api/ued/sync-events/retry-all-failed")
def api_ued_sync_events_retry_all(
    tenant_id: Optional[str] = None,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Retry all failed sync events (optionally for a specific tenant)."""
    failed = ORGDB.list_sync_events(status="failed", tenant_id=tenant_id, limit=1000)
    count = 0
    for evt in failed:
        ORGDB.mark_sync_event_retry(evt["id"], error="bulk retry", attempts=0, max_attempts=evt["max_attempts"])
        count += 1
    return {"ok": True, "retried": count}
```

**Step 4: Run tests to verify they pass**

Run: `pytest tests/test_ued_api.py -v`
Expected: All 6 tests PASS

**Step 5: Run full suite for regression check**

Run: `just test-quick`
Expected: All tests PASS

**Step 6: Commit**

```bash
git add src/backend/main.py tests/test_ued_api.py
git commit -m "feat: wire UED sync emission into user lifecycle routes + admin API"
```

---

## Task 8: End-to-End Smoke Test

**Files:**
- Modify: `tests/test_ued_api.py` (add E2E test)

**Step 1: Add end-to-end test**

Append to `tests/test_ued_api.py`:

```python
class TestSyncEventEmission:
    """Verify that user lifecycle actions emit sync events when tenant config exists."""

    def _setup_tenant(self, client, auth_headers, db_conn):
        """Create a tenant config with a known encryption key."""
        # The API encrypts on save, so we just post plaintext
        resp = client.post("/api/ued/configs", headers=auth_headers, json={
            "tenant_id": "azblink",  # matches LDAP_TENANT in dev env
            "name": "E2E Test Tenant",
            "ued_api_url": "https://ued-e2e:8000",
            "ued_api_key": "e2e-test-key-" + "x" * 51,
            "ldap_uri": "ldap://uc:389",
            "ldap_base_dn": "dc=uc,dc=com",
            "ldap_bind_dn": "cn=admin,dc=uc,dc=com",
            "ldap_bind_pw": "ucpassword",
            "schema_config": {
                "dn_template": "uid={uid},ou=people,{base_dn}",
                "object_classes": ["top", "account"],
                "attribute_map": {"uid": "{uid}"},
                "required_fields": ["uid"],
                "optional_fields": [],
                "password_attribute": "userPassword",
                "password_hash": "SSHA",
            },
        })
        assert resp.status_code == 201, f"Failed to create tenant config: {resp.text}"

    def _count_sync_events(self, db_conn, user_uid, event_type=None):
        with db_conn.cursor() as cur:
            if event_type:
                cur.execute(
                    "SELECT COUNT(*) FROM sync_events WHERE user_uid = %s AND event_type = %s",
                    (user_uid, event_type),
                )
            else:
                cur.execute("SELECT COUNT(*) FROM sync_events WHERE user_uid = %s", (user_uid,))
            return cur.fetchone()[0]

    def _cleanup_ldap_user(self, uid):
        """Remove test user from LDAP."""
        from ldap3 import Server, Connection, ALL
        host = os.getenv("LDAP_HOST", "localhost")
        port = int(os.getenv("LDAP_PORT", "1390"))
        server = Server(f"ldap://{host}:{port}", get_info=ALL)
        conn = Connection(server, user="cn=admin,dc=azblink,dc=com", password="adminpassword", auto_bind=True)
        conn.delete(f"uid={uid},ou=people,ou=org,dc=azblink,dc=com")
        conn.unbind()

    def test_user_create_emits_event(self, client, auth_headers, db_conn):
        self._setup_tenant(client, auth_headers, db_conn)
        uid = "ued-e2e-create"
        try:
            resp = client.post("/api/users/create", headers=auth_headers, json={
                "uid": uid,
                "displayName": "UED E2E User",
                "mail": f"{uid}@test.com",
                "mobile": "1234567890",
                "password": "testpass123",
                "orgDn": "ou=org,dc=azblink,dc=com",
            })
            assert resp.status_code == 201
            # Verify event was emitted (check DB directly — worker may not have
            # picked it up yet, which is fine; we're testing emission, not delivery)
            assert self._count_sync_events(db_conn, uid, "user_created") == 1
        finally:
            self._cleanup_ldap_user(uid)

    def test_no_event_without_tenant_config(self, client, auth_headers, db_conn):
        """Without a tenant config, no sync events should be emitted."""
        # Don't call _setup_tenant — no config exists
        uid = "ued-e2e-noconfig"
        try:
            resp = client.post("/api/users/create", headers=auth_headers, json={
                "uid": uid,
                "displayName": "No Config User",
                "mail": f"{uid}@test.com",
                "mobile": "1234567890",
                "password": "testpass123",
                "orgDn": "ou=org,dc=azblink,dc=com",
            })
            assert resp.status_code == 201
            assert self._count_sync_events(db_conn, uid) == 0
        finally:
            self._cleanup_ldap_user(uid)
```

**Step 2: Run E2E test**

Run: `pytest tests/test_ued_api.py::TestSyncEventEmission -v`
Expected: All 2 tests PASS

**Step 3: Run full test suite**

Run: `just test-quick`
Expected: All tests PASS

**Step 4: Commit**

```bash
git add tests/test_ued_api.py
git commit -m "test: add E2E smoke tests for UED sync event emission"
```

---

## Task 9: Documentation + Env Example Update

**Files:**
- Modify: `deploy/dev/.env.example` (already done in Task 3)
- Modify: `CLAUDE.md` (add UED section)

**Step 1: Add UED section to CLAUDE.md**

Add to the Technical Debt & Deferred Work section:

```markdown
### UED Sync Integration

| Endpoint | Purpose |
|----------|---------|
| `GET /api/ued/configs` | List tenant UED configs (secrets redacted) |
| `POST /api/ued/configs` | Create tenant config |
| `PATCH /api/ued/configs/{id}` | Update tenant config |
| `DELETE /api/ued/configs/{id}` | Remove tenant config |
| `POST /api/ued/configs/{id}/test` | Test UED + LDAP connectivity |
| `GET /api/ued/sync-events` | List sync events (filterable) |
| `POST /api/ued/sync-events/{id}/retry` | Retry failed event |
| `POST /api/ued/sync-events/retry-all-failed` | Retry all failed events |

**Key files:** `ued_crypto.py`, `ued_sync_client.py`, `sync_worker.py`
**Design doc:** `docs/plans/2026-02-13-ued-sync-integration-design.md`
```

**Step 2: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: add UED sync integration section to CLAUDE.md"
```

---

## Summary

| Task | What | New Files | Tests |
|------|------|-----------|-------|
| 1 | DB migration | `migrations/010_ued_sync.sql` | Manual SQL verification |
| 2 | Encryption module | `src/backend/ued_crypto.py` | 8 unit tests |
| 3 | Config + deps | Modified 3 files | Health check |
| 4 | OrgDB CRUD | Modified `orgdb.py` | 11 integration tests |
| 5 | UED HTTP client | `src/backend/ued_sync_client.py` | 4 unit tests |
| 6 | Sync worker | `src/backend/sync_worker.py` | 6 unit tests |
| 7 | Wire into main.py | Modified `main.py` | 6 API tests |
| 8 | E2E smoke test | Modified test file | 2 E2E tests |
| 9 | Documentation | Modified `CLAUDE.md` | — |

**Total: 9 tasks, 37 tests, 5 new files, 5 modified files**
