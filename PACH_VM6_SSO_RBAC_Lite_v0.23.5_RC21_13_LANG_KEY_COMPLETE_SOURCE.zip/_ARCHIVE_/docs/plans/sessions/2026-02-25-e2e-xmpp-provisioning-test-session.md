---
feature: e2e-xmpp-provisioning-test
date: 2026-02-25
branch: e2e-xmpp-provisioning-test
mode: level-3
team: []
status: in-progress
confidence: 0%
---

# Session Ledger: E2E XMPP Provisioning Test

End-to-end test simulating 2 real XMPP apps provisioned by the AD platform with XMPP+SIP profiles,
authenticated via QR code content, chatting between them, with AD platform audit trail tracking.
