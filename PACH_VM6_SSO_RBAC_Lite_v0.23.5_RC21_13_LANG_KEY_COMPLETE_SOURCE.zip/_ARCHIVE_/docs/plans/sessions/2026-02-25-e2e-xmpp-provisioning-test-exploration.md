# Exploration Report: E2E XMPP Provisioning Test

**Date:** 2026-02-25
**Feature:** End-to-end XMPP provisioning test with real XMPP server

---

## Codebase Architecture

### Key Components

1. **AD Directory Backend** (`src/backend/`)
   - `main.py` — FastAPI with user CRUD, QR generation, provision/consume endpoints
   - `provisioning.py` — Profile-linked enrichment (UID allocation, SIP password)
   - `qr_signing.py` — HMAC-SHA256 signing with `azblink.provisioning.v2` schema
   - `sync_worker.py` — Background worker polls sync_events, calls UED Sync API
   - `ued_sync_client.py` — HTTP client for UED Sync
   - `orgdb.py` — PostgreSQL: provision_tokens, qr_issuance_audit, sync_events

2. **UED Sync API** (`src/ued-sync/`)
   - `schemas/xmpp.py` — posixAccount with SSHA userPassword, no SIP attrs
   - `routers/discovery.py` — Capabilities endpoint with service_endpoints
   - `routers/sync.py` — User CRUD to LDAP

3. **Real Server** (192.168.122.89)
   - LDAP: port 389, base DN `dc=xmpp-sip-platform,dc=local`
   - XMPP: port 5222, domain `private.z`
   - SIP: port 5060 (but SIP LDAP auth not configured on AzPBX)
   - XMPP LDAP bind auth: **CONFIRMED WORKING** (6 users tested)

### Data Flow for E2E Test

```
1. Create profile with UED pointing to 192.168.122.89
2. POST /api/users/create {uid, password, profileId}
   → LDAP-A: inetOrgPerson in dev LDAP
   → emit_sync_event → SyncWorker → UED Sync → LDAP-B: posixAccount on 192.168.122.89
3. GET /api/users/{uid}/qrcode
   → Returns signed payload with XMPP/SIP service endpoints
   → Records in provision_tokens + qr_issuance_audit
4. POST /api/provision/consume {token, deviceId}
   → Validates and consumes token
   → Returns UC config (JID, SIP URI, authMethod)
5. XMPP client connects to 192.168.122.89:5222
   → Authenticates as uid@private.z with password
   → Sends/receives messages
6. Verify audit trail in provision_tokens + sync_events
```

### QR Code Content Structure (v2 schema)
```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": {
      "tenant": "azblink",
      "xmpp": {"domain": "private.z", "wsUrl": ""},
      "sip": {"domain": "", "wssUrl": ""},
      "credentials": {"username": "testuser", "token": "one-time-token"}
    },
    "sso": null
  },
  "iat": 1740441600,
  "exp": 1740445200,
  "nonce": "random",
  "sig": "hmac-hex"
}
```

### Audit Trail Tables
- `provision_tokens`: token_hash, uid, status (active/consumed/expired/revoked), consumed_by_device_id, client_platform, used_at
- `qr_issuance_audit`: user_uid, issued_by, token_hash, consumed, expires_at
- `sync_events`: profile_id, user_uid, event_type, status (pending/in_progress/completed/failed), attempts

## Knowledge Gaps

| # | Topic | Priority | Why |
|---|-------|----------|-----|
| 1 | slixmpp messaging API | CRITICAL | Need to send/receive messages between 2 clients |
| 2 | UED Sync targeting external LDAP | CRITICAL | Must configure profile to point UED at 192.168.122.89 |
| 3 | Sync event completion timing | HELPFUL | Need to wait for async sync before XMPP auth works |

## Team Composition

- **Backend + Test** (combined) — single specialist can handle this
- Frontend: NOT needed (no UI)
- Database: NOT needed (backend handles queries)
- DevOps: NOT needed (existing stack)

## Key Files

1. `src/ued-sync/scripts/verify-xmpp.py` — slixmpp client pattern
2. `src/backend/main.py:1949-2050` — QR generation endpoint
3. `src/backend/main.py:1608-1696` — Provision consume endpoint
4. `src/backend/main.py:1336-1395` — User create with provisioning
5. `src/ued-sync/src/ued_sync/schemas/xmpp.py` — XMPP schema
6. `tests/test_qr_flow_integration.py` — Existing QR flow test pattern
7. `tests/conftest.py` — Test fixtures
8. `docs/plans/sessions/2026-02-21-e2e-verification-spec.md` — Real server details
