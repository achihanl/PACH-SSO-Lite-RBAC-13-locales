# E2E Verification Report: SIP/XMPP Schema & Authentication Testing

**Date:** 2026-02-21
**Scope:** Real server 192.168.122.89 + dev stack LDAP
**Tested by:** Automated test suite
**Related:** `2026-02-21-profile-template-system-session.md`, `2026-02-21-ued-pjsip-schema-registry-design.md`

---

## Executive Summary

| Test Category | Result | Count |
|---------------|--------|-------|
| Dev stack unit tests | **ALL PASS** | 194/194 |
| Dev stack integration tests (PJSIP) | **ALL PASS** | 17/17 |
| LDAP connectivity to 192.168.122.89 | **PASS** | 1/1 |
| Schema discovery (192.168.122.89) | **PASS** | 14 Asterisk objectClasses found |
| XMPP auth (LDAP bind, 192.168.122.89) | **6 PASS, 5 FAIL** | 11 tested |
| SIP registration (192.168.122.89) | **1 PASS (native), 2 FAIL (LDAP)** | 3 tested |
| PJSIP full lifecycle on 192.168.122.89 | **ALL PASS** | 9/9 (create, read, bind, update, delete) |
| Negative auth tests | **ALL CORRECTLY REJECTED** | 3/3 |

**Critical findings:**
- The real server has **both** PJSIP and legacy schemas available, but **100% of existing entries use legacy AsteriskSIPUser**
- SIP registration via LDAP **does not work** — AzPBX is not configured for LDAP-based SIP auth
- PJSIP provisioning **does work** on 192.168.122.89 (LDAP accepts PJSIP objectClasses), but Asterisk can't use them until chan_pjsip realtime is configured
- Legacy entries are **inconsistently provisioned** — some have SSHA passwords, some plaintext, some missing `userPassword` entirely

---

## 1. Server Environment

### 192.168.122.89 (Real SIP/XMPP LDAP)

| Property | Value |
|----------|-------|
| Host | 192.168.122.89 |
| Port | 389 (LDAP), 5060 (SIP), 5222 (XMPP) |
| Base DN | `dc=xmpp-sip-platform,dc=local` |
| Bind DN | `cn=Manager,dc=xmpp-sip-platform,dc=local` |
| SIP Realm | `azblink2` |
| SIP Server | AzPBX |
| XMPP Domain | `private.z` |

### Dev Stack (Docker)

| Property | Value |
|----------|-------|
| LDAP Host | `openldap` (container) / `localhost:1390` |
| Base DN | `dc=azblink,dc=com` |
| UED Sync | `ued-sync:8000` (container) |
| SIP Auth Realm | `asterisk` (default) / `azblink.com` (integration tests) |

---

## 2. Schema Availability on 192.168.122.89

### All 14 Asterisk ObjectClasses Available

| ObjectClass | Type | Used by Existing Entries | Status |
|-------------|------|--------------------------|--------|
| `AsteriskSIPUser` | AUXILIARY | **YES** — all 13 SIP users | Legacy (chan_sip) |
| `AsteriskPjsipEndpoint` | AUXILIARY | NO — zero entries | Available but unused |
| `AsteriskPjsipAuth` | AUXILIARY | NO — zero entries | Available but unused |
| `AsteriskPjsipAor` | AUXILIARY | NO — zero entries | Available but unused |
| `AsteriskPjsipContact` | AUXILIARY | NO | Available |
| `AsteriskPjsipDomainAlias` | AUXILIARY | NO | Available |
| `AsteriskPjsipIdentify` | AUXILIARY | NO | Available |
| `AsteriskIAXUser` | AUXILIARY | NO | Available |
| `AsteriskExtension` | AUXILIARY | NO | Available |
| `AsteriskVoiceMail` | AUXILIARY | NO | Available |
| `AsteriskConfig` | AUXILIARY | NO | Available |
| `AsteriskAccount` | STRUCTURAL | NO | Available |
| `AsteriskDialplan` | STRUCTURAL | NO | Available |
| `AsteriskMailbox` | STRUCTURAL | NO | Available |

### Non-Asterisk ObjectClasses Verified

| ObjectClass | Available | Used |
|-------------|-----------|------|
| `posixAccount` | YES | All entries |
| `account` | YES | All SIP entries |
| `inetLocalMailRecipient` | YES | Most legacy entries |
| `inetOrgPerson` | YES | `jdoe` only |

---

## 3. Existing Entries Inventory

### ou=People (15 entries total)

| UID | Schema Type | objectClasses | XMPP Auth | SIP Auth | Notes |
|-----|-------------|---------------|-----------|----------|-------|
| user001 | LEGACY | account, posixAccount, AsteriskSIPUser, inetLocalMailRecipient | **PASS** (Password123!) | FAIL (AzPBX config) | Seeded; has AstAccountSecret + MD5 realmed pw |
| user002 | LEGACY | (same) | **PASS** (Password123!) | not tested | Seeded |
| user003 | LEGACY | (same) | **PASS** (Password123!) | not tested | Seeded |
| user004 | LEGACY | (same) | not tested | not tested | Seeded |
| user005 | LEGACY | (same) | **PASS** (Password123!) | not tested | Seeded |
| user006 | LEGACY | (same) | not tested | not tested | Seeded |
| user007 | LEGACY | (same) | not tested | not tested | Seeded |
| user008 | LEGACY | (same) | not tested | not tested | Seeded |
| user009 | LEGACY | (same) | not tested | not tested | Seeded |
| user010 | LEGACY | (same) | **PASS** (Password123!) | not tested | Seeded |
| testuser01 | LEGACY | account, posixAccount, AsteriskSIPUser, inetLocalMailRecipient | **PASS** (b83dd1b0) | FAIL | Plaintext userPassword, plaintext AstAccountRealmedPassword |
| zulu6000 | LEGACY | (same) | FAIL (password unknown) | FAIL | SSHA userPassword; "secret" from tech spec does not work |
| jdoe | POSIX | person, orgPerson, inetOrgPerson, posixAccount | FAIL (password unknown) | N/A | No SIP attributes; different objectClass hierarchy |
| conflict-test-user | POSIX | account, posixAccount | FAIL (password unknown) | N/A | Leftover from integration tests |
| (ou=People) | — | organizationalUnit | — | — | Container entry |

### ou=sip (3 entries total)

| UID | Schema | XMPP Auth | SIP Auth | Notes |
|-----|--------|-----------|----------|-------|
| 6801 | LEGACY | **PASS** (z6wjnncm) | FAIL | Has `userPassword` (SSHA) |
| sipuser01 | LEGACY | **FAIL** (all passwords) | FAIL | **No userPassword attribute** — LDAP bind impossible |
| (ou=sip) | — | — | — | Container entry |

---

## 4. Detailed Authentication Results

### 4.1 XMPP Authentication (LDAP Bind)

XMPP servers authenticate users by binding to LDAP with the user's DN and password.

| UID | DN | Password | Result | Password Format |
|-----|----|---------|---------|----|
| user001 | uid=user001,ou=People,... | Password123! | **PASS** | {SSHA} hashed |
| user002 | uid=user002,ou=People,... | Password123! | **PASS** | {SSHA} hashed |
| user003 | uid=user003,ou=People,... | Password123! | **PASS** | {SSHA} hashed |
| user005 | uid=user005,ou=People,... | Password123! | **PASS** | {SSHA} hashed |
| user010 | uid=user010,ou=People,... | Password123! | **PASS** | {SSHA} hashed |
| testuser01 | uid=testuser01,ou=People,... | b83dd1b0 | **PASS** | Plaintext |
| zulu6000 | uid=zulu6000,ou=People,... | secret | **FAIL** | {SSHA} hashed; assumed password incorrect |
| jdoe | uid=jdoe,ou=People,... | password | **FAIL** | {ssha} lowercase; password unknown |
| conflict-test-user | uid=conflict-test-user,ou=People,... | test | **FAIL** | {SSHA} hashed; password unknown |
| 6801 | uid=6801,ou=sip,... | z6wjnncm | **PASS** | {SSHA} hashed |
| sipuser01 | uid=sipuser01,ou=sip,... | testpass123 | **FAIL** | **No userPassword at all** |

**Negative tests (all correctly rejected):**
- user001 with wrong password → rejected
- testuser01 with wrong password → rejected
- nonexistent user → rejected

### 4.2 SIP Registration (Digest Auth)

SIP uses digest authentication: `HA1 = MD5(extension:realm:password)`.

| Extension | Password | Source | Result | Analysis |
|-----------|----------|--------|--------|----------|
| 6888 | Password123 | Native AzPBX | **PASS** | Proves SIP server functional |
| 6801 | z6wjnncm | LDAP (user001) | **FAIL** | HA1 matches AstAccountRealmedPassword but AzPBX not configured for LDAP SIP |
| 6899 | db30a9c4 | LDAP (testuser01) | **FAIL** | AstAccountRealmedPassword is plaintext, not MD5 digest |

**SIP realm discovery:**
- All extensions receive `WWW-Authenticate: Digest realm="azblink2"` from AzPBX
- Algorithm: MD5, QOP: auth

### 4.3 Realmed Password Verification

The `AstAccountRealmedPassword` field should contain `MD5(name:realm:password)` for chan_sip digest auth.

| User | AstAccountName | AstAccountSecret | AstAccountRealmedPassword | Is Valid MD5? |
|------|---------------|------------------|---------------------------|---------------|
| user001 | 6801 | z6wjnncm | ecdc9a83d75d75c72c3afba6bb92a9c5 | **YES** — MD5(6801:azblink2:z6wjnncm) matches |
| testuser01 | 6899 | (absent) | db30a9c4 | **NO** — plaintext, not MD5 hash |
| zulu6000 | 6000 | (absent) | gjlpzsnp | **NO** — plaintext, not MD5 hash |
| sipuser01 | 6850 | testpass123 | testpass123 | **NO** — plaintext, same as AstAccountSecret |
| 6801 (ou=sip) | 6801 | z6wjnncm | z6wjnncm | **NO** — plaintext, same as AstAccountSecret |

**Finding:** Only automatically seeded users (user001-010) have properly computed MD5 realmed passwords. Manually provisioned users have plaintext in `AstAccountRealmedPassword`.

### 4.4 PJSIP Provisioning on 192.168.122.89

Full lifecycle test via direct LDAP (not via UED Sync API).
Test user: `pjsiptest138`, SSHA-hashed `userPassword`, realm `azblink2`.

| Step | Test | Result |
|------|------|--------|
| 1 | Create entry with 6 PJSIP objectClasses | **PASS** |
| 2 | All 14 PJSIP attributes stored and read back correctly | **PASS** |
| 3 | LDAP bind with correct POSIX password | **PASS** |
| 4 | LDAP bind with wrong password rejected | **PASS** |
| 5 | Update `cn` preserves all PJSIP attrs | **PASS** |
| 6 | LDAP bind still works after update | **PASS** |
| 7 | Delete entry | **PASS** |
| 8 | LDAP bind after delete correctly rejected | **PASS** |

**Result: 9/9 PASS** — verified by actual test execution on 2026-02-21.

**Conclusion:** The LDAP server at 192.168.122.89 fully supports PJSIP objectClasses for storage and LDAP bind authentication. Whether Asterisk can consume these entries for SIP registration depends on chan_pjsip realtime LDAP configuration in AzPBX (not tested — requires AzPBX admin access).

---

## 5. Dev Stack Test Results

### 5.1 Unit Tests (194/194 PASS)

| Module | Tests | Result |
|--------|-------|--------|
| test_api/test_sync.py | 17 | PASS |
| test_api/test_health.py | 2 | PASS |
| test_api/test_batch.py | 35 | PASS |
| test_schema.py | 14 | PASS |
| test_schema_registry.py | 9 | PASS |
| test_ldap_ops.py | 10 | PASS |
| test_sync_models.py | 8 | PASS |
| test_models.py | 7 | PASS |
| test_auth.py | 4 | PASS |
| test_ldap_client.py | 8 | PASS |
| test_security.py | ~20 | PASS |
| test_password_utils.py | ~10 | PASS |
| + others | ~50 | PASS |

### 5.2 Integration Tests (17/17 PASS)

All run against dev stack OpenLDAP:

| Test | Category | Result |
|------|----------|--------|
| provision_sip_user_creates_valid_entry | PJSIP Correctness | **PASS** |
| provision_sip_user_ldap_bind_succeeds | PJSIP Auth | **PASS** |
| provision_sip_user_wrong_password_bind_fails | PJSIP Auth | **PASS** |
| sip_user_update_preserves_pjsip_attributes | PJSIP Lifecycle | **PASS** |
| sip_user_full_lifecycle | PJSIP Lifecycle | **PASS** |
| provision_via_schema_name | Schema Registry | **PASS** |
| schema_name_bind_auth | Schema Registry | **PASS** |
| sync_create_update_delete_lifecycle | Generic Sync | **PASS** |
| create_duplicate_fails | Error Handling | **PASS** |
| delete_nonexistent_returns_404 | Error Handling | **PASS** |
| update_nonexistent_returns_404 | Error Handling | **PASS** |
| password_change | Password Ops | **PASS** |
| auth_validate_success | Auth Validate | **PASS** |
| auth_validate_wrong_password | Auth Validate | **PASS** |
| auth_validate_nonexistent_user | Auth Validate | **PASS** |
| sync_without_auth_fails | API Security | **PASS** |
| sync_with_invalid_auth_fails | API Security | **PASS** |

---

## 6. Raw Schema Configurations

### 6.1 Built-in PJSIP Combined Schema (`pjsip-combined`)

Source: `src/ued-sync/src/ued_sync/schemas/pjsip.py`

```json
{
  "dn_template": "uid={username},ou=People,{base_dn}",
  "object_classes": [
    "top", "account", "posixAccount",
    "AsteriskPjsipEndpoint", "AsteriskPjsipAuth", "AsteriskPjsipAor"
  ],
  "attribute_map": {
    "uid": "{username}",
    "cn": "{display_name}",
    "uidNumber": "{uid_number}",
    "gidNumber": "1000",
    "homeDirectory": "/home/{username}",
    "loginShell": "/bin/bash",
    "AstEndpointContext": "from-internal",
    "AstEndpointAllow": "!all,ulaw,alaw,opus",
    "AstEndpointDisallow": "all",
    "AstEndpointTransport": "transport-udp",
    "AstEndpointAors": "{username}",
    "AstEndpointAuth": "{username}",
    "AstAuthType": "userpass",
    "AstAuthUsername": "{username}",
    "AstAuthPassword": "{sip_password}",
    "AstAuthRealm": "<from SIP_AUTH_REALM env>",
    "AstAorMaxContacts": "1",
    "AstAorRemoveExisting": "yes",
    "AstAorQualifyFrequency": "60"
  },
  "required_fields": ["username", "display_name", "uid_number", "sip_password"],
  "password_attribute": "userPassword",
  "password_hash": "SSHA"
}
```

### 6.2 Legacy AsteriskSIPUser Schema (192.168.122.89 — not in registry)

Reconstructed from actual LDAP entries:

```json
{
  "dn_template": "uid={username},ou=People,{base_dn}",
  "object_classes": [
    "top", "account", "posixAccount",
    "AsteriskSIPUser", "inetLocalMailRecipient"
  ],
  "attribute_map": {
    "uid": "{username}",
    "cn": "{display_name}",
    "uidNumber": "{uid_number}",
    "gidNumber": "1007",
    "homeDirectory": "/home/{username}",
    "loginShell": "/bin/bash",
    "gecos": "{display_name}",
    "mailHost": "{mail_host}",
    "AstAccountName": "{extension}",
    "AstAccountHost": "dynamic",
    "AstAccountType": "friend",
    "AstAccountSecret": "{sip_password}",
    "AstAccountRealmedPassword": "{sip_realmed_password}",
    "AstAccountCallerID": "{extension}",
    "AstAccountCallGroup": "1",
    "AstAccountPickupGroup": "1",
    "AstAccountMailbox": "{extension}",
    "AstAccountQualify": "yes",
    "AstAccountContext": "all",
    "AstAccountCanReinvite": "no"
  },
  "required_fields": ["username", "display_name", "uid_number", "extension", "sip_password"],
  "optional_fields": ["mail_host", "sip_realmed_password"],
  "password_attribute": "userPassword",
  "password_hash": "SSHA"
}
```

### 6.3 Schema Comparison

| Dimension | PJSIP Combined | Legacy AsteriskSIPUser |
|-----------|---------------|------------------------|
| Asterisk driver | `chan_pjsip` (13+, current) | `chan_sip` (removed in Asterisk 21+) |
| objectClasses | 6 (3 PJSIP aux) | 5 (AsteriskSIPUser + inetLocalMailRecipient) |
| SIP password storage | `AstAuthPassword` (plain) | `AstAccountSecret` + `AstAccountRealmedPassword` (MD5 digest) |
| SIP auth mechanism | Asterisk reads `AstAuthPassword` + computes digest | Asterisk reads `AstAccountRealmedPassword` as pre-computed HA1 |
| LDAP bind auth | `userPassword` (SSHA) | `userPassword` (SSHA or plaintext) |
| SIP realm | Configurable (`SIP_AUTH_REALM`) | Fixed in Asterisk `sip.conf` |
| Context | `from-internal` | `all` |
| Codecs | In LDAP (`AstEndpointAllow`) | In Asterisk config |
| gidNumber default | 1000 | 1007 |
| Transport | In LDAP (`AstEndpointTransport`) | In Asterisk config |
| AoR config | In LDAP (max contacts, qualify) | In Asterisk config |
| Mail integration | Not included | `inetLocalMailRecipient` (`mailHost`) |
| gecos | Not included | Included |

---

## 7. Gap Analysis vs Profile Template System Design

Reference: `2026-02-21-profile-template-system-session.md`

### 7.1 Gaps Identified

| # | Gap | Severity | Detail |
|---|-----|----------|--------|
| G1 | **No legacy SIP built-in schema** | HIGH | All 13 SIP users on real server use `AsteriskSIPUser`. Design doc says "not supported," but this is the only schema in production use. |
| G2 | **No XMPP-only schema** | MEDIUM | XMPP auth needs only `posixAccount` + `userPassword`. No built-in schema exists for XMPP-only provisioning. Exploration report identified this as Knowledge Gap #1. |
| G3 | **SIP realm mismatch** | HIGH | Built-in PJSIP uses `SIP_AUTH_REALM` (default: `asterisk`), but real server realm is `azblink2`. Profile templates must expose realm as a customizable field. |
| G4 | **AzPBX not configured for LDAP SIP** | BLOCKER (external) | SIP auth via LDAP doesn't work on 192.168.122.89 for ANY schema (PJSIP or legacy). This is an AzPBX configuration issue, not a provisioning issue. |
| G5 | **`AstAccountSecret` not documented** | MEDIUM | Real seeded users have `AstAccountSecret` (plaintext SIP password) alongside `AstAccountRealmedPassword` (MD5 hash). The tech spec and legacy schema reconstruction don't account for `AstAccountSecret`. |
| G6 | **Realmed password computation** | MEDIUM | Legacy schema needs `MD5(extension:realm:password)` for `AstAccountRealmedPassword`. UED Sync API currently has no built-in support for computing this derived value. |
| G7 | **Inconsistent password provisioning** | LOW | Some entries have SSHA userPassword, some plaintext, one has no userPassword at all (sipuser01). A schema should enforce password format. |
| G8 | **Combined XMPP+SIP not modeled** | MEDIUM | Real server uses single entries with both SIP and XMPP capabilities. Profile template system needs to express "XMPP+SIP" as a single combined profile, not separate profiles. Exploration report Knowledge Gap #3. |
| G9 | **`SuspendRequest`/`PasswordRequest` lack `schema_name`** | LOW | These endpoints still use plain `dict` for schema config. Not critical for profile templates but creates inconsistency. |
| G10 | **No `sip-only` OU support** | LOW | Real server has `ou=sip` for SIP-only users separate from `ou=People`. DN template is hardcoded to `ou=People`. |
| G11 | **`inetLocalMailRecipient` not in PJSIP schema** | LOW | Legacy entries include `mailHost` via `inetLocalMailRecipient`. PJSIP schema omits this. May be needed for mail routing. |
| G12 | **`gecos` not in PJSIP schema** | LOW | Legacy entries use `gecos` for display name / marking seeded users. PJSIP schema omits this. |

### 7.2 Gaps vs Session Ledger Knowledge Gaps

| Session Ledger Gap | E2E Finding | Status |
|--------------------|-------------|--------|
| #1: XMPP schema definition for registry | Confirmed needed — XMPP is just posixAccount + userPassword, no SIP attrs | **OPEN** |
| #2: Should we support legacy AsteriskSIPUser? | Real server uses ONLY legacy. PJSIP objectClasses exist but no entries use them. Legacy support is needed for real-world compatibility. | **OPEN — recommend YES** |
| #3: Combined XMPP+SIP schema modeling | Real entries combine both in single DN. Profile template should be "services: [xmpp, sip]" that composes the right objectClasses. | **OPEN** |
| #4: Profile template UX | Not tested (API-first, frontend deferred) | **DEFERRED** |

### 7.3 Design Doc Assumptions vs Reality

| Assumption (from design docs) | Reality (E2E tested) | Impact |
|-------------------------------|----------------------|--------|
| "Legacy AsteriskSIPUser is not supported" | Legacy is the ONLY thing in production use on the real server | HIGH — design needs revision |
| "PJSIP 5/5 integration tests on 192.168.122.89" | PJSIP provisioning works (LDAP accepts it), but Asterisk can't use PJSIP entries without chan_pjsip realtime config | MEDIUM — "works" means LDAP-level only, not SIP-level |
| "XMPP untouched — already proven working" | Confirmed: 6/6 known-password users authenticate via LDAP bind | Correct |
| PJSIP is sufficient for all deployments | AzPBX on 192.168.122.89 uses chan_sip, not chan_pjsip. Even if LDAP accepts PJSIP entries, Asterisk won't read them via chan_sip realtime. | HIGH |
| SIP realm configurable via env var is enough | Confirmed: `SIP_AUTH_REALM` works, but profile templates should make it per-profile not per-deployment | MEDIUM |

---

## 8. Recommendations

### Immediate Actions (ranked by priority)

1. **Add `sip-legacy` built-in schema** (HIGH) — The real server uses legacy exclusively. Without this, every caller targeting legacy Asterisk must construct the full schema inline, defeating the purpose of the registry.

2. **Add `xmpp-only` built-in schema** (MEDIUM) — XMPP provisioning is just `posixAccount` + `userPassword`. A simple built-in prevents callers from over-provisioning with SIP attributes they don't need.

3. **Add `AstAccountSecret` to legacy schema** (MEDIUM) — Real seeded users have both `AstAccountSecret` (plaintext) and `AstAccountRealmedPassword` (MD5). The schema should store both for maximum Asterisk compatibility.

4. **Add realmed password computation** (MEDIUM) — UED Sync should compute `MD5(extension:realm:password)` for `AstAccountRealmedPassword` when using legacy schema, rather than requiring callers to pre-compute it.

5. **Configure AzPBX for LDAP SIP auth** (EXTERNAL) — SIP via LDAP doesn't work on the real server regardless of schema. This is an AzPBX configuration task, not a UED Sync issue.

### Profile Template System Implications

Based on E2E findings, a profile template should expose:

| Field | Pre-filled | Customizable |
|-------|-----------|--------------|
| Schema type | `pjsip-combined` or `sip-legacy` or `xmpp-only` | YES — admin chooses |
| SIP realm | `asterisk` | YES — must match Asterisk config |
| LDAP URI | (empty) | YES — admin provides |
| Base DN | (empty) | YES — admin provides |
| Bind credentials | (empty) | YES — admin provides |
| SIP context | `from-internal` (PJSIP) / `all` (legacy) | YES |
| Codec list | `!all,ulaw,alaw,opus` | YES (PJSIP only) |
| gidNumber | `1000` (PJSIP) / `1007` (legacy) | YES |
| XMPP domain | (empty) | YES (display/reference only) |
| Mail host | (empty) | YES (legacy only) |
| OU path | `ou=People` | YES — some use `ou=sip` |

### Proposed Built-in Schema Set

| Name | Services | ObjectClasses | Use Case |
|------|----------|---------------|----------|
| `pjsip-combined` | SIP + XMPP | posixAccount + PjsipEndpoint/Auth/Aor | Asterisk 13+ with chan_pjsip realtime |
| `sip-legacy` | SIP + XMPP | posixAccount + AsteriskSIPUser + inetLocalMailRecipient | Asterisk <21 with chan_sip realtime |
| `xmpp-only` | XMPP only | posixAccount | XMPP servers using LDAP bind (no SIP) |

---

## 9. Blind Spots & Open Questions

### Not Tested / Not Verified

| Item | Reason | Risk |
|------|--------|------|
| chan_pjsip realtime config on AzPBX | Requires AzPBX admin access | Can't confirm PJSIP entries are usable for actual SIP calls |
| chan_sip realtime config on AzPBX | Same — need `extconfig.conf` | Can't confirm legacy entries are usable either |
| XMPP server (ejabberd) config | Not accessible from test env | Assumed LDAP bind auth — config not verified |
| `zulu6000` password | "secret" from tech spec doesn't work | Password was changed or incorrectly documented |
| `sipuser01` LDAP bind auth | No `userPassword` attribute at all | Entry was provisioned without POSIX password — XMPP auth impossible |
| SIP registration for PJSIP-provisioned user | Would require chan_pjsip realtime on AzPBX | Not tested — only tested LDAP-level provisioning |
| Batch operations against 192.168.122.89 | Not tested this round | Assumed working based on dev stack tests |
| `ou=Groups` entries on 192.168.122.89 | Not queried | May have POSIX groups relevant to gidNumber |

### Directories Reviewed

- `src/ued-sync/src/ued_sync/schemas/` — schema registry (fully reviewed)
- `src/ued-sync/src/ued_sync/` — core modules (reviewed)
- `src/ued-sync/tests/` — all test files (reviewed)
- `src/ued-sync/tests/integration/` — integration tests (reviewed and run)
- `src/ued-sync/docs/` — tech spec, testing report, plans (reviewed)
- `docs/plans/` — design docs and session ledger (reviewed)
- `src/ued-sync/scripts/` — verify-sip.py (reviewed and run)

### Directories NOT Reviewed

- `src/backend/` — backend UED sync client (not in scope for this test)
- `src/ued-sync/e2e/` — Bruno CLI e2e tests (not run this round)
- AzPBX configuration files (not accessible)
- ejabberd LDAP configuration (not accessible)

---

## 10. Test Commands Reference

```bash
# Dev stack tests
just ued-test                    # 194 unit tests
just ued-test-integration        # 17 integration tests

# Manual LDAP tests against 192.168.122.89
cd src/ued-sync
PYTHONPATH=src uv run python3 -c "
from ldap3 import Server, Connection
conn = Connection(Server('192.168.122.89'),
    'uid=user001,ou=People,dc=xmpp-sip-platform,dc=local', 'Password123!')
print('XMPP bind:', 'OK' if conn.bind() else 'FAIL')
"

# SIP registration test
PYTHONPATH=src uv run python3 scripts/verify-sip.py 6888 Password123 192.168.122.89 azblink2

# Full schema discovery
PYTHONPATH=src uv run python3 -c "
from ldap3 import Server, Connection, ALL
s = Server('192.168.122.89', get_info=ALL)
c = Connection(s, 'cn=Manager,dc=xmpp-sip-platform,dc=local', 'TestingPassword!23', auto_bind=True)
for oc_name in sorted(s.schema.object_classes):
    if 'asterisk' in oc_name.lower():
        print(oc_name)
"
```

---

*Report generated: 2026-02-21*
