---
feature: profile-ued-architecture-fix
date: 2026-02-24
phase: exploration
---

# Exploration Report: Profile-UED Architecture Fix

## Team Recommended
- **Backend** (Python/FastAPI/LDAP) — REQUIRED, heaviest domain
- **Frontend** (React/TypeScript/CSS) — REQUIRED, moderate scope (mostly deletion + restructuring)

## Knowledge Gaps
1. SQLAlchemy Core JOIN syntax for resolve_template_for_org (Critical)
2. Pydantic BaseSettings optional fields with env var names (Helpful)
3. TanStack Query invalidation after mutation (Helpful)
4. PostgreSQL ALTER TABLE DROP COLUMN with JSONB defaults (Helpful)

## Implementation Dependency Order
```
Task 1 (UED Sync env vars + discovery response)
  → Task 2 (Cache service endpoints on profile)
    → Task 3 (Drop xmpp_config/sip_config) → Task 4 (Badge derivation)
    → Task 5 (QR assembly from cached discovery)
    → Task 6 (Lifecycle sync TODOs)
```

## Key Architectural Decision
The `resolve_template_for_org(org_dn)` method in orgdb.py is the critical new code.
Joins config_template_assignments to config_templates to find the active profile for an org.
Enables both QR service URL resolution (task 5) and lifecycle sync routing (task 6).

## Files to Modify Summary
- **UED Sync**: config.py, sync_models.py, routers/discovery.py, tests/
- **Backend**: main.py, orgdb.py, config.py, ued_discovery.py
- **Frontend**: types/org-profiles.ts, ProfileCard.tsx, ProfileFormModal.tsx, ConfigTab.tsx
- **Database**: migrations/015_ued_service_endpoints.sql (NEW)
- **DevOps**: .env.example, docker-compose.yml
