# Profile Template System — Exploration Report

**Date:** 2026-02-21

## Key Findings

### 1. Schema Registry Pattern (Existing — SIP Only)

The UED Sync API has a working schema registry at `src/ued-sync/src/ued_sync/schemas/`:
- `__init__.py` — `get_schema(name)` + `list_schemas()`, factory-based registry
- `pjsip.py` — `pjsip_combined_schema()` factory, parameterized by `SIP_AUTH_REALM`
- Registry maps string names to no-arg callables returning `ProvisioningSchema`
- `SyncUserRequest` and `BatchRequest` support `schema_name` field with inline-wins priority

### 2. XMPP Authentication Model

**Critical insight from `ldap-technical-spec.md`:**
- XMPP authentication works via **LDAP bind** — the XMPP server (ejabberd) binds to LDAP using the user's DN + password
- There is **no XMPP-specific objectClass** — just `posixAccount` with `userPassword`
- The DN pattern is: `uid={username},ou=People,{base_dn}`
- This means XMPP provisioning is essentially **basic POSIX user creation**

### 3. Two SIP Schemas in Play

| Schema | ObjectClass | Server | Status |
|--------|-------------|--------|--------|
| PJSIP (Asterisk 13+) | `AsteriskPjsipEndpoint/Auth/Aor` | Dev stack | Built-in registry schema |
| Legacy SIP (chan_sip) | `AsteriskSIPUser` | 192.168.122.89 | Used in ldap-technical-spec, no registry schema |

The design doc explicitly says: "Legacy AsteriskSIPUser (chan_sip, removed in Asterisk 21+) is not supported."
However, the real server at 192.168.122.89 **uses the legacy schema**.

### 4. Existing Config Templates vs UED Tenant Configs

Two separate systems exist:
- **config_templates** (orgdb.py:199) — Client-side config (XMPP domains, SIP WebSocket URLs, QR settings). For the mobile/desktop app.
- **tenant_ldap_configs** (orgdb.py:262) — Server-side provisioning config (LDAP connection + schema). For UED Sync provisioning.

The "profile template" feature bridges these: predefined combinations of LDAP connection + schema that admins can reuse.

### 5. What a "Profile" Actually Is

Based on the codebase analysis, a "profile" = a reusable template that pre-fills a `tenant_ldap_configs` entry:
- LDAP connection defaults (URI pattern, base_dn pattern, SSL, timeout)
- Schema reference (schema_name pointing to a built-in, or inline schema)
- Service-specific parameters (SIP realm, XMPP domain, etc.)
- Admin only needs to provide: LDAP host/credentials, maybe domain-specific values

### 6. Real Server at 192.168.122.89

- Base DN: `dc=xmpp-sip-platform,dc=local`
- Bind DN: `cn=Manager,dc=xmpp-sip-platform,dc=local`
- Has both XMPP (LDAP bind auth) and SIP (AsteriskSIPUser) capabilities
- SIP tests pass with PJSIP schema (7/7 integration tests)
- XMPP verified working via `verify-xmpp.py` script

## Knowledge Gaps

1. **XMPP schema definition for registry** — Need to define the standard XMPP-only objectClasses/attributes
2. **Legacy AsteriskSIPUser schema** — Should we support this as a built-in alongside PJSIP?
3. **Combined XMPP+SIP schema** — The real server uses a single entry with BOTH SIP and XMPP; how to model this?
4. **Profile template UX** — Admin creates profile → what fields are exposed vs pre-filled?

## Team Composition

- **Backend (Python/FastAPI/LDAP)** — PRIMARY: schema registry extensions, API endpoints, profile CRUD
- **Database** — SUPPORTING: if new migration needed for template storage
- **Test** — SUPPORTING: schema registry tests, integration tests

Frontend is deferred (API-first approach).

## Key Files

| File | Purpose |
|------|---------|
| `src/ued-sync/src/ued_sync/schemas/__init__.py` | Schema registry to extend |
| `src/ued-sync/src/ued_sync/schemas/pjsip.py` | Pattern to follow for new schemas |
| `src/ued-sync/src/ued_sync/sync_models.py` | Request models with schema_name |
| `src/ued-sync/src/ued_sync/schema.py` | ProvisioningSchema model |
| `src/ued-sync/src/ued_sync/config.py` | Settings to extend |
| `src/ued-sync/docs/ldap-technical-spec.md` | Real LDAP schema reference |
| `src/ued-sync/tests/test_schema_registry.py` | Test patterns to follow |
| `src/ued-sync/tests/integration/test_sip_provisioning.py` | Integration test pattern |
| `src/backend/orgdb.py` | tenant_ldap_configs + config_templates tables |
| `src/backend/main.py` | UED config API endpoints |
