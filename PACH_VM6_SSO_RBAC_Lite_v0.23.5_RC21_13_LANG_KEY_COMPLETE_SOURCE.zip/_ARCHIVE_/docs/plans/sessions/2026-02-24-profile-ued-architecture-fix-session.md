---
feature: profile-ued-architecture-fix
date: 2026-02-24
branch: feat/profile-ued-architecture-fix
mode: level-3
team: []
status: in-progress
---

# Session Ledger: Profile-UED Architecture Fix

Fix the architectural fraud in the profile system:
1. Add service endpoint env vars to UED Sync + include in discovery response
2. Cache service endpoints from UED discovery on profile
3. Drop xmpp_config/sip_config from profile (deprecated)
4. Profile card badges derived from UED capabilities
5. QR assembly from UED discovery + user creds
6. Fix lifecycle sync (TODO comments for update/password/suspend/terminate)
