# User Detail Panel Migration — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Migrate the user detail panel from a single-scroll layout to a tabbed design (Overview, Devices, Provisioning History, Activity) matching `new-migration-ui/use-details.html`, closing 11 identified gaps.

**Architecture:** Backend-first — expose `issued_by` in QR history, add per-user devices endpoint, add per-user stats endpoint, add `createTimestamp` to LDAP user fetch, add manager DN resolution. Then frontend — refactor UserDetailPanel into tabbed layout using existing `Tabs` primitive from `@azblink/ui`, build Overview tab with stat cards and summary cards, wire Edit User modal, restyle QR history as timeline, build Devices tab, add Activity placeholder.

**Tech Stack:** FastAPI (backend), SQLAlchemy (orgdb), python-ldap3 (LDAP), React 19, TanStack Query/Router, `@azblink/ui` primitives (Tabs, Badge, Button, DetailGrid, Skeleton), Tailwind CSS 4, Zustand

**Reference files:**
- Design target: `new-migration-ui/use-details.html`
- Gap analysis: `new-migration-ui/USER_DETAIL_GAP_ANALYSIS_REPORT.md`
- Current panel: `src/frontend/src/components/features/user-management/UserDetailPanel.tsx`

---

## Review Amendments (2026-02-12)

Plan was reviewed against the live codebase by 3 parallel code-explorer agents verifying test infrastructure, frontend patterns, and backend patterns. The following issues were found and fixed inline:

| ID | Severity | Task | Fix |
|----|----------|------|-----|
| B1 | BLOCKER | 3 | `create_test_user()` accepts 3 positional args only — rewrote test to use direct `client.post()` |
| B2 | BLOCKER | 3 | Manager DN path was `ou=default` — corrected to `ou=people` per cleanup in `conftest.py:98` |
| B3 | BLOCKER | 3 | Manager LDAP lookup used `SUBTREE` — corrected to `BASE` (exact DN) |
| B4 | BLOCKER | 5 | Plan said to add `func` import — already imported at `orgdb.py:37`, removed instruction |
| C1 | CORRECTNESS | 2 | `createTimestamp` may return as string, not datetime — added type-check fallback |
| C2 | CORRECTNESS | 6 | Step 6 was vague — expanded with explicit `handleEditUser` + `<UserDetailPanel>` prop wiring |
| C3 | CORRECTNESS | 8 | `userQRHistoryQueryOptions` not re-exported — added explicit import instruction |
| C4 | CORRECTNESS | 10 | `useSuspenseQuery` inside Dialog would throw — changed to `useQuery` with loading guard |
| S1 | MINOR | 11 | `stat-card.tsx` has same `text-[var(--text-xs)]` bug — added to cleanup step |

---

## Wave 1: Backend — QR History + LDAP Enhancements

### Task 1: Add `issued_by` to QR history response

**Files:**
- Modify: `src/backend/orgdb.py:922-929` (list_qr_issuance_for_user return dict)
- Modify: `src/frontend/src/lib/queries/users.ts:34-41` (QRHistoryEntry interface)
- Test: `tests/test_provisioning.py` (add new test)

**Step 1: Write the failing test**

Add to `tests/test_provisioning.py`:

```python
class TestQRHistory:
    """QR issuance history endpoint."""

    def test_qr_history_includes_issued_by(self, client, auth_headers, db_conn, created_users):
        """GET /api/users/{uid}/qr_history returns issued_by field."""
        uid = "qrhistory_test_1"
        create_test_user(client, uid, created_users)

        # Insert audit row with known issued_by
        with db_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO qr_issuance_audit
                    (user_uid, issued_by, issued_at, token_hash, expires_at, consumed)
                VALUES (%s, %s, NOW(), %s, NOW() + INTERVAL '1 hour', FALSE)
            """, (uid, "admin_sarah", "fakehash_issued_by_test"))

        resp = client.get(f"/api/users/{uid}/qr_history", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert len(data["history"]) >= 1
        assert data["history"][0]["issued_by"] == "admin_sarah"
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- -k test_qr_history_includes_issued_by -v`
Expected: FAIL — `issued_by` not in response dict

**Step 3: Add `issued_by` to the return dict**

In `src/backend/orgdb.py`, line 922-929, change the `history.append({...})` to include `issued_by`:

```python
            history.append({
                "id": r["id"],
                "issued_at": r["issued_at"].isoformat() if r["issued_at"] else None,
                "expires_at": r["expires_at"].isoformat() if r["expires_at"] else None,
                "status": display_status,
                "consumed_at": r["consumed_at"].isoformat() if r["consumed_at"] else None,
                "device_info": device_info,
                "issued_by": r["issued_by"] or None,
            })
```

No query change needed — `issued_by` is already selected (the `select(qr_issuance_audit, ...)` on line 880-885 selects all columns from qr_issuance_audit).

**Step 4: Run test to verify it passes**

Run: `just test-quick -- -k test_qr_history_includes_issued_by -v`
Expected: PASS

**Step 5: Update frontend type**

In `src/frontend/src/lib/queries/users.ts`, update `QRHistoryEntry`:

```typescript
export interface QRHistoryEntry {
  id: number;
  issued_at: string | null;
  expires_at: string | null;
  status: 'consumed' | 'expired' | 'pending' | 'revoked';
  consumed_at: string | null;
  device_info: string | null;
  issued_by: string | null;
}
```

**Step 6: Commit**

```bash
git add src/backend/orgdb.py src/frontend/src/lib/queries/users.ts tests/test_provisioning.py
git commit -m "feat(api): expose issued_by in user QR history response"
```

---

### Task 2: Add `createTimestamp` to LDAP user fetch

**Files:**
- Modify: `src/backend/ldap_client.py:568-599` (get_user function)
- Modify: `src/frontend/src/types/user.ts:10-22` (User interface)
- Test: `tests/test_provisioning.py` (add new test)

**Step 1: Write the failing test**

```python
class TestUserDetail:
    """GET /api/users/{uid} endpoint."""

    def test_user_includes_created_at(self, client, auth_headers, created_users):
        """User detail returns createdAt timestamp from LDAP createTimestamp."""
        uid = "created_at_test_1"
        create_test_user(client, uid, created_users)

        resp = client.get(f"/api/users/{uid}", headers=auth_headers)
        assert resp.status_code == 200
        user = resp.json()["user"]
        # createTimestamp is an operational attribute — should be present
        # May be empty string if LDAP doesn't support it, but key must exist
        assert "createdAt" in user
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- -k test_user_includes_created_at -v`
Expected: FAIL — `createdAt` not in user dict

**Step 3: Add `createTimestamp` to LDAP attributes and output**

In `src/backend/ldap_client.py`, line 577, add `"createTimestamp"` to the attributes list:

```python
            attributes=["uid", "cn", "mail", "mobile", "sn", "givenName",
                         "userPassword", "description", "title",
                         "employeeNumber", "manager", "createTimestamp"],
```

And after line 595, add to the `out` dict:

```python
            "createdAt": e.createTimestamp.value.isoformat() if hasattr(e, "createTimestamp") and e.createTimestamp.value else "",
```

Note: `createTimestamp` is an LDAP operational attribute. OpenLDAP returns it when explicitly requested. **Important:** ldap3 may return operational attributes as a generalized time string (`"20260115T120000Z"`) rather than a `datetime` object. Use the fallback pattern below to handle both:

```python
            # createTimestamp: operational attr — may be datetime or string
            raw_ts = e.createTimestamp.value if hasattr(e, "createTimestamp") and e.createTimestamp.value else None
            if raw_ts:
                if isinstance(raw_ts, str):
                    # Generalized time: "20260115120000Z" or similar
                    from datetime import datetime as _dt
                    try:
                        raw_ts = _dt.strptime(raw_ts.rstrip("Z"), "%Y%m%d%H%M%S")
                    except ValueError:
                        raw_ts = None
                out["createdAt"] = raw_ts.isoformat() if raw_ts else ""
            else:
                out["createdAt"] = ""
```

Replace the single-line `createdAt` assignment from Step 3 above with this block.

**Step 4: Run test to verify it passes**

Run: `just test-quick -- -k test_user_includes_created_at -v`
Expected: PASS

**Step 5: Update frontend User type**

In `src/frontend/src/types/user.ts`, add to `User` interface:

```typescript
export interface User {
  uid: UID;
  dn: DN;
  displayName: string;
  mail: string;
  mobile: string;
  orgDn: DN;
  accountStatus: AccountStatus;
  title?: string;
  memberOf?: string[];
  employeeNumber?: string;
  manager?: string;
  createdAt?: string;
}
```

**Step 6: Commit**

```bash
git add src/backend/ldap_client.py src/frontend/src/types/user.ts tests/test_provisioning.py
git commit -m "feat(api): expose createdAt from LDAP createTimestamp in user detail"
```

---

### Task 3: Add manager DN → display name resolution

**Files:**
- Modify: `src/backend/ldap_client.py:568-599` (get_user function)
- Test: `tests/test_provisioning.py` (add test)

**Step 1: Write the failing test**

```python
    def test_user_manager_display_name(self, client, auth_headers, created_users):
        """User detail resolves manager DN to display name."""
        # Create manager via direct API call (create_test_user helper doesn't accept kwargs)
        manager_uid = "mgr_resolve_test"
        resp = client.post("/api/users/create", json={
            "uid": manager_uid,
            "displayName": "Sarah Kim",
            "mail": f"{manager_uid}@test.com",
            "mobile": "1234567890",
            "password": "testpass123",
            "orgDn": f"ou=org,{LDAP_BASE_DN}",
        })
        assert resp.status_code == 201
        created_users.append(manager_uid)

        # Create user with manager set — users live under ou=people
        uid = "mgr_test_user_1"
        manager_dn = f"uid={manager_uid},ou=people,{LDAP_BASE_DN}"
        resp = client.post("/api/users/create", json={
            "uid": uid,
            "displayName": f"Test User {uid}",
            "mail": f"{uid}@test.com",
            "mobile": "1234567890",
            "password": "testpass123",
            "orgDn": f"ou=org,{LDAP_BASE_DN}",
            "manager": manager_dn,
        })
        assert resp.status_code == 201
        created_users.append(uid)

        resp = client.get(f"/api/users/{uid}", headers=auth_headers)
        assert resp.status_code == 200
        user = resp.json()["user"]
        assert user["managerDisplayName"] == "Sarah Kim"
```

**Important:** `create_test_user()` only accepts 3 positional args `(client, uid, created_users)` with hardcoded fields. For tests that need custom `displayName`, `manager`, or other fields, use direct `client.post("/api/users/create", json={...})` calls and manually append to `created_users` for cleanup. Users are created under `ou=people,{LDAP_BASE_DN}` (per `conftest.py:98` cleanup pattern).

**Step 2: Run test to verify it fails**

Run: `just test-quick -- -k test_user_manager_display_name -v`
Expected: FAIL — `managerDisplayName` not in response

**Step 3: Add manager resolution to get_user**

After the existing `out` dict is built (line 596 in ldap_client.py), add resolution:

```python
        # Resolve manager DN → display name (best-effort)
        # Use BASE scope — we're looking up a specific DN, not searching a subtree
        manager_dn = out.get("manager", "")
        if manager_dn:
            try:
                conn2 = get_conn()
                conn2.search(manager_dn, "(objectClass=*)", BASE, attributes=["cn"])
                if conn2.entries:
                    out["managerDisplayName"] = str(conn2.entries[0].cn.value)
                else:
                    out["managerDisplayName"] = ""
                conn2.unbind()
            except Exception:
                out["managerDisplayName"] = ""
        else:
            out["managerDisplayName"] = ""
```

Note: `BASE` scope (not `SUBTREE`) is correct here because we have the exact DN — no need to search children. `BASE` is already imported in `ldap_client.py` alongside `SUBTREE`.

**Step 4: Run test to verify it passes**

Run: `just test-quick -- -k test_user_manager_display_name -v`
Expected: PASS

**Step 5: Update frontend User type**

In `src/frontend/src/types/user.ts`, add:

```typescript
  managerDisplayName?: string;
```

**Step 6: Commit**

```bash
git add src/backend/ldap_client.py src/frontend/src/types/user.ts tests/test_provisioning.py
git commit -m "feat(api): resolve manager DN to display name in user detail"
```

---

## Wave 2: Backend — Devices + Stats Endpoints

### Task 4: Add per-user devices endpoint

**Files:**
- Modify: `src/backend/orgdb.py` (add `list_devices_for_user` method)
- Modify: `src/backend/main.py` (add GET /api/users/{uid}/devices route)
- Create: `src/frontend/src/lib/queries/user-devices.ts` (query options)
- Test: `tests/test_provisioning.py` (add test)

**Step 1: Write the failing test**

```python
class TestUserDevices:
    """GET /api/users/{uid}/devices endpoint."""

    def test_user_devices_empty(self, client, auth_headers, created_users):
        """Returns empty list for user with no consumed tokens."""
        uid = "devices_test_1"
        create_test_user(client, uid, created_users)

        resp = client.get(f"/api/users/{uid}/devices", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["uid"] == uid
        assert data["devices"] == []

    def test_user_devices_with_consumed_token(self, client, auth_headers, db_conn, created_users):
        """Returns device info from consumed provision tokens."""
        uid = "devices_test_2"
        create_test_user(client, uid, created_users)

        # Insert a consumed token with device info
        token_hash = "device_test_hash_123"
        with db_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO provision_tokens
                    (token_hash, uid, profile_id, issued_at, expires_at, status,
                     consumed_by_device_id, client_platform, client_version, consumed_from_ip, used_at)
                VALUES (%s, %s, 'test-profile', NOW() - INTERVAL '1 hour', NOW() + INTERVAL '1 hour',
                        'consumed', 'D8F2A1C3FULL', 'iOS', '3.2.1', '192.168.1.42', NOW())
            """, (token_hash, uid))

        resp = client.get(f"/api/users/{uid}/devices", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["devices"]) == 1
        device = data["devices"][0]
        assert device["device_id"] == "D8F2A1C3FULL"
        assert device["platform"] == "iOS"
        assert device["client_version"] == "3.2.1"
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- -k "TestUserDevices" -v`
Expected: FAIL — 404 (route doesn't exist)

**Step 3: Add orgdb method**

Add to `src/backend/orgdb.py` after `list_qr_issuance_for_user`:

```python
    def list_devices_for_user(self, uid: str) -> list[dict[str, Any]]:
        """Return devices that consumed provision tokens for a specific user."""
        eng = self.connect()
        stmt = (
            select(
                provision_tokens.c.consumed_by_device_id,
                provision_tokens.c.client_platform,
                provision_tokens.c.client_version,
                provision_tokens.c.consumed_from_ip,
                provision_tokens.c.used_at,
                provision_tokens.c.status,
            )
            .where(provision_tokens.c.uid == uid)
            .where(provision_tokens.c.consumed_by_device_id.isnot(None))
            .order_by(provision_tokens.c.used_at.desc())
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()

        devices = []
        for r in rows:
            devices.append({
                "device_id": r["consumed_by_device_id"],
                "platform": r["client_platform"] or "",
                "client_version": r["client_version"] or "",
                "ip_address": r["consumed_from_ip"] or "",
                "consumed_at": r["used_at"].isoformat() if r["used_at"] else None,
                "status": r["status"],
            })
        return devices
```

**Step 4: Add API route**

Add to `src/backend/main.py` after the `api_user_qr_history` route (~line 2042):

```python
@app.get("/api/users/{uid}/devices")
def api_user_devices(uid: str, claims: Dict[str, Any] = Depends(require_user)):
    """Per-user provisioned devices (tokens consumed with device info)."""
    user = get_user(uid)
    if not user:
        raise HTTPException(404, "User not found")

    devices = ORGDB.list_devices_for_user(uid)
    return {"ok": True, "uid": uid, "devices": devices}
```

**Step 5: Run test to verify it passes**

Run: `just test-quick -- -k "TestUserDevices" -v`
Expected: PASS

**Step 6: Add frontend query + types**

Create `src/frontend/src/lib/queries/user-devices.ts`:

```typescript
/**
 * TanStack Query options for per-user device endpoints.
 * - GET /api/users/{uid}/devices
 */
import { queryOptions } from '@tanstack/react-query';
import { getApi } from '../api-client';
import { queryKeys } from './keys';

export interface UserDevice {
  device_id: string;
  platform: string;
  client_version: string;
  ip_address: string;
  consumed_at: string | null;
  status: string;
}

export const userDevicesQueryOptions = (uid: string) =>
  queryOptions({
    queryKey: queryKeys.userDevices(uid),
    queryFn: () => getApi().get<{ ok: true; uid: string; devices: UserDevice[] }>(`/users/${uid}/devices`),
    staleTime: 60_000,
    enabled: !!uid,
  });
```

Add to `src/frontend/src/lib/queries/keys.ts`, after the `userQRHistory` line:

```typescript
  userDevices: (uid: string) => ['users', uid, 'devices'] as const,
```

**Step 7: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py src/frontend/src/lib/queries/user-devices.ts src/frontend/src/lib/queries/keys.ts tests/test_provisioning.py
git commit -m "feat(api): add GET /api/users/{uid}/devices endpoint"
```

---

### Task 5: Add per-user stats endpoint

**Files:**
- Modify: `src/backend/orgdb.py` (add `get_user_stats` method)
- Modify: `src/backend/main.py` (add GET /api/users/{uid}/stats route)
- Create: `src/frontend/src/lib/queries/user-stats.ts` (query options)
- Test: `tests/test_provisioning.py` (add test)

**Step 1: Write the failing test**

```python
class TestUserStats:
    """GET /api/users/{uid}/stats endpoint."""

    def test_user_stats_fresh_user(self, client, auth_headers, created_users):
        """Returns zeroed stats for a newly created user."""
        uid = "stats_test_1"
        create_test_user(client, uid, created_users)

        resp = client.get(f"/api/users/{uid}/stats", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["uid"] == uid
        assert data["active_devices"] == 0
        assert data["qr_codes_generated"] == 0
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- -k test_user_stats_fresh_user -v`
Expected: FAIL — 404 (route doesn't exist)

**Step 3: Add orgdb method**

Add to `src/backend/orgdb.py`:

```python
    def get_user_stats(self, uid: str) -> dict[str, Any]:
        """Aggregate stats for a user: device count, QR count."""
        eng = self.connect()
        with eng.begin() as conn:
            # Active devices = consumed tokens with device_id
            device_count = conn.execute(
                select(func.count())
                .select_from(provision_tokens)
                .where(provision_tokens.c.uid == uid)
                .where(provision_tokens.c.consumed_by_device_id.isnot(None))
            ).scalar() or 0

            # QR codes generated
            qr_count = conn.execute(
                select(func.count())
                .select_from(qr_issuance_audit)
                .where(qr_issuance_audit.c.user_uid == uid)
            ).scalar() or 0

        return {
            "active_devices": device_count,
            "qr_codes_generated": qr_count,
        }
```

Note: `func` is already imported at `orgdb.py:37` — no additional import needed.

**Step 4: Add API route**

Add to `src/backend/main.py` after the `api_user_devices` route:

```python
@app.get("/api/users/{uid}/stats")
def api_user_stats(uid: str, claims: Dict[str, Any] = Depends(require_user)):
    """Per-user aggregate stats (device count, QR count)."""
    user = get_user(uid)
    if not user:
        raise HTTPException(404, "User not found")

    stats = ORGDB.get_user_stats(uid)
    return {"ok": True, "uid": uid, **stats}
```

**Step 5: Run test to verify it passes**

Run: `just test-quick -- -k test_user_stats_fresh_user -v`
Expected: PASS

**Step 6: Add frontend query**

Create `src/frontend/src/lib/queries/user-stats.ts`:

```typescript
/**
 * TanStack Query options for per-user stats.
 * - GET /api/users/{uid}/stats
 */
import { queryOptions } from '@tanstack/react-query';
import { getApi } from '../api-client';
import { queryKeys } from './keys';

export interface UserStats {
  active_devices: number;
  qr_codes_generated: number;
}

export const userStatsQueryOptions = (uid: string) =>
  queryOptions({
    queryKey: queryKeys.userStats(uid),
    queryFn: () => getApi().get<{ ok: true; uid: string } & UserStats>(`/users/${uid}/stats`),
    staleTime: 30_000,
    enabled: !!uid,
  });
```

Add to `src/frontend/src/lib/queries/keys.ts`:

```typescript
  userStats: (uid: string) => ['users', uid, 'stats'] as const,
```

**Step 7: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py src/frontend/src/lib/queries/user-stats.ts src/frontend/src/lib/queries/keys.ts tests/test_provisioning.py
git commit -m "feat(api): add GET /api/users/{uid}/stats endpoint"
```

---

## Wave 3: Frontend — Tabbed Layout + Overview Tab

### Task 6: Refactor UserDetailPanel into tabbed layout

**Files:**
- Modify: `src/frontend/src/components/features/user-management/UserDetailPanel.tsx` (major refactor)

This is the core structural change. The current single-scroll layout becomes:
1. **Header** (avatar, name, email+phone, badges, action buttons)
2. **Tabs** (Overview | Devices | Provisioning History | Activity)
3. **Tab content panels**

**Step 1: Refactor PanelHeader**

Replace the `PanelHeader` function (lines 74-116) to match the design — larger avatar, phone next to email, status/org/employee badges, all 3 action buttons:

```tsx
/** Panel header: avatar, name, contact, badges, actions (matches use-details.html) */
function PanelHeader({
  user,
  groups,
  onGenerateQR,
  onEditUser,
  onTerminate,
}: {
  user: User;
  groups: { cn: string; dn: string }[];
  onGenerateQR: () => void;
  onEditUser: () => void;
  onTerminate: () => void;
}) {
  const displayName = user.displayName || user.uid;
  const orgName = user.orgDn ? getOrgName(user.orgDn) : '';

  return (
    <div className="px-6 py-5 border-b border-[var(--color-border-subtle)] bg-[var(--color-bg-tertiary)]">
      <div className="flex items-start justify-between">
        <div className="flex gap-5">
          {/* Larger avatar */}
          <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-purple-500)] text-[28px] font-semibold text-white">
            {getInitials(displayName)}
          </div>
          <div className="min-w-0">
            <h2 className="text-2xl font-semibold text-[var(--color-text-primary)]">
              {displayName}
            </h2>
            <p className="text-sm text-[var(--color-text-muted)] mb-2">
              {user.mail}
              {user.mobile ? ` · ${user.mobile}` : ''}
            </p>
            <div className="flex gap-2 flex-wrap">
              <StatusBadge status={user.accountStatus} />
              {orgName && <Badge variant="info">{orgName}</Badge>}
              {user.employeeNumber && (
                <Badge variant="muted">{user.employeeNumber}</Badge>
              )}
            </div>
          </div>
        </div>
        <div className="flex gap-2 shrink-0">
          <Button
            variant="secondary"
            size="sm"
            leftIcon={<Edit className="h-3.5 w-3.5" />}
            onClick={onEditUser}
          >
            Edit User
          </Button>
          <Button
            size="sm"
            leftIcon={<QrCode className="h-3.5 w-3.5" />}
            onClick={onGenerateQR}
          >
            Generate QR
          </Button>
          <Button
            variant="danger"
            size="sm"
            leftIcon={<Ban className="h-3.5 w-3.5" />}
            onClick={onTerminate}
          >
            Terminate
          </Button>
        </div>
      </div>
    </div>
  );
}
```

**Step 2: Replace UserDetailContent with tabbed layout**

Replace the `UserDetailContent` function (lines 37-72) to use the `Tabs` primitive:

```tsx
function UserDetailContent({
  userId,
  onGenerateQR,
  onTerminate,
  onEditUser,
}: UserDetailPanelProps) {
  const { data: userData } = useSuspenseQuery(userQueryOptions(userId));
  const { data: groupsData } = useSuspenseQuery(userGroupsQueryOptions(userId));
  const [activeTab, setActiveTab] = useState<string>('overview');

  const user = userData.user;
  const groups = groupsData?.groups || [];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PanelHeader
        user={user}
        groups={groups}
        onGenerateQR={() => onGenerateQR(user.uid)}
        onEditUser={() => onEditUser(user.uid)}
        onTerminate={() => onTerminate(user.uid)}
      />

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as string)}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="devices">Devices</TabsTrigger>
          <TabsTrigger value="provisioning">Provisioning History</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
        </TabsList>

        <div className="flex-1 overflow-y-auto">
          <TabsContent value="overview" className="p-6">
            <OverviewTab user={user} groups={groups} />
          </TabsContent>
          <TabsContent value="devices" className="p-6">
            <DevicesTab uid={user.uid} />
          </TabsContent>
          <TabsContent value="provisioning" className="p-6">
            <ProvisioningHistoryTab uid={user.uid} />
          </TabsContent>
          <TabsContent value="activity" className="p-6">
            <ActivityTab />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
```

**Step 3: Update imports**

Add to UserDetailPanel.tsx imports:

```tsx
import { useState } from 'react';
import { QrCode, Edit, Ban, Building2 } from 'lucide-react';
import { Button, Badge, Tabs, TabsList, TabsTrigger, TabsContent, Skeleton } from '@azblink/ui';
import { StatusBadge } from './StatusBadge';
```

**Step 4: Update UserDetailPanelProps**

```tsx
interface UserDetailPanelProps {
  userId: string;
  onGenerateQR: (uid: string) => void;
  onTerminate: (uid: string) => void;
  onEditUser: (uid: string) => void;
}
```

**Step 5: Add stub tab components**

Add placeholder tab components at the bottom of the file (these will be fleshed out in subsequent tasks):

```tsx
/** Overview tab — stats + user info + org & groups cards */
function OverviewTab({ user, groups }: { user: User; groups: { cn: string; dn: string }[] }) {
  return (
    <div className="space-y-6">
      <p className="text-sm text-[var(--color-text-muted)]">Overview tab — coming in Task 7</p>
    </div>
  );
}

/** Devices tab — per-user provisioned devices */
function DevicesTab({ uid }: { uid: string }) {
  return (
    <div className="space-y-4">
      <p className="text-sm text-[var(--color-text-muted)]">Devices tab — coming in Task 9</p>
    </div>
  );
}

/** Provisioning History tab — timeline of QR events */
function ProvisioningHistoryTab({ uid }: { uid: string }) {
  return (
    <div className="space-y-4">
      <p className="text-sm text-[var(--color-text-muted)]">Provisioning History — coming in Task 8</p>
    </div>
  );
}

/** Activity tab — placeholder until backend supports activity events */
function ActivityTab() {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-[var(--color-text-muted)]">
      <p className="text-sm">Activity tracking is not yet available.</p>
      <p className="text-xs mt-1">XMPP, SIP, and SSO session events will appear here.</p>
    </div>
  );
}
```

**Step 6: Wire `onEditUser` through UserManagementPage**

In `src/frontend/src/components/features/user-management/UserManagementPage.tsx`:

Add a `handleEditUser` callback alongside the existing `handleGenerateQR` and `handleTerminate` (~line 114):

```tsx
  const handleEditUser = useCallback(
    (uid: string) => {
      // TODO: Wire to modal.openEdit(uid) in Task 10
      console.log('[UserManagement] Edit user:', uid);
    },
    [],
  );
```

Then update the `<UserDetailPanel>` usage (~line 161-165) to pass the new prop:

```tsx
            <UserDetailPanel
              userId={userId}
              onGenerateQR={handleGenerateQR}
              onTerminate={handleTerminate}
              onEditUser={handleEditUser}
            />
```

**Step 7: Commit**

```bash
git add src/frontend/src/components/features/user-management/UserDetailPanel.tsx \
        src/frontend/src/components/features/user-management/UserManagementPage.tsx
git commit -m "feat(ui): refactor UserDetailPanel into tabbed layout"
```

---

### Task 7: Build Overview tab (stats + summary cards)

**Files:**
- Modify: `src/frontend/src/components/features/user-management/UserDetailPanel.tsx` (replace OverviewTab stub)

**Step 1: Replace the OverviewTab stub**

The Overview tab has 3 sections matching `use-details.html`:
1. Stats grid (4 cards): Active Devices, QR Codes Generated, Days Since Onboard, Last Activity
2. User Information card (Full Name, Email, Phone, Job Title, Manager, Employee ID)
3. Organization & Groups card (Organization, DN, Groups, Profile, Created)

```tsx
function OverviewTab({ user, groups }: { user: User; groups: { cn: string; dn: string }[] }) {
  const { data: statsData } = useQuery(userStatsQueryOptions(user.uid));
  const navigate = useNavigate();

  const orgName = user.orgDn ? getOrgName(user.orgDn) : '—';
  const managerName = user.managerDisplayName || (user.manager ? user.manager : '—');
  const createdDate = user.createdAt
    ? new Date(user.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    : '—';

  // Days since onboard
  const daysSinceOnboard = user.createdAt
    ? Math.floor((Date.now() - new Date(user.createdAt).getTime()) / 86_400_000)
    : null;

  return (
    <div className="space-y-6">
      {/* Stats grid */}
      <div className="grid grid-cols-4 gap-4">
        <StatCard
          icon={Smartphone}
          label="Active Devices"
          value={statsData?.active_devices ?? '—'}
          iconColor="text-[var(--color-primary)]"
          iconBg="bg-[var(--color-primary-bg,rgba(59,130,246,0.1))]"
        />
        <StatCard
          icon={QrCode}
          label="QR Codes Generated"
          value={statsData?.qr_codes_generated ?? '—'}
          iconColor="text-[var(--color-purple-500)]"
          iconBg="bg-[rgba(168,85,247,0.1)]"
        />
        <StatCard
          icon={CalendarDays}
          label="Days Since Onboard"
          value={daysSinceOnboard ?? '—'}
          iconColor="text-[var(--color-success)]"
          iconBg="bg-[rgba(34,197,94,0.1)]"
        />
        <StatCard
          icon={Activity}
          label="Last Activity"
          value="—"
          iconColor="text-[var(--color-warning)]"
          iconBg="bg-[rgba(245,158,11,0.1)]"
        />
      </div>

      {/* Two-column summary cards */}
      <div className="grid grid-cols-2 gap-6">
        {/* User Information */}
        <div>
          <h3 className="text-sm font-semibold mb-3 text-[var(--color-text-primary)]">
            User Information
          </h3>
          <div className="rounded-lg bg-[var(--color-bg-tertiary)] p-5 space-y-0">
            <SummaryRow label="Full Name" value={user.displayName || user.uid} />
            <SummaryRow label="Email" value={user.mail || '—'} />
            <SummaryRow label="Phone" value={user.mobile || '—'} />
            <SummaryRow label="Job Title" value={user.title || '—'} />
            <SummaryRow label="Manager" value={managerName} />
            <SummaryRow label="Employee ID" value={user.employeeNumber || '—'} mono />
          </div>
        </div>

        {/* Organization & Groups */}
        <div>
          <h3 className="text-sm font-semibold mb-3 text-[var(--color-text-primary)]">
            Organization & Groups
          </h3>
          <div className="rounded-lg bg-[var(--color-bg-tertiary)] p-5 space-y-0">
            <SummaryRow
              label="Organization"
              value={
                user.orgDn ? (
                  <button
                    type="button"
                    className="text-sm font-medium text-[var(--color-primary)] hover:underline"
                    onClick={() => navigate({ to: '/directory/orgs', search: { orgId: user.orgDn } })}
                  >
                    {orgName}
                  </button>
                ) : '—'
              }
            />
            <SummaryRow label="DN" value={user.dn} mono small />
            <SummaryRow
              label="Groups"
              value={
                groups.length > 0 ? (
                  <div className="flex gap-1 flex-wrap">
                    {groups.map((g) => (
                      <Badge key={g.dn} variant="muted">{g.cn}</Badge>
                    ))}
                  </div>
                ) : '—'
              }
            />
            <SummaryRow label="Created" value={createdDate} />
          </div>
        </div>
      </div>
    </div>
  );
}

/** Key-value row for summary cards */
function SummaryRow({
  label,
  value,
  mono = false,
  small = false,
}: {
  label: string;
  value: React.ReactNode;
  mono?: boolean;
  small?: boolean;
}) {
  return (
    <div className="flex justify-between py-2">
      <span className="text-xs text-[var(--color-text-muted)]">{label}</span>
      <span
        className={cn(
          'text-xs font-medium text-[var(--color-text-primary)]',
          mono && 'font-mono',
          small && 'text-[11px]',
        )}
      >
        {value}
      </span>
    </div>
  );
}
```

**Step 2: Add required imports to UserDetailPanel.tsx**

```tsx
import { useQuery } from '@tanstack/react-query';
import { Smartphone, CalendarDays, Activity, Ban } from 'lucide-react';
import { cn } from '@azblink/ui';
import { StatCard } from '../stat-card';
import { userStatsQueryOptions } from '@/lib/queries/user-stats';
```

**Step 3: Verify in browser**

Run: open `http://localhost:8081/` → select a user → verify Overview tab renders stats + two summary cards.

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/user-management/UserDetailPanel.tsx
git commit -m "feat(ui): build Overview tab with stats grid and summary cards"
```

---

### Task 8: Build Provisioning History tab (timeline)

**Files:**
- Modify: `src/frontend/src/components/features/user-management/UserDetailPanel.tsx` (replace ProvisioningHistoryTab stub)

**Step 1: Replace the ProvisioningHistoryTab stub**

The timeline matches the design in `use-details.html` lines 505-551. Each QR event shows:
- Status dot (green=consumed/generated, amber=expired, red=revoked)
- Title: "QR-{id} {status}"
- Timestamp
- Description: device info + issued_by

```tsx
function ProvisioningHistoryTab({ uid }: { uid: string }) {
  const { data, isLoading, isError } = useQuery(userQRHistoryQueryOptions(uid));
  const history = data?.history ?? [];

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (isError) {
    return <p className="text-sm text-[var(--color-danger)]">Failed to load provisioning history.</p>;
  }

  if (history.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-[var(--color-text-muted)]">
        <p className="text-sm">No provisioning history yet.</p>
      </div>
    );
  }

  return (
    <div>
      <h3 className="text-sm font-semibold mb-4 text-[var(--color-text-primary)]">
        QR Code History
      </h3>
      <div className="relative pl-6">
        {/* Timeline line */}
        <div className="absolute left-[7px] top-0 bottom-0 w-0.5 bg-[var(--color-border-subtle)]" />

        {history.map((item, i) => {
          const dotColor = getDotColor(item.status);
          const title = `QR-${String(item.id).padStart(4, '0')} ${item.status}`;
          const time = item.issued_at
            ? new Date(item.issued_at).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })
            : '—';

          const desc = [
            item.device_info ? `Device: ${item.device_info}` : null,
            item.issued_by && item.issued_by !== 'system'
              ? `Generated by ${item.issued_by}`
              : null,
          ]
            .filter(Boolean)
            .join(' · ');

          return (
            <div
              key={item.id}
              className={cn('relative pb-6', i === history.length - 1 && 'pb-0')}
            >
              {/* Dot */}
              <div
                className="absolute -left-6 w-4 h-4 rounded-full border-2"
                style={{
                  backgroundColor: dotColor,
                  borderColor: dotColor,
                }}
              />
              {/* Content card */}
              <div className="rounded-lg bg-[var(--color-bg-tertiary)] px-4 py-3">
                <div className="flex justify-between items-start mb-1">
                  <span className="text-sm font-medium text-[var(--color-text-primary)]">
                    {title}
                  </span>
                  <span className="text-xs text-[var(--color-text-muted)] shrink-0 ml-4">
                    {time}
                  </span>
                </div>
                {desc && (
                  <p className="text-xs text-[var(--color-text-muted)]">{desc}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/** Map QR status to timeline dot color */
function getDotColor(status: string): string {
  switch (status) {
    case 'consumed':
      return 'var(--color-success)';
    case 'expired':
      return 'var(--color-warning)';
    case 'revoked':
      return 'var(--color-danger)';
    default:
      return 'var(--color-border-default)';
  }
}
```

**Step 2: Add explicit import for `userQRHistoryQueryOptions`**

`userQRHistoryQueryOptions` is exported from `@/lib/queries/users` but is NOT re-exported through any barrel. Add this import to the top of `UserDetailPanel.tsx`:

```tsx
import { userQRHistoryQueryOptions } from '@/lib/queries/users';
```

The old `QRHistory.tsx` component imported it directly — now that the timeline lives inside `UserDetailPanel.tsx`, the import must be added here.

**Step 3: Verify in browser**

Navigate to user detail → Provisioning History tab → verify timeline renders.

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/user-management/UserDetailPanel.tsx
git commit -m "feat(ui): build Provisioning History timeline tab"
```

---

### Task 9: Build Devices tab

**Files:**
- Modify: `src/frontend/src/components/features/user-management/UserDetailPanel.tsx` (replace DevicesTab stub)

**Step 1: Replace the DevicesTab stub**

```tsx
function DevicesTab({ uid }: { uid: string }) {
  const { data, isLoading, isError } = useQuery(userDevicesQueryOptions(uid));
  const devices = data?.devices ?? [];

  if (isLoading) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 2 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (isError) {
    return <p className="text-sm text-[var(--color-danger)]">Failed to load devices.</p>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">
          Registered Devices
        </h3>
      </div>

      {devices.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-[var(--color-text-muted)]">
          <Smartphone className="h-10 w-10 mb-3 opacity-30" />
          <p className="text-sm">No devices provisioned yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {devices.map((device) => (
            <div
              key={device.device_id}
              className="flex items-center gap-4 p-4 rounded-lg bg-[var(--color-bg-tertiary)] border border-[var(--color-border-subtle)]"
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-[var(--color-bg-elevated)]">
                <Smartphone className="h-6 w-6 text-[var(--color-text-muted)]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-[var(--color-text-primary)]">
                  {device.platform || 'Unknown'} Device
                </p>
                <p className="text-xs text-[var(--color-text-muted)] truncate">
                  {[
                    device.platform,
                    device.client_version ? `v${device.client_version}` : null,
                    `ID: ${device.device_id.slice(0, 8)}`,
                  ]
                    .filter(Boolean)
                    .join(' · ')}
                </p>
              </div>
              <div className="text-right shrink-0">
                <Badge variant={device.status === 'consumed' ? 'success' : 'muted'}>
                  {device.status === 'consumed' ? 'Provisioned' : device.status}
                </Badge>
                {device.consumed_at && (
                  <p className="text-[11px] text-[var(--color-text-muted)] mt-1">
                    {new Date(device.consumed_at).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
```

**Step 2: Add import**

```tsx
import { userDevicesQueryOptions } from '@/lib/queries/user-devices';
```

**Step 3: Verify in browser**

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/user-management/UserDetailPanel.tsx
git commit -m "feat(ui): build Devices tab with provisioned device cards"
```

---

## Wave 4: Frontend — Edit User + Cleanup

### Task 10: Wire Edit User modal

**Files:**
- Modify: `src/frontend/src/components/features/user-management/useModalState.ts` (add edit_user state)
- Modify: `src/frontend/src/components/features/user-management/UserManagementPage.tsx` (add EditUserModal)
- Create: `src/frontend/src/components/features/user-management/modals/EditUserModal.tsx`
- Create: `src/frontend/src/lib/queries/user-mutations.ts` (useUpdateUser hook)

**Step 1: Add `edit_user` to modal state machine**

In `useModalState.ts`, add `'edit_user'` to `ModalKind`:

```typescript
type ModalKind = 'closed' | 'qr_generation' | 'termination_confirm' | 'termination_success' | 'add_user' | 'edit_user';
```

Add `OPEN_EDIT` action type and handler:

```typescript
// In reducer:
case 'OPEN_EDIT':
  return { kind: 'edit_user', targetUid: action.uid };
```

Add `openEdit` helper to returned object:

```typescript
const openEdit = useCallback((uid: string) => dispatch({ type: 'OPEN_EDIT', uid }), []);
```

**Step 2: Create EditUserModal**

Create `src/frontend/src/components/features/user-management/modals/EditUserModal.tsx`:

```tsx
/**
 * Edit User Modal — updates displayName, mail, mobile via PATCH /api/users/{uid}.
 * - Pre-populates fields from current user data
 * - Validates non-empty displayName
 * - Invalidates user query on success
 */
import { useState, useEffect, type FormEvent } from 'react';
import { Loader2 } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, DialogClose, DialogFooter,
  Button, Label, Input,
} from '@azblink/ui';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { userQueryOptions } from '@/lib/queries/users';
import { useUpdateUser } from '@/lib/queries/user-mutations';
import { queryKeys } from '@/lib/queries/keys';

interface EditUserModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  uid: string;
}

export function EditUserModal({ open, onOpenChange, uid }: EditUserModalProps) {
  // useQuery (not useSuspenseQuery) — modal may open before cache is warm,
  // and useSuspenseQuery inside a Dialog would throw without a Suspense boundary.
  const { data, isLoading } = useQuery(userQueryOptions(uid));
  const user = data?.user;
  const updateUser = useUpdateUser();
  const queryClient = useQueryClient();

  const [displayName, setDisplayName] = useState('');
  const [mail, setMail] = useState('');
  const [mobile, setMobile] = useState('');

  // Sync form when user data loads/changes
  useEffect(() => {
    if (user) {
      setDisplayName(user.displayName);
      setMail(user.mail);
      setMobile(user.mobile);
    }
  }, [user]);

  // Loading guard — render spinner while data loads
  if (isLoading || !user) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent size="md">
          <DialogClose />
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-[var(--color-text-muted)]" />
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const handleOpenChange = (next: boolean) => {
    if (!next) updateUser.reset();
    onOpenChange(next);
  };

  const canSubmit = displayName.trim().length > 0 && !updateUser.isPending;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    updateUser.mutate(
      { uid, updates: { displayName: displayName.trim(), mail: mail.trim(), mobile: mobile.trim() } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: queryKeys.user(uid) });
          handleOpenChange(false);
        },
      },
    );
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent size="md">
        <DialogClose />
        <DialogHeader>
          <DialogTitle>Edit User</DialogTitle>
          <DialogDescription>Update details for {user.displayName || uid}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="px-6 py-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-displayName">Display Name *</Label>
              <Input id="edit-displayName" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-mail">Email</Label>
              <Input id="edit-mail" type="email" value={mail} onChange={(e) => setMail(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-mobile">Mobile</Label>
              <Input id="edit-mobile" value={mobile} onChange={(e) => setMobile(e.target.value)} />
            </div>
            {updateUser.isError && (
              <p role="alert" className="text-xs text-[var(--color-danger)]">
                {updateUser.error?.message || 'Update failed'}
              </p>
            )}
          </div>
          <DialogFooter>
            <Button type="button" variant="secondary" onClick={() => handleOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={!canSubmit}>
              {updateUser.isPending ? (
                <><Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" />Saving...</>
              ) : 'Save Changes'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
```

**Step 3: Create useUpdateUser mutation hook**

Create `src/frontend/src/lib/queries/user-mutations.ts`:

```typescript
/**
 * Mutation hooks for user write operations.
 * - useUpdateUser: PATCH /api/users/{uid}
 */
import { useMutation } from '@tanstack/react-query';
import { getApi } from '../api-client';
import type { UserUpdateRequest } from '@/types';

export function useUpdateUser() {
  return useMutation({
    mutationFn: ({ uid, updates }: { uid: string; updates: UserUpdateRequest }) =>
      getApi().patch<{ ok: true; modified: string[] }>(`/users/${uid}`, updates),
  });
}
```

**Step 4: Wire in UserManagementPage**

Pass `onEditUser` through and add `EditUserModal` alongside the other modals.

**Step 5: Commit**

```bash
git add src/frontend/src/components/features/user-management/modals/EditUserModal.tsx \
        src/frontend/src/lib/queries/user-mutations.ts \
        src/frontend/src/components/features/user-management/useModalState.ts \
        src/frontend/src/components/features/user-management/UserManagementPage.tsx \
        src/frontend/src/components/features/user-management/UserDetailPanel.tsx
git commit -m "feat(ui): wire Edit User modal with PATCH /api/users/{uid}"
```

---

### Task 11: Remove dead code (old QRHistory, DangerZone imports)

**Files:**
- Modify: `src/frontend/src/components/features/user-management/UserDetailPanel.tsx`

The old `QRHistory.tsx` and `DangerZone.tsx` components are no longer imported by UserDetailPanel (their functionality is now in the Provisioning History tab and the header Terminate button). Clean up:

**Step 1:** Remove unused imports of `QRHistory`, `DangerZone`, `ProvisioningStatus` from `UserDetailPanel.tsx`

**Step 2:** Verify QRHistory.tsx and DangerZone.tsx are not imported elsewhere. If not, leave them in place (may be useful for other contexts) but add a deprecation comment.

**Step 3:** Fix the `text-[var(--text-xs)]` bug in `QRHistory.tsx:63` — should be `text-xs`

**Step 4:** Fix the same `text-[var(--text-xs)]` bug in `src/frontend/src/components/features/stat-card.tsx` at lines 49 and 53 — should also be `text-xs`

**Step 5: Commit**

```bash
git add src/frontend/src/components/features/user-management/UserDetailPanel.tsx \
        src/frontend/src/components/features/user-management/QRHistory.tsx \
        src/frontend/src/components/features/stat-card.tsx
git commit -m "refactor(ui): remove dead imports, fix text-xs token bugs in QRHistory and StatCard"
```

---

### Task 12: Run full test suite and verify

**Step 1: Run backend tests**

```bash
just test
```

Expected: All tests pass including new TestQRHistory, TestUserDevices, TestUserStats, TestUserDetail tests.

**Step 2: Verify frontend in browser**

- Navigate to User Management → select a user
- Verify Header: avatar, name, email + phone, badges (Active, org, employee ID), Edit/Generate QR/Terminate buttons
- Verify Overview tab: 4 stat cards, User Information card, Organization & Groups card
- Verify Devices tab: list or empty state
- Verify Provisioning History tab: timeline or empty state
- Verify Activity tab: placeholder message
- Verify Edit User modal opens and saves
- Verify Terminate still works from header button

**Step 3: Final commit**

```bash
git commit -m "chore: verify user detail migration — all tabs functional"
```

---

## Deferred — Follow-Up Items

These items were explicitly deferred from the User Detail Panel migration. Each requires prerequisite work before it can be implemented. They are grouped by the backend capability they depend on.

---

### D1: Activity Tab — Real Event Data

**Current state:** Placeholder tab with message "Activity tracking is not yet available. XMPP, SIP, and SSO session events will appear here." (implemented in Task 6)

**What's needed:**
- Backend event pipeline that captures UC session events (XMPP login/logout, SIP registration, call activity)
- If Authentik is deployed: SSO session events (OIDC token issuance, session creation/revocation)
- A unified `user_activity_events` table (or similar) with columns: `event_type`, `timestamp`, `source` (xmpp/sip/sso), `details` (JSON), `user_uid`
- `GET /api/users/{uid}/activity` endpoint with pagination and filtering
- Frontend: replace ActivityTab stub with timeline component (reuse ProvisioningHistoryTab pattern)

**Dependencies:**
- UC event logging infrastructure (XMPP server hooks, SIP registrar hooks)
- Optional: Authentik webhook integration for SSO events
- Event schema design decision

**Priority:** Medium — valuable for admin visibility but not blocking any workflows
**Scope:** Separate epic (backend event pipeline + frontend tab)

---

### D2: "Last Activity" Stat — Real Data

**Current state:** StatCard displays "—" hardcoded (implemented in Task 7 OverviewTab)

**What's needed:**
- Same event pipeline as D1 above
- `GET /api/users/{uid}/stats` endpoint extended with `last_activity_at: string | null`
- Frontend: replace hardcoded "—" with formatted timestamp from stats response

**Dependencies:** D1 (Activity event pipeline)
**Priority:** Low — cosmetic improvement, blocked by D1
**Scope:** Small (1 backend query addition + 1 frontend line change) once D1 exists

---

### D3: Device Online/Offline Status

**Current state:** Devices tab shows provisioned devices with "Provisioned" badge (Task 9). No live status.

**What's needed:**
- Device heartbeat/session system — devices report liveness via periodic ping or WebSocket
- `device_sessions` table tracking last seen timestamp, connection state
- `GET /api/users/{uid}/devices` extended with `is_online: boolean`, `last_seen: string | null`
- Frontend: green/gray dot indicator on device cards, "Last seen 5m ago" text

**Dependencies:**
- Device heartbeat protocol (requires client app changes)
- Session tracking infrastructure (Redis or DB-backed)

**Priority:** Medium-High — high admin value, but requires client-side cooperation
**Scope:** Medium epic (protocol design + backend + frontend)

---

### D4: Device Refresh/Revoke Actions

**Current state:** Device cards are read-only (Task 9). No action buttons.

**What's needed:**
- `POST /api/users/{uid}/devices/{device_id}/revoke` endpoint — invalidates the provision token, marks device as revoked
- `POST /api/users/{uid}/devices/{device_id}/refresh` endpoint — re-issues QR/token for an existing device
- Frontend: "Revoke" danger button and "Refresh" secondary button on each device card
- Confirmation dialog for revoke action

**Dependencies:**
- Backend specification for revoke semantics (what happens to active sessions?)
- Decision on refresh flow (new QR? silent re-provision?)

**Priority:** Medium — important for security (revoking lost devices)
**Scope:** Small-medium (2 endpoints + frontend buttons + confirmation dialog)

---

### D5: Provisioning Profile Name in Overview

**Current state:** Overview tab shows Organization name but not the provisioning profile assigned to the user.

**What's needed:**
- Determine how users map to profiles: is it per-user, per-org, or per-group?
- If per-org: extend `GET /api/users/{uid}` to include `profileName` by looking up the org's default profile
- If per-user: add `profile_id` to the user record
- Frontend: add "Provisioning Profile" row to the Organization & Groups summary card

**Dependencies:**
- Product decision on org→profile mapping model
- May require schema changes if per-user assignment is chosen

**Priority:** Low — informational display only
**Scope:** Small once mapping model is decided

---

### D6: "Add Device" Button

**Current state:** Devices tab has no "Add Device" button.

**What's needed:**
- UX decision: does "Add Device" trigger a new QR generation flow? Or is it a different workflow?
- If QR-based: button could open the existing QR generation modal with a pre-selected "device provisioning" mode
- If manual: new flow for entering device details directly

**Dependencies:**
- Product decision on the device onboarding UX
- Possible overlap with the existing QR generation flow

**Priority:** Low — current workaround is "Generate QR" button in header
**Scope:** Depends on product decision (could be trivial redirect or new flow)

---

## Summary

| Wave | Tasks | Backend | Frontend | Est. Time |
|------|-------|---------|----------|-----------|
| 1 | Tasks 1-3 | QR issued_by, createTimestamp, manager resolve | Type updates | ~2 hours |
| 2 | Tasks 4-5 | Devices + Stats endpoints | Query + type files | ~2 hours |
| 3 | Tasks 6-9 | — | Tabbed layout, Overview, Timeline, Devices | ~4 hours |
| 4 | Tasks 10-12 | — | Edit modal, cleanup, verify | ~2 hours |
| **Total** | **12 tasks** | **5 backend changes** | **7 frontend changes** | **~10 hours** |
