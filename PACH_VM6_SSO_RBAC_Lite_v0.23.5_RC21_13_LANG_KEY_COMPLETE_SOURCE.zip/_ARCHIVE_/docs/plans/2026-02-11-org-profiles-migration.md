# Org Profiles — Migration Design Doc

Date: 2026-02-11
Status: Approved
Spec: `new-migration-ui/ORG_PROFILES_MIGRATION_SPEC.md`
Prototype: `new-migration-ui/org-profiles-content-only.html`
Workflow: `.cursor/rules/split-panel-migration-workflow.mdc`

---

## Summary

Card-based master-detail page for managing reusable provisioning configurations ("Org Profiles"). Each profile bundles XMPP, SIP, SSO, and QR settings that can be assigned to organizations. Lives under a new "Configuration" sidebar category.

**Key architectural decisions:**
- **Sidebar:** New "Configuration" category before Account, containing Org Profiles + Settings (moved from Account)
- **Routes:** `/configuration/org-profiles`, `/configuration/settings` (nested, consistent with `/directory/*`)
- **Storage:** PostgreSQL only — profiles are configuration data, not identity. No LDAP involvement.
- **Import/Export:** Deferred. CRUD first.

---

## Sidebar Navigation (Updated)

```
Overview
  └── Dashboard

Directory
  ├── Users
  ├── Groups
  └── Organizations

Provisioning
  ├── QR Codes
  └── Provisioning Ops

Security
  └── Audit Log

Configuration          ← NEW
  ├── Org Profiles     ← NEW — /configuration/org-profiles
  └── Settings         ← MOVED from Account — /configuration/settings

Account
  └── My Profile
```

Redirect route at old `/settings` path for backward compatibility.

---

## Database Schema

PostgreSQL only. Three new tables.

```sql
CREATE TABLE org_profiles (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name          VARCHAR(255) NOT NULL UNIQUE,
    description   TEXT NOT NULL DEFAULT '',
    type          VARCHAR(20) NOT NULL DEFAULT 'custom',  -- 'default' | 'custom'
    status        VARCHAR(20) NOT NULL DEFAULT 'draft',   -- 'active' | 'draft' | 'archived'
    xmpp_config   JSONB NOT NULL DEFAULT '{"enabled":false}',
    sip_config    JSONB NOT NULL DEFAULT '{"enabled":false}',
    sso_config    JSONB NOT NULL DEFAULT '{"enabled":false}',
    qr_settings   JSONB NOT NULL DEFAULT '{}',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by    VARCHAR(255),
    updated_by    VARCHAR(255)
);

-- Only one profile can be the default
CREATE UNIQUE INDEX idx_org_profiles_default
    ON org_profiles (type) WHERE type = 'default';

-- Org-to-profile assignment (many orgs → one profile)
CREATE TABLE org_profile_assignments (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id    UUID NOT NULL REFERENCES org_profiles(id) ON DELETE CASCADE,
    org_dn        VARCHAR(512) NOT NULL UNIQUE,
    assigned_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by   VARCHAR(255)
);

-- Change history (append-only)
CREATE TABLE org_profile_history (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id    UUID NOT NULL REFERENCES org_profiles(id) ON DELETE CASCADE,
    timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    actor         VARCHAR(255) NOT NULL,
    description   TEXT NOT NULL,
    field         VARCHAR(255),
    old_value     TEXT,
    new_value     TEXT
);

CREATE INDEX idx_org_profile_history_profile
    ON org_profile_history(profile_id, timestamp DESC);
```

**Design choices:**
- JSONB for config sections — evolve schema without ALTER TABLE, validate in Python/TypeScript
- Unique partial index on `type='default'` — only one default profile, DB-enforced
- `org_dn` UNIQUE in assignments — one org → one profile at a time
- Separate history table — append-only, no bloat on profile reads
- CASCADE on delete — removes assignments and history. UI confirms with affected org list.

---

## API Endpoints

Seven endpoints. All `Depends(require_admin)`. All PostgreSQL-only.

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/profiles` | List all profiles (flattened flags + usage stats) |
| GET | `/api/profiles/{id}` | Profile detail (full config + assignments + history) |
| POST | `/api/profiles` | Create profile |
| PUT | `/api/profiles/{id}` | Update profile (full replace of config sections) |
| PATCH | `/api/profiles/{id}/toggle` | Toggle a config section on/off |
| POST | `/api/profiles/{id}/clone` | Clone profile ("Copy of X") |
| DELETE | `/api/profiles/{id}` | Delete profile (cascade) |

### Response Shapes

**List** — flattened for card rendering, no full config blobs:
```json
{
    "ok": true,
    "profiles": [{
        "id": "uuid",
        "name": "Standard Profile",
        "description": "...",
        "type": "default",
        "status": "active",
        "xmpp_enabled": true,
        "sip_enabled": true,
        "sso_enabled": true,
        "usage_stats": { "org_count": 4, "total_users": 189, "qrs_generated": 156 }
    }]
}
```

**Detail** — full config, assignments, history:
```json
{
    "ok": true,
    "profile": {
        "id": "uuid",
        "name": "...",
        "description": "...",
        "type": "default",
        "status": "active",
        "xmpp": { "enabled": true, "domain": "...", "websocketUrl": "...", "conferenceServer": "...", "resourceBinding": true },
        "sip": { "enabled": true, "domain": "...", "websocketUrl": "...", "transport": "wss", "srtpRequired": true },
        "sso": { "enabled": true, "provider": "...", "issuerUrl": "...", "clientId": "...", "scopes": "...", "pkceRequired": true },
        "qrSettings": { "defaultValidityMinutes": 60, "oneTimeUse": true, "autoEmailOnCreate": false, "deepLinkScheme": "azblink://" },
        "assignedOrgs": [{ "name": "Engineering", "dn": "ou=...", "userCount": 42 }],
        "history": [{ "timestamp": "...", "description": "...", "actor": "...", "field": "...", "oldValue": "...", "newValue": "..." }],
        "createdAt": "...",
        "updatedAt": "..."
    }
}
```

**Toggle request:** `{ "section": "xmpp", "enabled": false }`

**Notable decisions:**
- List returns flattened booleans, not full JSONB — cards only need flags + stats
- Toggle is a separate PATCH — narrow endpoint for optimistic updates
- Clone is server-side POST — handles name suffixing and history atomically
- No pagination — ~10s of profiles expected
- `usage_stats.total_users` computed via LDAP lookups on assigned org DNs (may need caching if slow)

---

## Frontend File Structure

```
src/frontend/src/
├── routes/configuration/
│   ├── org-profiles/
│   │   └── index.tsx                    # Route with validateSearch(?profile=)
│   └── settings/
│       └── index.tsx                    # MOVED from routes/settings/
│
├── components/features/org-profiles/
│   ├── OrgProfilesManagementPage.tsx    # Route-level orchestrator (grid shell)
│   ├── PageHeader.tsx                   # Title + "Create Profile" CTA
│   ├── ProfileList.tsx                  # Left panel: card list container
│   ├── ProfileCard.tsx                  # Individual profile card
│   ├── ProfileDetailPanel.tsx           # Right panel: header + tabs
│   ├── ConfigTab.tsx                    # Tab: 4 config sections with toggles
│   ├── ConfigSection.tsx               # Single config section (header + card)
│   ├── UsageTab.tsx                     # Tab: stats grid + assigned orgs list
│   ├── HistoryTab.tsx                   # Tab: change history entries
│   ├── profile-type-config.ts          # Icon/color/badge config per type+status
│   ├── useModalState.ts                # Page-scoped modal reducer
│   └── modals/
│       ├── CreateProfileModal.tsx       # Create + Edit (prefilled) modal
│       └── DeleteProfileModal.tsx       # Confirm delete with affected orgs
│
├── lib/queries/
│   ├── org-profiles.ts                  # queryOptions: list, detail
│   └── org-profiles-mutations.ts        # create, update, toggle, clone, delete
│
└── types/
    └── org-profiles.ts                  # All TS types (matches API contract)
```

**Differences from Users/Groups:**
- ProfileCard replaces table Row — card-based, not DataTable
- ConfigSection is new — compound of header (icon + title + toggle) + key-value card
- CreateProfileModal handles both create and edit via mode prop
- No relations management phase — org assignments are read-only in v1

**New primitives:**

| Candidate | Decision | Rationale |
|-----------|----------|-----------|
| CollapsibleSection | Promote to @azblink/ui in Phase 0 | Reusable in any multi-section form modal |
| ConfigCard + ConfigRow | Keep in feature dir | Only used here for now |
| ToggleSwitch | Use existing Toggle from @azblink/ui | Already exists |

---

## Phased Implementation Plan

### Phase 0 — Schema + Types + Primitives (~1.5h)
- SQL migration: `migrations/005_org_profiles.sql`
- TypeScript types: `src/frontend/src/types/org-profiles.ts`
- Query key constants: add to `src/frontend/src/lib/queries/keys.ts`
- CollapsibleSection primitive: `packages/azblink-ui/primitives/CollapsibleSection/`
- Sidebar update: add Configuration category, move Settings
- Route scaffolding: `routes/configuration/org-profiles/index.tsx` + settings redirect

### Phase 1 — Backend endpoints + card list shell (~2h)
- Backend: table auto-creation in `orgdb.py`
- Backend: 7 endpoints in `main.py`
- Backend: `orgdb.py` functions for profile CRUD + history
- Frontend: `OrgProfilesManagementPage.tsx` with grid shell
- Frontend: `ProfileList.tsx` + `ProfileCard.tsx` with selection
- Frontend: query hooks in `org-profiles.ts`
- Verify: cards render, selection updates URL param

### Phase 2 — Detail panel read-only (~1.5h)
- `ProfileDetailPanel.tsx` with header (icon, title, Clone/Edit as no-ops)
- `ConfigTab.tsx` with 4 `ConfigSection.tsx` instances
- `UsageTab.tsx` with stats grid + assigned orgs
- `HistoryTab.tsx` with change entries
- Tab switching
- Verify: selecting card shows detail, all 3 tabs render

### Phase 3 — Create + Edit + Delete modals (~2h)
- `CreateProfileModal.tsx` with CollapsibleSection
- Form validation (name required, unique)
- Create → close → toast → auto-select
- Edit mode: prefill from selected profile
- Clone: `POST /api/profiles/{id}/clone` → toast → select
- `DeleteProfileModal.tsx` with affected orgs warning
- Verify: full CRUD lifecycle

### Phase 4 — Toggle + optimistic updates (~1h)
- Wire toggles to `PATCH /api/profiles/{id}/toggle`
- Optimistic update with rollback on error
- Card feature flags update via invalidation
- History entry auto-created by backend
- Verify: toggles respond instantly, history updates

### Phase 5 — Polish (~1h)
- Responsive: 900px grid collapse, 600px stats stack
- `?profile=` URL param auto-selection on mount
- Settings redirect from `/settings`
- Keyboard: Escape closes modals
- `data-testid` attributes
- a11y: `aria-current`, `role="alert"`, `htmlFor`+`id`
- DRY audit

**Estimated total: ~9-10 hours**
Review after each phase. One commit per phase.

---

## Risk Register

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| `usage_stats.total_users` slow (LDAP lookups per org) | Medium | Cache in PG on assignment change. Or compute on detail view only. |
| Admin deletes default profile | Low | Backend returns 400. UI hides delete on default. |
| Settings route move breaks bookmarks | Low | Redirect route at `/settings`. Keep 2-3 releases. |
| `org_dn` references stale/deleted LDAP orgs | Medium | Validate on detail load. Flag stale assignments in UI. |
| Edit PUT clobbers fields not in form (e.g. qrSettings) | Medium | Merge-on-write: only update fields present in request body. |

## Blind Spots

- **Seed data:** Should migration include a default "Standard Profile"? Recommend yes.
- **Org user counts:** Need to audit `ldap_client.py` for org-scoped user count capability during Phase 1.
- **QRs Generated stat:** Requires join through `qr_tokens` → assignments. Data path not yet traced.
- **Edit form coverage:** Create modal doesn't show all fields (e.g. `qrSettings`). Edit needs a fuller form or section-by-section editing.

## Deliberately Excluded (YAGNI)

- Import/Export
- Profile versioning/rollback
- Profile inheritance
- Real-time WebSocket push
- Bulk org assignment
- RBAC (uses `require_admin` for now)
