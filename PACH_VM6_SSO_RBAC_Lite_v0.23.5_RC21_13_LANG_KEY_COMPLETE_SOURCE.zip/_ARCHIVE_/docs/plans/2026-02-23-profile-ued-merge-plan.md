# Profile-UED 1:1 Merge Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Merge `tenant_ldap_configs` into `config_templates` so each profile IS its UED integration point — one row, one concept.

**Architecture:** Inline all UED fields (url, key, discovery cache, counters) onto `config_templates`. Re-FK `sync_events` to `config_templates.id`. Drop `tenant_ldap_configs`. Update all backend code, frontend types/components, and tests.

**Tech Stack:** Python/FastAPI, SQLAlchemy Core, PostgreSQL, React/TypeScript, TanStack Query

**Pre-requisite:** This branch (`sip-xmpp-profile-provisioning`) must be rebased onto `main` first to pick up the self-discovery simplification (commit `bcece84`). Task 1 handles this.

---

### Task 1: Rebase onto main

**Files:** Git operations only

**Step 1: Rebase**

```bash
git fetch origin
git rebase origin/main
```

Resolve conflicts — main has simplified `tenant_ldap_configs` (no LDAP columns), this branch has the old full schema. Take main's simplified version as the base, then apply provisioning additions (counters, ued_config_id FK) on top.

Key conflict files:
- `src/backend/orgdb.py` — tenant_ldap_configs Table definition
- `src/backend/main.py` — TenantConfigCreateReq, TenantConfigUpdateReq, UED endpoints
- `src/backend/sync_worker.py` — _process_event
- `tests/test_ued_api.py`, `tests/test_ued_orgdb.py`, `tests/test_sync_worker.py`
- `migrations/012_*` — numbering conflict (both branches use 012)

**Step 2: Rename migration**

Rename `012_profile_ued_link.sql` → `013_profile_ued_link.sql` (main already has `012_ued_self_discovery.sql`).

**Step 3: Verify tests pass after rebase**

```bash
python -m pytest tests/ -v --tb=short
docker exec azblink-ued-sync /app/.venv/bin/python -m pytest tests/ --ignore=tests/integration -v --tb=short
```

**Step 4: Commit rebase resolution**

Rebase commits are auto-applied. Force-push if needed:
```bash
git push -f origin sip-xmpp-profile-provisioning
```

---

### Task 2: Write migration 014_profile_ued_merge.sql

**Files:**
- Create: `migrations/014_profile_ued_merge.sql`

**Step 1: Write the migration**

```sql
-- migrations/014_profile_ued_merge.sql
-- Merge tenant_ldap_configs into config_templates (1:1 profile = UED).
BEGIN;

-- 1. Add UED columns to config_templates
ALTER TABLE config_templates
    ADD COLUMN IF NOT EXISTS ued_api_url TEXT,
    ADD COLUMN IF NOT EXISTS ued_api_key_enc TEXT,
    ADD COLUMN IF NOT EXISTS ued_enabled BOOLEAN NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS discovered_schema_name TEXT,
    ADD COLUMN IF NOT EXISTS discovered_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS next_uid_number INTEGER NOT NULL DEFAULT 5000,
    ADD COLUMN IF NOT EXISTS uid_range_start INTEGER NOT NULL DEFAULT 5000,
    ADD COLUMN IF NOT EXISTS uid_range_end INTEGER NOT NULL DEFAULT 65533,
    ADD COLUMN IF NOT EXISTS next_extension INTEGER NOT NULL DEFAULT 6000,
    ADD COLUMN IF NOT EXISTS ext_range_start INTEGER NOT NULL DEFAULT 6000,
    ADD COLUMN IF NOT EXISTS ext_range_end INTEGER NOT NULL DEFAULT 6999,
    ADD COLUMN IF NOT EXISTS last_sync_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS last_error TEXT;

-- 2. Copy data from linked tenant_ldap_configs rows
UPDATE config_templates ct
SET
    ued_api_url = tlc.ued_api_url,
    ued_api_key_enc = tlc.ued_api_key_enc,
    ued_enabled = tlc.enabled,
    discovered_schema_name = tlc.discovered_schema_name,
    discovered_at = tlc.discovered_at,
    next_uid_number = tlc.next_uid_number,
    uid_range_start = tlc.uid_range_start,
    uid_range_end = tlc.uid_range_end,
    next_extension = tlc.next_extension,
    ext_range_start = tlc.ext_range_start,
    ext_range_end = tlc.ext_range_end,
    last_sync_at = tlc.last_sync_at,
    last_error = tlc.last_error
FROM tenant_ldap_configs tlc
WHERE ct.ued_config_id = tlc.id;

-- 3. Add profile_id to sync_events, backfill
ALTER TABLE sync_events
    ADD COLUMN IF NOT EXISTS profile_id VARCHAR(128)
        REFERENCES config_templates(id) ON DELETE SET NULL;

UPDATE sync_events se
SET profile_id = ct.id
FROM tenant_ldap_configs tlc
JOIN config_templates ct ON ct.ued_config_id = tlc.id
WHERE se.tenant_id = tlc.tenant_id;

-- 4. Drop old tenant_id FK and column from sync_events
ALTER TABLE sync_events
    DROP CONSTRAINT IF EXISTS sync_events_tenant_id_fkey;
ALTER TABLE sync_events
    DROP COLUMN IF EXISTS tenant_id;

-- 5. Drop ued_config_id from config_templates
ALTER TABLE config_templates
    DROP CONSTRAINT IF EXISTS config_templates_ued_config_id_fkey;
ALTER TABLE config_templates
    DROP COLUMN IF EXISTS ued_config_id;

-- 6. Drop tenant_ldap_configs
DROP TABLE IF EXISTS tenant_ldap_configs;

COMMIT;
```

**Step 2: Commit**

```bash
git add migrations/014_profile_ued_merge.sql
git commit -m "migration: 014 merge tenant_ldap_configs into config_templates"
```

---

### Task 3: Update orgdb.py — Table definitions

**Files:**
- Modify: `src/backend/orgdb.py`

**Step 1: Replace config_templates Table definition (lines 199-216)**

Add the 13 new UED columns. Remove `ued_config_id` FK column.

New definition:
```python
config_templates = Table(
    "config_templates", metadata,
    Column("id", String(128), primary_key=True),
    Column("name", String(255), nullable=False, unique=True),
    Column("description", Text, nullable=False, server_default=""),
    Column("template_type", String(20), nullable=False, server_default="custom"),
    Column("status", String(20), nullable=False, server_default="draft"),
    Column("xmpp_config", JSON, nullable=False, server_default='{"enabled":false}'),
    Column("sip_config", JSON, nullable=False, server_default='{"enabled":false}'),
    Column("sso_config", JSON, nullable=False, server_default='{"enabled":false}'),
    Column("qr_settings", JSON, nullable=False, server_default='{"defaultValidityMinutes":60,"oneTimeUse":true,"autoEmailOnCreate":false,"deepLinkScheme":"azblink"}'),
    # UED provisioning (merged from tenant_ldap_configs)
    Column("ued_api_url", Text, nullable=True),
    Column("ued_api_key_enc", Text, nullable=True),
    Column("ued_enabled", Boolean, nullable=False, server_default="false"),
    Column("discovered_schema_name", Text, nullable=True),
    Column("discovered_at", DateTime(timezone=True), nullable=True),
    Column("next_uid_number", Integer, nullable=False, server_default="5000"),
    Column("uid_range_start", Integer, nullable=False, server_default="5000"),
    Column("uid_range_end", Integer, nullable=False, server_default="65533"),
    Column("next_extension", Integer, nullable=False, server_default="6000"),
    Column("ext_range_start", Integer, nullable=False, server_default="6000"),
    Column("ext_range_end", Integer, nullable=False, server_default="6999"),
    Column("last_sync_at", DateTime(timezone=True), nullable=True),
    Column("last_error", Text, nullable=True),
    # Audit
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("updated_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("created_by", String(255)),
    Column("updated_by", String(255)),
)
```

**Step 2: Delete `tenant_ldap_configs` Table definition (lines 263-289)**

Remove entirely.

**Step 3: Update `sync_events` Table definition (lines 291-306)**

Replace `tenant_id` FK with `profile_id` FK:
```python
sync_events = Table(
    "sync_events", metadata,
    Column("id", String(36), primary_key=True),
    Column("profile_id", String(128), ForeignKey("config_templates.id", ondelete="SET NULL"), nullable=True),
    Column("user_uid", Text, nullable=False),
    # ... rest unchanged
)
```

**Step 4: Verify file parses**

```bash
python -c "import sys; sys.path.insert(0, 'src/backend'); import orgdb; print('OK')"
```

---

### Task 4: Update orgdb.py — Methods

**Files:**
- Modify: `src/backend/orgdb.py`

**Step 1: Delete all tenant_ldap_config methods**

Remove these methods entirely:
- `create_tenant_ldap_config()` (lines 2328-2360)
- `get_tenant_ldap_config()` (lines 2362-2374)
- `get_tenant_ldap_config_by_id()` (lines 2376-2388)
- `list_tenant_ldap_configs()` (lines 2390-2403)
- `update_tenant_ldap_config()` (lines 2405-2416)
- `delete_tenant_ldap_config()` (lines 2418-2422)

**Step 2: Update allocate_uid_number() — change to use config_templates**

```python
def allocate_uid_number(self, profile_id: str) -> int:
    """Atomically allocate next POSIX uidNumber from profile's counter."""
    eng = self.connect()
    with eng.begin() as conn:
        row = conn.execute(
            config_templates.update()
            .where(config_templates.c.id == profile_id)
            .where(config_templates.c.next_uid_number <= config_templates.c.uid_range_end)
            .values(next_uid_number=config_templates.c.next_uid_number + 1)
            .returning(config_templates.c.next_uid_number - 1)
        ).scalar()
        if row is None:
            raise RuntimeError(f"UID range exhausted for profile {profile_id}")
        return row
```

**Step 3: Update allocate_extension() — same pattern**

```python
def allocate_extension(self, profile_id: str) -> int:
    """Atomically allocate next SIP extension from profile's counter."""
    eng = self.connect()
    with eng.begin() as conn:
        row = conn.execute(
            config_templates.update()
            .where(config_templates.c.id == profile_id)
            .where(config_templates.c.next_extension <= config_templates.c.ext_range_end)
            .values(next_extension=config_templates.c.next_extension + 1)
            .returning(config_templates.c.next_extension - 1)
        ).scalar()
        if row is None:
            raise RuntimeError(f"Extension range exhausted for profile {profile_id}")
        return row
```

**Step 4: Update insert_sync_event() — change tenant_id to profile_id**

```python
def insert_sync_event(self, profile_id: str, user_uid: str, event_type: str, payload: dict) -> str:
    """Insert a pending sync event linked to a profile."""
    event_id = str(uuid.uuid4())
    eng = self.connect()
    with eng.begin() as conn:
        conn.execute(sync_events.insert().values(
            id=event_id,
            profile_id=profile_id,
            user_uid=user_uid,
            event_type=event_type,
            payload=json.dumps(payload),
            request_id=str(uuid.uuid4()),
        ))
    return event_id
```

**Step 5: Update list_pending_sync_events() — change tenant_id to profile_id**

Replace all references to `sync_events.c.tenant_id` with `sync_events.c.profile_id` in the query. The per-user ordering logic stays the same, just keyed on `(profile_id, user_uid)` instead of `(tenant_id, user_uid)`.

**Step 6: Update any remaining methods referencing tenant_id**

Search for `tenant_id` in orgdb.py and replace with `profile_id` where referencing sync_events:
- `mark_sync_event_completed()`
- `mark_sync_event_retry()`
- `update_tenant_last_sync()` → rename to `update_profile_last_sync()`
- `update_tenant_last_error()` → rename to `update_profile_last_error()`
- `list_sync_events()` — filter param changes to `profile_id`

**Step 7: Ensure create_config_template() accepts new fields**

The existing `create_config_template()` method should already handle arbitrary column values passed in `data` dict. Verify it doesn't filter to a whitelist that excludes UED fields. If it does, add the new fields.

**Step 8: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "refactor(orgdb): merge tenant_ldap_configs into config_templates"
```

---

### Task 5: Update main.py — Remove UED config endpoints, update emit_sync_event

**Files:**
- Modify: `src/backend/main.py`

**Step 1: Update emit_sync_event() (lines 148-165)**

Change signature from `tenant_id` to `profile_id`. Look up profile instead of tenant config:

```python
def emit_sync_event(profile_id: str, user_uid: str, event_type: str, payload: dict) -> None:
    """Emit sync event if profile has UED provisioning enabled."""
    try:
        profile = ORGDB.get_config_template(profile_id)
        if not profile or not profile.get("ued_enabled") or not profile.get("ued_api_url"):
            return
        if event_type in ("user_created", "password_changed"):
            payload = encrypt_payload_password(payload)
        ORGDB.insert_sync_event(profile_id, user_uid, event_type, payload)
    except Exception as e:
        logger.exception("Failed to emit sync event for profile %s: %s", profile_id, e)
```

**Step 2: Update all emit_sync_event() call sites**

Replace `emit_sync_event(LDAP_TENANT, ...)` with `emit_sync_event(profile_id, ...)` at all call sites. The profile_id comes from the request's `profileId` field (for user_created) or needs to be resolved from the user's assigned profile (for updates/deletes/suspends).

For calls where no profile_id is available (user update, terminate, suspend, password change without profile context), the sync event should only be emitted if the user has a linked profile. This may require looking up the user's org → profile assignment. If this is too complex for now, these events can be skipped (only user_created needs profile-linked sync).

**Step 3: Delete TenantConfigCreateReq, TenantConfigUpdateReq (lines 3114-3149)**

Remove both classes.

**Step 4: Delete all /api/ued/configs endpoints (lines 3152-3229)**

Remove:
- `api_ued_configs_list()`
- `api_ued_config_create()`
- `api_ued_config_update()`
- `api_ued_config_delete()`
- `api_ued_config_test()`

**Step 5: Add UED fields to ConfigTemplateCreate (lines 2623-2630)**

```python
class ConfigTemplateCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str = Field(default="", max_length=1024)
    xmpp: Optional[XmppConfigUpdate] = None
    sip: Optional[SipConfigUpdate] = None
    sso: Optional[SsoConfigUpdate] = None
    qr: Optional[QrSettingsUpdate] = None
    # UED provisioning
    uedApiUrl: Optional[str] = None
    uedApiKey: Optional[str] = None
    uedEnabled: Optional[bool] = False
    uidRangeStart: Optional[int] = None
    uidRangeEnd: Optional[int] = None
    extRangeStart: Optional[int] = None
    extRangeEnd: Optional[int] = None
```

**Step 6: Add UED fields to ConfigTemplateUpdate (lines 2789-2797)**

```python
class ConfigTemplateUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    description: Optional[str] = Field(default=None, max_length=1024)
    status: Optional[str] = Field(default=None, pattern="^(active|draft|archived)$")
    xmpp: Optional[XmppConfigUpdate] = None
    sip: Optional[SipConfigUpdate] = None
    sso: Optional[SsoConfigUpdate] = None
    qr: Optional[QrSettingsUpdate] = None
    # UED provisioning
    uedApiUrl: Optional[str] = None
    uedApiKey: Optional[str] = None
    uedEnabled: Optional[bool] = None
    uidRangeStart: Optional[int] = None
    uidRangeEnd: Optional[int] = None
    extRangeStart: Optional[int] = None
    extRangeEnd: Optional[int] = None
```

**Step 7: Update api_create_config_template() handler**

When `uedApiKey` is provided, encrypt it before storage:
```python
if req.uedApiKey:
    data["ued_api_key_enc"] = encrypt_value(req.uedApiKey)
```

Map camelCase request fields to snake_case DB columns.

**Step 8: Update api_update_config_template() handler**

Same encryption logic for uedApiKey updates.

**Step 9: Add POST /api/config-templates/{id}/discover endpoint**

```python
@app.post("/api/config-templates/{template_id}/discover")
def api_config_template_discover(template_id: str, ...):
    """Run UED discovery on profile's endpoint, cache results."""
    profile = ORGDB.get_config_template(template_id)
    if not profile or not profile.get("ued_api_url"):
        raise HTTPException(404, "Profile not found or no UED URL configured")
    api_key = decrypt_value(profile["ued_api_key_enc"])
    result = asyncio.run(discover(profile["ued_api_url"], api_key))
    if result.ok:
        ORGDB.update_config_template(template_id, {
            "discovered_schema_name": result.schema_name,
            "discovered_at": datetime.now(timezone.utc),
        })
    return {"ok": result.ok, "discovery": {...}, "error": result.error}
```

**Step 10: Update profile list/detail responses**

Include UED fields in the response serialization (never include `ued_api_key_enc`):
- `discoveredSchemaName`, `discoveredAt`
- `uedApiUrl`, `uedEnabled`
- `nextUidNumber`, `uidRangeStart`, `uidRangeEnd`
- `nextExtension`, `extRangeStart`, `extRangeEnd`
- `lastSyncAt`, `lastError`

**Step 11: Update sync-events endpoints**

Change `tenant_id` filter param to `profile_id` in:
- `GET /api/ued/sync-events`
- `POST /api/ued/sync-events/retry-all-failed`

**Step 12: Remove LDAP_TENANT import**

Remove from the `from config import ...` line. Keep `LDAP_TENANT` in config.py if it's still used elsewhere (org tree, groups etc). Only remove it from `emit_sync_event` usage.

**Step 13: Commit**

```bash
git add src/backend/main.py
git commit -m "refactor(main): merge UED config into profile endpoints"
```

---

### Task 6: Update sync_worker.py

**Files:**
- Modify: `src/backend/sync_worker.py`

**Step 1: Update _process_event() to resolve profile_id**

```python
async def _process_event(self, event: dict) -> None:
    profile_id = event["profile_id"]
    event_id = event["id"]

    profile = self.orgdb.get_config_template(profile_id)
    if not profile or not profile.get("ued_enabled"):
        self.orgdb.mark_sync_event_retry(
            event_id, error=f"Profile {profile_id} disabled or not found",
            attempts=event["max_attempts"], max_attempts=event["max_attempts"],
        )
        return

    try:
        api_key = decrypt_value(profile["ued_api_key_enc"])
    except Exception as e:
        self.orgdb.mark_sync_event_retry(
            event_id, error=f"Decryption failed: {e}",
            attempts=event["max_attempts"], max_attempts=event["max_attempts"],
        )
        return

    payload = event["payload"]
    if isinstance(payload, str):
        payload = json.loads(payload)
    payload = decrypt_payload_password(payload)

    result = await self.ued_client.send(
        ued_api_url=profile["ued_api_url"],
        ued_api_key=api_key,
        event_type=event["event_type"],
        payload=payload,
        request_id=event["request_id"],
    )

    if result.ok:
        self.orgdb.mark_sync_event_completed(event_id)
        self.orgdb.update_profile_last_sync(profile_id)
    elif result.retryable:
        self.orgdb.mark_sync_event_retry(event_id, error=result.error_message, ...)
    else:
        self.orgdb.mark_sync_event_retry(
            event_id, error=result.error_message,
            attempts=event["max_attempts"], max_attempts=event["max_attempts"],
        )
```

**Step 2: Update list_pending_sync_events() call if it takes tenant_id**

Ensure the polling query uses `profile_id` for per-user ordering.

**Step 3: Commit**

```bash
git add src/backend/sync_worker.py
git commit -m "refactor(sync_worker): resolve profile_id instead of tenant_id"
```

---

### Task 7: Update provisioning.py

**Files:**
- Modify: `src/backend/provisioning.py`

**Step 1: Simplify enrich_sync_payload()**

Remove the two-table join. Read UED fields directly from the profile:

```python
def enrich_sync_payload(orgdb, profile_id, uid, display_name, mail, password):
    """Enrich sync payload with uidNumber/extension/sipPassword from profile's UED config."""
    profile = orgdb.get_config_template(profile_id)
    if not profile or not profile.get("ued_api_url") or not profile.get("ued_enabled"):
        return None

    schema_name = profile.get("discovered_schema_name")
    if not schema_name or schema_name not in _KNOWN_SCHEMAS:
        return None

    uid_number = orgdb.allocate_uid_number(profile_id)

    extension = None
    sip_password = None
    if schema_name in _SIP_SCHEMAS:
        extension = orgdb.allocate_extension(profile_id)
        sip_password = generate_sip_password()

    user_data = {
        "username": uid,
        "display_name": display_name,
        "uid_number": str(uid_number),
        "mail": mail or "",
    }
    if extension is not None:
        user_data["extension"] = str(extension)
    if sip_password is not None:
        user_data["sip_password"] = sip_password

    payload = {"user": user_data, "password": password}
    result = ProvisioningResult(
        schema_name=schema_name,
        uid_number=uid_number,
        extension=extension,
        sip_password=sip_password,
    )
    return payload, result
```

**Step 2: Commit**

```bash
git add src/backend/provisioning.py
git commit -m "refactor(provisioning): read UED fields from profile directly"
```

---

### Task 8: Apply migration and run backend tests

**Step 1: Apply migration**

```bash
docker exec -i azblink-postgres psql -U azblink_directory -d azblink_directory \
  < migrations/014_profile_ued_merge.sql
```

**Step 2: Verify table structure**

```bash
docker exec azblink-postgres psql -U azblink_directory -d azblink_directory \
  -c "\d config_templates"
docker exec azblink-postgres psql -U azblink_directory -d azblink_directory \
  -c "\d sync_events"
docker exec azblink-postgres psql -U azblink_directory -d azblink_directory \
  -c "\dt tenant_ldap_configs"  # should say "Did not find"
```

**Step 3: Run tests**

```bash
python -m pytest tests/ -v --tb=short
```

Fix failures iteratively. Expected failures are in test files that still reference tenant_ldap_configs.

---

### Task 9: Update test files

**Files:**
- Modify: `tests/test_ued_api.py`
- Modify: `tests/test_ued_orgdb.py`
- Modify: `tests/test_sync_worker.py`
- Modify: `tests/test_profile_provisioning.py`

**Step 1: Rewrite test_ued_orgdb.py**

- Remove `SAMPLE_SCHEMA_CONFIG` constant
- Replace `create_tenant_ldap_config()` calls with `create_config_template()` calls that include UED fields
- Replace `get_tenant_ldap_config()` calls with `get_config_template()` calls
- Update sync event tests: `insert_sync_event(profile_id, ...)` instead of `insert_sync_event(tenant_id, ...)`
- Test `allocate_uid_number(profile_id)` and `allocate_extension(profile_id)`
- cleanup fixture: delete from `sync_events` and `config_templates` (not `tenant_ldap_configs`)

**Step 2: Rewrite test_ued_api.py**

- Config creation tests: POST to `/api/config-templates` with UED fields instead of `/api/ued/configs`
- Config list tests: GET `/api/config-templates` and check UED fields in response
- Delete tests: DELETE `/api/config-templates/{id}`
- Sync event emission tests: setup profile with UED fields, create user with profileId, verify sync event has profile_id
- Discovery test: POST `/api/config-templates/{id}/discover` (mocked or real)
- Remove cleanup fixture for `tenant_ldap_configs`

**Step 3: Update test_sync_worker.py**

- `mock_orgdb` fixture: return profile dict (from `get_config_template`) with UED fields instead of tenant config
- `sample_event` fixture: use `profile_id` key instead of `tenant_id`
- Update assertions: `send()` called with `ued_api_url` from profile

**Step 4: Update test_profile_provisioning.py**

- Remove `_create_ued_config()` helper (no separate UED config creation)
- Update `_create_profile_with_ued()` to include UED fields inline on profile create
- All tests should create profiles with UED fields directly

**Step 5: Run all tests**

```bash
python -m pytest tests/ -v --tb=short
```

Expected: all pass.

**Step 6: Commit**

```bash
git add tests/
git commit -m "test: update all tests for profile-UED merge"
```

---

### Task 10: Update frontend types

**Files:**
- Modify: `src/frontend/src/types/org-profiles.ts`

**Step 1: Replace uedConfigId/schemaName with inline UED fields**

In `ProfileListItem`:
```typescript
// Remove:
uedConfigId: string | null;
schemaName: string | null;

// Add:
uedApiUrl: string | null;
uedEnabled: boolean;
discoveredSchemaName: string | null;
```

In `ProfileDetail`:
```typescript
// Remove:
uedConfigId: string | null;
schemaName: string | null;

// Add:
uedApiUrl: string | null;
uedEnabled: boolean;
discoveredSchemaName: string | null;
discoveredAt: string | null;
nextUidNumber: number;
uidRangeStart: number;
uidRangeEnd: number;
nextExtension: number;
extRangeStart: number;
extRangeEnd: number;
lastSyncAt: string | null;
lastError: string | null;
```

In `CreateProfilePayload`:
```typescript
// Remove:
uedConfigId?: string;

// Add:
uedApiUrl?: string;
uedApiKey?: string;
uedEnabled?: boolean;
uidRangeStart?: number;
uidRangeEnd?: number;
extRangeStart?: number;
extRangeEnd?: number;
```

In `UpdateProfilePayload`:
```typescript
// Remove:
uedConfigId?: string;

// Add:
uedApiUrl?: string;
uedApiKey?: string;
uedEnabled?: boolean;
uidRangeStart?: number;
uidRangeEnd?: number;
extRangeStart?: number;
extRangeEnd?: number;
```

**Step 2: Commit**

```bash
git add src/frontend/src/types/org-profiles.ts
git commit -m "feat(types): inline UED fields on profile types"
```

---

### Task 11: Add UED Provisioning section to ConfigTab

**Files:**
- Modify: `src/frontend/src/components/features/org-profiles/ConfigTab.tsx`
- Modify: `src/frontend/src/components/features/org-profiles/profile-type-config.ts`

**Step 1: Add UED section config to profile-type-config.ts**

Add a `ued` entry to the `sectionConfig` object with label, icon, color, bg.

**Step 2: Add UED ConfigSection to ConfigTab.tsx**

Between SSO and QR sections, add:

```tsx
{/* UED Provisioning */}
{profile.uedApiUrl && (
  <ConfigSection
    title={sectionConfig.ued.label}
    sectionKey="ued"
    icon={sectionConfig.ued.icon}
    iconColor={sectionConfig.ued.color}
    iconBg={sectionConfig.ued.bg}
    enabled={profile.uedEnabled}
    showToggle={false}
  >
    <ConfigRow label="Endpoint" value={profile.uedApiUrl} />
    <ConfigRow label="Schema" value={profile.discoveredSchemaName || 'Not discovered'} />
    <ConfigRow label="UID Range" value={`${profile.uidRangeStart}–${profile.uidRangeEnd} (next: ${profile.nextUidNumber})`} />
    <ConfigRow label="Extension Range" value={`${profile.extRangeStart}–${profile.extRangeEnd} (next: ${profile.nextExtension})`} />
    {profile.lastSyncAt && <ConfigRow label="Last Sync" value={profile.lastSyncAt} />}
    {profile.lastError && <ConfigRow label="Last Error" value={profile.lastError} />}
  </ConfigSection>
)}
```

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/org-profiles/ConfigTab.tsx \
        src/frontend/src/components/features/org-profiles/profile-type-config.ts
git commit -m "feat(ui): add UED Provisioning section to profile ConfigTab"
```

---

### Task 12: Add discovery mutation

**Files:**
- Modify: `src/frontend/src/lib/queries/org-profiles-mutations.ts`

**Step 1: Add useRunDiscovery hook**

```typescript
export function useRunDiscovery(id: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () =>
      getApi().post<{ ok: boolean; discovery: Record<string, unknown>; error: string }>(
        `/config-templates/${id}/discover`
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.configTemplates });
      queryClient.invalidateQueries({ queryKey: queryKeys.configTemplate(id) });
    },
  });
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/lib/queries/org-profiles-mutations.ts
git commit -m "feat(queries): add useRunDiscovery mutation hook"
```

---

### Task 13: Update CLAUDE.md

**Files:**
- Modify: `CLAUDE.md`

**Step 1: Update UED Sync Integration section**

Document the merged model:
- Profile = UED integration (1:1)
- No separate tenant_ldap_configs table
- UED fields inline on config_templates
- sync_events FK to config_templates.id via profile_id

**Step 2: Update migration list**

Add `014_profile_ued_merge.sql`.

**Step 3: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: update CLAUDE.md for profile-UED merge"
```

---

### Task 14: Full verification and PR

**Step 1: Run all backend tests**

```bash
python -m pytest tests/ -v --tb=short
```

**Step 2: Run UED Sync tests**

```bash
docker exec azblink-ued-sync /app/.venv/bin/python -m pytest tests/ --ignore=tests/integration -v --tb=short
```

**Step 3: Verify frontend builds**

```bash
cd src/frontend && npx tsc --noEmit
```

**Step 4: Push and create PR**

```bash
git push origin sip-xmpp-profile-provisioning
gh pr create --title "feat: profile = UED integration (1:1 merge)" --base main
```
