# DetailGrid + FieldCard Primitives — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Create two new @azblink/ui primitives (DetailGrid + FieldCard) that display key/value metadata in a card-based responsive grid, then migrate all three detail panels to use them.

**Architecture:** DetailGrid renders a semantic `<dl>` with CSS Grid `auto-fit` columns. FieldCard renders a `<div>` wrapping `<dt>/<dd>` with card styling (background, border, radius). Feature components import both from `@azblink/ui` and compose them with domain data. InfoField is kept for compact/inline use cases.

**Tech Stack:** React 19, CSS Modules, design tokens (`tokens.css`), `@azblink/ui` npm workspace package

---

## Task 1: Create FieldCard Primitive — Types

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/FieldCard/FieldCard.types.ts`

**Step 1: Create the types file**

```typescript
/** primitives/FieldCard/FieldCard.types.ts — Props for the FieldCard component. */
import type { ReactNode } from 'react';

export interface FieldCardProps {
  /** Uppercase label rendered as <dt> */
  label: string;
  /** Value content rendered as <dd> — accepts string or ReactNode */
  value: ReactNode;
  /** Render value in monospace font (useful for DNs, IDs) */
  mono?: boolean;
  /** Optional className for the card container */
  className?: string;
}
```

**Step 2: Verify — no build needed, just confirm file exists**

Run: `ls src/frontend/packages/azblink-ui/primitives/FieldCard/FieldCard.types.ts`
Expected: file listed

---

## Task 2: Create FieldCard Primitive — CSS Module

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/FieldCard/FieldCard.module.css`

**Step 1: Create the CSS Module**

Reference tokens from `packages/azblink-ui/tokens/tokens.css`. Never hardcode values.

```css
/* primitives/FieldCard/FieldCard.module.css */

/* ═══════════════════════════════════════════════════════════════════════════
   FIELD CARD
   Card-style key/value pair for detail panel metadata grids.
   Each card contains an uppercase label (<dt>) and a prominent value (<dd>).
   ═══════════════════════════════════════════════════════════════════════════ */

.fieldCard {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  padding: var(--space-4);
  background-color: var(--color-bg-secondary);
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-lg);
  min-width: 0;
}

.label {
  font-size: var(--text-2xs);
  font-weight: var(--font-semibold);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--color-text-muted);
  line-height: var(--leading-snug);
}

.value {
  font-size: var(--text-base);
  font-weight: var(--font-medium);
  color: var(--color-text-primary);
  line-height: var(--leading-normal);
  overflow-wrap: break-word;
  word-break: break-all;
}

.mono {
  font-family: var(--font-mono);
  font-size: var(--text-sm);
}
```

---

## Task 3: Create FieldCard Primitive — Component

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/FieldCard/FieldCard.tsx`

**Step 1: Create the component**

Follow the same pattern as `primitives/InfoField/InfoField.tsx` (lines 1-24).

```tsx
/** primitives/FieldCard/FieldCard.tsx — Card-style label/value pair for detail grids. */
import { cn } from '../../utils/cn';
import styles from './FieldCard.module.css';
import type { FieldCardProps } from './FieldCard.types';

/**
 * Renders a label/value pair inside a card container.
 * - Label: uppercase muted text (<dt>)
 * - Value: prominent text or ReactNode (<dd>)
 * - Used inside <DetailGrid> for detail panel metadata.
 *
 * @example
 * ```tsx
 * <FieldCard label="DN" value="ou=eng,dc=azblink,dc=com" mono />
 * <FieldCard label="Type" value={<GroupTypeBadge type="posix" />} />
 * ```
 */
export function FieldCard({ label, value, mono, className }: FieldCardProps) {
  return (
    <div className={cn(styles.fieldCard, className)}>
      <dt className={styles.label}>{label}</dt>
      <dd className={cn(styles.value, mono && styles.mono)}>
        {value}
      </dd>
    </div>
  );
}
```

---

## Task 4: Create FieldCard Primitive — Barrel Export

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/FieldCard/index.ts`

**Step 1: Create the barrel export**

```typescript
/** primitives/FieldCard/index.ts — Barrel export. */
export { FieldCard } from './FieldCard';
export type { FieldCardProps } from './FieldCard.types';
```

---

## Task 5: Create DetailGrid Primitive — Types

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/DetailGrid/DetailGrid.types.ts`

**Step 1: Create the types file**

```typescript
/** primitives/DetailGrid/DetailGrid.types.ts — Props for the DetailGrid component. */
import type { ReactNode } from 'react';

export interface DetailGridProps {
  /** FieldCard children */
  children: ReactNode;
  /** CSS min-width for auto-fit column breakpoint (default: '200px') */
  minColumnWidth?: string;
  /** Optional className for the grid container */
  className?: string;
}
```

---

## Task 6: Create DetailGrid Primitive — CSS Module

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/DetailGrid/DetailGrid.module.css`

**Step 1: Create the CSS Module**

```css
/* primitives/DetailGrid/DetailGrid.module.css */

/* ═══════════════════════════════════════════════════════════════════════════
   DETAIL GRID
   Responsive grid container for FieldCard items.
   Uses CSS Grid auto-fit — columns collapse/expand based on container width.
   ═══════════════════════════════════════════════════════════════════════════ */

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(var(--min-col-width, 200px), 1fr));
  gap: var(--space-3);
}
```

---

## Task 7: Create DetailGrid Primitive — Component

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/DetailGrid/DetailGrid.tsx`

**Step 1: Create the component**

```tsx
/** primitives/DetailGrid/DetailGrid.tsx — Responsive grid container for FieldCard items. */
import type { CSSProperties } from 'react';
import { cn } from '../../utils/cn';
import styles from './DetailGrid.module.css';
import type { DetailGridProps } from './DetailGrid.types';

/**
 * Semantic <dl> grid that auto-fits FieldCard children into responsive columns.
 * - Default min column width: 200px (override via minColumnWidth prop)
 * - No explicit column count — auto-fit adapts to container width
 *
 * @example
 * ```tsx
 * <DetailGrid>
 *   <FieldCard label="DN" value={org.dn} mono />
 *   <FieldCard label="Key" value={org.key} />
 * </DetailGrid>
 * ```
 */
export function DetailGrid({ children, minColumnWidth = '200px', className }: DetailGridProps) {
  const style = minColumnWidth !== '200px'
    ? { '--min-col-width': minColumnWidth } as CSSProperties
    : undefined;

  return (
    <dl className={cn(styles.grid, className)} style={style}>
      {children}
    </dl>
  );
}
```

---

## Task 8: Create DetailGrid Primitive — Barrel Export

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/DetailGrid/index.ts`

**Step 1: Create the barrel export**

```typescript
/** primitives/DetailGrid/index.ts — Barrel export. */
export { DetailGrid } from './DetailGrid';
export type { DetailGridProps } from './DetailGrid.types';
```

---

## Task 9: Register Both Primitives in @azblink/ui Barrel

**Files:**
- Modify: `src/frontend/packages/azblink-ui/index.ts` (insert after line 116, before the "Future exports" comment on line 118)

**Step 1: Add exports to the package barrel**

Insert these 5 lines after the existing InfoField export (line 116) and before the `// Future exports` comment (line 118):

```typescript

export { DetailGrid } from './primitives/DetailGrid';
export type { DetailGridProps } from './primitives/DetailGrid';

export { FieldCard } from './primitives/FieldCard';
export type { FieldCardProps } from './primitives/FieldCard';
```

**Step 2: Verify Vite HMR picks up the new exports**

Run: `cd src/frontend && npx tsc --noEmit --pretty 2>&1 | head -20`
Expected: no errors related to DetailGrid or FieldCard

**Step 3: Commit the primitives**

```bash
git add src/frontend/packages/azblink-ui/primitives/DetailGrid/ src/frontend/packages/azblink-ui/primitives/FieldCard/ src/frontend/packages/azblink-ui/index.ts
git commit -m "feat(ui): add DetailGrid and FieldCard primitives

Card-style key/value pairs for detail panel metadata grids.
DetailGrid: semantic <dl> with CSS Grid auto-fit responsive columns.
FieldCard: <dt>/<dd> pair in a bordered card with uppercase label."
```

---

## Task 10: Migrate Group OverviewTab

**Files:**
- Modify: `src/frontend/src/components/features/group-management/OverviewTab.tsx` (40 lines total)

**Step 1: Replace the full OverviewTab**

Current file ([OverviewTab.tsx](src/frontend/src/components/features/group-management/OverviewTab.tsx)):
- Line 6: imports `InfoField` from `@azblink/ui`
- Lines 21-37: `<div className="grid grid-cols-2 ...">` with mixed InfoField + ad-hoc dt/dd
- Line 22: `<InfoField label="DN" value={group.dn} />` (string-only, no mono)
- Lines 23-28: ad-hoc dt/dd for Type with `<GroupTypeBadge>` component

Replace the entire file with:

```tsx
/**
 * Overview tab for group detail — info grid (DN, Type, Created, Modified).
 * - Extracted from GroupDetailPanel during tabs migration
 * - Uses DetailGrid + FieldCard for card-style metadata display
 */
import { DetailGrid, FieldCard } from '@azblink/ui';
import { formatDate } from '@/lib/utils/date-helpers';
import { GroupTypeBadge } from './GroupTypeBadge';
import type { GroupDetail } from '@/types/group';

interface OverviewTabProps {
  group: GroupDetail;
}

export function OverviewTab({ group }: OverviewTabProps) {
  return (
    <div className="space-y-3">
      <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--color-text-muted)]">
        Information
      </h3>
      <DetailGrid>
        <FieldCard label="DN" value={group.dn} mono />
        <FieldCard label="Type" value={<GroupTypeBadge type={group.group_type} />} />
        <FieldCard
          label="Created"
          value={group.created_at ? formatDate(group.created_at) : '\u2014'}
        />
        <FieldCard
          label="Modified"
          value={group.updated_at ? formatDate(group.updated_at) : '\u2014'}
        />
      </DetailGrid>
    </div>
  );
}
```

Key changes:
- Import `DetailGrid, FieldCard` instead of `InfoField`
- `<div className="grid grid-cols-2 ...">` → `<DetailGrid>`
- `<InfoField label="DN" value={group.dn} />` → `<FieldCard label="DN" value={group.dn} mono />` (added `mono` for DN)
- Ad-hoc dt/dd for Type (lines 23-28) → `<FieldCard label="Type" value={<GroupTypeBadge .../>} />`
- InfoField for Created/Modified → FieldCard equivalents

**Step 2: Verify in browser**

Open http://localhost:8081/directory/groups, select a group, confirm:
- Overview tab shows 4 cards in a responsive grid
- DN renders in monospace, Type shows the badge, dates display correctly
- Resize the panel — cards reflow from 2 cols to 1 col

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/group-management/OverviewTab.tsx
git commit -m "feat(groups): migrate overview tab to DetailGrid + FieldCard"
```

---

## Task 11: Migrate Org OverviewTab

**Files:**
- Modify: `src/frontend/src/components/features/org-management/OverviewTab.tsx` (70 lines total)

**Step 1: Replace the info grid section**

Current file ([OverviewTab.tsx](src/frontend/src/components/features/org-management/OverviewTab.tsx)):
- Line 5: imports `InfoField` from `@azblink/ui`
- Lines 29-52: `<div className="grid grid-cols-2 ...">` with mixed InfoField + ad-hoc dt/dd
- Lines 30-35: ad-hoc dt/dd for DN with `<CopyableDN>` component
- Lines 38-43: ad-hoc dt/dd for SSO Status with `<SSOBadge>` component

Replace the entire file with:

```tsx
/**
 * Overview tab content: stats row + info grid + child orgs section.
 * Read-only display of org statistics and metadata.
 */
import { DetailGrid, FieldCard } from '@azblink/ui';
import { StatsRow } from './StatsRow';
import { ChildOrgItem } from './ChildOrgItem';
import { SSOBadge } from './SSOBadge';
import { CopyableDN } from './CopyableDN';
import { formatDate } from '@/lib/utils/date-helpers';
import type { OrgDetail } from '@/types/org';

interface OverviewTabProps {
  org: OrgDetail;
  onSelectChild: (dn: string) => void;
}

export function OverviewTab({ org, onSelectChild }: OverviewTabProps) {
  return (
    <div className="space-y-6">
      {/* Stats row */}
      <StatsRow stats={org.stats} />

      {/* Info grid */}
      <div className="space-y-3">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--color-text-muted)]">
          Information
        </h3>
        <DetailGrid>
          <FieldCard label="DN" value={<CopyableDN dn={org.dn} />} />
          <FieldCard label="Type" value={org.type} />
          <FieldCard label="Profile ID" value={org.profileId || '\u2014'} />
          <FieldCard label="SSO Status" value={<SSOBadge enabled={org.ssoConfig?.enabled ?? false} />} />
          <FieldCard
            label="Created"
            value={org.createdAt ? formatDate(org.createdAt) : '\u2014'}
          />
          <FieldCard
            label="Modified"
            value={org.updatedAt ? formatDate(org.updatedAt) : '\u2014'}
          />
        </DetailGrid>
      </div>

      {/* Child orgs */}
      {org.children.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--color-text-muted)]">
            Sub-Organizations ({org.children.length})
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {org.children.map((child) => (
              <ChildOrgItem key={child.dn} child={child} onSelect={onSelectChild} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
```

Key changes:
- Import `DetailGrid, FieldCard` instead of `InfoField`
- `<div className="grid grid-cols-2 ...">` → `<DetailGrid>`
- Ad-hoc dt/dd for DN (lines 30-35) → `<FieldCard label="DN" value={<CopyableDN .../>} />`
- Ad-hoc dt/dd for SSO Status (lines 38-43) → `<FieldCard label="SSO Status" value={<SSOBadge .../>} />`
- InfoField for Type, Profile ID, Created, Modified → FieldCard equivalents
- Child orgs section is NOT changed — it uses ChildOrgItem cards, not key/value pairs

**Step 2: Verify in browser**

Open http://localhost:8081/directory/orgs, select an org, confirm:
- Overview tab shows 6 cards in responsive grid (DN, Type, Profile ID, SSO Status, Created, Modified)
- DN shows CopyableDN component inside card, SSO Status shows badge
- Stats row and child orgs section unchanged

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/org-management/OverviewTab.tsx
git commit -m "feat(orgs): migrate overview tab to DetailGrid + FieldCard"
```

---

## Task 12: Migrate User ProfileSection

**Files:**
- Modify: `src/frontend/src/components/features/user-management/UserDetailPanel.tsx` (lines 118-167, ProfileSection function)

**Step 1: Update imports**

Current line 11:
```tsx
import { Button, InfoField, Skeleton } from '@azblink/ui';
```

Replace with:
```tsx
import { Button, DetailGrid, FieldCard, Skeleton } from '@azblink/ui';
```

**Step 2: Replace ProfileSection function**

Current [UserDetailPanel.tsx:118-167](src/frontend/src/components/features/user-management/UserDetailPanel.tsx#L118-L167):
- Lines 133-138: `<div className="grid grid-cols-2 ...">` with 4 InfoField components
- Lines 141-155: custom organization link (dt/dd with button)
- Lines 157-164: groups display (inline text, not a key/value pair)

Replace lines 118-167 (the entire ProfileSection function) with:

```tsx
/** User profile info: uid, email, mobile, title, organization, groups */
function ProfileSection({
  user,
  groups,
}: {
  user: User;
  groups: { cn: string; dn: string }[];
}) {
  const navigate = useNavigate();

  return (
    <div className="space-y-3">
      <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--color-text-muted)]">
        Profile
      </h3>
      <DetailGrid>
        <FieldCard label="UID" value={user.uid} mono />
        <FieldCard label="Email" value={user.mail} />
        <FieldCard label="Mobile" value={user.mobile || 'Not set'} />
        <FieldCard label="Title" value={user.title || 'Not set'} />
        {user.orgDn && (
          <FieldCard
            label="Organization"
            value={
              <button
                type="button"
                className="inline-flex items-center gap-1 text-sm font-medium text-[var(--color-primary)] hover:underline"
                onClick={() => navigate({ to: '/directory/orgs', search: { orgId: user.orgDn } })}
              >
                <Building2 className="h-3 w-3" />
                {getOrgName(user.orgDn)}
              </button>
            }
          />
        )}
        {groups.length > 0 && (
          <FieldCard
            label="Groups"
            value={groups.map((g) => g.cn).join(', ')}
          />
        )}
      </DetailGrid>
    </div>
  );
}
```

Key changes:
- `<div className="grid grid-cols-2 ...">` → `<DetailGrid>`
- 4 InfoField components → 4 FieldCard components (UID gets `mono`)
- Custom org link dt/dd block → `<FieldCard label="Organization" value={<button .../>} />`
- Inline groups text → `<FieldCard label="Groups" value={...} />`
- Organization and Groups now live inside the same DetailGrid as proper FieldCards
- Removes the `pt-1` and `pt-2` spacing hacks (grid gap handles it)

**Step 3: Verify in browser**

Open http://localhost:8081/directory/users, select a user, confirm:
- Profile section shows FieldCards in responsive grid
- UID renders in monospace
- Organization link is clickable inside its card
- Groups list displays inside a card
- Panel resize reflows cards correctly

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/user-management/UserDetailPanel.tsx
git commit -m "feat(users): migrate profile section to DetailGrid + FieldCard"
```

---

## Task 13: Visual QA + Final Commit

**Step 1: Full visual check across all three panels**

Open each panel and verify the card-style metadata grid:
1. http://localhost:8081/directory/groups → select any group → Overview tab
2. http://localhost:8081/directory/orgs → select any org → Overview tab
3. http://localhost:8081/directory/users → select any user → Profile section

Check for each:
- Cards have visible background + border + rounded corners
- Labels are uppercase, small, muted
- Values are larger, primary color
- Monospace applies to DN/UID fields
- ReactNode values (badges, buttons) render correctly inside cards
- Grid reflows on panel resize (2 cols → 1 col)
- Light mode works (toggle theme if available)

**Step 2: Run TypeScript check**

```bash
cd src/frontend && npx tsc --noEmit --pretty 2>&1 | head -30
```
Expected: no errors

**Step 3: Run existing E2E tests to check for regressions**

```bash
cd src/frontend && npx playwright test --reporter=line 2>&1 | tail -20
```
Expected: all existing tests pass

**Step 4: Final commit if any fixups were needed**

If any adjustments were made during QA, commit them:
```bash
git add -u
git commit -m "fix(ui): polish DetailGrid + FieldCard after visual QA"
```

---

## Summary

| Task | What | Files |
|------|------|-------|
| 1-4 | FieldCard primitive (types, CSS, component, barrel) | 4 new files |
| 5-8 | DetailGrid primitive (types, CSS, component, barrel) | 4 new files |
| 9 | Register in @azblink/ui barrel export | 1 modified file |
| 10 | Migrate group OverviewTab | 1 modified file |
| 11 | Migrate org OverviewTab | 1 modified file |
| 12 | Migrate user ProfileSection | 1 modified file |
| 13 | Visual QA + regression check | 0 files |

**Total:** 8 new files, 4 modified files, 3 commits (primitives, group, org, user)
