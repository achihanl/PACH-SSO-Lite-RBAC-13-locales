# Audit Log Migration — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Migrate the audit log page to the React split-panel architecture with a new unified backend endpoint, ListPanel-based table, detail panel, multi-axis filtering, and bidirectional cross-page navigation with QR codes.

**Architecture:** New `GET /api/audit/events` endpoint UNION ALL-joins 4 audit tables server-side, returns paginated + filtered results. Frontend renders via `ListPanel` + `AuditDetailPanel` split-panel. State lives in URL search params (no Zustand). Two new `@azblink/ui` primitives: `ToggleChipGroup` and `CodeBlock`.

**Tech Stack:** FastAPI + SQLAlchemy Core (backend), React 19 + TanStack Router + TanStack Query + Tailwind CSS 4 + @azblink/ui (frontend)

**Design doc:** `docs/plans/2026-02-10-audit-log-migration.md`

---

## Phase 0 — Backend endpoint + types + primitives (~3h)

### Task 0.1: Add unified audit query method to orgdb.py

**Files:**
- Modify: `src/backend/orgdb.py` (after line 994, after `list_user_lifecycle`)

**Step 1: Write the backend method**

Add `list_unified_audit()` to the `OrgDB` class. This method UNION ALL-joins the 4 audit tables, derives event types, and handles pagination + filtering:

```python
def list_unified_audit(
    self,
    *,
    page: int = 1,
    page_size: int = 20,
    time_range: str = "7d",
    category: str = "all",
    search: str = "",
    qr_id: str | None = None,
) -> dict[str, Any]:
    """Return paginated, filtered, unified audit events from all 4 audit tables.

    UNION ALL strategy:
    - qr_issuance_audit → qr-generated/consumed/expired/revoked
    - termination_events → user-terminated
    - auth_failure_audit → login (failure)
    - user_lifecycle_audit → user-created/sso-enrolled/config-change
    """
    eng = self.connect()
    now = datetime.now(timezone.utc)

    # Time range filter
    time_filters = {
        "today": now - timedelta(days=1),
        "7d": now - timedelta(days=7),
        "30d": now - timedelta(days=30),
        "90d": now - timedelta(days=90),
        "all": None,
    }
    since = time_filters.get(time_range, time_filters["7d"])

    with eng.begin() as conn:
        # Build unified CTE from raw SQL for clarity
        parts = []
        params: dict[str, Any] = {}

        # --- QR Issuance events ---
        qr_sql = """
            SELECT
                'QR-' || LPAD(qa.id::text, 5, '0') AS id,
                CASE
                    WHEN qa.consumed_reason = 'admin_revoked' THEN 'qr-revoked'
                    WHEN qa.consumed = true THEN 'qr-consumed'
                    WHEN qa.consumed = false AND qa.expires_at < NOW() THEN 'qr-expired'
                    ELSE 'qr-generated'
                END AS event_type,
                COALESCE(qa.consumed_at, qa.issued_at) AS timestamp,
                CASE
                    WHEN qa.consumed_reason = 'admin_revoked' THEN 'QR Code Revoked'
                    WHEN qa.consumed = true THEN 'QR Code Consumed'
                    WHEN qa.consumed = false AND qa.expires_at < NOW() THEN 'QR Code Expired'
                    ELSE 'QR Code Generated'
                END AS title,
                CASE
                    WHEN qa.consumed = true THEN 'Provisioning completed' ||
                        COALESCE(' on ' || pt.client_platform, '')
                    WHEN qa.consumed_reason = 'admin_revoked' THEN 'Token invalidated during termination'
                    WHEN qa.consumed = false AND qa.expires_at < NOW() THEN 'Token TTL exceeded without scan'
                    ELSE 'Valid for ' || EXTRACT(EPOCH FROM (qa.expires_at - qa.issued_at))::int / 3600 || ' hour(s)'
                END AS description,
                qa.issued_by AS actor,
                qa.user_uid AS target,
                'QR-' || LEFT(qa.token_hash, 9) AS reference_id,
                CASE WHEN qa.consumed = true THEN 'success' ELSE 'success' END AS result,
                'qr' AS category,
                CASE WHEN qa.consumed_at IS NOT NULL AND qa.issued_at IS NOT NULL
                    THEN EXTRACT(EPOCH FROM (qa.consumed_at - qa.issued_at))::int * 1000
                    ELSE NULL
                END AS duration_ms,
                qa.org_dn AS organization,
                qa.client_ip AS ip_address,
                CASE WHEN pt.client_platform IS NOT NULL THEN
                    json_build_object(
                        'model', COALESCE(pt.consumed_by_device_id, 'Unknown'),
                        'os', COALESCE(pt.client_platform, 'Unknown'),
                        'app_version', pt.client_version,
                        'user_agent', qa.user_agent
                    )::text
                    ELSE NULL
                END AS device_json,
                json_build_object(
                    'id', qa.id, 'user_uid', qa.user_uid, 'org_dn', qa.org_dn,
                    'issued_by', qa.issued_by, 'issued_at', qa.issued_at,
                    'token_hash', qa.token_hash, 'expires_at', qa.expires_at,
                    'consumed', qa.consumed, 'consumed_at', qa.consumed_at,
                    'consumed_reason', qa.consumed_reason,
                    'client_ip', qa.client_ip, 'user_agent', qa.user_agent
                )::text AS raw_data
            FROM qr_issuance_audit qa
            LEFT JOIN provision_tokens pt ON pt.token_hash = qa.token_hash
        """
        parts.append(qr_sql)

        # --- Termination events ---
        trm_sql = """
            SELECT
                'TRM-' || LPAD(te.id::text, 5, '0') AS id,
                'user-terminated' AS event_type,
                te.timestamp AS timestamp,
                'User Access Terminated' AS title,
                'All sessions revoked, LDAP disabled' AS description,
                te.terminated_by AS actor,
                te.user_uid AS target,
                'TRM-' || LPAD(te.id::text, 4, '0') AS reference_id,
                'success' AS result,
                'user' AS category,
                NULL::int AS duration_ms,
                te.org_dn AS organization,
                NULL AS ip_address,
                NULL AS device_json,
                json_build_object(
                    'id', te.id, 'user_uid', te.user_uid, 'user_dn', te.user_dn,
                    'org_dn', te.org_dn, 'terminated_by', te.terminated_by,
                    'reason', te.reason, 'timestamp', te.timestamp,
                    'actions_taken', te.actions_taken,
                    'ldap_disabled', te.ldap_disabled,
                    'tokens_revoked', te.tokens_revoked
                )::text AS raw_data
            FROM termination_events te
        """
        parts.append(trm_sql)

        # --- Auth failure events ---
        af_sql = """
            SELECT
                'SES-' || LPAD(af.id::text, 5, '0') AS id,
                'login' AS event_type,
                af.timestamp AS timestamp,
                'Authentication Failed' AS title,
                'Reason: ' || af.failure_reason AS description,
                COALESCE(af.username, 'Unknown') AS actor,
                '—' AS target,
                'SES-' || LPAD(af.id::text, 4, '0') AS reference_id,
                'failure' AS result,
                'auth' AS category,
                NULL::int AS duration_ms,
                NULL AS organization,
                af.client_ip AS ip_address,
                NULL AS device_json,
                json_build_object(
                    'id', af.id, 'username', af.username,
                    'failure_reason', af.failure_reason,
                    'timestamp', af.timestamp, 'client_ip', af.client_ip,
                    'user_agent', af.user_agent, 'endpoint', af.endpoint
                )::text AS raw_data
            FROM auth_failure_audit af
        """
        parts.append(af_sql)

        # --- User lifecycle events ---
        ul_sql = """
            SELECT
                'USR-' || LPAD(ul.id::text, 5, '0') AS id,
                CASE ul.action
                    WHEN 'created' THEN 'user-created'
                    WHEN 'suspended' THEN 'user-terminated'
                    WHEN 'unsuspended' THEN 'user-created'
                    WHEN 'password_reset' THEN 'config-change'
                    ELSE 'config-change'
                END AS event_type,
                ul.timestamp AS timestamp,
                CASE ul.action
                    WHEN 'created' THEN 'User Created'
                    WHEN 'suspended' THEN 'User Suspended'
                    WHEN 'unsuspended' THEN 'User Unsuspended'
                    WHEN 'password_reset' THEN 'Password Reset'
                    ELSE 'User Lifecycle: ' || ul.action
                END AS title,
                COALESCE(ul.detail, '') AS description,
                COALESCE(ul.performed_by, 'System') AS actor,
                ul.user_uid AS target,
                'USR-' || LPAD(ul.id::text, 4, '0') AS reference_id,
                'success' AS result,
                'user' AS category,
                NULL::int AS duration_ms,
                NULL AS organization,
                NULL AS ip_address,
                NULL AS device_json,
                json_build_object(
                    'id', ul.id, 'user_uid', ul.user_uid,
                    'action', ul.action, 'performed_by', ul.performed_by,
                    'detail', ul.detail, 'timestamp', ul.timestamp
                )::text AS raw_data
            FROM user_lifecycle_audit ul
        """
        parts.append(ul_sql)

        # Combine with UNION ALL
        union_sql = " UNION ALL ".join(parts)

        # Wrap in outer query with filtering + pagination
        where_clauses = []
        if since is not None:
            where_clauses.append("unified.timestamp >= :since")
            params["since"] = since
        if category != "all":
            where_clauses.append("unified.category = :category")
            params["category"] = category
        if search:
            where_clauses.append(
                "(unified.actor ILIKE :search OR unified.target ILIKE :search "
                "OR unified.reference_id ILIKE :search OR unified.description ILIKE :search)"
            )
            params["search"] = f"%{search}%"
        if qr_id:
            where_clauses.append("unified.reference_id ILIKE :qr_id")
            params["qr_id"] = f"%{qr_id}%"

        where_sql = (" WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

        # Count query
        count_sql = f"SELECT COUNT(*) FROM ({union_sql}) unified {where_sql}"
        total = conn.execute(text(count_sql), params).scalar() or 0

        # Data query with pagination
        offset = (page - 1) * page_size
        params["limit"] = page_size
        params["offset"] = offset
        data_sql = (
            f"SELECT * FROM ({union_sql}) unified {where_sql} "
            f"ORDER BY unified.timestamp DESC NULLS LAST "
            f"LIMIT :limit OFFSET :offset"
        )
        rows = conn.execute(text(data_sql), params).mappings().all()

    import math
    events = []
    for r in rows:
        device = None
        if r["device_json"]:
            try:
                device = json.loads(r["device_json"])
            except Exception:
                pass
        raw = {}
        if r["raw_data"]:
            try:
                raw = json.loads(r["raw_data"])
            except Exception:
                pass

        events.append({
            "id": r["id"],
            "event_type": r["event_type"],
            "timestamp": r["timestamp"].isoformat() if r["timestamp"] else None,
            "title": r["title"],
            "description": r["description"] or "",
            "actor": r["actor"] or "System",
            "target": r["target"] or "—",
            "reference_id": r["reference_id"],
            "result": r["result"],
            "category": r["category"],
            "duration_ms": r["duration_ms"],
            "organization": r["organization"],
            "ip_address": r["ip_address"],
            "device": device,
            "raw_data": raw,
        })

    return {
        "events": events,
        "pagination": {
            "page": page,
            "page_size": page_size,
            "total_events": total,
            "total_pages": math.ceil(total / page_size) if total > 0 else 1,
        },
    }
```

**Step 2: Add missing import at top of orgdb.py**

At the top of `orgdb.py`, ensure `text` is imported from sqlalchemy (check if already present):

```python
from sqlalchemy import text
```

Also ensure `json` is imported (check if already present).

**Step 3: Verify manually**

Run: `just psql` then `SELECT COUNT(*) FROM qr_issuance_audit;` to confirm seed data exists.

---

### Task 0.2: Add unified audit endpoint to main.py

**Files:**
- Modify: `src/backend/main.py` (after line 2332, after existing audit endpoints)

**Step 1: Add the endpoint**

```python
@app.get("/api/audit/events")
def api_audit_events(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    time_range: str = Query("7d"),
    category: str = Query("all"),
    search: str = Query(""),
    qr_id: str = Query(None),
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Unified audit events — paginated, filtered, across all audit tables."""
    valid_ranges = {"today", "7d", "30d", "90d", "all"}
    valid_categories = {"all", "qr", "user", "auth", "config"}
    if time_range not in valid_ranges:
        time_range = "7d"
    if category not in valid_categories:
        category = "all"
    result = ORGDB.list_unified_audit(
        page=page,
        page_size=page_size,
        time_range=time_range,
        category=category,
        search=search,
        qr_id=qr_id,
    )
    return {"ok": True, **result}
```

**Step 2: Verify endpoint works**

Run: `just up-bg` (if not running), then:

```bash
curl -s http://localhost:8081/api/audit/events | python3 -m json.tool | head -30
```

Expected: JSON response with `"ok": true`, `"events": [...]`, `"pagination": {...}`.

**Step 3: Run existing tests**

Run: `just test-quick`
Expected: All existing tests still pass (new endpoint doesn't break anything).

**Step 4: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py
git commit -m "feat(audit): add unified GET /api/audit/events endpoint (Phase 0)"
```

---

### Task 0.3: Add unified frontend types

**Files:**
- Modify: `src/frontend/src/types/audit.ts` (append after existing types)

**Step 1: Add types**

Append to the existing file (do NOT remove existing types — they're used by provisioning/tokens page):

```typescript
// ═══════════════════════════════════════════════════════════════════════════
// Unified Audit Events (for /audit-log page)
// ═══════════════════════════════════════════════════════════════════════════

/** 9 supported event types (qr-scanned deferred to v2) */
export type AuditEventType =
  | 'qr-generated'
  | 'qr-consumed'
  | 'qr-expired'
  | 'qr-revoked'
  | 'user-created'
  | 'user-terminated'
  | 'sso-enrolled'
  | 'config-change'
  | 'login';

export type EventCategory = 'qr' | 'user' | 'auth' | 'config';
export type TimeRange = 'today' | '7d' | '30d' | '90d' | 'all';
export type EventResult = 'success' | 'failure' | 'warning';

export interface AuditDeviceInfo {
  model: string;
  os: string;
  app_version: string | null;
  user_agent: string | null;
}

/** Unified audit event — matches GET /api/audit/events response shape */
export interface AuditEvent {
  id: string;
  event_type: AuditEventType;
  timestamp: string;
  title: string;
  description: string;
  actor: string;
  target: string;
  reference_id: string | null;
  result: EventResult;
  category: EventCategory;
  duration_ms: number | null;
  organization: string | null;
  ip_address: string | null;
  device: AuditDeviceInfo | null;
  raw_data: Record<string, unknown>;
}

export interface AuditPagination {
  page: number;
  page_size: number;
  total_events: number;
  total_pages: number;
}

export interface AuditEventsResponse {
  ok: boolean;
  events: AuditEvent[];
  pagination: AuditPagination;
}

/** URL search params for the /audit-log route */
export interface AuditLogSearchParams {
  eventId?: string;
  qr?: string;
  timeRange?: TimeRange;
  category?: EventCategory | 'all';
  search?: string;
  page?: number;
  chips?: string;
}
```

**Step 2: Ensure re-export from barrel**

Check `src/frontend/src/types/index.ts` — if it barrel-exports from `./audit`, the new types will auto-export. If not, add the re-export.

**Step 3: Commit**

```bash
git add src/frontend/src/types/audit.ts
git commit -m "feat(audit): add unified AuditEvent types (Phase 0)"
```

---

### Task 0.4: Add unified audit query hook + query keys

**Files:**
- Modify: `src/frontend/src/lib/queries/keys.ts` (line 35-38, extend audit section)
- Modify: `src/frontend/src/lib/queries/audit.ts` (append after existing hooks)

**Step 1: Add query key**

In `keys.ts`, extend the `audit` section:

```typescript
// Audit
audit: {
  qrIssuance: (limit?: number) => ['audit', 'qr_issuance', { limit }] as const,
  terminations: (limit?: number) => ['audit', 'terminations', { limit }] as const,
  events: (params: Record<string, unknown>) => ['audit', 'events', params] as const,
},
```

**Step 2: Add query options in audit.ts**

Append to `src/frontend/src/lib/queries/audit.ts`:

```typescript
import type { AuditEventsResponse, TimeRange, EventCategory } from '@/types/audit';

export interface AuditEventsQueryParams {
  page: number;
  pageSize: number;
  timeRange: TimeRange;
  category: EventCategory | 'all';
  search: string;
  qrId?: string;
}

export const auditEventsQueryOptions = (params: AuditEventsQueryParams) =>
  queryOptions({
    queryKey: queryKeys.audit.events({
      page: params.page,
      pageSize: params.pageSize,
      timeRange: params.timeRange,
      category: params.category,
      search: params.search,
      qrId: params.qrId,
    }),
    queryFn: () =>
      getApi().get<AuditEventsResponse>('/audit/events', {
        page: params.page,
        page_size: params.pageSize,
        time_range: params.timeRange,
        category: params.category,
        search: params.search || undefined,
        qr_id: params.qrId || undefined,
      }),
    staleTime: 15_000,
  });
```

**Step 3: Commit**

```bash
git add src/frontend/src/lib/queries/keys.ts src/frontend/src/lib/queries/audit.ts
git commit -m "feat(audit): add auditEventsQueryOptions hook (Phase 0)"
```

---

### Task 0.5: Create ToggleChipGroup primitive

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/ToggleChipGroup/ToggleChipGroup.types.ts`
- Create: `src/frontend/packages/azblink-ui/primitives/ToggleChipGroup/ToggleChipGroup.module.css`
- Create: `src/frontend/packages/azblink-ui/primitives/ToggleChipGroup/ToggleChipGroup.tsx`
- Create: `src/frontend/packages/azblink-ui/primitives/ToggleChipGroup/index.ts`
- Modify: `src/frontend/packages/azblink-ui/index.ts` (add barrel export)

**Step 1: Types**

```typescript
/** primitives/ToggleChipGroup/ToggleChipGroup.types.ts — Multi-select toggle chip group. */
import type { ComponentPropsWithoutRef, ReactNode } from 'react';

export interface ToggleChip {
  /** Unique chip ID (used as Set key) */
  id: string;
  /** Display label */
  label: string;
  /** Optional icon (rendered before label) */
  icon?: ReactNode;
}

export interface ToggleChipGroupProps extends Omit<ComponentPropsWithoutRef<'div'>, 'onChange'> {
  /** Chip definitions */
  chips: ToggleChip[];
  /** Currently active chip IDs */
  activeIds: Set<string>;
  /** Called when a chip is toggled */
  onChange: (activeIds: Set<string>) => void;
}
```

**Step 2: CSS Module**

```css
/** primitives/ToggleChipGroup/ToggleChipGroup.module.css — Toggle chip styling. */

.group {
  display: flex;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.chip {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1_5);
  padding: var(--space-1_5) var(--space-2_5);
  border-radius: var(--radius-full);
  border: 1px solid var(--color-border-subtle);
  background: transparent;
  color: var(--color-text-muted);
  font-family: var(--font-sans);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  line-height: var(--leading-compact);
  cursor: pointer;
  transition: all var(--transition-fast);
  white-space: nowrap;
}

.chip:hover {
  background: var(--color-bg-hover);
  border-color: var(--color-border-default);
}

.chip.active {
  background: var(--color-primary-bg);
  border-color: var(--color-primary);
  color: var(--color-primary);
}

.chipIcon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
  flex-shrink: 0;
}
```

**Step 3: Component**

```typescript
/** primitives/ToggleChipGroup/ToggleChipGroup.tsx — Multi-select filter chip group. */
import { useCallback } from 'react';
import { cn } from '../../utils/cn';
import styles from './ToggleChipGroup.module.css';
import type { ToggleChipGroupProps } from './ToggleChipGroup.types';

export function ToggleChipGroup({ chips, activeIds, onChange, className, ...props }: ToggleChipGroupProps) {
  const handleToggle = useCallback(
    (chipId: string) => {
      const next = new Set(activeIds);
      if (next.has(chipId)) {
        next.delete(chipId);
      } else {
        next.add(chipId);
      }
      onChange(next);
    },
    [activeIds, onChange],
  );

  return (
    <div className={cn(styles.group, className)} role="group" aria-label="Filter chips" {...props}>
      {chips.map((chip) => (
        <button
          key={chip.id}
          type="button"
          className={cn(styles.chip, activeIds.has(chip.id) && styles.active)}
          onClick={() => handleToggle(chip.id)}
          aria-pressed={activeIds.has(chip.id)}
        >
          {chip.icon && <span className={styles.chipIcon}>{chip.icon}</span>}
          {chip.label}
        </button>
      ))}
    </div>
  );
}
```

**Step 4: Barrel export**

```typescript
/** primitives/ToggleChipGroup/index.ts */
export { ToggleChipGroup } from './ToggleChipGroup';
export type { ToggleChipGroupProps, ToggleChip } from './ToggleChipGroup.types';
```

**Step 5: Add to @azblink/ui index.ts**

Add after the `ListPanel` exports section:

```typescript
export { ToggleChipGroup } from './primitives/ToggleChipGroup';
export type { ToggleChipGroupProps, ToggleChip } from './primitives/ToggleChipGroup';
```

**Step 6: Commit**

```bash
git add src/frontend/packages/azblink-ui/primitives/ToggleChipGroup/ src/frontend/packages/azblink-ui/index.ts
git commit -m "feat(ui): add ToggleChipGroup primitive (Phase 0)"
```

---

### Task 0.6: Create CodeBlock primitive

**Files:**
- Create: `src/frontend/packages/azblink-ui/primitives/CodeBlock/CodeBlock.types.ts`
- Create: `src/frontend/packages/azblink-ui/primitives/CodeBlock/CodeBlock.module.css`
- Create: `src/frontend/packages/azblink-ui/primitives/CodeBlock/CodeBlock.tsx`
- Create: `src/frontend/packages/azblink-ui/primitives/CodeBlock/index.ts`
- Modify: `src/frontend/packages/azblink-ui/index.ts` (add barrel export)

**Step 1: Types**

```typescript
/** primitives/CodeBlock/CodeBlock.types.ts — Pre-formatted code block. */
import type { ComponentPropsWithoutRef } from 'react';

export interface CodeBlockProps extends Omit<ComponentPropsWithoutRef<'pre'>, 'children'> {
  /** Code content to display */
  code: string;
  /** Maximum height before scrolling (default: '200px') */
  maxHeight?: string;
  /** Language label (decorative, shown in header if provided) */
  language?: string;
}
```

**Step 2: CSS Module**

```css
/** primitives/CodeBlock/CodeBlock.module.css — Pre-formatted code block styling. */

.codeBlock {
  background-color: var(--color-bg-secondary);
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-lg);
  overflow: hidden;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-2) var(--space-3);
  border-bottom: 1px solid var(--color-border-subtle);
  background-color: var(--color-bg-tertiary);
}

.language {
  font-family: var(--font-mono);
  font-size: var(--text-2xs);
  font-weight: var(--font-medium);
  color: var(--color-text-muted);
  text-transform: uppercase;
  letter-spacing: var(--tracking-widest);
}

.pre {
  margin: 0;
  padding: var(--space-3);
  overflow-x: auto;
  overflow-y: auto;
  font-family: var(--font-mono);
  font-size: var(--text-sm);
  line-height: var(--leading-relaxed);
  color: var(--color-text-secondary);
  white-space: pre;
  tab-size: 2;
}
```

**Step 3: Component**

```typescript
/** primitives/CodeBlock/CodeBlock.tsx — Pre-formatted code block for raw data display. */
import type { CSSProperties } from 'react';
import { cn } from '../../utils/cn';
import styles from './CodeBlock.module.css';
import type { CodeBlockProps } from './CodeBlock.types';

export function CodeBlock({ code, maxHeight = '200px', language, className, ...props }: CodeBlockProps) {
  const preStyle: CSSProperties = { maxHeight };

  return (
    <div className={cn(styles.codeBlock, className)}>
      {language && (
        <div className={styles.header}>
          <span className={styles.language}>{language}</span>
        </div>
      )}
      <pre className={styles.pre} style={preStyle} {...props}>
        {code}
      </pre>
    </div>
  );
}
```

**Step 4: Barrel export**

```typescript
/** primitives/CodeBlock/index.ts */
export { CodeBlock } from './CodeBlock';
export type { CodeBlockProps } from './CodeBlock.types';
```

**Step 5: Add to @azblink/ui index.ts**

Add after the `ToggleChipGroup` exports:

```typescript
export { CodeBlock } from './primitives/CodeBlock';
export type { CodeBlockProps } from './primitives/CodeBlock';
```

**Step 6: Commit**

```bash
git add src/frontend/packages/azblink-ui/primitives/CodeBlock/ src/frontend/packages/azblink-ui/index.ts
git commit -m "feat(ui): add CodeBlock primitive (Phase 0)"
```

---

### Task 0.7: Create audit event config map

**Files:**
- Create: `src/frontend/src/components/features/audit-management/audit-event-config.ts`

**Step 1: Write the config**

Follows `group-management/group-type-config.ts` pattern exactly:

```typescript
/**
 * Audit event type visual config — icon, foreground/background classes per AuditEventType.
 * Used by AuditRow (list), AuditDetailPanel (header), and FilterChips.
 */
import {
  Plus,
  Check,
  Clock,
  Ban,
  UserPlus,
  UserMinus,
  KeyRound,
  Settings,
  LogIn,
} from 'lucide-react';
import type { AuditEventType } from '@/types/audit';

export interface AuditEventConfig {
  icon: typeof Plus;
  fg: string;
  bg: string;
  label: string;
}

export const auditEventConfig: Record<AuditEventType, AuditEventConfig> = {
  'qr-generated': {
    icon: Plus,
    fg: 'text-blue-500',
    bg: 'bg-blue-500/10',
    label: 'QR Generated',
  },
  'qr-consumed': {
    icon: Check,
    fg: 'text-green-500',
    bg: 'bg-green-500/10',
    label: 'QR Consumed',
  },
  'qr-expired': {
    icon: Clock,
    fg: 'text-zinc-400',
    bg: 'bg-zinc-500/10',
    label: 'QR Expired',
  },
  'qr-revoked': {
    icon: Ban,
    fg: 'text-red-500',
    bg: 'bg-red-500/10',
    label: 'QR Revoked',
  },
  'user-created': {
    icon: UserPlus,
    fg: 'text-purple-500',
    bg: 'bg-purple-500/10',
    label: 'User Created',
  },
  'user-terminated': {
    icon: UserMinus,
    fg: 'text-red-500',
    bg: 'bg-red-500/10',
    label: 'User Terminated',
  },
  'sso-enrolled': {
    icon: KeyRound,
    fg: 'text-cyan-500',
    bg: 'bg-cyan-500/10',
    label: 'SSO Enrolled',
  },
  'config-change': {
    icon: Settings,
    fg: 'text-amber-500',
    bg: 'bg-amber-500/10',
    label: 'Config Change',
  },
  'login': {
    icon: LogIn,
    fg: 'text-indigo-500',
    bg: 'bg-indigo-500/10',
    label: 'Login',
  },
};
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/audit-management/audit-event-config.ts
git commit -m "feat(audit): add audit event type config map (Phase 0)"
```

---

## Phase 1 — Route + split-panel shell + table (~2h)

### Task 1.1: Create audit-log route

**Files:**
- Create: `src/frontend/src/routes/audit-log/index.tsx`

**Step 1: Write route file**

Follow `routes/provisioning/qr-codes.tsx` pattern:

```typescript
/**
 * Audit Log page — /audit-log
 * Split-panel layout: event list + event detail panel.
 * URL search params: ?eventId, ?qr, ?timeRange, ?category, ?search, ?page, ?chips
 */
import { createFileRoute } from '@tanstack/react-router';
import { AuditLogPage } from '@/components/features/audit-management/AuditLogPage';
import type { AuditLogSearchParams, TimeRange, EventCategory } from '@/types/audit';

const validTimeRanges: TimeRange[] = ['today', '7d', '30d', '90d', 'all'];
const validCategories: (EventCategory | 'all')[] = ['all', 'qr', 'user', 'auth', 'config'];

export const Route = createFileRoute('/audit-log')({
  validateSearch: (search: Record<string, unknown>): AuditLogSearchParams => ({
    eventId: (search.eventId as string) || undefined,
    qr: (search.qr as string) || undefined,
    timeRange: validTimeRanges.includes(search.timeRange as TimeRange)
      ? (search.timeRange as TimeRange)
      : '7d',
    category: validCategories.includes(search.category as EventCategory | 'all')
      ? (search.category as EventCategory | 'all')
      : 'all',
    search: (search.search as string) || undefined,
    page: search.page != null ? Number(search.page) || 1 : 1,
    chips: (search.chips as string) || undefined,
  }),
  component: AuditLogRoute,
});

function AuditLogRoute() {
  const searchParams = Route.useSearch();
  return <AuditLogPage searchParams={searchParams} />;
}
```

**Step 2: Regenerate route tree**

Run: `just ui-routes`

**Step 3: Commit**

```bash
git add src/frontend/src/routes/audit-log/
git commit -m "feat(audit): add /audit-log route with validateSearch (Phase 1)"
```

---

### Task 1.2: Create AuditLogPage orchestrator

**Files:**
- Create: `src/frontend/src/components/features/audit-management/AuditLogPage.tsx`

**Step 1: Write the page component**

Follow `QRManagementPage.tsx` pattern — split-panel grid with Suspense boundaries:

```typescript
/**
 * Top-level Audit Log page — split-panel layout.
 * - Left: event list (ListPanel + Pagination)
 * - Right: event detail panel
 * - URL search params drive all state
 * - Cmd+K to focus search
 */
import { useCallback, useEffect, useRef, Suspense } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { FileText } from 'lucide-react';
import { PageHeader } from './PageHeader';
import { AuditFilterBar } from './AuditFilterBar';
import { AuditList, AuditListSkeleton } from './AuditList';
import { AuditDetailPanel } from './AuditDetailPanel';
import { auditEventsQueryOptions } from '@/lib/queries/audit';
import type { AuditLogSearchParams, TimeRange, EventCategory, AuditEvent } from '@/types/audit';

interface AuditLogPageProps {
  searchParams: AuditLogSearchParams;
}

/** Parse comma-separated chips string to Set */
function parseChips(chips?: string): Set<string> {
  if (!chips) return new Set(['qr-generated', 'qr-consumed', 'qr-expired', 'user-events']);
  return new Set(chips.split(',').filter(Boolean));
}

/** Serialize Set to comma-separated string */
function serializeChips(chips: Set<string>): string {
  return Array.from(chips).join(',');
}

export function AuditLogPage({ searchParams }: AuditLogPageProps) {
  const {
    eventId,
    qr,
    timeRange = '7d',
    category = 'all',
    search = '',
    page = 1,
    chips: chipsParam,
  } = searchParams;

  const activeChips = parseChips(chipsParam);
  const navigate = useNavigate();
  const searchRef = useRef<HTMLInputElement>(null);

  // Cmd+K to focus search
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, []);

  const updateSearch = useCallback(
    (updates: Partial<AuditLogSearchParams>) => {
      navigate({
        to: '/audit-log',
        search: (prev: Record<string, unknown>) => ({ ...prev, ...updates }),
        replace: true,
      });
    },
    [navigate],
  );

  const handleSelectEvent = useCallback(
    (id: string) => updateSearch({ eventId: id }),
    [updateSearch],
  );

  const handleCloseDetail = useCallback(
    () => updateSearch({ eventId: undefined }),
    [updateSearch],
  );

  const handleTimeRangeChange = useCallback(
    (tr: TimeRange) => updateSearch({ timeRange: tr, page: 1 }),
    [updateSearch],
  );

  const handleCategoryChange = useCallback(
    (cat: EventCategory | 'all') => updateSearch({ category: cat, page: 1 }),
    [updateSearch],
  );

  const handleSearchChange = useCallback(
    (s: string) => updateSearch({ search: s || undefined, page: 1 }),
    [updateSearch],
  );

  const handlePageChange = useCallback(
    (p: number) => updateSearch({ page: p }),
    [updateSearch],
  );

  const handleChipsChange = useCallback(
    (chips: Set<string>) => updateSearch({ chips: serializeChips(chips) }),
    [updateSearch],
  );

  const handleClearQrFilter = useCallback(
    () => updateSearch({ qr: undefined, search: undefined }),
    [updateSearch],
  );

  return (
    <div className="flex flex-col gap-4 flex-1 min-h-0">
      <PageHeader
        search={search}
        onSearchChange={handleSearchChange}
        qrFilter={qr}
        onClearQrFilter={handleClearQrFilter}
        searchInputRef={searchRef}
      />

      <AuditFilterBar
        timeRange={timeRange as TimeRange}
        onTimeRangeChange={handleTimeRangeChange}
        category={category as EventCategory | 'all'}
        onCategoryChange={handleCategoryChange}
        activeChips={activeChips}
        onChipsChange={handleChipsChange}
      />

      <div className="flex flex-1 min-h-0 gap-6">
        {/* Left panel: event list */}
        <div className="flex-1 min-w-0">
          <Suspense fallback={<AuditListSkeleton />}>
            <AuditListPanel
              timeRange={timeRange as TimeRange}
              category={category as EventCategory | 'all'}
              search={search}
              qrId={qr}
              page={page}
              activeChips={activeChips}
              selectedEventId={eventId}
              onSelectEvent={handleSelectEvent}
              onPageChange={handlePageChange}
            />
          </Suspense>
        </div>

        {/* Right panel: detail */}
        <div className="hidden lg:flex w-[380px] shrink-0 flex-col rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden">
          <Suspense fallback={<DetailSkeleton />}>
            <DetailPanelWrapper
              timeRange={timeRange as TimeRange}
              category={category as EventCategory | 'all'}
              search={search}
              qrId={qr}
              page={page}
              selectedEventId={eventId}
              onClose={handleCloseDetail}
            />
          </Suspense>
        </div>
      </div>
    </div>
  );
}

/** Suspense-wrapped list that fetches events */
function AuditListPanel({
  timeRange,
  category,
  search,
  qrId,
  page,
  activeChips,
  selectedEventId,
  onSelectEvent,
  onPageChange,
}: {
  timeRange: TimeRange;
  category: EventCategory | 'all';
  search: string;
  qrId?: string;
  page: number;
  activeChips: Set<string>;
  selectedEventId?: string;
  onSelectEvent: (id: string) => void;
  onPageChange: (page: number) => void;
}) {
  const { data } = useSuspenseQuery(
    auditEventsQueryOptions({
      page,
      pageSize: 20,
      timeRange,
      category,
      search,
      qrId,
    }),
  );

  return (
    <AuditList
      events={data.events}
      pagination={data.pagination}
      activeChips={activeChips}
      selectedEventId={selectedEventId}
      qrFilter={qrId}
      onSelectEvent={onSelectEvent}
      onPageChange={onPageChange}
    />
  );
}

/** Suspense-wrapped detail panel */
function DetailPanelWrapper({
  timeRange,
  category,
  search,
  qrId,
  page,
  selectedEventId,
  onClose,
}: {
  timeRange: TimeRange;
  category: EventCategory | 'all';
  search: string;
  qrId?: string;
  page: number;
  selectedEventId?: string;
  onClose: () => void;
}) {
  const { data } = useSuspenseQuery(
    auditEventsQueryOptions({
      page,
      pageSize: 20,
      timeRange,
      category,
      search,
      qrId,
    }),
  );

  const selectedEvent = selectedEventId
    ? data.events.find((e) => e.id === selectedEventId)
    : undefined;

  if (!selectedEvent) {
    return <EmptyDetailPanel />;
  }

  return <AuditDetailPanel event={selectedEvent} onClose={onClose} />;
}

function EmptyDetailPanel() {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-2 text-[var(--color-text-muted)]">
      <FileText className="h-12 w-12 opacity-30" />
      <p className="text-sm">Select an event to view details</p>
    </div>
  );
}

function DetailSkeleton() {
  return (
    <div className="p-6 space-y-4">
      <div className="flex gap-4">
        <div className="h-12 w-12 rounded-lg bg-muted animate-pulse" />
        <div className="space-y-2 flex-1">
          <div className="h-5 w-32 bg-muted animate-pulse rounded" />
          <div className="h-4 w-24 bg-muted animate-pulse rounded" />
        </div>
      </div>
      <div className="h-px bg-[var(--color-border-subtle)]" />
      <div className="grid grid-cols-2 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-16 bg-muted animate-pulse rounded" />
        ))}
      </div>
    </div>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/audit-management/AuditLogPage.tsx
git commit -m "feat(audit): add AuditLogPage orchestrator (Phase 1)"
```

---

### Task 1.3: Create AuditList and AuditRow

**Files:**
- Create: `src/frontend/src/components/features/audit-management/AuditList.tsx`
- Create: `src/frontend/src/components/features/audit-management/AuditRow.tsx`

**Step 1: AuditList.tsx**

Follow `QRList.tsx` pattern with ListPanel:

```typescript
/**
 * Audit event list — left side of the split-panel layout.
 * - ListPanel primitive for card structure + elevated header
 * - Column headers: TIMESTAMP, EVENT, ACTOR, TARGET, REFERENCE
 * - Scrollable list of AuditRow components
 * - Client-side chip filtering within fetched page
 * - Pagination via Pagination primitive
 */
import {
  ListPanel,
  ListPanelHeader,
  ListPanelColumns,
  ListPanelBody,
  ListPanelFooter,
  Pagination,
} from '@azblink/ui';
import { AuditRow } from './AuditRow';
import type { AuditEvent, AuditPagination } from '@/types/audit';

interface AuditListProps {
  events: AuditEvent[];
  pagination: AuditPagination;
  activeChips: Set<string>;
  selectedEventId?: string;
  qrFilter?: string;
  onSelectEvent: (id: string) => void;
  onPageChange: (page: number) => void;
}

const AUDIT_COLUMNS = [
  { label: 'Timestamp' },
  { label: 'Event' },
  { label: 'Actor' },
  { label: 'Target' },
  { label: 'Reference' },
];

/** Map chip IDs to event types for client-side filtering */
const CHIP_TO_EVENT_TYPES: Record<string, string[]> = {
  'qr-generated': ['qr-generated'],
  'qr-consumed': ['qr-consumed'],
  'qr-expired': ['qr-expired', 'qr-revoked'],
  'user-events': ['user-created', 'user-terminated', 'sso-enrolled'],
};

function filterByChips(events: AuditEvent[], activeChips: Set<string>): AuditEvent[] {
  if (activeChips.size === 0) return events;
  const allowedTypes = new Set<string>();
  for (const chipId of activeChips) {
    const types = CHIP_TO_EVENT_TYPES[chipId];
    if (types) types.forEach((t) => allowedTypes.add(t));
  }
  // Events not covered by any chip (config-change, login) always show
  return events.filter(
    (e) => allowedTypes.has(e.event_type) || !Object.values(CHIP_TO_EVENT_TYPES).flat().includes(e.event_type),
  );
}

export function AuditList({
  events,
  pagination,
  activeChips,
  selectedEventId,
  qrFilter,
  onSelectEvent,
  onPageChange,
}: AuditListProps) {
  const visibleEvents = filterByChips(events, activeChips);

  return (
    <ListPanel data-testid="audit-table">
      <ListPanelHeader
        title="Activity Log"
        count={pagination.total_events}
        countLabel="events"
      />

      <ListPanelColumns
        columns={AUDIT_COLUMNS}
        className="grid-cols-[140px_2fr_120px_120px_100px] gap-4 px-5"
      />

      <ListPanelBody>
        {visibleEvents.length === 0 ? (
          <AuditListEmpty />
        ) : (
          visibleEvents.map((event) => (
            <AuditRow
              key={event.id}
              event={event}
              isSelected={selectedEventId === event.id}
              isHighlighted={!!qrFilter && event.reference_id?.includes(qrFilter)}
              onSelect={() => onSelectEvent(event.id)}
            />
          ))
        )}
      </ListPanelBody>

      <ListPanelFooter>
        <Pagination
          pageIndex={pagination.page - 1}
          pageSize={pagination.page_size}
          totalCount={pagination.total_events}
          pageSizes={[20, 50, 100]}
          onPageChange={(idx) => onPageChange(idx + 1)}
          onPageSizeChange={() => {}}
        />
      </ListPanelFooter>
    </ListPanel>
  );
}

export function AuditListSkeleton() {
  return (
    <ListPanel>
      <ListPanelHeader title="Activity Log">
        <div className="h-8 w-64 bg-muted animate-pulse rounded" />
      </ListPanelHeader>
      <ListPanelBody>
        <div className="p-2 space-y-2">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-14 bg-muted animate-pulse rounded" />
          ))}
        </div>
      </ListPanelBody>
    </ListPanel>
  );
}

function AuditListEmpty() {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-2 text-[var(--color-text-muted)] py-12" role="status" aria-live="polite">
      <p className="text-sm">No events found for current filters</p>
    </div>
  );
}
```

**Step 2: AuditRow.tsx**

```typescript
/**
 * Audit event row — displays a single event with icon, timestamp, details, and reference.
 * - Event icon from audit-event-config.ts
 * - Clickable QR- reference IDs for cross-page navigation
 * - Selected and highlighted states
 */
import { useNavigate } from '@tanstack/react-router';
import { cn } from '@azblink/ui';
import { auditEventConfig } from './audit-event-config';
import { formatDate } from '@/lib/utils/date-helpers';
import type { AuditEvent } from '@/types/audit';

interface AuditRowProps {
  event: AuditEvent;
  isSelected: boolean;
  isHighlighted?: boolean;
  onSelect: () => void;
}

export function AuditRow({ event, isSelected, isHighlighted, onSelect }: AuditRowProps) {
  const config = auditEventConfig[event.event_type];
  const Icon = config.icon;
  const navigate = useNavigate();

  const handleRefClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (event.reference_id?.startsWith('QR-')) {
      navigate({
        to: '/provisioning/qr-codes',
        search: { qrId: event.reference_id },
      });
    }
  };

  const timestamp = event.timestamp ? new Date(event.timestamp) : null;
  const dateStr = timestamp ? formatDate(event.timestamp) : '—';
  const timeStr = timestamp
    ? timestamp.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    : '';

  return (
    <button
      onClick={onSelect}
      aria-current={isSelected ? 'true' : undefined}
      data-testid={`audit-row-${event.id}`}
      className={cn(
        'group w-full grid grid-cols-[140px_2fr_120px_120px_100px] items-center gap-4 px-5 py-3 text-left transition-colors border-b border-[var(--color-border-subtle)]',
        isSelected
          ? 'bg-[var(--color-accent)]/5 border-l-2 border-l-[var(--color-accent)]'
          : 'hover:bg-[var(--color-bg-secondary)]',
        isHighlighted && !isSelected && 'bg-blue-500/10',
      )}
    >
      {/* Timestamp */}
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{dateStr}</p>
        <p className="text-sm text-text font-mono">{timeStr}</p>
      </div>

      {/* Event */}
      <div className="flex items-center gap-3 min-w-0">
        <div className={cn('h-8 w-8 rounded-lg flex items-center justify-center flex-shrink-0', config.bg)}>
          <Icon className={cn('h-4 w-4', config.fg)} />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium text-text truncate">{event.title}</p>
          <p className="text-xs text-muted-foreground truncate">{event.description}</p>
        </div>
      </div>

      {/* Actor */}
      <div className="text-sm text-muted-foreground truncate">{event.actor}</div>

      {/* Target */}
      <div className="text-sm text-muted-foreground truncate">{event.target}</div>

      {/* Reference */}
      <div className="min-w-0">
        {event.reference_id ? (
          event.reference_id.startsWith('QR-') ? (
            <button
              onClick={handleRefClick}
              className="text-xs font-mono text-[var(--color-primary)] hover:underline truncate"
            >
              {event.reference_id}
            </button>
          ) : (
            <span className="text-xs font-mono text-muted-foreground truncate">
              {event.reference_id}
            </span>
          )
        ) : (
          <span className="text-xs text-muted-foreground">—</span>
        )}
      </div>
    </button>
  );
}
```

**Step 3: Verify page renders**

Run: Open `http://localhost:8081/audit-log` in browser. Confirm:
- Events render in the list
- Clicking a row highlights it and updates URL `?eventId=`
- Pagination shows correct count

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/audit-management/AuditList.tsx src/frontend/src/components/features/audit-management/AuditRow.tsx
git commit -m "feat(audit): add AuditList + AuditRow with ListPanel (Phase 1)"
```

---

## Phase 2 — Detail panel (~2h)

### Task 2.1: Create AuditDetailPanel

**Files:**
- Create: `src/frontend/src/components/features/audit-management/AuditDetailPanel.tsx`

**Step 1: Write detail panel**

Follow `QRDetailPanel.tsx` pattern — sections with `DetailGrid` + `FieldCard`:

```typescript
/**
 * Audit event detail panel — right side of the split-panel layout.
 * - Header: large event icon + title + event ID + close button
 * - Sections: Event Details, Actor & Target, Cross-Reference, Device, Provisioning, Raw JSON
 * - CodeBlock for raw event data
 */
import { useNavigate } from '@tanstack/react-router';
import { X } from 'lucide-react';
import { Button, Badge, DetailGrid, FieldCard, CodeBlock, cn } from '@azblink/ui';
import { auditEventConfig } from './audit-event-config';
import { formatDateTime, formatDuration } from '@/lib/utils/date-helpers';
import type { AuditEvent } from '@/types/audit';

interface AuditDetailPanelProps {
  event: AuditEvent;
  onClose: () => void;
}

export function AuditDetailPanel({ event, onClose }: AuditDetailPanelProps) {
  const config = auditEventConfig[event.event_type];
  const Icon = config.icon;
  const navigate = useNavigate();

  const handleViewQR = () => {
    if (event.reference_id?.startsWith('QR-')) {
      navigate({
        to: '/provisioning/qr-codes',
        search: { qrId: event.reference_id },
      });
    }
  };

  return (
    <div className="flex flex-col h-full overflow-hidden" data-testid="audit-detail-panel">
      {/* Header */}
      <div className="px-5 py-4 border-b border-[var(--color-border-subtle)] flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className={cn('h-12 w-12 rounded-lg flex items-center justify-center', config.bg)}>
            <Icon className={cn('h-6 w-6', config.fg)} />
          </div>
          <div>
            <h2 className="text-base font-semibold text-text">{event.title}</h2>
            <p className="text-xs font-mono text-muted-foreground">{event.id}</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          aria-label="Close detail panel"
          className="shrink-0"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto">
        {/* Event Details */}
        <div className="px-5 py-4 border-b border-[var(--color-border-subtle)]">
          <h3 className="text-sm font-medium text-text mb-3">Event Details</h3>
          <DetailGrid>
            <FieldCard label="Timestamp" value={formatDateTime(event.timestamp)} mono />
            <FieldCard label="Event Type" value={event.event_type} mono />
            <FieldCard
              label="Result"
              value={
                <Badge variant={event.result === 'success' ? 'success' : event.result === 'failure' ? 'error' : 'warning'}>
                  {event.result}
                </Badge>
              }
            />
            {event.duration_ms != null && (
              <FieldCard label="Duration" value={formatDuration(event.duration_ms)} />
            )}
          </DetailGrid>
        </div>

        {/* Actor & Target */}
        <div className="px-5 py-4 border-b border-[var(--color-border-subtle)]">
          <h3 className="text-sm font-medium text-text mb-3">Actor & Target</h3>
          <DetailGrid>
            <FieldCard label="Actor" value={event.actor} />
            <FieldCard label="Target" value={event.target} />
            {event.organization && <FieldCard label="Organization" value={event.organization} mono />}
            {event.ip_address && <FieldCard label="IP Address" value={event.ip_address} mono />}
          </DetailGrid>
        </div>

        {/* Cross-Reference (QR only) */}
        {event.reference_id?.startsWith('QR-') && (
          <div className="px-5 py-4 border-b border-[var(--color-border-subtle)]">
            <h3 className="text-sm font-medium text-text mb-3">Related QR Code</h3>
            <button
              onClick={handleViewQR}
              className="w-full flex items-center gap-3 p-3 rounded-lg border border-[var(--color-border-subtle)] hover:bg-[var(--color-bg-hover)] transition-colors text-left"
            >
              <div className="h-8 w-8 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
                <svg className="h-4 w-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01" />
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-text">{event.reference_id}</p>
                <p className="text-xs text-muted-foreground">View in QR Codes page</p>
              </div>
              <svg className="h-4 w-4 text-muted-foreground shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        )}

        {/* Device Information (conditional) */}
        {event.device && (
          <div className="px-5 py-4 border-b border-[var(--color-border-subtle)]">
            <h3 className="text-sm font-medium text-text mb-3">Device Information</h3>
            <DetailGrid>
              <FieldCard label="Device" value={event.device.model} />
              <FieldCard label="OS" value={event.device.os} />
              {event.device.app_version && <FieldCard label="App Version" value={event.device.app_version} mono />}
              {event.device.user_agent && <FieldCard label="User Agent" value={event.device.user_agent} mono />}
            </DetailGrid>
          </div>
        )}

        {/* Raw Event Data */}
        <div className="px-5 py-4">
          <h3 className="text-sm font-medium text-text mb-3">Raw Event Data</h3>
          <CodeBlock
            code={JSON.stringify(event.raw_data, null, 2)}
            language="json"
            maxHeight="200px"
          />
        </div>
      </div>
    </div>
  );
}
```

**Step 2: Verify**

Open `http://localhost:8081/audit-log`, click an event row. Confirm:
- Detail panel opens on right
- All sections render with data
- Close button deselects and hides panel
- QR cross-reference link navigates to QR codes page

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/audit-management/AuditDetailPanel.tsx
git commit -m "feat(audit): add AuditDetailPanel with sections and cross-ref (Phase 2)"
```

---

## Phase 3 — Filters & search (~2h)

### Task 3.1: Create PageHeader with search and QR filter banner

**Files:**
- Create: `src/frontend/src/components/features/audit-management/PageHeader.tsx`

**Step 1: Write PageHeader**

```typescript
/**
 * Audit log page header — title, QR filter banner, search input, export button.
 * - FilterContextBanner shows when ?qr= param is present
 * - Search input with 300ms debounce
 * - Export button (CSV download)
 */
import { FileText, Search, Download, Filter, X } from 'lucide-react';
import { Button, Input } from '@azblink/ui';
import { SearchInput } from '@/components/features/user-management/SearchInput';

interface PageHeaderProps {
  search: string;
  onSearchChange: (value: string) => void;
  qrFilter?: string;
  onClearQrFilter: () => void;
  searchInputRef?: React.RefObject<HTMLInputElement | null>;
}

export function PageHeader({
  search,
  onSearchChange,
  qrFilter,
  onClearQrFilter,
  searchInputRef,
}: PageHeaderProps) {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-500/10">
            <FileText className="h-5 w-5 text-indigo-500" />
          </div>
          <div>
            <h1 className="text-xl font-semibold text-text">Audit Log</h1>
            <p className="text-sm text-muted-foreground">Security and provisioning event history</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <SearchInput
            value={search}
            onChange={onSearchChange}
            inputRef={searchInputRef}
            placeholder="Search by user, action, or reference ID..."
            ariaLabel="Search audit events"
          />
          <Button variant="outline" size="sm" aria-label="Export audit log">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* QR Filter Banner */}
      {qrFilter && (
        <div className="flex items-center gap-3 px-4 py-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
          <Filter className="h-4 w-4 text-blue-500 shrink-0" />
          <span className="text-sm text-text">
            Filtered by QR: <strong className="font-mono">{qrFilter}</strong>
          </span>
          <button
            onClick={onClearQrFilter}
            className="ml-auto text-sm text-muted-foreground hover:text-text transition-colors flex items-center gap-1"
          >
            <X className="h-3.5 w-3.5" />
            Clear filter
          </button>
        </div>
      )}
    </div>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/audit-management/PageHeader.tsx
git commit -m "feat(audit): add PageHeader with search and QR filter banner (Phase 3)"
```

---

### Task 3.2: Create AuditFilterBar

**Files:**
- Create: `src/frontend/src/components/features/audit-management/AuditFilterBar.tsx`

**Step 1: Write filter bar**

```typescript
/**
 * Audit filter bar — time range select, category select, toggle chips, live indicator.
 * - Time range and category selects drive server-side API filtering
 * - Toggle chips drive client-side row filtering
 * - Live indicator is decorative (no WebSocket in v1)
 */
import { Plus, Check, Clock, User } from 'lucide-react';
import { ToggleChipGroup } from '@azblink/ui';
import type { TimeRange, EventCategory } from '@/types/audit';
import type { ToggleChip } from '@azblink/ui';

interface AuditFilterBarProps {
  timeRange: TimeRange;
  onTimeRangeChange: (tr: TimeRange) => void;
  category: EventCategory | 'all';
  onCategoryChange: (cat: EventCategory | 'all') => void;
  activeChips: Set<string>;
  onChipsChange: (chips: Set<string>) => void;
}

const timeRangeOptions: { value: TimeRange; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: 'Last 7 days' },
  { value: '30d', label: 'Last 30 days' },
  { value: '90d', label: 'Last 90 days' },
  { value: 'all', label: 'All time' },
];

const categoryOptions: { value: EventCategory | 'all'; label: string }[] = [
  { value: 'all', label: 'All Events' },
  { value: 'qr', label: 'QR Provisioning' },
  { value: 'user', label: 'User Management' },
  { value: 'auth', label: 'Authentication' },
  { value: 'config', label: 'Configuration' },
];

const filterChips: ToggleChip[] = [
  { id: 'qr-generated', label: 'QR Generated', icon: <Plus className="h-3.5 w-3.5" /> },
  { id: 'qr-consumed', label: 'QR Consumed', icon: <Check className="h-3.5 w-3.5" /> },
  { id: 'qr-expired', label: 'QR Expired', icon: <Clock className="h-3.5 w-3.5" /> },
  { id: 'user-events', label: 'User Events', icon: <User className="h-3.5 w-3.5" /> },
];

export function AuditFilterBar({
  timeRange,
  onTimeRangeChange,
  category,
  onCategoryChange,
  activeChips,
  onChipsChange,
}: AuditFilterBarProps) {
  return (
    <div className="flex items-center gap-3 flex-wrap">
      {/* Time Range */}
      <div className="flex items-center gap-2">
        <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Time:</label>
        <select
          value={timeRange}
          onChange={(e) => onTimeRangeChange(e.target.value as TimeRange)}
          className="h-8 rounded-md border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] px-2.5 text-sm text-text"
          aria-label="Time range"
        >
          {timeRangeOptions.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>

      {/* Category */}
      <div className="flex items-center gap-2">
        <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Type:</label>
        <select
          value={category}
          onChange={(e) => onCategoryChange(e.target.value as EventCategory | 'all')}
          className="h-8 rounded-md border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] px-2.5 text-sm text-text"
          aria-label="Event category"
        >
          {categoryOptions.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>

      {/* Filter Chips */}
      <ToggleChipGroup
        chips={filterChips}
        activeIds={activeChips}
        onChange={onChipsChange}
      />

      {/* Spacer */}
      <div className="flex-1" />

      {/* Live Indicator (decorative) */}
      <div className="flex items-center gap-1.5" aria-hidden="true">
        <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
        <span className="text-xs text-muted-foreground">Live updates</span>
      </div>
    </div>
  );
}
```

**Step 2: Verify all filters work**

Open `http://localhost:8081/audit-log`. Test:
- Time range select changes URL param and refetches
- Category select changes URL param and refetches
- Chip toggles show/hide rows without refetch
- Live indicator pulses

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/audit-management/AuditFilterBar.tsx
git commit -m "feat(audit): add AuditFilterBar with selects, chips, and live indicator (Phase 3)"
```

---

## Phase 4 — Cross-page nav + responsive + polish + a11y (~2h)

### Task 4.1: Add "View in Audit Log" to QRDetailPanel

**Files:**
- Modify: `src/frontend/src/components/features/qr-management/QRDetailPanel.tsx`

**Step 1: Add import**

Add to existing imports:

```typescript
import { useNavigate } from '@tanstack/react-router';
import { FileText } from 'lucide-react';
```

Note: `useNavigate` may already be imported indirectly — check the file. `FileText` is new.

**Step 2: Add "View in Audit Log" link in Activity Timeline section**

After the timeline entries (inside the Activity Timeline `<div>`), after the closing `</div>` of the `space-y-3` timeline list and before the `No activity yet` fallback's closing `</div>`, add:

```tsx
{/* View full audit log link */}
<button
  onClick={() => navigate({
    to: '/audit-log',
    search: { qr: 'QR-' + code.token_hash.slice(0, 9) },
  })}
  className="mt-3 w-full flex items-center gap-2 p-2 rounded-lg hover:bg-[var(--color-bg-hover)] transition-colors text-left"
>
  <FileText className="h-4 w-4 text-indigo-500" />
  <span className="text-sm text-[var(--color-primary)] hover:underline">View full audit log</span>
</button>
```

Add `const navigate = useNavigate();` inside the component if not already present.

**Step 3: Verify round-trip navigation**

1. Go to `/provisioning/qr-codes`, select a QR code
2. Click "View full audit log" in Activity Timeline
3. Confirm navigates to `/audit-log?qr=QR-XXXX`
4. Click a QR reference ID in the audit table
5. Confirm navigates back to `/provisioning/qr-codes?qrId=QR-XXXX`

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/qr-management/QRDetailPanel.tsx
git commit -m "feat(audit): wire QR→Audit bidirectional cross-page navigation (Phase 4)"
```

---

### Task 4.2: Add responsive breakpoints

**Files:**
- Modify: `src/frontend/src/components/features/audit-management/AuditRow.tsx`
- Modify: `src/frontend/src/components/features/audit-management/AuditList.tsx`

**Step 1: Responsive column hiding in AuditRow**

Update the grid classes in the `<button>` element to hide columns at breakpoints:

```tsx
// Replace the static grid-cols with responsive version
className={cn(
  'group w-full grid grid-cols-[140px_2fr] md:grid-cols-[140px_2fr_120px_120px] lg:grid-cols-[140px_2fr_120px_120px_100px] items-center gap-4 px-5 py-3 text-left transition-colors border-b border-[var(--color-border-subtle)]',
  // ... rest of classes
)}
```

Add responsive visibility to Actor, Target, Reference cells:

```tsx
{/* Actor — hidden below md */}
<div className="hidden md:block text-sm text-muted-foreground truncate">{event.actor}</div>

{/* Target — hidden below md */}
<div className="hidden md:block text-sm text-muted-foreground truncate">{event.target}</div>

{/* Reference — hidden below lg */}
<div className="hidden lg:block min-w-0">...</div>
```

**Step 2: Match column headers in AuditList**

Update `ListPanelColumns` className to match:

```tsx
<ListPanelColumns
  columns={AUDIT_COLUMNS}
  className="grid-cols-[140px_2fr] md:grid-cols-[140px_2fr_120px_120px] lg:grid-cols-[140px_2fr_120px_120px_100px] gap-4 px-5"
/>
```

Note: The `ListPanelColumns` component renders ALL column labels regardless of visibility, so also add responsive classes to individual column labels or accept that hidden columns show headers (a common acceptable pattern — headers act as labels for when the columns become visible).

**Step 3: Keyboard navigation**

Add to `AuditLogPage.tsx` in the `useEffect` for keyboard shortcuts:

```typescript
// Arrow keys for row navigation, Escape to close
useEffect(() => {
  const handler = (e: KeyboardEvent) => {
    if (e.key === 'Escape' && eventId) {
      handleCloseDetail();
    }
  };
  document.addEventListener('keydown', handler);
  return () => document.removeEventListener('keydown', handler);
}, [eventId, handleCloseDetail]);
```

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/audit-management/
git commit -m "feat(audit): responsive breakpoints + keyboard nav (Phase 4)"
```

---

### Task 4.3: Add sidebar navigation entry

**Files:**
- Search for the sidebar/navigation component and add an entry for Audit Log

**Step 1: Find and update sidebar**

Find the sidebar navigation component (likely in `src/frontend/src/components/layout/` or similar). Add an entry:

```tsx
{ to: '/audit-log', label: 'Audit Log', icon: FileText }
```

Place it after the QR-related entries (it's a top-level admin page).

**Step 2: Commit**

```bash
git add <sidebar-file>
git commit -m "feat(audit): add Audit Log to sidebar navigation (Phase 4)"
```

---

### Task 4.4: Accessibility pass

**Files:**
- Modify: `src/frontend/src/components/features/audit-management/AuditList.tsx`
- Modify: `src/frontend/src/components/features/audit-management/AuditLogPage.tsx`

**Step 1: Add aria attributes**

In `AuditList.tsx`:
- Add `aria-live="polite"` to the event count in `ListPanelHeader`
- The `Pagination` primitive already handles `aria-current="page"` and `aria-label`

In `AuditLogPage.tsx`:
- Already has `aria-current` on selected row (via `AuditRow`)
- Already has `aria-label="Close detail panel"` on close button
- Already has `Cmd+K` shortcut wired

**Step 2: Add data-testid attributes**

Review all components and ensure `data-testid` attributes exist on:
- `audit-table` (ListPanel)
- `audit-row-{id}` (each row)
- `audit-detail-panel` (detail panel)
- Filter selects, search input, export button

**Step 3: Final commit**

```bash
git add src/frontend/src/components/features/audit-management/
git commit -m "feat(audit): accessibility pass — aria attrs, data-testid (Phase 4)"
```

---

## Final Verification

### Smoke tests to run manually:

1. **Page loads:** Navigate to `/audit-log` — events render in table
2. **Pagination:** Click page 2 — new events load
3. **Detail panel:** Click a row — detail panel opens with correct data
4. **Close panel:** Click X or press Escape — panel closes, row deselects
5. **Search:** Type "alice" — results filter after 300ms debounce
6. **Time range:** Change to "Today" — fewer results
7. **Category:** Change to "QR Provisioning" — only QR events
8. **Chips:** Toggle "QR Consumed" off — consumed events disappear from current page
9. **QR cross-ref (Audit→QR):** Click a QR- reference — navigates to QR codes page
10. **QR cross-ref (QR→Audit):** In QR detail, click "View full audit log" — navigates to audit page with banner
11. **QR filter banner:** Verify banner shows, search pre-filled, clear removes filter
12. **Responsive:** Resize window — columns hide at 768px, panel hides at 1100px
13. **Cmd+K:** Press Cmd+K — search input focuses

### Run automated tests:

```bash
just test-quick
```

Expected: All existing tests pass. No new integration tests required for Phase 1 (existing audit endpoint tests cover backend).

---

## Summary

| Phase | Tasks | Files Created | Files Modified | Commits |
|-------|-------|--------------|---------------|---------|
| 0 | 7 | 10 | 4 | 7 |
| 1 | 3 | 4 | 0 | 3 |
| 2 | 1 | 1 | 0 | 1 |
| 3 | 2 | 2 | 0 | 2 |
| 4 | 4 | 0 | 4+ | 4 |
| **Total** | **17** | **17** | **8+** | **17** |
