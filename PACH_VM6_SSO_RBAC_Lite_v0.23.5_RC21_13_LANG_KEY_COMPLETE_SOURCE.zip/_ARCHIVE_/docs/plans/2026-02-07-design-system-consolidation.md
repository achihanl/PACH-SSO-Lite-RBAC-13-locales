# Design System Consolidation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Consolidate the dual-token systems, update fonts, clean up dead config, and verify the full migration works end-to-end.

**Architecture:** The frontend uses Tailwind CSS 4 with a `@theme` block in `globals.css` that generates utility classes (`bg-background`, `text-text`, etc.) from CSS custom properties. The `@azblink/ui` design system defines its own tokens in `tokens/tokens.css` with different variable names (`--color-bg-primary`, `--color-text-primary`). Rather than replacing 112 Tailwind class usages across 23 files, we bridge the two systems: `globals.css @theme` variables point to `@azblink/ui` token variables. Dark/light mode switching is handled by `tokens.css` + `ThemeProvider`, eliminating the duplicate dark mode blocks in `globals.css`.

**Tech Stack:** Tailwind CSS 4, CSS Custom Properties, Vite 6, @azblink/ui (Base UI + CSS Modules)

---

## Context — What Was Done

The migration from shadcn/ui to @azblink/ui is code-complete:
- All 20+ component exports built (Button, Card, Table, Badge, Checkbox, AlertDialog, DropdownMenu, Tooltip, ThemeProvider, etc.)
- All 23 consumer files migrated from `@/components/ui/*` → `@azblink/ui`
- All `asChild` → `render` prop conversions done (4 sites)
- All variant mappings applied (`default→primary`, `destructive→danger`, `secondary→muted`)
- Old `src/frontend/src/components/ui/` directory deleted
- Radix dependencies removed from `package.json`
- ThemeProvider wired into `main.tsx`, `globals.css` updated to `[data-theme="dark"]`

**What remains is consolidation and cleanup:**

| Issue | Impact |
|---|---|
| Two independent token systems (globals.css vs tokens.css) | Components and Tailwind classes use different CSS variables — visual inconsistency |
| `tokens.css` not imported in frontend | @azblink/ui component styles reference undefined tokens at runtime |
| Fonts still Inter + Fira Code in `index.html` | Design system specifies Outfit + JetBrains Mono |
| `components.json` (shadcn CLI config) still exists | Dead file, confusing |
| Vite `manualChunks` references deleted packages | Build warning potential |
| `CLAUDE.md` still references shadcn/ui and old paths | Developer confusion |
| No npm install after dependency changes | `node_modules` has stale Radix packages |

---

### Task 1: Import @azblink/ui tokens and component CSS

**Files:**
- Modify: `src/frontend/src/styles/globals.css`

**Step 1: Add token and component CSS imports at the top of globals.css**

The `@azblink/ui` package exports two CSS files:
- `tokens/tokens.css` — design token custom properties (dark-first, with `[data-theme="light"]` override)
- `dist/index.css` — compiled CSS Module styles for components

Both must be imported BEFORE the Tailwind `@theme` block so token variables are available.

```css
@import "tailwindcss";
@import "@azblink/ui/tokens.css";
@import "@azblink/ui/styles.css";
```

**Step 2: Verify imports resolve**

Run: `cd src/frontend && npx vite build 2>&1 | head -20`
Expected: Build succeeds, no "could not resolve" errors for the CSS imports

If Vite can't resolve `@azblink/ui/tokens.css`, use the relative workspace path instead:
```css
@import "./packages/azblink-ui/tokens/tokens.css";
@import "./packages/azblink-ui/dist/index.css";
```

**Step 3: Commit**

```bash
git add src/frontend/src/styles/globals.css
git commit -m "feat(frontend): import @azblink/ui tokens and component CSS"
```

---

### Task 2: Bridge globals.css @theme to design system tokens

**Files:**
- Modify: `src/frontend/src/styles/globals.css`

The `@theme` block generates Tailwind utility classes from CSS custom properties. Currently it defines hardcoded color values. We need to redirect these to reference the design system token variables from `tokens.css`.

**Mapping table — old Tailwind tokens → design system tokens:**

| Tailwind `@theme` variable | Design system token |
|---|---|
| `--color-background` | `var(--color-bg-primary)` |
| `--color-surface` | `var(--color-bg-elevated)` |
| `--color-muted` | `var(--color-bg-tertiary)` |
| `--color-muted-hover` | `var(--color-bg-hover)` |
| `--color-muted-foreground` | `var(--color-text-muted)` |
| `--color-border` | `var(--color-border-default)` |
| `--color-text` | `var(--color-text-primary)` |
| `--color-text-muted` | `var(--color-text-muted)` |
| `--color-text-secondary` | `var(--color-text-secondary)` |
| `--color-icon-muted` | `var(--color-text-muted)` |
| `--color-primary` | `var(--color-primary)` |
| `--color-primary-foreground` | `#FFFFFF` (keep hardcoded — tokens don't define foreground) |
| `--color-accent` | `var(--color-primary)` |
| `--color-accent-foreground` | `#FFFFFF` |
| `--color-accent-muted` | `var(--color-blue-bg)` |
| `--color-accent-light` | `var(--color-blue-500)` |
| `--color-success` | `var(--color-success)` |
| `--color-success-light` | `var(--color-green-bg)` |
| `--color-success-foreground` | `var(--color-green-600)` |
| `--color-warning` | `var(--color-warning)` |
| `--color-warning-light` | `var(--color-amber-bg)` |
| `--color-warning-foreground` | `var(--color-amber-600)` |
| `--color-destructive` | `var(--color-danger)` |
| `--color-destructive-light` | `var(--color-red-bg)` |
| `--color-destructive-foreground` | `var(--color-red-600)` |
| `--color-ring` | `var(--color-primary)` |
| `--color-popover` | `var(--color-bg-elevated)` |
| `--color-popover-foreground` | `var(--color-text-primary)` |
| `--color-tooltip` | `var(--color-bg-hover)` |
| `--color-tooltip-foreground` | `var(--color-text-primary)` |
| `--color-secondary` | `var(--color-text-secondary)` |
| `--color-secondary-foreground` | `#FFFFFF` |

**Step 1: Replace the @theme color block**

Replace the hardcoded color values in the `@theme` block with `var()` references to design system tokens. Keep spacing, radius, shadow, z-index, and typography tokens since they map to Tailwind utility classes and the design system uses different variable names for those.

```css
@theme {
  /* Colors — bridged from @azblink/ui design tokens */
  --color-primary: var(--color-primary);
  --color-primary-foreground: #FFFFFF;
  --color-secondary: var(--color-text-secondary);
  --color-secondary-foreground: #FFFFFF;
  --color-accent: var(--color-primary);
  --color-accent-light: var(--color-blue-500);
  --color-accent-foreground: #FFFFFF;
  --color-success: var(--color-success);
  --color-success-light: var(--color-green-bg);
  --color-success-foreground: var(--color-green-600);
  --color-warning: var(--color-warning);
  --color-warning-light: var(--color-amber-bg);
  --color-warning-foreground: var(--color-amber-600);
  --color-destructive: var(--color-danger);
  --color-destructive-light: var(--color-red-bg);
  --color-destructive-foreground: var(--color-red-600);
  --color-muted: var(--color-bg-tertiary);
  --color-muted-foreground: var(--color-text-muted);
  --color-border: var(--color-border-default);
  --color-background: var(--color-bg-primary);
  --color-surface: var(--color-bg-elevated);
  --color-text: var(--color-text-primary);
  --color-text-muted: var(--color-text-muted);

  /* Additional tokens for component coverage */
  --color-muted-hover: var(--color-bg-hover);
  --color-text-secondary: var(--color-text-secondary);
  --color-icon-muted: var(--color-text-muted);
  --color-accent-muted: var(--color-blue-bg);
  --color-tooltip: var(--color-bg-hover);
  --color-tooltip-foreground: var(--color-text-primary);
  --color-ring: var(--color-primary);
  --color-popover: var(--color-bg-elevated);
  --color-popover-foreground: var(--color-text-primary);

  /* Spacing, radius, shadows, z-index, typography — keep as-is */
  /* ... existing values unchanged ... */
}
```

**Step 2: Remove duplicate dark mode blocks**

Delete BOTH dark mode blocks:
1. The `@media (prefers-color-scheme: dark)` block — no longer needed because `tokens.css` defines dark as default, and `ThemeProvider` sets `data-theme` attribute
2. The `[data-theme="dark"]` block — same reason, `tokens.css` already handles this

The `@theme` bridge variables now automatically resolve correctly because they point to `tokens.css` variables which change based on `[data-theme="light"]`.

**Step 3: Verify**

Run: `cd src/frontend && npx tsc --noEmit && npx vite build`
Expected: Build passes, CSS size should decrease slightly (removed duplicate dark mode definitions)

**Step 4: Commit**

```bash
git add src/frontend/src/styles/globals.css
git commit -m "refactor(frontend): bridge Tailwind tokens to @azblink/ui design system"
```

**Important note for the implementer:** Tailwind CSS 4's `@theme` block resolves `var()` references at build time. If Tailwind can't resolve `var(--color-bg-primary)` because it's defined in a separate file (`tokens.css`), you may need to keep the hardcoded values in `@theme` and instead use a `@layer` override approach:

```css
@theme {
  /* Keep hardcoded light-mode defaults for Tailwind class generation */
  --color-background: #F8FAFC;
  /* ... */
}

/* Then override at runtime via tokens */
:root {
  --color-background: var(--color-bg-primary);
}
```

Test which approach Tailwind CSS 4 supports before committing. Check Context7 for `@theme var()` support.

---

### Task 3: Update fonts in index.html and globals.css

**Files:**
- Modify: `src/frontend/index.html`
- Modify: `src/frontend/src/styles/globals.css`

The design system specifies Outfit (sans-serif) and JetBrains Mono (monospace). The frontend still loads Inter and Fira Code.

**Step 1: Update Google Fonts link in index.html**

```html
<!-- Old -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet" />

<!-- New -->
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
```

**Step 2: Update font-family in globals.css @theme block**

```css
/* Old */
--font-sans: 'Inter', system-ui, sans-serif;
--font-mono: 'Fira Code', monospace;

/* New — matches tokens.css */
--font-sans: 'Outfit', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
--font-mono: 'JetBrains Mono', 'Fira Code', 'SF Mono', Consolas, monospace;
```

**Step 3: Visual check**

Run: `cd src/frontend && npx vite build && npx vite preview`
Expected: App loads with new fonts. Check for layout shifts on:
- Dashboard page (stat cards, buttons)
- Login page (form labels, inputs)
- Sidebar (nav items)

**Step 4: Commit**

```bash
git add src/frontend/index.html src/frontend/src/styles/globals.css
git commit -m "refactor(frontend): migrate fonts to Outfit + JetBrains Mono"
```

---

### Task 4: Update Vite config and delete shadcn config

**Files:**
- Modify: `src/frontend/vite.config.ts`
- Delete: `src/frontend/components.json`

**Step 1: Update vendor chunk config**

The `manualChunks` config references `lucide-react` and `sonner` in `vendor-ui`. Since @azblink/ui is a workspace package, Vite inlines it. No change needed for @azblink/ui. But verify the chunks still make sense.

Current chunks:
```javascript
manualChunks: {
  'vendor-react': ['react', 'react-dom'],
  'vendor-tanstack': ['@tanstack/react-query', '@tanstack/react-router'],
  'vendor-ui': ['lucide-react', 'sonner'],
}
```

These are still correct — `lucide-react` and `sonner` are the remaining UI vendor deps.

**Step 2: Delete shadcn CLI config**

```bash
rm src/frontend/components.json
```

This file configured the `shadcn` CLI tool which is no longer used.

**Step 3: Verify build**

Run: `cd src/frontend && npx vite build`
Expected: Build succeeds with similar chunk sizes. No warnings about missing modules.

**Step 4: Commit**

```bash
git add -A src/frontend/components.json src/frontend/vite.config.ts
git commit -m "chore(frontend): delete shadcn config, verify Vite chunks"
```

---

### Task 5: Run npm install to prune stale dependencies

**Files:**
- Root and workspace `node_modules`

**Step 1: Clean install**

```bash
cd /path/to/repo && npm install
```

This will:
- Remove the 6 Radix packages from node_modules
- Remove `class-variance-authority`, `clsx`, `tailwind-merge` from the frontend workspace (still in @azblink/ui workspace)
- Verify all remaining deps resolve correctly

**Step 2: Verify no missing deps**

Run: `cd src/frontend && npx tsc --noEmit && npx vite build`
Expected: Both pass clean

**Step 3: Commit lockfile if changed**

```bash
git add package-lock.json
git commit -m "chore: prune stale dependencies from lockfile"
```

---

### Task 6: Update CLAUDE.md

**Files:**
- Modify: `CLAUDE.md`

**Step 1: Update the "Frontend Development" section**

Replace references to shadcn/ui with @azblink/ui:

```markdown
**Stack:** Vite 7, React 19, TanStack Router, TanStack Query, Zustand, @azblink/ui (Base UI + CSS Modules), Tailwind CSS 4
```

Update key directories:
```markdown
- `azblink-ui/` - @azblink/ui design system (npm workspace package)
- `azblink-ui/primitives/` - Component implementations (Button, Card, Table, etc.)
- `azblink-ui/tokens/` - Design tokens (CSS custom properties)
- `azblink-ui/providers/` - ThemeProvider
```

Remove the `just ui-add` command (shadcn CLI no longer relevant).

Add note about component imports:
```markdown
All UI components import from `@azblink/ui`:
```tsx
import { Button, Card, Badge, cn } from '@azblink/ui';
```
Do NOT create components in `src/frontend/src/components/ui/` — that directory was deleted.
```

**Step 2: Update the MCP Tools section**

The Serena section is fine. Context7 section should list @azblink/ui's Base UI:
```markdown
**Use Context7 for:** React 19, TanStack Router/Query, Zustand, **Base UI (@base-ui/react)**, Tailwind CSS 4, Vite 7
```

**Step 3: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: update CLAUDE.md for @azblink/ui migration"
```

---

### Task 7: Update migration plan status

**Files:**
- Modify: `docs/plans/2026-02-07-design-system-migration.md`

**Step 1: Update status line**

Change:
```markdown
> **Date:** 2026-02-07 | **Timeline:** 2 weeks | **Status:** Phase 1 complete, Phase 2+ pending
```
To:
```markdown
> **Date:** 2026-02-07 | **Timeline:** 2 weeks | **Status:** COMPLETE — all tasks executed, consolidation in progress
```

**Step 2: Add completion notes at the bottom**

```markdown
---

## Execution Log

**Completed 2026-02-07:**
- Tasks 1-8: Component gaps filled, new components built, exports updated
- Tasks 9-16: All route, feature, and layout files migrated
- Tasks 19-20: Radix deps removed, shadcn dir deleted
- Task 16: ThemeProvider integrated, ui-store theme state removed
- Task 17: globals.css updated to use `[data-theme="dark"]` attribute

**Deviations from plan:**
- `outline` added as a real Button/Badge variant (not mapped to `secondary`)
- `icon` added as a real Button size (not approximated with `sm` + className)
- This eliminated variant mapping work across 13+ files
- Token consolidation deferred to separate plan: `2026-02-07-design-system-consolidation.md`
```

**Step 3: Commit**

```bash
git add docs/plans/2026-02-07-design-system-migration.md
git commit -m "docs: mark design system migration plan as complete"
```

---

### Task 8: E2E smoke test

**Prerequisites:** Stack must be running (`just up-bg`)

**Step 1: Start the dev server**

```bash
cd src/frontend && npm run dev
```

**Step 2: Manual smoke test checklist**

Open http://localhost:3000 and verify each page renders without console errors:

| Page | Key Components | Check |
|---|---|---|
| `/login` | Button, Input, Label, Checkbox, Card | Form renders, submit button works |
| `/` (Dashboard) | StatCard, HealthStatus, Button, Card | Stats load, quick action buttons visible |
| `/directory/users` | Button (render prop → Link), Input, UserTable | "New User" button navigates, table renders |
| `/directory/users/new` | Card, Input, Label, Button | Form renders, cancel/submit buttons work |
| `/directory/users/:uid` | Card, Badge, Button (render prop → Link), Skeleton | Profile loads, QR button has link |
| `/directory/groups` | Button, Card, Input, Skeleton | Group cards render |
| `/directory/orgs` | Button, Card, cn(), Skeleton | Org tree expands/collapses |
| `/provisioning/qr-generator` | Card, Input, Button, cn() | User list filters, QR section loads |
| `/provisioning/tokens` | Table, Badge, Button, cn() | Token table renders |
| `/my-profile` | Card, Badge (variant=muted), Button | Profile data loads |
| `/settings` | Card, Skeleton | System status renders |
| Sidebar (collapsed) | Tooltip | Hover tooltips appear |
| Profile dropdown | DropdownMenu, RadioGroup | Theme toggle works (dark/light/system) |
| Session expired | AlertDialog | Trigger via API (or mock) |

**Step 3: Check browser console**

Expected: No React warnings about unknown props, no CSS resolution errors, no hydration mismatches.

**Step 4: Run existing tests if available**

```bash
just test-quick
```

**Step 5: Commit any fixes**

```bash
git add -A
git commit -m "test: fix issues found during design system smoke test"
```

---

## Execution Order

```
Task 1 (import CSS) ──────────────── must be first
Task 2 (bridge tokens) ─────────── depends on Task 1
Task 3 (fonts) ──────────────────── independent
Task 4 (Vite + shadcn config) ──── independent
Task 5 (npm install) ───────────── after Task 4 (package.json finalized)
Task 6 (CLAUDE.md) ─────────────── independent
Task 7 (plan status) ───────────── independent
Task 8 (E2E smoke test) ────────── after ALL other tasks
```

**Parallelizable:** Tasks 3, 4, 6, 7 can all run in parallel.

## Risk Register

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| Tailwind CSS 4 `@theme` can't resolve `var()` from imported CSS | 40% | High | Use hardcoded values in @theme + runtime `:root` override layer |
| Outfit font metrics differ from Inter causing layout shifts | 20% | Medium | Compare x-height and cap-height; add `size-adjust` if needed |
| @azblink/ui dist/index.css not found by Vite | 15% | Medium | Use relative workspace path instead of package path |
| Token naming collision between systems | 10% | Low | The `@theme` block scopes Tailwind vars; tokens.css uses `:root` |
