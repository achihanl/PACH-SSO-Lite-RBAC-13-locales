# UED Sync Review Fixes — Design Document

**Date:** 2026-02-13
**Scope:** 9 of 10 review suggestions from `2026-02-13-ued-sync-review-suggestions.md` (I2 deferred)
**Baseline:** 333 tests passing, 40 UED-specific

## Decisions

| Item | Decision |
|------|----------|
| S1 async pattern | `asyncio.run()` — no new dependency |
| S4 column type | PostgreSQL `UUID(as_uuid=False)` — match SQL migration |
| S6 auth test | Rename + comment — honest about what test verifies |
| S3 mock approach | `unittest.mock.patch` — no new dependency |
| I2 | Deferred — requires UED instance awareness |

## Implementation Sections

### Section 1 — Trivial Fixes (S7, S8, S2)

- **S7:** Add clarifying comment before PATCH update filter in `main.py` ~line 3120
  - `# Filter out None (unset) fields; False/0/"" are valid updates and pass through`
- **S8:** Update design doc SQL example to include `ON DELETE CASCADE` matching actual migration
  - File: `docs/plans/2026-02-13-ued-sync-integration-design.md`
- **S2:** Remove dead code from `tests/test_ued_sync_client.py`
  - Delete `run_async()` helper (lines 18-20)
  - Remove unused imports: `AsyncMock`, `patch`, `asyncio`

### Section 2 — Deprecation + Type Fixes (S1, S4)

- **S1:** Replace `asyncio.get_event_loop().run_until_complete()` with `asyncio.run()` in `tests/test_sync_worker.py`
  - 3 locations: lines ~91, 111, 131
- **S4:** Change `request_id` column from `String(36)` to `UUID(as_uuid=False)` in `orgdb.py`
  - Import `UUID` from `sqlalchemy.dialects.postgresql`

### Section 3 — Performance (C2)

- **C2:** Cache Fernet instance in `ued_crypto.py`
  - Module-level `_fernet_cache` and `_fernet_key_cache` variables
  - Auto-invalidates when `UED_ENCRYPTION_KEY` env var changes (test-safe)

### Section 4 — Feature Additions (S5, S6)

- **S5:** Add `offset: int = 0` parameter to sync-events list endpoint
  - `main.py`: add `offset` query param, pass through to OrgDB
  - `orgdb.py`: add `offset` param to `list_sync_events()`, chain `.offset(offset)`
  - New test in `test_ued_orgdb.py` for offset pagination
- **S6:** Rename `test_requires_auth` → `test_endpoint_accessible`
  - Update docstring, change assertion to `assert resp.status_code == 200`

### Section 5 — New Tests (S3)

- **S3:** Add 5 unit tests for `UedSyncClient.send()` in `tests/test_ued_sync_client.py`
  - `test_send_timeout` → TIMEOUT error, retryable
  - `test_send_connection_error` → CONNECTION_ERROR, retryable
  - `test_send_server_error_500` → retryable=True
  - `test_send_200_ok_false` → extract error fields from response body
  - `test_send_200_ok_true` → success path
  - Uses `unittest.mock.patch` on `httpx.AsyncClient.post`, `asyncio.run()` to execute

## Verification

- Run `pytest tests/ -v --tb=short` after each section
- Expected final: 338+ tests (333 existing + 5 new from S3 + ~1 from S5), 0 failures
