# Production Deployment Plan

**Date:** 2026-02-13
**Supersedes:** `docs/archive/2026-01-22-production-readiness-assessment.md` (v1.0 spec, ~38%)
**Spec Reference:** `specs/v2.0/Directory_Portal_Specification_v4.1.md`
**Overall Readiness:** ~65-70%

---

## Executive Summary

Since the Jan 2026 assessment, all three P0 blockers have been resolved (rate limiting, one-time token enforcement, user termination). The addition of UED Sync as an internal microservice introduces new production surface area around encryption, per-tenant isolation, and async event processing.

**What's production-ready:**
- Rate limiting (slowapi + Redis)
- One-time token enforcement (consumed/expired/revoked tracking)
- User termination flow (LDAP disable + token revocation + audit trail)
- Health endpoints (`/api/health`, `/api/health/deep`)
- Audit logging (QR issuance, auth failures, user lifecycle, terminations)
- CORS lockdown (configurable via `CORS_ORIGINS`)
- UED Sync stateless provisioner (health check, rate limiting, API key auth)

**What needs work:**
- Secrets management (still env var-based, needs vault integration)
- LDAP TLS (disabled in dev, required in prod)
- Database migration tooling (ad-hoc SQL scripts, no versioned runner)
- Production docker-compose or orchestration config
- Monitoring/alerting infrastructure
- Backup/restore procedures

---

## 1. Service Architecture (Production)

### Services

| Service | Role | Replicas | Scaling Model |
|---------|------|----------|---------------|
| **directory-api** | Main API (FastAPI + uvicorn) | 2+ | Horizontal (stateless, shared DB) |
| **directory-ui** | React SPA (static build) | 1+ (CDN/nginx) | Static files, infinitely cacheable |
| **ued-sync** | LDAP provisioner (FastAPI) | 1 per tenant | Horizontal per-tenant isolation |
| **postgresql** | Primary datastore | 1 (primary) | Vertical + read replicas |
| **redis** | Rate limiting, caching | 1+ | Sentinel/cluster for HA |
| **openldap** | AZBlink directory LDAP | 1+ | Replication for reads |
| **traefik** *(or nginx/ALB)* | Reverse proxy, TLS termination | 2+ | Active-passive or active-active |

### Network Topology (Production)

```
Internet
    │
    └─→ Load Balancer / Reverse Proxy (TLS termination)
         │
         ├─→ /api/*    → directory-api (port 8000)
         ├─→ /*        → directory-ui (static files)
         │
         └─→ Private Subnet (no public access)
              ├─→ postgresql:5432
              ├─→ redis:6379
              ├─→ openldap:389 (LDAPS:636 between services)
              └─→ ued-sync:8000 (internal only, per-tenant)
```

### UED Sync Deployment Model

```
directory-api
    │
    ├─→ tenant_ldap_configs (PostgreSQL)
    │     tenant_a: ued_api_url=http://ued-sync-a:8000, ued_api_key=***
    │     tenant_b: ued_api_url=http://ued-sync-b:8000, ued_api_key=***
    │
    ├─→ SyncWorker (in-process background task)
    │     Polls sync_events table, dispatches to per-tenant UED instances
    │
    ├─→ ued-sync-a:8000 (Tenant A's UC LDAP provisioner)
    └─→ ued-sync-b:8000 (Tenant B's UC LDAP provisioner)
```

- Each UED Sync instance is stateless: config passed per-request
- Blast radius: one tenant's UED failure doesn't affect others
- Can run same image with different `UED_API_KEY` per instance

---

## 2. Secrets Management

### Current State (Dev)

All secrets in `.env` file. Acceptable for local dev, not for production.

### Production Requirements

| Secret | Current | Production Target |
|--------|---------|-------------------|
| `LDAP_BIND_PW` | `adminpassword` | Vault/SSM, rotated quarterly |
| `POSTGRES_PASSWORD` | `azblink_directory` | Vault/SSM, unique per env |
| `JWT_SECRET` | `dev_jwt_secret_...` | `openssl rand -hex 32`, Vault |
| `ORG_QR_SIGNING_SECRET` | `dev_signing_secret_...` | Vault, ≥32 bytes random |
| `UED_API_KEY` | `dev-ued-api-key` | Unique per tenant, Vault |
| `UED_ENCRYPTION_KEY` | *(empty)* | Fernet key, Vault, backup stored separately |
| `CORS_ORIGINS` | `localhost:8081` | Explicit production domain(s) |

### Encryption Key Lifecycle (UED)

- `UED_ENCRYPTION_KEY` encrypts tenant LDAP passwords and API keys in PostgreSQL
- **Rotation:** Re-encrypt all `tenant_ldap_configs` rows with new key, then swap env var
- **Backup:** Store key backup in separate vault path from encrypted data
- **Loss:** If key lost, tenant configs must be re-entered manually (no recovery)

---

## 3. Docker Compose (Production Variant)

A production docker-compose should differ from dev in these ways:

| Aspect | Dev (`docker-compose.yml`) | Production |
|--------|---------------------------|------------|
| **Images** | Built from source (`build:`) | Pre-built tags (`image: ghcr.io/...`) |
| **Hot reload** | Enabled (volume mounts + `--reload`) | Disabled (no source mounts) |
| **UI** | Vite dev server | Nginx serving `dist/` static build |
| **Workers** | Single uvicorn process | Gunicorn with 2-4 uvicorn workers |
| **Ports** | Host-mapped (8081, 5433, 1390, 6380) | Internal only (except LB) |
| **TLS** | None | Required everywhere (LDAPS, Redis TLS, HTTPS) |
| **Seed** | Runs on startup | Not included (manual or migration-based) |
| **Logging** | stdout (human-readable) | JSON structured → log aggregator |
| **Health checks** | Basic (`/health`) | Deep checks + external monitoring |
| **Restart policy** | `unless-stopped` | `always` + orchestrator restart |
| **Resources** | Unlimited | CPU/memory limits per container |
| **Volumes** | Local Docker volumes | Managed persistent storage |

### Recommended Production Compose Structure

```yaml
# deploy/prod/docker-compose.yml (sketch — not yet created)
services:
  directory-api:
    image: ghcr.io/azblink/directory-api:${TAG}
    command: ["gunicorn", "main:app", "-k", "uvicorn.workers.UvicornWorker", "-w", "4", "-b", "0.0.0.0:8000"]
    environment:
      - LDAP_URI=ldaps://openldap:636
      - REQUIRE_OIDC_AUTH=true
      - ALLOW_BOOTSTRAP_WITHOUT_OIDC=false
    deploy:
      resources:
        limits: { cpus: "2", memory: "512M" }
    restart: always

  directory-ui:
    image: ghcr.io/azblink/directory-ui:${TAG}
    # nginx serving pre-built static files

  ued-sync:
    image: ghcr.io/azblink/ued-sync:${TAG}
    command: ["gunicorn", "ued_sync.main:app", "-k", "uvicorn.workers.UvicornWorker", "-w", "2", "-b", "0.0.0.0:8000"]
    environment:
      - UED_API_KEY=${UED_API_KEY}
      - DEBUG=false
    deploy:
      resources:
        limits: { cpus: "1", memory: "256M" }
    restart: always
    # No ports: section — internal only
```

---

## 4. Readiness Checklist

### Resolved (since Jan 2026 assessment)

| # | Item | Resolution | Verified |
|---|------|------------|----------|
| P0-1 | Rate limiting | `rate_limit.py` + slowapi + Redis | `tests/test_security.py` |
| P0-2 | One-time token enforcement | `consumed`/`consumed_at` columns, `validate_and_consume_token()` | `tests/test_provisioning.py` |
| P0-3 | User termination flow | `POST /api/users/{uid}/terminate` + audit | Integration tests |
| P1-5 | Health check endpoints | `/api/health` + `/api/health/deep` | `tests/test_health.py` |
| P1-7 | CORS lockdown | `CORS_ORIGINS` env var (no more `allow_origins=["*"]`) | `config.py` |
| P1-8 | Audit tables | `qr_issuance_audit`, `user_lifecycle_audit`, `auth_failure_audit` | `orgdb.py` |
| P1-9 | Redis infrastructure | In docker-compose, used by rate limiter | Running |

### Remaining Work

| # | Item | Priority | Effort | Blocker |
|---|------|----------|--------|---------|
| R1 | **Production docker-compose** | P0 | Medium | None — create `deploy/prod/` |
| R2 | **LDAP TLS (LDAPS)** | P0 | Medium | Cert provisioning |
| R3 | **Secrets management** | P0 | Medium | Vault/SSM infrastructure |
| R4 | **CI/CD pipeline** | P1 | Medium | Container registry setup |
| R5 | **Database migration runner** | P1 | Small | Choose tool (alembic vs custom) |
| R6 | **Monitoring + alerting** | P1 | Medium | Choose stack (Prometheus/Grafana, Datadog, etc.) |
| R7 | **Backup/restore procedures** | P1 | Medium | Storage + scheduling |
| ~~R8~~ | ~~QR schema alignment~~ | ~~P2~~ | ~~Small~~ | **RESOLVED** — spec updated to match implementation (hex sig, tenant field) |
| R9 | **Break-glass file permissions** | P2 | Small | Container user setup |
| R10 | **Load testing** | P2 | Medium | R1 required first |

### QR Schema Alignment (R8 — Resolved)

Both gaps identified in the initial review have been fixed via spec updates (no code changes):
- **`tenant` field:** Added to spec's UC payload examples to match implementation
- **Signature encoding:** Spec JSON example corrected from "base64-encoded" to "hex-encoded" (matching the spec's own reference Python code which uses `.hexdigest()`)

---

## 5. UED Sync Production Checklist

| Item | Status | Notes |
|------|--------|-------|
| Health endpoint (`/health`) | Done | Wire to LB/orchestrator |
| API key authentication | Done | `X-API-Key` header, per-tenant |
| Rate limiting | Done | slowapi, configurable per key |
| Structured logging | Done | JSON when `DEBUG=false` |
| Request tracing | Done | `X-Request-ID` header propagation |
| Fernet encryption for tenant secrets | Done | `UED_ENCRYPTION_KEY` required |
| Retry with exponential backoff | Done | 5s × 3^attempt, 1hr cap, 10 max |
| Event retention/pruning | Done | 90 days for completed, indefinite for failed |
| Gunicorn production server | TODO | Replace `--reload` with gunicorn workers |
| Per-tenant instance isolation | TODO | Separate containers per tenant |
| Encryption key rotation procedure | TODO | Re-encrypt migration script |
| UED API key rotation procedure | TODO | Update tenant config + restart UED instance |
| Monitoring (sync event failure rate) | TODO | Alert on failed events backlog |
| Horizontal scaling documentation | TODO | Document per-tenant deployment |

---

## 6. Deployment Environments

### Recommended Environment Progression

| Environment | Purpose | Infrastructure | Data |
|-------------|---------|----------------|------|
| **dev** | Local development | `deploy/dev/docker-compose.yml` | Seeded demo data |
| **staging** | Pre-production validation | `deploy/prod/` with staging secrets | Anonymized production snapshot |
| **production** | Live service | `deploy/prod/` with prod secrets | Real tenant data |

### Day-0 Deployment Steps (New Production Instance)

1. Provision infrastructure (host, storage, networking)
2. Set up secrets in vault (all items from §2)
3. Deploy `deploy/prod/docker-compose.yml` with production image tags
4. Run database schema init (API auto-creates tables on startup)
5. Apply any pending migrations from `migrations/`
6. Bootstrap first admin user via `ALLOW_BOOTSTRAP_WITHOUT_OIDC=true`
7. Disable bootstrap: set `ALLOW_BOOTSTRAP_WITHOUT_OIDC=false`, restart API
8. Enable OIDC: set `REQUIRE_OIDC_AUTH=true`, configure Authentik
9. *(Optional)* Configure UED Sync tenants via admin API
10. Smoke test: health endpoints, login, user CRUD, QR generation

### Day-N Operations

- **Upgrades:** Pull new image tags → rolling restart (zero-downtime for API, brief for UED Sync)
- **Schema changes:** Apply SQL migrations before API upgrade (`migrations/` directory)
- **Key rotation:** Re-encrypt tenant configs with new `UED_ENCRYPTION_KEY`, then swap env var
- **Tenant onboarding:** `POST /api/ued/configs` with tenant LDAP details + deploy new UED Sync instance
- **Incident response:** Check `/api/ued/sync-events` for failed events, `POST retry-all-failed`

---

## 7. Risk Matrix

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| UED Sync down | Medium | Low (async, retries) | Health checks, auto-restart, retry backoff |
| Encryption key lost | Low | High (tenant config loss) | Vault backup, documented recovery |
| LDAP connection pool exhaustion | Medium | High (auth failures) | Connection pooling, timeout tuning |
| Sync event backlog growth | Medium | Medium (stale provisioning) | Monitor failed count, alert threshold |
| QR replay attack | Low | Medium | Nonce + expiry + one-time consumption |
| Tenant LDAP misconfiguration | Medium | Low (per-tenant only) | `POST /api/ued/configs/{id}/test` before enabling |

---

## References

- v2.0 Spec: `specs/v2.0/Directory_Portal_Specification_v4.1.md`
- UED Sync Design: `docs/plans/2026-02-13-ued-sync-integration-design.md`
- Monorepo Design: `docs/plans/2026-02-13-monorepo-consolidation-design.md`
- Previous Assessment: `docs/archive/2026-01-22-production-readiness-assessment.md`
- Dev Deployment Spec: `deploy/dev/DEPLOYMENT_SPEC.md`
