# Org Profiles — Implementation Plan

> **Design doc**: `docs/plans/2026-02-11-org-profiles-migration.md`
> **Spec**: `new-migration-ui/ORG_PROFILES_MIGRATION_SPEC.md`
> **Prototype**: `new-migration-ui/org-profiles-content-only.html`
> **Workflow rules**: `.cursor/rules/split-panel-migration-workflow.mdc`

---

## Naming Collision Resolution

The existing `org_profiles` table and `/api/orgprofiles` endpoints store **per-org provisioning configs** (1:1 org→profile). This new feature creates **reusable config templates** (1:N template→orgs).

| Concept | Existing System | New Feature |
|---------|----------------|-------------|
| Table | `org_profiles` | `config_templates` |
| API path | `/api/orgprofiles` | `/api/config-templates` |
| Frontend route | N/A | `/configuration/org-profiles` |
| UI label | "OrgProfile" (internal) | "Organization Profiles" (user-facing) |

The UI still calls them "Organization Profiles" — only the backend table/API names differ to avoid collision.

---

## Phase 0: Schema + Types + Query Keys + Primitive + Nav

**Goal**: Everything else depends on types and nav structure. Define the domain model, build the CollapsibleSection primitive, and restructure navigation.

### Tasks

- [ ] **0.1** Create SQL migration `migrations/008_config_templates.sql`
  ```sql
  -- Migration 008: Config templates for reusable org provisioning profiles
  -- For existing deployments upgrading in-place.
  -- Fresh deployments auto-create via OrgDB.init().

  CREATE TABLE IF NOT EXISTS config_templates (
      id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name            VARCHAR(255) NOT NULL UNIQUE,
      description     TEXT NOT NULL DEFAULT '',
      template_type   VARCHAR(20) NOT NULL DEFAULT 'custom',
      status          VARCHAR(20) NOT NULL DEFAULT 'draft',
      xmpp_config     JSONB NOT NULL DEFAULT '{"enabled":false}',
      sip_config      JSONB NOT NULL DEFAULT '{"enabled":false}',
      sso_config      JSONB NOT NULL DEFAULT '{"enabled":false}',
      qr_settings     JSONB NOT NULL DEFAULT '{}',
      created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      created_by      VARCHAR(255),
      updated_by      VARCHAR(255)
  );

  CREATE UNIQUE INDEX IF NOT EXISTS idx_config_templates_default
      ON config_templates (template_type) WHERE template_type = 'default';

  CREATE TABLE IF NOT EXISTS config_template_assignments (
      id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      template_id     UUID NOT NULL REFERENCES config_templates(id) ON DELETE CASCADE,
      org_dn          VARCHAR(512) NOT NULL UNIQUE,
      assigned_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      assigned_by     VARCHAR(255)
  );

  CREATE TABLE IF NOT EXISTS config_template_history (
      id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      template_id     UUID NOT NULL REFERENCES config_templates(id) ON DELETE CASCADE,
      timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      actor           VARCHAR(255) NOT NULL,
      description     TEXT NOT NULL,
      field           VARCHAR(255),
      old_value       TEXT,
      new_value       TEXT
  );

  CREATE INDEX IF NOT EXISTS idx_config_template_history_template
      ON config_template_history(template_id, timestamp DESC);
  ```

- [ ] **0.2** Add SQLAlchemy table definitions to `src/backend/orgdb.py`
  - Add after existing `group_profiles` table definition (around line 95)
  - Follow existing pattern: `Table("config_templates", metadata, Column(...))`
  - Three tables: `config_templates`, `config_template_assignments`, `config_template_history`
  - Use `Column("id", Text, primary_key=True)` (store UUID as text, matching existing pattern)
  - Use `Column("xmpp_config", Text, nullable=False, server_default='{"enabled":false}')` (JSON stored as Text, matching `profile_json` pattern)
  - `metadata.create_all(eng)` in `init()` already handles new tables automatically

- [ ] **0.3** Create `src/frontend/src/types/org-profiles.ts`
  ```typescript
  /**
   * Org Profiles (config templates) type definitions.
   * - ProfileStatus: lifecycle state driving badge color
   * - ProfileType: default vs custom, driving icon color
   * - Config section types: XMPP, SIP, SSO, QR settings
   */

  export type ProfileStatus = 'active' | 'draft' | 'archived';
  export type ProfileType = 'default' | 'custom';
  export type FeatureKey = 'xmpp' | 'sip' | 'sso';
  export type ProfileTab = 'config' | 'usage' | 'history';

  export interface XmppConfig {
    enabled: boolean;
    domain: string;
    websocketUrl: string;
    conferenceServer?: string;
    resourceBinding: boolean;
  }

  export interface SipConfig {
    enabled: boolean;
    domain: string;
    websocketUrl: string;
    transport: 'wss' | 'ws' | 'tcp' | 'udp';
    srtpRequired: boolean;
  }

  export interface SsoConfig {
    enabled: boolean;
    provider: string;
    issuerUrl: string;
    clientId: string;
    scopes: string;
    pkceRequired: boolean;
  }

  export interface QrSettings {
    defaultValidityMinutes: number;
    oneTimeUse: boolean;
    autoEmailOnCreate: boolean;
    deepLinkScheme: string;
  }

  export interface UsageStats {
    orgCount: number;
    totalUsers: number;
    qrsGenerated: number;
  }

  export interface AssignedOrg {
    name: string;
    dn: string;
    userCount: number;
  }

  export interface HistoryEntry {
    id: string;
    timestamp: string;
    description: string;
    actor: string;
    field?: string;
    oldValue?: string;
    newValue?: string;
  }

  /** List view — flattened flags + usage stats, no full config blobs */
  export interface ProfileListItem {
    id: string;
    name: string;
    description: string;
    type: ProfileType;
    status: ProfileStatus;
    xmppEnabled: boolean;
    sipEnabled: boolean;
    ssoEnabled: boolean;
    usageStats: UsageStats;
  }

  /** Detail view — full config, assignments, history */
  export interface ProfileDetail {
    id: string;
    name: string;
    description: string;
    type: ProfileType;
    status: ProfileStatus;
    xmpp: XmppConfig;
    sip: SipConfig;
    sso: SsoConfig;
    qrSettings: QrSettings;
    assignedOrgs: AssignedOrg[];
    history: HistoryEntry[];
    createdAt: string;
    updatedAt: string;
  }

  export interface CreateProfilePayload {
    name: string;
    description?: string;
    xmpp?: Partial<XmppConfig>;
    sip?: Partial<SipConfig>;
    sso?: Partial<SsoConfig>;
  }

  export interface UpdateProfilePayload {
    name?: string;
    description?: string;
    status?: ProfileStatus;
    xmpp?: Partial<XmppConfig>;
    sip?: Partial<SipConfig>;
    sso?: Partial<SsoConfig>;
    qrSettings?: Partial<QrSettings>;
  }

  export interface ToggleSectionPayload {
    section: FeatureKey;
    enabled: boolean;
  }

  export interface FeatureFlag {
    key: FeatureKey;
    label: string;
    enabled: boolean;
  }

  export interface OrgProfilesSearchParams {
    profile?: string;
    tab?: ProfileTab;
  }
  ```
  - Export from `src/frontend/src/types/index.ts`

- [ ] **0.4** Add query keys to `src/frontend/src/lib/queries/keys.ts`
  ```typescript
  // Config templates (Org Profiles)
  configTemplates: ['configTemplates'] as const,
  configTemplate: (id: string) => ['configTemplates', id] as const,
  configTemplatesList: (params: Record<string, unknown>) =>
    ['configTemplates', 'list', params] as const,
  ```

- [ ] **0.5** Create CollapsibleSection primitive `src/frontend/packages/azblink-ui/primitives/CollapsibleSection/`
  - `CollapsibleSection.tsx` — wrapper component
    - Props: `title: string`, `icon?: ReactNode`, `defaultOpen?: boolean`, `children: ReactNode`
    - Uses internal `useState<boolean>` for open/closed
    - Chevron icon rotates 180° when open (CSS transform)
    - Content hidden via `display: none` (no animation in v1)
  - `CollapsibleSection.module.css` — structural styles only, all values from `tokens.css`
  - `CollapsibleSection.types.ts` — prop types
  - `index.ts` — barrel export
  - Export from `packages/azblink-ui/index.ts`

- [ ] **0.6** Update sidebar navigation in `src/frontend/src/components/layout/sidebar.tsx`
  - Add `Cog` icon import from lucide-react (for Configuration category)
  - Add new nav section before Account:
    ```typescript
    {
      label: 'Configuration',
      items: [
        { label: 'Org Profiles', href: '/configuration/org-profiles', icon: Cog },
        { label: 'Settings', href: '/configuration/settings', icon: Settings },
      ],
    },
    ```
  - Remove Settings from Account section (Account keeps only My Profile)
  - Import: add `Cog` to lucide-react imports

- [ ] **0.7** Create route scaffolds
  - Create `src/frontend/src/routes/configuration/org-profiles/index.tsx`
    ```typescript
    /**
     * Org Profiles page — /configuration/org-profiles
     * Card-based master-detail layout for managing provisioning config templates.
     * URL search params: ?profile (auto-select by id)
     */
    import { createFileRoute } from '@tanstack/react-router';
    import type { OrgProfilesSearchParams } from '@/types/org-profiles';

    const validTabs = ['config', 'usage', 'history'] as const;

    export const Route = createFileRoute('/configuration/org-profiles/')({
      validateSearch: (search: Record<string, unknown>): OrgProfilesSearchParams => ({
        profile: (search.profile as string) || undefined,
        tab: validTabs.includes(search.tab as typeof validTabs[number])
          ? (search.tab as OrgProfilesSearchParams['tab'])
          : undefined,
      }),
      component: OrgProfilesPage,
    });

    function OrgProfilesPage() {
      const searchParams = Route.useSearch();
      return <div>Org Profiles — Phase 1</div>;
    }
    ```
  - Move `src/frontend/src/routes/settings.tsx` to `src/frontend/src/routes/configuration/settings/index.tsx`
    - Update `createFileRoute('/settings')` → `createFileRoute('/configuration/settings/')`
    - Keep all component code identical
  - Create redirect at `src/frontend/src/routes/settings.tsx`:
    ```typescript
    /**
     * Redirect: /settings → /configuration/settings
     * Preserves backward compatibility with bookmarks/links.
     */
    import { createFileRoute, redirect } from '@tanstack/react-router';

    export const Route = createFileRoute('/settings')({
      beforeLoad: () => {
        throw redirect({ to: '/configuration/settings' });
      },
    });
    ```
  - Run `just ui-routes` to regenerate route tree

- [ ] **0.8** Create `src/frontend/src/components/features/org-profiles/profile-type-config.ts`
  - Follow `group-management/group-type-config.ts` pattern
  - Map `ProfileType` → `{ icon, color, bg }`
    - `default`: Shield icon, `text-blue-400`, `bg-blue-500/10`
    - `custom`: Users icon, `text-purple-400`, `bg-purple-500/10`
  - Map `ProfileStatus` → `{ label, color, bg }`
    - `active`: `text-green-500`, `bg-green-500/10`
    - `draft`: `text-amber-500`, `bg-amber-500/10`
    - `archived`: `text-zinc-500`, `bg-zinc-500/10`
  - Map config section → `{ icon, color, bg }`
    - `xmpp`: MessageCircle, `text-blue-500`, `bg-blue-500/10`
    - `sip`: Phone, `text-green-500`, `bg-green-500/10`
    - `sso`: KeyRound, `text-cyan-500`, `bg-cyan-500/10`
    - `qr`: QrCode, `text-amber-500`, `bg-amber-500/10`

**Commit**: `feat(org-profiles): add schema, types, query keys, CollapsibleSection, nav restructure (Phase 0)`

**Verify**: TypeScript compiles. Route tree regenerates. Sidebar shows Configuration category with Org Profiles and Settings. `/settings` redirects to `/configuration/settings`. `/configuration/org-profiles` renders placeholder.

---

## Phase 1: Backend Endpoints + Card List Shell

**Goal**: Can render profile cards from real backend data. Selection updates URL.

### Backend Tasks

- [ ] **1.1** Add CRUD methods to `src/backend/orgdb.py`
  - `list_config_templates()` → `List[dict]`
    - `select(config_templates).order_by(config_templates.c.updated_at.desc())`
    - Returns all rows as dicts
  - `get_config_template(template_id: str)` → `dict | None`
    - `select(config_templates).where(config_templates.c.id == template_id)`
  - `create_config_template(data: dict)` → `dict`
    - `insert(config_templates).values(...)` with `id=str(uuid4())`, `created_at=utcnow()`, `updated_at=utcnow()`
    - Returns the created template via `get_config_template()`
  - `update_config_template(template_id: str, updates: dict)` → `dict | None`
    - Follow existing `update_org_profile()` pattern — only update provided fields
    - Always set `updated_at=utcnow()`
    - Returns updated template or None
  - `delete_config_template(template_id: str)` → `bool`
    - Check if template exists first
    - If `template_type == 'default'`, return False (prevent default deletion)
    - CASCADE handles assignments + history cleanup
  - `clone_config_template(template_id: str, actor: str)` → `dict | None`
    - Get source template
    - Create new with `name="Copy of {source.name}"`, `template_type='custom'`, `status='draft'`
    - Copy all config columns (xmpp_config, sip_config, sso_config, qr_settings)
    - Add history entry: "Cloned from {source.name}"
  - `toggle_config_template_section(template_id: str, section: str, enabled: bool, actor: str)` → `dict | None`
    - Read current config JSONB for the section
    - Update `enabled` field in the JSON
    - Write back, update `updated_at`
    - Add history entry: "{section} {enabled ? 'enabled' : 'disabled'}"
  - `list_template_assignments(template_id: str)` → `List[dict]`
    - Join with LDAP user count per org (call `len(list_users_for_org(org_dn))` per assignment)
    - Returns `[{ org_dn, name, userCount, assigned_at }]`
  - `list_template_history(template_id: str)` → `List[dict]`
    - `select(config_template_history).where(...).order_by(timestamp.desc())`
  - `add_template_history(template_id: str, actor: str, description: str, field: str | None, old_value: str | None, new_value: str | None)`
    - `insert(config_template_history).values(...)`

- [ ] **1.2** Add Pydantic models to `src/backend/main.py` (inline, before endpoints)
  ```python
  class ConfigTemplateCreate(BaseModel):
      name: str = Field(..., min_length=1, max_length=255)
      description: str = Field(default="", max_length=1024)
      xmpp: Optional[dict] = None
      sip: Optional[dict] = None
      sso: Optional[dict] = None

  class ConfigTemplateUpdate(BaseModel):
      name: Optional[str] = Field(default=None, min_length=1, max_length=255)
      description: Optional[str] = Field(default=None, max_length=1024)
      status: Optional[str] = Field(default=None, pattern="^(active|draft|archived)$")
      xmpp: Optional[dict] = None
      sip: Optional[dict] = None
      sso: Optional[dict] = None
      qrSettings: Optional[dict] = None

  class ConfigTemplateSectionToggle(BaseModel):
      section: str = Field(..., pattern="^(xmpp|sip|sso)$")
      enabled: bool
  ```

- [ ] **1.3** Add 7 endpoints to `src/backend/main.py`
  - Place AFTER existing `/api/orgprofiles` endpoints to avoid confusion
  - Route ordering: `/api/config-templates` (list) BEFORE `/api/config-templates/{id}` (detail)

  ```python
  # --- Config Templates (Org Profiles UI) ---

  @app.get("/api/config-templates")
  def api_list_config_templates(claims: Dict[str, Any] = Depends(require_admin)):
      """List all config templates with flattened feature flags and usage stats."""
      rows = ORGDB.list_config_templates()
      out = []
      for r in rows:
          xmpp = json.loads(r["xmpp_config"]) if isinstance(r["xmpp_config"], str) else r["xmpp_config"]
          sip = json.loads(r["sip_config"]) if isinstance(r["sip_config"], str) else r["sip_config"]
          sso = json.loads(r["sso_config"]) if isinstance(r["sso_config"], str) else r["sso_config"]
          assignments = ORGDB.list_template_assignments(r["id"])
          total_users = sum(a.get("userCount", 0) for a in assignments)
          out.append({
              "id": r["id"],
              "name": r["name"],
              "description": r["description"],
              "type": r["template_type"],
              "status": r["status"],
              "xmppEnabled": xmpp.get("enabled", False),
              "sipEnabled": sip.get("enabled", False),
              "ssoEnabled": sso.get("enabled", False),
              "usageStats": {
                  "orgCount": len(assignments),
                  "totalUsers": total_users,
                  "qrsGenerated": 0,  # TODO: join with qr_issuance_audit
              },
          })
      return {"ok": True, "templates": out}

  @app.get("/api/config-templates/{template_id}")
  def api_get_config_template(template_id: str, claims: Dict[str, Any] = Depends(require_admin)):
      """Get full config template detail with assignments and history."""
      ...

  @app.post("/api/config-templates", status_code=201)
  def api_create_config_template(req: ConfigTemplateCreate, claims: Dict[str, Any] = Depends(require_admin)):
      """Create a new config template."""
      ...

  @app.put("/api/config-templates/{template_id}")
  def api_update_config_template(template_id: str, req: ConfigTemplateUpdate, claims: Dict[str, Any] = Depends(require_admin)):
      """Update a config template. Only provided fields are changed."""
      ...

  @app.patch("/api/config-templates/{template_id}/toggle")
  def api_toggle_config_template_section(template_id: str, req: ConfigTemplateSectionToggle, claims: Dict[str, Any] = Depends(require_admin)):
      """Toggle a config section (xmpp/sip/sso) on or off."""
      ...

  @app.post("/api/config-templates/{template_id}/clone")
  def api_clone_config_template(template_id: str, claims: Dict[str, Any] = Depends(require_admin)):
      """Clone a config template. Creates "Copy of {name}" with draft status."""
      ...

  @app.delete("/api/config-templates/{template_id}")
  def api_delete_config_template(template_id: str, claims: Dict[str, Any] = Depends(require_admin)):
      """Delete a config template. Prevents deletion of default template."""
      ...
  ```

  **Endpoint details:**
  - GET list: assemble flattened response with usage stats (LDAP user counts per assigned org)
  - GET detail: parse JSONB configs into nested dicts, include assignments + history
  - POST create: validate name uniqueness (409 if exists), default `status='draft'`, add history "Profile created"
  - PUT update: merge provided fields only, add history per changed field
  - PATCH toggle: update JSONB `enabled` flag, add history
  - POST clone: copy all configs, `name="Copy of {name}"`, `status='draft'`, add history
  - DELETE: check `template_type != 'default'` (400 if default), CASCADE handles cleanup

- [ ] **1.4** Seed default template on first startup
  - In `OrgDB.init()`, after `metadata.create_all(eng)`:
    - Check if any config_templates exist
    - If zero rows, insert a "Standard Profile" with `template_type='default'`, `status='active'`
    - Include example XMPP/SIP/SSO configs from spec
    - Log: `logger.info("Seeded default config template")`

### Frontend Tasks

- [ ] **1.5** Create `src/frontend/src/lib/queries/org-profiles.ts`
  ```typescript
  /**
   * Query options for config templates (Org Profiles).
   * List returns flattened flags; detail returns full config.
   */
  import { queryOptions } from '@tanstack/react-query';
  import { getApi } from '../api-client';
  import { queryKeys } from './keys';
  import type { ProfileListItem, ProfileDetail } from '@/types/org-profiles';

  export const profilesQueryOptions = () =>
    queryOptions({
      queryKey: queryKeys.configTemplates,
      queryFn: async () => {
        const res = await getApi().get<{ ok: boolean; templates: ProfileListItem[] }>(
          '/config-templates'
        );
        return res.templates;
      },
      staleTime: 30_000,
    });

  export const profileDetailQueryOptions = (id: string) =>
    queryOptions({
      queryKey: queryKeys.configTemplate(id),
      queryFn: async () => {
        const res = await getApi().get<{ ok: boolean; profile: ProfileDetail }>(
          `/config-templates/${id}`
        );
        return res.profile;
      },
      staleTime: 30_000,
      enabled: !!id,
    });
  ```

- [ ] **1.6** Create `src/frontend/src/components/features/org-profiles/OrgProfilesManagementPage.tsx`
  - Follow `GroupManagementPage.tsx` structure:
    - `useNavigate` for URL param updates
    - `useResizablePanel({ storageKey: 'panel-width:org-profiles', ... })` — NOT needed (card layout uses fixed 340px, not resizable)
    - `useSuspenseQuery(profilesQueryOptions())` for profile list
    - URL-driven selection: `searchParams.profile` → find matching profile
    - Auto-select first profile on mount if none selected
  - Layout: `grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-6 h-[calc(100vh-var(--topbar-height)-7.25rem)]`
  - Left: Suspense-wrapped `ProfileList`
  - Right: `ProfileDetailPanel` or empty state
  - Props: `searchParams: OrgProfilesSearchParams`

- [ ] **1.7** Create `src/frontend/src/components/features/org-profiles/PageHeader.tsx`
  - Title: "Organization Profiles"
  - Subtitle: "Reusable provisioning configurations for organizations"
  - Primary CTA: "Create Profile" button with Plus icon
  - No search input (spec shows none — profile count is small)
  - Props: `onCreate: () => void`

- [ ] **1.8** Create `src/frontend/src/components/features/org-profiles/ProfileList.tsx`
  - Card list container (not ListPanel — cards are different from table rows)
  - Header: "All Profiles · {count} profiles"
  - Scrollable card list with `overflow-y: auto`
  - No filter tabs (profile count is small, no filtering needed)
  - No pagination (< 20 profiles expected)
  - Props: `profiles: ProfileListItem[]`, `selectedId: string | null`, `onSelect: (id: string) => void`

- [ ] **1.9** Create `src/frontend/src/components/features/org-profiles/ProfileCard.tsx`
  - **Not** a grid row — this is a card component
  - Structure from spec §2:
    - Card header: icon (from `profile-type-config.ts`) + status badge
    - Title + description
    - Stats row: org count + user count (from `usageStats`)
    - Feature flags bar: XMPP/SIP/SSO checkmark or X
  - States: default (no border), hover (elevated border), selected (blue border + elevated bg)
  - `aria-current="true"` on selected card
  - Props: `profile: ProfileListItem`, `isSelected: boolean`, `onClick: () => void`

- [ ] **1.10** Wire route to page component
  - Update `src/frontend/src/routes/configuration/org-profiles/index.tsx`
  - Import and render `OrgProfilesManagementPage` with `searchParams`

**Commit**: `feat(org-profiles): add backend endpoints and card list shell (Phase 1)`

**Verify**: Page renders at `/configuration/org-profiles` with header, profile cards from API, card selection updates URL `?profile=`. Seeded default profile appears in list. API docs show all 7 endpoints at `/api/docs`.

---

## Phase 2: Detail Panel (Read-Only)

**Goal**: Selecting a profile card shows its full detail with 3 tabs.

### Tasks

- [ ] **2.1** Create `src/frontend/src/components/features/org-profiles/ProfileDetailPanel.tsx`
  - Suspense wrapper + content component (follow GroupDetailPanel pattern)
  - `useSuspenseQuery(profileDetailQueryOptions(id))` for full detail
  - Header:
    - Profile icon (56px, from `profile-type-config.ts`)
    - Title + description
    - Action buttons: Clone (secondary, compact), Edit (secondary, compact) — **wired to callback props, no-ops for Phase 2**
  - Tab strip: Configuration | Usage | History (using `Tabs` from `@azblink/ui`)
  - Tab content switches based on `tab` URL param
  - Skeleton loading state
  - Props: `profileId: string`, `tab?: ProfileTab`, `onTabChange`, `onClone`, `onEdit`, `onDelete`

- [ ] **2.2** Create `src/frontend/src/components/features/org-profiles/ConfigTab.tsx`
  - 4 `ConfigSection` instances: XMPP, SIP, SSO, QR Settings
  - Each section receives its config data from profile detail
  - Props: `profile: ProfileDetail`, `onToggle?: (section: FeatureKey, enabled: boolean) => void`

- [ ] **2.3** Create `src/frontend/src/components/features/org-profiles/ConfigSection.tsx`
  - Section header: colored icon (from config section map) + title + toggle switch
  - Toggle: uses `Toggle` from `@azblink/ui`, wired to `onToggle` callback (no-op in Phase 2)
  - Config card: key-value rows using `<div className="config-row">` pattern
  - When disabled (`enabled: false`): card content dims (opacity 0.5) but stays visible
  - QR Settings section: no toggle (always visible)
  - Value formatting:
    - Boolean values: "Enabled" (green) / "Disabled" (amber)
    - URL values: monospace font
    - Regular values: default text
  - Props: `title: string`, `icon: ReactNode`, `iconColor: string`, `enabled: boolean`, `onToggle?: (enabled: boolean) => void`, `children: ReactNode` (config rows)

- [ ] **2.4** Create `src/frontend/src/components/features/org-profiles/UsageTab.tsx`
  - Stats grid: 3-column grid with org count, total users, QRs generated
  - Uses existing `stat-card.tsx` pattern or inline stat cards
  - Assigned Organizations list:
    - Each org row: building icon + org name + org DN (truncated) + user count
    - No pagination (max ~10 orgs per profile)
  - Props: `profile: ProfileDetail`

- [ ] **2.5** Create `src/frontend/src/components/features/org-profiles/HistoryTab.tsx`
  - Change History section using config-card + config-row pattern
  - Each entry: timestamp (formatted) + description
  - Sorted by timestamp DESC (newest first)
  - Props: `history: HistoryEntry[]`

- [ ] **2.6** Wire detail panel into `OrgProfilesManagementPage.tsx`
  - When `selectedId` is set: render `ProfileDetailPanel`
  - When no selection: render empty state ("Select a profile to view details")
  - Tab changes update URL `?tab=` param
  - Clone/Edit/Delete callbacks: no-ops for Phase 2 (wire in Phase 3)

**Commit**: `feat(org-profiles): add detail panel with config, usage, history tabs (Phase 2)`

**Verify**: Selecting a card shows detail panel. All 3 tabs render with real data. Config sections show with colored icons. Feature flags and stats match card data. Toggle switches are visible but non-functional.

---

## Phase 3: Create + Edit + Clone + Delete Modals

**Goal**: Full CRUD lifecycle — create, edit, clone, and delete profiles.

### Tasks

- [ ] **3.1** Create `src/frontend/src/components/features/org-profiles/useModalState.ts`
  ```typescript
  /**
   * Modal state machine for the Org Profiles page.
   * - Page-scoped via useReducer (not Zustand)
   * - Kinds: closed, create, edit, delete_confirm
   */
  type ModalKind = 'closed' | 'create' | 'edit' | 'delete_confirm';

  interface ModalState {
    kind: ModalKind;
    targetProfileId: string | null;
  }

  type ModalAction =
    | { type: 'OPEN_CREATE' }
    | { type: 'OPEN_EDIT'; profileId: string }
    | { type: 'OPEN_DELETE'; profileId: string }
    | { type: 'CLOSE' };
  ```
  - Dispatch helpers: `openCreate()`, `openEdit(id)`, `openDelete(id)`, `close()`

- [ ] **3.2** Create `src/frontend/src/lib/queries/org-profiles-mutations.ts`
  ```typescript
  /**
   * Mutation hooks for config templates (Org Profiles).
   * Error handling in components only (never in hooks — prevents double toast).
   */
  import { useMutation, useQueryClient } from '@tanstack/react-query';
  import { getApi } from '../api-client';
  import { queryKeys } from './keys';
  import type { CreateProfilePayload, UpdateProfilePayload, ToggleSectionPayload } from '@/types/org-profiles';

  export function useCreateProfile() { ... }       // POST /api/config-templates
  export function useUpdateProfile(id: string) { ... }  // PUT /api/config-templates/{id}
  export function useToggleSection(id: string) { ... }  // PATCH /api/config-templates/{id}/toggle
  export function useCloneProfile(id: string) { ... }   // POST /api/config-templates/{id}/clone
  export function useDeleteProfile(id: string) { ... }  // DELETE /api/config-templates/{id}
  ```
  - All mutations: `onSuccess` → `queryClient.invalidateQueries({ queryKey: queryKeys.configTemplates })`
  - No `onError` in hooks — error handling only in components

- [ ] **3.3** Create `src/frontend/src/components/features/org-profiles/modals/CreateProfileModal.tsx`
  - Uses `Dialog` from `@azblink/ui`
  - **Handles both create and edit** via `mode: 'create' | 'edit'` prop
  - Form fields:
    - Profile Name (required, `Input` from `@azblink/ui`)
    - Description (optional, `Textarea` from `@azblink/ui`)
    - XMPP Configuration (`CollapsibleSection`, open by default)
      - Domain, WebSocket URL
    - SIP Configuration (`CollapsibleSection`, collapsed)
      - Domain, WebSocket URL
    - SSO Configuration (`CollapsibleSection`, collapsed)
      - Issuer URL, Client ID, Scopes
  - Form validation: name non-empty (disable submit button if empty)
  - Edit mode: prefill all fields from profile detail data
  - On submit:
    - Create: `useCreateProfile()` → close → toast "Profile created" → auto-select new profile
    - Edit: `useUpdateProfile(id)` → close → toast "Profile updated"
  - Max-width: 560px, max-height: 90vh (body scrolls)
  - Props: `open: boolean`, `onClose: () => void`, `mode: 'create' | 'edit'`, `profile?: ProfileDetail`

- [ ] **3.4** Create `src/frontend/src/components/features/org-profiles/modals/DeleteProfileModal.tsx`
  - Uses `AlertDialog` from `@azblink/ui`
  - Shows warning: "This will remove the profile and unassign {n} organizations."
  - Lists affected orgs (from profile's `assignedOrgs`)
  - Prevents deletion if `profile.type === 'default'` (button disabled + explanation)
  - On confirm: `useDeleteProfile(id)` → close → toast "Profile deleted" → deselect
  - Props: `open: boolean`, `onClose: () => void`, `profile: ProfileDetail`

- [ ] **3.5** Wire Clone action
  - In `ProfileDetailPanel.tsx`: Clone button calls `useCloneProfile(id)`
  - No modal needed — clone is instant
  - On success: toast "Profile cloned" → auto-select the new clone (returned from API)
  - On error: toast with error message

- [ ] **3.6** Wire modals into `OrgProfilesManagementPage.tsx`
  - Import `useModalState`
  - PageHeader `onCreate` → `openCreate()`
  - Detail panel `onEdit` → `openEdit(profileId)`
  - Detail panel `onDelete` → `openDelete(profileId)`
  - Render `CreateProfileModal` when `modal.kind === 'create' || modal.kind === 'edit'`
  - Render `DeleteProfileModal` when `modal.kind === 'delete_confirm'`
  - On create success: navigate to `?profile={newId}` to auto-select

**Commit**: `feat(org-profiles): add create, edit, clone, delete modals (Phase 3)`

**Verify**: Create modal opens, fills fields, creates profile, toast appears, new profile auto-selected. Edit modal prefills, saves changes. Clone creates "Copy of X", auto-selects. Delete confirms with org count, removes profile. Default profile cannot be deleted.

---

## Phase 4: Toggle + Optimistic Updates

**Goal**: Config section toggles respond instantly with optimistic cache updates.

### Tasks

- [ ] **4.1** Wire toggle switches in `ConfigSection.tsx`
  - Each XMPP/SIP/SSO section header has a `Toggle` from `@azblink/ui`
  - Toggle `onChange` calls `onToggle(section, newValue)` prop

- [ ] **4.2** Implement optimistic toggle in `OrgProfilesManagementPage.tsx`
  - `useToggleSection(profileId)` mutation with optimistic update:
    ```typescript
    onMutate: async ({ section, enabled }) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey: queryKeys.configTemplate(profileId) });
      // Snapshot previous value
      const previous = queryClient.getQueryData(queryKeys.configTemplate(profileId));
      // Optimistically update cache
      queryClient.setQueryData(queryKeys.configTemplate(profileId), (old) => ({
        ...old,
        [section]: { ...old[section], enabled },
      }));
      return { previous };
    },
    onError: (err, variables, context) => {
      // Rollback on error
      queryClient.setQueryData(queryKeys.configTemplate(profileId), context.previous);
    },
    onSettled: () => {
      // Refetch to ensure consistency
      queryClient.invalidateQueries({ queryKey: queryKeys.configTemplates });
      queryClient.invalidateQueries({ queryKey: queryKeys.configTemplate(profileId) });
    },
    ```
  - Error toast in component, not in mutation hook
  - Profile card feature flags update via list query invalidation

- [ ] **4.3** Update `ConfigSection.tsx` visual state
  - When `enabled: false`: config card content gets `opacity-50` class
  - Feature flag row on `ProfileCard` reads from `xmppEnabled`/`sipEnabled`/`ssoEnabled` (updated via list refetch)

- [ ] **4.4** Verify backend history entry
  - Toggle endpoint writes history: "{Section} enabled" or "{Section} disabled"
  - History tab shows new entries after toggle
  - Actor field populated from JWT claims `sub` or `uid`

**Commit**: `feat(org-profiles): add toggle with optimistic updates (Phase 4)`

**Verify**: Toggles respond immediately (no loading delay). Card feature flags update after refetch. Error shows toast + rollback. History tab shows toggle entries.

---

## Phase 5: Polish

**Goal**: Responsive layout, accessibility, redirects, DRY audit.

### Tasks

- [ ] **5.1** Responsive breakpoints
  - `>900px`: 2-col grid `grid-cols-[340px_1fr]`
  - `≤900px`: 1-col, card list capped at `max-h-[400px]` with scroll, detail below full-width
  - `≤600px`: Usage stats grid → single column
  - `≤500px`: Modal full-width, header actions stack

- [ ] **5.2** URL param auto-selection
  - On mount: if `?profile=` param exists, find matching profile in list
  - If found, select it. If not found (stale link), select first profile instead.
  - If no profiles exist, show empty state

- [ ] **5.3** Empty states
  - No profiles at all: icon + "No profiles yet" + "Create your first profile" CTA
  - No selection: icon + "Select a profile to view details"
  - No assigned orgs (usage tab): "No organizations assigned to this profile"
  - No history entries: "No changes recorded yet"

- [ ] **5.4** Loading skeletons
  - Card list: 3 skeleton cards (icon + text lines + badge)
  - Detail panel: skeleton header (icon + title) + skeleton tab strip + skeleton config rows
  - Follow existing `Skeleton` component from `@azblink/ui`

- [ ] **5.5** Accessibility
  - `aria-current="true"` on selected profile card
  - `aria-live="polite"` on profile count in list header
  - `aria-label` on icon-only buttons (Clone, Edit)
  - `htmlFor` + `id` on all form label/input pairs in create/edit modal
  - `autoFocus` on profile name input when modal opens
  - `role="alert"` on form validation errors
  - Escape key closes modals (handled by Dialog/AlertDialog primitives)

- [ ] **5.6** `data-testid` attributes
  - `data-testid="profile-card-{id}"` on each ProfileCard
  - `data-testid="profile-detail"` on detail panel
  - `data-testid="create-profile-modal"` on create modal
  - `data-testid="delete-profile-modal"` on delete modal
  - `data-testid="config-toggle-{section}"` on each toggle

- [ ] **5.7** DRY audit
  - Verify no duplicate utility functions — use shared imports
  - Verify no hardcoded colors — all from tokens or Tailwind bridge
  - Verify CollapsibleSection primitive is used (not ad-hoc accordion)
  - Verify config card pattern isn't duplicated — if used elsewhere, evaluate promotion to shared component

- [ ] **5.8** Settings redirect verification
  - `/settings` → `/configuration/settings` works
  - Sidebar "Settings" link points to `/configuration/settings`
  - No broken links to old path in any component

**Commit**: `feat(org-profiles): polish, responsive, a11y, empty states (Phase 5)`

**Verify**: Page looks correct at all breakpoints. `?profile=` auto-selects on mount. All accessibility attributes present. Skeletons render during loading. Old `/settings` route redirects. No duplicate code.

---

## File Manifest

### New Files (19)

| File | Purpose | Phase |
|------|---------|-------|
| `migrations/008_config_templates.sql` | DB migration | 0 |
| `src/frontend/src/types/org-profiles.ts` | Domain types | 0 |
| `src/frontend/packages/azblink-ui/primitives/CollapsibleSection/CollapsibleSection.tsx` | Accordion primitive | 0 |
| `src/frontend/packages/azblink-ui/primitives/CollapsibleSection/CollapsibleSection.module.css` | Accordion styles | 0 |
| `src/frontend/packages/azblink-ui/primitives/CollapsibleSection/CollapsibleSection.types.ts` | Accordion types | 0 |
| `src/frontend/packages/azblink-ui/primitives/CollapsibleSection/index.ts` | Barrel export | 0 |
| `src/frontend/src/routes/configuration/org-profiles/index.tsx` | Route file | 0 |
| `src/frontend/src/routes/configuration/settings/index.tsx` | Settings route (moved) | 0 |
| `src/frontend/src/components/features/org-profiles/profile-type-config.ts` | Icon/color config | 0 |
| `src/frontend/src/lib/queries/org-profiles.ts` | Query hooks | 1 |
| `src/frontend/src/components/features/org-profiles/OrgProfilesManagementPage.tsx` | Page orchestrator | 1 |
| `src/frontend/src/components/features/org-profiles/PageHeader.tsx` | Page header | 1 |
| `src/frontend/src/components/features/org-profiles/ProfileList.tsx` | Card list container | 1 |
| `src/frontend/src/components/features/org-profiles/ProfileCard.tsx` | Individual card | 1 |
| `src/frontend/src/components/features/org-profiles/ProfileDetailPanel.tsx` | Detail panel | 2 |
| `src/frontend/src/components/features/org-profiles/ConfigTab.tsx` | Config tab content | 2 |
| `src/frontend/src/components/features/org-profiles/ConfigSection.tsx` | Config section compound | 2 |
| `src/frontend/src/components/features/org-profiles/UsageTab.tsx` | Usage tab content | 2 |
| `src/frontend/src/components/features/org-profiles/HistoryTab.tsx` | History tab content | 2 |
| `src/frontend/src/components/features/org-profiles/useModalState.ts` | Modal state machine | 3 |
| `src/frontend/src/lib/queries/org-profiles-mutations.ts` | Mutation hooks | 3 |
| `src/frontend/src/components/features/org-profiles/modals/CreateProfileModal.tsx` | Create + Edit modal | 3 |
| `src/frontend/src/components/features/org-profiles/modals/DeleteProfileModal.tsx` | Delete confirmation | 3 |

### Modified Files (5)

| File | Change | Phase |
|------|--------|-------|
| `src/backend/orgdb.py` | Add 3 table defs + CRUD methods | 0, 1 |
| `src/backend/main.py` | Add Pydantic models + 7 endpoints | 1 |
| `src/frontend/src/lib/queries/keys.ts` | Add configTemplates query keys | 0 |
| `src/frontend/src/types/index.ts` | Export org-profiles types | 0 |
| `src/frontend/src/components/layout/sidebar.tsx` | Add Configuration category, move Settings | 0 |
| `src/frontend/packages/azblink-ui/index.ts` | Export CollapsibleSection | 0 |

### Redirect Files (1)

| File | Change | Phase |
|------|--------|-------|
| `src/frontend/src/routes/settings.tsx` | Redirect `/settings` → `/configuration/settings` | 0 |

---

## Commit Convention

```
feat(org-profiles): <short description> (Phase N)
fix: address Phase N code review findings
docs: add org profiles design doc and implementation plan
```

One commit per phase. One commit per review fix round. Never bundle unrelated changes.

## Review Cadence

After EACH phase:
1. Spec compliance review — does the implementation match this plan?
2. Code quality review — bugs, security, DRY, a11y?
3. Fix all CRITICAL and IMPORTANT findings before proceeding
4. Commit fixes as a separate `fix:` commit

After ALL phases:
5. Full migration code review — cross-cutting concerns, backward compat, dead code
