# Architecture Design: SIP + XMPP Profile Provisioning

## Core Design: Profile-Linked Provisioning Enrichment

Link `config_templates` (org profiles) to `tenant_ldap_configs` (UED configs) via FK `ued_config_id`. When a user is created with a profile that has UED integration, the backend:
1. Atomically allocates `uid_number` and `extension` (if SIP schema)
2. Generates `sip_password` (if SIP schema)
3. Builds enriched payload with all schema-required fields
4. Emits sync event → SyncWorker → UED Sync → LDAP entry created

## Key Decisions

1. **Zero UED Sync changes** — it already handles schema resolution correctly
2. **Atomic DB counters** for uid_number and extension — no LDAP queries, no race conditions
3. **XMPP username = uid** — no separate field needed (JID localpart = uid)
4. **SIP password auto-generated** — shown once in wizard success step, not stored in PostgreSQL
5. **Profile-UED link is optional** — profiles without `ued_config_id` work as before (no UC provisioning)

## Schema-Required Fields

| schema_name | uid_number | extension | sip_password |
|-------------|-----------|-----------|--------------|
| xmpp-only | allocate | - | - |
| pjsip-combined | allocate | allocate | generate |
| sip-legacy | allocate | allocate | generate |

## Database Changes

```sql
-- Link profiles to UED configs
ALTER TABLE config_templates ADD COLUMN ued_config_id VARCHAR(36)
  REFERENCES tenant_ldap_configs(id) ON DELETE SET NULL;

-- Atomic counters on UED configs
ALTER TABLE tenant_ldap_configs
  ADD COLUMN next_uid_number INTEGER DEFAULT 5000,
  ADD COLUMN uid_range_start INTEGER DEFAULT 5000,
  ADD COLUMN uid_range_end INTEGER DEFAULT 65533,
  ADD COLUMN next_extension INTEGER DEFAULT 6001,
  ADD COLUMN extension_range_start INTEGER DEFAULT 6001,
  ADD COLUMN extension_range_end INTEGER DEFAULT 6999;
```

## Data Flow

```
Admin → Onboarding Wizard → Step 3 picks profile → Step 5 submit
  → POST /api/users/create {uid, displayName, password, profileId}
  → Backend: create LDAP inetOrgPerson (existing)
  → Backend: lookup profile → get ued_config_id → get schema_name
  → Backend: allocate uid_number, extension (atomic SQL)
  → Backend: generate sip_password
  → Backend: emit_sync_event({user: enriched, password})
  → SyncWorker → UED Sync API → LDAP posixAccount + SIP/XMPP attrs
  → Response: {ok, uid, provisioning: {uid_number, extension, sip_password}}
  → UI: show provisioning details in success step
```

## Files to Create/Modify

### Create
- `migrations/012_sip_xmpp_profiles.sql` — Schema changes
- `src/backend/provisioning.py` — Field allocation + payload building
- `tests/test_provisioning.py` — Unit tests

### Modify
- `src/backend/main.py` — Extend UserCreateReq, modify /api/users/create
- `src/backend/orgdb.py` — Add helper functions for profile lookup + allocation
- `src/frontend/src/components/features/user-management/onboarding/OnboardingWizard.tsx` — Extended state
- `src/frontend/src/components/features/user-management/onboarding/StepProfile.tsx` — Show UC implications
- `src/frontend/src/components/features/user-management/onboarding/StepComplete.tsx` — Show provisioning details
- `src/frontend/src/lib/queries/user-create.ts` — Extended payload
- `src/frontend/src/types/org-profiles.ts` — Extended types
