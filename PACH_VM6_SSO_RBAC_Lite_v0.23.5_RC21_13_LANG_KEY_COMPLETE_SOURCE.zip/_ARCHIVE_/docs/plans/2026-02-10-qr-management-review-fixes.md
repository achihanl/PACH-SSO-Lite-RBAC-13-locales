# QR Management Review Fixes Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Fix 5 issues identified during code review of the QR Management feature.

**Architecture:** All changes are surgical backend fixes — no frontend changes needed. Two Important issues (over-fetch pagination, sequential LDAP) and three Minor issues (input validation on sort/order/date_range/status params).

**Tech Stack:** Python, FastAPI, SQLAlchemy, ldap3

---

## Issue Summary

| # | Severity | Issue | File | Line |
|---|----------|-------|------|------|
| 1 | Important | Over-fetch heuristic may miss results when status filter matches <25% of data | `src/backend/orgdb.py` | 709 |
| 2 | Important | Sequential LDAP lookups (N individual `get_user()` calls) | `src/backend/main.py` | 1655-1661 |
| 3 | Minor | No input validation on `sort` parameter | `src/backend/main.py` | 1631 |
| 4 | Minor | No input validation on `order` parameter | `src/backend/main.py` | 1632 |
| 5 | Minor | No input validation on `date_range` and `status` parameters | `src/backend/main.py` | 1629-1630 |

---

### Task 1: Write failing tests for input validation (Issues 3, 4, 5)

**Files:**
- Modify: `tests/test_qr_management.py`

**Step 1: Write the failing tests**

Add a new test class at the bottom of the file:

```python
class TestQRCodesInputValidation:
    """Input validation for query parameters."""

    def test_invalid_sort_returns_422(self, client):
        """Unknown sort column should return 422."""
        resp = client.get("/api/qr/codes", params={
            "limit": 5, "offset": 0, "date_range": "all",
            "sort": "password", "order": "desc",
        })
        assert resp.status_code == 422

    def test_invalid_order_returns_422(self, client):
        """Unknown order direction should return 422."""
        resp = client.get("/api/qr/codes", params={
            "limit": 5, "offset": 0, "date_range": "all",
            "sort": "issued_at", "order": "sideways",
        })
        assert resp.status_code == 422

    def test_invalid_date_range_returns_422(self, client):
        """Unknown date range should return 422."""
        resp = client.get("/api/qr/codes", params={
            "limit": 5, "offset": 0, "date_range": "999d",
            "sort": "issued_at", "order": "desc",
        })
        assert resp.status_code == 422

    def test_invalid_status_returns_422(self, client):
        """Unknown status filter should return 422."""
        resp = client.get("/api/qr/codes", params={
            "limit": 5, "offset": 0, "date_range": "all",
            "status": "destroyed", "sort": "issued_at", "order": "desc",
        })
        assert resp.status_code == 422

    def test_invalid_stats_date_range_returns_422(self, client):
        """Stats endpoint rejects invalid date range."""
        resp = client.get("/api/qr/stats", params={"date_range": "999d"})
        assert resp.status_code == 422
```

**Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_qr_management.py::TestQRCodesInputValidation -v`
Expected: 5 FAILED (currently returns 200 for all invalid inputs)

---

### Task 2: Add input validation to API endpoints (Issues 3, 4, 5)

**Files:**
- Modify: `src/backend/main.py` (lines 1624-1689)

**Step 1: Add Literal imports and constrained params**

At the top of `main.py`, find the `from typing import` line and add `Literal` if not present.

Then change the `api_qr_codes` function signature from:

```python
@app.get("/api/qr/codes")
def api_qr_codes(
    limit: int = 50,
    offset: int = 0,
    search: str = "",
    status: str = "",
    date_range: str = "7d",
    sort: str = "issued_at",
    order: str = "desc",
    claims: Dict[str, Any] = Depends(require_admin),
):
```

To:

```python
VALID_QR_STATUSES = ("", "consumed", "pending", "expired", "revoked")
VALID_QR_DATE_RANGES = ("7d", "30d", "90d", "all")
VALID_QR_SORT_COLS = ("issued_at", "user_uid")
VALID_QR_ORDERS = ("asc", "desc")

@app.get("/api/qr/codes")
def api_qr_codes(
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    search: str = "",
    status: str = Query("", description="Filter by derived status"),
    date_range: str = Query("7d", description="Time window filter"),
    sort: str = Query("issued_at", description="Sort column"),
    order: str = Query("desc", description="Sort direction"),
    claims: Dict[str, Any] = Depends(require_admin),
):
```

Then at the top of the function body, add validation:

```python
    if status and status not in VALID_QR_STATUSES:
        raise HTTPException(422, f"Invalid status: {status}. Must be one of: {', '.join(s for s in VALID_QR_STATUSES if s)}")
    if date_range not in VALID_QR_DATE_RANGES:
        raise HTTPException(422, f"Invalid date_range: {date_range}. Must be one of: {', '.join(VALID_QR_DATE_RANGES)}")
    if sort not in VALID_QR_SORT_COLS:
        raise HTTPException(422, f"Invalid sort: {sort}. Must be one of: {', '.join(VALID_QR_SORT_COLS)}")
    if order not in VALID_QR_ORDERS:
        raise HTTPException(422, f"Invalid order: {order}. Must be one of: {', '.join(VALID_QR_ORDERS)}")
```

Remove the existing `limit = min(limit, 200)` line since `Query(50, ge=1, le=200)` handles it.

Also update `api_qr_stats`:

```python
@app.get("/api/qr/stats")
def api_qr_stats(
    date_range: str = Query("7d", description="Time window filter"),
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Aggregate QR statistics for the management page stats row."""
    if date_range not in VALID_QR_DATE_RANGES:
        raise HTTPException(422, f"Invalid date_range: {date_range}. Must be one of: {', '.join(VALID_QR_DATE_RANGES)}")
    stats = ORGDB.get_qr_stats(date_range=date_range)
    return {"ok": True, **stats}
```

**Step 2: Run tests to verify they pass**

Run: `python -m pytest tests/test_qr_management.py -v`
Expected: ALL 16 tests PASS (11 existing + 5 new validation tests)

**Step 3: Commit**

```bash
git add src/backend/main.py tests/test_qr_management.py
git commit -m "fix(qr-management): add input validation for sort/order/date_range/status params"
```

---

### Task 3: Write failing test for status-filtered pagination accuracy (Issue 1)

**Files:**
- Modify: `tests/test_qr_management.py`

**Step 1: Write the failing test**

This test creates enough codes to expose the over-fetch problem:

```python
class TestQRCodesStatusFilterAccuracy:
    """Status-filtered pagination returns accurate total count."""

    def test_status_filter_total_is_accurate(self, client, db_conn, created_users):
        """Total count for status-filtered query matches actual count."""
        # Get total pending from stats endpoint (ground truth)
        stats = client.get("/api/qr/stats", params={"date_range": "all"}).json()

        # Get pending codes from list endpoint
        resp = client.get("/api/qr/codes", params={
            "limit": 200, "offset": 0, "status": "pending",
            "date_range": "all", "sort": "issued_at", "order": "desc",
        })
        data = resp.json()

        # The total should match the stats count
        assert data["total"] == stats["pending"], \
            f"List total ({data['total']}) != stats pending ({stats['pending']})"
```

**Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_qr_management.py::TestQRCodesStatusFilterAccuracy -v`
Expected: May PASS with small dataset but will FAIL when over-fetch window (limit*4) doesn't capture all rows. The fundamental fix is still needed.

---

### Task 4: Fix status-filtered pagination to be exhaustive (Issue 1)

**Files:**
- Modify: `src/backend/orgdb.py` (lines 695-771)

**Step 1: Replace over-fetch heuristic with two-pass approach**

The current approach fetches `limit * 4` rows and hopes enough match the status filter. Replace with:
- **Pass 1:** Count query that fetches all rows matching date_range + search, derives status in Python, counts matches (for accurate total)
- **Pass 2:** Paginated fetch starting from offset, scanning until `limit` matches found

Replace lines 695-771 (from `# Count total` through `return results, total`) with:

```python
        # When status-filtering, we need accurate total and correct pagination.
        # Derive status for ALL matching rows (date_range + search only),
        # then filter and paginate in Python.
        if status:
            # Fetch all rows (no SQL pagination — status is derived post-query)
            data_stmt = (
                select(*base_cols)
                .select_from(j)
                .order_by(sort_expr)
            )
            for cond in conditions:
                data_stmt = data_stmt.where(cond)

            with eng.begin() as conn:
                rows = conn.execute(data_stmt).mappings().all()

            # Derive status and filter
            filtered = []
            for r in rows:
                display_status = self._derive_qr_status(r, now)
                if display_status != status:
                    continue
                filtered.append(self._format_qr_row(r, display_status, now))

            total = len(filtered)
            results = filtered[offset : offset + limit]
            return results, total

        # No status filter — use SQL pagination directly
        count_stmt = select(func.count()).select_from(j)
        for cond in conditions:
            count_stmt = count_stmt.where(cond)

        data_stmt = (
            select(*base_cols)
            .select_from(j)
            .order_by(sort_expr)
            .limit(limit)
            .offset(offset)
        )
        for cond in conditions:
            data_stmt = data_stmt.where(cond)

        with eng.begin() as conn:
            total = conn.execute(count_stmt).scalar() or 0
            rows = conn.execute(data_stmt).mappings().all()

        results = []
        for r in rows:
            display_status = self._derive_qr_status(r, now)
            results.append(self._format_qr_row(r, display_status, now))

        return results, total
```

**Step 2: Extract helper methods to avoid duplication**

Add two private methods to the OrgDB class (after `list_qr_codes`):

```python
    @staticmethod
    def _derive_qr_status(row, now) -> str:
        """Derive display status from a joined qr_issuance_audit + provision_tokens row."""
        expires_at = row["expires_at"]
        if expires_at and expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)

        if row["consumed"]:
            return "consumed"
        if row["token_status"] in ("revoked_terminated", "revoked"):
            return "revoked"
        if expires_at and expires_at < now:
            return "expired"
        return "pending"

    @staticmethod
    def _format_qr_row(row, display_status: str, now) -> dict[str, Any]:
        """Format a joined row into the API response shape."""
        platform = row["client_platform"]
        device_id = row["consumed_by_device_id"]
        device_info = None
        if platform and device_id:
            device_info = f"{platform} ({device_id[:8]})"
        elif platform:
            device_info = platform
        elif device_id:
            device_info = f"Device {device_id[:8]}"

        return {
            "id": row["id"],
            "token_hash": row["token_hash"],
            "user_uid": row["user_uid"],
            "org_dn": row["org_dn"],
            "status": display_status,
            "device_info": device_info,
            "client_platform": row["client_platform"],
            "issued_at": row["issued_at"].isoformat() if row["issued_at"] else None,
            "expires_at": row["expires_at"].isoformat() if row["expires_at"] else None,
            "consumed_at": row["consumed_at"].isoformat() if row["consumed_at"] else None,
            "issued_by": row["issued_by"],
        }
```

Also update `get_qr_stats` to use `_derive_qr_status` instead of duplicating the logic:

```python
    def get_qr_stats(self, date_range: str = "7d") -> dict[str, int]:
        """...(keep existing docstring)..."""
        eng = self.connect()
        j = qr_issuance_audit.outerjoin(
            provision_tokens,
            qr_issuance_audit.c.token_hash == provision_tokens.c.token_hash,
        )

        now = datetime.now(timezone.utc)
        conditions = []

        if date_range != "all":
            days_map = {"7d": 7, "30d": 30, "90d": 90}
            days = days_map.get(date_range, 7)
            cutoff = now - timedelta(days=days)
            conditions.append(qr_issuance_audit.c.issued_at >= cutoff)

        data_stmt = (
            select(
                qr_issuance_audit.c.consumed,
                qr_issuance_audit.c.expires_at,
                provision_tokens.c.status.label("token_status"),
            )
            .select_from(j)
        )
        for cond in conditions:
            data_stmt = data_stmt.where(cond)

        with eng.begin() as conn:
            rows = conn.execute(data_stmt).mappings().all()

        stats: dict[str, int] = {
            "total_generated": 0,
            "consumed": 0,
            "pending": 0,
            "expired_unused": 0,
        }
        for r in rows:
            stats["total_generated"] += 1
            s = self._derive_qr_status(r, now)
            if s == "consumed":
                stats["consumed"] += 1
            elif s == "revoked":
                pass  # revoked — not counted in pending or expired
            elif s == "expired":
                stats["expired_unused"] += 1
            else:
                stats["pending"] += 1

        return stats
```

**Step 3: Run tests to verify they pass**

Run: `python -m pytest tests/test_qr_management.py -v`
Expected: ALL tests PASS

**Step 4: Commit**

```bash
git add src/backend/orgdb.py tests/test_qr_management.py
git commit -m "fix(qr-management): accurate status-filtered pagination + extract DRY helpers"
```

---

### Task 5: Write failing test for batch LDAP lookup (Issue 2)

**Files:**
- Modify: `tests/test_qr_management.py`

**Step 1: Write the test**

This is more of a performance concern than a correctness issue. The test verifies that the endpoint response time is acceptable for a page of results:

```python
import time

class TestQRCodesPerformance:
    """Performance characteristics of QR code endpoints."""

    def test_codes_endpoint_responds_within_2s(self, client, db_conn, created_users):
        """List endpoint with LDAP enrichment responds within 2 seconds."""
        start = time.monotonic()
        resp = client.get("/api/qr/codes", params={
            "limit": 50, "offset": 0, "date_range": "all",
            "sort": "issued_at", "order": "desc",
        })
        elapsed = time.monotonic() - start
        assert resp.status_code == 200
        assert elapsed < 2.0, f"Endpoint took {elapsed:.2f}s (limit: 2.0s)"
```

**Step 2: Run test**

Run: `python -m pytest tests/test_qr_management.py::TestQRCodesPerformance -v`
Expected: PASS (likely already under 2s with ~20 codes)

---

### Task 6: Add batch LDAP user lookup function (Issue 2)

**Files:**
- Modify: `src/backend/ldap_client.py`

**Step 1: Add `get_users_batch` function**

Add after the existing `get_user` function:

```python
def get_users_batch(uids: list[str]) -> dict[str, dict[str, Any]]:
    """Fetch multiple users by uid in a single LDAP search.

    - Uses OR filter: (|(uid=a)(uid=b)...)
    - Returns dict keyed by uid
    - Missing users are silently omitted
    """
    if not uids:
        return {}

    def _op():
        conn = get_conn()
        ensure_ou(conn, OU_PEOPLE)
        # Build OR filter: (|(uid=escaped1)(uid=escaped2)...)
        uid_clauses = "".join(f"(uid={escape_filter_chars(u)})" for u in uids)
        ldap_filter = f"(|{uid_clauses})" if len(uids) > 1 else f"(uid={escape_filter_chars(uids[0])})"
        conn.search(
            OU_PEOPLE,
            ldap_filter,
            SUBTREE,
            attributes=["uid", "cn", "mail", "mobile", "sn", "givenName",
                         "userPassword", "description"],
        )
        result = {}
        for e in conn.entries:
            uid = str(e.uid.value)
            result[uid] = {
                "uid": uid,
                "displayName": str(e.cn.value) if hasattr(e, "cn") else uid,
                "mail": str(e.mail.value) if hasattr(e, "mail") else "",
                "mobile": str(e.mobile.value) if hasattr(e, "mobile") else "",
                "orgDn": _infer_org_dn_from_user_dn(e.entry_dn),
                "accountStatus": _derive_account_status(e),
            }
        conn.unbind()
        return result
    return safe_ldap(_op)
```

**Step 2: Update `api_qr_codes` to use batch lookup**

In `src/backend/main.py`, change the import line to include `get_users_batch`:

```python
from ldap_client import ..., get_users_batch
```

Then replace lines 1652-1661:

```python
    # Batch LDAP user lookup for display names and orgs
    unique_uids = list({c["user_uid"] for c in codes})
    user_cache: Dict[str, Dict[str, Any]] = {}
    for uid in unique_uids:
        try:
            user = get_user(uid)
            if user:
                user_cache[uid] = user
        except Exception:
            pass  # LDAP lookup failed — skip enrichment for this user
```

With:

```python
    # Single LDAP search for all unique users on this page
    unique_uids = list({c["user_uid"] for c in codes})
    try:
        user_cache = get_users_batch(unique_uids) if unique_uids else {}
    except Exception:
        user_cache = {}  # LDAP lookup failed — skip enrichment
```

**Step 3: Run all tests**

Run: `python -m pytest tests/test_qr_management.py -v`
Expected: ALL tests PASS

**Step 4: Commit**

```bash
git add src/backend/ldap_client.py src/backend/main.py tests/test_qr_management.py
git commit -m "perf(qr-management): batch LDAP lookup replaces N sequential get_user() calls"
```

---

### Task 7: Run full test suite and verify no regressions

**Step 1: Run all tests**

Run: `python -m pytest tests/ --ignore=tests/test_breakglass.py -v`
Expected: All existing tests + all new tests PASS

**Step 2: TypeScript check (no frontend changes but verify)**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: Only 2 pre-existing errors (group-management/useModalState.ts, user-management/QRGenerationModal.tsx)

**Step 3: Commit (if any cleanup needed)**

If everything passes, no commit needed for this task.

---

## Summary

| Task | Issue(s) | Files | Type |
|------|----------|-------|------|
| 1 | 3, 4, 5 | `tests/test_qr_management.py` | Test (red) |
| 2 | 3, 4, 5 | `src/backend/main.py` | Fix (green) |
| 3 | 1 | `tests/test_qr_management.py` | Test (red) |
| 4 | 1 | `src/backend/orgdb.py` | Fix (green) |
| 5 | 2 | `tests/test_qr_management.py` | Test (red) |
| 6 | 2 | `src/backend/ldap_client.py`, `src/backend/main.py` | Fix (green) |
| 7 | — | Full suite | Verify |

**Estimated time:** ~20 minutes
**Expected commits:** 3
