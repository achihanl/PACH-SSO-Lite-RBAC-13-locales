# Profile Template System — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Ship 3 built-in schemas (pjsip-combined, sip-legacy, xmpp-only) with auto-computed realmed passwords, and add schema_name support to the backend's tenant_ldap_configs table.

**Architecture:** Extend UED Sync schema registry with 2 new schema modules, add a pre-processing hook for derived field computation, and integrate schema_name into the backend's tenant config CRUD + sync pipeline.

**Tech Stack:** Python 3.11+, FastAPI, Pydantic v2, PostgreSQL (JSONB), OpenLDAP, hashlib (MD5)

**Domains:** backend, database, test

---

### Task 1: Create XMPP-only schema module
**domain:** backend
**depends_on:** []
**parallel_group:** 1

**Files:**
- Create: `src/ued-sync/src/ued_sync/schemas/xmpp.py`

**Step 1:** Create the schema module with factory function.

```python
# src/ued-sync/src/ued_sync/schemas/xmpp.py
"""XMPP-only posixAccount provisioning schema.

Minimal schema for XMPP servers that authenticate via LDAP bind.
No SIP attributes — just posixAccount + userPassword (SSHA).

XMPP auth model:
  - Server binds to LDAP with user's DN + password
  - DN: uid={username},ou=People,{base_dn}
  - No XMPP-specific objectClass needed
"""

from ued_sync.schema import ProvisioningSchema


def xmpp_standard_schema() -> ProvisioningSchema:
    """Build the XMPP-only provisioning schema.

    - objectClasses: posixAccount (LDAP bind auth)
    - Password: userPassword with SSHA hash
    - No SIP attributes
    """
    return ProvisioningSchema(
        dn_template="uid={username},ou=People,{base_dn}",
        object_classes=["top", "account", "posixAccount"],
        attribute_map={
            "uid": "{username}",
            "cn": "{display_name}",
            "uidNumber": "{uid_number}",
            "gidNumber": "1000",
            "homeDirectory": "/home/{username}",
            "loginShell": "/bin/bash",
        },
        required_fields=["username", "display_name", "uid_number"],
        password_attribute="userPassword",
        password_hash="SSHA",
    )
```

---

### Task 2: Create SIP legacy schema module with realmed password auto-computation
**domain:** backend
**depends_on:** []
**parallel_group:** 1

**Files:**
- Create: `src/ued-sync/src/ued_sync/schemas/sip_legacy.py`

**Step 1:** Create the schema module with factory + prepare_user_data.

```python
# src/ued-sync/src/ued_sync/schemas/sip_legacy.py
"""Legacy Asterisk SIP (chan_sip) provisioning schema.

For Asterisk deployments using chan_sip (pre-PJSIP, removed in Asterisk 21+).
Proven against real server at 192.168.122.89 where 100% of SIP entries use
AsteriskSIPUser objectClass.

Key difference from PJSIP:
  - Uses AsteriskSIPUser (not PjsipEndpoint/Auth/Aor)
  - AstAccountRealmedPassword = MD5(extension:realm:password) for digest auth
  - AstAccountSecret = plaintext SIP password
  - Includes inetLocalMailRecipient for mail routing
"""

import hashlib

from ued_sync.config import settings
from ued_sync.schema import ProvisioningSchema


def compute_realmed_password(extension: str, realm: str, password: str) -> str:
    """Compute SIP digest auth HA1: MD5(extension:realm:password).

    - extension: SIP extension number (e.g., "6001")
    - realm: SIP auth realm (e.g., "azblink2")
    - password: plaintext SIP password
    - Returns: lowercase hex MD5 digest (32 chars)
    """
    return hashlib.md5(f"{extension}:{realm}:{password}".encode()).hexdigest()


def prepare_user_data(user_data: dict[str, str]) -> dict[str, str]:
    """Auto-compute sip_realmed_password if not provided.

    Uses MD5(extension:SIP_AUTH_REALM:sip_password) per RFC 2617.
    Skips computation if:
      - sip_realmed_password already present (caller override)
      - extension or sip_password missing (will fail required_fields check later)
    """
    data = dict(user_data)
    if "sip_realmed_password" not in data:
        extension = data.get("extension")
        sip_password = data.get("sip_password")
        if extension and sip_password:
            data["sip_realmed_password"] = compute_realmed_password(
                extension, settings.sip_auth_realm, sip_password
            )
    return data


def sip_legacy_schema() -> ProvisioningSchema:
    """Build the legacy AsteriskSIPUser provisioning schema.

    - objectClasses: posixAccount + AsteriskSIPUser + inetLocalMailRecipient
    - SIP auth: AstAccountSecret (plaintext) + AstAccountRealmedPassword (MD5)
    - Password: userPassword with SSHA hash (enables LDAP bind auth / XMPP)
    """
    return ProvisioningSchema(
        dn_template="uid={username},ou=People,{base_dn}",
        object_classes=[
            "top",
            "account",
            "posixAccount",
            "AsteriskSIPUser",
            "inetLocalMailRecipient",
        ],
        attribute_map={
            # POSIX
            "uid": "{username}",
            "cn": "{display_name}",
            "uidNumber": "{uid_number}",
            "gidNumber": "1007",
            "homeDirectory": "/home/{username}",
            "loginShell": "/bin/bash",
            "gecos": "{display_name}",
            # Mail
            "mailHost": "{mail_host}",
            # SIP
            "AstAccountName": "{extension}",
            "AstAccountHost": "dynamic",
            "AstAccountType": "friend",
            "AstAccountSecret": "{sip_password}",
            "AstAccountRealmedPassword": "{sip_realmed_password}",
            "AstAccountCallerID": "{extension}",
            "AstAccountCallGroup": "1",
            "AstAccountPickupGroup": "1",
            "AstAccountMailbox": "{extension}",
            "AstAccountQualify": "yes",
            "AstAccountContext": "all",
            "AstAccountCanReinvite": "no",
        },
        required_fields=[
            "username", "display_name", "uid_number",
            "extension", "sip_password",
        ],
        optional_fields=["mail_host", "sip_realmed_password"],
        password_attribute="userPassword",
        password_hash="SSHA",
    )
```

---

### Task 3: Register new schemas in registry
**domain:** backend
**depends_on:** [1, 2]
**parallel_group:** 2

**Files:**
- Modify: `src/ued-sync/src/ued_sync/schemas/__init__.py`

**Step 1:** Add imports and registry entries.

Update `__init__.py`:
- Add import: `from ued_sync.schemas.sip_legacy import sip_legacy_schema`
- Add import: `from ued_sync.schemas.xmpp import xmpp_standard_schema`
- Add to `_REGISTRY`: `"sip-legacy": sip_legacy_schema`
- Add to `_REGISTRY`: `"xmpp-only": xmpp_standard_schema`

---

### Task 4: Unit tests for new schemas + prepare_user_data
**domain:** test
**depends_on:** [1, 2, 3]
**parallel_group:** 3

**Files:**
- Modify: `src/ued-sync/tests/test_schema_registry.py` (add schema tests)
- Create: `src/ued-sync/tests/test_sip_legacy.py` (prepare_user_data tests)

**Step 1:** Add registry tests for both new schemas to `test_schema_registry.py`:

```python
# Tests to add:
def test_get_schema_sip_legacy():
    """Registry returns a valid ProvisioningSchema for 'sip-legacy'."""
    schema = get_schema("sip-legacy")
    assert isinstance(schema, ProvisioningSchema)
    assert "AsteriskSIPUser" in schema.object_classes
    assert "inetLocalMailRecipient" in schema.object_classes
    assert "posixAccount" in schema.object_classes
    assert schema.password_hash == "SSHA"

def test_get_schema_sip_legacy_has_required_fields():
    """sip-legacy requires username, display_name, uid_number, extension, sip_password."""
    schema = get_schema("sip-legacy")
    for f in ["username", "display_name", "uid_number", "extension", "sip_password"]:
        assert f in schema.required_fields

def test_get_schema_sip_legacy_has_sip_attrs():
    """sip-legacy maps all AsteriskSIPUser attributes."""
    schema = get_schema("sip-legacy")
    attr_map = schema.attribute_map
    assert "AstAccountName" in attr_map
    assert "AstAccountSecret" in attr_map
    assert "AstAccountRealmedPassword" in attr_map
    assert "AstAccountContext" in attr_map

def test_get_schema_xmpp_only():
    """Registry returns a valid ProvisioningSchema for 'xmpp-only'."""
    schema = get_schema("xmpp-only")
    assert isinstance(schema, ProvisioningSchema)
    assert "posixAccount" in schema.object_classes
    assert len(schema.object_classes) == 3  # top, account, posixAccount
    assert schema.password_hash == "SSHA"

def test_get_schema_xmpp_only_has_required_fields():
    """xmpp-only requires username, display_name, uid_number."""
    schema = get_schema("xmpp-only")
    assert schema.required_fields == ["username", "display_name", "uid_number"]

def test_get_schema_xmpp_only_no_sip_attrs():
    """xmpp-only has no Asterisk SIP attributes."""
    schema = get_schema("xmpp-only")
    for attr in schema.attribute_map:
        assert not attr.startswith("Ast"), f"Unexpected SIP attr: {attr}"

def test_list_schemas_includes_all():
    """list_schemas returns all 3 built-in schemas."""
    names = list_schemas()
    assert "pjsip-combined" in names
    assert "sip-legacy" in names
    assert "xmpp-only" in names
    assert len(names) == 3
```

**Step 2:** Create `test_sip_legacy.py` for prepare_user_data and compute_realmed_password:

```python
# Tests to create in test_sip_legacy.py:
def test_compute_realmed_password():
    """MD5(extension:realm:password) produces correct hex digest."""

def test_compute_realmed_password_known_value():
    """Verify against known MD5 from E2E report: MD5(6801:azblink2:z6wjnncm)."""

def test_prepare_user_data_auto_computes():
    """prepare_user_data adds sip_realmed_password when extension + sip_password present."""

def test_prepare_user_data_skips_if_present():
    """prepare_user_data does NOT overwrite existing sip_realmed_password."""

def test_prepare_user_data_skips_if_missing_extension():
    """prepare_user_data skips computation when extension is missing."""

def test_prepare_user_data_skips_if_missing_password():
    """prepare_user_data skips computation when sip_password is missing."""

def test_prepare_user_data_uses_sip_auth_realm():
    """prepare_user_data uses SIP_AUTH_REALM from settings."""
```

**Step 3:** Run `just ued-test` — all unit tests must pass.

---

### Task 5: Add pre-processing hook in sync router
**domain:** backend
**depends_on:** [2, 3]
**parallel_group:** 3

**Files:**
- Modify: `src/ued-sync/src/ued_sync/routers/sync.py`

**Step 1:** In `sync_user()` function, after `schema = body.resolved_schema` (line 36),
add pre-processing for named schemas that export `prepare_user_data`:

```python
# After line 36: schema = body.resolved_schema
# Pre-process user data for schemas with derived fields
user_data = body.user.copy()
if body.schema_name == "sip-legacy":
    from ued_sync.schemas.sip_legacy import prepare_user_data
    user_data = prepare_user_data(user_data)
```

**Step 2:** Replace `body.user` with `user_data` in:
- Line 39-43: `dn_values` dict (change `body.user` → `user_data`)
- Line 53: `build_attributes(schema, body.user)` → `build_attributes(schema, user_data)`
- Line 61: same for update branch

**Step 3:** Do the same in `batch.py` router if batch also supports sip-legacy.

---

### Task 6: Integration tests for sip-legacy on dev stack
**domain:** test
**depends_on:** [4, 5]
**parallel_group:** 4

**Files:**
- Create: `src/ued-sync/tests/integration/test_sip_legacy_provisioning.py`

**Step 1:** Create integration tests modeled after `test_sip_provisioning.py`:

```python
# Test classes:
class TestSipLegacyProvisioningCorrectness:
    def test_provision_legacy_sip_user_creates_valid_entry(...)
    # Verify: AsteriskSIPUser objectClass, all Ast* attrs, realmed password is correct MD5

class TestSipLegacyLdapBindAuth:
    def test_provision_legacy_sip_user_ldap_bind_succeeds(...)
    def test_provision_legacy_sip_user_wrong_password_bind_fails(...)

class TestSipLegacySchemaNameProvisioning:
    def test_provision_via_schema_name_sip_legacy(...)
    # Uses schema_name="sip-legacy" instead of inline schema

class TestSipLegacyRealmedPassword:
    def test_realmed_password_auto_computed(...)
    # Verify AstAccountRealmedPassword == MD5(extension:realm:sip_password)
    def test_realmed_password_manual_override(...)
    # Verify caller-provided sip_realmed_password is NOT overwritten
```

**Step 2:** Run `just ued-test-integration` — all tests must pass on dev stack.

---

### Task 7: Integration tests for xmpp-only on dev stack
**domain:** test
**depends_on:** [4]
**parallel_group:** 4

**Files:**
- Create: `src/ued-sync/tests/integration/test_xmpp_provisioning.py`

**Step 1:** Create XMPP integration tests:

```python
class TestXmppOnlyProvisioning:
    def test_provision_xmpp_user_creates_valid_entry(...)
    # Verify: posixAccount only, no Ast* attrs

class TestXmppOnlyLdapBindAuth:
    def test_xmpp_user_ldap_bind_succeeds(...)
    def test_xmpp_user_wrong_password_bind_fails(...)

class TestXmppOnlySchemaName:
    def test_provision_via_schema_name_xmpp_only(...)
```

**Step 2:** Run `just ued-test-integration` — all tests must pass.

---

### Task 8: Backend migration — add schema_name to tenant_ldap_configs
**domain:** database
**depends_on:** []
**parallel_group:** 1

**Files:**
- Create: `migrations/011_ued_schema_name.sql`

**Step 1:** Write idempotent migration:

```sql
-- migrations/011_ued_schema_name.sql
-- Add schema_name support to tenant_ldap_configs
BEGIN;

ALTER TABLE tenant_ldap_configs
    ADD COLUMN IF NOT EXISTS schema_name TEXT;

ALTER TABLE tenant_ldap_configs
    ALTER COLUMN schema_config DROP NOT NULL;

-- At least one schema source must be present
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_schema_source'
    ) THEN
        ALTER TABLE tenant_ldap_configs
        ADD CONSTRAINT chk_schema_source CHECK (
            schema_config IS NOT NULL OR schema_name IS NOT NULL
        );
    END IF;
END $$;

COMMENT ON COLUMN tenant_ldap_configs.schema_name IS
    'Built-in schema name (e.g., pjsip-combined, sip-legacy, xmpp-only). '
    'Mutually exclusive with schema_config — provide one or the other.';

COMMIT;
```

**Step 2:** Run migration: `just psql < ../../migrations/011_ued_schema_name.sql`
**Step 3:** Verify: `just psql -c "\d tenant_ldap_configs"` shows schema_name column.

---

### Task 9: Backend model + API updates for schema_name
**domain:** backend
**depends_on:** [8]
**parallel_group:** 5

**Files:**
- Modify: `src/backend/orgdb.py` (table model + CRUD method)
- Modify: `src/backend/main.py` (request models + endpoint)

**Step 1:** Update `orgdb.py` table definition (line ~275):
- Change `schema_config` column: `nullable=True` (was False)
- Add `Column("schema_name", Text, nullable=True)` after `schema_config`

**Step 2:** Update `create_tenant_ldap_config()` method (line ~2317):
- Add `schema_name: str | None = None` parameter
- Include `schema_name=schema_name` in INSERT values
- Make `schema_config` conditional: only `json.dumps()` if not None

**Step 3:** Update `main.py` request models (line ~3060):
- `TenantConfigCreateReq`: add `schema_name: Optional[str] = None`, make `schema_config: Optional[dict] = None`
- Add `@model_validator(mode='after')` to enforce exactly-one-present rule
- `TenantConfigUpdateReq`: add `schema_name: Optional[str] = None`
- Add validator preventing both set simultaneously

**Step 4:** Update `api_ued_config_create()` (line ~3100):
- Pass `schema_name=req.schema_name` to `ORGDB.create_tenant_ldap_config()`

---

### Task 10: Backend sync client + worker updates for schema_name
**domain:** backend
**depends_on:** [9]
**parallel_group:** 6

**Files:**
- Modify: `src/backend/ued_sync_client.py`
- Modify: `src/backend/sync_worker.py`

**Step 1:** Update `ued_sync_client.py`:
- Add `schema_name: str | None = None` to `_build_request()` and `send()` signatures
- In request body construction, use `schema_name` when available:
  ```python
  if schema_name:
      body["schema_name"] = schema_name
  elif schema_config:
      body["schema"] = schema_config
  ```

**Step 2:** Update `sync_worker.py` `_process_event()` (line ~118):
- Pass `schema_name=config.get("schema_name")` to `self.ued_client.send()`

**Step 3:** Hot reload should pick up changes (no rebuild needed for .py changes).

---

### Task 11: Backend integration tests for schema_name
**domain:** test
**depends_on:** [9, 10]
**parallel_group:** 7

**Files:**
- Tests in existing `tests/` directory

**Step 1:** Test the API validation:
- POST `/api/ued/configs` with `schema_name: "sip-legacy"` (no `schema_config`) → 201
- POST `/api/ued/configs` with both `schema_config` and `schema_name` → 422
- POST `/api/ued/configs` with neither → 422
- PATCH `/api/ued/configs/{id}` setting `schema_name` → 200

**Step 2:** Run `just test` — all backend tests must pass.

---

### Task 12: Full E2E validation
**domain:** test
**depends_on:** [6, 7, 10, 11]
**parallel_group:** 8

**Step 1:** Run full test suites:
- `just ued-test` — all UED Sync unit tests
- `just ued-test-integration` — all UED Sync integration tests
- `just test` — all backend tests

**Step 2:** Manual smoke test via API docs:
- Create tenant config with `schema_name: "sip-legacy"` via Swagger UI
- Verify `GET /api/ued/configs` shows the config with `schema_name`

**Step 3:** Verify `list_schemas()` endpoint (if exposed) returns all 3 schemas.
