# QR Stats: Inline Trend Indicators (Replace Stat Cards)

**Date:** 2026-02-10
**Status:** Active

## Problem

The QR Code Management page displays 4 stat cards (Total Generated, Consumed, Pending, Expired Unused) that are redundant with the tab filter badges below them. Both pull from the same `/api/qr/stats` endpoint. The cards consume ~120px of vertical space without adding information.

## Decision

- **Remove** the `StatsRow` (4 stat cards) entirely
- **Collapse** a compact, live stat line into the `PageHeader` subtitle
- **Differentiate** by showing **trend data** (period-over-period comparison) that tabs cannot express

## Visual Design

**Before:**
```
Row 1: PageHeader (title + search + date range + button)
Row 2: StatsRow (4 stat cards, ~120px)
Row 3: Tabs + list
```

**After:**
```
Row 1: PageHeader (title + INLINE TRENDS + search + date range + button)
Row 2: Tabs + list  ← gains ~120px of vertical space
```

**Subtitle changes from:**
```
QR Code Management
Generate and manage provisioning QR codes
```

**To:**
```
QR Code Management
15 generated · 0% consumed · 15 expired ↑12%
```

### Trend Logic

- Comparison window = same duration as selected date range, offset by that duration
- "Last 7 days" → current 7d vs previous 7d (days -14 to -7)
- "All time" → no trend arrows (no prior period)
- Consumed trend: green ↑ is good (more adoption)
- Expired trend: red ↑ is bad (more waste)

## Backend Changes

**File:** `src/backend/orgdb.py` — `get_qr_stats()`

Expand response with previous-period counts:

```json
{
  "ok": true,
  "total_generated": 15,
  "consumed": 0,
  "pending": 0,
  "expired_unused": 15,
  "prev_total_generated": 8,
  "prev_consumed": 3,
  "prev_pending": 1,
  "prev_expired_unused": 4
}
```

- When `date_range=all`, `prev_*` fields are `null`
- Second SQL query with offset window: `issued_at >= cutoff - duration AND issued_at < cutoff`

## Frontend Changes

| File | Action |
|------|--------|
| `StatsRow.tsx` | Delete |
| `QRManagementPage.tsx` | Remove `<StatsRow>`, hoist stats fetch, pass to `PageHeader` |
| `PageHeader.tsx` | Add `stats` prop, render inline trend subtitle |
| `qr-management.ts` (types) | Extend `QRStats` with `prev_*` fields |

### Trend Calculation

```typescript
function trendPercent(current: number, previous: number | null): string | null {
  if (previous === null || previous === 0) return null;
  const delta = ((current - previous) / previous) * 100;
  return `${delta > 0 ? '+' : ''}${Math.round(delta)}%`;
}
```

## Files Deleted

- `src/frontend/src/components/features/qr-management/StatsRow.tsx`

## Not Changed

- `stat-card.tsx` — kept for org-management and future use
- Tab badge counts — unchanged, still show per-status counts
- `/api/qr/stats` endpoint signature — additive fields only, no breaking changes
