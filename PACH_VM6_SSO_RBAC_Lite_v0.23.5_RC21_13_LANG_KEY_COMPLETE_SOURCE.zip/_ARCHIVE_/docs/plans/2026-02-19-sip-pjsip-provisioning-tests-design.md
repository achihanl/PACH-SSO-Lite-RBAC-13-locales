# SIP/PJSIP Provisioning Integration Tests — Design

**Date:** 2026-02-19
**Status:** Approved
**Scope:** UED Sync integration tests for Asterisk PJSIP LDAP provisioning + bind auth validation

## Problem

- UED Sync has 182+ tests covering generic LDAP provisioning (posixAccount schema)
- Zero test coverage for Asterisk/PJSIP-specific provisioning
- Dev OpenLDAP does not load the Asterisk PJSIP schema — cannot store SIP entries
- No verification that UED Sync can provision well-formed SIP entries usable by Asterisk

## Goals

1. **Provisioning correctness** — verify UED Sync creates LDAP entries with PJSIP objectClasses and attributes against real OpenLDAP
2. **LDAP bind auth validation** — verify provisioned SIP users can authenticate via LDAP bind (Layer 1 management-style auth)

## Non-Goals (Explicit Scope Boundary)

- SIP digest auth (Layer 2 — RFC 3261 challenge-response) — requires Asterisk
- Asterisk sorcery.conf / res_pjsip_ldap.conf generation or testing
- Multi-device AoR scenarios
- TLS/STARTTLS on LDAP connections (dev stack uses plaintext)

## Approach

**Single combined LDAP entry (Approach A):** One entry per SIP user carries all three PJSIP objectClasses alongside posixAccount on the same DN. Matches the `addComboPJ` pattern from the reference architecture.

## Architecture

### SIP Authentication Layers (Reference)

```
Layer 1: Management Bind (tested here)
  Asterisk binds to LDAP as service account → reads user credentials
  Equivalent: UED Sync's /api/v1/sync/auth/validate does search + bind

Layer 2: SIP Digest Auth (NOT tested — requires Asterisk)
  Asterisk reads AstAuthPassword from LDAP → computes MD5 digest locally
  Phone sends REGISTER with digest → Asterisk compares
```

### Test Flow

```
Test                         UED Sync API                   OpenLDAP
 │                              │                              │
 │  1. POST /sync/user          │                              │
 │     (create, pjsip_schema)   │                              │
 │ ────────────────────────────>│  2. ldap_add(dn, attrs)      │
 │                              │ ────────────────────────────>│
 │                              │  3. Success                   │
 │                              │<─────────────────────────────│
 │  4. 200 OK {ok: true}        │                              │
 │<─────────────────────────────│                              │
 │                              │                              │
 │  5. POST /sync/auth/validate │                              │
 │     (username, password)     │                              │
 │ ────────────────────────────>│  6. ldapsearch(uid=...)      │
 │                              │ ────────────────────────────>│
 │                              │  7. Entry found              │
 │                              │<─────────────────────────────│
 │                              │  8. ldap_bind(user_dn, pw)   │
 │                              │ ────────────────────────────>│
 │                              │  9. Bind success             │
 │                              │<─────────────────────────────│
 │  10. 200 {authenticated: true}│                              │
 │<─────────────────────────────│                              │
```

## Deliverables

### 1. PJSIP LDAP Schema File

**File:** `deploy/dev/ldap/asterisk-pjsip-schema.ldif`

Defines three AUXILIARY objectClasses using `cn=config` LDIF format:

| ObjectClass | Attributes |
|-------------|-----------|
| `AsteriskPjsipEndpoint` | `AstEndpointId` (MUST), `AstEndpointAuth`, `AstEndpointAors`, `AstEndpointContext`, `AstEndpointTransport`, `AstEndpointAllow`, `AstEndpointDisallow` |
| `AsteriskPjsipAuth` | `AstAuthId` (MUST), `AstAuthType`, `AstAuthUsername`, `AstAuthPassword` |
| `AsteriskPjsipAor` | `AstAorId` (MUST), `AstAorMaxContacts` |

All AUXILIARY — attachable to any structural objectClass (account, inetOrgPerson, etc.).

**OID namespace:** `1.3.6.1.4.1.22736` (Digium/Asterisk registered OID base).

### 2. Docker Compose Schema Mount

```yaml
# deploy/dev/docker-compose.yml — openldap volumes addition
- ./ldap/asterisk-pjsip-schema.ldif:/container/service/slapd/assets/config/bootstrap/ldif/custom/00-asterisk-pjsip-schema.ldif:ro
```

`00-` prefix ensures schema loads before `bootstrap.ldif` (alphabetical ordering).

### 3. Integration Test File

**File:** `src/ued-sync/tests/integration/test_sip_provisioning.py`

**Fixture — PJSIP provisioning schema:**

```python
pjsip_schema = {
    "dn_template": "uid={username},ou=People,{base_dn}",
    "object_classes": [
        "top", "account", "posixAccount",
        "AsteriskPjsipEndpoint", "AsteriskPjsipAuth", "AsteriskPjsipAor"
    ],
    "attribute_map": {
        "uid": "{username}",
        "cn": "{display_name}",
        "uidNumber": "{extension}",
        "gidNumber": "1000",
        "homeDirectory": "/home/{username}",
        "loginShell": "/bin/bash",
        # PJSIP Endpoint
        "AstEndpointId": "{extension}",
        "AstEndpointAuth": "{extension}",
        "AstEndpointAors": "{extension}",
        "AstEndpointContext": "all",
        # PJSIP Auth
        "AstAuthId": "{extension}",
        "AstAuthType": "userpass",
        "AstAuthUsername": "{extension}",
        "AstAuthPassword": "{sip_password}",
        # PJSIP AoR
        "AstAorId": "{extension}",
        "AstAorMaxContacts": "1",
    },
    "required_fields": ["username", "display_name", "extension", "sip_password"],
    "password_attribute": "userPassword",
    "password_hash": "SSHA",
}
```

**Test cases:**

| # | Test | Proves |
|---|------|--------|
| 1 | `test_provision_sip_user_creates_valid_entry` | LDAP entry created with all PJSIP objectClasses + attributes |
| 2 | `test_provision_sip_user_ldap_bind_succeeds` | Provisioned user's POSIX password works for LDAP bind |
| 3 | `test_provision_sip_user_wrong_password_bind_fails` | Wrong password returns `authenticated: false` |
| 4 | `test_sip_user_update_preserves_pjsip_attributes` | Updating display_name doesn't wipe PJSIP attributes |
| 5 | `test_sip_user_full_lifecycle` | Create → bind auth → update → bind auth → delete round-trip |

### 4. Justfile Update

No changes needed — `just ued-test-integration` already runs all `@pytest.mark.integration` tests in the integration directory.

## Stack Impact

- **Requires:** `just reset && just up` (one-time) to load new PJSIP schema into OpenLDAP
- **No backend code changes** — UED Sync is already schema-agnostic
- **No frontend changes**

## LDAP Entry Example (What Gets Created)

```ldif
dn: uid=siptest6830,ou=People,dc=azblink,dc=com
objectClass: top
objectClass: account
objectClass: posixAccount
objectClass: AsteriskPjsipEndpoint
objectClass: AsteriskPjsipAuth
objectClass: AsteriskPjsipAor
uid: siptest6830
cn: SIP Test User 6830
uidNumber: 6830
gidNumber: 1000
homeDirectory: /home/siptest6830
loginShell: /bin/bash
userPassword: {SSHA}<hashed>
AstEndpointId: 6830
AstEndpointAuth: 6830
AstEndpointAors: 6830
AstEndpointContext: all
AstAuthId: 6830
AstAuthType: userpass
AstAuthUsername: 6830
AstAuthPassword: haha123
AstAorId: 6830
AstAorMaxContacts: 1
```

**Linkage chain:** `Endpoint --(AstEndpointAuth: 6830)--> Auth --(AstAuthId: 6830)--> password lookup`

## Relationship to Reference Architecture

The reference SIP auth flow described two layers:

| Layer | What Happens | Tested Here? |
|-------|-------------|--------------|
| Layer 1: Management bind | Service account binds to LDAP, reads user entry | Yes — UED Sync auth/validate does search + bind |
| Layer 2: SIP digest auth | Asterisk reads AstAuthPassword, computes MD5 digest, compares with phone's response | No — requires Asterisk server |

This test suite proves Layer 1 works end-to-end through UED Sync against real OpenLDAP with real PJSIP schema enforcement.
