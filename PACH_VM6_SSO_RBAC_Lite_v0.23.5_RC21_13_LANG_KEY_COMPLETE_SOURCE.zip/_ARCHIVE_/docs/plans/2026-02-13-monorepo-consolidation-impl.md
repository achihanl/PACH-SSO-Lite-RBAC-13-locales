# Monorepo Consolidation Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Move `azb-ldap-integration` into `src/ued-sync/` and integrate it into the existing Docker Compose dev stack so `just up` starts all services.

**Architecture:** Copy UED Sync API source as a peer service under `src/`. Add a Dockerfile and docker-compose service entry. Extend the Justfile with UED-specific recipes. No code changes to either backend — they communicate via HTTP with per-tenant config.

**Tech Stack:** Python 3.11, FastAPI, uv, Docker Compose, just

**Design doc:** `docs/plans/2026-02-13-monorepo-consolidation-design.md`

**Source repo:** `/home/keith/_WORKSPACES_/azb-ldap-integration/`

---

### Task 1: Copy UED Sync API source into monorepo

**Files:**
- Create: `src/ued-sync/` (directory tree)

**Step 1: Create target directory**

```bash
mkdir -p src/ued-sync
```

**Step 2: Copy source directories and files**

Copy these directories from `/home/keith/_WORKSPACES_/azb-ldap-integration/`:

```bash
# Source code
cp -r /home/keith/_WORKSPACES_/azb-ldap-integration/src src/ued-sync/

# Tests
cp -r /home/keith/_WORKSPACES_/azb-ldap-integration/tests src/ued-sync/

# E2E tests (Bruno CLI)
cp -r /home/keith/_WORKSPACES_/azb-ldap-integration/e2e src/ued-sync/

# Documentation
cp -r /home/keith/_WORKSPACES_/azb-ldap-integration/docs src/ued-sync/

# Scripts
cp -r /home/keith/_WORKSPACES_/azb-ldap-integration/scripts src/ued-sync/

# Generated clients
cp -r /home/keith/_WORKSPACES_/azb-ldap-integration/clients src/ued-sync/

# OpenAPI specs
cp -r /home/keith/_WORKSPACES_/azb-ldap-integration/openspec src/ued-sync/

# Config files
cp /home/keith/_WORKSPACES_/azb-ldap-integration/pyproject.toml src/ued-sync/
cp /home/keith/_WORKSPACES_/azb-ldap-integration/uv.lock src/ued-sync/
cp /home/keith/_WORKSPACES_/azb-ldap-integration/justfile src/ued-sync/
cp /home/keith/_WORKSPACES_/azb-ldap-integration/README.md src/ued-sync/
cp /home/keith/_WORKSPACES_/azb-ldap-integration/CHANGELOG.md src/ued-sync/
cp /home/keith/_WORKSPACES_/azb-ldap-integration/CLAUDE.md src/ued-sync/
cp /home/keith/_WORKSPACES_/azb-ldap-integration/.gitignore src/ued-sync/
cp /home/keith/_WORKSPACES_/azb-ldap-integration/.dockerignore src/ued-sync/
```

**Step 3: Do NOT copy these files (intentionally excluded)**

- `.env`, `.env.example` — env vars merge into monorepo `.env.example`
- `Dockerfile` — replaced by `deploy/dev/Dockerfile.ued-sync`
- `docker-compose.yml` — replaced by service entry in monorepo compose
- `.git/` — fresh start
- `.venv/`, `__pycache__/`, `.pytest_cache/`, `.ruff_cache/`, `.coverage` — build artifacts
- `ldap_provision.py`, `test_ldap.py`, `ued_provision.py` — legacy/superseded scripts
- `.claude/` — session-specific, not portable

**Step 4: Verify the copy**

```bash
ls -la src/ued-sync/
# Expected: src/ tests/ e2e/ docs/ scripts/ clients/ openspec/
#           pyproject.toml uv.lock justfile README.md CHANGELOG.md CLAUDE.md
#           .gitignore .dockerignore

ls src/ued-sync/src/ued_sync/
# Expected: main.py config.py schema.py ldap_ops.py auth.py logging.py
#           password_utils.py routers/ middleware/
```

**Step 5: Commit**

```bash
git add src/ued-sync/
git commit -m "feat: copy UED Sync API source into src/ued-sync/

Fresh copy from azb-ldap-integration repo (no git history).
Original repo will be archived on GitHub."
```

---

### Task 2: Create Dockerfile.ued-sync

**Files:**
- Create: `deploy/dev/Dockerfile.ued-sync`

**Step 1: Write the Dockerfile**

The key difference from the original Dockerfile: build context is the monorepo root (`../..`), so COPY paths start from there. Also adds `--reload` for dev hot reload, and copies tests so `just ued-test` works inside the container.

```dockerfile
# deploy/dev/Dockerfile.ued-sync
# UED Sync API — stateless LDAP provisioning worker
# Build context: repo root (../../)
FROM python:3.11-slim

WORKDIR /app

# Install uv for fast dependency management
COPY --from=ghcr.io/astral-sh/uv:latest /uv /usr/local/bin/uv

# Copy dependency files first for layer caching
COPY src/ued-sync/pyproject.toml src/ued-sync/uv.lock ./

# Install runtime + test dependencies (need test deps for `just ued-test`)
RUN uv sync --frozen

# Copy application source
COPY src/ued-sync/src/ ./src/

# Copy tests (for running inside container)
COPY src/ued-sync/tests/ ./tests/

# Create non-root user
RUN useradd --create-home --shell /bin/bash appuser && \
    chown -R appuser:appuser /app
USER appuser

ENV PYTHONPATH=/app/src
ENV PYTHONUNBUFFERED=1

EXPOSE 8000

# Dev mode: --reload for hot reload via volume mount
CMD ["/app/.venv/bin/python", "-m", "uvicorn", "ued_sync.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
```

**Step 2: Verify file exists and path references are correct**

```bash
# Check that the COPY source paths resolve from repo root
ls src/ued-sync/pyproject.toml src/ued-sync/uv.lock src/ued-sync/src/ src/ued-sync/tests/
```

Expected: all paths exist.

**Step 3: Commit**

```bash
git add deploy/dev/Dockerfile.ued-sync
git commit -m "feat: add Dockerfile for UED Sync API dev container

Builds from repo root context with uv deps, includes tests
for in-container test execution. Hot reload enabled for dev."
```

---

### Task 3: Add ued-sync service to docker-compose.yml

**Files:**
- Modify: `deploy/dev/docker-compose.yml`

**Step 1: Add the ued-sync service definition**

Insert before the `traefik:` service block (after `directory-ui:`). The service:
- Joins `azblink-net` so the main backend can reach it at `http://ued-sync:8000`
- No host port exposure (internal-only)
- Volume-mounts source for hot reload
- Includes health check
- No depends_on — UED Sync is stateless, connects to tenant LDAPs per-request

Add this YAML block:

```yaml
  # UED Sync API - stateless LDAP provisioning worker (internal)
  # Called by directory-api via HTTP. Not exposed to end users.
  ued-sync:
    networks:
      - azblink-net
    build:
      context: ../..
      dockerfile: deploy/dev/Dockerfile.ued-sync
      network: host
    container_name: azblink-ued-sync
    volumes:
      # Mount source for hot reload (overrides COPY in Dockerfile)
      - ../../src/ued-sync/src:/app/src:ro
    environment:
      - UED_API_KEY=${UED_API_KEY:-dev-ued-api-key}
      - DEBUG=${UED_DEBUG:-false}
      - RATE_LIMIT_ENABLED=${UED_RATE_LIMIT_ENABLED:-true}
      - RATE_LIMIT_REQUESTS=${UED_RATE_LIMIT_REQUESTS:-100}
    healthcheck:
      test: ["CMD", "python", "-c", "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')"]
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 5s
    restart: unless-stopped
```

**Step 2: Verify compose syntax**

```bash
cd deploy/dev && docker compose config --quiet && echo "✓ Compose syntax valid"
```

Expected: no errors.

**Step 3: Commit**

```bash
git add deploy/dev/docker-compose.yml
git commit -m "feat: add ued-sync service to dev docker-compose stack

Internal service on azblink-net, reachable at http://ued-sync:8000.
No host port — backend-to-backend only. Hot reload via volume mount."
```

---

### Task 4: Update .env.example with UED Sync env vars

**Files:**
- Modify: `deploy/dev/.env.example`

**Step 1: Replace the existing UED comment block**

The current `.env.example` has (lines 51-52):
```
# UED Sync Integration (optional — only needed if connecting to UED Sync API)
# UED_ENCRYPTION_KEY=  # Generate: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Replace with:
```bash
# === UED Sync API (internal service) ===
# API key that the ued-sync container validates incoming requests against
UED_API_KEY=dev-ued-api-key
# When creating tenant configs in admin UI, set:
#   ued_api_url: http://ued-sync:8000
#   ued_api_key: dev-ued-api-key
UED_DEBUG=false
UED_RATE_LIMIT_ENABLED=true
UED_RATE_LIMIT_REQUESTS=100

# Fernet key for encrypting tenant secrets at rest (required when UED configs exist)
# Generate: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
# UED_ENCRYPTION_KEY=
```

**Step 2: Verify no duplicate env vars**

```bash
grep -c "UED_" deploy/dev/.env.example
```

Expected: 6 lines (UED_API_KEY, comment with ued_api_url, comment with ued_api_key, UED_DEBUG, UED_RATE_LIMIT_ENABLED, UED_RATE_LIMIT_REQUESTS, UED_ENCRYPTION_KEY comment).

**Step 3: Commit**

```bash
git add deploy/dev/.env.example
git commit -m "docs: expand UED Sync env vars in .env.example

Adds UED_API_KEY, UED_DEBUG, rate limit config, and documents
the tenant config values for local dev (http://ued-sync:8000)."
```

---

### Task 5: Add UED Sync recipes to Justfile

**Files:**
- Modify: `Justfile`

**Step 1: Add UED Sync section**

Append before the Testing section (before line 232 `# Testing`). Add:

```just
# =============================================================================
# UED Sync API
# =============================================================================

# View UED Sync logs (follow mode)
ued-logs:
    cd deploy/dev && docker compose logs -f ued-sync

# Restart UED Sync (hot reload handles most Python changes)
ued-restart:
    cd deploy/dev && docker compose restart ued-sync

# Rebuild UED Sync (only needed when pyproject.toml/deps change)
ued-rebuild:
    cd deploy/dev && docker compose up -d --build ued-sync

# Run UED Sync unit + API tests (mocked LDAP, inside container)
ued-test:
    cd deploy/dev && docker compose exec ued-sync python -m pytest tests/ -v -m "not integration"

# Run UED Sync integration tests (requires real LDAP)
ued-test-integration:
    cd deploy/dev && docker compose exec ued-sync python -m pytest tests/ -v -m integration

# Run UED Sync tests with coverage
ued-test-cov:
    cd deploy/dev && docker compose exec ued-sync python -m pytest tests/ --cov=ued_sync --cov-report=term-missing
```

**Step 2: Add `test-all` recipe to the Testing section**

After the existing `test-cov` recipe (line 261), add:

```just

# Run all tests (main backend + UED Sync)
test-all: test ued-test
```

**Step 3: Update the `stats` recipe to include ued-sync**

Change line 115 from:
```just
    docker stats azblink-directory-api azblink-directory-ui azblink-postgres azblink-openldap azblink-traefik --no-stream
```
to:
```just
    docker stats azblink-directory-api azblink-directory-ui azblink-ued-sync azblink-postgres azblink-openldap azblink-traefik --no-stream
```

**Step 4: Verify justfile syntax**

```bash
just --list | grep ued
```

Expected: `ued-logs`, `ued-rebuild`, `ued-restart`, `ued-test`, `ued-test-cov`, `ued-test-integration` all listed.

**Step 5: Commit**

```bash
git add Justfile
git commit -m "feat: add ued-* recipes and test-all to Justfile

Adds ued-logs, ued-restart, ued-rebuild, ued-test, ued-test-cov,
ued-test-integration. Also adds test-all to chain both test suites."
```

---

### Task 6: Update CLAUDE.md with UED Sync service info

**Files:**
- Modify: `CLAUDE.md`

**Step 1: Add UED Sync to the "Services when running" block**

In the "Development Commands" section, after the existing services list, add:
```
- UED Sync API: http://ued-sync:8000 (internal, no host port) — docs at /docs inside container
```

**Step 2: Add to the Hot Reload Rules table**

Add these rows to the existing table:
```
| `src/ued-sync/src/**/*.py` | None - auto reload | (wait ~1s) |
| `src/ued-sync/pyproject.toml` | Rebuild UED Sync | `just ued-rebuild` |
```

**Step 3: Add UED Sync to the Repository Structure tree**

Update the `src/` section:
```
│   ├── ued-sync/                   # UED Sync API (stateless LDAP provisioner)
│   │   ├── src/ued_sync/               # FastAPI app source
│   │   ├── tests/                      # Unit + API + integration tests
│   │   ├── e2e/                        # Bruno CLI e2e tests
│   │   └── pyproject.toml              # uv-managed Python deps
```

**Step 4: Add `just ued-test` to the Testing section**

```bash
just ued-test          # Run UED Sync unit tests
just ued-test-cov      # Run UED Sync tests with coverage
just test-all          # Run ALL tests (backend + UED Sync)
```

**Step 5: Update the "Key Environment Variables" section**

Add:
```bash
# UED Sync API (internal service)
UED_API_KEY=dev-ued-api-key
```

**Step 6: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: add UED Sync service to CLAUDE.md

Adds hot reload rules, testing commands, repo structure entry,
and environment variables for the UED Sync API service."
```

---

### Task 7: Update UED Sync README for monorepo context

**Files:**
- Modify: `src/ued-sync/README.md`

**Step 1: Add monorepo notice at the top**

Prepend to the existing README (before the first heading):

```markdown
> **Note:** This service was consolidated from the standalone `azb-ldap-integration` repository into this monorepo. The original repo is archived at [github.com/KeithMoc/azb-ldap-integration](https://github.com/KeithMoc/azb-ldap-integration).
>
> **In the monorepo:** Start with `just up` from the repo root. UED Sync runs as an internal service at `http://ued-sync:8000` on the Docker network. See `Justfile` for `ued-*` recipes.

```

**Step 2: Commit**

```bash
git add src/ued-sync/README.md
git commit -m "docs: add monorepo context notice to UED Sync README"
```

---

### Task 8: Build and verify the full stack

**Files:** None (verification only)

**Step 1: Build and start all services**

```bash
just up-bg
```

Expected: 7 containers start (postgres, redis, openldap, directory-api, directory-ui, ued-sync, traefik) + seed (exits after run).

**Step 2: Check all containers are running**

```bash
just ps
```

Expected: all 7 services show as running/healthy. `azblink-ued-sync` should be present.

**Step 3: Verify UED Sync health from inside the network**

```bash
cd deploy/dev && docker compose exec directory-api python -c "import urllib.request; print(urllib.request.urlopen('http://ued-sync:8000/health').read().decode())"
```

Expected: JSON response with health status (may show LDAP as unconfigured — that's correct, UED Sync has no default LDAP).

**Step 4: Verify UED Sync logs**

```bash
just ued-logs &
sleep 3
kill %1
```

Expected: uvicorn startup logs showing the UED Sync API is running on port 8000.

**Step 5: Run UED Sync tests inside container**

```bash
just ued-test
```

Expected: unit + API tests pass. Integration tests are skipped (marked `not integration`).

**Step 6: Run main backend tests**

```bash
just test-quick
```

Expected: existing tests still pass — no regression from adding the new service.

**Step 7: Run combined test suite**

```bash
just test-all
```

Expected: both `test` and `ued-test` pass sequentially.

---

### Task 9: Final commit and summary

**Step 1: Verify clean git status**

```bash
git status
```

Expected: clean working tree (all changes committed in tasks 1-7).

**Step 2: Review commit log**

```bash
git log --oneline -10
```

Expected: 7 commits from this implementation + 1 design doc commit.

**Step 3: Archive the old repo**

This is a manual GitHub step:
1. Go to https://github.com/KeithMoc/azb-ldap-integration/settings
2. Scroll to "Danger Zone"
3. Click "Archive this repository"
4. Confirm

---

## Summary of all commits

| # | Message | Files |
|---|---------|-------|
| 1 | `feat: copy UED Sync API source into src/ued-sync/` | `src/ued-sync/**` |
| 2 | `feat: add Dockerfile for UED Sync API dev container` | `deploy/dev/Dockerfile.ued-sync` |
| 3 | `feat: add ued-sync service to dev docker-compose stack` | `deploy/dev/docker-compose.yml` |
| 4 | `docs: expand UED Sync env vars in .env.example` | `deploy/dev/.env.example` |
| 5 | `feat: add ued-* recipes and test-all to Justfile` | `Justfile` |
| 6 | `docs: add UED Sync service to CLAUDE.md` | `CLAUDE.md` |
| 7 | `docs: add monorepo context notice to UED Sync README` | `src/ued-sync/README.md` |
| 8 | (verification only — no commit) | — |
| 9 | (archive old repo — manual GitHub step) | — |
