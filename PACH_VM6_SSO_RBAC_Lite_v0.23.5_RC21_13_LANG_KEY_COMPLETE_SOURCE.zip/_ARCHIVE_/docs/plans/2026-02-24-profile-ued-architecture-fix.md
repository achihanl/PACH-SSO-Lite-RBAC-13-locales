# Profile-UED Architecture Fix Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Make UED the single source of truth for service capabilities (XMPP/SIP), drop the redundant `xmpp_config`/`sip_config` JSON columns from profiles, cache full discovery data including service endpoints, and fix QR assembly and lifecycle sync to resolve `profile_id` from org DN.

**Architecture:** Currently, profiles store independent `xmpp_config` and `sip_config` JSON blobs that duplicate what UED already knows via its schema. The fix is: (1) UED Sync exposes `service_endpoints` in discovery, (2) AD Directory caches `discovered_capabilities` and `discovered_service_endpoints` from discovery, (3) QR assembly reads endpoints from cached discovery data via `org_dn -> assignment -> template` resolution, (4) `xmpp_config`/`sip_config` columns are dropped, (5) lifecycle sync resolves `profile_id` from user's org DN via template assignments.

**Tech Stack:** Python/FastAPI (backend + UED Sync), PostgreSQL (ALTER TABLE, TEXT[], JSONB), React 19/TypeScript (frontend), TanStack Query, pydantic-settings v2

**Domains:** backend, ued-sync, frontend, database

---

### Task 1: Add ServiceEndpoints to UED Sync Discovery Response
**domain:** ued-sync
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [python, fastapi, pydantic-settings, pytest]

**Files:**
- Modify: `src/ued-sync/src/ued_sync/config.py`
- Modify: `src/ued-sync/src/ued_sync/sync_models.py`
- Modify: `src/ued-sync/src/ued_sync/routers/discovery.py`
- Modify: `deploy/dev/docker-compose.yml`
- Modify: `deploy/dev/.env.example`
- Modify: `src/ued-sync/tests/` (relevant discovery test files)

**Steps:**

1. **Add `ServiceEndpoints` model to `sync_models.py`** (insert after `SchemaInfo` class, before `DiscoveryResponse`):
   ```python
   class ServiceEndpoints(BaseModel):
       """Service connection endpoints reported via discovery."""
       xmpp_domain: str = ""
       xmpp_ws_url: str = ""
       sip_domain: str = ""
       sip_wss_url: str = ""
   ```

2. **Add `service_endpoints` field to `DiscoveryResponse`** in `sync_models.py`:
   ```python
   service_endpoints: ServiceEndpoints = Field(default_factory=ServiceEndpoints)
   ```
   Place it after the `features` field, before `model_config`.

3. **Add service endpoint env vars to `Settings` in `config.py`** (add after the `sip_auth_realm` field at the end of the class):
   ```python
   # Service endpoints (reported via discovery, consumed by AD Directory for QR assembly)
   xmpp_domain: str = Field(default="", description="XMPP domain (e.g., xmpp.example.com)")
   xmpp_ws_url: str = Field(default="", description="XMPP WebSocket URL (e.g., wss://xmpp.example.com/ws)")
   sip_domain: str = Field(default="", description="SIP domain (e.g., sip.example.com)")
   sip_wss_url: str = Field(default="", description="SIP WSS URL (e.g., wss://sip.example.com/ws)")
   ```

4. **Build and include `ServiceEndpoints` in discovery response** in `routers/discovery.py`:
   - Add `ServiceEndpoints` to the imports from `sync_models`
   - In `get_discovery()`, construct the endpoints object and pass it:
     ```python
     from ued_sync.sync_models import ServiceEndpoints  # add to existing import

     # In get_discovery(), before building DiscoveryResponse:
     endpoints = ServiceEndpoints(
         xmpp_domain=settings.xmpp_domain,
         xmpp_ws_url=settings.xmpp_ws_url,
         sip_domain=settings.sip_domain,
         sip_wss_url=settings.sip_wss_url,
     )

     # Add to DiscoveryResponse constructor:
     response = DiscoveryResponse(
         ...existing fields...,
         service_endpoints=endpoints,
     )
     ```

5. **Add env vars to `docker-compose.yml`** under the `ued-sync` service environment section (after `SCHEMA_NAME` line ~199):
   ```yaml
   - XMPP_DOMAIN=${UED_XMPP_DOMAIN:-xmpp.azblink.com}
   - XMPP_WS_URL=${UED_XMPP_WS_URL:-wss://xmpp.azblink.com/ws}
   - SIP_DOMAIN=${UED_SIP_DOMAIN:-sip.azblink.com}
   - SIP_WSS_URL=${UED_SIP_WSS_URL:-wss://sip.azblink.com/ws}
   ```

6. **Add env vars to `.env.example`** under the UED section (after `UED_SCHEMA_NAME`):
   ```
   # UED service endpoints (used by AD Directory for QR assembly)
   UED_XMPP_DOMAIN=xmpp.example.com
   UED_XMPP_WS_URL=wss://xmpp.example.com/ws
   UED_SIP_DOMAIN=sip.example.com
   UED_SIP_WSS_URL=wss://sip.example.com/ws
   ```

7. **Update existing discovery tests** to verify `service_endpoints` appears in discovery response. Find the test that calls `GET /api/v1/discovery` and assert:
   ```python
   assert "service_endpoints" in data
   assert data["service_endpoints"]["xmpp_domain"] == ""  # default empty
   ```

8. **Verify:** Run `just ued-test` -- all existing tests pass, new assertions pass.

---

### Task 2: Cache Discovery Data in Database (Migration 015)
**domain:** database
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [sql, postgresql]

**Files:**
- Create: `migrations/015_ued_service_endpoints.sql`

**Steps:**

1. **Write migration file** `migrations/015_ued_service_endpoints.sql`:
   ```sql
   -- migrations/015_ued_service_endpoints.sql
   -- Add discovered_capabilities and discovered_service_endpoints columns.
   -- Drop xmpp_config and sip_config (UED is now single source of truth).
   BEGIN;

   -- 1. Add new discovery cache columns
   ALTER TABLE config_templates
       ADD COLUMN IF NOT EXISTS discovered_capabilities TEXT[] DEFAULT '{}',
       ADD COLUMN IF NOT EXISTS discovered_service_endpoints JSONB DEFAULT '{}';

   -- 2. Backfill capabilities from discovered_schema_name for existing rows
   -- pjsip-combined -> {posix,sip,xmpp}
   UPDATE config_templates
   SET discovered_capabilities = ARRAY['posix','sip','xmpp']
   WHERE discovered_schema_name = 'pjsip-combined'
     AND (discovered_capabilities IS NULL OR discovered_capabilities = '{}');

   -- sip-legacy -> {posix,sip}
   UPDATE config_templates
   SET discovered_capabilities = ARRAY['posix','sip']
   WHERE discovered_schema_name = 'sip-legacy'
     AND (discovered_capabilities IS NULL OR discovered_capabilities = '{}');

   -- xmpp-only -> {posix,xmpp}
   UPDATE config_templates
   SET discovered_capabilities = ARRAY['posix','xmpp']
   WHERE discovered_schema_name = 'xmpp-only'
     AND (discovered_capabilities IS NULL OR discovered_capabilities = '{}');

   -- 3. Drop xmpp_config and sip_config columns (UED is source of truth)
   ALTER TABLE config_templates
       DROP COLUMN IF EXISTS xmpp_config,
       DROP COLUMN IF EXISTS sip_config;

   COMMIT;
   ```

2. **Verify syntax:** The SQL is valid PostgreSQL. TEXT[] and JSONB are native types. `IF NOT EXISTS` / `IF EXISTS` ensure idempotency.

---

### Task 3: Update Backend OrgDB Schema + Discovery Cache Logic
**domain:** backend
**depends_on:** [1, 2]
**parallel_group:** 2
**capabilities_needed:** [python, sqlalchemy, fastapi]

**Files:**
- Modify: `src/backend/orgdb.py`
- Modify: `src/backend/ued_discovery.py`
- Modify: `src/backend/main.py`

**Steps:**

1. **Update `config_templates` table definition in `orgdb.py`** -- Remove the `xmpp_config` and `sip_config` Column definitions (lines 206-207) and add new columns in their place:
   ```python
   # REMOVE these two lines:
   # Column("xmpp_config", JSON, nullable=False, server_default='{"enabled":false}'),
   # Column("sip_config", JSON, nullable=False, server_default='{"enabled":false}'),

   # ADD these two lines (after sso_config or before qr_settings):
   Column("discovered_capabilities", ARRAY(String), nullable=False, server_default="{}"),
   Column("discovered_service_endpoints", JSON, nullable=False, server_default="{}"),
   ```
   Add the `ARRAY` import from `sqlalchemy.dialects.postgresql` at the top of `orgdb.py`:
   ```python
   from sqlalchemy.dialects.postgresql import ARRAY
   ```

2. **Add `resolve_template_for_org` method to `OrgDB`** (add after `list_template_assignments` method):
   ```python
   def resolve_template_for_org(self, org_dn: str) -> dict[str, Any] | None:
       """Resolve the config template assigned to a given org DN.

       Returns the full template row dict or None if no assignment.
       Uses a JOIN: config_template_assignments -> config_templates.
       """
       eng = self.connect()
       stmt = (
           select(config_templates)
           .join(
               config_template_assignments,
               config_template_assignments.c.template_id == config_templates.c.id,
           )
           .where(config_template_assignments.c.org_dn == org_dn)
       )
       with eng.begin() as conn:
           row = conn.execute(stmt).mappings().first()
       return dict(row) if row else None
   ```

3. **Update `DiscoveryResult` in `ued_discovery.py`** -- Add new fields for capabilities and service endpoints:
   ```python
   # Add to DiscoveryResult dataclass (after schema_required_fields):
   capabilities: list[str] = field(default_factory=list)
   service_endpoints: dict[str, str] = field(default_factory=dict)
   ```

4. **Update `discover()` function in `ued_discovery.py`** -- Parse the new fields from the response:
   ```python
   # In the success return block, add:
   capabilities=schema.get("capabilities", []),
   service_endpoints=data.get("service_endpoints", {}),
   ```

5. **Update `api_config_template_discover` in `main.py`** -- Cache capabilities and service_endpoints alongside schema_name:
   ```python
   # In the resp.status_code == 200 block, after extracting schema_name:
   capabilities = resp.json().get("schema", {}).get("capabilities", [])
   service_endpoints = resp.json().get("service_endpoints", {})
   if schema_name:
       actor = extract_actor(claims)
       ORGDB.update_config_template(template_id, {
           "discovered_schema_name": schema_name,
           "discovered_capabilities": capabilities,
           "discovered_service_endpoints": service_endpoints,
           "discovered_at": datetime.now(timezone.utc),
       }, actor)
   ```

6. **Remove `XmppConfigUpdate` and `SipConfigUpdate` classes from `main.py`** and remove the `xmpp` and `sip` fields from `ConfigTemplateCreate` and `ConfigTemplateUpdate`. Specifically:
   - Delete the `XmppConfigUpdate` class (lines ~2595-2601)
   - Delete the `SipConfigUpdate` class (lines ~2603-2609)
   - Remove `xmpp: Optional[XmppConfigUpdate] = None` and `sip: Optional[SipConfigUpdate] = None` from `ConfigTemplateCreate`
   - Remove `xmpp: Optional[XmppConfigUpdate] = None` and `sip: Optional[SipConfigUpdate] = None` from `ConfigTemplateUpdate`

7. **Update `_format_template_list_item` in `main.py`**:
   - Replace `xmppEnabled` / `sipEnabled` derivation (which currently reads from `xmpp_config`/`sip_config` JSON) with derivation from `discovered_capabilities`:
     ```python
     caps = row.get("discovered_capabilities") or []
     # ... in the return dict:
     "xmppEnabled": "xmpp" in caps,
     "sipEnabled": "sip" in caps,
     ```
   - Remove the `xmpp = row.get("xmpp_config")...` and `sip = row.get("sip_config")...` lines (keep `sso` parsing).

8. **Update `_format_template_detail` in `main.py`**:
   - Remove the `xmpp = row.get("xmpp_config")...` and `sip = row.get("sip_config")...` parsing.
   - Remove `"xmpp": xmpp` and `"sip": sip` from the return dict.
   - Add these new fields to the return dict:
     ```python
     "discoveredCapabilities": row.get("discovered_capabilities") or [],
     "discoveredServiceEndpoints": row.get("discovered_service_endpoints") or {},
     ```

9. **Update `api_create_config_template` in `main.py`** -- Remove the blocks that handle `req.xmpp` and `req.sip`:
   ```python
   # REMOVE:
   # if req.xmpp:
   #     data["xmpp_config"] = req.xmpp.model_dump(by_alias=True)
   # if req.sip:
   #     data["sip_config"] = req.sip.model_dump(by_alias=True)
   ```

10. **Update `api_update_config_template` in `main.py`** -- Remove the blocks that handle `req.xmpp` and `req.sip`:
    ```python
    # REMOVE:
    # if req.xmpp is not None:
    #     updates["xmpp_config"] = req.xmpp.model_dump(by_alias=True)
    # if req.sip is not None:
    #     updates["sip_config"] = req.sip.model_dump(by_alias=True)
    ```

11. **Update `toggle_config_template_section` in `orgdb.py`** -- The toggle endpoint currently handles "xmpp"/"sip"/"sso" sections. Remove the xmpp/sip handling (only "sso" remains toggleable). Check the `toggle_config_template_section` method and the `ConfigTemplateSectionToggle` model -- update the `section` pattern validation in `ConfigTemplateSectionToggle` from `^(xmpp|sip|sso)$` to `^(sso)$`, or keep it and just make xmpp/sip a no-op since the columns are gone. Simpler approach: **keep the validator as-is** but have the method ignore xmpp/sip since those columns no longer exist. The method in orgdb.py reads the existing JSON, flips `enabled`, and writes back. Since xmpp_config/sip_config no longer exist, update the method to only handle sso_config.

12. **Verify:** Hot reload picks up Python changes. Run `just test-quick` to confirm no crashes. Expect some tests that reference xmpp_config/sip_config to need updating in Task 8.

---

### Task 4: Update Frontend Types and Form (Remove XMPP/SIP Config)
**domain:** frontend
**depends_on:** [3]
**parallel_group:** 3
**capabilities_needed:** [typescript, react]

**Files:**
- Modify: `src/frontend/src/types/org-profiles.ts`
- Modify: `src/frontend/src/components/features/org-profiles/ConfigTab.tsx`
- Modify: `src/frontend/src/components/features/org-profiles/ProfileCard.tsx`
- Modify: `src/frontend/src/components/features/org-profiles/modals/ProfileFormModal.tsx`
- Modify: `src/frontend/src/components/features/org-profiles/profile-type-config.ts`

**Steps:**

1. **Update `org-profiles.ts` types:**
   - Remove the `XmppConfig` interface entirely
   - Remove the `SipConfig` interface entirely
   - Update `FeatureKey` type: change from `'xmpp' | 'sip' | 'sso'` to `'sso'` (xmpp/sip are now derived from UED capabilities, not toggleable sections)
   - Update `ProfileListItem`: remove `xmppEnabled` and `sipEnabled`, add:
     ```typescript
     /** Capabilities discovered from UED (e.g. ['posix','sip','xmpp']) */
     discoveredCapabilities: string[];
     ```
   - Update `ProfileDetail`:
     - Remove `xmpp: XmppConfig` and `sip: SipConfig`
     - Add:
       ```typescript
       /** Capabilities discovered from UED (e.g. ['posix','sip','xmpp']) */
       discoveredCapabilities: string[];
       /** Service endpoints discovered from UED */
       discoveredServiceEndpoints: {
         xmpp_domain?: string;
         xmpp_ws_url?: string;
         sip_domain?: string;
         sip_wss_url?: string;
       };
       ```
   - Update `ProfileFormData`:
     - Remove `xmpp: XmppConfig` and `sip: SipConfig`
   - Update `EMPTY_PROFILE_FORM`:
     - Remove the `xmpp: { ... }` and `sip: { ... }` blocks
   - Update `profileToFormData`:
     - Remove `xmpp: { ...p.xmpp }` and `sip: { ...p.sip }`
   - Update `formDataToPayload`:
     - Remove `xmpp: { ...form.xmpp }` and `sip: { ...form.sip }`
   - Update `CreateProfilePayload`:
     - Remove `xmpp?` and `sip?` fields
   - Update `UpdateProfilePayload`:
     - Remove `xmpp?` and `sip?` fields

2. **Update `ProfileCard.tsx`** -- Replace the hardcoded xmpp/sip feature flags with capability-derived flags:
   ```typescript
   // Replace the featureFlags array:
   const caps = profile.discoveredCapabilities ?? [];
   const featureFlags: { key: string; label: string; enabled: boolean }[] = [
     { key: 'xmpp', label: 'XMPP', enabled: caps.includes('xmpp') },
     { key: 'sip', label: 'SIP', enabled: caps.includes('sip') },
     { key: 'sso', label: 'SSO', enabled: profile.ssoEnabled },
   ];
   ```
   Update the rendering loop to use the `label` from each flag object instead of looking up `sectionConfig[key]` for xmpp/sip (since those may no longer be valid section keys). Alternatively, keep `sectionConfig` entries for xmpp/sip for display purposes only (icon + color), just source the enabled state from capabilities.

3. **Update `ConfigTab.tsx`** -- Remove the XMPP and SIP `ConfigSection` blocks (the first two sections). Replace with a read-only "Discovered Capabilities" section that shows data from `profile.discoveredCapabilities` and `profile.discoveredServiceEndpoints`:
   ```tsx
   {/* Capabilities (from UED Discovery) */}
   {profile.discoveredCapabilities?.length > 0 && (
     <ConfigSection
       title="Service Capabilities"
       sectionKey="capabilities"
       icon={sectionConfig.ued.icon}
       iconColor={sectionConfig.ued.color}
       iconBg={sectionConfig.ued.bg}
       enabled
       showToggle={false}
     >
       <ConfigRow label="Capabilities" value={profile.discoveredCapabilities.join(', ')} />
       {profile.discoveredServiceEndpoints?.xmpp_domain && (
         <ConfigRow label="XMPP Domain" value={profile.discoveredServiceEndpoints.xmpp_domain} />
       )}
       {profile.discoveredServiceEndpoints?.xmpp_ws_url && (
         <ConfigRow label="XMPP WebSocket" value={profile.discoveredServiceEndpoints.xmpp_ws_url} />
       )}
       {profile.discoveredServiceEndpoints?.sip_domain && (
         <ConfigRow label="SIP Domain" value={profile.discoveredServiceEndpoints.sip_domain} />
       )}
       {profile.discoveredServiceEndpoints?.sip_wss_url && (
         <ConfigRow label="SIP WSS URL" value={profile.discoveredServiceEndpoints.sip_wss_url} />
       )}
     </ConfigSection>
   )}
   ```
   Keep SSO, QR Settings, and UED Provisioning sections as-is.

4. **Update `ProfileFormModal.tsx`** -- Remove the XMPP and SIP collapsible form sections entirely (the `MessageSquare`/XMPP section and `Phone`/SIP section). These are no longer user-editable; they come from UED discovery. Remove related imports (`MessageSquare`, `Phone`). Remove the `TRANSPORT_OPTIONS` const. Update `SectionKey` type to remove `'xmpp' | 'sip'`. Remove calls to `updateField('xmpp', ...)` and `updateField('sip', ...)`.

5. **Update `profile-type-config.ts`** if needed -- Keep the `xmpp` and `sip` entries in `sectionConfig` for backwards-compatible display in ProfileCard (icon + color), but these are now read-only display decorations, not toggleable sections.

6. **Verify:** Run `npx tsc --noEmit` from `src/frontend/` to confirm no type errors. The Vite HMR will pick up changes automatically.

---

### Task 5: Add `resolve_template_for_org` Helper and Fix QR Assembly
**domain:** backend
**depends_on:** [3]
**parallel_group:** 3
**capabilities_needed:** [python, fastapi]

**Files:**
- Modify: `src/backend/main.py`

**Steps:**

1. **Add `_resolve_service_endpoints(org_dn)` helper** in `main.py` (add near the other helper functions, around line 100-150):
   ```python
   def _resolve_service_endpoints(org_dn: str) -> dict[str, str]:
       """Resolve XMPP/SIP service endpoints for an org via template assignment.

       Returns dict with keys: xmpp_domain, xmpp_ws_url, sip_domain, sip_wss_url.
       Falls back to UCCHAT_* env vars if no template is assigned or template
       has no discovered endpoints.
       """
       template = ORGDB.resolve_template_for_org(org_dn)
       if template:
           eps = template.get("discovered_service_endpoints") or {}
           if eps.get("xmpp_domain") or eps.get("sip_domain"):
               return {
                   "xmpp_domain": eps.get("xmpp_domain", ""),
                   "xmpp_ws_url": eps.get("xmpp_ws_url", ""),
                   "sip_domain": eps.get("sip_domain", ""),
                   "sip_wss_url": eps.get("sip_wss_url", ""),
               }
       # Fallback to env vars (backwards compatibility)
       return {
           "xmpp_domain": UCCHAT_XMPP_DOMAIN,
           "xmpp_ws_url": UCCHAT_XMPP_WS_URL,
           "sip_domain": UCCHAT_SIP_DOMAIN,
           "sip_wss_url": UCCHAT_SIP_WSS_URL,
       }
   ```

2. **Update `api_user_qrcode`** (the unified QR endpoint) -- Replace hardcoded `UCCHAT_*` env vars with resolved endpoints:
   ```python
   # After org_dn is determined:
   eps = _resolve_service_endpoints(org_dn)

   # Update uc_payload to use eps:
   uc_payload = {
       "tenant": LDAP_TENANT,
       "xmpp": {
           "domain": eps["xmpp_domain"],
           "wsUrl": eps["xmpp_ws_url"],
       },
       "sip": {
           "domain": eps["sip_domain"],
           "wssUrl": eps["sip_wss_url"],
       },
       "credentials": {
           "username": uid,
           "token": provision_token,
       },
   }
   ```

3. **Update `api_user_qrcodes`** (the dual QR endpoint) -- Same pattern, replace `UCCHAT_*` with resolved endpoints:
   ```python
   # After org_dn is determined:
   eps = _resolve_service_endpoints(org_dn)

   # In qr1_payload:
   "xmpp": {
       "domain": eps["xmpp_domain"],
       "ws_url": eps["xmpp_ws_url"],
   },
   "sip": {
       "domain": eps["sip_domain"],
       "wss_url": eps["sip_wss_url"],
   },
   ```

4. **Update `api_tenant_info`** -- This endpoint (around line 810-816) also exposes `xmppDomain`/`sipDomain` etc. Keep it using env var fallbacks since it's a global tenant endpoint, not org-specific. No change needed here.

5. **Verify:** Hot reload. Manually confirm `GET /api/users/{uid}/qrcode` still works. The fallback to env vars means zero behavior change for existing deployments without template assignments.

---

### Task 6: Fix Lifecycle Sync Profile Resolution
**domain:** backend
**depends_on:** [3]
**parallel_group:** 3
**capabilities_needed:** [python, fastapi]

**Files:**
- Modify: `src/backend/main.py`

**Steps:**

1. **Add `_resolve_profile_id_for_user(user)` helper** in `main.py` (near `_resolve_service_endpoints`):
   ```python
   def _resolve_profile_id_for_user(user: dict) -> str | None:
       """Resolve the config template ID for a user based on their org DN.

       Uses the user's orgDn (or inferred from DN) to find the assigned template.
       Returns the template ID or None if no assignment exists.
       """
       org_dn = user.get("orgDn")
       if not org_dn:
           # Infer from user DN
           dn = user.get("dn", "")
           if "," + OU_PEOPLE in dn:
               rel = dn.split("," + OU_PEOPLE)[0]
               parts = rel.split(",")
               ou_parts = [p for p in parts if p.lower().startswith("ou=")]
               org_dn = ",".join(ou_parts) + "," + OU_ORG if ou_parts else OU_ORG
           else:
               org_dn = OU_ORG
       template = ORGDB.resolve_template_for_org(org_dn)
       return template["id"] if template else None
   ```

2. **Fix `api_user_suspend`** -- Replace the `emit_sync_event(None, ...)` with resolved profile_id:
   ```python
   # Replace:  emit_sync_event(None, uid, "user_suspended", {...})
   # With:
   profile_id = _resolve_profile_id_for_user(user)
   emit_sync_event(profile_id, uid, "user_suspended", {
       "user": {"uid": uid, "dn": user.get("dn", "")},
   })
   ```
   Remove the `# TODO: resolve user's profile_id for suspend sync events` comment.

3. **Fix `api_user_unsuspend`** -- Same pattern:
   ```python
   profile_id = _resolve_profile_id_for_user(user)
   emit_sync_event(profile_id, uid, "user_unsuspended", {
       "user": {"uid": uid, "dn": user.get("dn", "")},
   })
   ```
   Remove the TODO comment.

4. **Fix `api_user_terminate`** -- Same pattern:
   ```python
   profile_id = _resolve_profile_id_for_user(user)
   emit_sync_event(profile_id, uid, "user_terminated", {
       "user": {"uid": uid, "dn": user_dn or ""},
   })
   ```
   Remove the TODO comment.

5. **Fix `api_user_reset_password`** -- Same pattern:
   ```python
   profile_id = _resolve_profile_id_for_user(user)
   emit_sync_event(profile_id, uid, "password_changed", {
       "user": {"uid": uid, "dn": user.get("dn", "")},
       "new_password": req.newPassword,
   })
   ```
   Remove the TODO comment.

6. **Verify:** Hot reload. The change is backwards-compatible: if no template assignment exists, `_resolve_profile_id_for_user` returns `None`, and `emit_sync_event` no-ops (same as before). When an assignment exists, sync events are properly routed.

---

### Task 7: Run Migration and Rebuild Stack
**domain:** database
**depends_on:** [2, 3]
**parallel_group:** 4
**capabilities_needed:** [docker, postgresql]

**Files:**
- Modify: `CLAUDE.md` (add migration 015 to the list)

**Steps:**

1. **Run the migration** against the running dev stack:
   ```bash
   just psql < ../../migrations/015_ued_service_endpoints.sql
   ```
   Expected output: `BEGIN`, `ALTER TABLE`, `UPDATE N`, `ALTER TABLE`, `COMMIT`.

2. **Restart the stack** to pick up the schema changes in the ORM:
   ```bash
   just down && just up-bg
   ```
   Wait for services to be healthy: `just ps`.

3. **Update CLAUDE.md** -- Add migration 015 to the "Database Migrations" section:
   ```markdown
   # UED service endpoints + drop xmpp_config/sip_config
   just psql < ../../migrations/015_ued_service_endpoints.sql
   ```

4. **Verify:** Connect to the database and confirm the columns:
   ```bash
   just psql -c "\d config_templates"
   ```
   Should show: `discovered_capabilities` (text[]), `discovered_service_endpoints` (jsonb), and NO `xmpp_config`/`sip_config` columns.

---

### Task 8: Update Backend Tests
**domain:** backend
**depends_on:** [3, 5, 6, 7]
**parallel_group:** 5
**capabilities_needed:** [python, pytest]

**Files:**
- Modify: `tests/` (relevant test files that reference xmpp_config/sip_config)

**Steps:**

1. **Search for test references to `xmpp_config`, `sip_config`, `xmppEnabled`, `sipEnabled`, `XmppConfigUpdate`, `SipConfigUpdate`:**
   ```bash
   grep -rn "xmpp_config\|sip_config\|xmppEnabled\|sipEnabled\|XmppConfigUpdate\|SipConfigUpdate" tests/
   ```

2. **Update each reference:**
   - If a test creates a profile with `xmpp` or `sip` payload fields, remove those fields.
   - If a test asserts `xmppEnabled` or `sipEnabled` in list responses, replace with assertions on `discoveredCapabilities`.
   - If a test asserts `xmpp` or `sip` in detail responses, replace with assertions on `discoveredCapabilities` and `discoveredServiceEndpoints`.

3. **Add a test for `resolve_template_for_org`** -- Create a profile, assign it to an org DN, then verify the resolution:
   ```python
   def test_resolve_template_for_org(client, admin_headers):
       # Create a profile
       res = client.post("/api/config-templates", json={"name": "Test Resolve"}, headers=admin_headers)
       assert res.status_code == 201
       template_id = res.json()["template"]["id"]

       # Assign to an org
       res = client.post(f"/api/config-templates/{template_id}/assign",
                         json={"org_dn": "ou=TestOrg,ou=orgs,dc=azblink,dc=com"},
                         headers=admin_headers)
       assert res.status_code == 200

       # Verify QR endpoint works (uses resolve internally)
       # This is an integration-level verification
   ```

4. **Run full test suite:**
   ```bash
   just test
   ```
   All tests must pass.

---

### Task 9: Update UED Sync Tests
**domain:** ued-sync
**depends_on:** [1]
**parallel_group:** 5
**capabilities_needed:** [python, pytest]

**Files:**
- Modify: `src/ued-sync/tests/` (discovery-related test files)

**Steps:**

1. **Find discovery tests:**
   ```bash
   grep -rn "discovery\|service_endpoints" src/ued-sync/tests/
   ```

2. **Update discovery tests** to assert the new `service_endpoints` field:
   ```python
   def test_discovery_includes_service_endpoints(test_client, api_headers):
       resp = test_client.get("/api/v1/discovery", headers=api_headers)
       assert resp.status_code == 200
       data = resp.json()
       assert "service_endpoints" in data
       se = data["service_endpoints"]
       assert "xmpp_domain" in se
       assert "xmpp_ws_url" in se
       assert "sip_domain" in se
       assert "sip_wss_url" in se
   ```

3. **Add a test with configured endpoints** (set env vars via monkeypatch):
   ```python
   def test_discovery_service_endpoints_from_env(monkeypatch, test_client, api_headers):
       from ued_sync.config import settings
       monkeypatch.setattr(settings, "xmpp_domain", "xmpp.test.com")
       monkeypatch.setattr(settings, "sip_domain", "sip.test.com")
       resp = test_client.get("/api/v1/discovery", headers=api_headers)
       data = resp.json()
       assert data["service_endpoints"]["xmpp_domain"] == "xmpp.test.com"
       assert data["service_endpoints"]["sip_domain"] == "sip.test.com"
   ```

4. **Run UED tests:**
   ```bash
   just ued-test
   ```
   All tests must pass.

---

### Task 10: Frontend Type Check and End-to-End Verification
**domain:** frontend
**depends_on:** [4, 7]
**parallel_group:** 5
**capabilities_needed:** [typescript, vite]

**Files:**
- None new (verification only)

**Steps:**

1. **Run TypeScript type check:**
   ```bash
   cd src/frontend && npx tsc --noEmit
   ```
   Must produce zero errors.

2. **Run Vite build to catch any runtime import issues:**
   ```bash
   just ui-build
   ```
   Must succeed.

3. **Manual browser verification** (if stack is running):
   - Open `http://localhost:8081/` and navigate to Org Profiles
   - Verify profile cards show capability badges (XMPP/SIP/SSO) derived from discovery data
   - Create a new profile -- confirm no XMPP/SIP form sections
   - Click "Discover Schema" on a UED-configured profile -- confirm capabilities and service endpoints populate
   - View ConfigTab -- confirm "Service Capabilities" section renders with discovered data

4. **Verify QR codes still work:**
   - Navigate to a user, generate a QR code
   - Confirm the QR payload contains xmpp/sip fields (from env var fallback if no template assigned)

---

### Task 11: Update CLAUDE.md Documentation
**domain:** documentation
**depends_on:** [8, 9, 10]
**parallel_group:** 6
**capabilities_needed:** [markdown]

**Files:**
- Modify: `CLAUDE.md`

**Steps:**

1. **Update `docs/api/FRONTEND_API_CONTRACTS.md`** if it exists -- Remove xmpp_config/sip_config from ConfigTemplate schema, add discoveredCapabilities and discoveredServiceEndpoints fields.

2. **Update the "Implementation Status" section** -- Note that xmpp_config/sip_config have been removed in favor of UED-discovered capabilities.

2. **Update the "Profile-inline UED config" section** -- Add the two new fields:
   ```markdown
   - Discovery cache: `discovered_schema_name`, `discovered_capabilities`, `discovered_service_endpoints`, `discovered_at`
   ```
   Remove any references to `xmpp_config`/`sip_config` columns.

3. **Update the "Built-in Schema Templates" section** if it references xmpp_config/sip_config anywhere.

4. **Update the "UED Sync Integration" section** -- Note that service endpoints are now part of the discovery response and cached on profiles.

5. **Update the "Key Environment Variables" section** -- Add the new UED service endpoint env vars and note they are optional fallbacks for the AD Directory backend.

6. **Commit all changes** with a descriptive commit message covering the full scope of the architecture fix.

---

## Dependency Graph Summary

```
Task 1 (UED Sync: ServiceEndpoints) ──┐
                                       ├── Task 3 (Backend OrgDB + Discovery cache) ──┐
Task 2 (Migration 015) ───────────────┘                                               │
                                                                                       ├── Task 7 (Run migration) ──┐
Task 4 (Frontend types/UI) ◄── Task 3                                                 │                            │
Task 5 (QR assembly fix) ◄── Task 3                                                   │                            │
Task 6 (Lifecycle sync fix) ◄── Task 3                                                │                            │
                                                                                       │                            │
Task 8 (Backend tests) ◄── Tasks 3,5,6,7                                              │                            │
Task 9 (UED Sync tests) ◄── Task 1                                                    │                            │
Task 10 (Frontend verify) ◄── Tasks 4,7                                               │                            │
                                                                                       │                            │
Task 11 (Docs + commit) ◄── Tasks 8,9,10                                              │                            │
```

## Parallel Groups

| Group | Tasks | Can start when |
|-------|-------|----------------|
| 1 | Task 1, Task 2 | Immediately (independent) |
| 2 | Task 3 | After Group 1 |
| 3 | Task 4, Task 5, Task 6 | After Task 3 |
| 4 | Task 7 | After Tasks 2, 3 |
| 5 | Task 8, Task 9, Task 10 | After their respective deps |
| 6 | Task 11 | After Group 5 |

## Risk Mitigation

- **Env var fallback**: QR assembly falls back to `UCCHAT_*` env vars when no template assignment exists, ensuring zero breakage for existing deployments.
- **Idempotent migration**: All `ALTER TABLE` uses `IF NOT EXISTS`/`IF EXISTS` guards.
- **Capability backfill**: Migration 015 backfills `discovered_capabilities` from existing `discovered_schema_name` values.
- **Lifecycle sync**: `_resolve_profile_id_for_user` returns `None` when no assignment exists, preserving the existing no-op behavior of `emit_sync_event`.
