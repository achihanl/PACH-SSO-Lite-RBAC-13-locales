# Implementation Plan: Review Items 3-6 Fix

**Date:** 2026-02-12
**Scope:** 4 actionable fixes from the user-create bugs review session
**Items 1 & 2:** Verified clean — no action needed (auth.py search attributes, move_user_org recursive OU)

---

## Work Items Overview

| # | Item | Risk | Effort | Files Changed |
|---|------|------|--------|---------------|
| A | test_breakglass.py mock config fix | Pre-existing test failure | Small (1 file) | `tests/test_breakglass.py` |
| B | LDAP write safety guards | Empty-string → LDAP rejection | Small (2 files) | `src/backend/ldap_client.py`, `src/backend/main.py` |
| C | Onboarding wizard validation alignment | Same bugs as fixed AddUserModal | Small (2 files) | `validation.ts`, `StepUserInfo.tsx` |
| D | Vite build — QRCodeResponse investigation | Pre-existing build failure | Investigate-only | N/A (likely cache) |

---

## Item A: Fix test_breakglass.py Mock Config

### Problem
`tests/test_breakglass.py:74` — `from main import _load_breakglass` fails with `ImportError: cannot import name 'LDAP_BIND_DN' from 'config'`.

The mock config module (lines 41-69) is injected into `sys.modules["config"]` before importing `main`. But `main.py` imports `ldap_client.py`, which does `from config import LDAP_BIND_DN, LDAP_BIND_PW` (ldap_client.py:7-16). These two attributes are missing from the mock.

### Root Cause
The mock omits `LDAP_BIND_DN` and `LDAP_BIND_PW`. Additionally, `UCCHAT_WEBRTC_SIP_URL` and `UCCHAT_TURN_URL` are exported by config.py but not present in the mock — these may be needed by main.py's ucChat provisioning code.

### Fix
Add the missing attributes to the mock config block in `test_breakglass.py`, after line 64 (before `sys.modules["config"] = _config`):

```python
# LDAP service account (used by ldap_client.py)
_config.LDAP_BIND_DN = "cn=admin,dc=test,dc=com"
_config.LDAP_BIND_PW = "testpassword"
# ucChat additional config (used by main.py provisioning)
_config.UCCHAT_WEBRTC_SIP_URL = "wss://localhost"
_config.UCCHAT_TURN_URL = "turn:localhost:3478"
```

### Verification
```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack
python -m pytest tests/test_breakglass.py -v
```

If additional `ImportError`s surface (transitive imports from mocked modules), add those attributes iteratively until the import succeeds. The test logic itself is sound — only the mock is incomplete.

### Trade-offs
- **Option A (chosen):** Add missing attributes to the mock — surgical, minimal change
- **Option B:** Refactor to use `unittest.mock.patch.dict` — cleaner but larger change, not worth the risk for a pre-existing issue

---

## Item B: LDAP Write Safety Guards

### Problem
The LDAP write audit found 5 `conn.add()`/`conn.modify()` calls where empty strings could theoretically reach LDAP and cause attribute syntax violations. The API layer (Pydantic models in main.py) only guards `uid` and `password` with `min_length=1` — all other string fields accept empty strings.

### Defense-in-Depth Strategy
Apply guards at **two layers**:

**Layer 1 — API boundary (main.py Pydantic models):** Add `min_length=1` to required fields that must never be empty. This catches bad input at the HTTP boundary.

**Layer 2 — LDAP client functions (ldap_client.py):** Add `if not param: raise ValueError()` guards to critical parameters. This catches any internal callers (CSV import, CLI, future code paths) that bypass the API layer.

### Layer 1: Pydantic Model Changes (`src/backend/main.py`)

#### UserMoveOrgReq (line 472)
```python
# Before:
orgDn: str = Field(..., max_length=512)

# After:
orgDn: str = Field(..., min_length=1, max_length=512)
```

#### GroupCreateReq (line 441) — `orgDn` field only
The `cn` field already has `min_length=1`. Add it to `orgDn`:
```python
# Before:
orgDn: str = Field(default=OU_ORG, max_length=512)

# After:
orgDn: str = Field(default=OU_ORG, min_length=1, max_length=512)
```

#### UserCreateReq (line 456) — `orgDn` field only
`uid` and `password` already have `min_length=1`. Add it to `orgDn`:
```python
# Before:
orgDn: str = Field(default=OU_ORG, max_length=512)

# After:
orgDn: str = Field(default=OU_ORG, min_length=1, max_length=512)
```

**Note:** Optional fields like `mail`, `mobile`, `title`, `employeeNumber`, `manager` intentionally default to `""` — they are already guarded in ldap_client.py's `create_user()` with `if mail:` / `if mobile:` conditionals. Adding `min_length=1` to these would break the "omit if empty" pattern. No change needed for these.

### Layer 2: ldap_client.py Guards

Add early validation to 4 functions:

#### `create_group()` — guard `cn` (line ~276)
**Note:** Actual signature is `create_group(org_dn: str, cn: str, description: str = "")` — do NOT change parameter order.
```python
def create_group(org_dn: str, cn: str, description: str = "") -> Dict[str, Any]:
    if not cn or not cn.strip():
        raise ValueError("Group cn must not be empty")
    # ... existing code
```

#### `group_add_member()` — guard `member_dn` (line ~319)
```python
def group_add_member(group_dn: str, member_dn: str):
    if not member_dn:
        raise ValueError("member_dn must not be empty")
    # ... existing code
```

#### `group_remove_member()` — guard `member_dn` (line ~330)
```python
def group_remove_member(group_dn: str, member_dn: str):
    if not member_dn:
        raise ValueError("member_dn must not be empty")
    # ... existing code
```

#### `reset_user_password()` — guard `new_password` (line ~767)
```python
def reset_user_password(uid: str, new_password: str):
    if not new_password:
        raise ValueError("new_password must not be empty")
    # ... existing code
```

**Not adding guards to:**
- `ensure_ou()` — callers always pass computed DNs from config constants; the risk is theoretical
- `create_user()` `uid` — already guarded by Pydantic `min_length=1` at API boundary; adding ldap_client guard is optional but creates noise since `uid` is always set by all callers

### Verification
```bash
just test-quick  # Integration tests against Docker stack
```

### Trade-offs
- **Chosen:** Two-layer defense (Pydantic + ldap_client guards) — covers both API and internal callers
- **Alternative:** Only Pydantic guards — misses CSV import and CLI callers
- **Alternative:** Only ldap_client guards — misses the opportunity to return 422 Validation Error at the API layer (RuntimeError would become 500)

---

## Item C: Onboarding Wizard Validation Alignment

### Problem
The onboarding wizard (`StepUserInfo.tsx`, `validation.ts`, `StepQRCode.tsx`) was built before the AddUserModal Zod validation was added. It has:
1. **Empty string submission** — `mail`, `mobile`, `title` sent as `""` to API (StepQRCode.tsx:37-39)
2. **Weak password validation** — only 8-char min + match check, no complexity (validation.ts:20-22)
3. **No password generation** — manual-only entry, no auto-generate/copy/show-hide UX
4. **Weak email validation** — basic regex instead of Zod `.email()` (validation.ts:17)
5. **No per-field errors** — single step-level error banner

### Design Decision: Reuse vs. Rewrite

The onboarding wizard has a fundamentally different UX from AddUserModal:
- **Multi-step wizard** with a reducer-based state machine vs. **single modal form**
- Password is always manual in the wizard (no "auto" mode concept — you're creating a user face-to-face)
- Steps are validated independently before advancing

**Decision:** Reuse the Zod schema's **validation rules** from `user-create.ts`, but adapt them to the wizard's per-step validation architecture. Do NOT try to force the wizard to use `passwordMode: 'auto' | 'manual'` — it doesn't fit the wizard UX.

### Approach: Extract Shared Validation Constants

Create a lightweight export from `user-create.ts` that the wizard can import:

```typescript
// In user-create.ts — add these named exports for reuse
export const PASSWORD_MIN_LENGTH = 8;
export const PASSWORD_MAX_LENGTH = 128;
export const PASSWORD_RULES = {
  minLength: 8,
  maxLength: 128,
  requireUppercase: true,
  requireLowercase: true,
  requireDigit: true,
};
export const UID_PATTERN = /^[a-zA-Z0-9._-]+$/;
```

**Wait — this is overengineering.** The Zod schema is 70 lines and already defines everything. The wizard's validation.ts is 63 lines. The simplest approach is:

### Revised Approach: Inline the Same Rules

Update `validation.ts` to match the same validation rules that the Zod schema enforces, without importing the Zod schema. This keeps the wizard's per-step architecture intact and avoids coupling the wizard's reducer-based flow to the Zod schema's `passwordMode` concept.

### Changes

#### File 1: `src/frontend/src/components/features/user-management/onboarding/validation.ts`

Replace `validateStepUserInfo()` with stronger validation matching AddUserModal's Zod schema:

```typescript
/** Step 1: User info — uid, fullName, email, password required with complexity rules */
export function validateStepUserInfo(state: OnboardingState): string | null {
  if (!state.fullName.trim()) return 'Full name is required';
  if (!state.uid.trim()) return 'Username is required';
  // Match AddUserModal's UID pattern (allows uppercase too)
  if (!/^[a-zA-Z0-9._-]+$/.test(state.uid.trim())) {
    return 'Username may only contain letters, numbers, dots, hyphens, and underscores';
  }
  if (!state.email.trim()) return 'Email is required';
  // Use same validation approach as Zod .email() — reject obviously invalid
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(state.email.trim())) {
    return 'Please enter a valid email address';
  }
  // Password complexity matching AddUserModal's Zod superRefine
  if (!state.password) return 'Password is required';
  if (state.password.length < 8) return 'Password must be at least 8 characters';
  if (state.password.length > 128) return 'Password must be 128 characters or fewer';
  if (!/[A-Z]/.test(state.password)) return 'Password must contain at least one uppercase letter';
  if (!/[a-z]/.test(state.password)) return 'Password must contain at least one lowercase letter';
  if (!/[0-9]/.test(state.password)) return 'Password must contain at least one number';
  if (state.password !== state.confirmPassword) return 'Passwords do not match';
  return null;
}
```

Key changes:
- UID regex: `^[a-z0-9][a-z0-9.\-]*$` → `^[a-zA-Z0-9._-]+$` (match AddUserModal)
- Email regex: added `{2,}` TLD length check
- Password: added max length, uppercase, lowercase, digit checks (5 new lines)

#### ~~File 2: `StepQRCode.tsx` — REMOVED (reviewer feedback)~~

**Original proposal:** Add `|| undefined` to `mail`, `mobile`, `title` fields.

**Why removed:** The `CreateUserPayload` interface types these as `string` (not `string | undefined`), so `|| undefined` would break TypeScript. More importantly, the backend already handles empty strings correctly:
- Pydantic models accept `default=""` for these fields
- `ldap_client.py:create_user()` already has `if mail:` / `if mobile:` guards that skip empty strings

The current code (`state.email.trim()`, etc.) is correct — empty strings flow through the type system and are filtered at the LDAP layer. No change needed.

#### File 3: `src/frontend/src/components/features/user-management/onboarding/StepUserInfo.tsx`

Update the password hint text to reflect the new complexity requirements:

```typescript
// Line 182-184, change from:
<p className="text-xs text-[var(--color-text-muted)]">
  Minimum 8 characters
</p>

// To:
<p className="text-xs text-[var(--color-text-muted)]">
  8-128 characters, at least one uppercase, one lowercase, and one number
</p>
```

### What This Plan Does NOT Do (Conscious Trade-offs)

| Feature | Decision | Reason |
|---------|----------|--------|
| Password generation UI in wizard | **Skip** | Wizard is face-to-face onboarding — admin types the password they'll hand to the user. Auto-generate adds UX complexity to a multi-step flow that doesn't need it. Can be added later if requested. |
| Per-field error display | **Skip** | The wizard's single-error-banner UX is adequate for a guided flow. The step-level validation catches the first error and guides the user. Adding per-field errors requires significant reducer changes and is a UX-polish item, not a bug fix. |
| Success toast | **Skip** | The wizard shows a complete step with QR code display — the visual feedback is sufficient. |
| Import Zod schema in wizard | **Skip** | Coupling the wizard to `passwordMode: 'auto' | 'manual'` doesn't fit. The inline rules are identical and easier to maintain in a 63-line file. |

### Verification
```bash
cd src/frontend && npx tsc --noEmit
```
Manual verification: Navigate to the onboarding wizard, submit with:
- Weak password (no uppercase) → should show error
- Empty email → should show error
- Empty optional fields → backend handles empty strings safely (no frontend change needed)

---

## Item D: Vite Build — QRCodeResponse (Investigation Only)

### Problem
`import type { QRCodeResponse } from '@/types'` reportedly fails during Vite build, but `tsc --noEmit` passes.

### Finding
- `QRCodeResponse` IS defined in `src/frontend/src/types/qr.ts:45` and exported
- Re-exported via `types/index.ts:13` (`export * from './qr'`)
- 7 files import it correctly via `@/types`
- TypeScript compilation succeeds

### Action
1. Attempt a clean build after all other changes:
   ```bash
   cd src/frontend && rm -rf node_modules/.vite dist && npx vite build
   ```
2. If it fails, capture the exact error message and investigate further
3. If it succeeds, it was a stale cache issue — no code change needed

### Actual Finding (During Implementation)
The real build failure was NOT `QRCodeResponse` — it was `Stepper` not exported from the stale `@azblink/ui` dist.
Root cause: `vite.config.ts` conditionally applied the source alias only in `NODE_ENV === 'development'`.
In production builds, `@azblink/ui` resolved to `dist/index.js` which was stale (Stepper added after last dist build).

### Fix Applied
Changed `vite.config.ts` to apply the `@azblink/ui` source alias unconditionally (dev + production).
Vite handles TSX + CSS Modules natively — no pre-built dist needed for a workspace package.

### Result
`npx vite build` succeeds: 2316 modules transformed, all chunks generated.

---

## Execution Order

1. **Item A** (test_breakglass.py) — independent, fast, verifiable immediately
2. **Item B** (LDAP write guards) — independent, small, backend-only
3. **Item C** (onboarding wizard) — largest item, frontend-only
4. **Item D** (Vite build) — investigate after C is complete (since C touches frontend files)

Items A and B can be done in parallel. Item C depends on neither. Item D should be last.

---

## Files Modified (Summary)

| File | Changes |
|------|---------|
| `tests/test_breakglass.py` | Add 4 missing mock config attributes |
| `src/backend/main.py` | Add `min_length=1` to 3 Pydantic fields |
| `src/backend/ldap_client.py` | Add 4 `ValueError` guards |
| `src/frontend/src/components/features/user-management/onboarding/validation.ts` | Strengthen password + UID + email validation |
| `src/frontend/src/components/features/user-management/onboarding/StepUserInfo.tsx` | Update password hint text |

**Total: 5 files, all surgical edits, no new files created.**

---

## Review Feedback Log

**Reviewer:** feature-dev:code-reviewer (2026-02-12)

| Issue | Severity | Resolution |
|-------|----------|------------|
| `create_group()` signature wrong — plan showed `(cn, org_dn)`, actual is `(org_dn, cn, description)` | Critical | Fixed in Item B, Layer 2 section |
| `StepQRCode.tsx` `\|\| undefined` breaks TypeScript type contract (`CreateUserPayload.mail` is `string`, not `string \| undefined`) and is unnecessary since backend already guards empty strings | Critical | Removed from Item C — no StepQRCode.tsx changes |
| `orgDn` `min_length=1` is a minor API contract change (clients sending `orgDn: ""` would get 422 instead of using default) | Advisory | Accepted — no current clients send empty orgDn; documented as minor breaking change |
| Error message wording differs from AddUserModal's Zod messages | Advisory | Accepted as-is — wizard has its own UX voice; messages convey the same rules |
