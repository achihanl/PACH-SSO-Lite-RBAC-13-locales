# UED Sync PJSIP Schema Registry Design

**Date:** 2026-02-21
**Status:** Approved

## Problem

UED Sync is schema-agnostic — every caller must construct and send the full
`ProvisioningSchema` payload (6 objectClasses, 13+ Asterisk attributes, DN
template, required fields). This works architecturally but creates two problems:

- **DRY violation:** Every caller (backend, CLI, tests, Bruno e2e) duplicates
  the same complex PJSIP schema definition
- **No single source of truth:** Schema drift across callers is inevitable

The PJSIP combined schema was proven correct against both the dev OpenLDAP stack
and the real SIP LDAP at `192.168.122.89` (5/5 tests passing, including LDAP
bind auth). We need to ship this proven schema as a reusable built-in.

## Decisions

- **PJSIP only** — target `AsteriskPjsipEndpoint/Auth/Aor` (Asterisk 13+).
  Legacy `AsteriskSIPUser` (`chan_sip`, removed in Asterisk 21+) is not supported.
- **Schema registry approach** — UED Sync ships named schemas that callers
  reference by name; inline schema still works and always takes priority.
- **SIP auth realm** — configurable via `SIP_AUTH_REALM` env var (default:
  `"asterisk"`). Backend can override per-tenant.
- **XMPP untouched** — already proven working on 192.168.122.89.

## Architecture

### Schema Registry Module

```
src/ued_sync/schemas/
├── __init__.py        # get_schema(name) -> ProvisioningSchema
└── pjsip.py           # pjsip_combined_schema(realm) -> ProvisioningSchema
```

- `get_schema("pjsip-combined")` returns a `ProvisioningSchema` instance
- Unknown names raise `SchemaError`
- The PJSIP schema is parameterized by `SIP_AUTH_REALM` from settings

### Default PJSIP Combined Schema

Proven by integration tests (5/5 against dev stack + 5/5 against
`192.168.122.89`):

- **objectClasses:** `top`, `account`, `posixAccount`,
  `AsteriskPjsipEndpoint`, `AsteriskPjsipAuth`, `AsteriskPjsipAor`
- **DN template:** `uid={username},ou=People,{base_dn}`
- **Attribute map:**
  - POSIX: `uid`, `cn`, `uidNumber`, `gidNumber`, `homeDirectory`, `loginShell`
  - Endpoint: `AstEndpointContext` (from-internal), `AstEndpointAllow`
    (!all,ulaw,alaw,opus), `AstEndpointDisallow` (all),
    `AstEndpointTransport` (transport-udp), `AstEndpointAors` ({username}),
    `AstEndpointAuth` ({username})
  - Auth: `AstAuthType` (userpass), `AstAuthUsername` ({username}),
    `AstAuthPassword` ({sip_password}), `AstAuthRealm` ({sip_auth_realm})
  - AoR: `AstAorMaxContacts` (1), `AstAorRemoveExisting` (yes),
    `AstAorQualifyFrequency` (60)
- **Required fields:** `username`, `display_name`, `uid_number`, `sip_password`
- **Password:** `userPassword` with SSHA hash (enables LDAP bind auth)

### Request Model Changes

`SyncUserRequest` and `BatchSyncRequest` gain an optional `schema_name` field:

```python
schema_config: Optional[ProvisioningSchema] = Field(None, alias="schema")
schema_name: Optional[str] = Field(None)
```

Resolution priority:
1. `schema` (inline) — always wins if provided
2. `schema_name` — resolved from registry
3. Neither — validation error

Not changed: `SuspendRequest`, `PasswordRequest`, `AuthValidateRequest` (these
use `dict` and carry simpler configs).

### New Config

```python
# config.py
sip_auth_realm: str = Field(
    default="asterisk",
    description="SIP auth realm for PJSIP provisioning (AstAuthRealm)",
)
```

Env var: `SIP_AUTH_REALM` (default: `"asterisk"`).

## Scope

### In scope
- Schema registry module (`schemas/`)
- Default PJSIP combined schema
- `schema_name` field on `SyncUserRequest` and `BatchSyncRequest`
- `SIP_AUTH_REALM` env var
- Unit tests for registry + model validation
- Integration tests using `schema_name` (dev stack + 192.168.122.89)

### Not in scope
- Migrating legacy `AsteriskSIPUser` entries
- XMPP changes (proven working)
- Schema registry API endpoints (internal only)
- Schema persistence (schemas are code, not data)
- `SuspendRequest`/`PasswordRequest`/`AuthValidateRequest` changes

## Test Plan

- **Unit:** Registry returns correct schema, unknown name errors, model
  validation (schema vs schema_name vs neither)
- **Integration (dev stack):** Create/auth/update/delete SIP user using
  `schema_name: "pjsip-combined"` instead of inline schema
- **Integration (192.168.122.89):** Same tests with
  `SIP_AUTH_REALM=xmpp-sip-platform.local`
