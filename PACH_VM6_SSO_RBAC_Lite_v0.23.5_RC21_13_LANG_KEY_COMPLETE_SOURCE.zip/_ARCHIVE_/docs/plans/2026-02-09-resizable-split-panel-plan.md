# Resizable Split Panel Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add drag-to-resize split panels to User, Group, and Org management pages with localStorage persistence and VS Code-like behavior.

**Architecture:** A shared `useResizablePanel` hook handles drag state, clamping, window resize, and localStorage persistence. A thin `<ResizeHandle>` component renders the draggable separator with accessibility support. All three management pages swap their CSS Grid layout for flex + the hook.

**Tech Stack:** React 19, TypeScript, Tailwind CSS 4, Playwright (e2e tests)

**Design doc:** `docs/plans/2026-02-09-resizable-split-panel-design.md`

---

### Task 1: Create the `useResizablePanel` hook

**Files:**
- Create: `src/frontend/src/hooks/use-resizable-panel.ts`

> **Naming:** Existing hooks use `use-kebab-case.ts` (see `use-breadcrumb.ts`, `use-keyboard.ts`).

**Step 1: Create the hook file**

```ts
// src/frontend/src/hooks/use-resizable-panel.ts

/**
 * Drag-to-resize hook for split-panel layouts.
 * - Tracks left panel width in px
 * - Clamps to min-widths on drag + window resize
 * - Persists to localStorage per-page (on drag end, not during)
 * - Double-click resets to default
 * - requestAnimationFrame for smooth visual updates
 */
import { useCallback, useEffect, useRef, useState } from 'react';

export interface UseResizablePanelOptions {
  /** localStorage key, e.g. 'panel-width:user-management' */
  storageKey: string;
  /** Initial left panel width in px. 0 = auto-calculate (container - defaultRightWidth). */
  defaultLeftWidth: number;
  /** Minimum left panel width in px */
  minLeftWidth: number;
  /** Minimum right panel width in px */
  minRightWidth: number;
}

export interface UseResizablePanelReturn {
  /** Current left panel width in px (0 until container is measured) */
  leftWidth: number;
  /** Attach to the flex container wrapping both panels + handle */
  containerRef: React.RefObject<HTMLDivElement | null>;
  /** Pass to ResizeHandle onMouseDown */
  handleMouseDown: (e: React.MouseEvent) => void;
  /** Pass to ResizeHandle onDoubleClick — resets to default */
  handleDoubleClick: () => void;
  /** True while user is actively dragging */
  isDragging: boolean;
  /** Pass to ResizeHandle for keyboard nudge */
  nudge: (delta: number) => void;
}

const GAP_PX = 0; // handle itself provides visual separation

function readStoredWidth(key: string): number | null {
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) return null;
    const val = Number(raw);
    return Number.isFinite(val) && val > 0 ? val : null;
  } catch {
    return null;
  }
}

function writeStoredWidth(key: string, width: number): void {
  try {
    localStorage.setItem(key, String(Math.round(width)));
  } catch {
    // localStorage full or disabled — silent fail
  }
}

export function useResizablePanel({
  storageKey,
  defaultLeftWidth,
  minLeftWidth,
  minRightWidth,
}: UseResizablePanelOptions): UseResizablePanelReturn {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [leftWidth, setLeftWidth] = useState<number>(0);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartX = useRef(0);
  const dragStartWidth = useRef(0);
  const rafId = useRef(0);

  /** Clamp width to respect both min constraints given container size */
  const clamp = useCallback(
    (width: number): number => {
      const container = containerRef.current;
      if (!container) return width;
      const maxLeft = container.offsetWidth - minRightWidth - GAP_PX;
      return Math.max(minLeftWidth, Math.min(width, maxLeft));
    },
    [minLeftWidth, minRightWidth],
  );

  /** Compute default width (for initial load + double-click reset) */
  const computeDefault = useCallback((): number => {
    const container = containerRef.current;
    if (!container) return defaultLeftWidth || 300;
    if (defaultLeftWidth > 0) return clamp(defaultLeftWidth);
    // auto: give right panel its natural share, rest to left
    return clamp(container.offsetWidth - 400 - GAP_PX);
  }, [defaultLeftWidth, clamp]);

  // Initialize width: localStorage > default > fallback
  useEffect(() => {
    const stored = readStoredWidth(storageKey);
    if (stored !== null) {
      setLeftWidth(clamp(stored));
    } else {
      setLeftWidth(computeDefault());
    }
  }, [storageKey, clamp, computeDefault]);

  // Re-clamp on window resize
  useEffect(() => {
    const handleResize = () => {
      setLeftWidth((prev) => clamp(prev));
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [clamp]);

  // Drag handlers attached to document during drag
  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      cancelAnimationFrame(rafId.current);
      rafId.current = requestAnimationFrame(() => {
        const delta = e.clientX - dragStartX.current;
        const newWidth = clamp(dragStartWidth.current + delta);
        setLeftWidth(newWidth);
      });
    };

    const handleMouseUp = (e: MouseEvent) => {
      cancelAnimationFrame(rafId.current);
      const delta = e.clientX - dragStartX.current;
      const finalWidth = clamp(dragStartWidth.current + delta);
      setLeftWidth(finalWidth);
      writeStoredWidth(storageKey, finalWidth);
      setIsDragging(false);
    };

    // Prevent text selection during drag
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      cancelAnimationFrame(rafId.current);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, clamp, storageKey]);

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      dragStartX.current = e.clientX;
      dragStartWidth.current = leftWidth;
      setIsDragging(true);
    },
    [leftWidth],
  );

  const handleDoubleClick = useCallback(() => {
    const defaultWidth = computeDefault();
    setLeftWidth(defaultWidth);
    writeStoredWidth(storageKey, defaultWidth);
  }, [computeDefault, storageKey]);

  const nudge = useCallback(
    (delta: number) => {
      setLeftWidth((prev) => {
        const newWidth = clamp(prev + delta);
        writeStoredWidth(storageKey, newWidth);
        return newWidth;
      });
    },
    [clamp, storageKey],
  );

  return {
    leftWidth,
    containerRef,
    handleMouseDown,
    handleDoubleClick,
    isDragging,
    nudge,
  };
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend && npx tsc --noEmit --pretty 2>&1 | head -30`
Expected: No errors related to `use-resizable-panel.ts`

**Step 3: Commit**

```bash
git add src/frontend/src/hooks/use-resizable-panel.ts
git commit -m "feat(ui): add useResizablePanel hook for drag-to-resize split panels"
```

---

### Task 2: Create the `<ResizeHandle>` component

**Files:**
- Create: `src/frontend/src/components/layout/resize-handle.tsx`

> **Naming:** Existing layout components use `kebab-case.tsx` (see `sidebar.tsx`, `header.tsx`, `breadcrumb.tsx`).

**Step 1: Create the component file**

```tsx
// src/frontend/src/components/layout/resize-handle.tsx

/**
 * Draggable vertical separator for resizable split panels.
 * - 3px visible line (transparent → subtle on hover → primary while dragging)
 * - 12px invisible hit area for easy grabbing
 * - role="separator" with keyboard support (Arrow Left/Right nudge ±20px)
 * - Focus-visible ring for accessibility
 */
import { useCallback } from 'react';
import { cn } from '@azblink/ui';

const NUDGE_PX = 20;

interface ResizeHandleProps {
  /** Mouse down handler from useResizablePanel */
  onMouseDown: (e: React.MouseEvent) => void;
  /** Double-click handler from useResizablePanel (reset to default) */
  onDoubleClick: () => void;
  /** Whether the user is actively dragging */
  isDragging: boolean;
  /** Keyboard nudge callback from useResizablePanel */
  onNudge: (delta: number) => void;
  /** Additional className (e.g. 'hidden lg:flex' for responsive hiding) */
  className?: string;
}

export function ResizeHandle({
  onMouseDown,
  onDoubleClick,
  isDragging,
  onNudge,
  className,
}: ResizeHandleProps) {
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        onNudge(-NUDGE_PX);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        onNudge(NUDGE_PX);
      }
    },
    [onNudge],
  );

  return (
    <div
      role="separator"
      aria-orientation="vertical"
      aria-label="Resize panels"
      tabIndex={0}
      onMouseDown={onMouseDown}
      onDoubleClick={onDoubleClick}
      onKeyDown={handleKeyDown}
      className={cn(
        'group relative flex items-center justify-center w-0 shrink-0',
        'cursor-col-resize select-none outline-none',
        'focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] focus-visible:ring-offset-1',
        isDragging && 'z-10',
        className,
      )}
    >
      {/* Visible indicator line */}
      <div
        className={cn(
          'absolute w-[3px] h-full rounded-full transition-colors duration-150',
          isDragging
            ? 'bg-[var(--color-primary)]'
            : 'bg-transparent group-hover:bg-[var(--color-border-subtle)]',
        )}
      />
      {/* Invisible hit area for easier grabbing */}
      <div className="absolute w-3 h-full" />
    </div>
  );
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend && npx tsc --noEmit --pretty 2>&1 | head -30`
Expected: No errors related to `resize-handle.tsx`

**Step 3: Commit**

```bash
git add src/frontend/src/components/layout/resize-handle.tsx
git commit -m "feat(ui): add ResizeHandle component for split panel divider"
```

---

### Task 3: Integrate into UserManagementPage

**Files:**
- Modify: `src/frontend/src/components/features/user-management/UserManagementPage.tsx:8,129,142,152-153`

**Step 1: Add imports**

At `UserManagementPage.tsx:8` (after existing imports from react), add the hook import.
At the end of the import block (after line 22), add the ResizeHandle import.

Replace the import line:
```ts
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
```
No change needed to this line — already has everything.

Add after line 22 (`import type { User, TerminationResponse } from '@/types';`):
```ts
import { useResizablePanel } from '@/hooks/use-resizable-panel';
import { ResizeHandle } from '@/components/layout/resize-handle';
```

**Step 2: Add the hook call**

Inside `UserManagementPage` function, after the `searchRef` declaration (line 64), add:

```ts
  const { leftWidth, containerRef, handleMouseDown: handleResizeMouseDown, handleDoubleClick: handleResizeDoubleClick, isDragging, nudge } =
    useResizablePanel({
      storageKey: 'panel-width:user-management',
      defaultLeftWidth: 0, // auto: container - 400px
      minLeftWidth: 280,
      minRightWidth: 320,
    });
```

> **Note:** Renamed `handleMouseDown` to `handleResizeMouseDown` to avoid collision with any future handlers.

**Step 3: Replace the grid layout**

Replace lines 128-153 (the `<div className="grid ...">` block through its closing `</div>`):

**Before:**
```tsx
      {/* Height: viewport minus topbar (64px) + breadcrumb (~48px) + page header (~68px) = ~180px */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-6 h-[calc(100vh-var(--topbar-height)-7.25rem)]">
        {/* Left panel: user list */}
        <Suspense fallback={<UserListSkeleton />}>
          <UserListPanel
            selectedUserId={userId}
            filter={filter}
            search={search}
            onSelectUser={handleSelectUser}
            onFilterChange={handleFilterChange}
          />
        </Suspense>

        {/* Right panel: user detail */}
        <div className="hidden lg:flex flex-col rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden">
          {userId ? (
            <UserDetailPanel
              userId={userId}
              onGenerateQR={handleGenerateQR}
              onTerminate={handleTerminate}
            />
          ) : (
            <EmptyDetailPanel />
          )}
        </div>
      </div>
```

**After:**
```tsx
      {/* Split panel: resizable left (list) | right (detail) */}
      <div
        ref={containerRef}
        className="flex h-[calc(100vh-var(--topbar-height)-7.25rem)]"
      >
        {/* Left panel: user list */}
        <div
          style={leftWidth > 0 ? { width: leftWidth } : undefined}
          className="shrink-0 min-w-0 w-full lg:w-auto"
        >
          <Suspense fallback={<UserListSkeleton />}>
            <UserListPanel
              selectedUserId={userId}
              filter={filter}
              search={search}
              onSelectUser={handleSelectUser}
              onFilterChange={handleFilterChange}
            />
          </Suspense>
        </div>

        {/* Resize handle (desktop only) */}
        <ResizeHandle
          className="hidden lg:flex"
          onMouseDown={handleResizeMouseDown}
          onDoubleClick={handleResizeDoubleClick}
          isDragging={isDragging}
          onNudge={nudge}
        />

        {/* Right panel: user detail */}
        <div className="hidden lg:flex flex-1 min-w-0 flex-col rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden">
          {userId ? (
            <UserDetailPanel
              userId={userId}
              onGenerateQR={handleGenerateQR}
              onTerminate={handleTerminate}
            />
          ) : (
            <EmptyDetailPanel />
          )}
        </div>
      </div>
```

**Step 4: Verify TypeScript compiles**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend && npx tsc --noEmit --pretty 2>&1 | head -30`
Expected: No errors

**Step 5: Visual smoke test**

1. Run `just up` (if not already running)
2. Open http://localhost:8081/directory/users
3. Verify: the handle appears between the list and detail panels
4. Verify: drag to resize works, cursor changes to `col-resize`
5. Verify: double-click resets width
6. Verify: refresh page — width persists from localStorage
7. Verify: on mobile viewport (< 1024px) — layout stacks vertically, no handle visible

**Step 6: Commit**

```bash
git add src/frontend/src/components/features/user-management/UserManagementPage.tsx
git commit -m "feat(users): wire resizable split panel to user management page"
```

---

### Task 4: Integrate into GroupManagementPage

**Files:**
- Modify: `src/frontend/src/components/features/group-management/GroupManagementPage.tsx:9,139,152-163`

**Step 1: Add imports**

After line 21 (`import type { GroupListItem } from '@/types/group';`), add:

```ts
import { useResizablePanel } from '@/hooks/use-resizable-panel';
import { ResizeHandle } from '@/components/layout/resize-handle';
```

**Step 2: Add the hook call**

Inside `GroupManagementPage` function, after the `modal` declaration (line 62), add:

```ts
  const { leftWidth, containerRef, handleMouseDown: handleResizeMouseDown, handleDoubleClick: handleResizeDoubleClick, isDragging, nudge } =
    useResizablePanel({
      storageKey: 'panel-width:group-management',
      defaultLeftWidth: 0, // auto: container - 420px
      minLeftWidth: 280,
      minRightWidth: 340,
    });
```

**Step 3: Replace the grid layout**

Replace lines 138-163 (the `<div className="grid ...">` block through its closing `</div>`):

**Before:**
```tsx
      {/* Height: viewport minus topbar (64px) + breadcrumb (~48px) + page header (~68px) = ~180px */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_420px] gap-6 h-[calc(100vh-var(--topbar-height)-7.25rem)]">
        {/* Left panel: group list */}
        <Suspense fallback={<GroupListSkeleton />}>
          <GroupListPanel
            selectedGroupId={groupId}
            filter={filter}
            search={search}
            onSelectGroup={handleSelectGroup}
            onFilterChange={handleFilterChange}
          />
        </Suspense>

        {/* Right panel: group detail */}
        <div className="hidden lg:flex flex-col rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden">
          {groupId ? (
            <GroupDetailPanel
              groupId={groupId}
              onDelete={handleDeleteGroup}
              onAddMember={(cn) => modal.openAddMembers(cn)}
            />
          ) : (
            <EmptyDetailPanel />
          )}
        </div>
      </div>
```

**After:**
```tsx
      {/* Split panel: resizable left (list) | right (detail) */}
      <div
        ref={containerRef}
        className="flex h-[calc(100vh-var(--topbar-height)-7.25rem)]"
      >
        {/* Left panel: group list */}
        <div
          style={leftWidth > 0 ? { width: leftWidth } : undefined}
          className="shrink-0 min-w-0 w-full lg:w-auto"
        >
          <Suspense fallback={<GroupListSkeleton />}>
            <GroupListPanel
              selectedGroupId={groupId}
              filter={filter}
              search={search}
              onSelectGroup={handleSelectGroup}
              onFilterChange={handleFilterChange}
            />
          </Suspense>
        </div>

        {/* Resize handle (desktop only) */}
        <ResizeHandle
          className="hidden lg:flex"
          onMouseDown={handleResizeMouseDown}
          onDoubleClick={handleResizeDoubleClick}
          isDragging={isDragging}
          onNudge={nudge}
        />

        {/* Right panel: group detail */}
        <div className="hidden lg:flex flex-1 min-w-0 flex-col rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden">
          {groupId ? (
            <GroupDetailPanel
              groupId={groupId}
              onDelete={handleDeleteGroup}
              onAddMember={(cn) => modal.openAddMembers(cn)}
            />
          ) : (
            <EmptyDetailPanel />
          )}
        </div>
      </div>
```

**Step 4: Verify TypeScript compiles**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend && npx tsc --noEmit --pretty 2>&1 | head -30`
Expected: No errors

**Step 5: Visual smoke test**

1. Open http://localhost:8081/directory/groups
2. Verify: drag-to-resize works between group list and detail panel
3. Verify: different localStorage key from users page (`panel-width:group-management`)
4. Verify: navigate to users page and back — each page remembers its own width

**Step 6: Commit**

```bash
git add src/frontend/src/components/features/group-management/GroupManagementPage.tsx
git commit -m "feat(groups): wire resizable split panel to group management page"
```

---

### Task 5: Integrate into OrgManagementPage

**Files:**
- Modify: `src/frontend/src/components/features/org-management/OrgManagementPage.tsx:8,69,81-93`

> **Note:** Orgs has the left panel as the *tree* (smaller, 320px default) and right as detail (larger). The hook defaultLeftWidth is 320 (not 0/auto) since the tree is the narrow side.

**Step 1: Add imports**

After line 17 (`import type { EnrichedOrgTreeNode } from '@/types/org';`), add:

```ts
import { useResizablePanel } from '@/hooks/use-resizable-panel';
import { ResizeHandle } from '@/components/layout/resize-handle';
```

**Step 2: Add the hook call**

Inside `OrgManagementPage` function, after the `modal` declaration (line 33), add:

```ts
  const { leftWidth, containerRef, handleMouseDown: handleResizeMouseDown, handleDoubleClick: handleResizeDoubleClick, isDragging, nudge } =
    useResizablePanel({
      storageKey: 'panel-width:org-management',
      defaultLeftWidth: 320,
      minLeftWidth: 200,
      minRightWidth: 400,
    });
```

**Step 3: Replace the grid layout**

Replace lines 68-93 (the `<div className="grid ...">` block through its closing `</div>`):

**Before:**
```tsx
      {/* Split panel: tree (320px) | detail */}
      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-6 h-[calc(100vh-var(--topbar-height)-7.25rem)]">
        {/* Left panel: org tree */}
        <Suspense fallback={<OrgTreeSkeleton />}>
          <OrgTreeWithModal
            selectedDn={orgId}
            onSelect={handleSelectOrg}
            modalState={modal}
            onCreateSuccess={handleCreateSuccess}
          />
        </Suspense>

        {/* Right panel: detail */}
        <div className="hidden lg:flex flex-col rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden">
          {orgId ? (
            <OrgDetailPanel
              dn={orgId}
              tab={searchParams.tab || 'overview'}
              onTabChange={handleTabChange}
              onSelectChild={handleSelectOrg}
            />
          ) : (
            <EmptyDetailPanel />
          )}
        </div>
      </div>
```

**After:**
```tsx
      {/* Split panel: resizable left (tree) | right (detail) */}
      <div
        ref={containerRef}
        className="flex h-[calc(100vh-var(--topbar-height)-7.25rem)]"
      >
        {/* Left panel: org tree */}
        <div
          style={leftWidth > 0 ? { width: leftWidth } : undefined}
          className="shrink-0 min-w-0 w-full lg:w-auto"
        >
          <Suspense fallback={<OrgTreeSkeleton />}>
            <OrgTreeWithModal
              selectedDn={orgId}
              onSelect={handleSelectOrg}
              modalState={modal}
              onCreateSuccess={handleCreateSuccess}
            />
          </Suspense>
        </div>

        {/* Resize handle (desktop only) */}
        <ResizeHandle
          className="hidden lg:flex"
          onMouseDown={handleResizeMouseDown}
          onDoubleClick={handleResizeDoubleClick}
          isDragging={isDragging}
          onNudge={nudge}
        />

        {/* Right panel: detail */}
        <div className="hidden lg:flex flex-1 min-w-0 flex-col rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden">
          {orgId ? (
            <OrgDetailPanel
              dn={orgId}
              tab={searchParams.tab || 'overview'}
              onTabChange={handleTabChange}
              onSelectChild={handleSelectOrg}
            />
          ) : (
            <EmptyDetailPanel />
          )}
        </div>
      </div>
```

**Step 4: Verify TypeScript compiles**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend && npx tsc --noEmit --pretty 2>&1 | head -30`
Expected: No errors

**Step 5: Visual smoke test**

1. Open http://localhost:8081/directory/orgs
2. Verify: drag-to-resize works — tree can shrink to 200px, detail needs at least 400px
3. Verify: double-click resets tree to 320px
4. Verify: keyboard (focus handle via Tab, then Arrow Left/Right nudges by 20px)

**Step 6: Commit**

```bash
git add src/frontend/src/components/features/org-management/OrgManagementPage.tsx
git commit -m "feat(orgs): wire resizable split panel to org management page"
```

---

### Task 6: Write Playwright e2e tests for resize behavior

**Files:**
- Create: `src/frontend/e2e/resizable-panel.spec.ts`

> **Context:** Existing Playwright tests are in `src/frontend/e2e/`. Config at `src/frontend/playwright.config.ts` points to `http://localhost:3000` (Vite dev server). The Docker stack must be running (`just up`) for API data.

**Step 1: Create the e2e test file**

```ts
// src/frontend/e2e/resizable-panel.spec.ts

/**
 * E2E tests for resizable split panels across all management pages.
 * - Verifies drag-to-resize changes panel width
 * - Verifies localStorage persistence across navigation
 * - Verifies double-click resets to default
 * - Verifies keyboard nudge (Arrow Left/Right)
 */
import { test, expect } from '@playwright/test';

const PAGES = [
  { name: 'Users', url: '/directory/users', storageKey: 'panel-width:user-management' },
  { name: 'Groups', url: '/directory/groups', storageKey: 'panel-width:group-management' },
  { name: 'Orgs', url: '/directory/orgs', storageKey: 'panel-width:org-management' },
] as const;

for (const { name, url, storageKey } of PAGES) {
  test.describe(`${name} page — resizable panel`, () => {
    test.beforeEach(async ({ page }) => {
      // Clear stored width so each test starts fresh
      await page.goto(url);
      await page.evaluate((key) => localStorage.removeItem(key), storageKey);
      await page.reload();
      // Wait for the page content to load
      await page.waitForSelector('[role="separator"]', { timeout: 10000 });
    });

    test('resize handle is visible on desktop viewport', async ({ page }) => {
      await page.setViewportSize({ width: 1280, height: 800 });
      await page.goto(url);
      const handle = page.getByRole('separator', { name: 'Resize panels' });
      await expect(handle).toBeVisible();
    });

    test('resize handle is hidden on mobile viewport', async ({ page }) => {
      await page.setViewportSize({ width: 375, height: 812 });
      await page.goto(url);
      const handle = page.getByRole('separator', { name: 'Resize panels' });
      await expect(handle).toBeHidden();
    });

    test('drag to resize changes left panel width', async ({ page }) => {
      await page.setViewportSize({ width: 1280, height: 800 });
      await page.goto(url);
      const handle = page.getByRole('separator', { name: 'Resize panels' });

      // Get initial left panel width
      const container = handle.locator('..');
      const leftPanel = container.locator('> div').first();
      const initialWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width);

      // Drag handle 100px to the right
      const handleBox = await handle.boundingBox();
      if (!handleBox) throw new Error('Handle not found');
      await page.mouse.move(handleBox.x + handleBox.width / 2, handleBox.y + handleBox.height / 2);
      await page.mouse.down();
      await page.mouse.move(handleBox.x + 100, handleBox.y + handleBox.height / 2, { steps: 5 });
      await page.mouse.up();

      // Verify width changed
      const newWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width);
      expect(newWidth).toBeGreaterThan(initialWidth + 50); // allow some tolerance
    });

    test('width persists in localStorage after drag', async ({ page }) => {
      await page.setViewportSize({ width: 1280, height: 800 });
      await page.goto(url);
      const handle = page.getByRole('separator', { name: 'Resize panels' });

      // Drag handle
      const handleBox = await handle.boundingBox();
      if (!handleBox) throw new Error('Handle not found');
      await page.mouse.move(handleBox.x + handleBox.width / 2, handleBox.y + handleBox.height / 2);
      await page.mouse.down();
      await page.mouse.move(handleBox.x + 80, handleBox.y + handleBox.height / 2, { steps: 5 });
      await page.mouse.up();

      // Check localStorage was set
      const stored = await page.evaluate((key) => localStorage.getItem(key), storageKey);
      expect(stored).not.toBeNull();
      expect(Number(stored)).toBeGreaterThan(0);

      // Reload and verify width is restored
      await page.reload();
      await page.waitForSelector('[role="separator"]');
      const storedAfterReload = await page.evaluate((key) => localStorage.getItem(key), storageKey);
      expect(storedAfterReload).toBe(stored);
    });

    test('double-click resets to default width', async ({ page }) => {
      await page.setViewportSize({ width: 1280, height: 800 });
      await page.goto(url);
      const handle = page.getByRole('separator', { name: 'Resize panels' });
      const container = handle.locator('..');
      const leftPanel = container.locator('> div').first();

      // Get initial (default) width
      const defaultWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width);

      // Drag to change width
      const handleBox = await handle.boundingBox();
      if (!handleBox) throw new Error('Handle not found');
      await page.mouse.move(handleBox.x + handleBox.width / 2, handleBox.y + handleBox.height / 2);
      await page.mouse.down();
      await page.mouse.move(handleBox.x + 150, handleBox.y + handleBox.height / 2, { steps: 5 });
      await page.mouse.up();

      // Verify width changed
      const draggedWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width);
      expect(draggedWidth).not.toBeCloseTo(defaultWidth, -1);

      // Double-click to reset
      await handle.dblclick();

      // Verify width is back to default (within 5px tolerance)
      const resetWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width);
      expect(Math.abs(resetWidth - defaultWidth)).toBeLessThan(5);
    });

    test('keyboard Arrow Left/Right nudges panel width', async ({ page }) => {
      await page.setViewportSize({ width: 1280, height: 800 });
      await page.goto(url);
      const handle = page.getByRole('separator', { name: 'Resize panels' });
      const container = handle.locator('..');
      const leftPanel = container.locator('> div').first();

      // Focus the handle
      await handle.focus();

      // Get current width
      const initialWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width);

      // Press ArrowRight to nudge +20px
      await handle.press('ArrowRight');
      const afterRight = await leftPanel.evaluate((el) => el.getBoundingClientRect().width);
      expect(Math.abs(afterRight - initialWidth - 20)).toBeLessThan(5);

      // Press ArrowLeft to nudge -20px
      await handle.press('ArrowLeft');
      const afterLeft = await leftPanel.evaluate((el) => el.getBoundingClientRect().width);
      expect(Math.abs(afterLeft - initialWidth)).toBeLessThan(5);
    });
  });
}
```

**Step 2: Run the tests (stack must be running)**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend && npx playwright test e2e/resizable-panel.spec.ts --headed 2>&1 | tail -20`

Expected: All tests pass. If any fail, debug one at a time:
```bash
npx playwright test e2e/resizable-panel.spec.ts -g "drag to resize" --headed --debug
```

**Step 3: Commit**

```bash
git add src/frontend/e2e/resizable-panel.spec.ts
git commit -m "test(e2e): add Playwright tests for resizable split panels"
```

---

### Task 7: Update docstrings in modified files

**Files:**
- Modify: `src/frontend/src/components/features/user-management/UserManagementPage.tsx:1-7`
- Modify: `src/frontend/src/components/features/group-management/GroupManagementPage.tsx:1-8`
- Modify: `src/frontend/src/components/features/org-management/OrgManagementPage.tsx:1-7`

**Step 1: Update file-level docstrings**

Each management page's top-of-file docstring currently says "split-panel master-detail layout". Update to mention resizable behavior.

**UserManagementPage.tsx — replace lines 1-7:**
```ts
/**
 * Top-level User Management page — resizable split-panel master-detail layout.
 * - Left panel: user list with search + filter tabs (drag handle to resize)
 * - Right panel: user detail with provisioning status, QR history, danger zone
 * - URL search params drive selection: ?userId=mei&filter=all&search=
 * - Modal state machine drives QR generation, termination, add-user dialogs
 * - Panel width persists to localStorage (key: panel-width:user-management)
 */
```

**GroupManagementPage.tsx — replace lines 1-8:**
```ts
/**
 * Top-level Group Management page — resizable split-panel master-detail layout.
 * - Left panel: group list with search + filter tabs (drag handle to resize)
 * - Right panel: group detail panel (GroupDetailPanel)
 * - URL search params drive selection: ?groupId=admins&filter=all&search=
 * - Cmd+K to focus search input
 * - Create/Delete group modals wired via useModalState
 * - Panel width persists to localStorage (key: panel-width:group-management)
 */
```

**OrgManagementPage.tsx — replace lines 1-7:**
```ts
/**
 * Top-level Organization Management page — resizable split-panel master-detail layout.
 * - Left panel: org tree (200px min, 320px default, drag handle to resize)
 * - Right panel: org detail panel (tabbed: Overview, SSO, Users, Provisioning)
 * - URL search params drive selection: ?orgId=ou%3DEngineering%2C...&tab=overview
 * - Modal state: create org, edit SSO, delete confirm
 * - Panel width persists to localStorage (key: panel-width:org-management)
 */
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/user-management/UserManagementPage.tsx \
        src/frontend/src/components/features/group-management/GroupManagementPage.tsx \
        src/frontend/src/components/features/org-management/OrgManagementPage.tsx
git commit -m "docs: update management page docstrings for resizable panels"
```

---

### Task 8: Final TypeScript check + full e2e pass

**Files:** None (verification only)

**Step 1: Full TypeScript check**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend && npx tsc --noEmit --pretty`
Expected: Exit code 0, no errors

**Step 2: Full Playwright e2e suite**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend && npx playwright test`
Expected: All tests pass (existing dashboard tests + new resizable-panel tests)

**Step 3: Manual cross-page smoke test**

1. Navigate Users → Groups → Orgs, resizing each
2. Verify each page remembers its own width independently
3. Verify no visual regressions in the detail panels (scrolling, overflow, etc.)
4. Verify mobile viewport (375px) — panels stack, no horizontal overflow

If anything fails, fix before proceeding. Do not skip.
