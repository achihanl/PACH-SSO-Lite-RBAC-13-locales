# SIP/PJSIP Provisioning Integration Tests — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add integration tests proving UED Sync can provision Asterisk PJSIP LDAP entries and validate LDAP bind auth against real OpenLDAP.

**Architecture:** Create the upstream Asterisk PJSIP LDAP schema file, mount it into the dev OpenLDAP container so it loads on bootstrap, then write integration tests that provision combined posixAccount+PJSIP entries and verify both attribute correctness and LDAP bind authentication.

**Tech Stack:** Python 3.12, pytest, FastAPI TestClient, OpenLDAP (osixia/openldap:1.5.0), Asterisk PJSIP LDAP schema (OID base `1.3.6.1.4.1.22736`)

**Design doc:** `docs/plans/2026-02-19-sip-pjsip-provisioning-tests-design.md`

---

### Task 1: Create the Asterisk PJSIP LDAP Schema File

The upstream Asterisk project defines PJSIP objectClasses in `contrib/scripts/asterisk.ldap-schema` ([GitLab fork with PJSIP additions](https://gitlab.com/XavierBrassoud/asterisk-pjsip-ldap-schema)). We need a **minimal subset** containing only the three objectClasses and the attributes our tests use. Using `.schema` format because osixia/openldap auto-converts `.schema` → LDIF via `schema-to-ldif.sh`.

**Files:**
- Create: `deploy/dev/ldap/asterisk-pjsip.schema`

**Step 1: Create the schema file with PJSIP objectClasses and attributes**

The schema uses Asterisk's registered OID namespace `1.3.6.1.4.1.22736`. Key detail from upstream: all three PJSIP objectClasses require `MUST cn` (not the `Ast*Id` attributes — those are MAY). We include only the attributes used in our test fixture plus a few commonly needed ones.

```schema
# Asterisk PJSIP LDAP Schema (minimal subset for AZBlink dev/test)
#
# Source: https://gitlab.com/XavierBrassoud/asterisk-pjsip-ldap-schema
# OID base: 1.3.6.1.4.1.22736 (Digium/Sangoma registered)
#
# Only the objectClasses and attributes needed for UED Sync integration
# testing are included. For production Asterisk deployments, use the full
# upstream schema.

objectIdentifier AsteriskRoot 1.3.6.1.4.1.22736
objectIdentifier AsteriskLDAP AsteriskRoot:5
objectIdentifier AstAttrType AsteriskLDAP:4
objectIdentifier AstObjectClass AsteriskLDAP:2

# ============================================================
# AoR (Address of Record) attributes
# ============================================================

attributetype ( AstAttrType:71
    NAME 'AstAorId'
    DESC 'Aor ID'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:72
    NAME 'AstAorContact'
    DESC 'Permanent contacts assigned to AoR'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:77
    NAME 'AstAorMaxContacts'
    DESC 'Maximum number of contacts that can bind to an AoR'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:79
    NAME 'AstAorRemoveExisting'
    DESC 'Determines whether new contacts replace existing ones'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:80
    NAME 'AstAorQualifyFrequency'
    DESC 'Interval at which to qualify an AoR'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

# ============================================================
# Auth attributes
# ============================================================

attributetype ( AstAttrType:85
    NAME 'AstAuthId'
    DESC 'Auth ID'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:86
    NAME 'AstAuthType'
    DESC 'Authentication type'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:88
    NAME 'AstAuthMd5Cred'
    DESC 'MD5 Hash used for authentication'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:89
    NAME 'AstAuthPassword'
    DESC 'Plain text password used for authentication'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:90
    NAME 'AstAuthRealm'
    DESC 'SIP realm for endpoint'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:91
    NAME 'AstAuthUsername'
    DESC 'Username to use for account'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

# ============================================================
# Endpoint attributes
# ============================================================

attributetype ( AstAttrType:94
    NAME 'AstEndpointId'
    DESC 'Endpoint ID'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:97
    NAME 'AstEndpointAllow'
    DESC 'Media Codec(s) to allow'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:99
    NAME 'AstEndpointAors'
    DESC 'AoR(s) to be used with the endpoint'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:100
    NAME 'AstEndpointAuth'
    DESC 'Authentication Object(s) associated with the endpoint'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:104
    NAME 'AstEndpointContext'
    DESC 'Dialplan context for inbound sessions'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:112
    NAME 'AstEndpointDisallow'
    DESC 'Media Codec(s) to disallow'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

attributetype ( AstAttrType:136
    NAME 'AstEndpointTransport'
    DESC 'Explicit transport configuration to use'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 )

# ============================================================
# PJSIP ObjectClasses
# ============================================================

objectclass ( AstObjectClass:9
    NAME 'AsteriskPjsipAor'
    DESC 'Asterisk PJSIP Address of Record'
    SUP top AUXILIARY
    MUST cn
    MAY ( AstAorId $ AstAorContact $ AstAorMaxContacts $
          AstAorRemoveExisting $ AstAorQualifyFrequency ) )

objectclass ( AstObjectClass:10
    NAME 'AsteriskPjsipAuth'
    DESC 'Asterisk PJSIP Authentication'
    SUP top AUXILIARY
    MUST cn
    MAY ( AstAuthId $ AstAuthType $ AstAuthMd5Cred $
          AstAuthPassword $ AstAuthRealm $ AstAuthUsername ) )

objectclass ( AstObjectClass:12
    NAME 'AsteriskPjsipEndpoint'
    DESC 'Asterisk PJSIP Endpoint'
    SUP top AUXILIARY
    MUST cn
    MAY ( AstEndpointId $ AstEndpointAllow $ AstEndpointAors $
          AstEndpointAuth $ AstEndpointContext $ AstEndpointDisallow $
          AstEndpointTransport ) )
```

**Step 2: Verify file is created**

Run: `ls -la deploy/dev/ldap/asterisk-pjsip.schema`
Expected: File exists, ~3.5KB

**Step 3: Commit**

```bash
git add deploy/dev/ldap/asterisk-pjsip.schema
git commit -m "feat(ldap): add Asterisk PJSIP schema for SIP provisioning tests

Minimal subset of upstream Asterisk PJSIP LDAP schema (OID 1.3.6.1.4.1.22736)
containing AsteriskPjsipEndpoint, AsteriskPjsipAuth, AsteriskPjsipAor."
```

---

### Task 2: Mount Schema in Docker Compose

The osixia/openldap container auto-converts `.schema` files mounted at `/container/service/slapd/assets/config/bootstrap/schema/` into cn=config LDIF during first boot.

**Files:**
- Modify: `deploy/dev/docker-compose.yml:54-57` (openldap volumes section)

**Step 1: Add the schema volume mount**

Add this line to the `openldap.volumes` array, **before** the existing bootstrap.ldif mount:

```yaml
    volumes:
      - azblink_ldap_data:/var/lib/ldap
      - azblink_ldap_config:/etc/ldap/slapd.d
      - ./ldap/asterisk-pjsip.schema:/container/service/slapd/assets/config/bootstrap/schema/asterisk-pjsip.schema:ro
      - ./ldap/bootstrap.ldif:/container/service/slapd/assets/config/bootstrap/ldif/custom/bootstrap.ldif:ro
```

**Step 2: Verify docker-compose.yml is valid**

Run: `cd deploy/dev && docker compose config --quiet && echo "valid"`
Expected: `valid` (no errors)

**Step 3: Commit**

```bash
git add deploy/dev/docker-compose.yml
git commit -m "feat(docker): mount Asterisk PJSIP schema into OpenLDAP container

Schema auto-converts to cn=config LDIF on container bootstrap.
Requires: just reset && just up (one-time rebuild)."
```

---

### Task 3: Rebuild Dev Stack with New Schema

The OpenLDAP container only processes schema files during initial bootstrap. Existing LDAP data volume must be reset.

**Files:** None (infrastructure only)

**Step 1: Reset and rebuild the dev stack**

Run: `just reset && just up-bg`
Expected: All containers start healthy. OpenLDAP logs should show the new schema being loaded.

**Step 2: Verify PJSIP schema is loaded in OpenLDAP**

Run from host (port 1390):
```bash
ldapsearch -x -H ldap://localhost:1390 -D "cn=admin,dc=azblink,dc=com" -w adminpassword \
  -b "cn=schema,cn=config" "(cn=*asterisk*)" cn -LLL
```

Expected output includes:
```
dn: cn={N}asterisk-pjsip,cn=schema,cn=config
cn: {N}asterisk-pjsip
```

where `{N}` is some integer (schema load order).

**Step 3: Verify objectClasses are available**

Run:
```bash
ldapsearch -x -H ldap://localhost:1390 -D "cn=admin,dc=azblink,dc=com" -w adminpassword \
  -b "cn=schema,cn=config" "(cn=*asterisk*)" olcObjectClasses -LLL 2>/dev/null | grep "NAME"
```

Expected: Lines containing `AsteriskPjsipEndpoint`, `AsteriskPjsipAuth`, `AsteriskPjsipAor`.

**Step 4: Quick smoke test — manually create a PJSIP entry**

```bash
ldapadd -x -H ldap://localhost:1390 -D "cn=admin,dc=azblink,dc=com" -w adminpassword <<'EOF'
dn: uid=schematest,ou=people,dc=azblink,dc=com
objectClass: top
objectClass: account
objectClass: posixAccount
objectClass: AsteriskPjsipEndpoint
objectClass: AsteriskPjsipAuth
objectClass: AsteriskPjsipAor
uid: schematest
cn: Schema Test
uidNumber: 9999
gidNumber: 1000
homeDirectory: /home/schematest
loginShell: /bin/bash
userPassword: testpass
AstEndpointId: 9999
AstEndpointAuth: 9999
AstEndpointAors: 9999
AstEndpointContext: all
AstAuthId: 9999
AstAuthType: userpass
AstAuthUsername: 9999
AstAuthPassword: sippass123
AstAorId: 9999
AstAorMaxContacts: 1
EOF
```

Expected: `adding new entry "uid=schematest,ou=people,dc=azblink,dc=com"` (no errors)

**Step 5: Clean up smoke test entry**

```bash
ldapdelete -x -H ldap://localhost:1390 -D "cn=admin,dc=azblink,dc=com" -w adminpassword \
  "uid=schematest,ou=people,dc=azblink,dc=com"
```

Expected: No errors.

---

### Task 4: Write the First Integration Test — Provisioning Correctness

**Files:**
- Create: `src/ued-sync/tests/integration/test_sip_provisioning.py`

**Step 1: Write the test file with fixture and first test**

```python
"""Integration tests for SIP/PJSIP provisioning via UED Sync against real LDAP.

Verifies that UED Sync correctly provisions LDAP entries with Asterisk PJSIP
objectClasses (AsteriskPjsipEndpoint, AsteriskPjsipAuth, AsteriskPjsipAor)
and validates LDAP bind authentication for provisioned SIP users.

Requires:
- Real OpenLDAP with Asterisk PJSIP schema loaded
- Run with: just ued-test-integration
"""

import os
import time

import pytest
from fastapi.testclient import TestClient

from ued_sync.main import app


pytestmark = pytest.mark.integration


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def api_headers():
    return {"X-API-Key": os.getenv("UED_API_KEY", "dev-api-key-change-me")}


@pytest.fixture
def ldap_config():
    """Real LDAP connection config from environment."""
    return {
        "uri": f"ldap://{os.getenv('UED_LDAP_HOST', 'localhost')}:{os.getenv('UED_LDAP_PORT', '389')}",
        "base_dn": os.getenv("UED_LDAP_BASE_DN", "dc=example,dc=com"),
        "bind_dn": os.getenv("UED_LDAP_BIND_DN", "cn=admin,dc=example,dc=com"),
        "bind_pw": os.getenv("UED_LDAP_BIND_PASSWORD", ""),
        "use_ssl": False,
    }


@pytest.fixture
def pjsip_schema():
    """Schema for combined posixAccount + PJSIP user entry.

    Matches the addComboPJ pattern: single LDAP entry carries identity
    (posixAccount) and all three PJSIP objectClasses (Endpoint, Auth, AoR).
    """
    return {
        "dn_template": "uid={username},ou=People,{base_dn}",
        "object_classes": [
            "top",
            "account",
            "posixAccount",
            "AsteriskPjsipEndpoint",
            "AsteriskPjsipAuth",
            "AsteriskPjsipAor",
        ],
        "attribute_map": {
            "uid": "{username}",
            "cn": "{display_name}",
            "uidNumber": "{extension}",
            "gidNumber": "1000",
            "homeDirectory": "/home/{username}",
            "loginShell": "/bin/bash",
            # PJSIP Endpoint
            "AstEndpointId": "{extension}",
            "AstEndpointAuth": "{extension}",
            "AstEndpointAors": "{extension}",
            "AstEndpointContext": "all",
            # PJSIP Auth
            "AstAuthId": "{extension}",
            "AstAuthType": "userpass",
            "AstAuthUsername": "{extension}",
            "AstAuthPassword": "{sip_password}",
            # PJSIP AoR
            "AstAorId": "{extension}",
            "AstAorMaxContacts": "1",
        },
        "required_fields": ["username", "display_name", "extension", "sip_password"],
        "password_attribute": "userPassword",
        "password_hash": "SSHA",
    }


@pytest.fixture
def sip_test_uid():
    """Generate unique test UID to avoid conflicts."""
    return f"siptest{int(time.time()) % 10000}"


@pytest.fixture
def sip_test_extension(sip_test_uid):
    """SIP extension number derived from test UID timestamp."""
    return str(6000 + int(sip_test_uid.replace("siptest", "")))


@pytest.fixture
def cleanup_sip_user(client, api_headers, ldap_config, pjsip_schema, sip_test_uid, sip_test_extension):
    """Fixture that ensures SIP test user is cleaned up after test."""
    yield sip_test_uid
    try:
        delete_request = {
            "operation": "delete",
            "request_id": f"cleanup-sip-{sip_test_uid}",
            "ldap": ldap_config,
            "schema": pjsip_schema,
            "user": {
                "username": sip_test_uid,
                "display_name": "Cleanup",
                "extension": sip_test_extension,
                "sip_password": "unused",
            },
        }
        client.post("/api/v1/sync/user", json=delete_request, headers=api_headers)
    except Exception:
        pass


class TestSipProvisioningCorrectness:
    """Verify UED Sync creates well-formed PJSIP LDAP entries."""

    def test_provision_sip_user_creates_valid_entry(
        self,
        client,
        api_headers,
        ldap_config,
        pjsip_schema,
        cleanup_sip_user,
        sip_test_extension,
    ):
        """Provision a SIP user and verify all PJSIP attributes are present."""
        test_uid = cleanup_sip_user
        sip_password = "haha123"

        # Create SIP user via UED Sync
        create_request = {
            "operation": "create",
            "request_id": f"sip-create-{test_uid}",
            "ldap": ldap_config,
            "schema": pjsip_schema,
            "user": {
                "username": test_uid,
                "display_name": f"SIP Test {sip_test_extension}",
                "extension": sip_test_extension,
                "sip_password": sip_password,
            },
            "password": "PosixPassword123!",
        }

        response = client.post(
            "/api/v1/sync/user", json=create_request, headers=api_headers
        )
        assert response.status_code == 200, f"Create failed: {response.json()}"
        data = response.json()
        assert data["ok"] is True
        assert data["operation"] == "create"
        assert test_uid in data["dn"]

        # Verify: search for the entry and check PJSIP attributes exist
        # Use auth/validate endpoint with return_attributes to read back the entry
        verify_request = {
            "request_id": f"sip-verify-{test_uid}",
            "ldap": ldap_config,
            "schema": {
                "search": {
                    "base_dn": "ou=People,{base_dn}",
                    "filter_template": "(uid={username})",
                    "scope": "subtree",
                },
                "return_attributes": [
                    "objectClass",
                    "AstEndpointId",
                    "AstEndpointAuth",
                    "AstEndpointAors",
                    "AstEndpointContext",
                    "AstAuthId",
                    "AstAuthType",
                    "AstAuthUsername",
                    "AstAuthPassword",
                    "AstAorId",
                    "AstAorMaxContacts",
                ],
            },
            "credentials": {
                "username": test_uid,
                "password": "PosixPassword123!",
            },
        }

        response = client.post(
            "/api/v1/sync/auth/validate",
            json=verify_request,
            headers=api_headers,
        )
        assert response.status_code == 200, f"Verify failed: {response.json()}"
        data = response.json()
        assert data["ok"] is True
        assert data["authenticated"] is True

        # Check returned attributes contain PJSIP data
        user_attrs = data.get("user", {}).get("attributes", {})
        if user_attrs:
            # If return_attributes is supported, verify PJSIP attributes
            assert sip_test_extension in str(
                user_attrs.get("AstEndpointId", "")
            ), "AstEndpointId missing or wrong"
            assert sip_test_extension in str(
                user_attrs.get("AstAuthId", "")
            ), "AstAuthId missing or wrong"
            assert sip_test_extension in str(
                user_attrs.get("AstAorId", "")
            ), "AstAorId missing or wrong"
            assert "userpass" in str(
                user_attrs.get("AstAuthType", "")
            ).lower(), "AstAuthType should be userpass"
```

**Step 2: Run the test to verify it passes against real LDAP**

Run: `just ued-test-integration`
Expected: `test_provision_sip_user_creates_valid_entry` PASSES (entry created with PJSIP objectClasses)

If it FAILS with `OBJECT_CLASS_VIOLATION`, the schema wasn't loaded — go back to Task 3.

**Step 3: Commit**

```bash
git add src/ued-sync/tests/integration/test_sip_provisioning.py
git commit -m "test(ued-sync): add SIP provisioning correctness integration test

Verifies UED Sync creates LDAP entries with AsteriskPjsipEndpoint,
AsteriskPjsipAuth, AsteriskPjsipAor objectClasses against real OpenLDAP."
```

---

### Task 5: Add LDAP Bind Auth Tests

Build on Task 4's file — add tests that verify LDAP bind works for provisioned SIP users.

**Files:**
- Modify: `src/ued-sync/tests/integration/test_sip_provisioning.py`

**Step 1: Add the bind auth test class**

Append after `TestSipProvisioningCorrectness`:

```python
class TestSipLdapBindAuth:
    """Verify LDAP bind authentication works for provisioned SIP users.

    This tests Layer 1 (management bind) of the SIP auth flow:
    a service account searches LDAP for the user, then the user's
    POSIX password is validated via LDAP bind.
    """

    def test_provision_sip_user_ldap_bind_succeeds(
        self,
        client,
        api_headers,
        ldap_config,
        pjsip_schema,
        cleanup_sip_user,
        sip_test_extension,
    ):
        """Provisioned SIP user can authenticate via LDAP bind."""
        test_uid = cleanup_sip_user
        posix_password = "SipUserPassword456!"

        # Create SIP user
        create_request = {
            "operation": "create",
            "request_id": f"sip-auth-create-{test_uid}",
            "ldap": ldap_config,
            "schema": pjsip_schema,
            "user": {
                "username": test_uid,
                "display_name": f"SIP Auth Test {sip_test_extension}",
                "extension": sip_test_extension,
                "sip_password": "haha123",
            },
            "password": posix_password,
        }

        response = client.post(
            "/api/v1/sync/user", json=create_request, headers=api_headers
        )
        assert response.status_code == 200, f"Create failed: {response.json()}"

        # Validate LDAP bind with correct password
        auth_request = {
            "request_id": f"sip-auth-validate-{test_uid}",
            "ldap": ldap_config,
            "schema": {
                "search": {
                    "base_dn": "ou=People,{base_dn}",
                    "filter_template": "(uid={username})",
                    "scope": "subtree",
                },
                "return_attributes": ["uid", "cn", "AstEndpointId"],
            },
            "credentials": {
                "username": test_uid,
                "password": posix_password,
            },
        }

        response = client.post(
            "/api/v1/sync/auth/validate",
            json=auth_request,
            headers=api_headers,
        )
        assert response.status_code == 200, f"Auth failed: {response.json()}"
        data = response.json()
        assert data["ok"] is True
        assert data["authenticated"] is True
        assert test_uid in data["user"]["dn"]

    def test_provision_sip_user_wrong_password_bind_fails(
        self,
        client,
        api_headers,
        ldap_config,
        pjsip_schema,
        cleanup_sip_user,
        sip_test_extension,
    ):
        """LDAP bind fails with wrong password for provisioned SIP user."""
        test_uid = cleanup_sip_user

        # Create SIP user
        create_request = {
            "operation": "create",
            "request_id": f"sip-wrongpw-create-{test_uid}",
            "ldap": ldap_config,
            "schema": pjsip_schema,
            "user": {
                "username": test_uid,
                "display_name": f"SIP Wrong PW Test {sip_test_extension}",
                "extension": sip_test_extension,
                "sip_password": "haha123",
            },
            "password": "CorrectPassword789!",
        }

        response = client.post(
            "/api/v1/sync/user", json=create_request, headers=api_headers
        )
        assert response.status_code == 200

        # Attempt bind with wrong password
        auth_request = {
            "request_id": f"sip-wrongpw-validate-{test_uid}",
            "ldap": ldap_config,
            "schema": {
                "search": {
                    "base_dn": "ou=People,{base_dn}",
                    "filter_template": "(uid={username})",
                },
            },
            "credentials": {
                "username": test_uid,
                "password": "WrongPassword000!",
            },
        }

        response = client.post(
            "/api/v1/sync/auth/validate",
            json=auth_request,
            headers=api_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["ok"] is True
        assert data["authenticated"] is False
```

**Step 2: Run the tests**

Run: `just ued-test-integration`
Expected: Both new tests PASS (`test_provision_sip_user_ldap_bind_succeeds`, `test_provision_sip_user_wrong_password_bind_fails`)

**Step 3: Commit**

```bash
git add src/ued-sync/tests/integration/test_sip_provisioning.py
git commit -m "test(ued-sync): add LDAP bind auth tests for SIP users

Verifies provisioned SIP users can authenticate via LDAP bind (Layer 1)
and that wrong passwords are correctly rejected."
```

---

### Task 6: Add Update + Full Lifecycle Tests

**Files:**
- Modify: `src/ued-sync/tests/integration/test_sip_provisioning.py`

**Step 1: Add update and lifecycle test class**

Append after `TestSipLdapBindAuth`:

```python
class TestSipUserLifecycle:
    """Full CRUD lifecycle tests for SIP/PJSIP users."""

    def test_sip_user_update_preserves_pjsip_attributes(
        self,
        client,
        api_headers,
        ldap_config,
        pjsip_schema,
        cleanup_sip_user,
        sip_test_extension,
    ):
        """Updating a SIP user's display_name doesn't wipe PJSIP attributes."""
        test_uid = cleanup_sip_user
        sip_password = "haha123"

        # Create SIP user
        create_request = {
            "operation": "create",
            "request_id": f"sip-update-create-{test_uid}",
            "ldap": ldap_config,
            "schema": pjsip_schema,
            "user": {
                "username": test_uid,
                "display_name": f"Original Name {sip_test_extension}",
                "extension": sip_test_extension,
                "sip_password": sip_password,
            },
            "password": "UpdateTestPass123!",
        }

        response = client.post(
            "/api/v1/sync/user", json=create_request, headers=api_headers
        )
        assert response.status_code == 200

        # Update display_name only
        update_request = {
            "operation": "update",
            "request_id": f"sip-update-{test_uid}",
            "ldap": ldap_config,
            "schema": pjsip_schema,
            "user": {
                "username": test_uid,
                "display_name": f"Updated Name {sip_test_extension}",
                "extension": sip_test_extension,
                "sip_password": sip_password,
            },
        }

        response = client.post(
            "/api/v1/sync/user", json=update_request, headers=api_headers
        )
        assert response.status_code == 200, f"Update failed: {response.json()}"
        data = response.json()
        assert data["ok"] is True
        assert data["operation"] == "update"

        # Verify LDAP bind still works (password wasn't wiped)
        auth_request = {
            "request_id": f"sip-update-verify-{test_uid}",
            "ldap": ldap_config,
            "schema": {
                "search": {
                    "base_dn": "ou=People,{base_dn}",
                    "filter_template": "(uid={username})",
                    "scope": "subtree",
                },
                "return_attributes": ["cn", "AstEndpointId", "AstAuthType"],
            },
            "credentials": {
                "username": test_uid,
                "password": "UpdateTestPass123!",
            },
        }

        response = client.post(
            "/api/v1/sync/auth/validate",
            json=auth_request,
            headers=api_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["ok"] is True
        assert data["authenticated"] is True, "LDAP bind failed after update — password may have been wiped"

    def test_sip_user_full_lifecycle(
        self,
        client,
        api_headers,
        ldap_config,
        pjsip_schema,
        cleanup_sip_user,
        sip_test_extension,
    ):
        """Full SIP user lifecycle: create -> bind auth -> update -> bind auth -> delete."""
        test_uid = cleanup_sip_user
        posix_password = "LifecyclePass123!"

        # 1. Create
        create_request = {
            "operation": "create",
            "request_id": f"sip-lifecycle-create-{test_uid}",
            "ldap": ldap_config,
            "schema": pjsip_schema,
            "user": {
                "username": test_uid,
                "display_name": f"Lifecycle Test {sip_test_extension}",
                "extension": sip_test_extension,
                "sip_password": "haha123",
            },
            "password": posix_password,
        }

        response = client.post(
            "/api/v1/sync/user", json=create_request, headers=api_headers
        )
        assert response.status_code == 200
        assert response.json()["ok"] is True

        # 2. Bind auth — succeeds
        auth_request = {
            "request_id": f"sip-lifecycle-auth1-{test_uid}",
            "ldap": ldap_config,
            "schema": {
                "search": {
                    "base_dn": "ou=People,{base_dn}",
                    "filter_template": "(uid={username})",
                },
            },
            "credentials": {
                "username": test_uid,
                "password": posix_password,
            },
        }

        response = client.post(
            "/api/v1/sync/auth/validate",
            json=auth_request,
            headers=api_headers,
        )
        assert response.status_code == 200
        assert response.json()["authenticated"] is True

        # 3. Update
        update_request = {
            "operation": "update",
            "request_id": f"sip-lifecycle-update-{test_uid}",
            "ldap": ldap_config,
            "schema": pjsip_schema,
            "user": {
                "username": test_uid,
                "display_name": f"Updated Lifecycle {sip_test_extension}",
                "extension": sip_test_extension,
                "sip_password": "haha123",
            },
        }

        response = client.post(
            "/api/v1/sync/user", json=update_request, headers=api_headers
        )
        assert response.status_code == 200
        assert response.json()["ok"] is True

        # 4. Bind auth again — still succeeds after update
        auth_request["request_id"] = f"sip-lifecycle-auth2-{test_uid}"
        response = client.post(
            "/api/v1/sync/auth/validate",
            json=auth_request,
            headers=api_headers,
        )
        assert response.status_code == 200
        assert response.json()["authenticated"] is True

        # 5. Delete
        delete_request = {
            "operation": "delete",
            "request_id": f"sip-lifecycle-delete-{test_uid}",
            "ldap": ldap_config,
            "schema": pjsip_schema,
            "user": {
                "username": test_uid,
                "display_name": "Cleanup",
                "extension": sip_test_extension,
                "sip_password": "unused",
            },
        }

        response = client.post(
            "/api/v1/sync/user", json=delete_request, headers=api_headers
        )
        assert response.status_code == 200
        assert response.json()["ok"] is True

        # 6. Bind auth — fails (user deleted)
        auth_request["request_id"] = f"sip-lifecycle-auth3-{test_uid}"
        response = client.post(
            "/api/v1/sync/auth/validate",
            json=auth_request,
            headers=api_headers,
        )
        assert response.status_code == 200
        assert response.json()["authenticated"] is False
```

**Step 2: Run all integration tests**

Run: `just ued-test-integration`
Expected: All 5 SIP tests PASS, plus existing integration tests still pass.

**Step 3: Commit**

```bash
git add src/ued-sync/tests/integration/test_sip_provisioning.py
git commit -m "test(ued-sync): add SIP user update + full lifecycle integration tests

Tests that updates preserve PJSIP attributes and full create->auth->
update->auth->delete round-trip works for combined posixAccount+PJSIP entries."
```

---

### Task 7: Final Verification and Docs Update

**Files:**
- Modify: `docs/plans/2026-02-19-sip-pjsip-provisioning-tests-design.md` (mark as implemented)

**Step 1: Run the full UED Sync test suite**

Run: `just ued-test && just ued-test-integration`
Expected: All unit tests pass (mocked LDAP, should be unaffected). All integration tests pass including new SIP tests.

**Step 2: Run main backend tests too (regression check)**

Run: `just test`
Expected: All backend tests pass (no regressions).

**Step 3: Update design doc status**

Change line 4 from `**Status:** Approved` to `**Status:** Implemented`.

**Step 4: Final commit**

```bash
git add docs/plans/2026-02-19-sip-pjsip-provisioning-tests-design.md
git commit -m "docs: mark SIP/PJSIP provisioning tests design as implemented"
```

---

## Summary of Changes

| File | Action | Purpose |
|------|--------|---------|
| `deploy/dev/ldap/asterisk-pjsip.schema` | Create | PJSIP LDAP schema (3 objectClasses, ~20 attributes) |
| `deploy/dev/docker-compose.yml` | Modify (1 line) | Mount schema into OpenLDAP container |
| `src/ued-sync/tests/integration/test_sip_provisioning.py` | Create | 5 integration tests (provisioning + bind auth + lifecycle) |
| `docs/plans/2026-02-19-sip-pjsip-provisioning-tests-design.md` | Modify (1 line) | Status: Approved → Implemented |

**Total commits:** 5
**Backend code changes:** 0 (UED Sync is already schema-agnostic)
**One-time infra action:** `just reset && just up` (reload OpenLDAP with new schema)
