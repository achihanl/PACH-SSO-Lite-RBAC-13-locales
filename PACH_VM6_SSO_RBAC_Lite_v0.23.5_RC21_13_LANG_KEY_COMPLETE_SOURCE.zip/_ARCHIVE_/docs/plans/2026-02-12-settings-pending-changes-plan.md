# Settings Pending Changes — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add a pending changes drawer + sticky bottom save bar to the Settings page, replacing the opaque `Set<string>` dirty tracking with a rich `Map<string, PendingChange>` that supports per-field diffing and granular revert.

**Architecture:** A custom `usePendingChanges` hook replaces inline state management. Two new feature components (`BottomSaveBar`, `PendingChangesDrawer`) are added as children of `SettingsManagementPage`. Section components remain unchanged — same props interface. No new primitives needed.

**Tech Stack:** React 19, TanStack Query, TypeScript, Tailwind CSS 4, `@azblink/ui` primitives, Playwright (E2E tests)

**Design doc:** `docs/plans/2026-02-12-settings-pending-changes-design.md`

---

## Task 1: Add `PendingChange` Type

**Files:**
- Modify: `src/frontend/src/types/settings.ts` (add after line 139)

**Step 1: Add the PendingChange type**

Append to the end of `settings.ts`:

```typescript
// ── Pending Change Tracking ──────────────────────────────────────
/** Tracks a single field change with before/after values for diffing and revert. */
export interface PendingChange {
  /** Composite key: "section.field" (e.g., "ldap.serverUrl") */
  id: string;
  /** Settings section name (e.g., "ldap", "email", "security") */
  section: string;
  /** Field key within the section (e.g., "serverUrl") */
  field: string;
  /** Human-readable label (e.g., "Server URL") */
  label: string;
  /** Original value from server — revert target */
  previousValue: unknown;
  /** Current form value */
  currentValue: unknown;
  /** Timestamp (Date.now()) of last change — used for sort order */
  timestamp: number;
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/types/settings.ts
git commit -m "feat(settings): add PendingChange type for granular change tracking"
```

---

## Task 2: Create Field Labels Constant Map

**Files:**
- Create: `src/frontend/src/components/features/settings/constants/field-labels.ts`

**Step 1: Create the field labels map**

This maps every editable `section.field` to a human-readable label used in the drawer.

```typescript
/**
 * Human-readable labels for settings fields.
 * - Used by PendingChangesDrawer to display change descriptions
 * - Keys match the section/field structure of AllSettings
 * - Only includes the 5 editable sections (excludes System Info, API Keys, Admins, Danger Zone)
 */

/** Section display names for group headers in the drawer. */
export const SECTION_LABELS: Record<string, string> = {
  ldap: 'LDAP Connection',
  email: 'Email / SMTP',
  security: 'Security',
  audit: 'Audit & Logging',
  branding: 'Branding',
};

/** Per-field display labels keyed by section.field. */
export const FIELD_LABELS: Record<string, Record<string, string>> = {
  ldap: {
    serverUrl: 'Server URL',
    baseDn: 'Base DN',
    bindDn: 'Bind DN',
    bindPassword: 'Bind Password',
    userSearchBase: 'User Search Base',
    groupSearchBase: 'Group Search Base',
    verifySsl: 'Verify SSL',
    connectionPooling: 'Connection Pooling',
  },
  email: {
    smtpHost: 'SMTP Host',
    smtpPort: 'SMTP Port',
    username: 'Username',
    password: 'Password',
    fromAddress: 'From Address',
    fromName: 'From Name',
    useTls: 'Use TLS',
  },
  security: {
    sessionTimeoutMinutes: 'Session Timeout',
    maxLoginAttempts: 'Max Login Attempts',
    requireMfa: 'Require MFA',
    ipAllowlist: 'IP Allowlist',
    auditApiRequests: 'Audit API Requests',
  },
  audit: {
    retentionPolicy: 'Retention Policy',
    siemExport: 'SIEM Export',
    includeUserDetails: 'Include User Details',
  },
  branding: {
    companyName: 'Company Name',
    supportEmail: 'Support Email',
    qrEmailFooter: 'QR Email Footer',
    includeLogoInEmails: 'Include Logo in Emails',
  },
};

/** Fields that contain sensitive values — display masked in the drawer. */
export const SENSITIVE_FIELDS = new Set([
  'ldap.bindPassword',
  'email.password',
]);

/**
 * Resolve a human-readable label for a section.field path.
 * Falls back to the raw field key if not found.
 */
export function getFieldLabel(section: string, field: string): string {
  return FIELD_LABELS[section]?.[field] ?? field;
}

/**
 * Resolve a section display name.
 * Falls back to the raw section key (capitalized) if not found.
 */
export function getSectionLabel(section: string): string {
  return SECTION_LABELS[section] ?? section.charAt(0).toUpperCase() + section.slice(1);
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/constants/field-labels.ts
git commit -m "feat(settings): add field-labels constant map for pending changes display"
```

---

## Task 3: Create `usePendingChanges` Hook

**Files:**
- Create: `src/frontend/src/components/features/settings/hooks/usePendingChanges.ts`

**Step 1: Create the hook**

This replaces the inline `useState<Set<string>>` + `updateField` callback in `SettingsManagementPage`.

```typescript
/**
 * Manages pending (unsaved) settings changes with per-field tracking.
 * - Replaces the Set<string> dirty tracking with Map<string, PendingChange>
 * - Supports per-field revert, auto-removal when edited back to original, grouped display
 * - Section components remain unchanged — same updateField(section, key, value) signature
 */

import { useState, useCallback, useMemo } from 'react';
import type { AllSettings, PendingChange } from '@/types/settings';
import { getFieldLabel, SENSITIVE_FIELDS } from '../constants/field-labels';

/** Return type for the usePendingChanges hook. */
export interface UsePendingChangesReturn {
  /** Current form state (replaces the old useState<AllSettings>). */
  settings: AllSettings;
  /** Map of all pending changes keyed by "section.field". */
  pendingChanges: Map<string, PendingChange>;
  /** True when at least one field is dirty. */
  hasPendingChanges: boolean;
  /** Count of dirty fields. */
  pendingCount: number;
  /** Changes grouped by section for drawer display (only sections with changes). */
  changesBySection: Record<string, PendingChange[]>;
  /** Update a field value — same signature as current updateField callback. */
  updateField: (section: string, key: string, value: unknown) => void;
  /** Revert a single field to its server value. */
  revertField: (section: string, key: string) => void;
  /** Revert all fields to server values (discard all). */
  revertAll: () => void;
  /** Build a sparse PATCH body containing only dirty fields. */
  getSavePatch: () => Record<string, Record<string, unknown>>;
  /** Clear all pending changes (call on save success). */
  clearAll: () => void;
  /** Reset everything when initialSettings changes (e.g., after query refetch). */
  resetToInitial: (newInitial: AllSettings) => void;
  /** Whether a field contains a sensitive value (passwords). */
  isSensitive: (section: string, field: string) => boolean;
}

/** Compare two values to determine if a field is dirty. */
function valuesEqual(a: unknown, b: unknown): boolean {
  if (typeof a === 'string' && typeof b === 'string') {
    return a.trim() === b.trim();
  }
  return a === b;
}

export function usePendingChanges(initialSettings: AllSettings): UsePendingChangesReturn {
  const [settings, setSettings] = useState<AllSettings>(initialSettings);
  const [changes, setChanges] = useState<Map<string, PendingChange>>(new Map());

  const updateField = useCallback(
    (section: string, key: string, value: unknown) => {
      // Update form state
      setSettings((prev) => ({
        ...prev,
        [section]: { ...prev[section as keyof AllSettings], [key]: value },
      }));

      // Update pending changes map
      setChanges((prev) => {
        const id = `${section}.${key}`;
        const original = (initialSettings as Record<string, Record<string, unknown>>)[section]?.[key];

        // If edited back to original → remove from pending changes
        if (valuesEqual(value, original)) {
          if (!prev.has(id)) return prev;
          const next = new Map(prev);
          next.delete(id);
          return next;
        }

        const next = new Map(prev);
        next.set(id, {
          id,
          section,
          field: key,
          label: getFieldLabel(section, key),
          previousValue: original,
          currentValue: value,
          timestamp: Date.now(),
        });
        return next;
      });
    },
    [initialSettings],
  );

  const revertField = useCallback(
    (section: string, key: string) => {
      const id = `${section}.${key}`;
      const original = (initialSettings as Record<string, Record<string, unknown>>)[section]?.[key];

      // Restore form value
      setSettings((prev) => ({
        ...prev,
        [section]: { ...prev[section as keyof AllSettings], [key]: original },
      }));

      // Remove from pending changes
      setChanges((prev) => {
        if (!prev.has(id)) return prev;
        const next = new Map(prev);
        next.delete(id);
        return next;
      });
    },
    [initialSettings],
  );

  const revertAll = useCallback(() => {
    setSettings(initialSettings);
    setChanges(new Map());
  }, [initialSettings]);

  const getSavePatch = useCallback((): Record<string, Record<string, unknown>> => {
    const body: Record<string, Record<string, unknown>> = {};
    for (const change of changes.values()) {
      if (!body[change.section]) body[change.section] = {};
      body[change.section][change.field] = change.currentValue;
    }
    return body;
  }, [changes]);

  const clearAll = useCallback(() => {
    setChanges(new Map());
  }, []);

  const resetToInitial = useCallback((newInitial: AllSettings) => {
    setSettings(newInitial);
    setChanges(new Map());
  }, []);

  const isSensitive = useCallback((section: string, field: string): boolean => {
    return SENSITIVE_FIELDS.has(`${section}.${field}`);
  }, []);

  const hasPendingChanges = changes.size > 0;
  const pendingCount = changes.size;

  const changesBySection = useMemo(() => {
    const grouped: Record<string, PendingChange[]> = {};
    for (const change of changes.values()) {
      if (!grouped[change.section]) grouped[change.section] = [];
      grouped[change.section].push(change);
    }
    // Sort each group by timestamp descending (most recent first)
    for (const section of Object.keys(grouped)) {
      grouped[section].sort((a, b) => b.timestamp - a.timestamp);
    }
    return grouped;
  }, [changes]);

  return {
    settings,
    pendingChanges: changes,
    hasPendingChanges,
    pendingCount,
    changesBySection,
    updateField,
    revertField,
    revertAll,
    getSavePatch,
    clearAll,
    resetToInitial,
    isSensitive,
  };
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/hooks/usePendingChanges.ts
git commit -m "feat(settings): add usePendingChanges hook — Map-based change tracking with per-field revert"
```

---

## Task 4: Create `BottomSaveBar` Component

**Files:**
- Create: `src/frontend/src/components/features/settings/BottomSaveBar.tsx`

**Step 1: Create the component**

```typescript
/**
 * Sticky bottom save bar for the Settings page.
 * - Appears when there are unsaved changes (slides up from bottom)
 * - Shows pending change count (clickable to open drawer)
 * - Save All + Discard All buttons
 * - Respects prefers-reduced-motion for slide animation
 */

import { Button } from '@azblink/ui';
import { Save, RotateCcw } from 'lucide-react';

interface BottomSaveBarProps {
  /** Number of unsaved changes. Bar is hidden when 0. */
  pendingCount: number;
  /** Whether a save is currently in progress. */
  isSaving: boolean;
  /** Callback to open the pending changes drawer. */
  onViewChanges: () => void;
  /** Callback to save all pending changes. */
  onSave: () => void;
  /** Callback to discard all pending changes. */
  onDiscard: () => void;
}

export function BottomSaveBar({
  pendingCount,
  isSaving,
  onViewChanges,
  onSave,
  onDiscard,
}: BottomSaveBarProps) {
  if (pendingCount === 0) return null;

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-20 pointer-events-none"
      data-testid="settings-bottom-save-bar"
    >
      <div className="pointer-events-auto ml-16 lg:ml-64 transition-[margin] duration-200">
        <div
          className="mx-auto max-w-[1200px] px-6 animate-in slide-in-from-bottom duration-250
                     motion-reduce:animate-none motion-reduce:transition-none"
        >
          <div
            className="flex items-center justify-between h-14 px-4
                       border-t border-x rounded-t-lg
                       border-[var(--color-border-subtle)]
                       bg-[var(--color-bg-primary)]/90 backdrop-blur-sm"
          >
            {/* Left: change count (clickable) */}
            <button
              type="button"
              onClick={onViewChanges}
              className="flex items-center gap-2 text-sm text-amber-500
                         hover:underline focus-visible:outline-none
                         focus-visible:ring-2 focus-visible:ring-amber-500/50
                         focus-visible:ring-offset-2 rounded-sm cursor-pointer"
              aria-label={`View ${pendingCount} unsaved change${pendingCount === 1 ? '' : 's'}`}
              data-testid="settings-bottom-bar-view-changes"
            >
              <span className="h-2 w-2 rounded-full bg-amber-500 shrink-0" aria-hidden="true" />
              <span>
                <span className="font-medium">{pendingCount}</span>
                {' '}
                <span className="hidden sm:inline">unsaved change{pendingCount === 1 ? '' : 's'}</span>
                <span className="sm:hidden">change{pendingCount === 1 ? '' : 's'}</span>
              </span>
            </button>

            {/* Right: action buttons */}
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={onDiscard}
                disabled={isSaving}
                data-testid="settings-bottom-bar-discard"
              >
                <RotateCcw className="h-4 w-4 sm:mr-1.5" aria-hidden="true" />
                <span className="hidden sm:inline">Discard All</span>
              </Button>
              <Button
                size="sm"
                onClick={onSave}
                disabled={isSaving}
                loading={isSaving}
                leftIcon={<Save className="h-4 w-4" />}
                data-testid="settings-bottom-bar-save"
              >
                Save All
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/BottomSaveBar.tsx
git commit -m "feat(settings): add BottomSaveBar — sticky bottom save/discard bar with drawer trigger"
```

---

## Task 5: Create `PendingChangesDrawer` Component

**Files:**
- Create: `src/frontend/src/components/features/settings/PendingChangesDrawer.tsx`

**Step 1: Create the component**

```typescript
/**
 * Slide-out drawer showing all pending settings changes.
 * - Groups changes by section with human-readable labels
 * - Per-item revert button restores individual field values
 * - Footer has Save All + Discard All buttons
 * - Keyboard accessible: Escape to close, Tab to cycle, focus trap
 * - Respects prefers-reduced-motion
 */

import { useEffect, useRef, useCallback } from 'react';
import { Button } from '@azblink/ui';
import { X, Undo2, Save, RotateCcw } from 'lucide-react';
import type { PendingChange } from '@/types/settings';
import { getSectionLabel, SENSITIVE_FIELDS } from './constants/field-labels';

interface PendingChangesDrawerProps {
  /** Whether the drawer is open. */
  isOpen: boolean;
  /** Callback to close the drawer. */
  onClose: () => void;
  /** Changes grouped by section key. */
  changesBySection: Record<string, PendingChange[]>;
  /** Total pending change count. */
  pendingCount: number;
  /** Revert a single field. */
  onRevertField: (section: string, field: string) => void;
  /** Discard all changes. */
  onDiscardAll: () => void;
  /** Save all changes. */
  onSave: () => void;
  /** Whether a save is in progress. */
  isSaving: boolean;
}

/** Format a value for display in the drawer. */
function formatValue(value: unknown, section: string, field: string): string {
  if (SENSITIVE_FIELDS.has(`${section}.${field}`)) {
    return '•••••••';
  }
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (value === null || value === undefined) return '(empty)';
  if (typeof value === 'number') return String(value);
  const str = String(value);
  return str.length === 0 ? '(empty)' : str;
}

export function PendingChangesDrawer({
  isOpen,
  onClose,
  changesBySection,
  pendingCount,
  onRevertField,
  onDiscardAll,
  onSave,
  isSaving,
}: PendingChangesDrawerProps) {
  const drawerRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  // Focus close button when drawer opens
  useEffect(() => {
    if (isOpen) {
      closeButtonRef.current?.focus();
    }
  }, [isOpen]);

  // Escape key closes drawer
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    },
    [onClose],
  );

  // Close drawer if all changes are reverted
  useEffect(() => {
    if (isOpen && pendingCount === 0) {
      onClose();
    }
  }, [isOpen, pendingCount, onClose]);

  // Section order for consistent display
  const sectionOrder = ['ldap', 'email', 'security', 'audit', 'branding'];
  const orderedSections = sectionOrder.filter((s) => changesBySection[s]?.length > 0);

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/20 transition-opacity duration-200
                     motion-reduce:transition-none"
          onClick={onClose}
          aria-hidden="true"
          data-testid="settings-drawer-backdrop"
        />
      )}

      {/* Drawer panel */}
      <div
        ref={drawerRef}
        role="dialog"
        aria-label="Pending changes"
        aria-modal="true"
        onKeyDown={handleKeyDown}
        className={`
          fixed top-14 right-0 bottom-0 z-50
          w-full sm:w-[400px]
          flex flex-col
          bg-[var(--color-bg-primary)] border-l border-[var(--color-border-subtle)]
          shadow-xl
          transition-transform duration-250 ease-out
          motion-reduce:transition-none
          ${isOpen ? 'translate-x-0' : 'translate-x-full'}
        `}
        data-testid="settings-pending-changes-drawer"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--color-border-subtle)]">
          <h2 className="text-sm font-semibold text-text">
            Pending Changes
            <span className="ml-1.5 text-xs font-medium text-amber-500">({pendingCount})</span>
          </h2>
          <button
            ref={closeButtonRef}
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-md text-[var(--color-text-muted)]
                       hover:text-text hover:bg-[var(--color-bg-secondary)]
                       focus-visible:outline-none focus-visible:ring-2
                       focus-visible:ring-[var(--color-ring)]"
            aria-label="Close pending changes"
            data-testid="settings-drawer-close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Change list (scrollable) */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6" aria-live="polite">
          {orderedSections.map((sectionKey) => (
            <div key={sectionKey}>
              {/* Section heading */}
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--color-text-muted)] mb-3">
                {getSectionLabel(sectionKey)}
              </h3>

              {/* Change cards */}
              <div className="space-y-2">
                {changesBySection[sectionKey].map((change) => (
                  <div
                    key={change.id}
                    className="rounded-lg border border-[var(--color-border-subtle)]
                               bg-[var(--color-bg-secondary)] p-3
                               animate-in fade-in duration-200
                               motion-reduce:animate-none"
                    data-testid={`settings-change-card-${change.id}`}
                  >
                    {/* Field label + revert button */}
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <span className="text-sm font-medium text-text">{change.label}</span>
                      <button
                        type="button"
                        onClick={() => onRevertField(change.section, change.field)}
                        className="shrink-0 flex items-center gap-1 text-xs text-[var(--color-text-muted)]
                                   hover:text-text rounded-md px-1.5 py-0.5
                                   hover:bg-[var(--color-bg-tertiary)]
                                   focus-visible:outline-none focus-visible:ring-2
                                   focus-visible:ring-[var(--color-ring)]"
                        aria-label={`Revert ${change.label}`}
                        data-testid={`settings-revert-${change.id}`}
                      >
                        <Undo2 className="h-3 w-3" />
                        <span>Revert</span>
                      </button>
                    </div>

                    {/* Old → New values */}
                    <div className="text-xs space-y-0.5">
                      <div className="text-[var(--color-text-muted)] line-through">
                        {formatValue(change.previousValue, change.section, change.field)}
                      </div>
                      <div className="text-text">
                        <span className="text-[var(--color-text-muted)] mr-1" aria-hidden="true">→</span>
                        {formatValue(change.currentValue, change.section, change.field)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-[var(--color-border-subtle)]">
          <Button
            variant="outline"
            size="sm"
            onClick={onDiscardAll}
            disabled={isSaving}
            data-testid="settings-drawer-discard-all"
          >
            <RotateCcw className="h-4 w-4 mr-1.5" aria-hidden="true" />
            Discard All
          </Button>
          <Button
            size="sm"
            onClick={onSave}
            disabled={isSaving}
            loading={isSaving}
            leftIcon={<Save className="h-4 w-4" />}
            data-testid="settings-drawer-save-all"
          >
            Save All
          </Button>
        </div>
      </div>
    </>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/settings/PendingChangesDrawer.tsx
git commit -m "feat(settings): add PendingChangesDrawer — grouped change list with per-item revert"
```

---

## Task 6: Wire Into SettingsManagementPage

**Files:**
- Modify: `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`

This is the integration step. We replace the inline state management with the hook and add the two new components.

**Step 1: Update imports**

Replace the existing imports block (lines 10–38). Add the new hook and components; remove `useState` (still need `useEffect`, `useCallback` for connection test handlers).

Add these imports:
```typescript
import { usePendingChanges } from './hooks/usePendingChanges';
import { BottomSaveBar } from './BottomSaveBar';
import { PendingChangesDrawer } from './PendingChangesDrawer';
```

**Step 2: Replace state management**

Remove these lines (approximately lines 45–61):
```typescript
// REMOVE: old dirty tracking
const [settings, setSettings] = useState<AllSettings>(initialSettings);
const [dirtyFields, setDirtyFields] = useState<Set<string>>(new Set());
// ... (hasDirtyFields derived)
const updateField = useCallback((section: string, key: string, value: unknown) => {
  // ...
}, []);
```

Replace with:
```typescript
// Pending changes — replaces Set<string> dirty tracking
const {
  settings,
  pendingChanges,
  hasPendingChanges,
  pendingCount,
  changesBySection,
  updateField,
  revertField,
  revertAll,
  getSavePatch,
  clearAll,
  resetToInitial,
} = usePendingChanges(initialSettings);

// Drawer visibility
const [drawerOpen, setDrawerOpen] = useState(false);
```

**Step 3: Update saveMutation**

Replace the `mutationFn` (approximately lines 71–88):

```typescript
const saveMutation = useMutation({
  mutationFn: () => patchSettings(getSavePatch()),
  onSuccess: () => {
    clearAll();
    setDrawerOpen(false);
    queryClient.invalidateQueries({ queryKey: queryKeys.settings });
    toast.success('Settings saved');
  },
  onError: (err: Error) => {
    toast.error(`Save failed: ${err.message}`);
  },
});
```

**Step 4: Update beforeunload useEffect**

Replace `dirtyFields.size` reference (approximately lines 141–147):

```typescript
useEffect(() => {
  const handler = (e: BeforeUnloadEvent) => {
    if (hasPendingChanges) e.preventDefault();
  };
  window.addEventListener('beforeunload', handler);
  return () => window.removeEventListener('beforeunload', handler);
}, [hasPendingChanges]);
```

**Step 5: Update resetToInitial on query data change**

If there's a `useEffect` that resets state when `initialSettings` changes, replace it:

```typescript
useEffect(() => {
  resetToInitial(initialSettings);
}, [initialSettings, resetToInitial]);
```

**Step 6: Update SettingsNav dirtyCount prop**

Change from `dirtyCount={dirtyFields.size}` to:
```typescript
<SettingsNav dirtyCount={pendingCount} /* ...other props... */ />
```

**Step 7: Update Save button disabled condition**

Change from `disabled={!hasDirtyFields || saveMutation.isPending}` to:
```typescript
disabled={!hasPendingChanges || saveMutation.isPending}
```

**Step 8: Add BottomSaveBar and PendingChangesDrawer**

After the main content grid (after the closing `</div>` of the sections grid, before the AlertDialog), add:

```tsx
{/* Sticky bottom save bar */}
<BottomSaveBar
  pendingCount={pendingCount}
  isSaving={saveMutation.isPending}
  onViewChanges={() => setDrawerOpen(true)}
  onSave={() => saveMutation.mutate()}
  onDiscard={revertAll}
/>

{/* Pending changes drawer */}
<PendingChangesDrawer
  isOpen={drawerOpen}
  onClose={() => setDrawerOpen(false)}
  changesBySection={changesBySection}
  pendingCount={pendingCount}
  onRevertField={revertField}
  onDiscardAll={revertAll}
  onSave={() => saveMutation.mutate()}
  isSaving={saveMutation.isPending}
/>
```

**Step 9: Verify manually**

```bash
# The dev server should hot-reload (Vite HMR)
# Open http://localhost:8081/settings
# Test:
# 1. Change a field → bottom bar appears
# 2. Click "N unsaved changes" → drawer opens
# 3. Click Revert on one item → field restores, card disappears
# 4. Click Save All → changes persist, bar + drawer disappear
# 5. Click Discard All → all fields restore
```

**Step 10: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): wire usePendingChanges + BottomSaveBar + PendingChangesDrawer into page"
```

---

## Task 7: Add Route Guard for Navigation

**Files:**
- Modify: `src/frontend/src/components/features/settings/SettingsManagementPage.tsx` (add useBlocker)

**Docs to check:** TanStack Router `useBlocker` API — query Context7 for current usage.

**Step 1: Add route blocker**

Add this inside the component, after the `usePendingChanges` call:

```typescript
import { useBlocker } from '@tanstack/react-router';

// Block navigation when there are unsaved changes
useBlocker({
  condition: hasPendingChanges,
  blockerFn: () =>
    window.confirm(
      `You have ${pendingCount} unsaved change${pendingCount === 1 ? '' : 's'}. Leave without saving?`,
    ),
});
```

**Step 2: Verify**

```bash
# Open http://localhost:8081/settings
# Change a field
# Click a sidebar nav link (e.g., Users)
# Expected: browser confirm dialog appears
# Click Cancel → stays on settings
# Click OK → navigates away
```

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "feat(settings): add route guard warning when navigating with unsaved changes"
```

---

## Task 8: E2E Tests — Pending Changes Feature

**Files:**
- Create: `src/frontend/e2e/settings-pending-changes.spec.ts`

**Docs to check:** Existing E2E patterns in `src/frontend/e2e/dashboard.spec.ts` and `src/frontend/e2e/resizable-panel.spec.ts`.

**Step 1: Write E2E test suite**

```typescript
/**
 * E2E tests for the Settings pending changes feature.
 * - Bottom save bar visibility and interaction
 * - Pending changes drawer open/close, per-item revert
 * - Save and discard flows
 */

import { test, expect } from '@playwright/test';

test.describe('Settings Pending Changes', () => {
  test.beforeEach(async ({ page }) => {
    // Navigate to settings page (login handled by auth setup if needed)
    await page.goto('/settings');
    await expect(page.getByTestId('settings-section-system-info')).toBeVisible();
  });

  test('bottom save bar is hidden when no changes exist', async ({ page }) => {
    await expect(page.getByTestId('settings-bottom-save-bar')).not.toBeVisible();
  });

  test('bottom save bar appears when a field is changed', async ({ page }) => {
    // Change the LDAP server URL
    const input = page.locator('#ldap-server-url');
    await input.clear();
    await input.fill('ldap://changed:389');

    // Bottom bar should appear
    await expect(page.getByTestId('settings-bottom-save-bar')).toBeVisible();
    await expect(page.getByTestId('settings-bottom-bar-view-changes')).toContainText('1');
  });

  test('clicking "unsaved changes" opens the drawer', async ({ page }) => {
    // Make a change
    const input = page.locator('#ldap-server-url');
    await input.clear();
    await input.fill('ldap://changed:389');

    // Click the change count link
    await page.getByTestId('settings-bottom-bar-view-changes').click();

    // Drawer should be visible
    await expect(page.getByTestId('settings-pending-changes-drawer')).toBeVisible();
    await expect(page.getByTestId('settings-change-card-ldap.serverUrl')).toBeVisible();
  });

  test('per-item revert restores field value', async ({ page }) => {
    const input = page.locator('#ldap-server-url');
    const originalValue = await input.inputValue();

    // Change the field
    await input.clear();
    await input.fill('ldap://changed:389');

    // Open drawer and revert
    await page.getByTestId('settings-bottom-bar-view-changes').click();
    await page.getByTestId('settings-revert-ldap.serverUrl').click();

    // Field should be restored
    await expect(input).toHaveValue(originalValue);

    // Drawer should close (no more changes)
    await expect(page.getByTestId('settings-pending-changes-drawer')).not.toBeVisible();
    await expect(page.getByTestId('settings-bottom-save-bar')).not.toBeVisible();
  });

  test('discard all reverts all changes', async ({ page }) => {
    const ldapInput = page.locator('#ldap-server-url');
    const originalLdap = await ldapInput.inputValue();

    // Change two fields
    await ldapInput.clear();
    await ldapInput.fill('ldap://changed:389');

    // Open drawer and discard all
    await page.getByTestId('settings-bottom-bar-view-changes').click();
    await page.getByTestId('settings-drawer-discard-all').click();

    // Field restored, drawer + bar hidden
    await expect(ldapInput).toHaveValue(originalLdap);
    await expect(page.getByTestId('settings-pending-changes-drawer')).not.toBeVisible();
    await expect(page.getByTestId('settings-bottom-save-bar')).not.toBeVisible();
  });

  test('drawer closes on Escape key', async ({ page }) => {
    // Make a change and open drawer
    const input = page.locator('#ldap-server-url');
    await input.clear();
    await input.fill('ldap://changed:389');
    await page.getByTestId('settings-bottom-bar-view-changes').click();

    // Press Escape
    await page.keyboard.press('Escape');

    // Drawer closes but bottom bar stays (changes not discarded)
    await expect(page.getByTestId('settings-pending-changes-drawer')).not.toBeVisible();
    await expect(page.getByTestId('settings-bottom-save-bar')).toBeVisible();
  });

  test('drawer closes on backdrop click', async ({ page }) => {
    // Make a change and open drawer
    const input = page.locator('#ldap-server-url');
    await input.clear();
    await input.fill('ldap://changed:389');
    await page.getByTestId('settings-bottom-bar-view-changes').click();

    // Click backdrop
    await page.getByTestId('settings-drawer-backdrop').click();

    // Drawer closes, bottom bar stays
    await expect(page.getByTestId('settings-pending-changes-drawer')).not.toBeVisible();
    await expect(page.getByTestId('settings-bottom-save-bar')).toBeVisible();
  });

  test('editing field back to original removes it from pending changes', async ({ page }) => {
    const input = page.locator('#ldap-server-url');
    const originalValue = await input.inputValue();

    // Change it
    await input.clear();
    await input.fill('ldap://changed:389');
    await expect(page.getByTestId('settings-bottom-save-bar')).toBeVisible();

    // Change it back
    await input.clear();
    await input.fill(originalValue);

    // Should auto-remove — bar disappears
    await expect(page.getByTestId('settings-bottom-save-bar')).not.toBeVisible();
  });

  test('changes are grouped by section in drawer', async ({ page }) => {
    // Change one field in LDAP section
    const ldapInput = page.locator('#ldap-server-url');
    await ldapInput.clear();
    await ldapInput.fill('ldap://changed:389');

    // Scroll down and change a security toggle
    await page.getByTestId('settings-section-security').scrollIntoViewIfNeeded();
    // Toggle a security checkbox/toggle (adjust selector based on actual implementation)

    // Open drawer
    await page.getByTestId('settings-bottom-bar-view-changes').click();

    // LDAP section should be visible in drawer
    await expect(page.getByTestId('settings-pending-changes-drawer')).toContainText('LDAP Connection');
  });
});
```

**Step 2: Run E2E tests**

```bash
cd src/frontend && npx playwright test e2e/settings-pending-changes.spec.ts --headed
```

Expected: All tests pass. If any fail, fix the underlying component code before proceeding.

**Step 3: Commit**

```bash
git add src/frontend/e2e/settings-pending-changes.spec.ts
git commit -m "test(settings): add E2E tests for pending changes — bar, drawer, revert, discard"
```

---

## Summary

| Task | Files | Estimated Time |
|------|-------|---------------|
| 1. PendingChange type | Modify `types/settings.ts` | 2 min |
| 2. Field labels map | Create `constants/field-labels.ts` | 3 min |
| 3. usePendingChanges hook | Create `hooks/usePendingChanges.ts` | 5 min |
| 4. BottomSaveBar | Create `BottomSaveBar.tsx` | 5 min |
| 5. PendingChangesDrawer | Create `PendingChangesDrawer.tsx` | 5 min |
| 6. Wire into page | Modify `SettingsManagementPage.tsx` | 10 min |
| 7. Route guard | Modify `SettingsManagementPage.tsx` | 3 min |
| 8. E2E tests | Create `settings-pending-changes.spec.ts` | 10 min |

**Total: ~43 min, 8 commits, 4 new files, 2 modified files**

### Dependencies

```
Task 1 ──┐
Task 2 ──┼──→ Task 3 ──┐
         │              ├──→ Task 6 ──→ Task 7
Task 4 ──┘              │
Task 5 ──────────────────┘
                         └──→ Task 8
```

Tasks 1, 2, 4, 5 can be parallelized. Task 3 depends on 1+2. Task 6 depends on 3+4+5. Tasks 7 and 8 depend on 6.
