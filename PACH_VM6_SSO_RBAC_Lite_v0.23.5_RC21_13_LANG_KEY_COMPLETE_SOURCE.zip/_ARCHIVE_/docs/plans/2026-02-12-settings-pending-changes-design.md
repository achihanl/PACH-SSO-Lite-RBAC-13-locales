# Settings Pending Changes — Design Document

> **Date:** 2026-02-12
> **Status:** Approved
> **Scope:** Settings page change tracking, sticky save bar, pending changes drawer

## Problem Statement

The settings page has three UX pain points:

1. **Save button is far from edits** — Fixed at page top; users editing sections 8/9 must scroll up to save
2. **"N unsaved" is opaque** — Sidebar shows count but not *which* fields or *what* changed
3. **No granular undo** — Only "Save All" or "Reset to Defaults"; can't revert one specific field

## Solution Overview

Two new visual components backed by a richer change-tracking data model:

| Problem | Solution |
|---------|----------|
| Save button far from edits | **Sticky bottom bar** appears when dirty, has Save + Discard |
| "N unsaved" is opaque | **Pending changes drawer** shows each field with old→new values, grouped by section |
| No granular undo | **Per-item revert button** on each change card restores that single field |
| Tracking architecture | **`usePendingChanges` hook** with `Map<string, PendingChange>` replaces `Set<string>` |

## 1. Change Tracking Data Model

### Current → Proposed

```typescript
// CURRENT — only knows THAT something changed
dirtyFields: Set<string>  // e.g. {"ldap.serverUrl", "security.requireMfa"}

// PROPOSED — knows WHAT changed, with history
type PendingChange = {
  id: string;               // unique ID (e.g., "ldap.serverUrl")
  section: string;           // "ldap"
  field: string;             // "serverUrl"
  label: string;             // "Server URL" (human-readable)
  previousValue: unknown;    // value from server (restore target)
  currentValue: unknown;     // current form value
  timestamp: number;         // Date.now() when changed
};

// Map keyed by "section.field" for O(1) lookup
pendingChanges: Map<string, PendingChange>
```

### Key Behaviors

- **First edit** of a field → creates a `PendingChange`, capturing `previousValue` from `initialSettings`
- **Subsequent edits** to same field → updates `currentValue` and `timestamp` only (preserves original `previousValue`)
- **Revert one field** → sets form value back to `previousValue`, removes entry from Map
- **Edit back to original value** → auto-removes the entry (no longer dirty)
- **Save All** → PATCH all entries, clear Map on success
- **Discard All** → restore all `previousValue`s, clear Map

### Value Comparison

| Type | Comparison | Rationale |
|------|-----------|-----------|
| Strings | `===` after `.trim()` | Prevents whitespace-only "changes" |
| Numbers | `===` | Exact match |
| Booleans | `===` | Exact match |
| Passwords | `===` (no trimming) | Whitespace matters in passwords |

## 2. Sticky Bottom Save Bar

Appears when `pendingCount > 0`. Solves pain point #1.

### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  ● 3 unsaved changes              [Discard All]  [Save All ▸]  │
└─────────────────────────────────────────────────────────────────┘
  ↑ amber dot    ↑ clickable link        ↑ ghost      ↑ primary
                   opens drawer
```

### Behavior

| State | Bottom Bar |
|-------|-----------|
| No changes | **Hidden** — zero vertical footprint |
| 1+ changes | **Slides up** from bottom (250ms ease-out) |
| Saving | Save button shows spinner + disabled, Discard disabled |
| Save success | Bar slides down + disappears (150ms ease-in) |
| Save error | Bar stays, toast shows error message |

### Styling

- Fixed to viewport bottom, inside main content area (respects sidebar margin)
- `z-20` — above content, below modals/dialogs (z-30)
- Blur backdrop: `backdrop-blur-sm bg-[var(--color-bg-primary)]/90`
- Top border: `border-t border-[var(--color-border-subtle)]`
- Height: `56px` (matches header/breadcrumb rhythm)
- Horizontal padding: `px-6`, max-width: `max-w-[1200px]` centered

### "N unsaved changes" as Drawer Trigger

- Clickable link (underline on hover, `cursor-pointer`)
- Keyboard: focusable, activates on Enter/Space
- Screen reader: `aria-label="View 3 unsaved changes"`

### Responsive

- **Desktop (lg+):** Full bar with text labels
- **Mobile (<lg):** Icon-only Discard (RotateCcw), shortened "N changes" text

### Relationship to Existing Top Buttons

- Existing "Save All Changes" button in page header **stays** — useful when user is at top
- Bottom bar is a **duplicate affordance**, not a replacement
- Both trigger the same `saveMutation.mutate()`

## 3. Pending Changes Drawer

Slide-out panel from right edge. Solves pain points #2 and #3.

### Layout

```
┌──────────────────────────────────────────────┐
│  Pending Changes (3)                    [✕]  │
│─────────────────────────────────────────────│
│                                              │
│  LDAP Connection                             │
│  ┌──────────────────────────────────────┐   │
│  │ Server URL                  [↩ Revert]   │
│  │  ldap://old-server:389                   │
│  │  → ldap://new-server:389                 │
│  └──────────────────────────────────────┘   │
│  ┌──────────────────────────────────────┐   │
│  │ Verify SSL                  [↩ Revert]   │
│  │  false → true                            │
│  └──────────────────────────────────────┘   │
│                                              │
│  Security                                    │
│  ┌──────────────────────────────────────┐   │
│  │ Session Timeout             [↩ Revert]   │
│  │  30 minutes → 60 minutes                 │
│  └──────────────────────────────────────┘   │
│                                              │
│─────────────────────────────────────────────│
│  [Discard All]                  [Save All ▸] │
└──────────────────────────────────────────────┘
```

### Structure

- **Width:** `w-[400px]` on desktop, full-width on mobile
- **Position:** Fixed right edge, full viewport height below header (`top-14`)
- **Overlay:** Semi-transparent backdrop (`bg-black/20`), click to close
- **Grouped by section** — changes under section subheadings
- **Sorted within group** by timestamp (most recent first)
- **Empty sections** hidden — only sections with changes appear

### Per-Change Card

- **Field label** — human-readable (e.g., "Server URL" not `serverUrl`)
- **Previous value** — muted text, strikethrough style
- **Current value** — preceded by `→`, normal weight
- **Revert button** — small ghost button with undo icon, right-aligned
- **Booleans** display as `false → true`
- **Passwords/secrets** display as `••••••• → •••••••` with "(modified)" label

### Revert Behavior

| Action | Result |
|--------|--------|
| Click revert on one item | Field restores to `previousValue`, card animates out (150ms) |
| Revert last item in a section | Section subheading disappears |
| Revert all items | Drawer closes automatically |
| Discard All (drawer footer) | All fields restored, drawer closes, bottom bar hides |

### Keyboard & Accessibility

- **Escape** closes drawer
- **Tab** cycles through revert buttons and action buttons
- **Focus trap** when open
- `role="dialog"` with `aria-label="Pending changes"`
- Revert buttons: `aria-label="Revert Server URL to ldap://old-server:389"`
- `aria-live="polite"` region announces reverted items

### Animation

- **Open:** Slide from right, 250ms ease-out
- **Close:** Slide to right, 150ms ease-in
- **Item revert:** Card fades out + collapses height, 200ms
- **Reduced motion:** All animations instant (0ms via `prefers-reduced-motion`)

## 4. State Management & Integration

### Custom Hook: `usePendingChanges`

```typescript
function usePendingChanges(initialSettings: AllSettings) {
  // Returns:
  settings: AllSettings;
  pendingChanges: Map<string, PendingChange>;
  hasPendingChanges: boolean;
  pendingCount: number;
  changesBySection: Record<string, PendingChange[]>;

  updateField(section, key, value);   // same signature as today
  revertField(section, key);          // per-item undo
  revertAll();                        // discard all
  getSavePatch();                     // sparse PATCH body
  clearAll();                         // called on save success
}
```

### Integration Impact

| File | Change | Impact |
|------|--------|--------|
| `SettingsManagementPage.tsx` | Replace `useState<Set>` + `updateField` with `usePendingChanges()` hook; add BottomSaveBar + PendingChangesDrawer | Simplifies ~30 lines |
| `SettingsNav.tsx` | `dirtyCount` prop stays (now fed by `pendingCount`) | No change |
| Section components (all 9) | Same `settings` + `onFieldChange` interface | Zero changes |
| `settings.ts` (types) | Add `PendingChange` interface | Additive |
| `lib/queries/settings.ts` | Same API calls | No change |

### Field Label Resolution

Static map in constants file (~27 fields across 5 editable sections):

```typescript
const FIELD_LABELS: Record<string, Record<string, string>> = {
  ldap: { serverUrl: "Server URL", baseDn: "Base DN", verifySsl: "Verify SSL", ... },
  security: { sessionTimeoutMinutes: "Session Timeout", requireMfa: "Require MFA", ... },
  email: { smtpHost: "SMTP Host", smtpPort: "SMTP Port", useTls: "Use TLS", ... },
  audit: { retentionPolicy: "Retention Policy", siemExport: "SIEM Export", ... },
  branding: { companyName: "Company Name", supportEmail: "Support Email", ... },
};
```

### State Scope

- Page-local state in custom hook — no Zustand store needed
- No external undo/redo library — Map + previousValue is sufficient for single-level revert
- Pure React: `useState`, `useCallback`, `useMemo`

## 5. Edge Cases

### Concurrent Edits During Save

- Form inputs are **not** disabled while `saveMutation.isPending`
- If user changes a field during save:
  - **Save succeeds** → `initialSettings` refreshes → new edit becomes fresh PendingChange against saved value
  - **Save fails** → existing pending changes remain, plus new edits tracked

### Saving While Drawer is Open

- Save button shows spinner in both bottom bar and drawer footer
- On success → cards animate out, drawer closes after 300ms delay, bottom bar slides down
- On error → drawer stays open, error toast, all cards remain

### Section Exclusions

| Section | Reason for Exclusion |
|---------|---------------------|
| API Keys | Generate/Revoke are immediate mutations, not form fields |
| Admins | Add/remove are immediate mutations |
| Danger Zone | Export/Purge are action buttons |
| System Info | Read-only |
| LDAP/Email Test buttons | Testing doesn't modify form state |

Only the 5 form sections (LDAP, Email, Security, Audit, Branding) participate in change tracking.

### Browser Navigation

| Trigger | Behavior |
|---------|----------|
| Browser back/forward | `beforeunload` warning (existing, unchanged) |
| TanStack Router navigation | Route guard via `useBlocker` — "You have N unsaved changes" with Stay/Leave |
| Page refresh | `beforeunload` warning (existing) |
| Drawer open + Escape | Closes drawer only — does NOT discard changes |

### Responsive

| Viewport | Bottom Bar | Drawer |
|----------|-----------|--------|
| Desktop (lg+) | Full bar with text labels | `w-[400px]` from right edge |
| Tablet (md–lg) | Compact labels | `w-[400px]` or `w-[85vw]` |
| Mobile (<md) | Icon-only Discard, shortened text | Full-width overlay (`w-full`) |

## 6. Component Inventory & File Plan

### New Files

| File | Purpose |
|------|---------|
| `settings/hooks/usePendingChanges.ts` | Custom hook — Map state, updateField, revertField, revertAll, getSavePatch |
| `settings/BottomSaveBar.tsx` | Sticky bottom bar — count, drawer trigger, Save/Discard |
| `settings/PendingChangesDrawer.tsx` | Slide-out drawer — grouped change list with per-item revert |
| `settings/constants/field-labels.ts` | Static map of section.field → human-readable labels |

All paths relative to `src/frontend/src/components/features/`.

### Build Sequence

```
1. PendingChange type               (types — no deps)
2. field-labels.ts                   (constants — no deps)
3. usePendingChanges hook            (depends on 1, 2)
4. BottomSaveBar                     (depends on 1, uses @azblink/ui)
5. PendingChangesDrawer              (depends on 1, 2, uses @azblink/ui)
6. Wire into SettingsManagementPage  (depends on 3, 4, 5)
7. Route guard for navigation        (depends on 3)
```

Steps 1–2 are independent. Steps 4–5 are independent of each other.

### Explicitly Excluded (YAGNI)

- **Multi-level undo** (Ctrl+Z history) — single-level revert to server value is sufficient
- **Persist changes to localStorage** — session-scoped; refresh = gone (with beforeunload warning)
- **Diff highlighting** (character-level red/green) — old→new text is enough for settings
- **Change timestamps in UI** — tracked internally for sort order but not displayed (clutter)
- **New @azblink/ui primitives** — drawer is feature-specific, not reusable enough for the design system
