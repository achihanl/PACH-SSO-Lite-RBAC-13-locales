# Groups Management Page — Full-Stack Migration Design

**Date:** 2026-02-08
**Status:** Approved
**Source specs:** `new-migration-ui/GROUPS_REACT_MIGRATION_SPEC.md`, `new-migration-ui/groups-content-only.html`
**Reference implementation:** `/directory/users` split-panel migration (user-management components)

## Overview

Migrate the `/directory/groups` page from a flat card grid to a split-panel master-detail layout with inline modals. Unlike the user management migration (frontend-only), this requires backend extensions — new PostgreSQL tables, enhanced API endpoints, and a granular RBAC authorization model.

## Architecture Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| New metadata storage | Hybrid: LDAP + PostgreSQL | LDAP owns identity (`cn`, `member`, `description`). Postgres owns enrichment (`type`, `permissions`, `roles`, `timestamps`). Follows `org_profiles` precedent. |
| Group types | Categorical labels only | Drive UI color/icon/filtering. No behavioral coupling. Types: `security`, `distribution`, `department`, `project`. |
| Member roles | Group-scoped management | `owner` → delete group, transfer ownership, manage admins. `admin` → add/remove members, edit group, toggle permissions. `member` → view group, inherits RBAC permissions. |
| Permissions model | Group-level RBAC | Groups grant app capabilities (`user_management`, `qr_provisioning`, `audit_log_access`, `system_configuration`) to their members. Backend enforces via `require_permission` decorator. |
| `description` storage | LDAP | Native `groupOfNames` attribute. No schema extension needed. |
| Authorization evolution | Additive, backward-compatible | `require_permission` checks RBAC first, falls back to existing `require_admin`. Existing admin access unaffected. |

## Data Model

### PostgreSQL Schema

```sql
-- Group enrichment metadata (keyed by LDAP cn)
CREATE TABLE IF NOT EXISTS group_profiles (
    cn              TEXT PRIMARY KEY,
    group_type      TEXT NOT NULL DEFAULT 'distribution'
                    CHECK (group_type IN ('security','distribution','department','project')),
    permissions     JSONB NOT NULL DEFAULT '[]',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Per-member role within a group
CREATE TABLE IF NOT EXISTS group_member_roles (
    group_cn        TEXT NOT NULL REFERENCES group_profiles(cn) ON DELETE CASCADE,
    member_uid      TEXT NOT NULL,
    role            TEXT NOT NULL DEFAULT 'member'
                    CHECK (role IN ('owner','admin','member')),
    assigned_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (group_cn, member_uid)
);

CREATE INDEX idx_gmr_member ON group_member_roles(member_uid);
```

**Design notes:**
- `permissions` as JSONB array — valid set is small and fixed, normalized table would be over-engineering
- Composite PK `(group_cn, member_uid)` — one role per member per group
- Cascading delete — removing a group profile removes all role assignments
- Group creator automatically gets `owner` role

### LDAP (unchanged schema, enhanced usage)

- Read/write `description` attribute on `groupOfNames` entries (already supported, just not used)
- No custom attributes or auxiliary objectClasses needed

## API Contract

### Enhanced Existing Endpoints

| Endpoint | Changes |
|----------|---------|
| `GET /api/groups` | Join LDAP + Postgres. Return `type`, `description`, `permissions`, `created_at`, `member_count`. Add `?type=` and `?search=` query params. |
| `POST /api/groups/create` | Accept `description`, `group_type`. Create LDAP entry + `group_profiles` row. Assign `owner` role to creator. |
| `GET /api/groups/{cn}/members` | Return full member objects with `role` from `group_member_roles` (not just string UIDs). |
| `DELETE /api/groups/{cn}` | Also delete `group_profiles` row (cascades to `group_member_roles`). |

### New Endpoints

| Endpoint | Auth | Purpose |
|----------|------|---------|
| `GET /api/groups/{cn}` | `require_user` | Group detail — LDAP + Postgres merged |
| `PATCH /api/groups/{cn}` | `require_admin` → later `require_permission` | Update description, type |
| `PATCH /api/groups/{cn}/permissions` | `require_admin` → later `require_permission` | Replace permissions list |
| `PATCH /api/groups/{cn}/members/{uid}/role` | `require_admin` → later `require_permission` | Change member role |
| `GET /api/users/search?q=&excludeGroup=` | `require_user` | Search users for add-members modal |

### Request/Response Models

```python
class GroupCreateReq(BaseModel):
    orgDn: str
    cn: str
    description: str = ""
    group_type: str = "distribution"

class GroupUpdateReq(BaseModel):
    description: str | None = None
    group_type: str | None = None

class GroupPermissionsReq(BaseModel):
    permissions: list[str]  # full replacement list

class GroupMemberRoleReq(BaseModel):
    role: str  # owner | admin | member

class GroupListItem(BaseModel):
    cn: str
    dn: str
    description: str
    group_type: str
    member_count: int
    permissions: list[str]
    created_at: str
    updated_at: str

class GroupDetail(GroupListItem):
    members: list[GroupMember]

class GroupMember(BaseModel):
    uid: str
    dn: str
    displayName: str
    mail: str
    role: str  # owner | admin | member
```

## Frontend Component Architecture

All components under `src/frontend/src/components/features/group-management/`.

```
group-management/
├── GroupManagementPage.tsx      # Route-level shell, split-panel, URL state, modal orchestration
├── PageHeader.tsx               # Title + search + "Create Group" CTA
├── GroupList.tsx                 # Left panel — filter tabs + scrollable group rows
├── GroupRow.tsx                  # Type-colored icon, cn, description, member count, type badge
├── GroupDetailPanel.tsx          # Right panel — info grid, members, permissions
├── GroupTypeBadge.tsx            # Type pill with color mapping (red/blue/purple/green)
├── MemberRoleBadge.tsx          # Role pill (owner=amber, admin=purple, member=zinc)
├── MemberRow.tsx                # Avatar, name, email, role badge, remove button, role dropdown
├── PermissionToggle.tsx         # Label + description + toggle switch
├── useModalState.ts             # Reducer: closed | create_group | add_members | delete_confirm
├── modals/
│   ├── CreateGroupModal.tsx     # Name, description, type select, parent org select
│   ├── AddMembersModal.tsx      # User search + checkbox selection + bulk add
│   └── DeleteGroupModal.tsx     # Confirmation with group name
```

### Patterns (carried from user-management)

- `useReducer` for modal state (page-scoped, not Zustand)
- URL search params: `groupId`, `filter`, `search` via TanStack Router `validateSearch`
- `useSuspenseQuery` + `Suspense` boundary
- Client-side filtering of server-fetched list
- `useRef` + `useEffect` for Cmd+K shortcut
- `@azblink/ui` primitives: Dialog, Tabs, Button, Card, Badge, Input, Textarea

### Query Hooks (`src/frontend/src/lib/queries/`)

- `groups.ts` — enhanced `groupsQueryOptions` + new `groupDetailQueryOptions(cn)`
- `group-mutations.ts` — `useCreateGroup`, `useDeleteGroup`, `useUpdateGroup`
- `group-members.ts` — `useAddMembers`, `useRemoveMember`, `useUpdateMemberRole`
- `group-permissions.ts` — `useUpdateGroupPermissions`

### Type Definitions (`src/frontend/src/types/group.ts`)

New file replacing the minimal `Group` interface in `types/user.ts`.

## Authorization Middleware — `require_permission`

### Decorator Usage

```python
@app.get("/api/users")
@require_permission("user_management")
async def api_users(request: Request):
    ...
```

### Resolution Logic

1. Extract `uid` from JWT (existing `require_user` flow)
2. Query `group_member_roles` for all groups the user belongs to
3. Query `group_profiles.permissions` for those groups
4. If any group grants the required permission → allow
5. If no group grants it → check if user is LDAP admin (backward-compatible fallback)
6. If neither → 403

### Backward Compatibility

- `require_admin` continues to work unchanged (LDAP-based)
- `require_permission` is additive — RBAC first, falls back to `require_admin`
- Existing admin users lose no access
- Endpoints migrate from `require_admin` → `require_permission` one at a time
- Phase 5 migrates group-management endpoints only; others remain on `require_admin`

### Performance

- 2 Postgres queries per permission-gated request (acceptable for group management throughput)
- Future optimization: 30s in-memory cache keyed by `uid`, invalidated on role/permission changes

## Implementation Phases

Each phase pairs backend + frontend, testable end-to-end. Code review after each phase.

| Phase | Backend | Frontend | Deliverable |
|-------|---------|----------|-------------|
| **0: Schema + API foundation** | Migration SQL. New `groupdb.py` for Postgres CRUD. Enhance `ldap_client.py` for `description`. | New types in `types/group.ts` | DB tables exist, types defined |
| **1: Enhanced list + detail** | `GET /api/groups` enriched (join). New `GET /api/groups/{cn}`. `?type=` and `?search=` filters. | Split-panel shell: `GroupManagementPage`, `PageHeader`, `GroupList`, `GroupRow`, `GroupTypeBadge` | Browsable group list with filtering |
| **2: Group detail panel** | — (uses Phase 1 endpoints) | `GroupDetailPanel` — info grid, member list with `MemberRow`, permissions with `PermissionToggle` | Right panel shows full detail |
| **3: Create + delete** | Enhance `POST /api/groups/create`. New `DELETE /api/groups/{cn}` cascade. New `PATCH /api/groups/{cn}`. | `CreateGroupModal`, `DeleteGroupModal`, `useModalState` | Full group lifecycle |
| **4: Member management** | Enhance `GET /api/groups/{cn}/members` with roles. New `PATCH .../role`. New `GET /api/users/search`. | `AddMembersModal`, role dropdown in `MemberRow`, remove member | Add/remove members, change roles |
| **5: Permissions** | New `PATCH /api/groups/{cn}/permissions`. New `require_permission` decorator. Wire into auth. | `PermissionToggle` wired to mutation, optimistic updates | RBAC toggles functional |
| **6: Polish** | — | Cmd+K shortcut, `$cn.tsx` redirect, empty states, skeletons, accessibility | Production-ready UX |

**Dependency chain:** 0 → 1 → 2 → 3 → 4 → 5 → 6 (strictly sequential)

## Color Mappings

### Group Types

| Type | Badge color | Icon color |
|------|-------------|------------|
| `security` | `red` | `text-red-400` |
| `distribution` | `blue` | `text-blue-400` |
| `department` | `purple` | `text-purple-400` |
| `project` | `green` | `text-green-400` |

### Member Roles

| Role | Badge color |
|------|-------------|
| `owner` | `amber` |
| `admin` | `purple` |
| `member` | `zinc` |

### Permission Keys

| Key | UI Label | Description |
|-----|----------|-------------|
| `user_management` | User Management | Create, edit, delete users |
| `qr_provisioning` | QR Provisioning | Generate QR codes |
| `audit_log_access` | Audit Log Access | View audit logs |
| `system_configuration` | System Configuration | Modify system settings |
