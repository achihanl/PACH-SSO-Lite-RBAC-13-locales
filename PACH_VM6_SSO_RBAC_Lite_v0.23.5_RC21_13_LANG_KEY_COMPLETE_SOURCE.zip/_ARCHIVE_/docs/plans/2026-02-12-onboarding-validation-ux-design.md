# Onboarding Validation UX & Delivery Button Icons

**Date:** 2026-02-12
**Status:** Approved
**Scope:** `src/frontend/src/components/features/user-management/onboarding/` + `modals/DeliveryOptions.tsx`

## Problem

1. **Validation UX:** Step 1 (User Info) validation returns a single error string displayed as a top-level banner. No field-level highlighting — user must guess which field is invalid.
2. **Delivery button icons:** The `[Email]` `[SMS]` `[Print]` `[Copy URL]` buttons in the QR panel don't render Lucide SVG icons. CSS specificity conflict between `Button.module.css` and Tailwind utility overrides causes the vertical icon+label layout to break.

## Solution

### 1. Per-Field Validation Errors

Refactor `validation.ts` to return a field-keyed error map instead of a single string:

```ts
type FieldErrors = Partial<Record<keyof OnboardingState, string>>;

export function validateStepUserInfo(state: OnboardingState): FieldErrors {
  const errors: FieldErrors = {};
  // Check all fields simultaneously, populate map
  return errors;
}
```

**Wizard state additions:**
- `fieldErrors: FieldErrors` — populated on "Next" click, cleared on field change
- `hasAttemptedNext: boolean` — prevents showing errors before first attempt

**Field display:**
- `<Input aria-invalid={!!errors.fieldName} />` — activates existing red border CSS in `Input.module.css`
- `<p className="text-xs text-[var(--color-danger)]">{error}</p>` below each field

### 2. Password Complexity Live Checklist

Private `PasswordChecklist` component inside `StepUserInfo.tsx` (not a new file):
- Renders below manual password field
- 4 rules: length >= 8, uppercase, lowercase, number
- Each row: `CheckCircle2` (green) when met, `Circle` (muted) when not
- Updates in real-time as user types
- `validateStepUserInfo` still blocks "Next" if rules unmet, with `errors.password = 'See requirements below'`

### 3. Delivery Button Icon Fix

Replace `DeliveryButton` internals — use a plain `<button>` with Tailwind instead of the `Button` primitive:
- The vertical icon+label layout is a one-off pattern that doesn't match Button's horizontal design
- Eliminates CSS specificity conflict between `Button.module.css` and Tailwind overrides
- Icons (`Mail`, `Smartphone`, `Printer`, `Link2`) render reliably as direct children of the button

## Files Modified

| File | Change |
|------|--------|
| `onboarding/validation.ts` | Return `FieldErrors` map instead of `string \| null` |
| `onboarding/OnboardingWizard.tsx` | Add `fieldErrors` + `hasAttemptedNext` state; pass errors to steps |
| `onboarding/StepUserInfo.tsx` | Accept `errors` prop; `aria-invalid` on inputs; inline error text; `PasswordChecklist` |
| `modals/DeliveryOptions.tsx` | Refactor `DeliveryButton` to plain `<button>` with Tailwind |

## Not In Scope

- Real-time on-blur validation (only on "Next" click + live password checklist)
- Error summary banner at top
- Step 2/3/4 validation display changes
- QRGenerationModal changes (shares `DeliveryOptions`, gets icon fix automatically)
