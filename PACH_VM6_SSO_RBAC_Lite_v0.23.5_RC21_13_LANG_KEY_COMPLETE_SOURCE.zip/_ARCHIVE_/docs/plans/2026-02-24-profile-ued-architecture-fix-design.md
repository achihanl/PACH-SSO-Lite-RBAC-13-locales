---
feature: profile-ued-architecture-fix
date: 2026-02-24
phase: architecture
---

# Profile-UED Architecture Fix — Design

## Architecture Decision
Single source of truth: UED discovery response. The profile stops pretending to know about XMPP/SIP configuration independently. Service configuration lives on the UED instance (env vars), discovered dynamically, cached on the profile.

## Key New Components
1. `ServiceEndpoints` model on UED Sync discovery response
2. `discovered_capabilities TEXT[]` + `discovered_service_endpoints JSONB` columns on config_templates
3. `OrgDB.resolve_template_for_org(org_dn)` — JOIN assignments→templates
4. `_resolve_profile_id_for_user(user)` helper for lifecycle sync
5. `_resolve_service_endpoints(org_dn)` helper for QR assembly

## Migration Strategy
Single migration 015: ADD new columns + DROP xmpp_config/sip_config

## Backward Compatibility
- UCCHAT_* env vars become optional fallback (warning instead of crash)
- API response shape changes (breaking for internal admin UI only)
- Seed data updated (Standard Profile starts empty until UED discovery)

## Build Sequence
Phase 1: UED Sync (non-breaking) → Phase 2: DB + cache (non-breaking) → Phase 3: Drop columns (breaking) + Phase 4: Frontend (parallel) → Phase 5: QR + Phase 6: Lifecycle sync
