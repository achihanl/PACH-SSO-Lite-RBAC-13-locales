# Plan: Onboarding Wizard Full Validation + Password UX Upgrade

**Date:** 2026-02-12
**Goal:** Port the new.tsx password UX (auto-generate + manual toggle) into the onboarding wizard, then remove new.tsx

---

## Changes

### 1. OnboardingWizard.tsx — Add passwordMode + UI state to reducer
- Add `passwordMode: 'auto' | 'manual'` to `OnboardingState` (default: `'auto'`)
- Add `showPassword: boolean` and `copiedPassword: boolean` to state
- Initialize `password` with `generatePassword()` in INITIAL_STATE
- Import `generatePassword` from `user-create.ts`

### 2. StepUserInfo.tsx — Replace password section with toggle UX
- Add Toggle, show/hide, copy, regenerate controls matching new.tsx lines 211-294
- Import `Toggle` from `@azblink/ui`, icons from `lucide-react`
- Import `generatePassword` from `user-create.ts`
- Wire through `dispatch` (not just `setField`) for password mode toggle actions

### 3. validation.ts — Adapt for passwordMode
- When `passwordMode === 'auto'`, skip manual password checks (password is already valid)
- When `passwordMode === 'manual'`, run full complexity checks as-is

### 4. StepQRCode.tsx — Show password in summary when auto-generated
- Add password row to Creation Summary so admin can see/copy before QR generation

### 5. Delete new.tsx — Remove deprecated route
- Delete `src/frontend/src/routes/directory/users/new.tsx`
- Regenerate route tree

## Files Modified
- `OnboardingWizard.tsx` — state shape
- `StepUserInfo.tsx` — password UX
- `validation.ts` — passwordMode-aware
- `StepQRCode.tsx` — password in summary
- `new.tsx` — deleted

**No new files created.**
