# UED PJSIP Schema Registry Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Ship a built-in PJSIP provisioning schema in UED Sync so callers can
reference it by name (`schema_name: "pjsip-combined"`) instead of sending the
full 13-attribute schema inline every request.

**Architecture:** New `schemas/` module inside `ued_sync` with a registry
function (`get_schema`) and the PJSIP combined schema definition. Request
models gain an optional `schema_name` field; resolution happens in the router
before any LDAP work. `SIP_AUTH_REALM` env var parameterizes the schema.

**Tech Stack:** Python 3.11, FastAPI, Pydantic v2, pydantic-settings, ldap3,
pytest

---

### Task 1: Add `SIP_AUTH_REALM` to Settings

**Files:**
- Modify: `src/ued-sync/src/ued_sync/config.py:60-77`

**Step 1: Write the failing test**

Create `src/ued-sync/tests/test_config_sip.py`:

```python
"""Tests for SIP_AUTH_REALM config."""

from unittest.mock import patch

from ued_sync.config import Settings


def test_sip_auth_realm_default():
    """Default SIP auth realm is 'asterisk'."""
    s = Settings(api_key="dev-api-key-change-me")
    assert s.sip_auth_realm == "asterisk"


def test_sip_auth_realm_from_env():
    """SIP_AUTH_REALM env var overrides default."""
    with patch.dict("os.environ", {"SIP_AUTH_REALM": "xmpp-sip-platform.local"}):
        s = Settings(api_key="dev-api-key-change-me")
        assert s.sip_auth_realm == "xmpp-sip-platform.local"
```

**Step 2: Run test to verify it fails**

Run: `just ued-test` (or from host: `cd src/ued-sync && PYTHONPATH=src uv run pytest tests/test_config_sip.py -v`)

Expected: FAIL with `AttributeError: 'Settings' object has no attribute 'sip_auth_realm'`

**Step 3: Write minimal implementation**

Add to `src/ued-sync/src/ued_sync/config.py` after the rate limiting block
(after line 77, before `settings = Settings()`):

```python
    # SIP provisioning
    sip_auth_realm: str = Field(
        default="asterisk",
        description="SIP auth realm for PJSIP provisioning (AstAuthRealm)",
    )
```

**Step 4: Run test to verify it passes**

Run: `just ued-test`

Expected: PASS (both new tests + all 182 existing)

**Step 5: Commit**

```bash
git add src/ued-sync/src/ued_sync/config.py src/ued-sync/tests/test_config_sip.py
git commit -m "feat(ued-sync): add SIP_AUTH_REALM setting for PJSIP provisioning"
```

---

### Task 2: Create the schema registry module

**Files:**
- Create: `src/ued-sync/src/ued_sync/schemas/__init__.py`
- Create: `src/ued-sync/src/ued_sync/schemas/pjsip.py`

**Step 1: Write the failing test**

Create `src/ued-sync/tests/test_schema_registry.py`:

```python
"""Tests for built-in schema registry."""

import pytest

from ued_sync.schema import ProvisioningSchema, SchemaError


def test_get_schema_pjsip_combined():
    """Registry returns a valid ProvisioningSchema for 'pjsip-combined'."""
    from ued_sync.schemas import get_schema

    schema = get_schema("pjsip-combined")
    assert isinstance(schema, ProvisioningSchema)
    assert "AsteriskPjsipEndpoint" in schema.object_classes
    assert "AsteriskPjsipAuth" in schema.object_classes
    assert "AsteriskPjsipAor" in schema.object_classes
    assert "posixAccount" in schema.object_classes
    assert schema.password_attribute == "userPassword"
    assert schema.password_hash == "SSHA"


def test_get_schema_pjsip_has_required_fields():
    """PJSIP schema requires username, display_name, uid_number, sip_password."""
    from ued_sync.schemas import get_schema

    schema = get_schema("pjsip-combined")
    assert "username" in schema.required_fields
    assert "display_name" in schema.required_fields
    assert "uid_number" in schema.required_fields
    assert "sip_password" in schema.required_fields


def test_get_schema_pjsip_has_endpoint_attrs():
    """PJSIP schema maps all Asterisk endpoint attributes."""
    from ued_sync.schemas import get_schema

    schema = get_schema("pjsip-combined")
    attr_map = schema.attribute_map
    assert "AstEndpointContext" in attr_map
    assert "AstEndpointAllow" in attr_map
    assert "AstEndpointTransport" in attr_map
    assert "AstEndpointAors" in attr_map
    assert "AstEndpointAuth" in attr_map
    assert "AstAuthType" in attr_map
    assert "AstAuthUsername" in attr_map
    assert "AstAuthPassword" in attr_map
    assert "AstAorMaxContacts" in attr_map


def test_get_schema_pjsip_realm_from_settings():
    """PJSIP schema uses SIP_AUTH_REALM from settings for AstAuthRealm."""
    from unittest.mock import patch
    from ued_sync.schemas import get_schema

    with patch("ued_sync.schemas.pjsip.settings") as mock_settings:
        mock_settings.sip_auth_realm = "custom-realm.local"
        schema = get_schema("pjsip-combined")
        assert schema.attribute_map["AstAuthRealm"] == "custom-realm.local"


def test_get_schema_unknown_name_raises():
    """Unknown schema name raises SchemaError."""
    from ued_sync.schemas import get_schema

    with pytest.raises(SchemaError, match="Unknown schema name"):
        get_schema("nonexistent-schema")


def test_list_schemas():
    """list_schemas returns available schema names."""
    from ued_sync.schemas import list_schemas

    names = list_schemas()
    assert "pjsip-combined" in names
```

**Step 2: Run test to verify it fails**

Run: `cd src/ued-sync && PYTHONPATH=src uv run pytest tests/test_schema_registry.py -v`

Expected: FAIL with `ModuleNotFoundError: No module named 'ued_sync.schemas'`

**Step 3: Write minimal implementation**

Create `src/ued-sync/src/ued_sync/schemas/__init__.py`:

```python
"""Built-in provisioning schema registry.

Callers can reference schemas by name (e.g. ``"pjsip-combined"``) instead of
sending the full ProvisioningSchema inline.  Inline schemas always take
priority over named schemas.
"""

from ued_sync.schema import ProvisioningSchema, SchemaError
from ued_sync.schemas.pjsip import pjsip_combined_schema

# Registry: name -> factory function (no args, returns ProvisioningSchema)
_REGISTRY: dict[str, callable] = {
    "pjsip-combined": pjsip_combined_schema,
}


def get_schema(name: str) -> ProvisioningSchema:
    """Look up a built-in schema by name.

    Args:
        name: Registry key (e.g. ``"pjsip-combined"``)

    Returns:
        ProvisioningSchema instance

    Raises:
        SchemaError: If name is not found in the registry
    """
    factory = _REGISTRY.get(name)
    if factory is None:
        available = ", ".join(sorted(_REGISTRY.keys()))
        raise SchemaError(
            f"Unknown schema name '{name}'. Available: {available}"
        )
    return factory()


def list_schemas() -> list[str]:
    """Return all registered schema names."""
    return sorted(_REGISTRY.keys())
```

Create `src/ued-sync/src/ued_sync/schemas/pjsip.py`:

```python
"""Asterisk PJSIP combined provisioning schema.

Produces a single LDAP entry carrying posixAccount + all three PJSIP
AUXILIARY objectClasses (Endpoint, Auth, AoR).  Proven against:
  - Dev OpenLDAP stack (5/5 integration tests)
  - Real SIP LDAP at 192.168.122.89 (5/5 integration tests)

Attribute reference:
  https://gitlab.com/XavierBrassoud/asterisk-pjsip-ldap-schema
"""

from ued_sync.config import settings
from ued_sync.schema import ProvisioningSchema


def pjsip_combined_schema() -> ProvisioningSchema:
    """Build the default PJSIP combined provisioning schema.

    - objectClasses: posixAccount + AsteriskPjsipEndpoint/Auth/Aor
    - Auth realm: from ``SIP_AUTH_REALM`` env var (default ``"asterisk"``)
    - Password: userPassword with SSHA hash (enables LDAP bind auth)
    """
    return ProvisioningSchema(
        dn_template="uid={username},ou=People,{base_dn}",
        object_classes=[
            "top",
            "account",
            "posixAccount",
            "AsteriskPjsipEndpoint",
            "AsteriskPjsipAuth",
            "AsteriskPjsipAor",
        ],
        attribute_map={
            # POSIX
            "uid": "{username}",
            "cn": "{display_name}",
            "uidNumber": "{uid_number}",
            "gidNumber": "1000",
            "homeDirectory": "/home/{username}",
            "loginShell": "/bin/bash",
            # Endpoint
            "AstEndpointContext": "from-internal",
            "AstEndpointAllow": "!all,ulaw,alaw,opus",
            "AstEndpointDisallow": "all",
            "AstEndpointTransport": "transport-udp",
            "AstEndpointAors": "{username}",
            "AstEndpointAuth": "{username}",
            # Auth
            "AstAuthType": "userpass",
            "AstAuthUsername": "{username}",
            "AstAuthPassword": "{sip_password}",
            "AstAuthRealm": settings.sip_auth_realm,
            # AoR
            "AstAorMaxContacts": "1",
            "AstAorRemoveExisting": "yes",
            "AstAorQualifyFrequency": "60",
        },
        required_fields=["username", "display_name", "uid_number", "sip_password"],
        password_attribute="userPassword",
        password_hash="SSHA",
    )
```

**Step 4: Run test to verify it passes**

Run: `cd src/ued-sync && PYTHONPATH=src uv run pytest tests/test_schema_registry.py -v`

Expected: 6 PASSED

**Step 5: Run full test suite to verify no regressions**

Run: `just ued-test`

Expected: 188+ passed (182 existing + 6 new), 0 failed

**Step 6: Commit**

```bash
git add src/ued-sync/src/ued_sync/schemas/ src/ued-sync/tests/test_schema_registry.py
git commit -m "feat(ued-sync): add PJSIP schema registry with pjsip-combined schema"
```

---

### Task 3: Add `schema_name` to request models

**Files:**
- Modify: `src/ued-sync/src/ued_sync/sync_models.py:21-35` (SyncUserRequest)
- Modify: `src/ued-sync/src/ued_sync/sync_models.py:126-155` (BatchRequest)

**Step 1: Write the failing tests**

Add to `src/ued-sync/tests/test_sync_models.py` (append to existing file):

```python
def test_sync_user_request_with_schema_name():
    """SyncUserRequest accepts schema_name instead of inline schema."""
    req = SyncUserRequest(
        operation="create",
        request_id="test-001",
        ldap={
            "uri": "ldap://localhost:389",
            "base_dn": "dc=test,dc=com",
            "bind_dn": "cn=admin,dc=test,dc=com",
            "bind_pw": "secret",
        },
        schema_name="pjsip-combined",
        user={"username": "testuser", "display_name": "Test", "uid_number": "9001", "sip_password": "secret"},
        password="LdapPass123!",
    )
    assert req.schema_name == "pjsip-combined"
    # resolved_schema should return a ProvisioningSchema from the registry
    schema = req.resolved_schema
    assert "AsteriskPjsipEndpoint" in schema.object_classes


def test_sync_user_request_inline_schema_wins():
    """Inline schema takes priority over schema_name."""
    from ued_sync.schema import ProvisioningSchema
    inline = ProvisioningSchema(
        dn_template="uid={username},{base_dn}",
        object_classes=["top", "account", "posixAccount"],
        attribute_map={"uid": "{username}", "cn": "{display_name}"},
        required_fields=["username", "display_name"],
    )
    req = SyncUserRequest(
        operation="create",
        request_id="test-002",
        ldap={
            "uri": "ldap://localhost:389",
            "base_dn": "dc=test,dc=com",
            "bind_dn": "cn=admin,dc=test,dc=com",
            "bind_pw": "secret",
        },
        schema=inline,
        schema_name="pjsip-combined",
        user={"username": "testuser", "display_name": "Test"},
    )
    # Inline wins — only 3 objectClasses, not 6
    assert len(req.resolved_schema.object_classes) == 3


def test_sync_user_request_neither_schema_raises():
    """SyncUserRequest with no schema and no schema_name raises."""
    import pytest
    with pytest.raises(ValueError, match="schema.*schema_name"):
        SyncUserRequest(
            operation="create",
            request_id="test-003",
            ldap={
                "uri": "ldap://localhost:389",
                "base_dn": "dc=test,dc=com",
                "bind_dn": "cn=admin,dc=test,dc=com",
                "bind_pw": "secret",
            },
            user={"username": "testuser"},
        )


def test_sync_user_request_invalid_schema_name_raises():
    """SyncUserRequest with unknown schema_name raises."""
    import pytest
    with pytest.raises((ValueError, Exception)):
        SyncUserRequest(
            operation="create",
            request_id="test-004",
            ldap={
                "uri": "ldap://localhost:389",
                "base_dn": "dc=test,dc=com",
                "bind_dn": "cn=admin,dc=test,dc=com",
                "bind_pw": "secret",
            },
            schema_name="nonexistent",
            user={"username": "testuser"},
        )
```

**Step 2: Run test to verify it fails**

Run: `cd src/ued-sync && PYTHONPATH=src uv run pytest tests/test_sync_models.py -v -k "schema_name"`

Expected: FAIL (field doesn't exist yet)

**Step 3: Write minimal implementation**

Modify `src/ued-sync/src/ued_sync/sync_models.py`.

Replace `SyncUserRequest` (lines 21-35) with:

```python
class SyncUserRequest(BaseModel):
    """Request to sync a user to LDAP.

    Provide either ``schema`` (inline ProvisioningSchema) or ``schema_name``
    (built-in registry name like ``"pjsip-combined"``).  Inline always wins.
    """

    model_config = ConfigDict(populate_by_name=True)

    operation: Literal["create", "update", "delete"] = Field(
        ..., description="Operation type"
    )
    request_id: str = Field(..., description="Unique request ID for idempotency")
    ldap: LdapConfig = Field(..., description="LDAP connection configuration")
    schema_config: Optional[ProvisioningSchema] = Field(
        None, alias="schema", description="Inline provisioning schema"
    )
    schema_name: Optional[str] = Field(
        None, description="Built-in schema name (e.g. 'pjsip-combined')"
    )
    user: dict[str, str] = Field(..., description="User data with field values")
    password: Optional[str] = Field(None, description="User password (for create)")

    @property
    def resolved_schema(self) -> ProvisioningSchema:
        """Return the effective schema (inline wins over named)."""
        if self.schema_config is not None:
            return self.schema_config
        if self.schema_name is not None:
            from ued_sync.schemas import get_schema
            return get_schema(self.schema_name)
        raise ValueError("Either 'schema' or 'schema_name' must be provided")

    def model_post_init(self, __context) -> None:
        """Validate that at least one schema source is provided."""
        if self.schema_config is None and self.schema_name is None:
            raise ValueError("Either 'schema' or 'schema_name' must be provided")
        if self.schema_name is not None and self.schema_config is None:
            # Validate schema_name resolves (fail fast)
            from ued_sync.schemas import get_schema
            get_schema(self.schema_name)
```

Replace `BatchRequest` (lines 126-155) with same pattern — add
`schema_name` and `resolved_schema`:

```python
class BatchRequest(BaseModel):
    """Request for batch user operations.

    Provide either ``schema`` (inline) or ``schema_name`` (registry).
    """

    model_config = ConfigDict(populate_by_name=True)

    operation: BatchOperation = Field(..., description="Batch operation type")
    request_id: str = Field(..., description="Unique request ID for idempotency")
    ldap: LdapConfig = Field(..., description="LDAP connection configuration")
    schema_config: Optional[ProvisioningSchema] = Field(
        None, alias="schema", description="Provisioning schema"
    )
    schema_name: Optional[str] = Field(
        None, description="Built-in schema name (e.g. 'pjsip-combined')"
    )
    users: Optional[list[BatchUserCreate]] = Field(
        None, description="Users to create (for create operation)"
    )
    uids: Optional[list[str]] = Field(
        None, description="User IDs to delete (for delete operation)"
    )

    @property
    def resolved_schema(self) -> ProvisioningSchema:
        """Return the effective schema (inline wins over named)."""
        if self.schema_config is not None:
            return self.schema_config
        if self.schema_name is not None:
            from ued_sync.schemas import get_schema
            return get_schema(self.schema_name)
        raise ValueError("Either 'schema' or 'schema_name' must be provided")

    def model_post_init(self, __context) -> None:
        """Validate schema + operation-specific fields."""
        if self.schema_config is None and self.schema_name is None:
            raise ValueError("Either 'schema' or 'schema_name' must be provided")
        if self.schema_name is not None and self.schema_config is None:
            from ued_sync.schemas import get_schema
            get_schema(self.schema_name)
        if self.operation == BatchOperation.CREATE:
            if not self.users:
                raise ValueError("users field required for create operation")
            if len(self.users) > 100:
                raise ValueError("Maximum 100 users per batch")
        elif self.operation == BatchOperation.DELETE:
            if not self.uids:
                raise ValueError("uids field required for delete operation")
            if len(self.uids) > 100:
                raise ValueError("Maximum 100 uids per batch")
```

**Step 4: Update routers to use `resolved_schema`**

In `src/ued-sync/src/ued_sync/routers/sync.py`, line 36, change:

```python
# Before:
schema = body.schema_config
# After:
schema = body.resolved_schema
```

In `src/ued-sync/src/ued_sync/routers/batch.py`, lines 78 and 92, change:

```python
# Before:
schema=body.schema_config,
# After:
schema=body.resolved_schema,
```

**Step 5: Run tests**

Run: `just ued-test`

Expected: All tests pass (existing + new). Some existing tests that
construct `SyncUserRequest` may need updating since `schema_config` is
now optional — check the `test_sync_models.py` fixtures and
`test_api/test_sync.py` to see if they use `schema=...` (which maps to
`schema_config` via alias). Since the alias is unchanged and the field
was `...` (required) → `None` (optional), existing tests sending
`schema=<ProvisioningSchema>` will continue to work.

**Step 6: Commit**

```bash
git add src/ued-sync/src/ued_sync/sync_models.py \
        src/ued-sync/src/ued_sync/routers/sync.py \
        src/ued-sync/src/ued_sync/routers/batch.py \
        src/ued-sync/tests/test_sync_models.py
git commit -m "feat(ued-sync): add schema_name field for built-in schema resolution"
```

---

### Task 4: Integration test — `schema_name` against dev stack

**Files:**
- Modify: `src/ued-sync/tests/integration/test_sip_provisioning.py`

**Step 1: Add a new test class for schema_name-based provisioning**

Append to `test_sip_provisioning.py`:

```python
class TestSipSchemaNameProvisioning:
    """Tests using schema_name='pjsip-combined' instead of inline schema."""

    def test_provision_via_schema_name(
        self, client, api_headers, ldap_config, cleanup_sip_user, sip_test_extension,
    ):
        """Create a SIP user using schema_name instead of inline schema."""
        uid = cleanup_sip_user
        ext = sip_test_extension

        create_request = {
            "operation": "create",
            "request_id": f"sip-named-{uid}",
            "ldap": ldap_config,
            "schema_name": "pjsip-combined",
            "user": {
                "username": uid,
                "display_name": "Schema Name Test",
                "uid_number": ext,
                "sip_password": "sip_named_pass",
            },
            "password": "LdapBindPass123!",
        }

        response = client.post("/api/v1/sync/user", json=create_request, headers=api_headers)
        assert response.status_code == 200, f"Create failed: {response.json()}"
        data = response.json()
        assert data["ok"] is True
        assert uid in data["dn"]

    def test_schema_name_bind_auth(
        self, client, api_headers, ldap_config, cleanup_sip_user, sip_test_extension,
    ):
        """User created via schema_name can authenticate via LDAP bind."""
        uid = cleanup_sip_user
        ext = sip_test_extension
        ldap_password = "BindAuthTest456!"

        # Create via schema_name
        create_request = {
            "operation": "create",
            "request_id": f"sip-named-auth-{uid}",
            "ldap": ldap_config,
            "schema_name": "pjsip-combined",
            "user": {
                "username": uid,
                "display_name": "Bind Auth Test",
                "uid_number": ext,
                "sip_password": "sip_digest_pass",
            },
            "password": ldap_password,
        }

        resp = client.post("/api/v1/sync/user", json=create_request, headers=api_headers)
        assert resp.status_code == 200

        # Verify LDAP bind works
        auth_request = {
            "request_id": f"sip-named-bind-{uid}",
            "ldap": ldap_config,
            "schema": {
                "search": {
                    "base_dn": "ou=People,{base_dn}",
                    "filter_template": "(uid={username})",
                },
            },
            "credentials": {"username": uid, "password": ldap_password},
        }

        auth_resp = client.post("/api/v1/sync/auth/validate", json=auth_request, headers=api_headers)
        assert auth_resp.status_code == 200
        auth_data = auth_resp.json()
        assert auth_data["authenticated"] is True
```

**Step 2: Run against dev stack**

Run: `just ued-test-integration`

Expected: All 17 tests pass (15 existing + 2 new)

**Step 3: Run against real SIP LDAP at 192.168.122.89**

Run from host:

```bash
cd src/ued-sync && \
API_KEY=dev-api-key-change-me \
UED_LDAP_HOST=192.168.122.89 \
UED_LDAP_PORT=389 \
UED_LDAP_BASE_DN="dc=xmpp-sip-platform,dc=local" \
UED_LDAP_BIND_DN="cn=Manager,dc=xmpp-sip-platform,dc=local" \
UED_LDAP_BIND_PASSWORD="TestingPassword!23" \
SIP_AUTH_REALM="xmpp-sip-platform.local" \
PYTHONPATH=src \
uv run pytest tests/integration/test_sip_provisioning.py -v -s
```

Expected: All 7 tests pass

**Step 4: Commit**

```bash
git add src/ued-sync/tests/integration/test_sip_provisioning.py
git commit -m "test(ued-sync): add schema_name integration tests for PJSIP provisioning"
```

---

### Task 5: Add `SIP_AUTH_REALM` to docker-compose + update docs

**Files:**
- Modify: `deploy/dev/docker-compose.yml` (ued-sync environment block)

**Step 1: Add env var to docker-compose**

In the `ued-sync` service environment block, add:

```yaml
      - SIP_AUTH_REALM=${SIP_AUTH_REALM:-asterisk}
```

**Step 2: Run full test suite**

Run: `just ued-test && just ued-test-integration`

Expected: All tests pass

**Step 3: Commit**

```bash
git add deploy/dev/docker-compose.yml
git commit -m "feat(docker): add SIP_AUTH_REALM env var for UED Sync PJSIP provisioning"
```

---

### Task 6: Final verification and cleanup

**Step 1: Run full unit test suite**

Run: `just ued-test`

Expected: 188+ passed, 0 failed

**Step 2: Run full integration test suite (dev stack)**

Run: `just ued-test-integration`

Expected: 17 passed, 0 failed

**Step 3: Run against real SIP LDAP**

Run:

```bash
cd src/ued-sync && \
API_KEY=dev-api-key-change-me \
UED_LDAP_HOST=192.168.122.89 \
UED_LDAP_PORT=389 \
UED_LDAP_BASE_DN="dc=xmpp-sip-platform,dc=local" \
UED_LDAP_BIND_DN="cn=Manager,dc=xmpp-sip-platform,dc=local" \
UED_LDAP_BIND_PASSWORD="TestingPassword!23" \
SIP_AUTH_REALM="xmpp-sip-platform.local" \
PYTHONPATH=src \
uv run pytest tests/integration/test_sip_provisioning.py -v
```

Expected: 7 passed, 0 failed

**Step 4: Verify no uncommitted changes remain**

Run: `git status`

Expected: Clean working tree
