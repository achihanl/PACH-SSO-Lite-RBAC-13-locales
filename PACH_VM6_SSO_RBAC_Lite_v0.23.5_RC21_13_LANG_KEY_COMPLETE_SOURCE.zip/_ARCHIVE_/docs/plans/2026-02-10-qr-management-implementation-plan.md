# QR Code Management — Implementation Plan

> **Design doc**: `docs/plans/2026-02-10-qr-management-migration.md`
> **Spec**: `new-migration-ui/QR_MIGRATION_SPEC.md`
> **Workflow rules**: `.cursor/rules/split-panel-migration-workflow.mdc`

---

## Phase 0: Schema + Types + Query Keys + Status Config

**Goal**: Everything else depends on types. Define the domain model first.

### Tasks

- [ ] **0.1** Create `src/frontend/src/types/qr-management.ts`
  - `QRStatus` type union: `'consumed' | 'pending' | 'expired' | 'revoked'`
  - `QRCodeListItem` interface (matches `GET /api/qr/codes` response item)
  - `QRStats` interface (matches `GET /api/qr/stats` response)
  - `QRFilter` type: `'all' | QRStatus`
  - `QRDateRange` type: `'7d' | '30d' | '90d' | 'all'`
  - `QRManagementSearchParams` interface (URL search params)
  - Export all from `src/frontend/src/types/index.ts`

- [ ] **0.2** Add query keys to `src/frontend/src/lib/queries/keys.ts`
  ```typescript
  qrCodes: {
    list: (params: Record<string, unknown>) => ['qr', 'codes', params] as const,
    stats: (dateRange: string) => ['qr', 'stats', dateRange] as const,
  }
  ```

- [ ] **0.3** Create `src/frontend/src/components/features/qr-management/qr-status-config.ts`
  - Follow `group-management/group-type-config.ts` pattern
  - Map each `QRStatus` to `{ icon, color, bg, dot, label }`
  - Icons: CheckCircle (consumed), Clock (pending), AlertCircle (expired), ShieldOff (revoked)
  - Colors from spec §3 status color token map

**Commit**: `feat(qr-management): add types, query keys, and status config (Phase 0)`

**Verify**: TypeScript compiles with no errors.

---

## Phase 1: Backend Endpoints + Split-Panel Shell

**Goal**: Can render an empty split-panel with real data from the backend.

### Backend Tasks

- [ ] **1.1** Add `list_qr_codes()` method to `src/backend/orgdb.py`
  - LEFT JOIN `qr_issuance_audit` with `provision_tokens` on `token_hash`
  - Select: all audit fields + `token_status`, `consumed_by_device_id`, `client_platform`
  - Status derivation (same logic as `list_qr_issuance_for_user`)
  - Parameters: `limit`, `offset`, `search`, `status`, `date_range`, `sort`, `order`
  - Date range filter: `issued_at >= now() - interval`
  - Search filter: `user_uid ILIKE %search%` OR `token_hash ILIKE search%`
  - Status filter: post-derivation filter (or CTE)
  - Returns: `(rows: list[dict], total: int)`

- [ ] **1.2** Add `get_qr_stats()` method to `src/backend/orgdb.py`
  - Same join as above but `SELECT COUNT(*) ... GROUP BY` equivalent
  - Uses CASE/WHEN for status bucketing in SQL
  - Parameters: `date_range`
  - Returns: dict with `total_generated`, `consumed`, `pending`, `expired_unused`

- [ ] **1.3** Add `GET /api/qr/codes` endpoint to `src/backend/main.py`
  - Auth: `Depends(require_admin)`
  - Call `ORGDB.list_qr_codes()` for DB rows
  - Batch LDAP user lookup: collect unique `user_uid`, call `get_user()` per uid, cache in dict
  - Enrich each row with `user_display_name` (from LDAP `displayName`) and `user_org` (extracted from `org_dn`)
  - **Placement**: BEFORE `/api/users/{uid}/qrcode` to avoid path capture

- [ ] **1.4** Add `GET /api/qr/stats` endpoint to `src/backend/main.py`
  - Auth: `Depends(require_admin)`
  - Call `ORGDB.get_qr_stats()`

### Frontend Tasks

- [ ] **1.5** Create `src/frontend/src/lib/queries/qr-management.ts`
  - `qrCodesQueryOptions(params)` — useSuspenseQuery options for GET /api/qr/codes
  - `qrStatsQueryOptions(dateRange)` — useSuspenseQuery options for GET /api/qr/stats
  - `useRegenerateQR()` — mutation: revoke (existing `useRevokeQR` logic) + generate (existing `useGenerateQR` logic), invalidate QR codes + stats

- [ ] **1.6** Create route file `src/frontend/src/routes/provisioning/qr-codes.tsx`
  - `createFileRoute('/provisioning/qr-codes')` with `validateSearch`
  - Render `QRManagementPage` with searchParams prop
  - Add redirect from `/provisioning/qr-generator` → `/provisioning/qr-codes`

- [ ] **1.7** Create `src/frontend/src/components/features/qr-management/QRManagementPage.tsx`
  - Follow `GroupManagementPage.tsx` structure exactly:
    - `useResizablePanel({ storageKey: 'panel-width:qr-management', ... })`
    - `useNavigate` for URL param updates
    - `Cmd+K` keyboard shortcut for search focus
    - Suspense-wrapped list panel + detail panel
    - Empty detail state when nothing selected
  - Props: `searchParams: QRManagementSearchParams`

- [ ] **1.8** Create `src/frontend/src/components/features/qr-management/PageHeader.tsx`
  - Title: "QR Code Management"
  - SearchInput (import from user-management)
  - DateRangeSelect (simple `<select>` with options)
  - "Generate QR" primary button
  - "Bulk Generate" secondary button (disabled, shows toast)

**Commit**: `feat(qr-management): add backend endpoints and split-panel shell (Phase 1)`

**Verify**: Page renders at `/provisioning/qr-codes` with header, empty list panel, empty detail panel. Backend returns real data from `/api/qr/codes` and `/api/qr/stats`.

---

## Phase 2: Detail Panel (Read-Only) + Stats Row

**Goal**: Selecting a QR code shows its details. Stats row shows real metrics.

### Tasks

- [ ] **2.1** Create `src/frontend/src/components/features/qr-management/StatsRow.tsx`
  - Fetch from `qrStatsQueryOptions(dateRange)` via `useSuspenseQuery`
  - 4 StatCard components (reuse `stat-card.tsx`)
  - Cards: Total Generated (blue), Consumed (green), Pending (amber), Expired (red)
  - Skeleton loading state

- [ ] **2.2** Create `src/frontend/src/components/features/qr-management/QRDetailPanel.tsx`
  - Receives `selectedCode: QRCodeListItem` prop
  - Sections:
    - **PanelHeader**: QR preview SVG placeholder, UserSummary (name, org, email, QR ID tag), action buttons (Regenerate, Resend stub)
    - **InfoSection "QR Details"**: DetailGrid + FieldCard for status, validity, created, consumed, time-to-provision, generated by
    - **InfoSection "Device"**: DetailGrid + FieldCard for device, platform (conditional — only if device_info exists)
    - **ProvisionChecklist**: XMPP/SIP/SSO status items (derived from config — show as "Included" for all since we don't have per-token provision results)
    - **ActivityTimeline**: Fetch `userQRHistoryQueryOptions(selectedCode.user_uid)`, synthesize timeline events from history entries
  - Wire Regenerate button to callback prop (no-op for Phase 2, implemented in Phase 4)
  - Wire Resend button to "Coming soon" toast

- [ ] **2.3** Wire `QRDetailPanel` into `QRManagementPage.tsx`
  - When `qrId` is set in URL, find the matching code from list data
  - Render `QRDetailPanel` in right panel (or `EmptyDetailPanel` when none selected)

**Commit**: `feat(qr-management): add detail panel and stats row (Phase 2)`

**Verify**: Stats row shows real counts. Clicking a list row (placeholder) shows detail panel with info sections.

---

## Phase 3: Generate QR Modal

**Goal**: Admin can generate a new QR code for any user.

### Tasks

- [ ] **3.1** Create `src/frontend/src/components/features/qr-management/useModalState.ts`
  - Modal kinds: `'closed' | 'generate_qr' | 'regenerate_confirm' | 'revoke_confirm'`
  - State: `{ kind, targetUid, targetTokenHash }`
  - Dispatch helpers: `openGenerate()`, `openRegenerate(uid)`, `openRevoke(tokenHash)`, `close()`

- [ ] **3.2** Create `src/frontend/src/components/features/qr-management/modals/GenerateQRModal.tsx`
  - Dialog from `@azblink/ui`
  - User select: fetch users list, searchable dropdown
  - ValiditySelector: import from `user-management/modals/ValiditySelector.tsx`
  - Delivery method: simple select (Display only / Email / SMS) — Email and SMS show "Coming soon" info
  - On submit: call `useGenerateQR()` mutation, invalidate QR codes + stats queries, close modal, show success toast
  - Form validation: user required, validity required

- [ ] **3.3** Wire modal into `QRManagementPage.tsx`
  - "Generate QR" button in PageHeader opens modal
  - Modal success callback: invalidate queries, optionally select the new QR in the list

**Commit**: `feat(qr-management): add generate QR modal (Phase 3)`

**Verify**: Generate QR modal opens, user can select user + validity, QR is generated, list and stats refresh.

---

## Phase 4: List Panel + Actions (Filter Tabs, Rows, Hover Actions)

**Goal**: Full list panel with filtering, pagination, and row actions.

### Tasks

- [ ] **4.1** Create `src/frontend/src/components/features/qr-management/QRStatusBadge.tsx`
  - Uses `qr-status-config.ts` for icon/color lookup
  - Renders Badge from `@azblink/ui` with status dot + label
  - data-testid per spec §7

- [ ] **4.2** Create `src/frontend/src/components/features/qr-management/QRRow.tsx`
  - Grid layout: `grid-cols-[2fr_100px_120px_100px_80px]` (per spec)
  - UserCell: avatar (initials + gradient) + name + org
  - QRStatusBadge
  - DeviceCell: device_info or "—"
  - TimeCell: relative time (formatDate helper)
  - HoverActions: audit log link icon button (opacity-0 → group-hover:opacity-100)
  - Selected state: `data-selected` or `aria-current="true"`
  - onClick: update URL param `qrId`

- [ ] **4.3** Create `src/frontend/src/components/features/qr-management/QRList.tsx`
  - ListHeader: title + count + FilterTabs (Tabs from @azblink/ui)
  - Filter tabs: All, Pending (count), Consumed, Expired, Revoked
  - Tab change updates URL `filter` param
  - Scrollable list of QRRow components
  - Loading skeleton
  - Empty state when no results

- [ ] **4.4** Wire list into `QRManagementPage.tsx`
  - Suspense-wrapped QRList with data fetching
  - Row click updates `qrId` URL param → detail panel shows

- [ ] **4.5** Implement Regenerate action
  - In detail panel: Regenerate button calls `openRegenerate(uid)` → shows confirm dialog
  - Confirm: revoke all tokens for user (`useRevokeQR`), then generate new (`useGenerateQR`)
  - Invalidate QR codes + stats queries on success
  - Toast: "QR regenerated for {user}"

**Commit**: `feat(qr-management): add list panel with filtering and actions (Phase 4)`

**Verify**: Filter tabs filter the list. Search works. Rows are selectable. Hover shows audit link. Regenerate works end-to-end.

---

## Phase 5: Authorization

**Goal**: Endpoints are properly secured.

### Tasks

- [ ] **5.1** Verify `require_admin` on both new endpoints
  - `GET /api/qr/codes` — admin only
  - `GET /api/qr/stats` — admin only
  - Existing generate/revoke endpoints already have correct auth

- [ ] **5.2** Add route guard (optional)
  - If non-admin users can access `/provisioning/qr-codes`, show "Access denied" instead of errors
  - Or rely on API 403 and show error state

**Commit**: `feat(qr-management): verify authorization (Phase 5)`

**Verify**: Non-admin users get 403. Admin users see full page.

---

## Phase 6: Polish

**Goal**: Responsive layout, accessibility, skeletons, empty states, redirect.

### Tasks

- [ ] **6.1** Add redirect from old route
  - In `src/frontend/src/routes/provisioning/qr-generator.tsx`: redirect to `/provisioning/qr-codes`
  - Preserve any URL params (e.g., `?uid=alice` → pass through)

- [ ] **6.2** Responsive breakpoints
  - `<1100px`: detail panel hidden, list takes full width
  - `<900px`: stats row 2 columns
  - `<500px`: stats row 1 column

- [ ] **6.3** Empty states
  - No QR codes at all: icon + "No QR codes generated yet" + "Generate your first QR code" CTA
  - No results for filter/search: icon + "No QR codes match" + clear filters link
  - No selection: icon + "Select a QR code to view details"

- [ ] **6.4** Loading skeletons
  - Stats row: 4 skeleton cards
  - List: 6 skeleton rows
  - Detail panel: skeleton header + skeleton info grid

- [ ] **6.5** Accessibility
  - `aria-current="true"` on selected row
  - `aria-live="polite"` on list count and stats
  - `aria-label` on icon-only buttons
  - `Cmd+K` / `Ctrl+K` search focus
  - Focus management: after generating QR, focus returns to list

- [ ] **6.6** DRY audit
  - Verify no duplicate `getInitials()` or `getOrgName()` — use shared imports
  - Verify no hardcoded colors — all from tokens or Tailwind bridge
  - Remove old `/provisioning/qr-generator` components if fully replaced

- [ ] **6.7** data-testid attributes per spec §7
  - `data-testid="qr-table"`, `data-testid="qr-row-{id}"`, etc.

**Commit**: `feat(qr-management): polish, responsive, a11y, empty states (Phase 6)`

**Verify**: Page looks correct at all breakpoints. All accessibility attributes present. Old route redirects. No duplicate code.

---

## File Manifest

### New Files (14)

| File | Purpose | Phase |
|------|---------|-------|
| `src/frontend/src/types/qr-management.ts` | Domain types | 0 |
| `src/frontend/src/components/features/qr-management/qr-status-config.ts` | Status icon/color config | 0 |
| `src/frontend/src/lib/queries/qr-management.ts` | Query hooks + mutations | 1 |
| `src/frontend/src/routes/provisioning/qr-codes.tsx` | Route file | 1 |
| `src/frontend/src/components/features/qr-management/QRManagementPage.tsx` | Page orchestrator | 1 |
| `src/frontend/src/components/features/qr-management/PageHeader.tsx` | Page header | 1 |
| `src/frontend/src/components/features/qr-management/StatsRow.tsx` | Stats cards | 2 |
| `src/frontend/src/components/features/qr-management/QRDetailPanel.tsx` | Detail panel | 2 |
| `src/frontend/src/components/features/qr-management/useModalState.ts` | Modal state machine | 3 |
| `src/frontend/src/components/features/qr-management/modals/GenerateQRModal.tsx` | Generate modal | 3 |
| `src/frontend/src/components/features/qr-management/QRStatusBadge.tsx` | Status badge | 4 |
| `src/frontend/src/components/features/qr-management/QRRow.tsx` | List row | 4 |
| `src/frontend/src/components/features/qr-management/QRList.tsx` | List panel | 4 |

### Modified Files (3)

| File | Change | Phase |
|------|--------|-------|
| `src/backend/main.py` | Add 2 new endpoints | 1 |
| `src/backend/orgdb.py` | Add `list_qr_codes()` + `get_qr_stats()` | 1 |
| `src/frontend/src/lib/queries/keys.ts` | Add QR management query keys | 0 |

### Redirect File (1)

| File | Change | Phase |
|------|--------|-------|
| `src/frontend/src/routes/provisioning/qr-generator.tsx` | Redirect to `/provisioning/qr-codes` | 6 |

---

## Commit Convention

```
feat(qr-management): <short description> (Phase N)
fix: address Phase N code review findings
docs: add QR management design doc and implementation plan
```

## Review Cadence

After EACH phase:
1. Spec compliance review — does the implementation match this plan?
2. Code quality review — bugs, security, DRY, a11y?
3. Fix all CRITICAL and IMPORTANT findings before proceeding
4. Commit fixes as a separate `fix:` commit

After ALL phases:
5. Full migration code review — cross-cutting concerns, backward compat, dead code
