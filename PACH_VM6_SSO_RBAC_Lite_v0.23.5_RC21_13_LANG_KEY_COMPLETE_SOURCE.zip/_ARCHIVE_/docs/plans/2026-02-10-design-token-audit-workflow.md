# Design Token Audit Workflow

Reusable process for auditing feature component styling against the `@azblink/ui` design system tokens. First applied to `org-management/` (2026-02-10).

## When to Run This Audit

- After building a new feature page with 5+ components
- Before a design system version bump
- When migrating from hardcoded values to tokens
- As part of quarterly UI consistency reviews

## Audit Checklist

### 1. Color Token Compliance

| Check | Pass Criteria |
|-------|--------------|
| No Tailwind color utilities (`text-blue-400`, `bg-emerald-500/10`) | All colors reference `var(--color-*)` tokens |
| No hardcoded hex/rgb in Tailwind arbitrary values | Use token var() references in `[]` brackets |
| Semantic aliases for domain-specific colors | e.g., `--color-org-root` aliases `--color-indigo-500` |
| Status colors use semantic tokens | `--color-success`, `--color-warning`, `--color-danger` |

**How to find violations:**
```bash
# Grep for Tailwind color classes (non-token)
rg 'text-(red|blue|green|emerald|amber|purple|indigo|cyan|pink|orange)-\d' src/frontend/src/components/features/<domain>/
rg 'bg-(red|blue|green|emerald|amber|purple|indigo|cyan|pink|orange)-\d' src/frontend/src/components/features/<domain>/
rg 'border-(red|blue|green|emerald|amber|purple|indigo|cyan|pink|orange)-\d' src/frontend/src/components/features/<domain>/
```

### 2. Icon Container Sizes

| Token | Size | Use For |
|-------|------|---------|
| `--icon-container-sm` | 32px | List rows, inline cards, tree nodes |
| `--icon-container-md` | 40px | Stat cards, toggle cards |
| `--icon-container-lg` | 56px | Panel headers, hero sections |

**How to find violations:**
```bash
# Grep for hardcoded icon sizes
rg 'h-[789] w-[789]|h-1[0-6] w-1[0-6]' src/frontend/src/components/features/<domain>/
```

### 3. Typography Token Usage

| Pattern | Primitive (CSS Modules) | Feature (Tailwind) |
|---------|------------------------|-------------------|
| Font size | `var(--text-sm)` | `text-sm` or `text-[var(--text-sm)]` |
| Font weight | `var(--font-medium)` | `font-medium` |
| Line height | `var(--leading-snug)` | `leading-snug` |

**Rule:** Within a single component, don't mix patterns. Use either:
- Pure Tailwind utilities (rely on `globals.css` @theme bridge)
- Pure `var()` in `text-[var(...)]` brackets

### 4. Spacing Consistency

- All gaps, padding, margins should map to `--space-*` tokens
- Common Tailwind equivalents: `gap-3` = `--space-3` (12px), `p-4` = `--space-4` (16px)
- Flag any value not in the token scale (e.g., `gap-7` = 28px has no token)

### 5. Repeated Patterns

- Section headings repeated across files -> extract shared component
- Card wrappers with identical class strings -> evaluate primitive candidate
- Config objects with hardcoded styling -> centralize with token references

## Fix Strategies (Priority Order)

1. **Semantic aliases** - Create thin aliases in `tokens.css` pointing to existing palette tokens (zero new color values)
2. **Shared components** - Extract repeated UI patterns (e.g., `SectionHeading`)
3. **Token references** - Replace hardcoded Tailwind classes with `var()` references
4. **Grid unification** - Replace ad-hoc `grid grid-cols-*` with `DetailGrid` primitive where applicable

## Applied: org-management/ (2026-02-10)

### Tokens Added
- 8 org-type semantic color aliases (`--color-org-root`, `--color-org`, etc.)
- 3 icon container sizes (`--icon-container-sm/md/lg`)

### Components Created
- `SectionHeading.tsx` - shared section heading (replaced 8+ inline duplicates)

### Files Modified (13)
- `tokens.css` - new token definitions
- `org-type-config.ts` - Tailwind colors -> token var() references
- `StatCard.tsx` - added bg, icon size token
- `StatsRow.tsx` - icon colors -> semantic tokens
- `ChildOrgItem.tsx` - icon size token
- `PanelHeader.tsx` - icon size token
- `SSOBadge.tsx` - emerald -> success tokens
- `CopyableDN.tsx` - emerald check -> success token
- `QRSettingItem.tsx` - icon size token
- `OrgUserRow.tsx` - avatar size token
- `OverviewTab.tsx` - SectionHeading + DetailGrid
- `SSOConfigTab.tsx` - SectionHeading + DetailGrid
- `ProvisioningTab.tsx` - SectionHeading + DetailGrid
- `UsersTab.tsx` - SectionHeading

### Not Modified (acceptable exceptions)
- `ProvisioningTab.tsx` `<legend>` - kept inline classes (semantic HTML requires `<legend>`, not `<h3>`)
- `TreeNode.tsx` - auto-fixed via org-type-config inheritance
- Modal files - use primitives, already compliant
