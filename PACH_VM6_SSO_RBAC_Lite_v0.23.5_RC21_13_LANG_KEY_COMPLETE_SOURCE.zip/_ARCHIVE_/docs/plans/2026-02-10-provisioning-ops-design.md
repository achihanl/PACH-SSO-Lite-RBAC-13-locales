# Provisioning Operations Page — Design

**Date:** 2026-02-10
**Route:** `/provisioning/tokens` (repurposed)
**Status:** Design reviewed and updated — ready for implementation planning
**Reviews:** Feature dev architecture review + UI/UX design review (2026-02-10)

## Context

The `/provisioning/tokens` page is a v1 rough draft — a flat `DataTable` of `qr_issuance_audit` records with placeholder buttons. The QR Codes page (`/provisioning/qr-codes`) and Audit Log (`/audit-log`) now cover individual QR tracking and audit trails respectively, but three operational gaps remain:

1. **Token lifecycle ops** — bulk revoke, extend expiry, generate new
2. **Device provisioning tracking** — which devices consumed which tokens, stuck provisions
3. **Compliance monitoring** — anomaly detection, wastage, security flags

This design repurposes the tokens page into "Provisioning Operations" — a hybrid dashboard + tabbed split-panel that fills these gaps.

### Token status state machine (critical context)

The `provision_tokens.status` column uses these values:

```
active → consumed    (via validate_and_consume_token)
active → used        (via mark_provision_token_used — legacy path)
active → revoked_terminated  (via revoke_tokens_for_user)
active → revoked     (via rotate_qr / manual revoke)
active → [unchanged] (natural expiry — no background job, evaluated at read time)
```

**Important:** Token expiry is evaluated at read time. There is no background job that changes status when a token expires. Queries for "expired" tokens use `status = 'active' AND expires_at < NOW()`. Queries for "consumed" tokens must check `status IN ('used', 'consumed')` to cover both code paths.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Dashboard Header (6 stat cards)                            │
│  Desktop: 3x2 grid | Mobile: 2-card summary + expandable   │
├─────────────────────────────────────────────────────────────┤
│  [Lifecycle]  [Devices]  [Compliance]     ← Tab bar         │
├──────────────────────────────┬──────────────────────────────┤
│  DataTable (left)            │  DetailPanel (right)         │
│  - filters/chips             │  - contextual detail         │
│  - rows with actions         │  - action buttons            │
│  - pagination                │  - cross-nav links           │
└──────────────────────────────┴──────────────────────────────┘
```

**Layout:** Dashboard header + tabbed split-panel (reuses existing `DataTable`, `DetailGrid`, `FieldCard`, `Tabs`, `ToggleChipGroup`, `Pagination`, `AlertDialog`, `Skeleton`, `Checkbox` primitives).

**State management:** URL search params only (no Zustand) — same pattern as QR Codes and Audit Log pages. Tab-specific params (`tokenHash`, `deviceId`) are preserved across tab switches so returning to a tab restores the previous selection.

### Interaction patterns

- **Cmd/Ctrl+K** — focus search input (per existing pattern)
- **Escape** — close detail panel, deselect row
- **Arrow Up/Down** — navigate list rows (when list focused)
- **Tab keyboard nav** — handled by Base UI `Tabs` primitive (arrow keys on tab bar)

---

## Section 1: Dashboard Header

Always-visible stat cards (~120px tall on desktop). Each card is clickable and switches to the relevant tab with a pre-filter.

**Desktop (>768px):** 3x2 grid, all 6 cards visible.
**Mobile (<768px):** 2-card summary row showing Active Tokens + Compliance Alerts only, with "View all stats" disclosure that expands to show the remaining 4 cards. This prevents the dashboard from consuming the entire mobile viewport before actionable content.

**Loading state:** Each card renders at final dimensions with `Skeleton` placeholder blocks (number + label) while `GET /api/qr/stats` loads. Prevents layout shift.

| Card | Metric | Source | Visual |
|------|--------|--------|--------|
| **Active Tokens** | Tokens with status=active, not expired | Existing `pending` from `GET /api/qr/stats` | Number + amber dot |
| **Expiring Soon** | Tokens expiring within 24h | **New** field: `expiring_24h` | Number + red pulse if > 0 |
| **Devices Provisioned** | Unique devices that consumed tokens in period | **New** field: `active_devices` | Number + trend arrow |
| **Stale Active** | Tokens past 80% of TTL, not consumed | **New** field: `stale_active` | Number + amber badge if > 0 |
| **Consumption Rate** | consumed / total_generated as % | Derived from existing fields | Percentage + trend |
| **Compliance Alerts** | Tokens with anomalies | **New** field: `compliance_alert_count` | Number + red badge if > 0 |

> **Design decision:** "Avg Provision Time" was replaced with "Stale Active" per UI/UX review. Every dashboard card should answer "What do I need to do?" — avg provision time is analytics, not operational. Stale Active is directly actionable (extend or revoke) and clicks through to the Lifecycle tab.

### Backend: Extend `GET /api/qr/stats`

Add 4 new fields to existing response. Note correct column references:

```python
# expiring_24h (from provision_tokens)
COUNT(*) WHERE status = 'active'
  AND expires_at BETWEEN NOW() AND NOW() + INTERVAL '24 hours'

# active_devices (from provision_tokens)
COUNT(DISTINCT consumed_by_device_id)
  WHERE consumed_by_device_id IS NOT NULL
  AND used_at >= <period_start>  -- NOTE: column is used_at, not consumed_at

# stale_active (from provision_tokens)
COUNT(*) WHERE status = 'active'
  AND expires_at > NOW()
  AND (NOW() - issued_at) > 0.8 * (expires_at - issued_at)

# compliance_alert_count
# Sum of all alert conditions (computed inline or via subquery)
```

### Frontend type extension

```typescript
// Extend existing QRStats in types/qr-management.ts
interface QRStats {
  // ... existing fields ...
  expiring_24h: number;
  active_devices: number;
  stale_active: number;
  compliance_alert_count: number;
}
```

---

## Section 2: Tab 1 — Lifecycle

**Purpose:** Operational actions on tokens grouped by urgency/state.

### Left panel (DataTable)

Uses the `DataTable` primitive (not `ListPanel`) because this tab has 6 columnar fields including sortable headers and an ACTIONS column — `DataTable` provides proper column alignment, sort indicators, and cell alignment.

**Filter chips** (reusing `ToggleChipGroup`):
- `Expiring Soon` (amber pulse) — tokens expiring within 24h
- `Active` — status=active, not expiring soon
- `Expired Unused` — expired but never consumed (wastage)
- `Revoked` — admin-revoked tokens

**Columns:** USER | TOKEN | ISSUED | EXPIRES | STATUS | ACTIONS
- TOKEN: mono font, truncated hash (8 chars), click-to-copy with tooltip showing full hash
- EXPIRES: relative time with color coding (red if <4h, amber if <24h)
- ACTIONS: inline buttons per row

**Row actions (contextual by status):**

| Status | Actions |
|--------|---------|
| Active | **Revoke** (ghost, red) |
| Expiring Soon | **Extend** (outline) + **Revoke** (ghost, red) |
| Expired Unused | **Generate New** (outline, purple) — opens Generate QR modal pre-filled with user UID |
| Revoked | None (read-only) |

> **Design decision:** "Re-issue" was replaced with "Generate New" per both reviews. There is no per-token re-issue endpoint — generating a new QR for the same user is the correct operation, and it reuses the existing `useGenerateQR` mutation and `GenerateQRModal`.

**Bulk actions bar** (appears when `Checkbox` selections active):
- "X tokens selected" + **Bulk Revoke** + **Bulk Generate New**
- Checkbox in column header for select-all-on-page
- **Bulk Revoke requires `AlertDialog` confirmation** showing: count of tokens, list of affected users (truncated at 5 + "+N more"), irreversibility warning

**Sort:** Default `expires_at ASC` (soonest expiring first).

**Data source:** Extend existing `GET /api/qr/codes` with new pseudo-status values `expiring_soon` and `active_stable` to support compound filter conditions server-side.

**Empty state:** `EmptyState` with KeyRound icon + "No tokens match the current filters".

### Right panel (detail on row click)

- Sections: Token Details, User Info, Timeline (reuse `QRHistoryEntry` pattern)
- Action buttons at top: Revoke / Extend / Generate New (same as row but larger)
- Cross-nav: "View QR Code →" to `/provisioning/qr-codes?qrId=...`
- Cross-nav: "View Audit Log →" to `/audit-log?qr=...`
- **Empty state (no selection):** "Select a token to view details" with KeyRound icon

### Backend: New/modified endpoints

**Extend `GET /api/qr/codes`** — add pseudo-status support:
- `status=expiring_soon`: WHERE status='active' AND expires_at BETWEEN NOW() AND NOW()+24h
- `status=active_stable`: WHERE status='active' AND expires_at > NOW()+24h

**`POST /api/provisioning/tokens/bulk-revoke`**
```json
// Request
{ "token_hashes": ["abc123...", "def456..."] }

// Response
{
  "ok": true,
  "revoked_count": 2,
  "skipped_count": 1,
  "errors": [
    { "token_hash": "ghi789...", "reason": "already_expired" }
  ]
}
```
- Requires admin permission
- Maximum batch size: 100 tokens
- Audit log entry per revocation
- New method: `OrgDB.bulk_revoke_tokens(hashes: List[str]) -> dict`

**`POST /api/provisioning/tokens/{hash}/extend`**
```json
// Request
{ "extend_seconds": 3600 }

// Response
{
  "ok": true,
  "token_hash": "abc123...",
  "new_expires_at": "2026-02-11T12:00:00Z"
}
```
- Requires admin permission
- Only active (non-expired, non-consumed) tokens can be extended
- **Capped at `ORG_QR_MAX_TTL_SEC`** — returns 422 if resulting expiry would exceed max
- New method: `OrgDB.extend_token_expiry(hash: str, extend_sec: int) -> dict`

### Error handling (toast pattern)

| Result | Toast Style | Behavior |
|--------|-------------|----------|
| Success | Green | "2 tokens revoked successfully" — auto-dismiss 5s |
| Partial failure | Amber | "3 of 5 tokens revoked. 2 already expired." — manual dismiss |
| Error | Red | "Failed to revoke tokens. Please try again." — manual dismiss |

---

## Section 3: Tab 2 — Devices

**Purpose:** Track which devices consumed tokens, identify provisioning failures, device inventory.

> **Important note:** Device info (`consumed_by_device_id`, `client_platform`, `client_version`) is only populated when consuming clients send device headers. This tab may be empty for deployments where clients don't provide this data.

### Left panel (DataTable)

**Filter chips:**
- `Recently Provisioned` — consumed in last 24h
- `Multi-token` — devices that consumed 2+ tokens (re-provisions)
- `Unknown Platform` — consumed_by_device_id exists but client_platform is null

**Columns:** DEVICE ID | PLATFORM | USER | PROVISIONED AT | TOKEN STATUS | IP ADDRESS
- DEVICE ID: mono font, truncated, click-to-copy
- PLATFORM: badge with icon (iOS / Android / Desktop / Unknown)

**Sort:** Default `used_at DESC` (most recent provisions first). Note: column is `used_at` on `provision_tokens`, not `consumed_at`.

> **Design decision:** The accordion grouped-by-user view was dropped per UI/UX review. The "Multi-token" filter chip already surfaces re-provisioned devices. Flat list with filter chips is consistent with how all other tabs work, and avoids pagination/keyboard-nav complications from accordion patterns.

**Empty state:** "No device data available. Device information is recorded when clients include device headers during QR provisioning." with Smartphone icon.

### Right panel (detail on device click)

- **Device Summary:** device_id, platform, client_version, IP, user_agent
- **Provisioning History:** all tokens this device consumed (timeline view)
  - Highlights if device consumed tokens for multiple users (shared device flag — amber warning)
- Cross-nav: "View User →" to user management
- Cross-nav: "View QR Code →" per token
- **Empty state:** "Select a device to view provisioning history" with Smartphone icon

### Backend: New endpoints

**`GET /api/provisioning/devices`**
```
Query params: limit, offset, search, date_range, platform_filter
```
```json
// Response
{
  "ok": true,
  "devices": [
    {
      "device_id": "iPhone14-abc",
      "platform": "iOS",
      "client_version": "1.2.3",
      "ip_address": "192.168.1.100",
      "user_uid": "alice.chen",
      "user_display_name": "Alice Chen",
      "consumed_at": "2026-02-10T15:30:42Z",
      "token_hash": "abc123...",
      "token_count": 2
    }
  ],
  "total": 42,
  "limit": 50,
  "offset": 0
}
```
- New method: `OrgDB.list_provisioned_devices()`
- Queries `provision_tokens` WHERE `consumed_by_device_id IS NOT NULL`
- JOINs with `qr_issuance_audit` for LDAP enrichment

**`GET /api/provisioning/devices/{device_id}/history`**
```json
// Response
{
  "ok": true,
  "device_id": "iPhone14-abc",
  "history": [
    {
      "token_hash": "abc123...",
      "user_uid": "alice.chen",
      "consumed_at": "2026-02-10T15:30:42Z",
      "status": "consumed",
      "platform": "iOS",
      "client_version": "1.2.3"
    }
  ]
}
```
- New method: `OrgDB.get_device_token_history(device_id: str)`

### Frontend types

```typescript
// types/provisioning-ops.ts
export interface ProvisionedDevice {
  device_id: string;
  platform: string | null;
  client_version: string | null;
  ip_address: string | null;
  user_uid: string;
  user_display_name: string;
  consumed_at: string;
  token_hash: string;
  token_count: number;
}
```

---

## Section 4: Tab 3 — Compliance

**Purpose:** Surface anomalies, security risks, and operational waste.

### Alert types

| Alert Type | Condition | Severity | Icon | Badge variant |
|------------|-----------|----------|------|---------------|
| `expired-unused` | Token expired without consumption | Warning (amber) | Clock | `warning` |
| `rapid-consumption` | Token consumed within <60s of issuance | Warning (amber) | Zap | `warning` |
| `multi-issue` | Same user has 3+ active tokens simultaneously | Warning (amber) | AlertTriangle | `warning` |
| `stale-active` | Token active but >80% of TTL elapsed | Low | Hourglass | `outline` |
| `cross-user-device` | Device consumed tokens for 2+ different users | Critical (red) | ShieldAlert | `error` |
| `high-failure-rate` | User has >3 expired-unused tokens in 30 days | Warning (amber) | TrendingDown | `warning` |

> **Design decisions from review:**
> - `rapid-consumption` severity changed from "info" (blue) to "warning" (amber) — sub-60s consumption is unusual enough to warrant attention, not just informational. Blue was also semantically overloaded (already means "QR Generated" in audit-event-config).
> - `stale-active` severity uses `outline` badge variant instead of `muted` (gray) — gray badges are invisible in dark theme.

### Layout

**Top:** Alert summary strip — horizontal cards, one per alert type with count + severity badge. Clicking a card filters the list below. Uses `flex-wrap` with `gap-2`; wraps to 2 columns on mobile. If all counts are zero, collapse strip and show "All clear — no compliance issues detected" positive state.

**Bottom:** Alert list (ListPanel)

**Loading state:** `Skeleton` placeholders for both summary strip and alert list while `GET /api/provisioning/compliance` loads. This endpoint may be slow (6 queries); see performance section.

**Columns:** SEVERITY | ALERT TYPE | SUBJECT | DETAIL | DETECTED | ACTION

**Actions by alert type:**

| Alert Type | Actions |
|------------|---------|
| expired-unused | Generate New (opens modal pre-filled), Dismiss |
| rapid-consumption | View in Audit Log |
| multi-issue | Revoke Oldest, Revoke All (with AlertDialog confirmation) |
| stale-active | Extend, Revoke |
| cross-user-device | View Device History (switches to Devices tab) |
| high-failure-rate | View User (cross-nav) |

**Dismiss mechanism:** Dismissed alerts stored in `localStorage` with 24h TTL (keyed by alert ID). Alerts reappear after 24h if the condition persists. This prevents alert fatigue without requiring a database table.

> **Design decision:** Changed from session-scoped to localStorage+TTL per UI/UX review. Session-scoped dismiss creates alert fatigue — operators who investigate and dismiss an alert see it again immediately on refresh, leading to learned helplessness.

### Right panel (detail on alert click)

- Alert description + severity explanation
- Evidence section: specific tokens/devices/users involved, with links
- Recommended action text (e.g., "This user has 3 unexpired tokens. Consider revoking older ones to reduce exposure.")
- Action buttons matching row actions
- **Empty state:** "Select an alert to view details" with ShieldCheck icon

### Backend: New endpoint

**`GET /api/provisioning/compliance`**
```json
// Response
{
  "ok": true,
  "alerts": [
    {
      "id": "CMP-001",
      "type": "cross-user-device",
      "severity": "critical",
      "subject_uid": null,
      "subject_device_id": "iPhone14-abc",
      "description": "Device consumed tokens for 2 different users",
      "detected_at": "2026-02-10T15:30:42Z",
      "evidence": {
        "users": ["alice.chen", "bob.smith"],
        "token_hashes": ["abc123...", "def456..."]
      },
      "recommended_action": "Investigate shared device usage"
    }
  ],
  "summary": {
    "expired-unused": 12,
    "rapid-consumption": 3,
    "multi-issue": 1,
    "stale-active": 8,
    "cross-user-device": 0,
    "high-failure-rate": 2
  }
}
```

**Cache:** Server-side 60s cache TTL on this endpoint — compliance alerts don't need real-time freshness and the underlying queries are expensive.

SQL queries (all from existing tables). Note correct status values:

```sql
-- expired-unused (status stays 'active' — expiry is read-time evaluation)
SELECT * FROM provision_tokens
WHERE status = 'active' AND expires_at < NOW();

-- rapid-consumption (JOIN for issued_at, check both consumed statuses)
SELECT * FROM provision_tokens pt
JOIN qr_issuance_audit qa ON pt.token_hash = qa.token_hash
WHERE pt.status IN ('used', 'consumed')
AND pt.used_at - qa.issued_at < INTERVAL '60 seconds';

-- multi-issue
SELECT uid, COUNT(*) FROM provision_tokens
WHERE status = 'active' AND expires_at > NOW()
GROUP BY uid HAVING COUNT(*) > 2;

-- stale-active
SELECT * FROM provision_tokens
WHERE status = 'active' AND expires_at > NOW()
AND (NOW() - issued_at) > 0.8 * (expires_at - issued_at);

-- cross-user-device
SELECT consumed_by_device_id, COUNT(DISTINCT uid)
FROM provision_tokens
WHERE consumed_by_device_id IS NOT NULL
GROUP BY consumed_by_device_id
HAVING COUNT(DISTINCT uid) > 1;

-- high-failure-rate (exclude both consumed statuses)
SELECT uid, COUNT(*) FROM provision_tokens
WHERE status NOT IN ('used', 'consumed')
AND issued_at > NOW() - INTERVAL '30 days'
GROUP BY uid HAVING COUNT(*) > 3;
```

- New method: `OrgDB.compute_compliance_alerts() -> dict`
- **Performance:** Consider combining into a single CTE-based query to reduce round-trips.

### Frontend types

```typescript
// types/provisioning-ops.ts
export type ComplianceAlertType =
  | 'expired-unused'
  | 'rapid-consumption'
  | 'multi-issue'
  | 'stale-active'
  | 'cross-user-device'
  | 'high-failure-rate';

export type AlertSeverity = 'critical' | 'warning' | 'info' | 'low';

export interface ComplianceAlert {
  id: string;
  type: ComplianceAlertType;
  severity: AlertSeverity;
  subject_uid: string | null;
  subject_device_id: string | null;
  description: string;
  detected_at: string;
  evidence: Record<string, unknown>;
  recommended_action: string;
}

export type ComplianceSummary = Record<ComplianceAlertType, number>;

export interface ComplianceResponse {
  ok: true;
  alerts: ComplianceAlert[];
  summary: ComplianceSummary;
}
```

---

## Section 5: Cross-Page Navigation

### Inbound (other pages → Provisioning Ops)

| From | Trigger | Lands on |
|------|---------|----------|
| QR Codes detail panel | "View Token →" link | Lifecycle tab, token pre-selected via `?tokenHash=...` |
| Audit Log detail panel | Click token reference | Lifecycle tab, token pre-selected via `?tokenHash=...` |
| Sidebar nav | "Provisioning Ops" | Dashboard header (default view) |

### Outbound (Provisioning Ops → other pages)

| From | Trigger | Goes to |
|------|---------|---------|
| Lifecycle detail | "View QR Code →" | `/provisioning/qr-codes?qrId=...` |
| Lifecycle detail | "View Audit Log →" | `/audit-log?qr=...` |
| Devices detail | "View User →" | `/directory/users?uid=...` |
| Compliance alert | "View Device History" | Devices tab (same page, tab switch + filter) |
| Compliance alert | "View in Audit Log" | `/audit-log?qr=...` |

### URL search params

```typescript
export interface ProvisioningOpsSearchParams {
  tab?: 'lifecycle' | 'devices' | 'compliance';
  tokenHash?: string;    // pre-select token in lifecycle (uses token_hash, not id)
  deviceId?: string;     // pre-select device in devices
  alertType?: string;    // pre-filter compliance alerts
  dateRange?: '7d' | '30d' | '90d' | 'all';  // shared across tabs, persists on tab switch
  search?: string;       // tab-scoped search
  page?: number;         // tab-scoped pagination
}
```

> **Design decision:** `tokenId` renamed to `tokenHash` per review to avoid ambiguity with QR issuance IDs. `dateRange` is shared across tabs and persists on tab switch.

### Sidebar update

- Replace "QR Generator" with **"QR Codes"** → `/provisioning/qr-codes` (fixes broken redirect link)
- Rename "Tokens" to **"Provisioning Ops"** → `/provisioning/tokens`
- Sidebar badge: show dot indicator only for `critical` severity alerts (currently only `cross-user-device`). Amber dot for warnings, red dot for critical. This prevents notification fatigue from routine alerts.

---

## Implementation Summary

### Backend changes

| Change | Endpoint | orgdb.py method |
|--------|----------|-----------------|
| Extend | `GET /api/qr/stats` | `get_qr_stats()` — 4 new fields |
| Extend | `GET /api/qr/codes` | `list_qr_codes()` — add `expiring_soon`, `active_stable` pseudo-statuses |
| New | `POST /api/provisioning/tokens/bulk-revoke` | `bulk_revoke_tokens()` |
| New | `POST /api/provisioning/tokens/{hash}/extend` | `extend_token_expiry()` |
| New | `GET /api/provisioning/devices` | `list_provisioned_devices()` |
| New | `GET /api/provisioning/devices/{id}/history` | `get_device_token_history()` |
| New | `GET /api/provisioning/compliance` | `compute_compliance_alerts()` |

### Database: New migration required

Despite initially claiming no migrations, performance indexes are needed for the compliance queries:

```sql
-- Migration 007: Provisioning Operations indexes
CREATE INDEX IF NOT EXISTS idx_pt_device
ON provision_tokens(consumed_by_device_id) WHERE consumed_by_device_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_pt_issued_at
ON provision_tokens(issued_at DESC);
```

### Frontend changes

| Layer | File | Action |
|-------|------|--------|
| Route | `routes/provisioning/tokens.tsx` | **Rewrite** |
| Types | `types/provisioning-ops.ts` | **New** |
| Types | `types/qr-management.ts` | **Extend** QRStats |
| Types | `types/index.ts` | **Extend** barrel export |
| Queries | `lib/queries/provisioning-ops.ts` | **New** |
| Queries | `lib/queries/keys.ts` | **Extend** with provisioning ops keys |
| Page | `components/features/provisioning-ops/ProvisioningOpsPage.tsx` | **New** |
| Page | `components/features/provisioning-ops/DashboardHeader.tsx` | **New** |
| Tab 1 | `components/features/provisioning-ops/LifecycleTab.tsx` | **New** |
| Tab 1 | `components/features/provisioning-ops/LifecycleRow.tsx` | **New** |
| Tab 1 | `components/features/provisioning-ops/LifecycleDetailPanel.tsx` | **New** |
| Tab 2 | `components/features/provisioning-ops/DevicesTab.tsx` | **New** |
| Tab 2 | `components/features/provisioning-ops/DeviceDetailPanel.tsx` | **New** |
| Tab 3 | `components/features/provisioning-ops/ComplianceTab.tsx` | **New** |
| Tab 3 | `components/features/provisioning-ops/ComplianceDetailPanel.tsx` | **New** |
| Config | `components/features/provisioning-ops/alert-type-config.ts` | **New** |
| Modify | `components/features/qr-management/QRDetailPanel.tsx` | Add "View Token →" |
| Modify | Sidebar component | Fix QR link + rename + alert dot |

No new primitives — composes from existing `DataTable`, `ListPanel`, `DetailGrid`, `FieldCard`, `Badge`, `ToggleChipGroup`, `Tabs`, `Pagination`, `AlertDialog`, `Skeleton`, `Checkbox`.

### Excluded from v1 (YAGNI)

- Device blocking/MDM actions (no device registry)
- Configurable alert thresholds (hardcoded: 60s rapid, 3 multi-issue, 80% stale)
- Email/webhook alert notifications
- CSV/PDF export (placeholder only)
- WebSocket live updates (decorative pulse only)
- Accordion grouped-by-user view on Devices tab
- Per-token re-issue endpoint (uses existing Generate QR modal instead)

---

## Appendix: Review Feedback Log

### Feature Dev Review — Issues Addressed

| ID | Severity | Issue | Resolution |
|---|---|---|---|
| FC1 | Critical | Token status `"used"` vs `"consumed"` mismatch in SQL | Fixed all SQL to use `IN ('used', 'consumed')` / `NOT IN (...)` |
| FC2 | Critical | `avg_provision_time_ms` references non-existent `consumed_at` column | Replaced metric with `stale_active`; fixed column refs to `used_at` |
| FC3 | Critical | Expired tokens keep status=active (no background job) | Added token status state machine documentation |
| FI1 | Important | No re-issue endpoint defined | Replaced "Re-issue" with "Generate New" using existing modal |
| FI2 | Important | Devices tab may be entirely empty | Added empty state with explanation |
| FI3 | Important | 6 compliance queries need indexes | Added migration 007 with 2 indexes; added CTE suggestion + cache TTL |
| FI4 | Important | Lifecycle filters need compound conditions | Extended `GET /api/qr/codes` with pseudo-statuses |
| FI5 | Important | Sidebar has broken QR Generator link | Fixed sidebar spec: "QR Codes" + "Provisioning Ops" |
| FI6 | Important | Bulk revoke response doesn't handle partial failures | Response now includes `revoked_count`, `skipped_count`, `errors` |
| FI7 | Important | Extend endpoint has no max guard | Capped at `ORG_QR_MAX_TTL_SEC` with 422 response |

### UI/UX Review — Issues Addressed

| ID | Severity | Issue | Resolution |
|---|---|---|---|
| UC1 | Critical | Dashboard header ~720px on mobile | Collapsed to 2-card summary + expandable on <768px |
| UC2 | Critical | Session-scoped dismiss causes alert fatigue | Changed to localStorage with 24h TTL |
| UC3 | Critical | Bulk revoke lacks confirmation dialog | Requires AlertDialog confirmation with user list |
| UI1 | Important | "Avg Provision Time" is vanity metric | Replaced with "Stale Active" |
| UI2 | Important | Accordion grouping underspecified | Dropped accordion for v1 |
| UI3 | Important | "Low" severity gray invisible in dark theme | Changed to `outline` badge variant |
| UI4 | Important | No loading states for stat cards | Added Skeleton placeholders spec |
| UI5 | Important | Tab switching transition unspecified | Preserve per-tab params; show tab-specific empty state |
| UI6 | Important | Error states for bulk ops not designed | Added toast pattern table (green/amber/red) |
| UI7 | Important | "Re-issue" has no backend endpoint | Same as FI1: "Generate New" via existing modal |
| M1 | Minor | 6-column list should use DataTable | Changed from ListPanel to DataTable |
| M2 | Minor | Token hash needs copy-to-clipboard | Added click-to-copy with tooltip |
| M3 | Minor | Alert summary strip responsive unspecified | Added flex-wrap + "All clear" collapse |
| M4 | Minor | Sidebar badge causes notification fatigue | Changed to dot indicator for critical only |
| M5 | Minor | Missing keyboard shortcut spec | Added Cmd+K, Escape, arrow keys |
| M6 | Minor | Blue color overloaded | Changed "Re-issue" to purple; rapid-consumption to amber |
| M7 | Minor | ComplianceSummary TypeScript syntax error | Changed to `Record<ComplianceAlertType, number>` |
