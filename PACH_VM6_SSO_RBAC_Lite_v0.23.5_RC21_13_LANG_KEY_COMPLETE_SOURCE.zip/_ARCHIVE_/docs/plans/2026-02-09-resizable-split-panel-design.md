# Resizable Split Panel Design

**Date:** 2026-02-09
**Status:** Approved
**Scope:** User, Group, and Org management pages

## Problem

All three management pages use fixed-width CSS Grid split panels. Users cannot adjust the panel widths to suit their workflow (e.g., wider detail panel when reviewing provisioning, narrower list when scanning names).

## Solution

A lightweight `useResizablePanel` hook + `<ResizeHandle>` component. Zero external dependencies. All three management pages adopt the same pattern.

## Architecture

```
useResizablePanel (hook)
├── Tracks leftWidth state (px)
├── Handles mouse drag events on document
├── Clamps to min-widths on drag + window resize
├── Persists to localStorage on drag end
└── Double-click resets to default

ResizeHandle (component)
├── role="separator" with aria attributes
├── Visible 3px line on hover, primary color while dragging
├── 12px invisible hit area for easy grabbing
└── Keyboard: Left/Right arrows nudge ±20px
```

## Width Constraints

| Page | Left Min | Left Default | Right Min | Storage Key |
|------|----------|-------------|-----------|-------------|
| Users | 280px | `container - 400px` | 320px | `panel-width:user-management` |
| Groups | 280px | `container - 420px` | 340px | `panel-width:group-management` |
| Orgs | 200px | 320px | 400px | `panel-width:org-management` |

## Hook API

```ts
interface UseResizablePanelOptions {
  storageKey: string;
  defaultLeftWidth: number;  // 0 = auto-calculate
  minLeftWidth: number;
  minRightWidth: number;
}

interface UseResizablePanelReturn {
  leftWidth: number;
  containerRef: RefObject<HTMLDivElement>;
  handleMouseDown: (e: MouseEvent) => void;
  handleDoubleClick: () => void;
  isDragging: boolean;
}
```

## ResizeHandle Component

- Thin vertical bar: 3px visible, 12px hit area
- Transparent by default, subtle on hover, primary color while dragging
- `role="separator"` + `aria-orientation="vertical"`
- Keyboard: Arrow Left/Right nudge ±20px, focus-visible ring
- Hidden on mobile (`hidden lg:flex`)

## Integration Pattern

**Before (CSS Grid, fixed):**
```tsx
<div className="grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-6 h-[calc(...)]">
  <LeftPanel />
  <div className="hidden lg:flex ..."><RightPanel /></div>
</div>
```

**After (flex + hook):**
```tsx
const { leftWidth, containerRef, handleMouseDown, handleDoubleClick, isDragging } =
  useResizablePanel({ storageKey: '...', defaultLeftWidth: 0, minLeftWidth: 280, minRightWidth: 320 });

<div ref={containerRef} className="flex h-[calc(...)]">
  <div style={{ width: leftWidth }} className="flex-shrink-0 hidden lg:flex">
    <LeftPanel />
  </div>
  <ResizeHandle className="hidden lg:flex" onMouseDown={handleMouseDown}
    onDoubleClick={handleDoubleClick} isDragging={isDragging} />
  <div className="flex-1 min-w-0 hidden lg:flex"><RightPanel /></div>
</div>
```

## Files

| Action | File |
|--------|------|
| **Create** | `src/frontend/src/hooks/useResizablePanel.ts` |
| **Create** | `src/frontend/src/components/layout/ResizeHandle.tsx` |
| **Modify** | `src/frontend/src/components/features/user-management/UserManagementPage.tsx` |
| **Modify** | `src/frontend/src/components/features/org-management/OrgManagementPage.tsx` |
| **Modify** | `src/frontend/src/components/features/group-management/GroupManagementPage.tsx` |

## Behavior Details

- **Drag:** `mousemove`/`mouseup` on `document` (works even if cursor leaves handle)
- **Smooth updates:** `requestAnimationFrame` during drag
- **Persistence:** `localStorage.setItem` on drag end (not during drag)
- **Window resize:** Re-clamp widths via `resize` event listener
- **Double-click:** Reset to default width
- **Mobile:** Unchanged — handle hidden, panels stack vertically

## What Does NOT Change

- Child components (UserList, GroupList, OrgTree, all detail panels)
- State management, data fetching, routing
- Mobile responsive stacking behavior
- Design tokens or @azblink/ui package
