# Group Detail Panel Tabs Migration — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Migrate the group detail panel from scrolling vertical sections to a tabbed interface (Overview, Members, Permissions) matching the org detail panel pattern.

**Architecture:** Extract the three inline sections (`InfoSection`, `MembersSection`, `PermissionsSection`) from `GroupDetailPanel.tsx` into dedicated tab files. Add a `GroupDetailTabs.tsx` container mirroring `org-management/DetailTabs.tsx`. Wire tab state through URL search params for persistence.

**Tech Stack:** React 19, @azblink/ui Tabs primitive (Base UI), TanStack Router (search params), TanStack Query (mutations), TypeScript

---

## Task 1: Add `tab` to URL Search Params

**Files:**
- Modify: `src/frontend/src/types/group.ts` (add GroupTab type)
- Modify: `src/frontend/src/components/features/group-management/GroupManagementPage.tsx:25-31` (add tab to search params interface)
- Modify: `src/frontend/src/routes/directory/groups/index.tsx:16-24` (validate tab param)

**Step 1: Add `GroupTab` type to `src/frontend/src/types/group.ts`**

Add after the existing type aliases (line 10):

```typescript
export type GroupTab = 'overview' | 'members' | 'permissions';
```

**Step 2: Add `tab` to `GroupManagementSearchParams`**

In `GroupManagementPage.tsx`, update the interface:

```typescript
export interface GroupManagementSearchParams {
  groupId?: string;
  filter?: GroupFilter;
  search?: string;
  page?: number;
  pageSize?: number;
  tab?: GroupTab;  // ← add this
}
```

Import `GroupTab`:

```typescript
import type { GroupTab } from '@/types/group';
```

**Step 3: Add `handleTabChange` callback in `GroupManagementPage`**

After `handleDeleteGroup` (around line 112), add:

```typescript
const handleTabChange = useCallback(
  (tab: GroupTab) => updateSearchParams({ tab }),
  [updateSearchParams],
);
```

**Step 4: Pass `tab` and `onTabChange` to `GroupDetailPanel`**

Update the `GroupDetailPanel` render (around line 173):

```tsx
<GroupDetailPanel
  groupId={groupId}
  tab={searchParams.tab || 'overview'}
  onTabChange={handleTabChange}
  onDelete={handleDeleteGroup}
  onAddMember={(cn) => modal.openAddMembers(cn)}
/>
```

**Step 5: Validate `tab` in route search params**

In `src/frontend/src/routes/directory/groups/index.tsx`, add validation:

```typescript
import type { GroupTab } from '@/types/group';

const validFilters: GroupFilter[] = ['all', 'security', 'distribution', 'department', 'project'];
const validTabs: GroupTab[] = ['overview', 'members', 'permissions'];
```

In `validateSearch`, add:

```typescript
tab: validTabs.includes(search.tab as GroupTab)
  ? (search.tab as GroupTab)
  : undefined,
```

**Step 6: Verify the app compiles**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: Type errors in `GroupDetailPanel.tsx` because we haven't updated its props yet (that's Task 2). Confirm the errors are only about the new `tab`/`onTabChange` props.

**Step 7: Commit**

```bash
git add src/frontend/src/types/group.ts \
  src/frontend/src/components/features/group-management/GroupManagementPage.tsx \
  src/frontend/src/routes/directory/groups/index.tsx
git commit -m "feat(groups): add tab search param and GroupTab type"
```

---

## Task 2: Create `OverviewTab.tsx`

**Files:**
- Create: `src/frontend/src/components/features/group-management/OverviewTab.tsx`

**Step 1: Create the file**

Extract `InfoSection` from `GroupDetailPanel.tsx` into a standalone tab component:

```tsx
/**
 * Overview tab for group detail — info grid (DN, Type, Created, Modified).
 * - Extracted from GroupDetailPanel during tabs migration
 * - Future: summary stats, group metadata
 */
import { InfoField } from '@azblink/ui';
import { formatDate } from '@/lib/utils/date-helpers';
import { GroupTypeBadge } from './GroupTypeBadge';
import type { GroupDetail } from '@/types/group';

interface OverviewTabProps {
  group: GroupDetail;
}

export function OverviewTab({ group }: OverviewTabProps) {
  return (
    <div className="space-y-3">
      <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--color-text-muted)]">
        Information
      </h3>
      <div className="grid grid-cols-2 gap-x-4 gap-y-2">
        <InfoField label="DN" value={group.dn} />
        <div>
          <dt className="text-[var(--text-xs)] text-[var(--color-text-muted)]">Type</dt>
          <dd className="mt-0.5">
            <GroupTypeBadge type={group.group_type} />
          </dd>
        </div>
        <InfoField
          label="Created"
          value={group.created_at ? formatDate(group.created_at) : '\u2014'}
        />
        <InfoField
          label="Modified"
          value={group.updated_at ? formatDate(group.updated_at) : '\u2014'}
        />
      </div>
    </div>
  );
}
```

**Step 2: Verify it compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | grep OverviewTab`
Expected: No errors from this file (it's not imported yet).

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/group-management/OverviewTab.tsx
git commit -m "feat(groups): extract OverviewTab from GroupDetailPanel"
```

---

## Task 3: Create `MembersTab.tsx`

**Files:**
- Create: `src/frontend/src/components/features/group-management/MembersTab.tsx`

**Step 1: Create the file**

Extract `MembersSection` with its mutation hooks:

```tsx
/**
 * Members tab for group detail — full-height member list + Add Member CTA.
 * - Extracted from GroupDetailPanel during tabs migration
 * - Owns useRemoveMember + useUpdateMemberRole mutation hooks
 * - No max-height constraint — uses full available tab panel height
 */
import { UserPlus } from 'lucide-react';
import { cn } from '@azblink/ui';
import { toast } from 'sonner';
import { MemberRow } from './MemberRow';
import { useRemoveMember, useUpdateMemberRole } from '@/lib/queries/group-members';
import type { GroupDetail, MemberRole } from '@/types/group';

interface MembersTabProps {
  group: GroupDetail;
  onAddMember?: (cn: string) => void;
}

export function MembersTab({ group, onAddMember }: MembersTabProps) {
  const members = group.members || [];
  const removeMember = useRemoveMember();
  const updateRole = useUpdateMemberRole();

  const handleRemove = (uid: string) => {
    const member = members.find((m) => m.uid === uid);
    const name = member?.displayName || uid;
    if (!window.confirm(`Remove ${name} from ${group.cn}?`)) return;

    removeMember.mutate(
      { cn: group.cn, uid },
      {
        onSuccess: () => {
          toast.success(`Removed ${name}`);
        },
        onError: (err: Error) => {
          toast.error(err.message || 'Failed to remove member');
        },
      },
    );
  };

  const handleRoleChange = (uid: string, role: MemberRole) => {
    updateRole.mutate(
      { cn: group.cn, uid, role },
      {
        onSuccess: () => {
          toast.success(`Role updated`);
        },
        onError: (err: Error) => {
          toast.error(err.message || 'Failed to update role');
        },
      },
    );
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--color-text-muted)]">
          Members
        </h3>
        <span className="text-xs text-[var(--color-text-muted)]" aria-live="polite">
          {members.length} member{members.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Full-height member list — no max-h constraint */}
      <div className="-mx-1">
        {members.length > 0 ? (
          members.map((member) => (
            <MemberRow
              key={member.uid}
              member={member}
              onRemove={handleRemove}
              onRoleChange={handleRoleChange}
            />
          ))
        ) : (
          <p className="text-sm text-[var(--color-text-muted)] px-3 py-4 text-center">
            No members
          </p>
        )}
      </div>

      {/* Add Member CTA */}
      <button
        type="button"
        onClick={() => onAddMember?.(group.cn)}
        className={cn(
          'flex w-full items-center justify-center gap-2 rounded-md py-2.5',
          'border border-dashed border-[var(--color-border-subtle)]',
          'text-sm text-[var(--color-text-muted)]',
          'hover:border-[var(--color-primary)] hover:text-[var(--color-primary)]',
          'transition-colors cursor-pointer',
        )}
      >
        <UserPlus className="h-4 w-4" />
        Add Member
      </button>
    </div>
  );
}
```

Key difference from original: **No `max-h-52 overflow-y-auto`** on the member list div. The tab panel itself handles overflow.

**Step 2: Verify it compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | grep MembersTab`
Expected: No errors from this file.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/group-management/MembersTab.tsx
git commit -m "feat(groups): extract MembersTab from GroupDetailPanel"
```

---

## Task 4: Create `PermissionsTab.tsx`

**Files:**
- Create: `src/frontend/src/components/features/group-management/PermissionsTab.tsx`

**Step 1: Create the file**

Extract `PermissionsSection` with its mutation hook:

```tsx
/**
 * Permissions tab for group detail — ToggleCard list for RBAC capabilities.
 * - Extracted from GroupDetailPanel during tabs migration
 * - Owns useUpdateGroupPermissions mutation hook
 * - Semantic <fieldset> wrapper for a11y
 */
import { PermissionToggle, PERMISSIONS } from './PermissionToggle';
import { useUpdateGroupPermissions } from '@/lib/queries/group-permissions';
import type { PermissionKey } from '@/types/group';

interface PermissionsTabProps {
  groupCn: string;
  permissions: PermissionKey[];
}

export function PermissionsTab({ groupCn, permissions }: PermissionsTabProps) {
  const enabledSet = new Set(permissions);
  const updatePermissions = useUpdateGroupPermissions();

  const handleToggle = (key: PermissionKey, enabled: boolean) => {
    const updated = enabled
      ? permissions.includes(key) ? permissions : [...permissions, key]
      : permissions.filter((p) => p !== key);
    updatePermissions.mutate({ cn: groupCn, permissions: updated });
  };

  return (
    <fieldset className="space-y-3 border-none p-0 m-0">
      <legend className="text-xs font-semibold uppercase tracking-wider text-[var(--color-text-muted)]">
        Permissions
      </legend>
      <div className="space-y-2">
        {PERMISSIONS.map((perm) => (
          <PermissionToggle
            key={perm.key}
            permissionKey={perm.key}
            label={perm.label}
            description={perm.description}
            icon={perm.icon}
            enabled={enabledSet.has(perm.key)}
            onToggle={(newEnabled) => handleToggle(perm.key, newEnabled)}
          />
        ))}
      </div>
    </fieldset>
  );
}
```

**Step 2: Verify it compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | grep PermissionsTab`
Expected: No errors from this file.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/group-management/PermissionsTab.tsx
git commit -m "feat(groups): extract PermissionsTab from GroupDetailPanel"
```

---

## Task 5: Create `GroupDetailTabs.tsx`

**Files:**
- Create: `src/frontend/src/components/features/group-management/GroupDetailTabs.tsx`

**Step 1: Create the file**

Mirror `org-management/DetailTabs.tsx` exactly:

```tsx
/**
 * 3-tab container for group detail: Overview, Members, Permissions.
 * - Mirrors org-management/DetailTabs.tsx pattern
 * - Tab state synced to URL ?tab= param via onTabChange callback
 */
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@azblink/ui';
import { OverviewTab } from './OverviewTab';
import { MembersTab } from './MembersTab';
import { PermissionsTab } from './PermissionsTab';
import type { GroupTab } from '@/types/group';
import type { GroupDetail } from '@/types/group';

interface GroupDetailTabsProps {
  group: GroupDetail;
  activeTab: GroupTab;
  onTabChange: (tab: GroupTab) => void;
  onAddMember?: (cn: string) => void;
}

export function GroupDetailTabs({ group, activeTab, onTabChange, onAddMember }: GroupDetailTabsProps) {
  return (
    <Tabs
      value={activeTab}
      onValueChange={(v) => onTabChange(v as GroupTab)}
    >
      <TabsList variant="underline">
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="members">Members</TabsTrigger>
        <TabsTrigger value="permissions">Permissions</TabsTrigger>
      </TabsList>

      <div className="flex-1 overflow-y-auto px-5 py-5">
        <TabsContent value="overview">
          <OverviewTab group={group} />
        </TabsContent>

        <TabsContent value="members">
          <MembersTab group={group} onAddMember={onAddMember} />
        </TabsContent>

        <TabsContent value="permissions">
          <PermissionsTab groupCn={group.cn} permissions={group.permissions} />
        </TabsContent>
      </div>
    </Tabs>
  );
}
```

**Step 2: Verify it compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | grep GroupDetailTabs`
Expected: No errors from this file.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/group-management/GroupDetailTabs.tsx
git commit -m "feat(groups): add GroupDetailTabs container"
```

---

## Task 6: Rewrite `GroupDetailPanel.tsx`

**Files:**
- Modify: `src/frontend/src/components/features/group-management/GroupDetailPanel.tsx`

This is the pivotal task. Remove the three inline sections, update props, wire in `GroupDetailTabs`.

**Step 1: Rewrite the file**

Replace the entire file content:

```tsx
/**
 * Right panel of split-panel layout — shows selected group's details.
 * - Header: type-colored icon, group name, description, action buttons
 * - Tabs: Overview, Members, Permissions (via GroupDetailTabs)
 * - Suspense-wrapped data loading with skeleton
 */
import { Suspense } from 'react';
import { useSuspenseQuery } from '@tanstack/react-query';
import { Edit, Trash2 } from 'lucide-react';
import { Button, Skeleton, cn } from '@azblink/ui';
import { GroupDetailTabs } from './GroupDetailTabs';
import { typeIconConfig } from './group-type-config';
import { groupDetailQueryOptions } from '@/lib/queries/groups';
import type { GroupDetail, GroupTab } from '@/types/group';

interface GroupDetailPanelProps {
  groupId: string;
  tab?: GroupTab;
  onTabChange?: (tab: GroupTab) => void;
  onEdit?: (cn: string) => void;
  onDelete?: (cn: string) => void;
  onAddMember?: (cn: string) => void;
}

export function GroupDetailPanel({ groupId, tab, onTabChange, onEdit, onDelete, onAddMember }: GroupDetailPanelProps) {
  return (
    <Suspense fallback={<GroupDetailSkeleton />}>
      <GroupDetailContent
        groupId={groupId}
        tab={tab}
        onTabChange={onTabChange}
        onEdit={onEdit}
        onDelete={onDelete}
        onAddMember={onAddMember}
      />
    </Suspense>
  );
}

function GroupDetailContent({
  groupId,
  tab = 'overview',
  onTabChange,
  onEdit,
  onDelete,
  onAddMember,
}: GroupDetailPanelProps) {
  const { data: group } = useSuspenseQuery(groupDetailQueryOptions(groupId));

  const handleTabChange = (newTab: GroupTab) => {
    onTabChange?.(newTab);
  };

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      <PanelHeader
        group={group}
        onEdit={() => onEdit?.(group.cn)}
        onDelete={() => onDelete?.(group.cn)}
      />

      {/* Tabbed content */}
      <GroupDetailTabs
        group={group}
        activeTab={tab}
        onTabChange={handleTabChange}
        onAddMember={onAddMember}
      />
    </div>
  );
}

/** Panel header with type icon, group name, description, and action buttons */
function PanelHeader({
  group,
  onEdit,
  onDelete,
}: {
  group: GroupDetail;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const iconConfig = typeIconConfig[group.group_type] ?? typeIconConfig.distribution;
  const Icon = iconConfig.icon;

  return (
    <div className="px-5 py-5 border-b border-[var(--color-border-subtle)]">
      <div className="flex items-center gap-4 mb-3">
        {/* Type-colored icon */}
        <div className={cn(
          'flex h-14 w-14 shrink-0 items-center justify-center rounded-xl',
          iconConfig.bg,
        )}>
          <Icon className={cn('h-7 w-7', iconConfig.color)} />
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="text-lg font-semibold text-[var(--color-text-primary)] truncate">
            {group.cn}
          </h2>
          <p className="text-sm text-[var(--color-text-muted)] truncate">
            {group.description || 'No description'}
          </p>
        </div>
      </div>
      <div className="flex gap-2">
        <Button
          variant="secondary"
          size="sm"
          onClick={onEdit}
          leftIcon={<Edit className="h-3.5 w-3.5" />}
        >
          Edit
        </Button>
        <Button
          variant="secondary"
          size="sm"
          onClick={onDelete}
          leftIcon={<Trash2 className="h-3.5 w-3.5" />}
        >
          Delete
        </Button>
      </div>
    </div>
  );
}

function GroupDetailSkeleton() {
  return (
    <div className="flex flex-col h-full">
      {/* Header skeleton */}
      <div className="px-5 py-5 border-b border-[var(--color-border-subtle)]">
        <div className="flex items-center gap-4 mb-3">
          <Skeleton className="h-14 w-14 rounded-xl" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-5 w-36" />
            <Skeleton className="h-4 w-48" />
          </div>
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-8 w-16" />
          <Skeleton className="h-8 w-20" />
        </div>
      </div>
      {/* Tab bar skeleton */}
      <div className="px-5 pt-3 border-b border-[var(--color-border-subtle)]">
        <div className="flex gap-4">
          <Skeleton className="h-4 w-16 mb-3" />
          <Skeleton className="h-4 w-16 mb-3" />
          <Skeleton className="h-4 w-20 mb-3" />
        </div>
      </div>
      {/* Tab content skeleton */}
      <div className="flex-1 px-5 py-5 space-y-3">
        <Skeleton className="h-3 w-24" />
        <div className="grid grid-cols-2 gap-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="space-y-1">
              <Skeleton className="h-2.5 w-12" />
              <Skeleton className="h-3 w-24" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
```

**Step 2: Verify it compiles clean**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: Zero errors. All imports resolve, all types match.

**Step 3: Commit**

```bash
git add src/frontend/src/components/features/group-management/GroupDetailPanel.tsx
git commit -m "feat(groups): replace scrolling sections with tabbed interface

Migrates GroupDetailPanel from vertical scrolling sections to a 3-tab
layout (Overview, Members, Permissions) matching the org detail panel
pattern. Members list no longer height-constrained."
```

---

## Task 7: Visual Verification

**Files:** None (manual testing)

**Step 1: Start the dev server (if not running)**

Run: `just up-bg` (or verify it's already running)

**Step 2: Open the groups page**

Navigate to: `http://localhost:8081/directory/groups`

**Step 3: Verify the following**

- [ ] Select a group → detail panel shows with **tab bar** below header
- [ ] **Overview tab** is active by default — shows Info grid (DN, Type, Created, Modified)
- [ ] Click **Members tab** → shows member list at full panel height (no inner scroll box)
- [ ] Click **Permissions tab** → shows ToggleCard list
- [ ] Tab state persists in URL as `?tab=members` etc.
- [ ] Switching groups resets to Overview tab (or preserves tab — verify behavior)
- [ ] Tab underline indicator animates correctly (via `@azblink/ui` Tabs primitive)
- [ ] Members "Add Member" button still works
- [ ] Permission toggles still fire mutations
- [ ] Skeleton shows tab bar placeholder during loading

**Step 4: Document any issues**

If issues found, fix before proceeding. Do not commit broken UI.

---

## Task 8: Update JSDoc in Touched Files

**Files:**
- Verify: All 5 new/modified files have accurate file-level JSDoc

**Step 1: Audit each file's docstring**

Ensure the docstring at line 1 of each file accurately reflects the current content:

| File | Expected docstring focus |
|------|-------------------------|
| `GroupDetailPanel.tsx` | Suspense wrapper, header, tab delegation |
| `GroupDetailTabs.tsx` | 3-tab container, URL sync |
| `OverviewTab.tsx` | Info grid, extracted from GroupDetailPanel |
| `MembersTab.tsx` | Full-height member list, mutation hooks |
| `PermissionsTab.tsx` | ToggleCard list, mutation hook |

**Step 2: Commit if any updates needed**

```bash
git add -u src/frontend/src/components/features/group-management/
git commit -m "docs(groups): update JSDoc for tab migration files"
```

---

## Summary

| Task | Files | Action | Commit message |
|------|-------|--------|----------------|
| 1 | 3 modified | Add `GroupTab` type + URL param wiring | `feat(groups): add tab search param and GroupTab type` |
| 2 | 1 created | Extract `OverviewTab` | `feat(groups): extract OverviewTab from GroupDetailPanel` |
| 3 | 1 created | Extract `MembersTab` (no max-h) | `feat(groups): extract MembersTab from GroupDetailPanel` |
| 4 | 1 created | Extract `PermissionsTab` | `feat(groups): extract PermissionsTab from GroupDetailPanel` |
| 5 | 1 created | Create `GroupDetailTabs` container | `feat(groups): add GroupDetailTabs container` |
| 6 | 1 modified | Rewrite `GroupDetailPanel` | `feat(groups): replace scrolling sections with tabbed interface` |
| 7 | 0 | Visual verification | (no commit) |
| 8 | 0-5 | JSDoc audit | `docs(groups): update JSDoc for tab migration files` |

**Total: 4 new files, 3 modified files, 6-7 commits**
