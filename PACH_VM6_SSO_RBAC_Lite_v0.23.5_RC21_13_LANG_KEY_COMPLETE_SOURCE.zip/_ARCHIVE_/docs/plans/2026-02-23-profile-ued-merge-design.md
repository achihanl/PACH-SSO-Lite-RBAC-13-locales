# Profile = UED Integration (1:1 Merge Design)

- **Date:** 2026-02-23
- **Status:** Approved
- **Branch:** TBD (off main, after `bcece84`)

## Problem

Profiles (`config_templates`) and UED configs (`tenant_ldap_configs`) are separate tables with an FK link. This creates unnecessary indirection — admins must create a UED config separately, then link it to a profile. The mental model is simpler: **one profile = one UED provisioning target**.

## Decision

Merge `tenant_ldap_configs` columns inline onto `config_templates`. Drop `tenant_ldap_configs`. Each profile owns its UED endpoint, discovery cache, and allocation counters directly.

## Schema

### config_templates (after merge)

```sql
-- Existing columns (unchanged)
id              VARCHAR(128) PK
name            VARCHAR(255) UNIQUE
description     TEXT
template_type   VARCHAR(20)     -- 'custom' | 'default'
status          VARCHAR(20)     -- 'draft' | 'active' | 'archived'
xmpp_config     JSON
sip_config      JSON
sso_config      JSON
qr_settings     JSON
created_at      TIMESTAMPTZ
updated_at      TIMESTAMPTZ
created_by      VARCHAR(255)
updated_by      VARCHAR(255)

-- UED provisioning (merged from tenant_ldap_configs)
ued_api_url             TEXT        NULLABLE    -- NULL = no UED
ued_api_key_enc         TEXT        NULLABLE    -- Fernet-encrypted
ued_enabled             BOOLEAN     DEFAULT false
discovered_schema_name  TEXT        NULLABLE    -- cached from discovery
discovered_at           TIMESTAMPTZ NULLABLE

-- Allocation counters (per-profile, admin-configurable ranges)
next_uid_number     INTEGER DEFAULT 5000
uid_range_start     INTEGER DEFAULT 5000
uid_range_end       INTEGER DEFAULT 65533
next_extension      INTEGER DEFAULT 6000
ext_range_start     INTEGER DEFAULT 6000
ext_range_end       INTEGER DEFAULT 6999

-- Sync metadata
last_sync_at    TIMESTAMPTZ NULLABLE
last_error      TEXT        NULLABLE
```

### sync_events (FK change)

```sql
-- Before: tenant_id TEXT FK → tenant_ldap_configs.tenant_id
-- After:  profile_id VARCHAR(128) FK → config_templates.id ON DELETE SET NULL
```

### Dropped

- `tenant_ldap_configs` table — entirely removed
- `config_templates.ued_config_id` column — replaced by inline fields
- `LDAP_TENANT` env var — no longer needed

## API Changes

### Absorbed into profile CRUD

| Old endpoint | New location |
|---|---|
| `POST /api/ued/configs` | `POST /api/config-templates` (UED fields in payload) |
| `PATCH /api/ued/configs/{id}` | `PUT /api/config-templates/{id}` |
| `DELETE /api/ued/configs/{id}` | `DELETE /api/config-templates/{id}` |
| `POST /api/ued/configs/{id}/test` | `POST /api/config-templates/{id}/discover` |
| `GET /api/ued/configs` | Removed (profile list shows UED status) |

### Sync events (stay, re-keyed)

| Endpoint | Change |
|---|---|
| `GET /api/ued/sync-events` | Filter by `profile_id` instead of `tenant_id` |
| `POST /api/ued/sync-events/{id}/retry` | Unchanged |
| `POST /api/ued/sync-events/retry-all-failed` | Filter by `profile_id` |

### Profile payload additions

```json
{
  "name": "UC PJSIP Profile",
  "xmppConfig": { "enabled": true },
  "sipConfig": { "enabled": true },
  "uedApiUrl": "https://ued-pjsip:8000",
  "uedApiKey": "secret",
  "uedEnabled": true,
  "uidRangeStart": 10000,
  "uidRangeEnd": 59999,
  "extRangeStart": 1000,
  "extRangeEnd": 9999
}
```

Response includes `discoveredSchemaName`, `discoveredAt`, `nextUidNumber`, `nextExtension`, `lastSyncAt`, `lastError`. Never returns `uedApiKey`.

## Backend Code Changes

| File | Change |
|---|---|
| `orgdb.py` | Merge UED columns into config_templates Table. Drop tenant_ldap_configs. Move allocate methods. Update sync_events to profile_id. |
| `main.py` | Remove `/api/ued/configs` endpoints. Add UED fields to profile models. Add `POST .../discover`. Change `emit_sync_event(profile_id, ...)`. |
| `sync_worker.py` | Resolve `profile_id` → config_templates row instead of `tenant_id` → tenant_ldap_configs. |
| `provisioning.py` | Read UED fields directly from profile row. No two-table join. |
| `config.py` | Remove `LDAP_TENANT`. |
| `ued_discovery.py` | Unchanged |
| `ued_sync_client.py` | Unchanged |
| `ued_crypto.py` | Unchanged |

## Frontend Changes

- Add UED fields to `ProfileBase`/`ProfileDetail` types in `org-profiles.ts`
- Add "UED Provisioning" `ConfigSection` to `ConfigTab.tsx` (alongside XMPP/SIP/SSO/QR)
- Add `useRunDiscovery(profileId)` mutation
- No new files — UED is just more fields on existing profile types/components

## Migration

`013_profile_ued_merge.sql`:
1. Add UED columns to config_templates (nullable/defaults)
2. Copy data from tenant_ldap_configs via ued_config_id FK
3. Add profile_id column to sync_events, backfill, drop tenant_id
4. Drop ued_config_id from config_templates
5. Drop tenant_ldap_configs table

## Test Changes

- Rewrite `test_ued_api.py` — test UED via profile endpoints
- Rewrite `test_ued_orgdb.py` — test UED fields on config_templates
- Update `test_sync_worker.py` — profile_id resolution
- Unchanged: `test_ued_discovery.py`, `test_ued_sync_client.py`, UED Sync container tests (215)
