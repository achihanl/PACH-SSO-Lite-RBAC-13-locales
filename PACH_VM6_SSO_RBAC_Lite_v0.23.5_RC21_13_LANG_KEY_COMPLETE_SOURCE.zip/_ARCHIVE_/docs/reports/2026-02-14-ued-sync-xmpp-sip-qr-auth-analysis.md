# Iterative Analysis Report: UED Sync, XMPP/SIP Profiles, QR-LDAP Authentication

**Date:** 2026-02-14 (revised)
**Analyst:** Claude Opus 4.6 (AI-assisted code review)
**Audit:** 4-agent parallel audit team (UED Sync, XMPP/SIP, QR-LDAP Auth, Security/Completeness)
**Scope:** AZBlink Directory monorepo — `src/backend/`, `src/ued-sync/`, `deploy/dev/`, `migrations/`
**Methodology:** Three-pass iterative analysis (Broad Scan → Deep Analysis → Represent), followed by 4-agent cross-verification audit against source code

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Subject 1: UED Sync API Migration Verification](#2-subject-1-ued-sync-api-migration-verification)
3. [Subject 2: XMPP and SIP Service Profile Definitions](#3-subject-2-xmpp-and-sip-service-profile-definitions)
4. [Subject 3: QR Code — LDAP Bind Authentication](#4-subject-3-qr-code--ldap-bind-authentication)
5. [Tagged Findings](#5-tagged-findings)
6. [Audit Corrections](#6-audit-corrections)
7. [Appendix: Files Analyzed](#7-appendix-files-analyzed)

---

## 1. Executive Summary

Three subjects were analyzed across the AZBlink Directory monorepo:

| Subject | Status | Verdict |
|---------|--------|---------|
| UED Sync API migration into monorepo | **Complete** | Client, server, infra, DB, tests — all wired |
| XMPP/SIP profile definitions | **Three-store architecture** | Env defaults, Config templates, UED schema (parallel, not cascading) |
| QR-LDAP authentication | **Fully traced** | LDAP bind (ldap3) → JWT → QR sign → token consume |

**Key clarification:** The term "PED" does not exist anywhere in the codebase. The system uses **UED** (Unified Endpoint Directory) Sync API for LDAP provisioning. QR codes directly provision client apps with XMPP/SIP connection details — there is no intermediary PED server.

---

## 2. Subject 1: UED Sync API Migration Verification

### 2.1 Architecture Overview

The UED Sync integration follows a **client-server split** within the monorepo:

```
┌─────────────────────────────────────────────────────────┐
│                    AZBlink AD Monorepo                   │
│                                                         │
│  ┌─────────────────────┐    HTTP     ┌────────────────┐ │
│  │   src/backend/       │──────────►│  src/ued-sync/   │ │
│  │   (Event Producer)   │           │  (LDAP Writer)   │ │
│  │                      │           │                  │ │
│  │  ued_sync_client.py  │           │  main.py         │ │
│  │  sync_worker.py      │           │  routers/sync.py │ │
│  │  ued_crypto.py       │           │  ldap_ops.py     │ │
│  └──────────┬───────────┘           │  schema.py       │ │
│             │                       └────────┬─────────┘ │
│             ▼                                ▼           │
│      ┌─────────────┐               ┌─────────────┐     │
│      │  PostgreSQL  │               │   OpenLDAP   │     │
│      │  (events,    │               │   (target)   │     │
│      │   configs)   │               └─────────────┘     │
│      └─────────────┘                                    │
└─────────────────────────────────────────────────────────┘
```

### 2.2 Client Side (`src/backend/`)

#### `ued_sync_client.py` (147 lines) — HTTP Event Dispatcher

Maps AZBlink lifecycle events to UED API endpoints:

```python
EVENT_ENDPOINT_MAP: dict[str, tuple[str, str | None]] = {
    "user_created":      ("/api/v1/sync/user",          "create"),
    "user_updated":      ("/api/v1/sync/user",          "update"),
    "user_terminated":   ("/api/v1/sync/user",          "delete"),
    "user_suspended":    ("/api/v1/sync/user/suspend",   "suspend"),
    "user_unsuspended":  ("/api/v1/sync/user/suspend",   "unsuspend"),
    "password_changed":  ("/api/v1/sync/user/password",  None),
}
```

- `UedSyncClient.send()` — async HTTP POST with 30s timeout
- Returns structured `SyncResult` dataclass with `ok`, `status_code`, `request_id`, `error_code`, `error_message`, `retryable`
- **Retry classification:** 5xx and 429 → retryable; 4xx → not retryable (permanent failure)

#### `sync_worker.py` (142 lines) — Background Poller

```
┌─────────────────────────────────────────────────────┐
│                   SyncWorker.run()                   │
│                                                     │
│  Poll every 5s ──► Dequeue up to 50 events          │
│       │                    │                        │
│       │            Decrypt tenant secrets            │
│       │                    │                        │
│       │            Dispatch to UED via HTTP          │
│       │                    │                        │
│       │            ┌───────┴───────┐                │
│       │         Success         Failure              │
│       │            │               │                │
│       │     Mark completed    Retryable?             │
│       │                     ┌──┴──┐                 │
│       │                   Yes    No                  │
│       │                    │      │                  │
│       │              Increment  Mark                 │
│       │              attempt   failed                │
│       │              + backoff                       │
│       │                                             │
│  Every ~720 cycles (~1hr) ──► Prune old events      │
│                        (retention: 90 days)          │
└─────────────────────────────────────────────────────┘
```

- **Exponential backoff formula:** `min(5 * 3^attempt, 3600)` seconds
- **Per-user event ordering:** enforced at the database level via `idx_sync_events_user_ordering` index — the worker processes events in DB-returned order, relying on SQL ordering rather than Python-level locking
- **Imports:** `decrypt_value` is imported at module level (line 14); `decrypt_payload_password` is late-imported inside `_process_event()` at line 106

#### `ued_crypto.py` (65 lines) — Fernet Encryption

- Encrypts/decrypts tenant secrets (API keys, LDAP bind passwords) at rest
- Module-level Fernet instance cache with environment variable change detection
- `UED_ENCRYPTION_KEY` required only when tenant configs exist (graceful when unused)

### 2.3 Server Side (`src/ued-sync/`)

#### `main.py` (36 lines) — FastAPI Entry Point

- Version: `0.3.0`
- Mounts: health, sync, batch routers
- Middleware: `RequestLoggingMiddleware` + rate limiting

#### `routers/sync.py` — Sync Endpoints

| Endpoint | Purpose |
|----------|---------|
| `POST /api/v1/sync/user` | Create/update/delete user in target LDAP |
| `POST /api/v1/sync/user/suspend` | Suspend/unsuspend user |
| `POST /api/v1/sync/user/password` | Change user password |
| `POST /api/v1/auth/validate` | Validate API key + test LDAP connectivity |

- Schema-driven DN interpolation (template variables like `{uid}`, `{org}`)
- Attribute building from provisioning schema definitions

#### `routers/batch.py` — Bulk Operations

| Endpoint | Purpose |
|----------|---------|
| `POST /api/v1/batch/users` | Bulk create/delete, max 100 per batch |

- HTTP 200 (all success), 207 (partial), 400 (invalid request), 401 (auth required), 500 (all failed), 503 (LDAP unavailable)

#### `schema.py` (209 lines) — Provisioning Schema

- `LdapConfig`, `ProvisioningSchema` Pydantic models
- RFC 4515 (`escape_ldap_filter_value`) and RFC 4514 (`escape_dn_value`) escaping functions for LDAP filter/DN safety
- `interpolate_template()` for dynamic `{placeholder}` substitution with optional LDAP escaping
- `build_attributes()` constructs full LDAP attribute dicts from schema + interpolation context

#### `ldap_ops.py` (335 lines) — LDAP Client

- `GenericLdapClient` — **synchronous** context manager (`__enter__`/`__exit__`) for LDAP CRUD
- `LdapResult` dataclass with `retryable` flag for upstream retry decisions
- Error code mapping with 6 entries:

| Code | Constant | Retryable |
|------|----------|-----------|
| 0 | `SUCCESS` | No |
| 32 | `LDAP_NOT_FOUND` | No |
| 68 | `LDAP_ALREADY_EXISTS` | No |
| 19 | `LDAP_CONSTRAINT_VIOLATION` | No |
| 49 | `LDAP_BIND_FAILED` | No |
| -1 | `LDAP_CONNECT_FAILED` | Yes |

Additional string-based error codes `LDAP_TIMEOUT` and `LDAP_INVALID_DN` are handled in exception blocks.

#### `auth.py` — API Key Authentication

- `X-API-Key` header validation with `secrets.compare_digest()` (constant-time)
- Dev mode: accepts any matching key
- Prod mode: requires 64-char hex format (`re.compile(r"^[a-fA-F0-9]{64}$")`)

#### `password_utils.py` — Password Hashing

- `hash_password()` supports SSHA (16-byte salt), MD5, PLAIN
- SSHA is the default and recommended scheme

#### `sync_models.py` (177 lines) — Request/Response Models

- Complete Pydantic models for sync, suspend, password, auth-validate, and batch endpoints
- Max 100 users/uids per batch with Pydantic validator enforcement

### 2.4 Infrastructure

#### `deploy/dev/Dockerfile.ued-sync` (34 lines)

- Base: `python:3.11-slim`
- Package manager: `uv` (not pip)
- Non-root user execution
- **Critical:** CMD uses `/app/.venv/bin/python` — bare `python` would use system Python without venv packages

#### `deploy/dev/docker-compose.yml` (ued-sync service)

- Internal Docker network only — no host port exposed
- Health check: `GET /health`
- Source mounted for hot reload during development
- Depends on: OpenLDAP

#### `migrations/010_ued_sync.sql` (71 lines)

Creates two tables:

```sql
-- Tenant LDAP configurations (encrypted secrets)
CREATE TABLE tenant_ldap_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id TEXT UNIQUE NOT NULL,
    ued_api_url TEXT NOT NULL,
    ued_api_key_enc TEXT NOT NULL,
    ldap_uri TEXT, ldap_base_dn TEXT,
    ldap_bind_dn TEXT, ldap_bind_pw_enc TEXT,
    ldap_use_ssl BOOLEAN DEFAULT FALSE,
    schema_config JSONB DEFAULT '{}',
    enabled BOOLEAN DEFAULT TRUE,
    ...
);

-- Sync event queue with retry tracking
CREATE TABLE sync_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id TEXT NOT NULL REFERENCES tenant_ldap_configs(tenant_id),
    user_uid TEXT NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    payload JSONB NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    attempts INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 10,
    next_retry_at TIMESTAMPTZ,
    ...
);
```

Also includes:
- **4 partial indexes** optimized for: worker polling, per-user event ordering, retention cleanup, and failed events dashboard
- **2 CHECK constraints** on `event_type` (6 valid values) and `status` (4 valid values: pending, processing, completed, failed)

### 2.5 Admin API Endpoints (`src/backend/main.py`)

8 endpoints at `/api/ued/`:

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/ued/configs` | GET | List tenant UED configs (secrets redacted) |
| `/api/ued/configs` | POST | Create tenant config |
| `/api/ued/configs/{id}` | PATCH | Update tenant config |
| `/api/ued/configs/{id}` | DELETE | Remove tenant config |
| `/api/ued/configs/{id}/test` | POST | Test UED + LDAP connectivity |
| `/api/ued/sync-events` | GET | List sync events (filterable) |
| `/api/ued/sync-events/{id}/retry` | POST | Retry failed event |
| `/api/ued/sync-events/retry-all-failed` | POST | Retry all failed events |

### 2.6 Test Coverage

- **176 unit + API test functions** in `src/ued-sync/tests/` (mocked LDAP, ~0.6s)
- **18 integration test functions** in `src/ued-sync/tests/integration/` (real LDAP)
- Bruno CLI e2e tests in `src/ued-sync/e2e/`
- **194 total test functions** across all test categories

Test breakdown by file:

| File | Tests |
|------|-------|
| `test_auth.py` | 20 |
| `test_schema.py` | 24 |
| `test_api/test_sync.py` | 28 |
| `test_api/test_batch.py` | 9 |
| `test_api/test_health.py` | 3 |
| `test_password_utils.py` | 9 |
| `test_ldap_ops.py` | 26 |
| `test_middleware/test_rate_limit.py` | 9 |
| `test_middleware/test_logging_middleware.py` | 10 |
| `test_sync_models.py` | 4 |
| `test_security.py` | 25 |
| `test_logging.py` | 5 |
| `test_rate_limit_integration.py` | 4 |
| `integration/test_sync_integration.py` | 11 |
| `integration/test_audit_integration.py` | 7 |

### 2.7 Migration Verdict

**The UED Sync API migration is structurally complete.** All components are present:

- [x] Client-side event producer (`ued_sync_client.py`, `sync_worker.py`, `ued_crypto.py`)
- [x] Server-side LDAP provisioner (`src/ued-sync/` — full FastAPI app)
- [x] Database schema (`migrations/010_ued_sync.sql` — tables + indexes + constraints)
- [x] OrgDB methods (16 methods for CRUD, event lifecycle, retry, pruning)
- [x] Docker infrastructure (Dockerfile, compose service, health checks)
- [x] Admin API (8 endpoints for config management + event monitoring)
- [x] Authentication (API key with constant-time comparison)
- [x] Encryption at rest (Fernet for tenant secrets)
- [x] Test suite (194 tests across unit, API, and integration categories)
- [x] Hot reload support (uvicorn auto-reload for development)

---

## 3. Subject 2: XMPP and SIP Service Profile Definitions

### 3.1 Three-Store Profile Architecture

XMPP/SIP configuration exists in three **parallel** stores, each serving a different purpose. These are independent systems, not a cascading resolution chain:

```
┌──────────────────────────────────────────────────────────┐
│  Store 3: UED Schema Configs (per-tenant)                │
│  ┌────────────────────────────────────────────────────┐  │
│  │  tenant_ldap_configs.schema_config (JSONB)         │  │
│  │  Purpose: How to write users to target LDAP        │  │
│  │  Used by: UED Sync microservice only               │  │
│  └────────────────────────────────────────────────────┘  │
│                                                          │
│  Store 2: Config Templates (per-org, admin-managed)      │
│  ┌────────────────────────────────────────────────────┐  │
│  │  config_templates table — JSON columns:            │  │
│  │  xmpp_config, sip_config, sso_config, qr_settings  │  │
│  │  Purpose: Admin-managed per-org configuration       │  │
│  │  Used by: Admin API (not yet used in QR generation) │  │
│  └────────────────────────────────────────────────────┘  │
│                                                          │
│  Store 1: Environment Defaults (global)                  │
│  ┌────────────────────────────────────────────────────┐  │
│  │  config.py environment variables:                   │  │
│  │  UCCHAT_XMPP_DOMAIN, UCCHAT_XMPP_WS_URL           │  │
│  │  UCCHAT_SIP_DOMAIN, UCCHAT_SIP_WSS_URL             │  │
│  │  UCCHAT_WEBRTC_SIP_URL, UCCHAT_TURN_URL            │  │
│  │  Purpose: Runtime connection defaults               │  │
│  │  Used by: QR generation (sole source for UC values) │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

**Important design note:** At QR generation time, XMPP/SIP connection details come **exclusively** from environment defaults (Store 1). Config templates (Store 2) are not loaded during QR generation. This means per-org XMPP/SIP overrides are not yet wired into the QR flow.

### 3.2 Store 1: Environment Defaults (`src/backend/config.py`)

Global defaults set via environment variables:

```python
# UC Chat / XMPP Configuration
UCCHAT_XMPP_DOMAIN    = os.getenv("UCCHAT_XMPP_DOMAIN", "")
UCCHAT_XMPP_WS_URL    = os.getenv("UCCHAT_XMPP_WS_URL", "")

# UC Call / SIP Configuration
UCCHAT_SIP_DOMAIN     = os.getenv("UCCHAT_SIP_DOMAIN", "")
UCCHAT_SIP_WSS_URL    = os.getenv("UCCHAT_SIP_WSS_URL", "")

# WebRTC / TURN (additional)
UCCHAT_WEBRTC_SIP_URL = os.getenv("UCCHAT_WEBRTC_SIP_URL", "")  # backward-compat alias
UCCHAT_TURN_URL       = os.getenv("UCCHAT_TURN_URL", "")          # TURN server for relay
```

Startup validation (`_validate_uc_config()`) raises `RuntimeError` if the four core variables are empty — UC services require connection details.

### 3.3 Store 2: Config Templates (`src/backend/main.py`, lines 2555-2593)

Pydantic models for per-org configuration (stored in `config_templates` table as JSON columns):

```python
class XmppConfigUpdate(BaseModel):
    enabled: bool = False
    domain: str                    # XMPP domain
    websocket_url: str             # WebSocket URL
    conference_server: str         # MUC server
    resource_binding: bool = False

class SipConfigUpdate(BaseModel):
    enabled: bool = False
    domain: str                    # SIP domain
    websocket_url: str             # WebSocket URL
    transport: str = "wss"         # Transport: wss|ws|tcp|udp
    srtp_required: bool = False

class SsoConfigUpdate(BaseModel):
    enabled: bool = False
    provider: str                  # SSO provider name
    issuer_url: str                # OIDC issuer URL
    client_id: str                 # OIDC client ID
    scopes: str = "openid profile email"
    pkce_required: bool = True

class QrSettingsUpdate(BaseModel):
    default_validity_minutes: int = 60   # QR TTL (1 min to 30 days)
    one_time_use: bool = True
    auto_email_on_create: bool = False
    deep_link_scheme: str = "azblink"    # App deep link scheme
```

These are stored as `JSON` (not JSONB) columns in the `config_templates` PostgreSQL table — a separate table from `org_profiles`.

### 3.4 Store 3: UED Schema Configs (`src/ued-sync/src/ued_sync/schema.py`)

For tenants with UED Sync enabled, the `ProvisioningSchema` defines how users are written to the target LDAP:

- **`object_classes`**: Which LDAP object classes to create (e.g., `inetOrgPerson`, `posixAccount`)
- **`dn_template`**: Where in the LDAP tree to place users (e.g., `uid={uid},ou=people,{base_dn}`)
- **`attribute_map`**: Dynamic attribute building with `{uid}`, `{org}` interpolation
- **`required_fields`** / **`optional_fields`**: Validation rules for provisioning data
- **`password_hash`**: SSHA, MD5, or PLAIN hashing for `userPassword`
- **`password_attribute`**: Which LDAP attribute stores the password

### 3.5 Profile Resolution at QR Generation

When generating a QR code (`GET /api/users/{uid}/qrcode`):

1. Fetch user from LDAP (uid, displayName, org inferred from DN)
2. **Use environment defaults directly** for XMPP/SIP connection details (no org profile or config template lookup)
3. Build UC payload with `credentials.username` + one-time `credentials.token`
4. Sign payload with HMAC-SHA256 via `sign_provisioning_payload()`
5. Store provision token hash in `provision_tokens` table
6. Encode as QR code

**Note:** A separate dual-QR endpoint (`GET /api/users/{uid}/qrcodes`) exists using the older `azblink.ucchat_core_provision/v1` schema with different field naming conventions (`ws_url` vs `wsUrl`). It loads org profiles but only for QR#2 (SSO), not for XMPP/SIP values.

---

## 4. Subject 3: QR Code — LDAP Bind Authentication

### 4.1 Complete Authentication Chain

The backend uses the **`ldap3`** library (not `python-ldap`).

```
┌─────────┐    POST /api/auth/login     ┌──────────┐
│  Client  │ ──────────────────────────► │  FastAPI  │
│  (React) │   {username, password,     │  main.py  │
│          │    remember}               │          │
└─────────┘                             └────┬─────┘
                                             │
                                     ┌───────▼────────┐
                                     │  auth.py        │
                                     │                 │
                                     │  Step 1: Find DN│
                                     │  (service bind +│
                                     │   LDAP search)  │
                                     │                 │
                                     │  Step 2: Bind   │
                                     │  (user creds →  │
                                     │   LDAP bind)    │
                                     │                 │
                                     │  Step 3: Fetch  │
                                     │  (attributes    │
                                     │   via service   │
                                     │   account)      │
                                     │                 │
                                     │  Step 4: JWT    │
                                     │  (HS256 token   │
                                     │   generation)   │
                                     │                 │
                                     │  Step 5: Return │
                                     │  {token, user}  │
                                     └───────┬─────────┘
                                             │
                                             ▼
┌─────────┐    GET /api/users/{uid}/qrcode  ┌──────────┐
│  Admin   │ ──────────────────────────────►│  main.py  │
│  (with   │   Authorization: Bearer JWT   │          │
│   JWT)   │                               │          │
└─────────┘                                └────┬─────┘
                                                │
                                        ┌───────▼────────┐
                                        │  qr_signing.py  │
                                        │                 │
                                        │  Build UC payload│
                                        │  Sign (HMAC-256)│
                                        │  Generate QR    │
                                        │  Store token    │
                                        └───────┬─────────┘
                                                │
                                                ▼
                                        ┌────────────────┐
                                        │  QR Code with   │
                                        │  signed payload │
                                        │  (v2 schema)    │
                                        └───────┬─────────┘
                                                │
                                          scan  │
                                                ▼
                                        ┌────────────────┐
                                        │  Client App     │
                                        │  Verify sig     │
                                        │  Extract config  │
                                        │  Connect to UC  │
                                        └────────────────┘
```

### 4.2 Step 1: LDAP DN Resolution (`auth.py`)

```python
# Service-account bind to search for user's DN (using ldap3)
def authenticate_user(username, password):
    # 1. Connect with service credentials via ldap3
    admin_conn = get_conn()  # Connection(server, user=LDAP_BIND_DN, password=LDAP_BIND_PW, auto_bind=True)

    # 2. Search for user by uid (with LDAP filter escaping)
    user_dn = find_user_dn(admin_conn, OU_PEOPLE, username)
    # filter: f"(uid={escape_filter_chars(username)})"
    admin_conn.unbind()
```

### 4.3 Step 2: LDAP Bind Authentication (`auth.py`)

The critical security step — password verification happens via actual LDAP bind:

```python
# 3. Bind as the user (this IS the authentication) — ldap3 API
user_conn = Connection(server, user=user_dn, password=password, auto_bind=True)
# If auto_bind succeeds → password is correct
# If LDAPBindError → password is wrong
```

**Why LDAP bind?** The password is never extracted from LDAP. Instead, the LDAP server itself verifies the password against its stored hash (typically SSHA). This means:
- No password hashes leave the LDAP server
- No client-side hash comparison
- LDAP server enforces password policy (lockout, complexity, etc.)

### 4.4 Step 3: Attribute Fetching

After successful bind, attributes are fetched using a **new service-account connection** (not the user's connection):

- `uid`, `cn`, `displayName`, `mail` — user identity
- `memberOf` — group memberships (parsed to determine `isAdmin`)

**Design note:** Attributes are fetched with service-account privileges via `_fetch_user_details()`, meaning a user with restricted LDAP read ACLs would still have their full attributes retrieved.

### 4.5 Step 4: JWT Token Generation (`auth.py`)

```python
def _generate_jwt(user_data, user_dn, remember):
    payload = {
        "uid": user_data["uid"],        # Subject identifier (note: not standard "sub")
        "dn": user_data["dn"],
        "displayName": user_data.get("displayName", user_data["uid"]),
        "email": user_data.get("mail", ""),
        "isAdmin": is_admin,
        "groups": user_data.get("groups", []),
        "iat": now,
        "exp": now + timedelta(hours=8),  # or 7 days with remember=True
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")
```

**Standards note:** The JWT uses `uid` as the subject identifier rather than the standard `sub` claim (RFC 7519). Some JWT middleware may expect `sub` — consuming services should use `uid` instead.

### 4.6 Step 5: QR Code Signing (`qr_signing.py`)

The `azblink.provisioning.v2` schema:

```json
{
  "schema": "azblink.provisioning.v2",
  "uc": {
    "tenant": "azblink",
    "xmpp": {
      "domain": "xmpp.azblink.com",
      "wsUrl": "wss://xmpp.azblink.com/ws"
    },
    "sip": {
      "domain": "sip.azblink.com",
      "wssUrl": "wss://sip.azblink.com/ws"
    },
    "credentials": {
      "username": "mei",
      "token": "<one-time-provision-token>"
    }
  },
  "sso": null,
  "nonce": "random-16-byte-urlsafe",
  "iat": 1739491200,
  "exp": 1739577600,
  "sig": "hmac-sha256-hex"
}
```

**Signing process:**
1. Build canonical JSON (sorted keys, no whitespace, UTF-8)
2. Compute HMAC-SHA256 with `ORG_QR_SIGNING_SECRET` (hex digest)
3. Attach `sig` field to payload
4. Encode as QR code (base64 or direct JSON)

**Verification:**
1. Extract `sig` from payload
2. Recompute HMAC on payload (minus sig field)
3. Constant-time comparison via `hmac.compare_digest()`
4. Check `exp` for TTL expiration
5. Token-based replay protection via `provision_tokens` table (atomic check-and-update of token status from "active" to "consumed")

**Signing secret validation:** `config.py` enforces `ORG_QR_SIGNING_SECRET` must not be the default value and must be at least 32 characters, with a hard `RuntimeError` on failure at startup.

**Note on dual schemas:** The older `/api/users/{uid}/qrcodes` endpoint uses a different schema (`azblink.ucchat_core_provision/v1`) with a base64url-encoded HMAC signature (via `hmac_sig()` in main.py), while the v2 endpoint uses hex-encoded signatures (via `qr_signing.py`). These produce incompatible output formats.

### 4.7 Dual Auth Plane Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Authentication Planes                  │
│                                                         │
│  Plane A (UC/LDAP) ─── ALWAYS AVAILABLE                 │
│  ├── XMPP authentication: direct LDAP bind              │
│  ├── SIP authentication: direct LDAP bind               │
│  └── Admin login: LDAP bind → JWT                       │
│                                                         │
│  Plane B (SSO/OIDC) ─── OPTIONAL                        │
│  ├── Web app SSO: OIDC with Authentik                   │
│  ├── Graceful degradation when Authentik down            │
│  └── Break-glass: file-based emergency bypass            │
│       (/etc/azblink/directory/breakglass.json)           │
│       Features:                                          │
│       - Reloaded on each request (no restart needed)     │
│       - Localhost-only by default (allow_from)           │
│       - Time-limited via expires_at                      │
│       - Two modes: bootstrap_only, admin_recovery        │
│                                                         │
│  Design Rule: UC MUST work even when Authentik           │
│  is not installed.                                       │
└─────────────────────────────────────────────────────────┘
```

---

## 5. Tagged Findings

### SECURITY

| ID | Finding | Location | Severity | Status |
|----|---------|----------|----------|--------|
| S1 | UED Sync uses HTTP (not HTTPS) on Docker network | `ued_sync_client.py` | Medium | Acceptable for Docker-internal comms; production with network-separated UED should enforce TLS |
| S2 | Constant-time API key comparison | `ued-sync/auth.py:57` | Positive | `secrets.compare_digest()` prevents timing attacks |
| S3 | Constant-time HMAC verification | `qr_signing.py:134` | Positive | `hmac.compare_digest()` prevents timing attacks |
| S4 | Fernet encryption for secrets at rest | `ued_crypto.py` | Positive | Tenant API keys and LDAP passwords are never stored in plaintext |
| S5 | **Incomplete DN escaping** | `ldap_client.py:34-36` | **High** | `dn_escape_ou()` only escapes commas — does NOT implement full RFC 4514 (missing: `+`, `"`, `\`, `<`, `>`, `;`, `=`, leading/trailing spaces). Potential DN injection in org/user/group creation |
| S6 | **No JWT token revocation** | `auth.py`, `main.py` | **High** | No blacklist, no logout endpoint. Terminated users retain valid JWTs until expiry (up to 7 days with "remember me"). `/api/users/{uid}/terminate` disables LDAP but cannot revoke JWT sessions |
| S7 | **JWT_SECRET has no minimum length validation** | `config.py:55-72` | Medium | Unlike `ORG_QR_SIGNING_SECRET` (which requires ≥32 chars and rejects the default), `JWT_SECRET` only warns at startup — no fail-fast check, no length minimum. Docker compose default is a readable string |
| S8 | **No password complexity enforcement** | `main.py`, `auth.py` | Medium | `min_length=1` is the only validation. No uppercase/digit/special character requirements anywhere in the backend |
| S9 | **Error information leakage** | `main.py:266,337-354,1378` | Medium | OIDC token errors leak exception messages (`Invalid token: {e}`); health detail endpoint exposes `str(e)` for DB/LDAP/Redis connection errors; LDAP operation errors leak internal details |
| S10 | X-Forwarded-For spoofing in rate limiter | `rate_limit.py:25-27` | Low | Trusts first value of `X-Forwarded-For` without verifying proxy chain |
| S11 | SSHA uses SHA-1 for password hashing | `ldap_client.py:18-21` | Low | Legacy, for OpenLDAP compatibility; SSHA with salt is the standard LDAP approach |

### MAGIC_NUMBER

| ID | Finding | Location | Impact |
|----|---------|----------|--------|
| M1 | `profile_id=org_dn` placeholder in QR generation | `main.py:1929` | Low — placeholder for future per-user profile mapping (see deferred item D5) |
| M2 | 50 events per poll cycle | `sync_worker.py:41` | Low — reasonable batch size, could be configurable |
| M3 | 5-second poll interval | `sync_worker.py:30` | Low — balances latency vs load |
| M4 | 720 cycles between prune runs (~1 hour) | `sync_worker.py:59` | Low — reasonable maintenance interval |
| M5 | 90-day event retention | `sync_worker.py:31` | Low — standard audit retention period |
| M6 | `min(5 * 3^attempt, 3600)` backoff formula | `sync_worker.py:22` | Low — caps at 1 hour, starts at 5s |

### TOCTOU (Time-of-Check-Time-of-Use)

| ID | Finding | Location | Impact |
|----|---------|----------|--------|
| T1 | Gap between DN lookup (service bind) and user bind (user creds) | `auth.py:158-170` | Very Low — standard LDAP auth pattern; user could theoretically be deleted between lookup and bind, but bind would simply fail |

### DESIGN

| ID | Finding | Location | Impact |
|----|---------|----------|--------|
| D1 | Late import to avoid potential circular dependency | `sync_worker.py:106` | Low — `decrypt_value` imported at top level, but `decrypt_payload_password` lazily imported inside method |
| D2 | Module-level Fernet cache with env var change detection | `ued_crypto.py` | Positive — avoids re-initializing Fernet on every call while handling config changes |
| D3 | `sso: null` in v2 schema (Phase 1) | `qr_signing.py:67` | By design — SSO profile slot reserved for Phase 2 implementation |
| D4 | Dual QR schemas coexist (v1 + v2) | `main.py`, `qr_signing.py` | Medium — `azblink.ucchat_core_provision/v1` and `azblink.provisioning.v2` use different field names and signature encodings. Potential client confusion |
| D5 | Config templates not wired to QR generation | `main.py:1900-1914` | By design (future) — per-org XMPP/SIP overrides exist in admin API but env defaults are sole source for QR payloads |

### RATE_LIMITING

| ID | Finding | Location | Impact |
|----|---------|----------|--------|
| R1 | Backend rate limiting | `rate_limit.py` | Positive — Redis-backed via slowapi. Default 100/min, bootstrap 5/hour, user_create 20/min, QR 10/min |
| R2 | UED Sync rate limiting | `ued-sync/middleware/rate_limit.py` | Positive — slowapi-based, configurable via `RATE_LIMIT_ENABLED`/`RATE_LIMIT_REQUESTS` env vars |

### CORS

| ID | Finding | Location | Impact |
|----|---------|----------|--------|
| C1 | CORS properly configured | `main.py:94-100` | Positive — explicit origins (not `*`), `allow_credentials=True`. `CORS_ORIGINS` defaults to localhost:8081; must be reconfigured for production |

---

## 6. Audit Corrections

This section documents corrections made during the 4-agent cross-verification audit.

### 6.1 Systematic Line Count Correction

All line counts in the original report were consistently off by +1 (likely counting the trailing newline as a content line).

| File | Original | Corrected (`wc -l`) |
|------|----------|---------------------|
| `ued_sync_client.py` | 148 | **147** |
| `sync_worker.py` | 143 | **142** |
| `ued_crypto.py` | 66 | **65** |
| `ued-sync/main.py` | 37 | **36** |
| `ldap_ops.py` | 336 | **335** |
| `Dockerfile.ued-sync` | 35 | **34** |
| `migrations/010_ued_sync.sql` | 72 | **71** |
| `auth.py` | 207 | **206** |
| `qr_signing.py` | 144 | **143** |
| `config.py` | 152 | **151** |
| `main.py` | 3203+ | **3202** |
| `orgdb.py` | 2583+ | **2582** |

### 6.2 Substantive Corrections

| # | Original Claim | Correction | Severity |
|---|----------------|------------|----------|
| 1 | `GenericLdapClient` is an "async context manager" | It is a **synchronous** context manager (`__enter__`/`__exit__`, not `__aenter__`/`__aexit__`) | Medium |
| 2 | LDAP error codes: 0, 32, 68, 49 | Actual map has **6 entries**: 0, 32, 68, 19, 49, -1. Plus string codes `LDAP_TIMEOUT` and `LDAP_INVALID_DN` | Low |
| 3 | "182 unit + API tests" | **176 non-integration** / **194 total** including 18 integration tests | Low |
| 4 | Report implies `python-ldap` (`ldap.initialize`, `simple_bind_s`) | Backend uses **`ldap3`** library with `Server()`/`Connection()` API | High |
| 5 | JWT contains `sub` field | JWT uses **`uid`** as subject identifier, not standard `sub` | Medium |
| 6 | Attributes fetched include `o` (organization) | Only 5 attributes: **uid, displayName, cn, mail, memberOf** — no `o` | Low |
| 7 | QR xmpp has `jid, password, wsUrl`; sip has `uri, password, wssUrl` | xmpp has **domain, wsUrl**; sip has **domain, wssUrl**; credentials in separate **`credentials`** block with `username` + `token` | High |
| 8 | QR field names: `timestamp`, `expiresAt`, `signature` | Actual field names: **`iat`**, **`exp`**, **`sig`** | Medium |
| 9 | Nonce replay protection via `provision_tokens` table | Replay protection is **token-based** (one-time provision token), not nonce-based. Nonce exists in signed wrapper but is never checked server-side | Medium |
| 10 | XmppConfigUpdate has `ws_url`, `conference_domain` | Actual fields: **`websocket_url`**, **`conference_server`**, plus `enabled` and `resource_binding` | Medium |
| 11 | SipConfigUpdate has `wss_url`, `stun_server`, `turn_server` | Actual fields: **`websocket_url`**, **`transport`**, **`srtp_required`** — `stun_server` and `turn_server` do not exist | High |
| 12 | QrSettingsUpdate has `ttl_seconds`, `max_scans` | Actual fields: **`default_validity_minutes`**, **`one_time_use`**, **`auto_email_on_create`**, **`deep_link_scheme`** | High |
| 13 | Config templates stored as "JSONB in `org_profiles` table" | Stored as **JSON** (not JSONB) in separate **`config_templates`** table | Medium |
| 14 | QR generation "loads org profile → falls back to env defaults" | QR generation uses env defaults **directly and exclusively** — no org profile loading occurs | High |
| 15 | batch.py response codes: 200, 207, 500, 503 | Actually declares **6 codes**: 200, 207, **400**, **401**, 500, 503 | Low |

---

## 7. Appendix: Files Analyzed

### Pass 1: Broad Scan (5 parallel agents)

| Agent | Scope | Files Discovered |
|-------|-------|-----------------|
| UED Sync scan | `src/backend/ued_*`, `src/ued-sync/` | 15+ files |
| XMPP/SIP scan | `config.py`, `main.py`, `schema.py` | 8+ files |
| QR-LDAP scan | `auth.py`, `qr_signing.py`, `main.py` | 6+ files |
| UED internals | `src/ued-sync/src/ued_sync/` | 10+ files |
| DB schema | `orgdb.py`, `migrations/` | 4+ files |

### Pass 2: Deep Analysis (full file reads)

| File | Lines | Module |
|------|-------|--------|
| `src/backend/ued_sync_client.py` | 147 | HTTP event dispatcher |
| `src/backend/sync_worker.py` | 142 | Background poller |
| `src/backend/ued_crypto.py` | 65 | Fernet encryption |
| `src/backend/qr_signing.py` | 143 | HMAC-SHA256 QR signing |
| `src/backend/auth.py` | 206 | LDAP bind + JWT (ldap3) |
| `src/backend/config.py` | 151 | Environment configuration |
| `src/backend/main.py` | 3202 | API routes (UED + QR sections) |
| `src/backend/orgdb.py` | 2582 | PostgreSQL operations |
| `src/backend/rate_limit.py` | — | Redis-backed rate limiting |
| `src/ued-sync/src/ued_sync/main.py` | 36 | FastAPI entry point |
| `src/ued-sync/src/ued_sync/routers/sync.py` | ~200 | Sync endpoints |
| `src/ued-sync/src/ued_sync/routers/batch.py` | ~150 | Batch operations |
| `src/ued-sync/src/ued_sync/schema.py` | 209 | Provisioning schema |
| `src/ued-sync/src/ued_sync/ldap_ops.py` | 335 | LDAP client (sync context manager) |
| `src/ued-sync/src/ued_sync/auth.py` | ~50 | API key auth |
| `src/ued-sync/src/ued_sync/password_utils.py` | ~40 | Password hashing |
| `src/ued-sync/src/ued_sync/sync_models.py` | 177 | Request/response Pydantic models |
| `src/ued-sync/src/ued_sync/middleware/rate_limit.py` | — | Rate limiting middleware |
| `deploy/dev/Dockerfile.ued-sync` | 34 | Container build |
| `deploy/dev/docker-compose.yml` | (section) | Service definition |
| `migrations/010_ued_sync.sql` | 71 | Database migration |

### Pass 3: Cross-Verification Audit (4 parallel agents)

| Agent | Scope | Tool Calls | Findings |
|-------|-------|------------|----------|
| Agent 1: UED Sync | Client, server, infra, tests | 27 | 12 claims verified, 15 corrections |
| Agent 2: XMPP/SIP | Profile layers, models, QR flow | 25 | 5 claims verified, 8 corrections, 6 missing items |
| Agent 3: QR-LDAP Auth | Auth chain, JWT, QR signing | 30+ | 7 claims verified, 7 corrections, 9 missing items |
| Agent 4: Security | Security tags, completeness | 40+ | 10 tags verified, 7 new security findings |

---

*Report generated by iterative three-pass analysis with 4-agent cross-verification audit. All findings are based on static code review — no runtime testing was performed.*
