# SSO Integration Requirements & Gap Audit

**Date:** 2026-02-15
**Analyst:** Claude Opus 4.6 (Evidence-based iterative analysis)
**Scope:** Full monorepo — `src/backend/`, `src/ued-sync/`, `src/frontend/`, `deploy/`, `specs/v2.0/`, `docs/prd/`
**Methodology:** Three-phase forensic audit (Discovery → Forensic Analysis → Execution Trace)
**Reference Report:** `docs/reports/2026-02-14-ued-sync-xmpp-sip-qr-auth-analysis.md`

---

## 1. Executive Summary

### Current Status

| Subsystem | Functional Coverage | SSO Readiness |
|-----------|-------------------|---------------|
| UED Sync (LDAP provisioning) | **Complete** | Not SSO-dependent — independent |
| QR Provisioning (UC core, v2 schema) | **Complete** | `sso` slot reserved (`null` in Phase 1) |
| QR Provisioning (SSO block) | **Scaffolded** | Org profile SSO config stored but not injected into unified QR |
| LDAP Bind Authentication | **Complete** | Functions independently of SSO |
| OIDC Token Verification | **Complete** | `oidc_verify.py` verified against JWKS |
| Authentik Session Revocation | **Placeholder** | `main.py:1389-1392` — hardcoded `"not_configured"` |
| UC Server Session Termination | **Placeholder** | `main.py:1394-1397` — hardcoded `"not_configured"` |
| Frontend SSO Org Config UI | **Complete** | SSOConfigTab, EditSSOModal, SSOBadge, SSOStatusCard |
| Frontend Auth Flow (OIDC login) | **Not Started** | Auth store is LDAP-only (`auth-store.ts`) |
| Breakglass Emergency Bypass | **Complete** | File-based, IP-restricted, mode-aware |
| Dual Auth Plane Routing | **Complete** | `require_user`/`require_admin` route LDAP ↔ OIDC |

### The "Ground Truth"

The system implements a fully functional **LDAP-only authentication plane** (Plane A) with UC provisioning via QR codes. The OIDC verification module (`oidc_verify.py`) is wired in but **dormant by default** (`REQUIRE_OIDC_AUTH=false`). The SSO integration exists at three distinct layers of completeness: (1) the **org-level SSO config CRUD is complete** — admins can store OIDC issuer/clientId/scopes per organization; (2) the **QR#2 SSO profile payload builder exists** and generates `azblink.sso_profile` payloads, but the **unified QR endpoint does NOT inject SSO into the v2 payload** — it always passes `sso_payload=None`; (3) the **Authentik client and UC Server client do not exist as code files** — they are specified only in the PRD as pseudocode. The termination endpoint has explicit TODO placeholders at lines 1389-1397 of `main.py`.

---

## 2. Technical Audit

### Critical Findings

#### `[BLOCKER]` B1 — Unified QR endpoint never populates SSO block

**Location:** `src/backend/main.py:1861-1959` (`api_user_qrcode`)
**Evidence:** The unified QR endpoint (`GET /api/users/{uid}/qrcode`) calls `sign_provisioning_payload(uc_payload, sso_payload=None)`. The `sso_payload` parameter is hardcoded to `None`. Even when an OrgProfile has `ssoProfile.enabled=true` with a valid OIDC issuer, the unified QR#1 endpoint ignores it.

The **dual QR endpoint** (`GET /api/users/{uid}/qrcodes`, lines 1963-2072) does build QR#2 with SSO data, but this is the legacy split-QR approach (separate `azblink.sso_profile` schema), not the v2 unified payload.

**Impact:** Phase 2 PRD §3.2 requires the unified endpoint to conditionally include SSO. This is the single largest code gap for SSO activation.

---

#### `[BLOCKER]` B2 — `authentik_client.py` does not exist

**Location:** Missing file — specified in `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md:250-396`
**Evidence:** `grep -r "authentik_client" src/backend/` returns zero matches in Python files. The PRD provides a complete pseudocode implementation but no actual file exists. The termination endpoint at `main.py:1389-1392` has:
```python
# 3. Revoke Authentik sessions (placeholder - not implemented yet)
# TODO: Implement when Authentik integration is added
authentik_sessions_revoked = None
actions["authentik_sessions"] = "not_configured"
```

**Impact:** Blocks complete user termination across both auth planes. A terminated user's Authentik sessions would remain active.

---

#### `[BLOCKER]` B3 — `uc_client.py` does not exist

**Location:** Missing file — specified in `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md:400-522`
**Evidence:** `grep -r "uc_client" src/backend/` returns zero matches. The termination endpoint at `main.py:1394-1397` has:
```python
# 4. Signal UC Server (placeholder - not implemented yet)
# TODO: Implement when UC Server API is available
uc_sessions_terminated = None
actions["uc_sessions"] = "not_configured"
```

**Impact:** Blocks active UC session termination. LDAP disable prevents new logins but does NOT disconnect existing XMPP/SIP sessions.

---

#### `[BLOCKER]` B4 — Frontend auth store has no OIDC flow

**Location:** `src/frontend/src/stores/auth-store.ts`
**Evidence:** The `login()` method (line 56) POSTs to `/auth/login` with username/password only (LDAP bind). No OIDC authorization code flow, no PKCE, no token exchange, no refresh logic. When `REQUIRE_OIDC_AUTH=true`, the frontend would have no way to authenticate users.

**Impact:** Blocks end-to-end SSO for admin portal users.

---

#### `[BLOCKER]` B5 — Missing config variables for Authentik/UC Server

**Location:** `src/backend/config.py`
**Evidence:** The following variables specified in PRD §3.7 are absent from `config.py`:
- `AUTHENTIK_API_URL`
- `AUTHENTIK_API_TOKEN`
- `UC_SERVER_API_URL`
- `UC_SERVER_API_KEY`

These are referenced in the PRD pseudocode but never defined in the actual config module.

**Impact:** Even if `authentik_client.py` and `uc_client.py` were created, they would have no configuration source.

---

#### `[DEBT]` D1 — Split QR endpoint uses legacy schema

**Location:** `src/backend/main.py:1963-2072` (`api_user_qrcodes`)
**Evidence:** The `/api/users/{uid}/qrcodes` endpoint generates QR#2 with schema `azblink.sso_profile` (v1-era). The v2 spec requires SSO to be embedded in the unified `azblink.provisioning.v2` payload. This endpoint should be deprecated once the unified QR injects SSO.

---

#### `[DEBT]` D2 — SSO profile builder has hardcoded app list

**Location:** `src/backend/main.py:2347-2393` (`_build_sso_profile_payload`)
**Evidence:** The OIDC clients dictionary hardcodes five app names:
```python
"clients": {
    "teampulse": ..., "ehub": ..., "safenest": ...,
    "usentinel": ..., "nextcloud": ...,
}
```
These are not configurable and would require code changes to add new SSO-enabled applications.

---

#### `[DEBT]` D3 — Database schema missing Phase 2 migration

**Location:** `migrations/` directory
**Evidence:** The PRD §4.2 specifies `migrations/005_phase2_sso.sql` with `breakglass_audit` table and `authentik_tokens_revoked` column on `termination_events`. This migration file does not exist. Note: the `authentik_sessions_revoked` column already exists on `termination_events` (orgdb.py:130), but the `breakglass_audit` table does not.

---

#### `[IMPLICIT]` I1 — Admin role fallback in non-OIDC mode

**Location:** `src/backend/main.py:273-282` (`require_admin`)
**Evidence:** When `REQUIRE_OIDC_AUTH=false`, the function returns claims without checking group membership:
```python
if not REQUIRE_OIDC_AUTH:
    return claims  # all authenticated users are admin
```
This is intentional for backward compatibility but means **every LDAP-authenticated user has admin privileges** in the default deployment mode. Enabling `REQUIRE_OIDC_AUTH` changes the security model fundamentally.

---

#### `[IMPLICIT]` I2 — LDAP JWT and OIDC JWT use different signing mechanisms

**Location:** `src/backend/auth.py` (LDAP JWT: HS256 symmetric) vs `src/backend/oidc_verify.py` (OIDC: RS256/ES256 asymmetric)
**Evidence:** The LDAP login flow generates JWTs signed with `JWT_SECRET` (symmetric HS256). The OIDC flow verifies tokens signed with the IdP's public key (asymmetric RS256+). When transitioning to `REQUIRE_OIDC_AUTH=true`, the LDAP login endpoint (`POST /api/auth/login`) continues to issue HS256 JWTs, but `_claims_from_auth_header()` only calls `verify_bearer_token()` (OIDC verification) for the Bearer token. **The LDAP login route is excluded from the OIDC requirement** — it uses its own JWT auth via `verify_jwt_token()` in the `require_user` dependency. These two auth paths must both work or the system must clearly choose one.

---

#### `[HARDCODED]` H1 — Breakglass expires in 2030

**Location:** `deploy/dev/runtime/breakglass.json`
**Evidence:**
```json
{
  "enabled": true,
  "expires_at": "2030-12-31T23:59:59+00:00",
  "note": "Development breakglass - long expiry for dev convenience."
}
```
The dev breakglass has a 4+ year TTL and allows all RFC1918 private IPs. This file is volume-mounted in Docker. If this file pattern leaks to production, it permanently bypasses OIDC auth.

---

#### `[RISK]` R1 — No account soft-lock on auth failures

**Location:** `src/backend/main.py` (auth failure recording)
**Evidence:** Auth failures are recorded to `auth_failure_audit` table, but no lockout mechanism exists. The v2 spec and gap analysis (§1.3) require: "Lock account after 5 failures within 5 minutes." This is missing from both LDAP and OIDC auth paths.

---

#### `[RISK]` R2 — LDAP auth and OIDC auth not unified for admin portal

**Location:** `src/backend/main.py:240-266`, `src/backend/auth.py`
**Evidence:** The current code has **two separate login mechanisms**:
1. `POST /api/auth/login` → LDAP bind → HS256 JWT (used by frontend today)
2. Bearer token in `Authorization` header → OIDC JWKS verification (used when `REQUIRE_OIDC_AUTH=true`)

When SSO is enabled, there is no defined transition path. The frontend would need to either:
- (a) Redirect to Authentik's login page (OIDC Authorization Code + PKCE flow), or
- (b) Continue using LDAP login and have the backend accept both JWT types simultaneously

Neither path is implemented. This is a design decision that blocks the entire SSO activation.

---

#### `[AMBIGUITY]` A1 — Dual QR endpoints with overlapping purpose

**Location:** `main.py:1861` (`/api/users/{uid}/qrcode`) vs `main.py:1963` (`/api/users/{uid}/qrcodes`)
**Evidence:** Two QR generation endpoints exist:
- `/qrcode` (singular): Returns unified v2 payload, `sso=null` always
- `/qrcodes` (plural): Returns separate QR#1 + conditional QR#2

The v2 spec says the unified endpoint should include SSO when enabled. Once B1 is fixed, the `/qrcodes` endpoint becomes redundant but no deprecation flag exists.

---

### Dependency Graph

```
Authentik Deployment (external)
  ├── AUTHENTIK_API_URL + AUTHENTIK_API_TOKEN (B5)
  │     └── authentik_client.py (B2)
  │           └── Termination endpoint (main.py:1389) — revoke sessions
  │           └── Deep health check — Authentik status
  │
  ├── OIDC_ISSUER + OIDC_AUDIENCE (already in config.py)
  │     └── oidc_verify.py (already functional)
  │           └── require_user / require_admin (already routes)
  │                 └── Frontend OIDC login flow (B4)
  │
  └── OrgProfile.ssoProfile (already stored)
        └── Unified QR SSO injection (B1)

UC Server Admin API (external)
  ├── UC_SERVER_API_URL + UC_SERVER_API_KEY (B5)
  │     └── uc_client.py (B3)
  │           └── Termination endpoint (main.py:1394) — kill sessions
  │           └── Deep health check — UC Server status

UED Sync (internal, complete)
  └── Independent of SSO — triggered by user lifecycle events
      └── Receives termination events via emit_sync_event()
```

---

## 3. The Runtime Trace

### Trace 1: Current State — Admin Logs In and Generates QR (LDAP Mode)

```
1. [Frontend] auth-store.login(username, password)
     → POST /api/auth/login {username, password, remember}

2. [main.py] api_login() → auth.authenticate_user()
     2a. get_conn() → admin LDAP bind
     2b. find_user_dn(admin_conn, OU_PEOPLE, username) → user DN
     2c. _get_user_bind_connection(user_dn, password) → LDAP bind as user
         → SUCCESS: password verified server-side
         → FAILURE: return LoginError("INVALID_CREDENTIALS")
     2d. _fetch_user_details(user_dn) → uid, displayName, mail, groups
     2e. _generate_jwt(user_data, user_dn, remember)
         → isAdmin = "IT-Admins" in groups
         → JWT(HS256, exp=8h or 7d)

3. [Frontend] auth-store stores token + user in localStorage/sessionStorage

4. [Frontend] User navigates to user detail → generates QR
     → GET /api/users/{uid}/qrcode, Authorization: Bearer <JWT>

5. [main.py] require_user() → _claims_from_auth_header()
     5a. REQUIRE_OIDC_AUTH=false → return {"sub": "anonymous", "groups": []}
         (NOTE: JWT is in header but not verified in non-OIDC mode)

6. [main.py] api_user_qrcode()
     6a. get_user(uid) → LDAP lookup
     6b. secrets.token_urlsafe(24) → provision_token
     6c. SHA-256(provision_token) → token_hash
     6d. ORGDB.record_provision_token(token_hash, uid, "unified", exp)
     6e. Build uc_payload = {tenant, xmpp, sip, credentials}
     6f. sign_provisioning_payload(uc_payload, sso_payload=None, ttl)
         → azblink.provisioning.v2, sso=null
     6g. ORGDB.record_qr_issuance(...)
     6h. make_qr_png_base64(payload_json)
     6i. Return {ok, uid, orgDn, qrType, ssoEnabled=false, payload, pngBase64}
```

**Data Mutations:**
- LDAP: read-only (bind + search)
- PostgreSQL: INSERT into `provision_tokens`, INSERT into `qr_issuance_audit`
- No SSO data touched at any point

---

### Trace 2: Target State — SSO-Enabled QR Generation (Phase 2, NOT YET IMPLEMENTED)

```
1. [Frontend] OIDC login via Authentik
     → Redirect to Authentik authorization endpoint
     → User authenticates (Authentik login page)
     → Redirect back with authorization code
     → Frontend exchanges code + PKCE verifier for tokens
     → auth-store receives access_token (RS256 signed by Authentik)

2. [main.py] require_user() → _claims_from_auth_header()
     2a. REQUIRE_OIDC_AUTH=true
     2b. Bearer token present → verify_bearer_token(token)
         → oidc_verify.py: fetch JWKS from Authentik
         → Verify RS256 signature, audience, issuer, expiry
         → Return claims {sub, groups, email, ...}
     2c. require_admin() checks OIDC_ADMIN_GROUP in claims.groups

3. [main.py] api_user_qrcode() [MODIFIED - B1 FIXED]
     3a. get_user(uid) → LDAP lookup
     3b. _find_org_profile_for_dn(org_dn) → OrgProfile from PostgreSQL
     3c. IF ssoProfile.enabled AND ssoProfile.oidc.issuer:
           sso_payload = {issuer, clientId, scopes, pkceRequired}
         ELSE:
           sso_payload = None
     3d. sign_provisioning_payload(uc_payload, sso_payload, ttl)
         → azblink.provisioning.v2, sso={...} or null
     3e. Return {ssoEnabled: true/false, payload: {...}}

4. [Client App] Scans QR → extracts UC config → connects XMPP/SIP
     4a. IF payload.sso present:
           → Store OIDC config
           → Initiate PKCE authorization flow against Authentik
           → Obtain access/refresh tokens
           → Use for web app SSO
```

---

### Trace 3: Target State — User Termination with SSO Revocation (Phase 2, NOT YET IMPLEMENTED)

```
1. [main.py] api_user_terminate(uid, reason)
     1a. get_user(uid) → LDAP lookup

2. LDAP Disable (CRITICAL - abort on failure)
     → disable_user(uid) → sets userAccountControl
     → XMPP/SIP: new binds rejected
     → Existing XMPP/SIP sessions: STILL ACTIVE (B3 gap)

3. Token Revocation
     → ORGDB.revoke_tokens_for_user(uid)
     → QR codes become invalid

4. Authentik Session Revocation [REQUIRES B2]
     → authentik_client.revoke_all_user_access(uid)
       4a. GET /api/v3/core/authenticated_sessions/?user__username={uid}
       4b. DELETE /api/v3/core/authenticated_sessions/{uuid}/ (each session)
       4c. GET /api/v3/core/tokens/?user__username={uid}
       4d. DELETE /api/v3/core/tokens/{id}/ (each token)
     → Web SSO sessions terminated

5. UC Server Session Termination [REQUIRES B3]
     → uc_client.send_termination_notice(uid, message)
       5a. POST /api/admin/notify {username, type, message}
     → uc_client.terminate_user_sessions(uid)
       5b. POST /api/admin/sessions/terminate {username}
     → XMPP/SIP connections forcibly closed

6. Audit + UED Sync
     → ORGDB.record_termination(all_actions)
     → emit_sync_event("user_terminated", ...)
     → UED Sync worker propagates to target LDAP (if configured)
```

---

## 4. Pragmatic Action Plan

*Ordered by dependency chain. Each task must complete before dependent tasks begin.*

| Priority | Task | Type | Rationale | Definition of Done |
|:---|:---|:---|:---|:---|
| **P0-a** | Add `AUTHENTIK_API_URL`, `AUTHENTIK_API_TOKEN`, `UC_SERVER_API_URL`, `UC_SERVER_API_KEY` to `config.py` | Feature | Fixes `[BLOCKER]` B5 — no config source for integration clients | Variables read from env with empty defaults; startup validation warns if OIDC enabled but Authentik URL missing |
| **P0-b** | Create `src/backend/authentik_client.py` | Feature | Fixes `[BLOCKER]` B2 — no Authentik session revocation | `AuthentikClient` class with `health_check()`, `revoke_user_sessions()`, `revoke_user_tokens()`, `revoke_all_user_access()`; unit tests with mocked HTTP |
| **P0-c** | Create `src/backend/uc_client.py` | Feature | Fixes `[BLOCKER]` B3 — no UC session termination | `UCServerClient` class with `health_check()`, `terminate_user_sessions()`, `send_termination_notice()`; unit tests with mocked HTTP |
| **P0-d** | Wire `authentik_client` and `uc_client` into termination endpoint | Feature | Resolves TODO at `main.py:1389-1397` | Termination response includes actual session/token revocation counts; graceful degradation when services unavailable |
| **P0-e** | Inject SSO block into unified QR endpoint | Feature | Fixes `[BLOCKER]` B1 — `sso_payload` always `None` | `GET /api/users/{uid}/qrcode` returns `sso: {...}` when org has SSO enabled; `sso: null` when disabled; existing tests pass; new SSO tests added |
| **P1-a** | Create `breakglass_audit` table migration | Feature | Fixes `[DEBT]` D3 — no breakglass audit trail | `migrations/011_phase2_sso.sql` creates `breakglass_audit` table; breakglass activations logged |
| **P1-b** | Add deep health check for Authentik + UC Server | Feature | PRD §3.8 — health status for optional services | `GET /api/health/deep` returns `authentik: healthy/unhealthy/not_configured`, `uc_server: healthy/unhealthy/not_configured`; "degraded" status when optional services down |
| **P1-c** | Implement account soft-lock on auth failures | Feature | Fixes `[RISK]` R1 — no lockout mechanism | 5 failures in 5 minutes locks account for 15 minutes; applies to both LDAP and OIDC paths; redis-backed counter |
| **P1-d** | Deprecate `/api/users/{uid}/qrcodes` split endpoint | Refactor | Fixes `[AMBIGUITY]` A1 — overlapping endpoints | Add `Deprecation` header to response; update frontend to use unified endpoint |
| **P2-a** | Design frontend OIDC auth flow | Feature | Fixes `[BLOCKER]` B4 — no OIDC login in frontend | Design doc specifying: redirect to Authentik → code exchange → token storage → refresh logic → logout flow |
| **P2-b** | Implement frontend OIDC auth flow | Feature | Depends on P2-a | `oidc-auth.ts` module; auth-store updated to handle both LDAP and OIDC tokens; conditional login page based on `REQUIRE_OIDC_AUTH` flag from `/api/tenant` response |
| **P2-c** | Harden breakglass for production | Fix | Fixes `[HARDCODED]` H1 — 4-year dev TTL | Production deployment guide specifies max 24h TTL; `directoryctl.py` enforces TTL ceiling; dev file unchanged |
| **P3-a** | Make SSO app list configurable | Refactor | Fixes `[DEBT]` D2 — hardcoded app names | Move OIDC client map to OrgProfile JSON; `_build_sso_profile_payload()` reads from profile instead of hardcoding |

---

## 5. Unresolved Questions

These cannot be resolved by static analysis and require human/product decisions or runtime verification:

| # | Question | Requires | Impact |
|:---|:---|:---|:---|
| **Q1** | When `REQUIRE_OIDC_AUTH=true`, should the LDAP login endpoint (`POST /api/auth/login`) remain accessible, or should it be disabled entirely? | Product decision | Determines whether admin portal supports dual-login (LDAP + OIDC) or OIDC-only. Affects B4 implementation significantly. |
| **Q2** | Does the UC Server (XMPP/SIP) have an admin API for session termination? What is the exact API contract? | UC team verification | The PRD specifies `/api/admin/sessions/terminate` and `/api/admin/notify`, but this API is hypothetical. If the UC server doesn't expose these endpoints, B3 is blocked by external dependency. |
| **Q3** | Should the Authentik instance be shared-database with the Directory Portal PostgreSQL, or isolated? | Ops/architecture decision | `config.py:22` comments suggest same Postgres server but separate database. Shared connection pooling, backup, and migration strategy depend on this. |
| **Q4** | What is the OIDC scope/claim mapping for XMPP/SIP authentication via SSO? | Architecture decision | Today, XMPP/SIP use direct LDAP bind (Plane A). The user's stated intent is "XMPP + SIP via SSO as well." This would require the XMPP/SIP servers to accept OIDC tokens instead of (or in addition to) LDAP bind — a fundamental change to the UC server, not just the Directory Portal. |
| **Q5** | What Authentik API permissions are required for the admin token? | Security review | The PRD client calls `authenticated_sessions` (list/delete) and `tokens` (list/delete). Minimum required scope needs definition to follow principle of least privilege. |
| **Q6** | Should the frontend OIDC flow use popup-based or redirect-based authorization? | UX decision | Affects implementation of B4. Popup avoids full page reload but requires careful origin validation. Redirect is simpler but disrupts admin workflow. |
| **Q7** | When the unified QR includes SSO, should the mobile client validate the OIDC issuer reachability before storing the config? | Mobile team decision | Prevents storing broken SSO config, but adds latency and failure mode to QR scan flow. |

---

## Appendix A: File Manifest

### High Relevance (analyzed in detail)

| File | Lines | Relevance |
|:---|:---|:---|
| `src/backend/main.py` | 3200+ | Auth routing, QR generation, termination, SSO profile endpoints |
| `src/backend/auth.py` | 207 | LDAP bind + HS256 JWT generation |
| `src/backend/oidc_verify.py` | 101 | OIDC RS256 JWT verification via JWKS |
| `src/backend/config.py` | 152 | All env vars; missing Authentik/UC Server vars |
| `src/backend/qr_signing.py` | 144 | HMAC-SHA256 v2 payload signing; sso slot functional |
| `src/backend/orgdb.py` | 2583+ | `record_termination()` with `authentik_sessions_revoked` column |
| `src/frontend/src/stores/auth-store.ts` | ~130 | LDAP-only login; no OIDC |
| `src/frontend/src/types/org.ts` | ~90 | `SSOConfig` interface — complete |
| `src/frontend/src/types/org-profiles.ts` | ~180 | Template-level SSO config — complete |
| `src/frontend/src/components/features/org-management/SSOConfigTab.tsx` | 82 | SSO config display — complete |
| `src/frontend/src/components/features/org-management/modals/EditSSOModal.tsx` | ~160 | SSO edit form — complete |
| `deploy/dev/runtime/breakglass.json` | 7 | Dev breakglass — 2030 expiry |
| `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md` | 1287 | Full Phase 2 spec with pseudocode |
| `specs/v2.0/V1_TO_V2_GAP_ANALYSIS.md` | 595 | Comprehensive v1→v2 gap analysis |
| `docs/reports/2026-02-14-ued-sync-xmpp-sip-qr-auth-analysis.md` | 622 | UED + QR + LDAP auth analysis |

### Medium Relevance (referenced for context)

| File | Relevance |
|:---|:---|
| `src/backend/ued_sync_client.py` | UED event dispatch — independent of SSO |
| `src/backend/sync_worker.py` | Background poller — independent of SSO |
| `src/backend/ued_crypto.py` | Fernet encryption — used by UED, not SSO |
| `src/ued-sync/src/ued_sync/` (all) | UED Sync microservice — no SSO dependency |
| `migrations/010_ued_sync.sql` | UED tables — no SSO columns |
| `src/frontend/src/components/features/org-management/SSOStatusCard.tsx` | Toggle card — UI complete |
| `src/frontend/src/components/features/org-management/SSOBadge.tsx` | Status badge — UI complete |
| `deploy/dev/docker-compose.yml` | No Authentik service defined |

### Low Relevance (inventoried, not analyzed)

| Category | Count |
|:---|:---|
| UED Sync internal plans (`src/ued-sync/docs/plans/`) | 14 files |
| Frontend QR management components | 10+ files |
| Frontend provisioning ops components | 8+ files |
| Backend test suite | 20+ files |
| Database migrations (non-SSO) | 10 files |

---

## Appendix B: Critical Path to SSO Activation

```
Phase 2 Dependencies (sequential):

  ┌─────────────────────────────────────────────────────────┐
  │ P0-a: Add config vars for Authentik + UC Server         │
  └────────────┬────────────────────┬───────────────────────┘
               │                    │
  ┌────────────▼──────┐  ┌─────────▼──────────┐
  │ P0-b: Create      │  │ P0-c: Create       │
  │ authentik_client.py│  │ uc_client.py       │
  └────────────┬──────┘  └─────────┬──────────┘
               │                    │
  ┌────────────▼────────────────────▼───────────────────────┐
  │ P0-d: Wire into termination endpoint                    │
  └─────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────┐
  │ P0-e: Inject SSO into unified QR (independent of above) │
  └─────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────┐
  │ P2-a/b: Frontend OIDC auth flow (can parallel P0 work)  │
  └─────────────────────────────────────────────────────────┘

  External dependencies (blocking):
  - Authentik deployed and configured
  - UC Server admin API available (or decision to defer B3)
  - Product decision on Q1 (dual login vs OIDC-only)
  - Product decision on Q4 (XMPP/SIP via SSO implications)
```

---

## Appendix C: LDAP Architecture Classification — Design A vs Design B

### The Question

When the user states the intent is "XMPP + SIP via SSO as well," this implies a change to how UC servers authenticate users. The critical architectural question is: **Does AZBlink use true LDAP replication (Design A) or API-driven attribute sync (Design B)?**

This distinction determines whether Authentik can be placed "in front of" the local LDAP for SSO, or whether the architecture requires fundamental restructuring.

### Evidence: AZBlink Implements Design B (Attribute Sync + Dual LDAP)

**Definitive statement** from `docs/plans/2026-02-13-ued-sync-integration-design.md:15-18`:

> "AZBlink Directory = identity directory of record (inetOrgPerson in its own OpenLDAP).
> UED Sync API = UC provisioner (AsteriskSIPUser + XMPP objectClasses in tenant-specific OpenLDAP).
> Two distinct LDAP servers with different schemas. AZBlink owns the identity; UED owns the UC accounts."

**Topology confirmed:**

```
AZBlink Central LDAP (inetOrgPerson)        Tenant LDAP (AsteriskSIPUser + XMPP)
┌───────────────────────────────┐           ┌───────────────────────────────┐
│ ou=people: uid, cn, mail,     │  event    │ ou=people: uid, cn, mail,     │
│   mobile, userPassword (SSHA) │──driven──▶│   userPassword (per-schema),  │
│ ou=org:   hierarchy           │  sync     │   objectClass: xmppUser,      │
│ ou=groups: memberOf           │  (HTTP)   │   sipUser, asteriskSIPUser    │
└───────────────────────────────┘           └───────────────────────────────┘
       ▲ admin writes here                    ▲ UED Sync API writes here
       ▲ XMPP/SIP do NOT bind here           ▲ XMPP/SIP bind HERE
```

### How Password Sync Works Today

Passwords are **not replicated as verifiers**. Instead:

1. Admin sets password in AZBlink → `ldap_client.py:reset_user_password()` writes SSHA hash to central LDAP
2. `main.py` emits `password_changed` sync event with **plaintext password encrypted via Fernet**
3. `sync_worker.py` decrypts, sends to UED Sync API over HTTPS
4. `ued-sync/routers/sync.py` receives plaintext, calls `hash_password()` with tenant's configured scheme (SSHA/MD5/PLAIN)
5. `ued-sync/ldap_ops.py` writes independently-hashed password to tenant LDAP

**Each LDAP hashes independently.** No verifier data flows between servers. Password consistency depends entirely on the sync pipeline's reliability.

### What This Means for SSO Integration

| Design Property | Implication for SSO |
|:---|:---|
| Two separate LDAPs with different schemas | Authentik must choose which LDAP to bind against |
| No LDAP replication | Cannot place Authentik "in front of" a replica |
| Password sync is async (5s poll + retry) | Brief window where central and tenant passwords diverge |
| UC servers bind to tenant LDAP (not central) | If Authentik binds to central LDAP, UC auth is still separate |
| UED Sync is opt-in per tenant | Some tenants may have UED, others may not |

### The Three Architectural Options for "XMPP + SIP via SSO"

#### Option 1: Authentik uses AZBlink's Central LDAP as backend

```
User → Authentik (OIDC) → LDAP bind to AZBlink Central LDAP
                                    ↕
User → XMPP/SIP → LDAP bind to Tenant LDAP (separate server)
```

- **Pro:** SSO for web apps, simplest to implement
- **Con:** XMPP/SIP still authenticate against tenant LDAP independently — "SSO" only applies to web apps, not UC protocols
- **Con:** Central LDAP becomes a WAN dependency for web SSO
- **This is what the current architecture supports with minimal changes**

#### Option 2: Authentik uses Tenant LDAP as backend (per-site)

```
User → Authentik (local) → LDAP bind to Tenant LDAP (same site)
User → XMPP/SIP          → LDAP bind to Tenant LDAP (same site)
```

- **Pro:** True local survivability — SSO + UC both work when WAN is down
- **Pro:** Single credential source at each site
- **Con:** Requires Authentik deployed per-site (not centrally)
- **Con:** Tenant LDAP must have sufficient user attributes for Authentik (currently UC-specific schema only)
- **Con:** Password changes must propagate from central → tenant → Authentik picks them up
- **This requires extending tenant LDAP schema to include identity attributes Authentik needs**

#### Option 3: Migrate to true LDAP replication (Design A)

```
Central LDAP ──syncrepl──▶ Site LDAP (read-only replica + UC schema extensions)
User → Authentik (local) → LDAP bind to Site LDAP
User → XMPP/SIP          → LDAP bind to Site LDAP
```

- **Pro:** True single-source-of-truth with local survivability
- **Pro:** Password changes propagate automatically via replication
- **Con:** Requires OpenLDAP syncrepl configuration (significant infra change)
- **Con:** Single schema must accommodate both identity and UC attributes
- **Con:** Invalidates the current UED Sync API architecture entirely
- **This is the most robust but most disruptive option**

### Recommendation (requires product decision)

The current system is architecturally aligned with **Option 1**: Authentik binds to central LDAP for web SSO, while XMPP/SIP continue using tenant LDAP via direct bind. This preserves the existing UED Sync investment and the "UC works without Authentik" invariant.

If the intent is truly "XMPP + SIP authenticate via SSO tokens" (not LDAP bind), that requires the XMPP/SIP servers themselves to accept OIDC tokens — a change outside AZBlink Directory's scope, requiring UC server modifications.

### New Unresolved Question

| # | Question | Requires | Impact |
|:---|:---|:---|:---|
| **Q8** | Which option (1, 2, or 3) aligns with the product vision for "XMPP + SIP via SSO"? Does this mean (a) web SSO only, (b) per-site Authentik with shared tenant LDAP, or (c) full replication migration? | Product/architecture decision | Determines whether UED Sync API remains relevant or is replaced by OpenLDAP replication |
| **Q9** | If Option 2, what additional attributes must the tenant LDAP schema support for Authentik to function as an OIDC provider? (Currently tenant LDAP has UC-specific objectClasses only, not full inetOrgPerson) | Schema analysis | Determines UED Sync schema extension scope |
| **Q10** | If Option 1, is WAN dependency for web SSO acceptable, or is local survivability a hard requirement? | Ops/resilience decision | Determines whether per-site Authentik is needed |

---

*Report generated by evidence-based three-phase forensic audit. All findings are based on static code analysis — no runtime testing was performed. Line numbers reference current HEAD.*

*Addendum on LDAP architecture classification added 2026-02-16 based on hub-and-spoke directory model review.*
