# Frontend API Contracts - Phase 1 UC Core QR Provisioning

> **Version:** 1.0.0
> **Status:** Production Ready
> **PRD Reference:** `docs/prd/PHASE1_UC_CORE_QR_PRD.md`

---

## Table of Contents

1. [Overview](#1-overview)
2. [TypeScript Interfaces](#2-typescript-interfaces)
3. [API Service Contracts](#3-api-service-contracts)
4. [Error Handling](#4-error-handling)
5. [Business Flow State Machines](#5-business-flow-state-machines)
6. [Data Layer Integration](#6-data-layer-integration)
7. [Rate Limiting Considerations](#7-rate-limiting-considerations)

---

## 1. Overview

### 1.1 Business Context

Phase 1 UC Core QR Provisioning enables:
- Admin Portal generates QR codes for users
- Mobile clients scan QR to configure XMPP/SIP
- One-time tokens prevent credential sharing
- Full audit trail for compliance

### 1.2 Key Actors

| Actor | Role | Primary Endpoints |
|-------|------|-------------------|
| **Admin Portal** | Generate QR, manage users, revoke tokens | `/users/{uid}/qrcode`, `/users/{uid}/qrcode/revoke` |
| **Mobile Client** | Consume QR token, connect to UC | `/provision/consume` |
| **Audit Dashboard** | View issuance/consumption logs | `/audit/*` |

### 1.3 Authentication Modes

```typescript
type AuthLevel = 'public' | 'user' | 'admin';

// When REQUIRE_OIDC_AUTH=false (dev/UC-only mode)
// All endpoints accept unauthenticated requests

// When REQUIRE_OIDC_AUTH=true (production with Authentik)
// user: Any valid OIDC Bearer token
// admin: OIDC token with OIDC_ADMIN_GROUP membership
```

---

## 2. TypeScript Interfaces

### 2.1 Common Types

```typescript
/** Standard API response wrapper */
interface ApiResponse<T = unknown> {
  ok: boolean;
  error?: string;
  detail?: string;
  [key: string]: T | boolean | string | undefined;
}

/** ISO 8601 timestamp string */
type ISOTimestamp = string; // e.g., "2024-01-01T12:00:00Z"

/** Unix epoch timestamp (seconds) */
type UnixTimestamp = number;

/** LDAP Distinguished Name */
type DN = string; // e.g., "ou=Engineering,ou=org,dc=azblink,dc=com"

/** User identifier (LDAP uid) */
type UID = string; // e.g., "alice"
```

### 2.2 QR Provisioning Schema (v2)

```typescript
/** PRD §3.1 - azblink.provisioning.v2 schema */
interface ProvisioningPayloadV2 {
  schema: 'azblink.provisioning.v2';
  payload: {
    uc: UCConfig;
    sso: SSOConfig | null; // Always null in Phase 1
  };
  iat: UnixTimestamp;  // Issued-at
  exp: UnixTimestamp;  // Expiration
  nonce: string;       // Unique per-issuance
  sig: string;         // HMAC-SHA256 signature
}

interface UCConfig {
  tenant: string;
  xmpp: {
    domain: string;    // e.g., "uc.example.com"
    wsUrl: string;     // e.g., "wss://uc.example.com/xmpp-websocket"
  };
  sip: {
    domain: string;    // e.g., "sip.example.com"
    wssUrl: string;    // e.g., "wss://sip.example.com/ws"
  };
  credentials: {
    username: UID;
    token: string;     // One-time provisioning token
  };
}

/** Phase 2 - not used in Phase 1 */
interface SSOConfig {
  enabled: boolean;
  issuer: string;
  clientId: string;
  // ... extended in Phase 2
}
```

### 2.3 User Management Types

```typescript
interface User {
  uid: UID;
  dn: DN;
  displayName: string;
  mail: string;
  mobile: string;
  orgDn: DN;
  title?: string;
  memberOf?: string[];  // Group DNs
}

interface UserCreateRequest {
  uid: UID;
  displayName?: string;
  mail?: string;
  mobile?: string;
  orgDn?: DN;           // Default: ou=org,{baseDn}
  title?: string;
  password: string;
  groups?: string[];    // Group CNs to add
}

interface UserUpdateRequest {
  displayName?: string;
  mail?: string;
  mobile?: string;
}

interface UserTerminateRequest {
  reason: string;       // e.g., "employment_ended"
  immediate?: boolean;  // Default: true
}

interface UserSuspendRequest {
  reason: string;
}

interface UserUnsuspendRequest {
  newPassword: string;
}
```

### 2.4 QR Generation Types

```typescript
/** GET /api/users/{uid}/qrcode response */
interface QRCodeResponse extends ApiResponse {
  ok: true;
  uid: UID;
  orgDn: DN;
  qrType: 'unified' | 'split';
  payload: ProvisioningPayloadV2;
  pngBase64: string;    // Base64-encoded PNG image
}

/** GET /api/users/{uid}/qrcode query params */
interface QRCodeParams {
  ttl_sec?: number;     // Token TTL (default: 3600, max: 86400)
}

/** POST /api/users/{uid}/qrcode/revoke response */
interface QRRevokeResponse extends ApiResponse {
  ok: true;
  user_uid: UID;
  tokens_revoked: number;
}
```

### 2.5 Token Consumption Types (Mobile Client)

```typescript
/** POST /api/provision/consume request */
interface ProvisionConsumeRequest {
  token: string;        // From QR payload.uc.credentials.token
  deviceId?: string;    // Optional device identifier
  clientInfo?: {
    platform: 'ios' | 'android' | 'desktop' | string;
    version: string;    // e.g., "2.1.0"
  };
}

/** POST /api/provision/consume response (Phase 1) */
interface ProvisionConsumeResponse extends ApiResponse {
  ok: true;
  uid: UID;
  consumed_at: ISOTimestamp;
  config: {
    xmpp: {
      jid: string;      // e.g., "alice@uc.example.com"
      wsUrl?: string;
    };
    sip: {
      uri: string;      // e.g., "sip:alice@sip.example.com"
      wssUrl?: string;
    };
    authMethod: 'ldap_bind';  // Phase 1 uses LDAP bind
  };
}

/** Token consumption error codes */
type TokenError =
  | 'INVALID_SIGNATURE'      // 400 - Tampered payload
  | 'TOKEN_NOT_FOUND'        // 404 - Unknown token
  | 'TOKEN_ALREADY_CONSUMED' // 409 - Already used
  | 'TOKEN_EXPIRED';         // 410 - Past exp time
```

### 2.6 Audit Types

```typescript
interface QRIssuanceAuditRecord {
  id: number;
  user_uid: UID;
  org_dn: DN;
  issued_by: string;
  issued_at: ISOTimestamp;
  token_hash: string;
  expires_at: ISOTimestamp;
  consumed: boolean;
  consumed_at?: ISOTimestamp;
  consumed_reason?: string;
  client_ip?: string;
  user_agent?: string;
}

interface TerminationAuditRecord {
  id: number;
  user_uid: UID;
  user_dn: DN;
  org_dn: DN;
  terminated_by: string;
  terminated_at: ISOTimestamp;
  reason: string;
  actions_taken: {
    ldap_disabled: boolean;
    tokens_revoked: number;
    authentik_sessions_revoked?: number;
    uc_sessions_terminated?: number;
  };
}

interface UserLifecycleRecord {
  id: number;
  uid: UID;
  event_type: 'created' | 'suspended' | 'unsuspended' | 'password_reset' | 'terminated';
  performed_by: string;
  performed_at: ISOTimestamp;
  details?: string;
}
```

### 2.7 Organization Types

```typescript
interface OrgTreeNode {
  dn: DN;
  name: string;
  children: OrgTreeNode[];
}

interface OrgCreateRequest {
  parentDn?: DN;        // Default: ou=org,{baseDn}
  name: string;
}

interface OrgRenameRequest {
  dn: DN;
  newName: string;
}
```

### 2.8 Group Types

```typescript
interface Group {
  cn: string;
  dn: DN;
  description?: string;
  members?: DN[];
}

interface GroupCreateRequest {
  orgDn?: DN;           // Default: ou=org,{baseDn}
  cn: string;
}

interface GroupMemberRequest {
  uid: UID;
}
```

---

## 3. API Service Contracts

### 3.1 QR Provisioning Service (Admin Portal)

```typescript
interface QRProvisioningService {
  /**
   * Generate unified QR code for user provisioning
   * PRD §3.4.1
   *
   * @auth user (any authenticated user can generate for users they manage)
   * @rateLimit 10/minute
   */
  generateQRCode(uid: UID, params?: QRCodeParams): Promise<QRCodeResponse>;

  /**
   * Revoke all active provisioning tokens for a user
   * PRD §3.4.3
   *
   * @auth admin
   */
  revokeUserTokens(uid: UID): Promise<QRRevokeResponse>;

  /**
   * Get QR issuance audit log
   *
   * @auth admin
   */
  getIssuanceAudit(limit?: number): Promise<{ records: QRIssuanceAuditRecord[] }>;
}
```

### 3.2 Provisioning Service (Mobile Client)

```typescript
interface MobileProvisioningService {
  /**
   * Consume one-time provisioning token from QR code
   * PRD §3.4.2
   *
   * @auth public (no auth required)
   * @rateLimit 10/minute
   * @throws TokenError on failure
   */
  consumeToken(request: ProvisionConsumeRequest): Promise<ProvisionConsumeResponse>;

  /**
   * Validate token without consuming (for pre-check)
   *
   * @auth public
   * @rateLimit 10/minute
   */
  validateToken(token: string): Promise<{ ok: boolean; uid?: UID; profile_id?: string }>;
}
```

### 3.3 User Management Service

```typescript
interface UserService {
  /** @auth user */
  listUsers(): Promise<{ users: User[] }>;

  /** @auth user */
  getUser(uid: UID): Promise<{ user: User }>;

  /** @auth admin, @rateLimit 20/minute */
  createUser(request: UserCreateRequest): Promise<{ ok: true; dn: DN; status: string }>;

  /** @auth admin */
  updateUser(uid: UID, request: UserUpdateRequest): Promise<{ ok: true; modified: string[] }>;

  /** @auth admin */
  resetPassword(uid: UID, newPassword: string): Promise<{ ok: true }>;

  /** @auth admin */
  moveToOrg(uid: UID, orgDn: DN): Promise<{ ok: true; newDn: DN }>;

  /** @auth admin, @rateLimit 20/minute */
  terminateUser(uid: UID, request: UserTerminateRequest): Promise<TerminationResponse>;

  /** @auth admin */
  suspendUser(uid: UID, request: UserSuspendRequest): Promise<{ ok: true; status: 'suspended' }>;

  /** @auth admin */
  unsuspendUser(uid: UID, request: UserUnsuspendRequest): Promise<{ ok: true; status: 'active' }>;

  /** @auth user */
  getUserGroups(uid: UID): Promise<{ groups: Group[] }>;
}

interface TerminationResponse extends ApiResponse {
  ok: true;
  status: 'terminated';
  user_uid: UID;
  event_id: number;
  actions: {
    ldap_disabled: boolean;
    tokens_revoked: number;
    authentik_sessions_revoked: number | null;
    uc_sessions_terminated: number | null;
  };
  timestamp: ISOTimestamp;
}
```

### 3.4 Organization Service

```typescript
interface OrgService {
  /** @auth user */
  getOrgTree(): Promise<{ tree: OrgTreeNode[] }>;

  /** @auth user */
  getUsersInOrg(orgDn: DN, includeSub?: boolean): Promise<{ users: User[] }>;

  /** @auth admin */
  createOrg(request: OrgCreateRequest): Promise<{ ok: true; orgDn: DN }>;

  /** @auth admin */
  renameOrg(request: OrgRenameRequest): Promise<{ ok: true; newDn: DN }>;

  /** @auth admin */
  deleteOrg(dn: DN): Promise<{ ok: true; deleted: DN }>;
}
```

### 3.5 Group Service

```typescript
interface GroupService {
  /** @auth user */
  listGroups(): Promise<{ groups: Group[] }>;

  /** @auth user */
  getGroupMembers(cn: string): Promise<{ users: User[] }>;

  /** @auth admin */
  createGroup(request: GroupCreateRequest): Promise<{ ok: true; groupDn: DN }>;

  /** @auth admin */
  deleteGroup(cn: string): Promise<{ ok: true; deleted: DN }>;

  /** @auth admin */
  addMember(cn: string, uid: UID): Promise<{ ok: true }>;

  /** @auth admin */
  removeMember(cn: string, uid: UID): Promise<{ ok: true }>;
}
```

---

## 4. Error Handling

### 4.1 Error Response Structure

```typescript
interface ApiErrorResponse {
  ok: false;
  error: string;        // Machine-readable error code
  detail?: string;      // Human-readable message
}

/** HTTP status to error mapping */
const HTTP_ERRORS = {
  400: 'BAD_REQUEST',
  401: 'UNAUTHORIZED',
  403: 'FORBIDDEN',
  404: 'NOT_FOUND',
  409: 'CONFLICT',
  410: 'GONE',
  429: 'RATE_LIMIT_EXCEEDED',
  500: 'INTERNAL_ERROR',
  503: 'SERVICE_UNAVAILABLE',
} as const;
```

### 4.2 Domain-Specific Errors

```typescript
/** QR/Token errors (PRD §3.4.2) */
const TOKEN_ERRORS = {
  INVALID_SIGNATURE: { status: 400, message: 'Signature verification failed' },
  TOKEN_NOT_FOUND: { status: 404, message: 'Token does not exist' },
  TOKEN_ALREADY_CONSUMED: { status: 409, message: 'Token was already used' },
  TOKEN_EXPIRED: { status: 410, message: 'Token has expired' },
} as const;

/** User management errors */
const USER_ERRORS = {
  USER_NOT_FOUND: { status: 404, message: 'User not found' },
  USER_ALREADY_EXISTS: { status: 409, message: 'User already exists' },
  INVALID_ORG_DN: { status: 400, message: 'Invalid organization DN' },
} as const;

/** Rate limit error */
interface RateLimitError extends ApiErrorResponse {
  error: 'rate_limit_exceeded';
  detail: string;       // e.g., "Rate limit exceeded: 10 per 1 minute"
  retryAfter?: number;  // Seconds until reset (from Retry-After header)
}
```

### 4.3 Error Handling Utilities

```typescript
/** Type guard for API errors */
function isApiError(response: unknown): response is ApiErrorResponse {
  return typeof response === 'object' && response !== null &&
         'ok' in response && response.ok === false;
}

/** Type guard for token errors */
function isTokenError(error: string): error is TokenError {
  return ['INVALID_SIGNATURE', 'TOKEN_NOT_FOUND',
          'TOKEN_ALREADY_CONSUMED', 'TOKEN_EXPIRED'].includes(error);
}

/** Extract error from HTTP response */
async function extractError(response: Response): Promise<ApiErrorResponse> {
  try {
    const body = await response.json();
    if (isApiError(body)) return body;
    // Handle FastAPI HTTPException format
    if (body.detail) {
      if (typeof body.detail === 'object') {
        return { ok: false, ...body.detail };
      }
      return { ok: false, error: 'API_ERROR', detail: body.detail };
    }
  } catch {
    // Non-JSON response
  }
  return {
    ok: false,
    error: HTTP_ERRORS[response.status as keyof typeof HTTP_ERRORS] || 'UNKNOWN_ERROR',
    detail: response.statusText
  };
}
```

---

## 5. Business Flow State Machines

### 5.1 QR Provisioning Flow (Admin Portal)

```typescript
/** States for QR generation UI */
type QRGenerationState =
  | { status: 'idle' }
  | { status: 'loading'; uid: UID }
  | { status: 'success'; data: QRCodeResponse }
  | { status: 'error'; error: ApiErrorResponse };

/** Actions */
type QRGenerationAction =
  | { type: 'GENERATE'; uid: UID; ttl?: number }
  | { type: 'SUCCESS'; data: QRCodeResponse }
  | { type: 'ERROR'; error: ApiErrorResponse }
  | { type: 'RESET' };

/** State machine */
function qrGenerationReducer(
  state: QRGenerationState,
  action: QRGenerationAction
): QRGenerationState {
  switch (action.type) {
    case 'GENERATE':
      return { status: 'loading', uid: action.uid };
    case 'SUCCESS':
      return { status: 'success', data: action.data };
    case 'ERROR':
      return { status: 'error', error: action.error };
    case 'RESET':
      return { status: 'idle' };
  }
}
```

### 5.2 Token Consumption Flow (Mobile Client)

```typescript
/** States for mobile provisioning */
type ProvisioningState =
  | { status: 'scanning' }                           // Camera active
  | { status: 'validating'; payload: ProvisioningPayloadV2 }
  | { status: 'consuming'; token: string }
  | { status: 'success'; config: ProvisionConsumeResponse['config'] }
  | { status: 'error'; error: TokenError | 'SCAN_ERROR' | 'NETWORK_ERROR' }
  | { status: 'expired' };                           // QR exp time passed

/** Flow diagram (PRD §3.3) */
const PROVISIONING_FLOW = `
  [scanning]
      │ QR decoded
      ▼
  [validating] ──── exp < now ───► [expired]
      │ valid
      ▼
  [consuming]
      │
      ├── 200 OK ──────────────► [success]
      │
      ├── 404 TOKEN_NOT_FOUND ─► [error]
      │
      ├── 409 ALREADY_CONSUMED ► [error]
      │
      ├── 410 TOKEN_EXPIRED ───► [expired]
      │
      └── network error ───────► [error]
`;

/** Validate QR payload before consumption */
function validateQRPayload(payload: unknown): payload is ProvisioningPayloadV2 {
  if (typeof payload !== 'object' || payload === null) return false;
  const p = payload as ProvisioningPayloadV2;

  return (
    p.schema === 'azblink.provisioning.v2' &&
    typeof p.payload?.uc?.credentials?.token === 'string' &&
    typeof p.exp === 'number' &&
    typeof p.sig === 'string'
  );
}

/** Check if QR is expired (client-side pre-check) */
function isQRExpired(payload: ProvisioningPayloadV2): boolean {
  return Math.floor(Date.now() / 1000) > payload.exp;
}
```

### 5.3 User Termination Flow

```typescript
/** States for termination process */
type TerminationState =
  | { status: 'confirming'; uid: UID }               // Show confirmation dialog
  | { status: 'processing'; uid: UID; step: TerminationStep }
  | { status: 'success'; result: TerminationResponse }
  | { status: 'error'; error: ApiErrorResponse };

type TerminationStep =
  | 'disabling_ldap'
  | 'revoking_tokens'
  | 'revoking_authentik'   // Phase 2
  | 'killing_uc_sessions'; // Phase 2

/** Termination action sequence (PRD spec §6.2) */
const TERMINATION_STEPS = [
  { step: 'disabling_ldap', critical: true },
  { step: 'revoking_tokens', critical: false },
  { step: 'revoking_authentik', critical: false },  // Not implemented in Phase 1
  { step: 'killing_uc_sessions', critical: false }, // Not implemented in Phase 1
] as const;
```

---

## 6. Data Layer Integration

### 6.1 API Client Configuration

```typescript
interface ApiClientConfig {
  baseUrl: string;              // e.g., "http://localhost:8081/api"
  getAuthToken?: () => Promise<string | null>;
  onUnauthorized?: () => void;  // Callback for 401 responses
  onRateLimited?: (retryAfter: number) => void;
}

/** Create configured API client */
function createApiClient(config: ApiClientConfig) {
  const { baseUrl, getAuthToken, onUnauthorized, onRateLimited } = config;

  async function request<T>(
    method: string,
    path: string,
    body?: unknown
  ): Promise<T> {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };

    const token = await getAuthToken?.();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${baseUrl}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    // Handle rate limiting
    if (response.status === 429) {
      const retryAfter = parseInt(response.headers.get('Retry-After') || '60');
      onRateLimited?.(retryAfter);
      throw await extractError(response);
    }

    // Handle unauthorized
    if (response.status === 401) {
      onUnauthorized?.();
      throw await extractError(response);
    }

    // Handle other errors
    if (!response.ok) {
      throw await extractError(response);
    }

    return response.json();
  }

  return {
    get: <T>(path: string) => request<T>('GET', path),
    post: <T>(path: string, body?: unknown) => request<T>('POST', path, body),
    patch: <T>(path: string, body?: unknown) => request<T>('PATCH', path, body),
    delete: <T>(path: string) => request<T>('DELETE', path),
  };
}
```

### 6.2 React Query Integration Example

```typescript
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

/** Query keys */
const queryKeys = {
  users: ['users'] as const,
  user: (uid: UID) => ['users', uid] as const,
  userQR: (uid: UID) => ['users', uid, 'qrcode'] as const,
  orgTree: ['org', 'tree'] as const,
  groups: ['groups'] as const,
  audit: {
    qrIssuance: ['audit', 'qr_issuance'] as const,
    terminations: ['audit', 'terminations'] as const,
  },
};

/** Hook: Generate QR Code */
function useGenerateQR(uid: UID) {
  const api = useApiClient();

  return useQuery({
    queryKey: queryKeys.userQR(uid),
    queryFn: () => api.get<QRCodeResponse>(`/users/${uid}/qrcode`),
    staleTime: 0,        // Always fetch fresh (token is one-time)
    gcTime: 0,           // Don't cache
    enabled: !!uid,
  });
}

/** Hook: Consume Token (Mobile) */
function useConsumeToken() {
  return useMutation({
    mutationFn: (request: ProvisionConsumeRequest) =>
      api.post<ProvisionConsumeResponse>('/provision/consume', request),
    onError: (error) => {
      // Handle specific token errors
      if (isTokenError(error.error)) {
        // Show appropriate user message
      }
    },
  });
}

/** Hook: Terminate User */
function useTerminateUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ uid, request }: { uid: UID; request: UserTerminateRequest }) =>
      api.post<TerminationResponse>(`/users/${uid}/terminate`, request),
    onSuccess: (_, { uid }) => {
      // Invalidate user queries
      queryClient.invalidateQueries({ queryKey: queryKeys.user(uid) });
      queryClient.invalidateQueries({ queryKey: queryKeys.users });
    },
  });
}
```

### 6.3 Zustand Store Example

```typescript
import { create } from 'zustand';

interface QRProvisioningStore {
  // State
  currentQR: QRCodeResponse | null;
  isGenerating: boolean;
  error: ApiErrorResponse | null;

  // Actions
  generateQR: (uid: UID, ttl?: number) => Promise<void>;
  revokeTokens: (uid: UID) => Promise<number>;
  clearQR: () => void;
}

const useQRStore = create<QRProvisioningStore>((set, get) => ({
  currentQR: null,
  isGenerating: false,
  error: null,

  generateQR: async (uid, ttl) => {
    set({ isGenerating: true, error: null });
    try {
      const params = ttl ? `?ttl_sec=${ttl}` : '';
      const response = await api.get<QRCodeResponse>(`/users/${uid}/qrcode${params}`);
      set({ currentQR: response, isGenerating: false });
    } catch (error) {
      set({ error: error as ApiErrorResponse, isGenerating: false });
    }
  },

  revokeTokens: async (uid) => {
    const response = await api.post<QRRevokeResponse>(`/users/${uid}/qrcode/revoke`);
    // Clear current QR if it's for this user
    if (get().currentQR?.uid === uid) {
      set({ currentQR: null });
    }
    return response.tokens_revoked;
  },

  clearQR: () => set({ currentQR: null, error: null }),
}));
```

---

## 7. Rate Limiting Considerations

### 7.1 Limits by Endpoint

| Endpoint | Limit | Window | Use Case |
|----------|-------|--------|----------|
| `GET /users/{uid}/qrcode` | 10 | 1 min | QR regeneration |
| `POST /provision/consume` | 10 | 1 min | Mobile provisioning |
| `POST /users/create` | 20 | 1 min | User onboarding |
| `POST /bootstrap` | 5 | 1 hour | Day-0 setup |
| Default | 100 | 1 min | All other endpoints |

### 7.2 Client-Side Handling

```typescript
/** Rate limit aware request wrapper */
async function rateLimitAwareRequest<T>(
  requestFn: () => Promise<T>,
  options?: {
    maxRetries?: number;
    onRateLimited?: (waitMs: number, attempt: number) => void;
  }
): Promise<T> {
  const { maxRetries = 3, onRateLimited } = options ?? {};

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await requestFn();
    } catch (error) {
      if (isRateLimitError(error) && attempt < maxRetries - 1) {
        const waitMs = (error.retryAfter ?? 60) * 1000;
        onRateLimited?.(waitMs, attempt);
        await sleep(waitMs);
        continue;
      }
      throw error;
    }
  }
  throw new Error('Max retries exceeded');
}

function isRateLimitError(error: unknown): error is RateLimitError {
  return isApiError(error) && error.error === 'rate_limit_exceeded';
}
```

### 7.3 UI Considerations

```typescript
/** Debounce QR generation to avoid rate limits */
const DEBOUNCE_QR_GENERATION_MS = 2000;

/** Show warning before hitting rate limit */
function QRGenerationLimitWarning({ requestCount }: { requestCount: number }) {
  const remaining = 10 - requestCount;

  if (remaining <= 3) {
    return (
      <Alert variant="warning">
        {remaining} QR generation{remaining !== 1 ? 's' : ''} remaining this minute
      </Alert>
    );
  }
  return null;
}
```

---

## Appendix A: Endpoint Quick Reference

| Method | Path | Auth | Rate Limit | PRD Ref |
|--------|------|------|------------|---------|
| GET | `/users/{uid}/qrcode` | user | 10/min | §3.4.1 |
| POST | `/users/{uid}/qrcode/revoke` | admin | 100/min | §3.4.3 |
| POST | `/provision/consume` | public | 10/min | §3.4.2 |
| POST | `/provision/validate` | public | 10/min | - |
| GET | `/users` | user | 100/min | - |
| GET | `/users/{uid}` | user | 100/min | - |
| POST | `/users/create` | admin | 20/min | - |
| PATCH | `/users/{uid}` | admin | 100/min | - |
| POST | `/users/{uid}/terminate` | admin | 20/min | Spec §6.2 |
| POST | `/users/{uid}/suspend` | admin | 100/min | Spec §6.3 |
| POST | `/users/{uid}/unsuspend` | admin | 100/min | Spec §6.3 |
| GET | `/audit/qr_issuance` | admin | 100/min | - |
| GET | `/audit/terminations` | admin | 100/min | - |

---

## Appendix B: QR Payload Example

```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": {
      "tenant": "azblink",
      "xmpp": {
        "domain": "uc.azblink.com",
        "wsUrl": "wss://uc.azblink.com/xmpp-websocket"
      },
      "sip": {
        "domain": "sip.azblink.com",
        "wssUrl": "wss://sip.azblink.com/ws"
      },
      "credentials": {
        "username": "alice",
        "token": "dGhpcyBpcyBhIG9uZS10aW1lIHRva2VuCg"
      }
    },
    "sso": null
  },
  "iat": 1706140800,
  "exp": 1706144400,
  "nonce": "abc123xyz789",
  "sig": "a1b2c3d4e5f6..."
}
```

---

*Generated from OpenAPI spec and PRD analysis*
*Last updated: 2025-01-25*
