# Split-Panel Master-Detail Migrations — Post-Mortem

Post-mortem from migrating `/directory/users` (7 phases, 12 hours) and `/directory/groups` (7 phases + 14 commits, 14 hours) from flat layouts to split-panel master-detail pages.

**Prescriptive workflow rules:** `.cursor/rules/split-panel-migration-workflow.mdc`

---

## What Went Well

- **Backend-first audit** saved significant work. Both migrations discovered existing endpoints (termination, suspend, QR audit, group CRUD) that the spec assumed were missing. Auditing `main.py` before writing a single component prevented duplicate backend work.
- **Phased approach with per-phase reviews** caught real bugs early. Stale query keys, missing callback props, and breaking API changes were found within the phase they originated — not weeks later in production.
- **URL-driven state** (TanStack Router `validateSearch`) eliminated an entire class of bugs around stale selection, broken back/forward, and non-shareable URLs. No Zustand was needed for selection, filter, or search state.
- **Page-scoped modal state machines** (`useReducer` with discriminated unions) were cleaner and more predictable than global state. Each page owns its modals; no cross-page leakage.
- **Design system primitives built in Phase 0** (Dialog, Tabs, Textarea) unblocked all subsequent phases. Every modal, filter tab, and text input reused these primitives without ad-hoc styling.

## What Bit Us Repeatedly

These bugs appeared in **both** migrations. They are structural, not accidental:

| Pattern | Root Cause | How It Manifested |
|---------|-----------|-------------------|
| **Silent exception swallowing** | Best-effort Postgres ops after LDAP writes used bare `except: pass` | Permission/audit data silently failed to persist; no logs to debug |
| **Breaking API response keys** | Renamed response fields without checking tests or consumers | Existing tests failed on `users` → `members` key rename |
| **Duplicate helper functions** | Copy-paste across feature directories | `getInitials()` in 3 files, `typeIconConfig` in 2 files |
| **Stale query key types** | Backend response shape changed but query hook type annotation didn't | `{ members: string[] }` vs `{ members: GroupMember[] }` — silent at runtime, broken autocomplete |
| **Double error toasts** | Error handler in both mutation hook and component | User saw the same error twice |
| **Missing confirmation dialogs** | Destructive actions (remove member) implemented without `window.confirm()` | Accidental removals with no undo |
| **O(n) LDAP scan for O(1) lookup** | Using `list_users()` to find a single user by uid | Slow search when LDAP has hundreds of entries |

## Architectural Decisions and Why

### Hybrid Storage (LDAP + PostgreSQL)

LDAP owns identity (cn, dn, members, passwords). PostgreSQL owns enrichment (type, permissions, roles, timestamps, audit). This is non-negotiable — UC systems bind directly to LDAP, so it must be the source of truth for identity. PostgreSQL fills the gaps LDAP can't handle (RBAC, audit trails, metadata).

**Consequence:** Every write is LDAP-first, then best-effort Postgres. If Postgres fails, the core operation still succeeded. But you **must** log the failure (`logger.warning(..., exc_info=True)`), or you'll never know enrichment data is stale.

### RBAC via `require_permission()`

The 3-step fallback chain: non-OIDC bypass → RBAC check → admin group → 403.

This was designed for the transition period where OIDC isn't active yet. When `REQUIRE_OIDC_AUTH=false`, all authenticated users pass through. When OIDC is active, the system checks per-user permissions from Postgres first, then falls back to the admin group claim. This means:
- Day 1: Everyone who logs in can manage users/groups (LDAP-only mode)
- Day 2: OIDC enabled, admin group members can manage
- Day 3: Fine-grained RBAC assigns specific permissions per user

**Known gap:** OIDC `sub` claim may not match LDAP `uid`. A mapping layer is needed before RBAC works for OIDC users. Marked with `TODO today:` in `main.py`.

### Optimistic Updates (Permissions Only)

Only permission toggles use optimistic cache updates (`onMutate` snapshot → `onError` rollback → `onSettled` invalidation). Everything else uses simple `invalidateQueries` on success.

**Why selective:** Toggles need immediate visual feedback — a 200ms round-trip delay on a toggle feels broken. But for CRUD operations (create, delete, add member), showing a loading spinner and then refreshing is both simpler and safer. Optimistic CRUD is complex (temporary IDs, rollback UI) and the latency is masked by modal close animations anyway.

## Effort Breakdown (Actuals)

| Phase | Users | Groups | Notes |
|-------|-------|--------|-------|
| 0 — Schema + types + primitives | ~1h | ~1h | Groups reused primitives from users |
| 1 — Shell + endpoints | ~2h | ~2h | Split-panel layout, route setup, backend search |
| 2 — Detail panel | ~1.5h | ~1h | Groups had more sections (members, permissions) |
| 3 — CRUD modals | ~2h | ~2h | Create + delete patterns are nearly identical |
| 4 — Relations | ~2h | ~2h | Members management, role changes |
| 5 — Auth/permissions | N/A | ~1.5h | RBAC is groups-only for now |
| 6 — Polish | ~1h | ~1h | Redirects, a11y, DRY audit |
| Reviews + fixes | ~2h | ~3h | More fixes needed as patterns were established |
| **Total** | **~12h** | **~14h** | Groups was slower due to RBAC + more relations |

**Prediction for next migration:** ~10-12 hours. The workflow is now codified, primitives exist, shared helpers exist, and the review checklist prevents the most common bugs.

## Settings Migration (2026-02-11) — Non-Split-Panel Variant

The settings page migration diverges from the split-panel pattern. It's a form-driven scroll-spy layout — the first migration that isn't master-detail.

**Key design decisions:**
- **Absorb existing system info** — the read-only health/build page becomes section 1 of the new settings page. No separate route.
- **Sticky nav + scroll-spy** — 9 sections in a 240px sidebar + 1fr content grid. IntersectionObserver-powered, not URL-driven selection.
- **Batch save with dirty tracking** — unlike split-panel pages (per-action mutations), settings uses a single "Save All" that sends only changed fields.
- **3 new @azblink/ui primitives** — Select, RadioGroup, ToggleRow. ToggleRow was promoted from feature component because Org Profiles also needs it.
- **Full backend vertical slice** — new `app_settings` + `api_keys` PostgreSQL tables, settings CRUD endpoints, test-connection endpoints.

**What's reusable from prior migrations:**
- Phase 0 discipline (types → primitives → queries before any UI)
- Per-phase commit + review cadence
- Error handling rules (toasts in components only, `logger.warning` with `exc_info=True`)
- `getInitials()` utility for admin avatars
- AlertDialog for danger zone confirmations

**What's different:**
- No split-panel layout, no master-detail, no selection state
- Local form state (`useState`) instead of URL search params for form data
- ScrollSpy is a new pattern (no prior IntersectionObserver usage)
- Settings storage introduces a config priority chain: database > env var > default

**Design doc:** `docs/plans/2026-02-11-settings-migration.md`
**Workflow rules:** `.cursor/rules/settings-migration-workflow.mdc`

## Future Migration Candidates

Based on existing routes in `src/frontend/src/routes/`:

| Route | Current State | Migration Complexity |
|-------|--------------|---------------------|
| `/directory/orgs` | Flat list | Medium — org hierarchy adds tree navigation |
| `/provisioning/tokens` | Table | Low — simple list + detail, no relations |
| `/provisioning/qr-generator` | Standalone page | Deprecated — absorbed into user detail panel |
| `/my-profile` | Single page | Low — no list panel, just detail |
| ~~/settings~~ | ~~Flat page~~ | **In progress** — scroll-spy form layout (2026-02-11) |

The orgs migration is the most complex remaining candidate due to hierarchical data (ou tree structure in LDAP).

## Shared Assets Registry

Components and utilities built during these migrations that future work should reuse:

| Asset | Location | Reusable For |
|-------|----------|-------------|
| `SearchInput` | `user-management/SearchInput.tsx` | Any searchable list (already shared by groups) |
| `getInitials()` | `lib/utils/user-helpers.ts` | Any avatar display |
| `getOrgName()` | `lib/utils/user-helpers.ts` | Any org reference display |
| `Dialog` compound | `@azblink/ui` | All modals |
| `Tabs` compound | `@azblink/ui` | Filter tabs, segmented controls |
| `Textarea` | `@azblink/ui` | Multi-line text input |
| `useModalState` pattern | `user-management/useModalState.ts` | Page-scoped modal state (copy + adapt) |
| `typeIconConfig` pattern | `group-management/group-type-config.ts` | Any entity-type visual config |
| `PermissionToggle` | `group-management/PermissionToggle.tsx` | Any toggle-based permission UI |
| `Select` | `@azblink/ui` (planned) | Dropdown selects in forms |
| `RadioGroup` | `@azblink/ui` (planned) | Card-style exclusive choice (audit retention, etc.) |
| `ToggleRow` | `@azblink/ui` (planned) | Label + desc + toggle in bordered row (settings, org profiles) |
| `useScrollSpy` | `settings/useScrollSpy.ts` (planned) | Scroll-spy navigation for any long-form page |
