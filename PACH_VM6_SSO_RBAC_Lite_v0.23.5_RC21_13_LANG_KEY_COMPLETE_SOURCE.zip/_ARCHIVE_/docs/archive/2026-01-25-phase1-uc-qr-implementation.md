# Phase 1 UC Core QR: Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Implement unified QR provisioning with `azblink.provisioning.v2` schema and `/provision/consume` endpoint for Phase 1 UC-only deployment.

**Architecture:** Mobile clients scan QR to receive UC configuration (XMPP/SIP endpoints). One-time tokens prevent QR reuse. Authentication uses Plane A (direct LDAP bind) — no session passwords returned.

**Tech Stack:** FastAPI, PostgreSQL, Redis, HMAC-SHA256 signing, pytest

---

## Task 1: Add `ORG_QR_MAX_TTL_SEC` Configuration

**Files:**
- Modify: `src/backend/config.py`
- Test: `tests/test_config.py` (new)

**Step 1: Write the failing test**

Create `tests/test_config.py`:

```python
"""Tests for configuration module."""
import os


def test_org_qr_max_ttl_sec_exists():
    """ORG_QR_MAX_TTL_SEC should be defined with default 86400."""
    from config import ORG_QR_MAX_TTL_SEC
    assert ORG_QR_MAX_TTL_SEC == 86400


def test_org_qr_max_ttl_sec_from_env(monkeypatch):
    """ORG_QR_MAX_TTL_SEC should read from environment."""
    monkeypatch.setenv("ORG_QR_MAX_TTL_SEC", "7200")
    # Force reimport
    import importlib
    import config
    importlib.reload(config)
    assert config.ORG_QR_MAX_TTL_SEC == 7200
```

**Step 2: Run test to verify it fails**

Run: `cd src/backend && python -m pytest ../../tests/test_config.py -v`
Expected: FAIL with "cannot import name 'ORG_QR_MAX_TTL_SEC'"

**Step 3: Write minimal implementation**

Edit `src/backend/config.py`, add after line 32:

```python
ORG_QR_MAX_TTL_SEC = int(os.getenv("ORG_QR_MAX_TTL_SEC", "86400"))
```

**Step 4: Run test to verify it passes**

Run: `cd src/backend && python -m pytest ../../tests/test_config.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/backend/config.py tests/test_config.py
git commit -m "$(cat <<'EOF'
feat(config): add ORG_QR_MAX_TTL_SEC setting

Adds maximum TTL limit for QR provisioning tokens (default 86400 seconds).
This prevents admins from setting excessively long token lifetimes.

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: Create QR Signing Module

**Files:**
- Create: `src/backend/qr_signing.py`
- Test: `tests/test_qr_signing.py` (new)

**Step 1: Write the failing test**

Create `tests/test_qr_signing.py`:

```python
"""Tests for QR payload signing module."""
import time


def test_sign_provisioning_payload_returns_v2_schema():
    """Signed payload should have azblink.provisioning.v2 schema."""
    from qr_signing import sign_provisioning_payload

    uc_payload = {
        "tenant": "example",
        "xmpp": {"domain": "uc.example.com", "wsUrl": "wss://uc.example.com/ws"},
        "sip": {"domain": "sip.example.com", "wssUrl": "wss://sip.example.com/ws"},
        "credentials": {"username": "alice", "token": "test-token"}
    }

    signed = sign_provisioning_payload(uc_payload)

    assert signed["schema"] == "azblink.provisioning.v2"
    assert signed["payload"]["uc"] == uc_payload
    assert signed["payload"]["sso"] is None
    assert "iat" in signed
    assert "exp" in signed
    assert "nonce" in signed
    assert "sig" in signed


def test_sign_and_verify_roundtrip():
    """Signed payload should verify successfully."""
    from qr_signing import sign_provisioning_payload, verify_provisioning_payload

    uc_payload = {"xmpp": {"domain": "test.com"}}
    signed = sign_provisioning_payload(uc_payload)

    valid, error, payload = verify_provisioning_payload(signed)

    assert valid is True
    assert error == ""
    assert payload["uc"]["xmpp"]["domain"] == "test.com"
    assert payload["sso"] is None


def test_verify_rejects_tampered_payload():
    """Tampered payload should be rejected."""
    from qr_signing import sign_provisioning_payload, verify_provisioning_payload

    signed = sign_provisioning_payload({"test": "data"})
    signed["payload"]["test"] = "tampered"

    valid, error, _ = verify_provisioning_payload(signed)

    assert valid is False
    assert error == "INVALID_SIGNATURE"


def test_verify_rejects_missing_signature():
    """Payload without signature should be rejected."""
    from qr_signing import verify_provisioning_payload

    payload = {
        "schema": "azblink.provisioning.v2",
        "payload": {"uc": {}, "sso": None},
        "iat": int(time.time()),
        "exp": int(time.time()) + 3600,
        "nonce": "test"
    }

    valid, error, _ = verify_provisioning_payload(payload)

    assert valid is False
    assert error == "MISSING_SIGNATURE"


def test_verify_rejects_expired_payload():
    """Expired payload should be rejected."""
    from qr_signing import sign_provisioning_payload, verify_provisioning_payload

    signed = sign_provisioning_payload({"test": "data"}, ttl_sec=0)
    # Wait a moment to ensure expiration
    time.sleep(0.1)

    valid, error, _ = verify_provisioning_payload(signed)

    assert valid is False
    assert error == "TOKEN_EXPIRED"


def test_ttl_capped_at_max():
    """TTL should be capped at ORG_QR_MAX_TTL_SEC."""
    from qr_signing import sign_provisioning_payload
    from config import ORG_QR_MAX_TTL_SEC

    # Request TTL longer than max
    signed = sign_provisioning_payload({"test": "data"}, ttl_sec=ORG_QR_MAX_TTL_SEC + 10000)

    actual_ttl = signed["exp"] - signed["iat"]
    assert actual_ttl == ORG_QR_MAX_TTL_SEC
```

**Step 2: Run test to verify it fails**

Run: `cd src/backend && python -m pytest ../../tests/test_qr_signing.py -v`
Expected: FAIL with "No module named 'qr_signing'"

**Step 3: Write minimal implementation**

Create `src/backend/qr_signing.py`:

```python
"""QR Payload Signing Module.

Provides HMAC-SHA256 signing and verification for provisioning payloads
using the azblink.provisioning.v2 schema.
"""

import hmac
import hashlib
import json
import time
import secrets
from typing import Tuple, Optional, Dict, Any

from config import ORG_QR_SIGNING_SECRET, ORG_QR_DEFAULT_TTL_SEC, ORG_QR_MAX_TTL_SEC


def sign_provisioning_payload(
    uc_payload: Dict[str, Any],
    sso_payload: Optional[Dict[str, Any]] = None,
    ttl_sec: Optional[int] = None
) -> Dict[str, Any]:
    """Sign a unified provisioning payload with HMAC-SHA256.

    Args:
        uc_payload: UC configuration (xmpp, sip, credentials)
        sso_payload: SSO configuration (None in Phase 1)
        ttl_sec: Token TTL in seconds (capped at ORG_QR_MAX_TTL_SEC)

    Returns:
        Complete signed wrapper with schema, iat, exp, nonce, sig
    """
    ttl = min(ttl_sec or ORG_QR_DEFAULT_TTL_SEC, ORG_QR_MAX_TTL_SEC)
    now = int(time.time())

    wrapper = {
        "schema": "azblink.provisioning.v2",
        "payload": {
            "uc": uc_payload,
            "sso": sso_payload  # None in Phase 1
        },
        "iat": now,
        "exp": now + ttl,
        "nonce": secrets.token_urlsafe(16)
    }

    # Canonical JSON: sorted keys, no whitespace
    message = json.dumps(wrapper, sort_keys=True, separators=(',', ':'))
    sig = hmac.new(
        ORG_QR_SIGNING_SECRET.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

    wrapper["sig"] = sig
    return wrapper


def verify_provisioning_payload(
    signed_payload: Dict[str, Any]
) -> Tuple[bool, str, Dict[str, Any]]:
    """Verify a signed provisioning payload.

    Args:
        signed_payload: The complete signed payload including sig

    Returns:
        Tuple of (valid, error_message, payload_content)
        - valid: True if signature valid and not expired
        - error_message: "" if valid, otherwise error code
        - payload_content: The inner payload dict if valid, else {}

    Error codes:
        - MISSING_SIGNATURE: No sig field
        - INVALID_SIGNATURE: Signature doesn't match
        - TOKEN_EXPIRED: exp < current time
    """
    payload_copy = dict(signed_payload)
    sig = payload_copy.pop("sig", None)

    if not sig:
        return False, "MISSING_SIGNATURE", {}

    # Recompute signature
    message = json.dumps(payload_copy, sort_keys=True, separators=(',', ':'))
    expected = hmac.new(
        ORG_QR_SIGNING_SECRET.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

    # Constant-time comparison
    if not hmac.compare_digest(sig, expected):
        return False, "INVALID_SIGNATURE", {}

    # Check expiration
    now = int(time.time())
    if payload_copy.get("exp", 0) < now:
        return False, "TOKEN_EXPIRED", {}

    return True, "", payload_copy.get("payload", {})
```

**Step 4: Run test to verify it passes**

Run: `cd src/backend && python -m pytest ../../tests/test_qr_signing.py -v`
Expected: All 6 tests PASS

**Step 5: Commit**

```bash
git add src/backend/qr_signing.py tests/test_qr_signing.py
git commit -m "$(cat <<'EOF'
feat(qr): add qr_signing module with HMAC-SHA256

Implements sign_provisioning_payload() and verify_provisioning_payload()
for the azblink.provisioning.v2 schema. Features:
- HMAC-SHA256 signing with canonical JSON
- TTL capped at ORG_QR_MAX_TTL_SEC
- Constant-time signature comparison
- Expiration checking

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: Database Migration for Device Tracking

**Files:**
- Create: `migrations/004_phase1_uc_qr.sql`

**Step 1: Write the migration**

Create `migrations/004_phase1_uc_qr.sql`:

```sql
-- Migration 004: Phase 1 UC Core QR Support
-- Enhances provision_tokens table for device tracking at consumption time
--
-- Applied: (timestamp will be recorded on execution)
-- Rollback: DROP columns and indexes (see bottom of file)

-- Add device tracking columns
ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS consumed_by_device_id VARCHAR(128);

ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS consumed_from_ip VARCHAR(45);

ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS client_platform VARCHAR(32);

ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS client_version VARCHAR(32);

-- Add index for user-based token lookup (used by revocation)
CREATE INDEX IF NOT EXISTS idx_provision_tokens_uid_status
ON provision_tokens(uid, status);

-- Add index for cleanup of expired tokens
CREATE INDEX IF NOT EXISTS idx_provision_tokens_expires
ON provision_tokens(expires_at)
WHERE status = 'active';

-- Rollback commands (for reference, run manually if needed):
-- DROP INDEX IF EXISTS idx_provision_tokens_expires;
-- DROP INDEX IF EXISTS idx_provision_tokens_uid_status;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS client_version;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS client_platform;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS consumed_from_ip;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS consumed_by_device_id;
```

**Step 2: Apply migration**

Run: `just psql < migrations/004_phase1_uc_qr.sql`
Expected: Commands complete without error

**Step 3: Verify columns exist**

Run: `just psql -c "\d provision_tokens"`
Expected: New columns visible in table structure

**Step 4: Commit**

```bash
git add migrations/004_phase1_uc_qr.sql
git commit -m "$(cat <<'EOF'
feat(db): add device tracking columns to provision_tokens

Migration 004 adds:
- consumed_by_device_id: Device UUID from mobile client
- consumed_from_ip: Client IP at consumption time
- client_platform: ios/android/desktop
- client_version: App version string

Also adds indexes for user token lookup and expired token cleanup.

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: Add Device Tracking Method to OrgDB

**Files:**
- Modify: `src/backend/orgdb.py`
- Test: `tests/test_orgdb_device.py` (new)

**Step 1: Write the failing test**

Create `tests/test_orgdb_device.py`:

```python
"""Tests for OrgDB device tracking method."""
import pytest
from datetime import datetime, timezone, timedelta


@pytest.fixture
def orgdb():
    """Get OrgDB instance."""
    from orgdb import OrgDB
    return OrgDB()


@pytest.fixture
def test_token(orgdb):
    """Create a test provision token."""
    import secrets
    import hashlib

    token = secrets.token_urlsafe(24)
    token_hash = hashlib.sha256(token.encode()).hexdigest()

    orgdb.record_provision_token(
        token_hash=token_hash,
        uid="testuser",
        profile_id="uc_core",
        expires_at=datetime.now(timezone.utc) + timedelta(hours=1)
    )

    return token_hash


def test_update_provision_token_device(orgdb, test_token):
    """Should update device info on provision token."""
    orgdb.update_provision_token_device(
        token_hash=test_token,
        device_id="device-123",
        client_ip="192.168.1.100",
        platform="ios",
        version="2.1.0"
    )

    token = orgdb.get_provision_token(test_token)

    assert token["consumed_by_device_id"] == "device-123"
    assert token["consumed_from_ip"] == "192.168.1.100"
    assert token["client_platform"] == "ios"
    assert token["client_version"] == "2.1.0"


def test_update_provision_token_device_partial(orgdb, test_token):
    """Should handle partial device info updates."""
    orgdb.update_provision_token_device(
        token_hash=test_token,
        device_id="device-456",
        client_ip=None,
        platform="android",
        version=None
    )

    token = orgdb.get_provision_token(test_token)

    assert token["consumed_by_device_id"] == "device-456"
    assert token["consumed_from_ip"] is None
    assert token["client_platform"] == "android"
    assert token["client_version"] is None
```

**Step 2: Run test to verify it fails**

Run: `just test-quick tests/test_orgdb_device.py -v`
Expected: FAIL with "AttributeError: 'OrgDB' object has no attribute 'update_provision_token_device'"

**Step 3: Write minimal implementation**

Edit `src/backend/orgdb.py`, add method after `validate_and_consume_token` (around line 385):

```python
    def update_provision_token_device(
        self,
        token_hash: str,
        device_id: str | None = None,
        client_ip: str | None = None,
        platform: str | None = None,
        version: str | None = None
    ) -> None:
        """Update provision token with device consumption info.

        Called after successful token validation to record device details.
        All parameters are optional - only provided values are updated.

        Args:
            token_hash: SHA-256 hash of the token
            device_id: Device UUID from client
            client_ip: IP address of consuming client
            platform: Client platform (ios/android/desktop)
            version: Client app version string
        """
        eng = self.connect()
        with eng.begin() as conn:
            update_vals = {}
            if device_id is not None:
                update_vals["consumed_by_device_id"] = device_id
            if client_ip is not None:
                update_vals["consumed_from_ip"] = client_ip
            if platform is not None:
                update_vals["client_platform"] = platform
            if version is not None:
                update_vals["client_version"] = version

            if update_vals:
                conn.execute(
                    update(provision_tokens)
                    .where(provision_tokens.c.token_hash == token_hash)
                    .values(**update_vals)
                )
```

**Step 4: Run test to verify it passes**

Run: `just test-quick tests/test_orgdb_device.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/backend/orgdb.py tests/test_orgdb_device.py
git commit -m "$(cat <<'EOF'
feat(orgdb): add update_provision_token_device method

Records device information when a provision token is consumed:
- device_id: Client device UUID
- client_ip: IP address
- platform: ios/android/desktop
- version: App version

Supports partial updates - only provided fields are written.

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: Update QR Code Endpoint to v2 Schema

**Files:**
- Modify: `src/backend/main.py`
- Test: `tests/test_qrcode_v2.py` (new)

**Step 1: Write the failing test**

Create `tests/test_qrcode_v2.py`:

```python
"""Tests for QR code endpoint with v2 schema."""
import pytest


def test_qrcode_endpoint_returns_v2_schema(client, test_user, auth_headers):
    """QR endpoint should return azblink.provisioning.v2 schema."""
    response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers=auth_headers
    )

    assert response.status_code == 200
    data = response.json()

    assert data["ok"] is True
    assert data["uid"] == test_user["uid"]
    assert data["qrType"] == "unified"

    payload = data["payload"]
    assert payload["schema"] == "azblink.provisioning.v2"
    assert payload["payload"]["sso"] is None

    uc = payload["payload"]["uc"]
    assert "tenant" in uc
    assert "xmpp" in uc
    assert "sip" in uc
    assert "credentials" in uc
    assert uc["credentials"]["username"] == test_user["uid"]
    assert "token" in uc["credentials"]  # One-time token present


def test_qrcode_endpoint_includes_xmpp_config(client, test_user, auth_headers):
    """QR UC block should include XMPP configuration."""
    response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers=auth_headers
    )

    uc = response.json()["payload"]["payload"]["uc"]

    assert "domain" in uc["xmpp"]
    assert "wsUrl" in uc["xmpp"]


def test_qrcode_endpoint_includes_sip_config(client, test_user, auth_headers):
    """QR UC block should include SIP configuration."""
    response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers=auth_headers
    )

    uc = response.json()["payload"]["payload"]["uc"]

    assert "domain" in uc["sip"]
    assert "wssUrl" in uc["sip"]


def test_qrcode_endpoint_signature_valid(client, test_user, auth_headers):
    """QR payload signature should be verifiable."""
    from qr_signing import verify_provisioning_payload

    response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers=auth_headers
    )

    payload = response.json()["payload"]
    valid, error, _ = verify_provisioning_payload(payload)

    assert valid is True
    assert error == ""


def test_qrcode_endpoint_respects_ttl(client, test_user, auth_headers):
    """QR endpoint should respect ttlSec parameter."""
    response = client.get(
        f"/api/users/{test_user['uid']}/qrcode?ttlSec=1800",
        headers=auth_headers
    )

    payload = response.json()["payload"]
    ttl = payload["exp"] - payload["iat"]

    assert ttl == 1800


def test_qrcode_endpoint_caps_ttl_at_max(client, test_user, auth_headers):
    """QR endpoint should cap TTL at ORG_QR_MAX_TTL_SEC."""
    from config import ORG_QR_MAX_TTL_SEC

    response = client.get(
        f"/api/users/{test_user['uid']}/qrcode?ttlSec=999999",
        headers=auth_headers
    )

    payload = response.json()["payload"]
    ttl = payload["exp"] - payload["iat"]

    assert ttl == ORG_QR_MAX_TTL_SEC
```

**Step 2: Run test to verify it fails**

Run: `just test-quick tests/test_qrcode_v2.py -v`
Expected: FAIL (current endpoint returns v1 schema)

**Step 3: Write implementation**

This requires modifying the existing `/api/users/{uid}/qrcode` endpoint in `main.py`. Locate the endpoint (around line 889) and update it to use the new signing module and v2 schema.

The key changes:
1. Import `sign_provisioning_payload` from `qr_signing`
2. Build UC payload with tenant, xmpp, sip, credentials
3. Generate one-time token and store hash
4. Sign with new function
5. Return v2 structure

**Step 4: Run test to verify it passes**

Run: `just test-quick tests/test_qrcode_v2.py -v`
Expected: All tests PASS

**Step 5: Commit**

```bash
git add src/backend/main.py tests/test_qrcode_v2.py
git commit -m "$(cat <<'EOF'
feat(api): update /qrcode endpoint to v2 schema

Updates GET /api/users/{uid}/qrcode to return azblink.provisioning.v2:
- Nested payload.uc with xmpp, sip, credentials
- payload.sso = null (Phase 1)
- One-time provision token in credentials
- TTL capped at ORG_QR_MAX_TTL_SEC
- Uses new qr_signing module for HMAC-SHA256

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: Create `/api/provision/consume` Endpoint

**Files:**
- Modify: `src/backend/main.py`
- Test: `tests/test_provision_consume.py` (new)

**Step 1: Write the failing test**

Create `tests/test_provision_consume.py`:

```python
"""Tests for /api/provision/consume endpoint."""
import pytest
import secrets
import hashlib
from datetime import datetime, timezone, timedelta


@pytest.fixture
def provision_token(orgdb, test_user):
    """Create a valid provision token for testing."""
    token = secrets.token_urlsafe(24)
    token_hash = hashlib.sha256(token.encode()).hexdigest()

    orgdb.record_provision_token(
        token_hash=token_hash,
        uid=test_user["uid"],
        profile_id="uc_core",
        expires_at=datetime.now(timezone.utc) + timedelta(hours=1)
    )

    return token


@pytest.fixture
def expired_token(orgdb, test_user):
    """Create an expired provision token."""
    token = secrets.token_urlsafe(24)
    token_hash = hashlib.sha256(token.encode()).hexdigest()

    orgdb.record_provision_token(
        token_hash=token_hash,
        uid=test_user["uid"],
        profile_id="uc_core",
        expires_at=datetime.now(timezone.utc) - timedelta(hours=1)  # Expired
    )

    return token


def test_consume_valid_token(client, provision_token, test_user):
    """Should consume valid token and return config."""
    response = client.post(
        "/api/provision/consume",
        json={"token": provision_token}
    )

    assert response.status_code == 200
    data = response.json()

    assert data["ok"] is True
    assert data["uid"] == test_user["uid"]
    assert "consumed_at" in data
    assert data["config"]["authMethod"] == "ldap_bind"
    assert test_user["uid"] in data["config"]["xmpp"]["jid"]
    assert test_user["uid"] in data["config"]["sip"]["uri"]


def test_consume_with_device_info(client, provision_token):
    """Should accept and store device info."""
    response = client.post(
        "/api/provision/consume",
        json={
            "token": provision_token,
            "deviceId": "device-uuid-123",
            "clientInfo": {
                "platform": "ios",
                "version": "2.1.0"
            }
        }
    )

    assert response.status_code == 200


def test_consume_token_once_only(client, provision_token):
    """Token should only be consumable once."""
    # First consumption
    r1 = client.post("/api/provision/consume", json={"token": provision_token})
    assert r1.status_code == 200

    # Second consumption should fail
    r2 = client.post("/api/provision/consume", json={"token": provision_token})
    assert r2.status_code == 409
    assert r2.json()["error"] == "TOKEN_ALREADY_CONSUMED"


def test_consume_nonexistent_token(client):
    """Should reject nonexistent token."""
    response = client.post(
        "/api/provision/consume",
        json={"token": "nonexistent-token-xyz"}
    )

    assert response.status_code == 404
    assert response.json()["error"] == "TOKEN_NOT_FOUND"


def test_consume_expired_token(client, expired_token):
    """Should reject expired token."""
    response = client.post(
        "/api/provision/consume",
        json={"token": expired_token}
    )

    assert response.status_code == 410
    assert response.json()["error"] == "TOKEN_EXPIRED"


def test_consume_rate_limited(client):
    """Endpoint should be rate limited."""
    # Make 12 requests (limit is 10/min)
    for i in range(12):
        response = client.post(
            "/api/provision/consume",
            json={"token": f"fake-token-{i}"}
        )
        if i >= 10:
            assert response.status_code == 429
```

**Step 2: Run test to verify it fails**

Run: `just test-quick tests/test_provision_consume.py -v`
Expected: FAIL with 404 (endpoint doesn't exist)

**Step 3: Write implementation**

Add to `src/backend/main.py`:

```python
from pydantic import BaseModel, Field
from typing import Optional, Dict


class ProvisionConsumeReq(BaseModel):
    token: str = Field(..., min_length=1, max_length=256)
    deviceId: Optional[str] = Field(default=None, max_length=128)
    clientInfo: Optional[Dict[str, str]] = None


@app.post("/api/provision/consume")
@limiter.limit(LIMIT_QR)
def api_provision_consume(
    request: Request,
    req: ProvisionConsumeReq
):
    """Consume a one-time provisioning token.

    Called by mobile clients after scanning QR code.
    Returns UC configuration with authMethod for LDAP bind.

    Phase 1: No session passwords returned - client authenticates
    directly to UC services using LDAP bind.
    """
    # Hash the token
    token_hash = hashlib.sha256(req.token.encode()).hexdigest()

    # Atomic validate-and-consume
    valid, error, token_data = ORGDB.validate_and_consume_token(token_hash)

    if not valid:
        status_code = {
            "TOKEN_NOT_FOUND": 404,
            "TOKEN_EXPIRED": 410,
            "TOKEN_ALREADY_CONSUMED": 409
        }.get(error, 400)
        raise HTTPException(status_code, {"ok": False, "error": error})

    uid = token_data.get("uid")

    # Update token with device info (best-effort, don't fail on error)
    try:
        ORGDB.update_provision_token_device(
            token_hash=token_hash,
            device_id=req.deviceId,
            client_ip=request.client.host if request.client else None,
            platform=req.clientInfo.get("platform") if req.clientInfo else None,
            version=req.clientInfo.get("version") if req.clientInfo else None
        )
    except Exception:
        pass  # Device tracking is best-effort

    # Return config with LDAP bind auth method (Phase 1)
    return {
        "ok": True,
        "uid": uid,
        "consumed_at": iso(utcnow()),
        "config": {
            "xmpp": {
                "jid": f"{uid}@{UCCHAT_XMPP_DOMAIN}"
            },
            "sip": {
                "uri": f"sip:{uid}@{UCCHAT_SIP_DOMAIN}"
            },
            "authMethod": "ldap_bind"
        }
    }
```

**Step 4: Run test to verify it passes**

Run: `just test-quick tests/test_provision_consume.py -v`
Expected: All tests PASS

**Step 5: Commit**

```bash
git add src/backend/main.py tests/test_provision_consume.py
git commit -m "$(cat <<'EOF'
feat(api): add POST /api/provision/consume endpoint

Implements one-time token consumption for QR provisioning:
- Validates token exists, not consumed, not expired
- Atomic consumption prevents race conditions
- Records device info (deviceId, platform, version, IP)
- Returns config with authMethod: "ldap_bind" (Phase 1)
- Rate limited at 10/minute

Phase 1 uses Plane A (LDAP bind) - no session passwords returned.

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>
EOF
)"
```

---

## Task 7: Integration Test — Full QR Flow

**Files:**
- Test: `tests/test_qr_flow_integration.py` (new)

**Step 1: Write the integration test**

Create `tests/test_qr_flow_integration.py`:

```python
"""Integration test for complete QR provisioning flow."""
import pytest


def test_full_qr_provisioning_flow(client, test_user, auth_headers):
    """Test complete flow: generate QR → consume token → verify config."""
    # Step 1: Admin generates QR code
    qr_response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers=auth_headers
    )
    assert qr_response.status_code == 200

    qr_data = qr_response.json()
    assert qr_data["payload"]["schema"] == "azblink.provisioning.v2"

    # Extract one-time token from QR payload
    token = qr_data["payload"]["payload"]["uc"]["credentials"]["token"]

    # Step 2: Mobile client consumes token
    consume_response = client.post(
        "/api/provision/consume",
        json={
            "token": token,
            "deviceId": "test-device-001",
            "clientInfo": {"platform": "ios", "version": "2.1.0"}
        }
    )
    assert consume_response.status_code == 200

    config = consume_response.json()
    assert config["ok"] is True
    assert config["uid"] == test_user["uid"]
    assert config["config"]["authMethod"] == "ldap_bind"

    # Step 3: Verify token cannot be reused
    reuse_response = client.post(
        "/api/provision/consume",
        json={"token": token}
    )
    assert reuse_response.status_code == 409
    assert reuse_response.json()["error"] == "TOKEN_ALREADY_CONSUMED"


def test_qr_revocation_invalidates_tokens(client, test_user, auth_headers):
    """Test that revoking tokens prevents consumption."""
    # Generate QR
    qr_response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers=auth_headers
    )
    token = qr_response.json()["payload"]["payload"]["uc"]["credentials"]["token"]

    # Revoke all tokens for user
    revoke_response = client.post(
        f"/api/users/{test_user['uid']}/qrcode/revoke",
        headers=auth_headers
    )
    assert revoke_response.status_code == 200

    # Try to consume revoked token
    consume_response = client.post(
        "/api/provision/consume",
        json={"token": token}
    )
    assert consume_response.status_code in [404, 409]  # Not found or already consumed
```

**Step 2: Run integration test**

Run: `just test-quick tests/test_qr_flow_integration.py -v`
Expected: All tests PASS

**Step 3: Commit**

```bash
git add tests/test_qr_flow_integration.py
git commit -m "$(cat <<'EOF'
test: add QR provisioning integration tests

Full flow test covering:
- Admin generates QR with v2 schema
- Mobile extracts and consumes one-time token
- Token cannot be reused (409 ALREADY_CONSUMED)
- Revoked tokens cannot be consumed

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>
EOF
)"
```

---

## Task 8: Run Full Test Suite

**Step 1: Run all tests**

Run: `just test`
Expected: All tests pass

**Step 2: Run security tests**

Run: `just test-security`
Expected: All security tests pass (rate limiting verified)

**Step 3: Final commit with test verification**

```bash
git add -A
git commit -m "$(cat <<'EOF'
chore: Phase 1 UC Core QR implementation complete

All tests passing:
- QR schema v2 (azblink.provisioning.v2)
- One-time token enforcement
- /provision/consume endpoint with LDAP bind auth
- Device tracking
- Rate limiting
- Integration tests

Ready for deployment verification.

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>
EOF
)"
```

---

## Deployment Verification Checklist

After implementation, verify:

- [ ] `GET /api/health/deep` returns all healthy
- [ ] `GET /api/users/{uid}/qrcode` returns v2 schema
- [ ] QR payload includes `payload.uc` with xmpp, sip, credentials
- [ ] QR payload has `payload.sso: null`
- [ ] `POST /api/provision/consume` works with valid token
- [ ] Token can only be consumed once (409 on retry)
- [ ] Expired tokens rejected (410)
- [ ] Rate limiting active on both endpoints
- [ ] Audit logs populated in `qr_issuance_audit`

---

## Summary

| Task | Description | Estimated Time |
|------|-------------|----------------|
| 1 | Add `ORG_QR_MAX_TTL_SEC` config | 15 min |
| 2 | Create `qr_signing.py` module | 45 min |
| 3 | Database migration | 15 min |
| 4 | Add device tracking method | 30 min |
| 5 | Update `/qrcode` endpoint to v2 | 1 hour |
| 6 | Create `/provision/consume` endpoint | 1 hour |
| 7 | Integration tests | 30 min |
| 8 | Full test suite verification | 15 min |

**Total: ~4-5 hours of implementation time**
