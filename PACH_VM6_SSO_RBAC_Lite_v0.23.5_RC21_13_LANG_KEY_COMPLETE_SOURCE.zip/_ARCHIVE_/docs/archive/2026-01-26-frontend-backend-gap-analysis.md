# AZBlink Directory: Frontend-Backend Gap Analysis

## Technical Audit Report

**Date:** 2026-01-26
**Version:** 1.0.0
**Scope:** React Frontend vs FastAPI Backend
**Author:** Claude Code Audit

---

## Executive Summary

| Metric | Value |
|--------|-------|
| Backend API Endpoints | 45 |
| Frontend Query Hooks | 13 |
| Frontend Mutations | 3 |
| **Implementation Rate** | **~32%** |
| Critical Gaps | 7 |
| High Priority Gaps | 12 |
| Medium Priority Gaps | 9 |
| Low Priority Gaps | 6 |

---

## 1. Architecture Overview

### 1.1 Backend (`src/backend/main.py`)

- **FastAPI monolith** (~33KB)
- **45 API endpoints** across 7 domains
- **Authentication:** LDAP bind + optional OIDC
- **Persistence:** PostgreSQL + OpenLDAP

### 1.2 Frontend (`src/frontend/`)

- **Stack:** React 19, TanStack Router/Query, Zustand, shadcn/ui, Tailwind 4
- **13 routes** implemented
- **13 query hooks**, **3 mutations**
- **Design tokens:** Defined with dark mode (partial implementation)

---

## 2. Complete Endpoint Inventory

### 2.1 Backend Endpoints (45 total)

```
HEALTH (2)
├── GET  /api/health
└── GET  /api/health/deep

AUTH (2)
├── POST /api/auth/login
└── POST /api/bootstrap

TENANT (1)
└── GET  /api/tenant

USERS (11)
├── GET    /api/users
├── GET    /api/users/{uid}
├── PATCH  /api/users/{uid}
├── GET    /api/users/{uid}/groups
├── POST   /api/users/create
├── POST   /api/users/{uid}/reset_password
├── POST   /api/users/{uid}/move_org
├── POST   /api/users/{uid}/terminate
├── POST   /api/users/{uid}/suspend
├── POST   /api/users/{uid}/unsuspend
└── POST   /api/users/import_csv

ORGANIZATIONS (4)
├── GET    /api/org/tree
├── GET    /api/org/users
├── POST   /api/org/create
├── POST   /api/org/rename
└── DELETE /api/org/{dn}

GROUPS (5)
├── GET    /api/groups
├── POST   /api/groups/create
├── POST   /api/groups/{cn}/members
├── DELETE /api/groups/{cn}/members/{uid}
├── GET    /api/groups/{cn}/members
└── DELETE /api/groups/{cn}

QR/PROVISIONING (5)
├── POST   /api/provision/validate
├── POST   /api/provision/consume
├── GET    /api/users/{uid}/qrcode
├── GET    /api/users/{uid}/qrcodes
└── POST   /api/users/{uid}/qrcode/revoke

ORG PROFILES (9)
├── GET    /api/orgprofiles
├── POST   /api/orgprofiles
├── GET    /api/orgprofiles/{id}
├── PATCH  /api/orgprofiles/{id}
├── DELETE /api/orgprofiles/{id}
├── POST   /api/orgprofiles/{id}/rotate_qr
├── GET    /api/orgprofiles/{id}/qrcode
├── GET    /api/orgprofiles/{id}/sso_profile
└── GET    /api/orgprofiles/{id}/sso_profile/qrcode

AUDIT (4)
├── GET    /api/audit/qr_issuance
├── GET    /api/audit/terminations
├── GET    /api/audit/auth_failures
└── GET    /api/audit/user_lifecycle
```

### 2.2 Frontend Query/Mutation Coverage

| File | Queries | Mutations | Coverage |
|------|---------|-----------|----------|
| `users.ts` | 3 | 0 | 27% (3/11 endpoints) |
| `orgs.ts` | 2 | 0 | 40% (2/5 endpoints) |
| `groups.ts` | 2 | 0 | 33% (2/6 endpoints) |
| `qr.ts` | 1 | 1 | 40% (2/5 endpoints) |
| `audit.ts` | 2 | 0 | 50% (2/4 endpoints) |
| `health.ts` | 2 | 0 | 100% (2/2 endpoints) |
| **Inline** | 0 | 1 | `POST /users/create` in `new.tsx` |

**Missing query/mutation hooks:**
- OrgProfiles: **0%** (0/9 endpoints) - entire domain missing
- User mutations: terminate, suspend, unsuspend, reset_password, move_org, update
- Group mutations: create, add/remove member, delete
- Org mutations: create, rename, delete

---

## 3. Route Analysis

### 3.1 Implemented Routes (13)

| Route | Query Data | Mutations | Status |
|-------|------------|-----------|--------|
| `/` (Dashboard) | users | none | ⚠️ Hardcoded stats |
| `/login` | none | auth.login | ✅ Complete |
| `/directory/users` | users | none | ✅ Complete |
| `/directory/users/new` | none | users.create | ✅ Complete |
| `/directory/users/$uid` | user, userGroups | none | ⚠️ Edit button noop |
| `/directory/groups` | groups | none | ⚠️ Create button noop |
| `/directory/orgs` | orgTree | none | ⚠️ Create button noop |
| `/provisioning/qr-generator` | users, qrCode | qr.revoke | ✅ Complete |
| `/provisioning/tokens` | audit.qrIssuance | none | ⚠️ Revoke button noop |
| `/my-profile` | user, userGroups | none | ⚠️ Edit button noop |
| `/settings` | health | none | ✅ Complete |

### 3.2 Missing Routes

| Route | Backend Support | Priority |
|-------|-----------------|----------|
| `/provisioning/profiles` | ✅ 9 endpoints | **Critical** |
| `/audit` or `/audit/dashboard` | ✅ 4 endpoints | High |
| `/directory/users/$uid/edit` | ✅ PATCH endpoint | High |
| `/directory/groups/$cn` | ✅ members endpoint | High |
| `/bootstrap` | ✅ bootstrap endpoint | Medium |
| `/users/import` | ✅ import_csv endpoint | Medium |

---

## 4. UI Component Gaps

### 4.1 Buttons Without Actions

| Location | Button | Expected Action |
|----------|--------|-----------------|
| `/directory/users/$uid` | Edit | Open edit form/modal |
| `/directory/users/$uid` | More (...) | Dropdown: terminate, suspend, reset pwd |
| `/directory/users/$uid` | Manage (groups) | Open group management modal |
| `/directory/groups` | Create Group | Open create dialog |
| `/directory/orgs` | Create Org Unit | Open create dialog |
| `/provisioning/tokens` | Revoke | Call revoke mutation |
| `/provisioning/tokens` | Export CSV | Download CSV |
| `/provisioning/tokens` | Refresh | Refetch query |
| `/my-profile` | Edit Profile | Open edit form/modal |
| `/` (Dashboard) | New User | Navigate to `/directory/users/new` |
| `/` (Dashboard) | Generate QR | Navigate to `/provisioning/qr-generator` |
| `/` (Dashboard) | Bulk Import | Navigate to import page |

### 4.2 Hardcoded Data

| Location | Data | Should Be |
|----------|------|-----------|
| `/` (Dashboard) | Groups: 12 | `GET /api/groups` count |
| `/` (Dashboard) | Organizations: 5 | `GET /api/org/tree` count |
| `/` (Dashboard) | Pending QR Scans: 8 | `GET /api/audit/qr_issuance` active count |
| `/` (Dashboard) | +3 today | `GET /api/audit/user_lifecycle` today count |
| `/directory/users/$uid` | Status: "Active" | From user data or separate status endpoint |

### 4.3 Missing UI Components

| Component | Use Case | Complexity |
|-----------|----------|------------|
| `ConfirmDialog` | Terminate/suspend/delete actions | Low |
| `UserEditForm` | Edit user profile | Medium |
| `GroupMemberManager` | Add/remove group members | Medium |
| `OrgCreateDialog` | Create organization | Low |
| `GroupCreateDialog` | Create group | Low |
| `PasswordResetDialog` | Reset user password | Low |
| `BulkImportDialog` | CSV import with preview | High |
| `AuditTable` | Reusable for all 4 audit types | Medium |
| `ThemeToggle` | Light/dark mode switch | Low |

---

## 5. Dark Mode Status

### 5.1 Token Infrastructure

| Status | Item |
|--------|------|
| ✅ | Design tokens defined in `globals.css` |
| ✅ | Light mode values |
| ✅ | Dark mode values (prefers-color-scheme) |
| ✅ | `.dark` class support for manual toggle |
| ✅ | `theme` state in `ui-store.ts` |
| ✅ | `setTheme` action in `ui-store.ts` |

### 5.2 Implementation Gaps

| Status | Item |
|--------|------|
| ❌ | Theme toggle UI component |
| ❌ | Theme toggle in Settings page |
| ⚠️ | 85 hardcoded color classes in 12 files (per design doc) |

**Files needing token migration:**
1. `sidebar.tsx` - 12 hardcoded classes
2. `settings.tsx` - 22 hardcoded classes
3. `my-profile.tsx` - 14 hardcoded classes
4. `login.tsx` - 8 hardcoded classes
5. `startup-check.tsx` - 8 hardcoded classes
6. `orgs/index.tsx` - 7 hardcoded classes
7. `empty-state.tsx` - 5 hardcoded classes
8. `groups/index.tsx` - 5 hardcoded classes
9. `tokens.tsx` - 3 hardcoded classes
10. `header.tsx` - 1 hardcoded class
11. `tooltip.tsx` - 1 hardcoded class

---

## 6. State Management Analysis

### 6.1 Zustand Stores

| Store | State | Actions | Usage |
|-------|-------|---------|-------|
| `auth-store` | token, user, expiresAt | login, logout | ✅ Full |
| `ui-store` | sidebarCollapsed, theme, commandPaletteOpen, sessionExpiredModalOpen | toggleSidebar, setTheme, etc. | ⚠️ Partial |

### 6.2 Unused State

| State | In Store | In UI |
|-------|----------|-------|
| `commandPaletteOpen` | ✅ | ❌ No command palette component |
| `theme` | ✅ | ❌ No toggle UI (only store persistence) |

---

## 7. Type Safety Analysis

### 7.1 Defined Types (Used)

| File | Types | Used In |
|------|-------|---------|
| `api.ts` | `ApiResponse`, `DN`, `UID`, etc. | All queries |
| `user.ts` | `User`, `UserCreateRequest`, `Group`, `OrgTreeNode` | User/group/org pages |
| `qr.ts` | `QRCodeResponse`, `QRRevokeResponse` | QR generator |
| `audit.ts` | `QRIssuanceAuditRecord`, `TerminationAuditRecord` | Tokens page |

### 7.2 Defined Types (Unused)

| Type | Defined | Used |
|------|---------|------|
| `UserUpdateRequest` | ✅ | ❌ No edit form |
| `UserTerminateRequest` | ✅ | ❌ No terminate action |
| `UserSuspendRequest` | ✅ | ❌ No suspend action |
| `UserUnsuspendRequest` | ✅ | ❌ No unsuspend action |
| `TerminationResponse` | ✅ | ❌ No terminate action |

### 7.3 Missing Types

| Type | Backend Support | Needed For |
|------|-----------------|------------|
| `OrgProfile` | ✅ | Org profiles CRUD |
| `OrgProfileCreateRequest` | ✅ | Create org profile |
| `SSOProfile` | ✅ | SSO profile management |
| `AuthFailureAuditRecord` | ✅ | Auth failures audit |
| `UserLifecycleAuditRecord` | ✅ | User lifecycle audit |
| `GroupCreateRequest` | ✅ | Create group |
| `OrgCreateRequest` | ✅ | Create org |

---

## 8. Gap Prioritization Matrix

### 8.1 Critical (P0) - Broken UI Elements

| Gap | Impact | Effort | Reason |
|-----|--------|--------|--------|
| Edit user form + mutation | High | Medium | Edit button exists but does nothing |
| Group create dialog + mutation | High | Low | Create button exists but does nothing |
| Org create dialog + mutation | High | Low | Create button exists but does nothing |
| Dashboard quick action wiring | Medium | Low | Buttons navigate nowhere |

### 8.2 High Priority (P1) - Core Admin Features

| Gap | Impact | Effort | Reason |
|-----|--------|--------|--------|
| User terminate action | High | Medium | Compliance requirement |
| User suspend/unsuspend actions | High | Medium | Access control |
| Password reset action | High | Low | Essential admin task |
| Group member management | High | Medium | Group membership is core |
| OrgProfiles module | High | High | Entire domain missing |

### 8.3 Medium Priority (P2) - Enhanced Features

| Gap | Impact | Effort | Reason |
|-----|--------|--------|--------|
| Audit dashboard (4 types) | Medium | Medium | Compliance reporting |
| CSV bulk import UI | Medium | High | Initial setup efficiency |
| User move org action | Medium | Low | Organization management |
| Group delete action | Medium | Low | Cleanup capability |
| Org rename/delete actions | Medium | Low | Organization management |

### 8.4 Low Priority (P3) - Polish

| Gap | Impact | Effort | Reason |
|-----|--------|--------|--------|
| Dark mode toggle UI | Low | Low | Tokens already defined |
| Dashboard real stats | Low | Low | Replace hardcoded values |
| Command palette | Low | Medium | Keyboard navigation |
| Tenant info in Settings | Low | Low | Nice to have |
| Bootstrap wizard | Low | Medium | Day-0 only |

---

## 9. Blind Spots & Assumptions

### 9.1 What Was Reviewed
- All backend endpoints via pattern search
- All frontend routes, queries, mutations
- All TypeScript types
- Design documents
- Store implementations
- Component implementations

### 9.2 What Was NOT Reviewed
- Test coverage for existing features
- Error boundary implementations
- Loading state completeness
- Mobile responsiveness
- Accessibility (WCAG) compliance beyond contrast
- Security (XSS, CSRF protection)
- Performance (bundle size, query deduplication)
- i18n readiness

### 9.3 Assumptions Made
- Mobile client endpoints (`/provision/consume`, `/provision/validate`) intentionally out of scope for admin UI
- Backend endpoints are stable and working
- Types in `FRONTEND_API_CONTRACTS.md` match actual backend responses

---

## 10. Recommended Next Steps

### Option A: Fix Broken UI First (Fast Wins)
**Timeline:** 1-2 days
**Scope:** P0 items only

1. Wire dashboard quick action buttons to navigation
2. Create `GroupCreateDialog` component
3. Create `OrgCreateDialog` component
4. Create `UserEditForm` with PATCH mutation
5. Add confirmation dialogs for destructive actions

**Pros:** Quick user satisfaction, unblocks basic workflows
**Cons:** Doesn't address missing modules

### Option B: Complete Core Admin (Comprehensive)
**Timeline:** 1-2 weeks
**Scope:** P0 + P1 items

1. All P0 items
2. User lifecycle actions (terminate, suspend, unsuspend)
3. Password reset functionality
4. Group detail page with member management
5. OrgProfiles CRUD module (new route, queries, mutations, UI)

**Pros:** Feature-complete admin panel
**Cons:** Longer timeline

### Option C: Compliance-First
**Timeline:** 3-5 days
**Scope:** P0 + Audit + User Lifecycle

1. All P0 items
2. Full audit dashboard (4 audit types)
3. User terminate with confirmation
4. User suspend/unsuspend

**Pros:** Meets compliance requirements
**Cons:** Leaves OrgProfiles module incomplete

---

## Appendix A: File Reference

### Frontend Files by Domain

```
src/frontend/src/
├── routes/
│   ├── index.tsx               # Dashboard
│   ├── login.tsx               # Login page
│   ├── my-profile.tsx          # User profile
│   ├── settings.tsx            # System settings
│   ├── __root.tsx              # Layout shell
│   ├── directory/
│   │   ├── route.tsx           # Directory layout
│   │   ├── users/
│   │   │   ├── index.tsx       # User list
│   │   │   ├── new.tsx         # Create user
│   │   │   └── $uid.tsx        # User detail
│   │   ├── groups/
│   │   │   └── index.tsx       # Group list
│   │   └── orgs/
│   │       └── index.tsx       # Org tree
│   └── provisioning/
│       ├── route.tsx           # Provisioning layout
│       ├── qr-generator.tsx    # QR generator
│       └── tokens.tsx          # Token audit
├── lib/
│   ├── queries/
│   │   ├── keys.ts             # Query key factory
│   │   ├── users.ts            # User queries
│   │   ├── orgs.ts             # Org queries
│   │   ├── groups.ts           # Group queries
│   │   ├── qr.ts               # QR queries + mutations
│   │   ├── audit.ts            # Audit queries
│   │   └── health.ts           # Health queries
│   ├── api-client.ts           # HTTP client
│   └── errors.ts               # Error handling
├── stores/
│   ├── auth-store.ts           # Auth state
│   └── ui-store.ts             # UI state
├── types/
│   ├── index.ts                # Type exports
│   ├── api.ts                  # Base types
│   ├── user.ts                 # User/Group/Org types
│   ├── qr.ts                   # QR types
│   └── audit.ts                # Audit types
└── components/
    ├── ui/                     # shadcn components
    └── features/               # Domain components
```

---

## Appendix B: Backend Endpoint Details

### Users Domain (11 endpoints)

| Endpoint | Method | Request Body | Response | Auth |
|----------|--------|--------------|----------|------|
| `/api/users` | GET | - | `{users: User[]}` | user |
| `/api/users/{uid}` | GET | - | `{user: User}` | user |
| `/api/users/{uid}` | PATCH | `UserUpdateRequest` | `{ok, modified[]}` | admin |
| `/api/users/{uid}/groups` | GET | - | `{groups: Group[]}` | user |
| `/api/users/create` | POST | `UserCreateRequest` | `{ok, dn, status}` | admin |
| `/api/users/{uid}/reset_password` | POST | `{newPassword}` | `{ok}` | admin |
| `/api/users/{uid}/move_org` | POST | `{orgDn}` | `{ok, newDn}` | admin |
| `/api/users/{uid}/terminate` | POST | `UserTerminateRequest` | `TerminationResponse` | admin |
| `/api/users/{uid}/suspend` | POST | `UserSuspendRequest` | `{ok, status}` | admin |
| `/api/users/{uid}/unsuspend` | POST | `UserUnsuspendRequest` | `{ok, status}` | admin |
| `/api/users/import_csv` | POST | `ImportCsvReq` | `{ok, imported, errors}` | admin |

### Organizations Domain (5 endpoints)

| Endpoint | Method | Request Body | Response | Auth |
|----------|--------|--------------|----------|------|
| `/api/org/tree` | GET | - | `{tree: OrgTreeNode[]}` | user |
| `/api/org/users` | GET | `?dn=&include_sub=` | `{users: User[]}` | user |
| `/api/org/create` | POST | `OrgCreateReq` | `{ok, orgDn}` | admin |
| `/api/org/rename` | POST | `OrgRenameReq` | `{ok, newDn}` | admin |
| `/api/org/{dn}` | DELETE | - | `{ok, deleted}` | admin |

### Groups Domain (6 endpoints)

| Endpoint | Method | Request Body | Response | Auth |
|----------|--------|--------------|----------|------|
| `/api/groups` | GET | - | `{groups: Group[]}` | user |
| `/api/groups/create` | POST | `GroupCreateReq` | `{ok, groupDn}` | admin |
| `/api/groups/{cn}/members` | GET | - | `{members: string[]}` | user |
| `/api/groups/{cn}/members` | POST | `GroupMemberAddReq` | `{ok}` | admin |
| `/api/groups/{cn}/members/{uid}` | DELETE | - | `{ok}` | admin |
| `/api/groups/{cn}` | DELETE | - | `{ok, deleted}` | admin |

### OrgProfiles Domain (9 endpoints)

| Endpoint | Method | Request Body | Response | Auth |
|----------|--------|--------------|----------|------|
| `/api/orgprofiles` | GET | - | `{profiles: OrgProfile[]}` | user |
| `/api/orgprofiles` | POST | `OrgProfileUpsert` | `{ok, profile}` | admin |
| `/api/orgprofiles/{id}` | GET | - | `{profile: OrgProfile}` | user |
| `/api/orgprofiles/{id}` | PATCH | `OrgProfilePatchReq` | `{ok, profile}` | admin |
| `/api/orgprofiles/{id}` | DELETE | - | `{ok}` | admin |
| `/api/orgprofiles/{id}/rotate_qr` | POST | `RotateReq` | `{ok, profile}` | admin |
| `/api/orgprofiles/{id}/qrcode` | GET | - | `{pngBase64, payload}` | user |
| `/api/orgprofiles/{id}/sso_profile` | GET | - | `{ssoProfile}` | user |
| `/api/orgprofiles/{id}/sso_profile/qrcode` | GET | - | `{pngBase64, payload}` | user |

### Audit Domain (4 endpoints)

| Endpoint | Method | Request Body | Response | Auth |
|----------|--------|--------------|----------|------|
| `/api/audit/qr_issuance` | GET | `?limit=` | `{records: QRIssuanceAuditRecord[]}` | admin |
| `/api/audit/terminations` | GET | `?limit=` | `{records: TerminationAuditRecord[]}` | admin |
| `/api/audit/auth_failures` | GET | `?limit=` | `{records: AuthFailureRecord[]}` | admin |
| `/api/audit/user_lifecycle` | GET | `?limit=` | `{records: UserLifecycleRecord[]}` | admin |

---

**End of Report**
