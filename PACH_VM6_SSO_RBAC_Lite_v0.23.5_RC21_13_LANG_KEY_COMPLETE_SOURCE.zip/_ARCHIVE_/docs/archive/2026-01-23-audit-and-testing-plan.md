# Audit Logging & Test Coverage Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Populate the existing audit tables that are currently empty, add the missing `user_lifecycle_audit` and `auth_failure_audit` tables, and add test coverage for CSV import and break-glass.

**Architecture:** Audit logging is added at the endpoint level in `main.py` (after the action succeeds, record the event). New tables are defined in `orgdb.py` with SQLAlchemy Core and auto-created on startup. Tests hit the real Docker stack.

**Tech Stack:** FastAPI, SQLAlchemy Core, PostgreSQL, pytest + httpx, ldap3

---

## Context for Implementer

**Current state:** The `qr_issuance_audit` table exists (defined in orgdb.py:117) but no code writes to it. The `GET /api/audit/qr_issuance` endpoint reads from it and returns an empty list. The `termination_events` table IS populated correctly.

**Tables that exist but are empty:**
- `qr_issuance_audit` — Schema: id, user_uid, org_dn, issued_by, issued_at, token_hash, expires_at, consumed, consumed_at, consumed_reason, client_ip, user_agent

**Tables that don't exist yet (need creation):**
- `user_lifecycle_audit` — Track user create, suspend, unsuspend, move_org, password_reset
- `auth_failure_audit` — Track failed OIDC token validations

**Key files:**
- `src/backend/main.py` — All API endpoints (~1280 lines)
- `src/backend/orgdb.py` — PostgreSQL tables + OrgDB class
- `src/backend/config.py` — Environment variables
- `tests/conftest.py` — Shared fixtures

**Patterns:**
- Tables: SQLAlchemy Core `Table()` with `metadata.create_all(eng)` on init
- OrgDB methods: `def method(self, ...) -> ...:` using `eng.begin() as conn:`
- Audit calls: fire-and-forget after the primary action succeeds

---

### Task 1: Populate `qr_issuance_audit` on Unified QR Generation

The unified QR endpoint (`GET /api/users/{uid}/qrcode`) generates QR codes but never records them to `qr_issuance_audit`.

**Files:**
- Modify: `src/backend/orgdb.py` (add `record_qr_issuance` method)
- Modify: `src/backend/main.py:818-855` (add audit call after QR generation)
- Modify: `tests/test_audit.py` (strengthen test)

**Step 1: Add the OrgDB method**

Add to `src/backend/orgdb.py` after the `list_auth_failures` method (at the end of the class):

```python
    def record_qr_issuance(
        self,
        user_uid: str,
        org_dn: str,
        issued_by: str,
        token_hash: str,
        expires_at: datetime,
    ) -> None:
        """Record a QR issuance event to the audit table."""
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(
                insert(qr_issuance_audit).values(
                    user_uid=user_uid,
                    org_dn=org_dn,
                    issued_by=issued_by,
                    issued_at=utcnow(),
                    token_hash=token_hash,
                    expires_at=expires_at,
                    consumed=False,
                )
            )
```

**Step 2: Call it from the unified QR endpoint**

In `src/backend/main.py`, in the `api_user_qrcode` function, add after `payload["sig"] = hmac_sig(payload)` and before `payload_text = ...`:

```python
    # Audit: record QR issuance
    import hashlib as _hl
    token_hash = _hl.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[:32]
    issued_by = claims.get("sub", "unknown")
    ORGDB.record_qr_issuance(
        user_uid=uid,
        org_dn=org_dn,
        issued_by=issued_by,
        token_hash=token_hash,
        expires_at=datetime.fromtimestamp(payload["exp"], tz=timezone.utc),
    )
```

**Step 3: Update the test to verify audit record appears**

Replace `test_qr_issuance_after_qr_generation` in `tests/test_audit.py`:

```python
    def test_qr_issuance_after_qr_generation(self, client, created_users):
        """After generating a QR, audit shows the issuance."""
        uid = "audit_qr_1"
        create_test_user(client, uid, created_users)

        # Generate a unified QR
        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200

        # Check audit
        resp = client.get("/api/audit/qr_issuance")
        assert resp.status_code == 200
        data = resp.json()
        user_uids = [r["user_uid"] for r in data["records"]]
        assert uid in user_uids, f"Expected {uid} in audit records, got: {user_uids}"
```

**Step 4: Run test**

Run: `pytest tests/test_audit.py -v`

Expected: All PASS

**Step 5: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_audit.py
git commit -m "feat(audit): populate qr_issuance_audit on unified QR generation (Spec §11)"
```

---

### Task 2: Add `user_lifecycle_audit` Table and Log User Creation

Track user lifecycle events (create, suspend, unsuspend, move_org, password_reset).

**Files:**
- Modify: `src/backend/orgdb.py` (add table + method)
- Modify: `src/backend/main.py` (add audit calls)
- Create: `tests/test_lifecycle_audit.py`

**Step 1: Write the failing test**

Create `tests/test_lifecycle_audit.py`:

```python
"""User lifecycle audit tests (Spec §11)."""

import pytest
from conftest import create_test_user, LDAP_BASE_DN


class TestLifecycleAudit:
    """GET /api/audit/user_lifecycle."""

    def test_lifecycle_endpoint_returns_list(self, client):
        """Returns ok with list of lifecycle records."""
        resp = client.get("/api/audit/user_lifecycle")
        assert resp.status_code == 200, f"Failed: {resp.text}"
        data = resp.json()
        assert data["ok"] is True
        assert "records" in data
        assert isinstance(data["records"], list)

    def test_user_create_appears_in_audit(self, client, created_users):
        """After creating a user, the event appears in lifecycle audit."""
        uid = "lifecycle_create_1"
        create_test_user(client, uid, created_users)

        resp = client.get("/api/audit/user_lifecycle")
        data = resp.json()
        create_events = [
            r for r in data["records"]
            if r["user_uid"] == uid and r["action"] == "created"
        ]
        assert len(create_events) >= 1, (
            f"Expected lifecycle 'created' event for {uid}, got: {data['records']}"
        )

    def test_suspend_appears_in_audit(self, client, created_users):
        """After suspending a user, the event appears in lifecycle audit."""
        uid = "lifecycle_suspend_1"
        create_test_user(client, uid, created_users)

        client.post(f"/api/users/{uid}/suspend", json={"reason": "test_audit"})

        resp = client.get("/api/audit/user_lifecycle")
        data = resp.json()
        suspend_events = [
            r for r in data["records"]
            if r["user_uid"] == uid and r["action"] == "suspended"
        ]
        assert len(suspend_events) >= 1

    def test_unsuspend_appears_in_audit(self, client, created_users):
        """After unsuspending a user, the event appears in lifecycle audit."""
        uid = "lifecycle_unsuspend_1"
        create_test_user(client, uid, created_users)

        client.post(f"/api/users/{uid}/suspend", json={"reason": "test"})
        client.post(f"/api/users/{uid}/unsuspend", json={"newPassword": "newpass123"})

        resp = client.get("/api/audit/user_lifecycle")
        data = resp.json()
        unsuspend_events = [
            r for r in data["records"]
            if r["user_uid"] == uid and r["action"] == "unsuspended"
        ]
        assert len(unsuspend_events) >= 1

    def test_password_reset_appears_in_audit(self, client, created_users):
        """After resetting password, the event appears in lifecycle audit."""
        uid = "lifecycle_pwreset_1"
        create_test_user(client, uid, created_users)

        client.post("/api/users/reset_password", json={
            "uid": uid,
            "newPassword": "auditpass789",
        })

        resp = client.get("/api/audit/user_lifecycle")
        data = resp.json()
        reset_events = [
            r for r in data["records"]
            if r["user_uid"] == uid and r["action"] == "password_reset"
        ]
        assert len(reset_events) >= 1
```

**Step 2: Run to verify failure**

Run: `pytest tests/test_lifecycle_audit.py -v`

Expected: FAIL (404 — endpoint doesn't exist)

**Step 3: Add table definition to orgdb.py**

Add after the `qr_issuance_audit` table (after line 132):

```python

user_lifecycle_audit = Table(
    "user_lifecycle_audit",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("user_uid", String(255), nullable=False),
    Column("action", String(50), nullable=False),  # created, suspended, unsuspended, password_reset, moved_org, updated
    Column("performed_by", String(255), nullable=True),
    Column("detail", Text, nullable=True),
    Column("timestamp", DateTime(timezone=True), nullable=False),
)
```

**Step 4: Add OrgDB methods**

Add after `record_qr_issuance` (from Task 1):

```python
    def record_lifecycle_event(
        self,
        user_uid: str,
        action: str,
        performed_by: str = "unknown",
        detail: str | None = None,
    ) -> None:
        """Record a user lifecycle event."""
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(
                insert(user_lifecycle_audit).values(
                    user_uid=user_uid,
                    action=action,
                    performed_by=performed_by,
                    detail=detail,
                    timestamp=utcnow(),
                )
            )

    def list_user_lifecycle(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent user lifecycle audit records."""
        eng = self.connect()
        stmt = (
            select(user_lifecycle_audit)
            .order_by(user_lifecycle_audit.c.timestamp.desc())
            .limit(limit)
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()
        return [
            {
                "id": r["id"],
                "user_uid": r["user_uid"],
                "action": r["action"],
                "performed_by": r["performed_by"],
                "detail": r["detail"],
                "timestamp": r["timestamp"].isoformat() if r["timestamp"] else None,
            }
            for r in rows
        ]
```

**Step 5: Add audit calls to endpoints in main.py**

In `api_user_create` (after successful creation, before return):
```python
    ORGDB.record_lifecycle_event(req.uid, "created", claims.get("sub", "unknown"))
```

In `api_user_suspend` (after `suspend_user(uid)`):
```python
    ORGDB.record_lifecycle_event(uid, "suspended", claims.get("sub", "unknown"), req.reason)
```

In `api_user_unsuspend` (after `unsuspend_user(uid, req.newPassword)`):
```python
    ORGDB.record_lifecycle_event(uid, "unsuspended", claims.get("sub", "unknown"))
```

In `api_user_reset_password` (after successful password reset, before return):
```python
    ORGDB.record_lifecycle_event(req.uid, "password_reset", claims.get("sub", "unknown"))
```

**Step 6: Add the audit endpoint in main.py**

Add after the `/api/audit/auth_failures` endpoint:

```python

@app.get("/api/audit/user_lifecycle")
def api_audit_user_lifecycle(
    limit: int = 100,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Query user lifecycle audit log (Spec §11)."""
    records = ORGDB.list_user_lifecycle(limit=min(limit, 1000))
    return {"ok": True, "records": records}
```

**Step 7: Run tests**

Run: `pytest tests/test_lifecycle_audit.py -v`

Expected: All 5 PASS

**Step 8: Run full suite**

Run: `pytest tests/ -q`

Expected: All pass

**Step 9: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_lifecycle_audit.py
git commit -m "feat(audit): add user_lifecycle_audit table and populate on CRUD events (Spec §11)"
```

---

### Task 3: Add `auth_failure_audit` Table and Log Token Failures

Populate the auth failure audit when OIDC token validation fails.

**Files:**
- Modify: `src/backend/orgdb.py` (add table + methods)
- Modify: `src/backend/main.py` (add logging in `_claims_from_auth_header`)
- Modify: `tests/test_audit.py` (strengthen auth failure test)

**Step 1: Write the failing test**

Add to `tests/test_audit.py` in `TestAuditAuthFailures`:

```python
    def test_invalid_token_appears_in_audit(self, client):
        """After sending an invalid token, the failure appears in audit (requires OIDC mode)."""
        # This test only works if REQUIRE_OIDC_AUTH=true. In dev mode (OIDC disabled),
        # the endpoint still returns empty. We verify the structure is correct.
        resp = client.get("/api/audit/auth_failures")
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert isinstance(data["records"], list)
        # In dev mode (no OIDC), this will be empty — that's expected
```

**Step 2: Add table definition to orgdb.py**

Add after `user_lifecycle_audit` table:

```python

auth_failure_audit = Table(
    "auth_failure_audit",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("client_ip", String(45), nullable=True),
    Column("endpoint", Text, nullable=True),
    Column("error_type", String(100), nullable=False),  # invalid_token, expired_token, missing_token
    Column("detail", Text, nullable=True),
    Column("timestamp", DateTime(timezone=True), nullable=False),
)
```

**Step 3: Add OrgDB methods**

```python
    def record_auth_failure(
        self,
        client_ip: str,
        endpoint: str,
        error_type: str,
        detail: str | None = None,
    ) -> None:
        """Record an authentication failure event."""
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(
                insert(auth_failure_audit).values(
                    client_ip=client_ip,
                    endpoint=endpoint,
                    error_type=error_type,
                    detail=detail,
                    timestamp=utcnow(),
                )
            )

    def list_auth_failures(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent auth failure records."""
        eng = self.connect()
        stmt = (
            select(auth_failure_audit)
            .order_by(auth_failure_audit.c.timestamp.desc())
            .limit(limit)
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()
        return [
            {
                "id": r["id"],
                "client_ip": r["client_ip"],
                "endpoint": r["endpoint"],
                "error_type": r["error_type"],
                "detail": r["detail"],
                "timestamp": r["timestamp"].isoformat() if r["timestamp"] else None,
            }
            for r in rows
        ]
```

Note: This replaces the existing `list_auth_failures` method that just returns `[]`.

**Step 4: Add logging in main.py**

In the `_claims_from_auth_header` function, modify the token validation failure to log:

Replace:
```python
    try:
        return verify_bearer_token(token)
    except Exception as e:
        raise HTTPException(401, f"Invalid token: {e}")
```

With:
```python
    try:
        return verify_bearer_token(token)
    except Exception as e:
        client_ip = request.client.host if request.client else "unknown"
        try:
            ORGDB.record_auth_failure(client_ip, request.url.path, "invalid_token", str(e))
        except Exception:
            pass  # Don't let audit failure break auth flow
        raise HTTPException(401, f"Invalid token: {e}")
```

**Step 5: Run tests**

Run: `pytest tests/test_audit.py -v`

Expected: All PASS

**Step 6: Run full suite**

Run: `pytest tests/ -q`

Expected: All pass

**Step 7: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_audit.py
git commit -m "feat(audit): add auth_failure_audit table and log token validation failures (Spec §11)"
```

---

### Task 4: CSV Import Integration Tests

The `POST /api/users/import_csv` endpoint exists but has zero dedicated tests.

**Files:**
- Create: `tests/test_import_csv.py`

**Step 1: Write the tests**

Create `tests/test_import_csv.py`:

```python
"""CSV import endpoint tests."""

import pytest
from conftest import LDAP_BASE_DN


@pytest.fixture
def cleanup_csv_users(client, ldap_conn):
    """Track and cleanup users created via CSV import."""
    uids = []
    yield uids
    for uid in uids:
        # Try to delete the user
        from ldap3 import SUBTREE
        ldap_conn.search(
            f"ou=people,{LDAP_BASE_DN}",
            f"(uid={uid})",
            SUBTREE,
        )
        for entry in ldap_conn.entries:
            ldap_conn.delete(entry.entry_dn)


class TestCSVImport:
    """POST /api/users/import_csv."""

    def test_import_single_user(self, client, cleanup_csv_users):
        """Import a single user via CSV."""
        csv_content = "uid,displayName,mail,mobile,password\ncsv_user_1,CSV User One,csv1@test.com,5551111111,csvpass123"
        resp = client.post("/api/users/import_csv", json={
            "csv": csv_content,
        })
        assert resp.status_code == 200, f"Import failed: {resp.text}"
        data = resp.json()
        assert data["ok"] is True
        assert data["created"] == 1
        assert data["errors"] == []
        cleanup_csv_users.append("csv_user_1")

        # Verify user exists
        resp = client.get("/api/users/csv_user_1")
        assert resp.status_code == 200
        assert resp.json()["user"]["uid"] == "csv_user_1"

    def test_import_multiple_users(self, client, cleanup_csv_users):
        """Import multiple users via CSV."""
        csv_content = (
            "uid,displayName,mail,mobile,password\n"
            "csv_multi_1,Multi One,multi1@test.com,5552222221,pass1\n"
            "csv_multi_2,Multi Two,multi2@test.com,5552222222,pass2\n"
            "csv_multi_3,Multi Three,multi3@test.com,5552222223,pass3"
        )
        resp = client.post("/api/users/import_csv", json={
            "csv": csv_content,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["created"] == 3
        cleanup_csv_users.extend(["csv_multi_1", "csv_multi_2", "csv_multi_3"])

    def test_import_with_org_path(self, client, cleanup_csv_users, ldap_conn):
        """Import user with orgPath creates org and places user."""
        csv_content = "uid,displayName,mail,mobile,password,orgPath\ncsv_org_1,Org User,org@test.com,5553333333,pass1,CSVTestOrg"
        resp = client.post("/api/users/import_csv", json={
            "csv": csv_content,
            "autoCreateOrg": True,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["created"] == 1
        cleanup_csv_users.append("csv_org_1")

        # Cleanup the org
        org_dn = f"ou=CSVTestOrg,ou=org,{LDAP_BASE_DN}"
        people_dn = f"ou=CSVTestOrg,ou=people,{LDAP_BASE_DN}"
        groups_dn = f"ou=CSVTestOrg,ou=groups,{LDAP_BASE_DN}"
        # User is under people sub-org
        user_dn = f"uid=csv_org_1,{people_dn}"
        ldap_conn.delete(user_dn)
        ldap_conn.delete(people_dn)
        ldap_conn.delete(groups_dn)
        ldap_conn.delete(org_dn)

    def test_import_duplicate_user_counts_as_updated(self, client, cleanup_csv_users):
        """Importing an existing user counts as updated, not error."""
        csv_content = "uid,displayName,mail,mobile,password\ncsv_dup_1,Dup User,dup@test.com,5554444444,pass1"
        # First import
        resp = client.post("/api/users/import_csv", json={"csv": csv_content})
        assert resp.status_code == 200
        cleanup_csv_users.append("csv_dup_1")

        # Second import
        resp = client.post("/api/users/import_csv", json={"csv": csv_content})
        assert resp.status_code == 200
        data = resp.json()
        assert data["updated"] >= 1
        assert data["errors"] == []

    def test_import_empty_csv_does_nothing(self, client):
        """Empty CSV (headers only) creates nothing."""
        csv_content = "uid,displayName,mail,mobile,password\n"
        resp = client.post("/api/users/import_csv", json={"csv": csv_content})
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["created"] == 0

    def test_import_skips_empty_uid_rows(self, client, cleanup_csv_users):
        """Rows with empty uid are skipped."""
        csv_content = (
            "uid,displayName,mail,mobile,password\n"
            ",Empty UID,empty@test.com,5555555555,pass1\n"
            "csv_skip_1,Valid User,valid@test.com,5555555556,pass2"
        )
        resp = client.post("/api/users/import_csv", json={"csv": csv_content})
        assert resp.status_code == 200
        data = resp.json()
        assert data["created"] == 1
        cleanup_csv_users.append("csv_skip_1")
```

**Step 2: Run tests**

Run: `pytest tests/test_import_csv.py -v`

Expected: All 6 PASS (endpoint already exists)

**Step 3: Commit**

```bash
git add tests/test_import_csv.py
git commit -m "test(import): add CSV import endpoint integration tests"
```

---

### Task 5: Break-Glass Recovery Tests

The break-glass code exists in main.py but has zero tests. These tests require `REQUIRE_OIDC_AUTH=true` to exercise the break-glass path.

**Files:**
- Create: `tests/test_breakglass.py`

**Step 1: Write the tests**

Create `tests/test_breakglass.py`:

```python
"""Break-glass recovery tests (Spec §12).

These tests verify the _load_breakglass and _breakglass_allows logic by
importing and testing the functions directly (unit tests), since the Docker
stack runs with REQUIRE_OIDC_AUTH=false (break-glass path not reachable via HTTP).
"""

import json
import os
import tempfile
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock

import pytest

# Import the break-glass functions directly from the backend module
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src", "backend"))
from main import _load_breakglass


class TestBreakglassLoad:
    """Unit tests for _load_breakglass function."""

    def test_nonexistent_file_returns_none(self, tmp_path):
        """Missing file returns None (break-glass disabled)."""
        result = _load_breakglass(str(tmp_path / "does_not_exist.json"))
        assert result is None

    def test_disabled_config_returns_none(self, tmp_path):
        """enabled=false returns None."""
        cfg = tmp_path / "breakglass.json"
        cfg.write_text(json.dumps({
            "enabled": False,
            "expires_at": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
        }))
        result = _load_breakglass(str(cfg))
        assert result is None

    def test_expired_config_returns_none(self, tmp_path):
        """Expired timestamp returns None."""
        cfg = tmp_path / "breakglass.json"
        cfg.write_text(json.dumps({
            "enabled": True,
            "expires_at": (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat(),
        }))
        result = _load_breakglass(str(cfg))
        assert result is None

    def test_valid_config_returns_dict(self, tmp_path):
        """Valid, non-expired config returns parsed dict."""
        expires = (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat()
        cfg = tmp_path / "breakglass.json"
        cfg.write_text(json.dumps({
            "enabled": True,
            "expires_at": expires,
            "allow_from": ["127.0.0.1", "10.0.0.1"],
            "mode": "admin_recovery",
        }))
        result = _load_breakglass(str(cfg))
        assert result is not None
        assert result["mode"] == "admin_recovery"
        assert "127.0.0.1" in result["allow_from"]
        assert "10.0.0.1" in result["allow_from"]

    def test_invalid_mode_defaults_to_bootstrap(self, tmp_path):
        """Unknown mode defaults to bootstrap_only."""
        expires = (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat()
        cfg = tmp_path / "breakglass.json"
        cfg.write_text(json.dumps({
            "enabled": True,
            "expires_at": expires,
            "mode": "invalid_mode",
        }))
        result = _load_breakglass(str(cfg))
        assert result is not None
        assert result["mode"] == "bootstrap_only"

    def test_missing_expires_returns_none(self, tmp_path):
        """Config without expires_at returns None."""
        cfg = tmp_path / "breakglass.json"
        cfg.write_text(json.dumps({
            "enabled": True,
            "mode": "admin_recovery",
        }))
        result = _load_breakglass(str(cfg))
        assert result is None

    def test_malformed_json_returns_none(self, tmp_path):
        """Malformed JSON returns None (doesn't crash)."""
        cfg = tmp_path / "breakglass.json"
        cfg.write_text("not valid json {{{")
        result = _load_breakglass(str(cfg))
        assert result is None

    def test_default_allow_from_is_localhost(self, tmp_path):
        """Missing allow_from defaults to localhost."""
        expires = (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat()
        cfg = tmp_path / "breakglass.json"
        cfg.write_text(json.dumps({
            "enabled": True,
            "expires_at": expires,
            "mode": "bootstrap_only",
        }))
        result = _load_breakglass(str(cfg))
        assert result is not None
        assert "127.0.0.1" in result["allow_from"]
        assert "::1" in result["allow_from"]
```

**Step 2: Run tests**

Run: `pytest tests/test_breakglass.py -v`

Expected: All 8 PASS (testing existing logic)

**Step 3: Commit**

```bash
git add tests/test_breakglass.py
git commit -m "test(breakglass): add unit tests for break-glass config loading (Spec §12)"
```

---

### Task 6: Full Suite Validation

**Files:** None (validation only)

**Step 1: Run full test suite**

Run: `pytest tests/ -v`

Expected: All tests pass (~100+ tests total)

**Step 2: Run twice to verify no pollution**

Run: `pytest tests/ -q && pytest tests/ -q`

Expected: Both runs pass identically

**Step 3: Count total tests**

Run: `pytest tests/ --co -q | tail -1`

Expected: ~100+ tests collected

**Step 4: No commit needed if everything passes**

---
