# Production Readiness Assessment: Backend vs Spec v1.0

**Date:** 2026-01-22
**Spec Reference:** `specs/v1.0/SPEC.md`
**Implementation:** `src/backend/`
**Overall Completeness:** ~38%

---

## Executive Summary

The backend is functional for development and demos but **not production-ready**. Three critical blockers must be resolved before any production deployment:

1. **No rate limiting** - All endpoints vulnerable to abuse
2. **One-time tokens not enforced** - QR codes reusable indefinitely
3. **No user termination flow** - Compliance failure for offboarding

---

## P0: Critical Blockers

### 1. No Rate Limiting

**Current state:** Zero rate limiting on any endpoint (`main.py` has no throttling middleware).

**Risk:**
- Denial of service attacks
- Credential stuffing on auth endpoints
- QR token exhaustion attacks
- Mass account creation abuse

**Spec requirement (Section 0.3):**

| Endpoint | Required Limit |
|----------|----------------|
| `/api/bootstrap` | 5/hour |
| `/api/users/create` | 20/minute |
| `/api/users/*/qrcode*` | 10/minute |
| Auth failures | 5/5min + soft-lock |
| All other endpoints | 100/minute |

**Required fix:** Add Redis infrastructure + rate limiting middleware (slowapi or nginx).

---

### 2. One-Time Token Enforcement Missing

**Current state:** Tokens are recorded in `provision_tokens` table (`main.py:664`) but never validated on consumption. No endpoint checks token status before accepting it.

**Risk:**
- Leaked/photographed QR codes work forever
- Terminated users can still provision new devices
- No way to revoke a specific QR code

**Spec requirement (Section 0.2):**
- Token hash stored on issuance
- On first use: mark consumed, proceed
- On reuse: reject with `TOKEN_ALREADY_CONSUMED`
- On expiry: reject with `TOKEN_EXPIRED`

**Required fix:**
1. Add token consumption endpoint or integrate into provisioning flow
2. Add `consumed`, `consumed_at`, `consumed_reason` columns
3. Validate token status before accepting

---

### 3. No User Termination Flow

**Current state:** `POST /api/users/{uid}/terminate` does not exist. No way to properly offboard a user.

**Risk:**
- Compliance failure (terminated employees retain access)
- No audit trail for terminations
- Active sessions persist after offboarding

**Spec requirement (Section 6.2):** Ordered termination actions:
1. Disable LDAP account
2. Invalidate all provisioning tokens
3. Revoke Authentik sessions (if enabled)
4. Signal UC Server to kill active sessions
5. Log termination event
6. Notify connected clients (optional)

**Required fix:** Implement full termination endpoint with audit logging.

---

## P1: Security Hardening

### 4. QR Schema Mismatch

**Current (`main.py:571-579`):**
```json
{"type": "ucchat-user-provision", "v": 1, "uid": "...", "sig": "..."}
```

**Spec requires:**
```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {"uc": {...}, "sso": null},
  "iat": 1704067200,
  "exp": 1704070800,
  "nonce": "...",
  "sig": "..."
}
```

**Risk:** Mobile clients built against spec won't parse current QR codes. Missing `nonce` and `exp` fields reduce replay protection.

---

### 5. No Health Check Endpoints

**Missing:**
- `GET /api/health` - Basic liveness
- `GET /api/health/deep` - LDAP/PostgreSQL/Redis connectivity

**Risk:** Load balancers and orchestrators can't detect unhealthy instances.

---

### 6. Hardcoded/Weak Signing Secret

**Risk:** If dev default (`dev_signing_secret_change_in_prod`) reaches production, all QR signatures can be forged.

**Required:** Cryptographically random 32+ byte secret via `ORG_QR_SIGNING_SECRET`.

---

### 7. CORS Wide Open

**Current (`main.py:48-54`):**
```python
allow_origins=["*"]
```

**Risk:** Any website can make authenticated API calls if user's browser has valid token.

**Required:** Restrict to known frontend origins in production.

---

## P1: Operational Readiness

### 8. No Audit Logging Infrastructure

**Missing tables:**
- `qr_issuance_audit` (full schema)
- `termination_events`
- `auth_failure_audit`
- `breakglass_audit`
- `user_lifecycle_audit`
- `admin_auth_audit`
- `orgprofile_audit`

**Risk:** No forensic trail for security incidents.

---

### 9. No Redis Infrastructure

**Required for:**
- Rate limiting state
- Session caching
- Break-glass cache (currently re-reads file every request)

**Current docker-compose:** No Redis service.

---

### 10. No Database Migrations

**Current:** Tables created via `ORGDB.init()` with no versioning.

**Risk:** No safe upgrade path when schema changes needed.

---

### 11. Break-glass Permissions Not Enforced

**Spec requires:** File owned by root, mode 640, backend runs as non-root.

**Current:** No permission enforcement. Attacker with file write access can grant admin.

---

## Acceptable Gaps (Defer to Post-Launch)

| Item | Reason Acceptable |
|------|-------------------|
| Authentik integration | Spec treats as optional; UC-only works without it |
| REST endpoint style (POST vs DELETE) | Functionally equivalent |
| Code modularization | Maintainability debt, not security issue |
| Admin UI completeness | API works; UI can iterate |
| `PATCH /api/users/{uid}` | Workarounds exist |

---

## Minimum Path to Production

| Priority | Item | Effort | Dependency |
|----------|------|--------|------------|
| **P0** | Redis infrastructure | Small | None |
| **P0** | Rate limiting | Medium | Redis |
| **P0** | One-time token enforcement | Small | None |
| **P0** | User termination endpoint | Medium | Audit tables |
| **P1** | Health check endpoints | Small | None |
| **P1** | Audit tables + logging | Medium | None |
| **P1** | QR schema alignment | Medium | Mobile client coordination |
| **P2** | CORS lockdown | Small | Known frontend origins |
| **P2** | Database migrations | Medium | None |

---

## Recommended Implementation Order

1. **Add Redis to docker-compose** (unblocks rate limiting)
2. **Create audit tables** (unblocks termination logging)
3. **Implement rate limiting** (biggest security gap)
4. **Implement token consumption validation** (second biggest gap)
5. **Implement termination endpoint** (compliance requirement)
6. **Add health endpoints** (operational necessity)
7. **Align QR schema** (coordinate with mobile team)
8. **Lock down CORS** (requires frontend origin list)

---

## References

- Spec: `specs/v1.0/SPEC.md`
- Existing gap analysis: `milestones/v1.0-baseline/GAP_ANALYSIS.md`
- Checklist: `milestones/v1.0-baseline/CHECKLIST.md`
