# Critical Fixes: Backend Bugs & Test Quality

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Fix the confirmed backend bug (`BASE` not imported in `ldap_client.py`), remove "always-pass" test patterns, and add proper failing-then-passing tests for the features that were untested.

**Architecture:** Fix the backend first (import the missing constant), then rewrite the 3 tests that accept 500 as passing into tests that actually assert correct behavior.

**Tech Stack:** Python 3.12, ldap3, pytest, FastAPI

---

## Context: What the Code Review Found

1. **Confirmed backend bug:** `ldap_client.py:334` uses `BASE` but never imports it — causes `NameError` at runtime, endpoint returns 500
2. **3 tests that can never fail:** `test_rename_org`, `test_list_group_members`, `test_move_user_to_different_org` all accept both 200 and 500
3. **2 "known bugs" that aren't actually bugs:** `rename_org_ou()` and `move_user_to_org()` use `delete_old_rdn` which IS the correct ldap3 kwarg name (tests return 200)

---

### Task 1: Fix `BASE` Import in ldap_client.py

**Files:**
- Modify: `src/backend/ldap_client.py:1`

**Step 1: Add BASE to the import statement**

Change line 1 from:
```python
from ldap3 import Server, Connection, ALL, MODIFY_ADD, MODIFY_DELETE, MODIFY_REPLACE, SUBTREE, LEVEL
```
to:
```python
from ldap3 import Server, Connection, ALL, BASE, MODIFY_ADD, MODIFY_DELETE, MODIFY_REPLACE, SUBTREE, LEVEL
```

**Step 2: Verify the fix by calling the endpoint**

Run:
```bash
curl -s "http://localhost:8081/api/groups/members?groupDn=cn%3DIT-Admins%2Cou%3Dgroups%2Cdc%3Dazblink%2Cdc%3Dcom" | python -m json.tool
```

Expected: 200 with `{"ok": true, "groupDn": "...", "users": [...]}` (NOT 500)

Wait 2 seconds for hot reload before testing.

**Step 3: Commit**

```bash
git add src/backend/ldap_client.py
git commit -m "fix(ldap): import BASE scope constant for get_group_members"
```

---

### Task 2: Rewrite `test_list_group_members` to Assert Success

**Files:**
- Modify: `tests/test_org_groups.py:183-218`

**Step 1: Remove the 500-accepting pattern**

Replace the `test_list_group_members` method with one that asserts 200:

```python
    def test_list_group_members(self, client, created_users, ldap_conn):
        """Create group with member, GET /api/groups/members returns that member."""
        uid = "grp_members_list_1"
        cn = "testgroup-members-list-1"

        # Create a test user
        resp = create_test_user(client, uid, created_users)
        assert resp.status_code == 200

        # Create a group
        resp = client.post("/api/groups/create", json={
            "orgDn": OU_ORG,
            "cn": cn,
        })
        assert resp.status_code == 200

        group_dn = f"cn={cn},{OU_GROUPS}"

        try:
            # Add user to group
            resp = client.post("/api/groups/members/add", json={
                "groupDn": group_dn,
                "uid": uid,
            })
            assert resp.status_code == 200

            # List members — must return 200 with the user
            resp = client.get("/api/groups/members", params={
                "groupDn": group_dn,
            })
            assert resp.status_code == 200, (
                f"Expected 200, got {resp.status_code}: {resp.text}"
            )
            data = resp.json()
            assert data["ok"] is True
            assert "users" in data
            assert isinstance(data["users"], list)
            # Our user should be in the members list
            member_uids = [u["uid"] for u in data["users"]]
            assert uid in member_uids, (
                f"Expected {uid} in members, got: {member_uids}"
            )
        finally:
            # Cleanup group
            ldap_conn.delete(group_dn)
```

**Step 2: Run the test**

Run: `pytest tests/test_org_groups.py::TestGroupCRUD::test_list_group_members -v`

Expected: PASS (because Task 1 fixed the BASE import)

**Step 3: Commit**

```bash
git add tests/test_org_groups.py
git commit -m "test(groups): assert group members endpoint returns 200 (not 500)"
```

---

### Task 3: Rewrite `test_rename_org` to Assert Success Only

**Files:**
- Modify: `tests/test_org_groups.py:52-90`

**Step 1: Remove the 500-accepting pattern**

Replace with a test that asserts 200 only:

```python
    def test_rename_org(self, client, cleanup_orgs):
        """Create org, then POST /api/org/rename, verify success and new DN."""
        org_name = "TestOrgRename1"
        new_name = "TestOrgRenamed1"

        # Create the org
        resp = client.post("/api/org/create", json={
            "parentDn": OU_ORG,
            "name": org_name,
        })
        assert resp.status_code == 200

        original_dn = f"ou={org_name},{OU_ORG}"
        new_dn = f"ou={new_name},{OU_ORG}"

        # Rename it
        resp = client.post("/api/org/rename", json={
            "dn": original_dn,
            "newName": new_name,
        })
        assert resp.status_code == 200, (
            f"Rename failed with {resp.status_code}: {resp.text}"
        )
        data = resp.json()
        assert data["ok"] is True

        # Track the NEW dn for cleanup
        cleanup_orgs.append(new_dn)
```

**Step 2: Run the test**

Run: `pytest tests/test_org_groups.py::TestOrgCRUD::test_rename_org -v`

Expected: PASS (confirmed in prior run that rename returns 200)

**Step 3: Commit**

```bash
git add tests/test_org_groups.py
git commit -m "test(org): assert rename endpoint returns 200 (remove 500 fallback)"
```

---

### Task 4: Rewrite `test_move_user_to_different_org` to Assert Success Only

**Files:**
- Modify: `tests/test_users.py:147-196`

**Step 1: Remove the 500-accepting pattern**

Replace with a test that asserts 200 only:

```python
    def test_move_user_to_different_org(self, client, created_users, ldap_conn):
        """Move user to a different org, assert ok=True and cleanup."""
        uid = "crud_move_1"
        resp = create_test_user(client, uid, created_users)
        assert resp.status_code == 200

        # Create a target org
        target_org_name = "MoveTarget"
        org_resp = client.post("/api/org/create", json={
            "parentDn": f"ou=org,{LDAP_BASE_DN}",
            "name": target_org_name,
        })
        assert org_resp.status_code == 200, f"Failed to create target org: {org_resp.text}"

        target_org_dn = f"ou={target_org_name},ou=org,{LDAP_BASE_DN}"

        try:
            # Move the user
            move_resp = client.post("/api/users/move_org", json={
                "uid": uid,
                "orgDn": target_org_dn,
            })
            assert move_resp.status_code == 200, (
                f"Move failed with {move_resp.status_code}: {move_resp.text}"
            )
            move_data = move_resp.json()
            assert move_data["ok"] is True
        finally:
            # Cleanup: delete moved user from new location
            new_user_dn = f"uid={uid},ou={target_org_name},ou=people,{LDAP_BASE_DN}"
            ldap_conn.delete(new_user_dn)
            # Remove the people sub-OU
            people_sub_dn = f"ou={target_org_name},ou=people,{LDAP_BASE_DN}"
            ldap_conn.delete(people_sub_dn)
            # Remove the groups sub-OU
            groups_sub_dn = f"ou={target_org_name},ou=groups,{LDAP_BASE_DN}"
            ldap_conn.delete(groups_sub_dn)
            # Remove the org OU
            ldap_conn.delete(target_org_dn)
            # Remove from created_users list since we cleaned up manually
            if uid in created_users:
                created_users.remove(uid)
```

**Step 2: Run the test**

Run: `pytest tests/test_users.py::TestUserMoveOrg::test_move_user_to_different_org -v`

Expected: PASS (confirmed in prior run that move returns 200)

**Step 3: Commit**

```bash
git add tests/test_users.py
git commit -m "test(users): assert move_org returns 200 (remove 500 fallback)"
```

---

### Task 5: Run Full Suite to Confirm No Regressions

**Files:** None (validation only)

**Step 1: Run full test suite**

Run: `pytest tests/ -v`

Expected: 66 passed, 1 skipped, 0 failed

**Step 2: Run twice to verify no test pollution**

Run: `pytest tests/ -v && pytest tests/ -v`

Expected: Both runs pass identically

**Step 3: No commit needed if everything passes**

---
