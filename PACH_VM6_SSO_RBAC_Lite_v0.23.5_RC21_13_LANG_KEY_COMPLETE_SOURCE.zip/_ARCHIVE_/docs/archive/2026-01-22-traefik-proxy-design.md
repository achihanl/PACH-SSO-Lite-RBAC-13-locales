# Traefik Proxy for Dev Stack

## Summary

Add Traefik reverse proxy to the dev stack for path-based routing. Self-contained architecture with no hardcoded hostnames - works with localhost, IP addresses, or tunnels without configuration.

**Implementation Notes:**
- Using Traefik v2.11 (v3.x has Docker API compatibility issues)
- Port 8081 (port 80 was in use on the host)
- Network name is `dev_azblink-net` (compose prefixes with project name)
- Path-only routing (no Host() rules) for VM packaging portability

## Architecture

```
┌─────────────────────┐     ┌─────────────────┐     ┌──────────────────┐
│  Cloudflare Tunnel  │────▶│     Traefik     │────▶│  directory-ui    │
│  (external access)  │     │     :80         │     │  :8001 internal  │
└─────────────────────┘     │                 │     └──────────────────┘
                            │  /api/* ───────────▶  ┌──────────────────┐
┌─────────────────────┐     │  (strip prefix) │     │  directory-api   │
│  localhost:80       │────▶│                 │     │  :8000 internal  │
│  (local dev)        │     └─────────────────┘     └──────────────────┘
└─────────────────────┘
```

## Routing Rules

| Path | Priority | Destination | Notes |
|------|----------|-------------|-------|
| `/api/*` | 10 | directory-api:8000 | Strip `/api` prefix |
| `/*` | 1 | directory-ui:8001 | Catch-all |

Accepts any hostname (path-based routing only). See `2026-01-26-self-contained-hostname-design.md`.

## Design Decisions

1. **Path-prefix routing** over subdomain routing
   - Single hostname, no CORS issues
   - One DNS record, one Cloudflare tunnel rule

2. **Strip prefix middleware**
   - Backend unchanged, receives `/health` not `/api/health`
   - No FastAPI modifications needed

3. **Integrated into docker-compose.yml**
   - Single file, no layered compose complexity
   - Dev stack prioritizes simplicity

4. **Traefik-only access**
   - Remove direct port mappings for API/UI
   - All HTTP traffic through Traefik on port 80
   - Keep postgres:5433 and ldap:1390 for dev tooling

5. **No dashboard**
   - Simpler, more secure
   - Debug via `docker compose logs traefik`

## Implementation

### Add Traefik Service

```yaml
traefik:
  image: traefik:v3.2
  container_name: azblink-traefik
  restart: unless-stopped
  command:
    - "--providers.docker=true"
    - "--providers.docker.exposedbydefault=false"
    - "--providers.docker.network=azblink-net"
    - "--entrypoints.web.address=:80"
    - "--log.level=INFO"
  ports:
    - "80:80"
  networks:
    - azblink-net
  volumes:
    - /var/run/docker.sock:/var/run/docker.sock:ro
```

### Add Labels to directory-ui

```yaml
labels:
  - "traefik.enable=true"
  - "traefik.http.routers.ui.rule=PathPrefix(`/`)"
  - "traefik.http.routers.ui.entrypoints=web"
  - "traefik.http.routers.ui.priority=1"
  - "traefik.http.services.ui.loadbalancer.server.port=8001"
```

### Add Labels to directory-api

```yaml
labels:
  - "traefik.enable=true"
  - "traefik.http.routers.api.rule=PathPrefix(`/api`)"
  - "traefik.http.routers.api.entrypoints=web"
  - "traefik.http.routers.api.priority=10"
  - "traefik.http.middlewares.api-strip.stripprefix.prefixes=/api"
  - "traefik.http.routers.api.middlewares=api-strip"
  - "traefik.http.services.api.loadbalancer.server.port=8000"
```

### Remove Port Mappings

Remove from `directory-api`:
```yaml
ports:
  - "8000:8000"  # DELETE
```

Remove from `directory-ui`:
```yaml
ports:
  - "8001:8001"  # DELETE
```

## Testing

```bash
# Start stack
cd deploy/dev && docker compose up -d

# Test UI
curl -s http://localhost/ | head -5

# Test API (verify strip prefix works)
curl http://localhost/api/health

# Test API docs
curl http://localhost/api/docs

# Debug routing
docker compose logs traefik
```

## External Access (Optional)

For tunnels or external access, connect your tunnel service (Cloudflare, ngrok, etc.) to `azblink-traefik:80` on the `azblink-net` network. No Traefik configuration changes required - path-based routing accepts any hostname.
