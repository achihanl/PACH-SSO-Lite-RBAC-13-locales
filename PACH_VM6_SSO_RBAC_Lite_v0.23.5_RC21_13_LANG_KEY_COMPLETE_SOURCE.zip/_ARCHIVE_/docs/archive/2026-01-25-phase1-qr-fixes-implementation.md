# Phase 1 QR Fixes Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Fix 9 issues from code review - startup validation, error handling, code cleanup.

**Architecture:** Surgical fixes to existing files. No new files except test additions. Changes ordered from lowest to highest risk.

**Tech Stack:** Python 3.12, FastAPI, SQLAlchemy, pytest

---

## Task 1: Update Environment Files

**Files:**
- Modify: `deploy/dev/.env.example`
- Modify: `deploy/dev/.env`

**Step 1: Add UC variables to .env.example**

Add at end of `deploy/dev/.env.example`:
```bash
# UC Core QR Provisioning (Phase 1) - REQUIRED for QR features
UCCHAT_XMPP_DOMAIN=xmpp.example.com
UCCHAT_XMPP_WS_URL=wss://xmpp.example.com/ws
UCCHAT_SIP_DOMAIN=sip.example.com
UCCHAT_SIP_WSS_URL=wss://sip.example.com/ws

# QR Token TTL (optional - defaults shown)
# ORG_QR_DEFAULT_TTL_SEC=3600
# ORG_QR_MAX_TTL_SEC=86400
```

**Step 2: Add UC variables to .env (with dev values)**

Add at end of `deploy/dev/.env`:
```bash
# UC Core QR Provisioning (Phase 1)
UCCHAT_XMPP_DOMAIN=xmpp.azblink.com
UCCHAT_XMPP_WS_URL=wss://xmpp.azblink.com/ws
UCCHAT_SIP_DOMAIN=sip.azblink.com
UCCHAT_SIP_WSS_URL=wss://sip.azblink.com/ws
```

**Step 3: Commit**

```bash
git add deploy/dev/.env.example deploy/dev/.env
git commit -m "docs: add UC provisioning variables to env files"
```

---

## Task 2: Document Manual Migration

**Files:**
- Modify: `CLAUDE.md`

**Step 1: Add migration section to CLAUDE.md**

Find the "## Development Commands" section and add after it:

```markdown
## Database Migrations

For existing deployments upgrading to a version with schema changes, run migrations manually:

```bash
# Connect to postgres and run migration
just psql < ../../migrations/004_phase1_uc_qr.sql
```

Fresh deployments don't need this - tables are created automatically on startup.
```

**Step 2: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: add manual migration instructions to CLAUDE.md"
```

---

## Task 3: Fix Import Paths in conftest.py

**Files:**
- Modify: `tests/conftest.py`

**Step 1: Add sys.path setup at top of conftest.py**

Add after the existing imports (after line 8):
```python
import sys
from pathlib import Path

# Add src/backend to path for all tests - enables clean imports
_backend_path = Path(__file__).parent.parent / "src" / "backend"
if str(_backend_path) not in sys.path:
    sys.path.insert(0, str(_backend_path))
```

**Step 2: Run tests to verify**

```bash
just test-quick
```

Expected: All 196+ tests pass

**Step 3: Commit**

```bash
git add tests/conftest.py
git commit -m "fix(tests): add backend path to sys.path in conftest"
```

---

## Task 4: Remove Import Hacks from Modules

**Files:**
- Modify: `src/backend/qr_signing.py`
- Modify: `tests/test_config.py`
- Modify: `tests/test_qr_signing_unit.py`

**Step 1: Simplify qr_signing.py imports**

Replace lines 23-27:
```python
# Handle import for both in-Docker (config) and test (src.backend.config) contexts
try:
    from config import ORG_QR_SIGNING_SECRET, ORG_QR_DEFAULT_TTL_SEC, ORG_QR_MAX_TTL_SEC
except ImportError:
    from src.backend.config import ORG_QR_SIGNING_SECRET, ORG_QR_DEFAULT_TTL_SEC, ORG_QR_MAX_TTL_SEC
```

With:
```python
from config import ORG_QR_SIGNING_SECRET, ORG_QR_DEFAULT_TTL_SEC, ORG_QR_MAX_TTL_SEC
```

**Step 2: Remove sys.path hack from test_config.py**

Remove these lines (near top of file):
```python
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src", "backend"))
```

**Step 3: Remove sys.path hack from test_qr_signing_unit.py**

Remove these lines (near top of file):
```python
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src", "backend"))
```

**Step 4: Run tests to verify**

```bash
just test-quick
```

Expected: All tests pass

**Step 5: Commit**

```bash
git add src/backend/qr_signing.py tests/test_config.py tests/test_qr_signing_unit.py
git commit -m "fix: remove import path hacks, use conftest sys.path"
```

---

## Task 5: Fix Timestamp Race in orgdb.py

**Files:**
- Modify: `src/backend/orgdb.py:379-421`

**Step 1: Update validate_and_consume_token method**

Replace the method (lines 379-421) with:
```python
    def validate_and_consume_token(self, token_hash: str) -> tuple[bool, str, dict]:
        """Validate a provision token and mark it consumed if valid.

        Uses atomic check-and-update to prevent race conditions where the same
        token could be consumed twice under high concurrency.

        Returns: (valid, error_message, token_data)

        Error messages:
        - "TOKEN_NOT_FOUND": Token doesn't exist
        - "TOKEN_ALREADY_CONSUMED": Token was already used
        - "TOKEN_EXPIRED": Token has expired
        - "": No error, token is valid
        """
        eng = self.connect()
        now = utcnow()  # Capture once to avoid race between check and update

        # Atomic check-and-update: only update if status is active and not expired
        with eng.begin() as conn:
            result = conn.execute(
                update(provision_tokens)
                .where(
                    (provision_tokens.c.token_hash == token_hash)
                    & (provision_tokens.c.status == "active")
                    & (provision_tokens.c.expires_at > now)
                )
                .values(used_at=now, status="consumed")
            )

            if result.rowcount == 1:
                # Success - fetch updated token data
                token = self.get_provision_token(token_hash)
                return True, "", token

        # Atomic update failed - determine why
        token = self.get_provision_token(token_hash)
        if not token:
            return False, "TOKEN_NOT_FOUND", {}

        if token.get("status") != "active":
            return False, "TOKEN_ALREADY_CONSUMED", token

        # Must be expired
        return False, "TOKEN_EXPIRED", token
```

**Step 2: Run tests to verify**

```bash
just test-quick
```

Expected: All tests pass

**Step 3: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "fix(orgdb): capture timestamp once in token validation"
```

---

## Task 6: Remove Duplicate TTL Capping from main.py

**Files:**
- Modify: `src/backend/main.py:1047-1054`

**Step 1: Remove min() capping, let qr_signing handle it**

Replace lines 1047-1054:
```python
    # Calculate effective TTL (capped at max)
    effective_ttl = min(
        ttl_sec if ttl_sec is not None else ORG_QR_DEFAULT_TTL_SEC,
        ORG_QR_MAX_TTL_SEC
    )

    # Sign with v2 schema wrapper (sso_payload is None in Phase 1)
    signed_payload = sign_provisioning_payload(uc_payload, sso_payload=None, ttl_sec=effective_ttl)
```

With:
```python
    # Calculate requested TTL (qr_signing.py handles max capping)
    requested_ttl = ttl_sec if ttl_sec is not None else ORG_QR_DEFAULT_TTL_SEC

    # Sign with v2 schema wrapper (sso_payload is None in Phase 1)
    signed_payload = sign_provisioning_payload(uc_payload, sso_payload=None, ttl_sec=requested_ttl)
```

**Step 2: Run tests to verify**

```bash
just test-quick
```

Expected: All tests pass (qr_signing.py still caps TTL)

**Step 3: Commit**

```bash
git add src/backend/main.py
git commit -m "refactor: remove duplicate TTL capping from main.py"
```

---

## Task 7: Use Same Token Hash in Audit Table

**Files:**
- Modify: `src/backend/main.py:1069-1083`

**Step 1: Replace payload hash with token hash in audit**

Replace lines 1069-1083:
```python
    # Audit: record QR issuance
    try:
        _payload_hash = hashlib.sha256(json.dumps(signed_payload, sort_keys=True).encode()).hexdigest()
        _issued_by = claims.get("sub", "unknown")
        ORGDB.record_qr_issuance(
            user_uid=uid,
            org_dn=org_dn,
            issued_by=_issued_by,
            token_hash=_payload_hash,
            expires_at=exp_dt,
            client_ip=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"),
        )
    except Exception:
        pass
```

With:
```python
    # Audit: record QR issuance (use same token_hash for correlation with provision_tokens)
    try:
        _issued_by = claims.get("sub", "unknown")
        ORGDB.record_qr_issuance(
            user_uid=uid,
            org_dn=org_dn,
            issued_by=_issued_by,
            token_hash=token_hash,  # Same hash as provision_tokens for easy correlation
            expires_at=exp_dt,
            client_ip=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"),
        )
    except Exception:
        pass
```

**Step 2: Run tests to verify**

```bash
just test-quick
```

Expected: All tests pass

**Step 3: Commit**

```bash
git add src/backend/main.py
git commit -m "fix: use same token hash in audit table for correlation"
```

---

## Task 8: Remove Silent Token Recording Error

**Files:**
- Modify: `src/backend/main.py:1056-1067`

**Step 1: Remove try/except around record_provision_token**

Replace lines 1056-1067:
```python
    # Store token hash in provision_tokens table
    token_hash = hashlib.sha256(provision_token.encode()).hexdigest()
    exp_dt = datetime.fromtimestamp(signed_payload["exp"], tz=timezone.utc)
    try:
        ORGDB.record_provision_token(
            token_hash=token_hash,
            uid=uid,
            profile_id=org_dn,  # Use org_dn as profile_id for now
            expires_at=exp_dt
        )
    except Exception:
        pass  # Fire-and-forget
```

With:
```python
    # Store token hash in provision_tokens table
    # NOTE: No try/except - if DB fails, return 500 rather than broken QR
    token_hash = hashlib.sha256(provision_token.encode()).hexdigest()
    exp_dt = datetime.fromtimestamp(signed_payload["exp"], tz=timezone.utc)
    ORGDB.record_provision_token(
        token_hash=token_hash,
        uid=uid,
        profile_id=org_dn,  # Use org_dn as profile_id for now
        expires_at=exp_dt
    )
```

**Step 2: Run tests to verify**

```bash
just test-quick
```

Expected: All tests pass

**Step 3: Commit**

```bash
git add src/backend/main.py
git commit -m "fix: fail QR generation if token recording fails"
```

---

## Task 9: Add Startup Validation for UC Config

**Files:**
- Modify: `src/backend/config.py`
- Test: `tests/test_config.py`

**Step 1: Write failing test**

Add to `tests/test_config.py`:
```python
class TestUCConfigValidation:
    """Tests for UC provisioning config validation."""

    def test_uc_config_validates_on_import(self):
        """Config module should validate UC variables are set."""
        # This test verifies the validation exists
        # The actual validation happens at import time
        # If we got here with valid .env, validation passed
        import config
        assert config.UCCHAT_XMPP_DOMAIN != ""
        assert config.UCCHAT_SIP_DOMAIN != ""

    def test_uc_config_rejects_empty_xmpp_domain(self, monkeypatch):
        """Empty UCCHAT_XMPP_DOMAIN should raise RuntimeError."""
        import importlib
        monkeypatch.setenv("UCCHAT_XMPP_DOMAIN", "")
        monkeypatch.setenv("UCCHAT_XMPP_WS_URL", "wss://test")
        monkeypatch.setenv("UCCHAT_SIP_DOMAIN", "test")
        monkeypatch.setenv("UCCHAT_SIP_WSS_URL", "wss://test")

        import config
        with pytest.raises(RuntimeError, match="UCCHAT_XMPP_DOMAIN"):
            importlib.reload(config)
```

**Step 2: Run test to verify it fails**

```bash
pytest tests/test_config.py::TestUCConfigValidation -v
```

Expected: FAIL (validation not implemented yet)

**Step 3: Implement validation in config.py**

Add at end of `src/backend/config.py`:
```python
# ----------------------------
# Startup validation
# ----------------------------
def _validate_uc_config():
    """Fail fast if UC provisioning config is incomplete."""
    missing = []
    if not UCCHAT_XMPP_DOMAIN:
        missing.append("UCCHAT_XMPP_DOMAIN")
    if not UCCHAT_XMPP_WS_URL:
        missing.append("UCCHAT_XMPP_WS_URL")
    if not UCCHAT_SIP_DOMAIN:
        missing.append("UCCHAT_SIP_DOMAIN")
    if not UCCHAT_SIP_WSS_URL:
        missing.append("UCCHAT_SIP_WSS_URL")
    if missing:
        raise RuntimeError(
            f"UC provisioning requires: {', '.join(missing)}. "
            "Set these environment variables or disable QR provisioning."
        )


_validate_uc_config()
```

**Step 4: Remove LDAP_TENANT fallback**

Change line 70:
```python
UCCHAT_XMPP_DOMAIN = os.getenv("UCCHAT_XMPP_DOMAIN", LDAP_TENANT)
```

To:
```python
UCCHAT_XMPP_DOMAIN = os.getenv("UCCHAT_XMPP_DOMAIN", "")
```

**Step 5: Run tests to verify**

```bash
just test-quick
```

Expected: All tests pass

**Step 6: Commit**

```bash
git add src/backend/config.py tests/test_config.py
git commit -m "feat: add startup validation for UC config variables"
```

---

## Task 10: Add Startup Validation for Signing Secret

**Files:**
- Modify: `src/backend/config.py`
- Test: `tests/test_config.py`

**Step 1: Write failing test**

Add to `tests/test_config.py`:
```python
class TestSigningSecretValidation:
    """Tests for QR signing secret validation."""

    def test_signing_secret_rejects_default_value(self, monkeypatch):
        """Default signing secret should raise RuntimeError."""
        import importlib
        monkeypatch.setenv("ORG_QR_SIGNING_SECRET", "CHANGE_ME__ORG_QR_SIGNING_SECRET")
        # Set valid UC config to isolate this test
        monkeypatch.setenv("UCCHAT_XMPP_DOMAIN", "test")
        monkeypatch.setenv("UCCHAT_XMPP_WS_URL", "wss://test")
        monkeypatch.setenv("UCCHAT_SIP_DOMAIN", "test")
        monkeypatch.setenv("UCCHAT_SIP_WSS_URL", "wss://test")

        import config
        with pytest.raises(RuntimeError, match="default value"):
            importlib.reload(config)

    def test_signing_secret_rejects_short_value(self, monkeypatch):
        """Short signing secret should raise RuntimeError."""
        import importlib
        monkeypatch.setenv("ORG_QR_SIGNING_SECRET", "tooshort")
        monkeypatch.setenv("UCCHAT_XMPP_DOMAIN", "test")
        monkeypatch.setenv("UCCHAT_XMPP_WS_URL", "wss://test")
        monkeypatch.setenv("UCCHAT_SIP_DOMAIN", "test")
        monkeypatch.setenv("UCCHAT_SIP_WSS_URL", "wss://test")

        import config
        with pytest.raises(RuntimeError, match="at least 32"):
            importlib.reload(config)
```

**Step 2: Run test to verify it fails**

```bash
pytest tests/test_config.py::TestSigningSecretValidation -v
```

Expected: FAIL (validation not implemented yet)

**Step 3: Add signing secret validation to config.py**

Add after `_validate_uc_config()` function:
```python
def _validate_signing_secret():
    """Fail if signing secret is default or too short."""
    default = "CHANGE_ME__ORG_QR_SIGNING_SECRET"
    if ORG_QR_SIGNING_SECRET == default:
        raise RuntimeError(
            "ORG_QR_SIGNING_SECRET is set to default value. "
            "Generate a secure random secret: openssl rand -hex 32"
        )
    if len(ORG_QR_SIGNING_SECRET) < 32:
        raise RuntimeError(
            f"ORG_QR_SIGNING_SECRET must be at least 32 characters "
            f"(got {len(ORG_QR_SIGNING_SECRET)})"
        )


_validate_uc_config()
_validate_signing_secret()
```

**Step 4: Run tests to verify**

```bash
just test-quick
```

Expected: All tests pass

**Step 5: Commit**

```bash
git add src/backend/config.py tests/test_config.py
git commit -m "feat: add startup validation for signing secret"
```

---

## Task 11: Final Verification

**Step 1: Run full test suite**

```bash
just test
```

Expected: All tests pass (196+)

**Step 2: Restart stack to verify startup validation**

```bash
just down && just up
```

Expected: Stack starts successfully with valid config

**Step 3: Test QR endpoint returns valid domains**

```bash
curl -s http://localhost:8081/api/users/robert/qrcode | python3 -c "
import sys, json
d = json.load(sys.stdin)
uc = d['payload']['payload']['uc']
print(f\"XMPP domain: {uc['xmpp']['domain']}\")
print(f\"XMPP wsUrl: {uc['xmpp']['wsUrl']}\")
print(f\"SIP domain: {uc['sip']['domain']}\")
print(f\"SIP wssUrl: {uc['sip']['wssUrl']}\")
"
```

Expected: All values non-empty (xmpp.azblink.com, wss://..., etc.)

**Step 4: Verify consume returns valid config**

```bash
# Get fresh token and consume it
TOKEN=$(curl -s http://localhost:8081/api/users/robert/qrcode | python3 -c "import sys,json; print(json.load(sys.stdin)['payload']['payload']['uc']['credentials']['token'])")
curl -s -X POST http://localhost:8081/api/provision/consume \
  -H "Content-Type: application/json" \
  -d "{\"token\": \"$TOKEN\"}" | python3 -m json.tool
```

Expected: Valid config with non-empty JID and SIP URI

**Step 5: Push to remote**

```bash
git push origin main
```

---

## Verification Checklist

After all tasks complete:

- [ ] `just test-quick` passes (196+ tests)
- [ ] Fresh `just down && just up` works with updated `.env`
- [ ] QR code contains valid domains/URLs (not empty)
- [ ] `/api/provision/consume` works end-to-end
- [ ] Startup fails without required UC vars (intentional)
- [ ] Startup fails with default signing secret (intentional)
