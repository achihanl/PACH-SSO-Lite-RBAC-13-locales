# AZBlink Directory: Enterprise SaaS UI Redesign

**Date:** 2025-01-25
**Status:** Design Complete — Ready for Implementation
**Author:** Claude Code + UI/UX Pro Max

---

## 1. Executive Summary

Complete UI redesign for AZBlink Directory, transforming the current multi-page iframe-based mockups into a cohesive enterprise SaaS application inspired by GitHub and Linear design patterns.

### Key Changes

| Before | After |
|--------|-------|
| 6 separate HTML pages with iframe preview | Single app shell with sidebar navigation |
| No consistent design system | Swiss Minimalism + Data-Dense Dashboard |
| Tailwind CDN with inline styles | Design tokens + component library |
| Same UI for all users | Role-based views (End User, Org Admin, System Admin) |
| Manual `?demo=true` URL params | Automatic mode detection with clear indicators |

---

## 2. Design System

### 2.1 Color Palette

```css
:root {
  /* Primary */
  --color-primary: #0F172A;      /* slate-900 - Professional dark */
  --color-secondary: #334155;    /* slate-700 - Hierarchy */

  /* Accent */
  --color-accent: #0369A1;       /* sky-700 - Action blue */
  --color-accent-light: #0EA5E9; /* sky-500 - Hover state */

  /* Semantic */
  --color-success: #059669;      /* emerald-600 - Provisioned, connected */
  --color-warning: #D97706;      /* amber-600 - Pending, attention */
  --color-error: #DC2626;        /* red-600 - Failed, revoked */

  /* Neutral */
  --color-bg: #F8FAFC;           /* slate-50 - Page background */
  --color-surface: #FFFFFF;      /* white - Cards, panels */
  --color-border: #E2E8F0;       /* slate-200 - Dividers */
  --color-text: #020617;         /* slate-950 - Primary text */
  --color-text-muted: #64748B;   /* slate-500 - Secondary text */
}
```

### 2.2 Typography

| Role | Font | Weight | Size | Line Height |
|------|------|--------|------|-------------|
| **Headings** | Inter | 600–700 | 24–32px | 1.2 |
| **Body** | Inter | 400–500 | 14–16px | 1.5 |
| **Monospace** | Fira Code | 400 | 13–14px | 1.4 |
| **Labels** | Inter | 500 | 12px | 1.4 |

**Google Fonts Import:**
```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Fira+Code:wght@400;500&display=swap');
```

### 2.3 Spacing Scale

```css
--space-1: 4px;
--space-2: 8px;
--space-3: 12px;
--space-4: 16px;
--space-5: 20px;
--space-6: 24px;
--space-8: 32px;
--space-10: 40px;
--space-12: 48px;
--space-16: 64px;
```

### 2.4 Border Radius

```css
--radius-sm: 4px;    /* Badges, small buttons */
--radius-md: 8px;    /* Cards, inputs */
--radius-lg: 12px;   /* Modals, panels */
--radius-xl: 16px;   /* Large containers */
--radius-full: 9999px; /* Pills, avatars */
```

### 2.5 Shadows

```css
--shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
--shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
```

---

## 3. Layout Architecture

### 3.1 App Shell Structure

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TOP HEADER (h-14, fixed, z-30)                                              │
│ [Toggle] [Logo] [Title] [Search ⌘K] [Notifications] [Help] [Profile]       │
├────────────────┬────────────────────────────────────────────────────────────┤
│ SIDEBAR        │ MAIN AREA                                                  │
│ w-64 or w-16   │ ┌────────────────────────────────────────────────────────┐ │
│ fixed          │ │ BREADCRUMB BAR (h-12, sticky top-0)                    │ │
│ top-14         │ ├────────────────────────────────────────────────────────┤ │
│                │ │ CONTENT (overflow-y-auto, p-6)                         │ │
│                │ │                                                        │ │
│                │ │                                                        │ │
│                │ └────────────────────────────────────────────────────────┘ │
└────────────────┴────────────────────────────────────────────────────────────┘
```

### 3.2 Responsive Breakpoints

| Breakpoint | Width | Sidebar | Header Search | Content Offset |
|------------|-------|---------|---------------|----------------|
| **xl** | ≥1280px | Expanded (w-64) | Full input | ml-64 |
| **lg** | 1024–1279px | Collapsed (w-16) | Full input | ml-16 |
| **md** | 768–1023px | Hidden (overlay) | Icon only | ml-0 |
| **sm** | <768px | Drawer | Icon only | ml-0 |

### 3.3 Z-Index Scale

```css
--z-sidebar: 20;
--z-header: 30;
--z-dropdown: 40;
--z-modal: 50;
--z-toast: 60;
```

---

## 4. Component Specifications

### 4.1 Top Header

**Height:** 56px (h-14)
**Background:** white with bottom border
**Position:** fixed, full width, z-30

| Element | Desktop | Tablet | Mobile |
|---------|---------|--------|--------|
| Sidebar Toggle | Icon button 40×40 | Same | Same |
| Logo | Icon + "AZBlink" | Icon + text | Icon only |
| Title | Current section | Same | Hidden |
| Search | w-80 input | w-64 input | Icon → modal |
| Notifications | Icon + badge | Same | Same |
| Help | Icon | Same | Same |
| Profile | Avatar + name + caret | Avatar + caret | Avatar only |

### 4.2 Sidebar

**Width:** 256px expanded, 64px collapsed
**Background:** slate-50 with right border
**Position:** fixed, top-14 to bottom

**Navigation Items:**
- Height: 40px
- Padding: 12px horizontal
- Active state: sky-50 background, sky-700 text, left border accent
- Hover state: slate-100 background
- Icons: 20×20, Lucide icon set

**Sections:**
- Label: 12px, slate-500, uppercase, tracking-wide
- Margin: 24px top, 8px bottom

### 4.3 Breadcrumb Bar

**Height:** 48px (h-12)
**Position:** sticky top-0, z-10
**Content:** Path segments (left), Page actions (right)

```html
<div class="breadcrumb-bar">
  <nav class="breadcrumb">
    <a href="/">Home</a>
    <span class="separator">/</span>
    <a href="/users">Users</a>
    <span class="separator">/</span>
    <span class="current">Alex Thompson</span>
  </nav>
  <div class="actions">
    <button class="btn-secondary">Edit</button>
    <button class="btn-icon">⋮</button>
  </div>
</div>
```

### 4.4 Command Palette (⌘K)

**Trigger:** Click search input, or ⌘K / Ctrl+K
**Position:** Centered modal, max-width 640px
**Sections:** Recent, Actions, Navigation

**Features:**
- Fuzzy search across users, groups, orgs
- Keyboard navigation (↑↓ to select, Enter to execute)
- Action shortcuts displayed on right

### 4.5 Button Variants

| Variant | Background | Text | Border | Use Case |
|---------|------------|------|--------|----------|
| **Primary** | sky-700 | white | none | Main CTA |
| **Secondary** | white | slate-700 | slate-200 | Secondary actions |
| **Ghost** | transparent | slate-600 | none | Tertiary actions |
| **Danger** | red-600 | white | none | Destructive actions |

**Sizes:**
- sm: h-8, px-3, text-sm
- md: h-10, px-4, text-sm (default)
- lg: h-12, px-6, text-base

### 4.6 Card Variants

**Stat Card:**
```html
<div class="stat-card">
  <div class="stat-value">247</div>
  <div class="stat-label">Users</div>
  <div class="stat-change positive">+3 today</div>
</div>
```

**Content Card:**
```html
<div class="content-card">
  <div class="card-header">
    <h3>Section Title</h3>
    <button class="btn-ghost">Action</button>
  </div>
  <div class="card-body">
    <!-- Content -->
  </div>
</div>
```

**User Card:**
```html
<div class="user-card">
  <div class="avatar">AT</div>
  <div class="user-info">
    <div class="user-name">Alex Thompson</div>
    <div class="user-email">alex@safenest.org</div>
  </div>
  <div class="user-meta">SafeNest Inc</div>
</div>
```

### 4.7 Status Badges

| Status | Background | Text | Dot Color |
|--------|------------|------|-----------|
| **Active/Success** | emerald-50 | emerald-700 | emerald-500 |
| **Pending/Warning** | amber-50 | amber-700 | amber-500 |
| **Error/Revoked** | red-50 | red-700 | red-500 |
| **Inactive/N/A** | slate-100 | slate-500 | slate-400 |

---

## 5. Page Designs

### 5.1 Dashboard

**Purpose:** System overview, quick actions, recent activity
**URL:** `/` or `/dashboard`

**Layout:**
```
┌─────────────────────────────────────────────────────────────┐
│ Stats Row (4 cards): Users, Groups, Orgs, Pending QR Scans  │
├─────────────────────────────────┬───────────────────────────┤
│ Quick Actions                   │ System Health             │
│ - New User                      │ - LDAP: Connected         │
│ - Generate QR                   │ - PostgreSQL: OK          │
│ - Bulk Import                   │ - Authentik: N/A          │
├─────────────────────────────────┴───────────────────────────┤
│ Recent Activity (table)                                     │
│ - Timestamp, Event, User, Status                            │
└─────────────────────────────────────────────────────────────┘
```

### 5.2 Users List

**Purpose:** Browse, search, filter users
**URL:** `/directory/users`

**Features:**
- Search input with filters (org, status, group)
- Sortable table columns
- Bulk selection for actions
- Pagination or infinite scroll
- Click row → User Detail

**Table Columns:**
| Column | Width | Sortable |
|--------|-------|----------|
| Checkbox | 40px | No |
| User (avatar + name + email) | flex | Yes (name) |
| Organization | 160px | Yes |
| Status | 100px | Yes |
| QR#1 | 80px | No |
| QR#2 | 80px | No |
| Actions | 80px | No |

### 5.3 User Detail

**Purpose:** View/edit user, manage provisioning
**URL:** `/directory/users/:uid`

**Sections:**
1. **Header:** Avatar, name, email, org, status badges
2. **Profile:** LDAP attributes (DN, phone, department, created)
3. **Provisioning:** Last QR scan, device, UC status, actions
4. **Groups:** List with add/remove

### 5.4 QR Generator

**Purpose:** Generate QR#1/QR#2 for provisioning
**URL:** `/provisioning/qr-generator`

**Flow:**
1. **Step 1:** Select user (search/dropdown)
2. **Step 2:** Display QR codes side-by-side
   - QR#1 always shown (UC Core)
   - QR#2 shown if SSO enabled, otherwise disabled state
3. **Actions:** Copy link, download PNG, email to user
4. **Instructions:** Collapsible panel with scan steps

### 5.5 Tokens Audit

**Purpose:** View and revoke provisioning tokens
**URL:** `/provisioning/tokens`

**Table Columns:**
| Column | Description |
|--------|-------------|
| Token ID | Truncated hash |
| User | Name + email |
| Type | QR#1 or QR#2 |
| Created | Timestamp |
| Expires | Timestamp + countdown |
| Status | Active/Used/Revoked/Expired |
| Actions | Revoke button |

### 5.6 Settings

**Purpose:** System configuration
**URL:** `/settings`

**Sections:**
- API Configuration (base URL, timeouts)
- Authentication Mode (REQUIRE_OIDC_AUTH toggle)
- Break-glass Configuration
- LDAP Connection Status

---

## 6. Mobile Considerations

### 6.1 Touch Targets

All interactive elements minimum 44×44px tap area.

### 6.2 Navigation

- Hamburger menu triggers sidebar drawer
- Drawer has backdrop overlay (click to close)
- Swipe right from edge to open drawer

### 6.3 Tables → Cards

On mobile (<768px), data tables transform to card lists:

```html
<!-- Desktop: Table row -->
<tr>
  <td>Alex Thompson</td>
  <td>alex@safenest.org</td>
  <td>SafeNest Inc</td>
  <td><span class="badge success">Active</span></td>
</tr>

<!-- Mobile: Card -->
<div class="user-card-mobile">
  <div class="card-header">
    <div class="avatar">AT</div>
    <div class="name">Alex Thompson</div>
    <span class="badge success">Active</span>
  </div>
  <div class="card-body">
    <div>alex@safenest.org</div>
    <div class="muted">SafeNest Inc</div>
  </div>
</div>
```

### 6.4 QR Display

QR codes displayed full-width on mobile with large tap targets for copy/download actions.

---

## 7. Accessibility Checklist

- [ ] Color contrast ratio ≥ 4.5:1 for all text
- [ ] Focus states visible on all interactive elements
- [ ] Skip link to main content
- [ ] ARIA labels on icon-only buttons
- [ ] Form inputs have associated labels
- [ ] Heading hierarchy (h1 → h2 → h3)
- [ ] `prefers-reduced-motion` respected for animations
- [ ] Keyboard navigation for all functionality

---

## 8. File Structure

```
src/ui/
├── index.html              # App shell + router
├── styles/
│   ├── tokens.css          # Design tokens (CSS custom properties)
│   ├── base.css            # Reset, typography, utilities
│   └── components.css      # Component styles
├── components/
│   ├── header.html         # Top header partial
│   ├── sidebar.html        # Sidebar navigation partial
│   ├── breadcrumb.html     # Breadcrumb bar partial
│   └── command-palette.html # Search modal
├── pages/
│   ├── dashboard.html
│   ├── users-list.html
│   ├── user-detail.html
│   ├── groups-list.html
│   ├── orgs-tree.html
│   ├── qr-generator.html
│   ├── tokens-audit.html
│   ├── my-profile.html     # End-user self-service
│   └── settings.html
└── js/
    ├── app.js              # Router, state management
    ├── api.js              # API client
    ├── components.js       # Dynamic component logic
    └── command-palette.js  # Search functionality
```

---

## 9. Implementation Phases

### Phase 1: Foundation (2–3 days)
- [ ] Design tokens CSS file
- [ ] App shell (header, sidebar, content area)
- [ ] Responsive layout with sidebar toggle
- [ ] Basic routing (hash-based or history API)

### Phase 2: Core Pages (3–4 days)
- [ ] Dashboard with stats and activity
- [ ] Users list with search/filter
- [ ] User detail page
- [ ] QR Generator flow

### Phase 3: Polish (2–3 days)
- [ ] Command palette (⌘K)
- [ ] Mobile responsive refinements
- [ ] Tokens audit page
- [ ] Settings page
- [ ] Toast notifications

### Phase 4: Integration (1–2 days)
- [ ] Connect to live API
- [ ] Error handling and loading states
- [ ] Demo mode fallback

---

## 10. References

- **Phase 1 PRD:** `docs/prd/PHASE1_UC_CORE_QR_PRD.md`
- **Phase 1 Report:** `docs/reports/PHASE1_UC_CORE_QR_REPORT.md`
- **Current UI:** `src/ui/` (to be replaced)
- **Demo flows:** `demo/qr-flow/` (design inspiration for ucChat)

---

## Appendix: Tailwind Config

```javascript
// tailwind.config.js
module.exports = {
  content: ['./src/ui/**/*.html', './src/ui/**/*.js'],
  theme: {
    extend: {
      colors: {
        primary: '#0F172A',
        accent: '#0369A1',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['Fira Code', 'monospace'],
      },
      spacing: {
        '14': '3.5rem',
        '18': '4.5rem',
      },
    },
  },
  plugins: [],
}
```
