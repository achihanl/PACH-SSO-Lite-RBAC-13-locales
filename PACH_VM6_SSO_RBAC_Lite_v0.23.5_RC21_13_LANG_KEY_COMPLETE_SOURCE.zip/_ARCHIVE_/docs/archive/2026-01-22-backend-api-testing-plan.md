# Backend API Testing Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Create integration test suite for `src/backend/` API with focus on security-critical paths.

**Architecture:** pytest + httpx tests run outside Docker, hitting the real API stack. Tests use seed data and clean up after themselves. Fixtures manage DB/LDAP/Redis connections for setup/cleanup only.

**Tech Stack:** pytest, httpx, psycopg2-binary, python-ldap, redis

---

## Task 1: Create Test Infrastructure

**Files:**
- Create: `tests/requirements.txt`
- Create: `tests/conftest.py`
- Modify: `Justfile` (add test commands)

**Step 1: Create test dependencies file**

Create `tests/requirements.txt`:
```
pytest>=8.0
httpx>=0.27
psycopg2-binary>=2.9
python-ldap>=3.4
redis>=5.0
pytest-cov>=4.0
```

**Step 2: Create conftest.py with core fixtures**

Create `tests/conftest.py`:
```python
"""Shared fixtures for integration tests."""

import os
import pytest
import httpx
import psycopg2
import ldap
import redis as redis_lib

# Seed data constants (from deploy/dev seed)
SEED_USER_UID = "jsmith"
LDAP_BASE_DN = "dc=azblink,dc=com"
LDAP_ADMIN_DN = "cn=admin,dc=azblink,dc=com"
LDAP_ADMIN_PW = "adminpassword"


@pytest.fixture(scope="session")
def api_base_url():
    """Base URL for the running API."""
    return os.getenv("API_URL", "http://localhost:8081")


@pytest.fixture
def client(api_base_url):
    """HTTP client for API calls."""
    with httpx.Client(base_url=api_base_url, timeout=30) as c:
        yield c


@pytest.fixture(scope="session")
def db_conn():
    """Direct Postgres connection for setup/cleanup."""
    conn = psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "localhost"),
        port=int(os.getenv("POSTGRES_PORT", "5433")),
        database="azblink_directory",
        user="azblink_directory",
        password="azblink_directory",
    )
    conn.autocommit = True
    yield conn
    conn.close()


@pytest.fixture(scope="session")
def ldap_conn():
    """Direct LDAP connection for setup/cleanup."""
    host = os.getenv("LDAP_HOST", "localhost")
    port = os.getenv("LDAP_PORT", "1390")
    conn = ldap.initialize(f"ldap://{host}:{port}")
    conn.simple_bind_s(LDAP_ADMIN_DN, LDAP_ADMIN_PW)
    yield conn
    conn.unbind_s()


@pytest.fixture(scope="session")
def redis_conn():
    """Redis connection for rate limit management."""
    host = os.getenv("REDIS_HOST", "localhost")
    port = int(os.getenv("REDIS_PORT", "6380"))
    r = redis_lib.Redis(host=host, port=port, db=0)
    yield r
    r.close()


@pytest.fixture
def seed_user_uid():
    """UID of a user that exists in seed data."""
    return SEED_USER_UID


@pytest.fixture
def created_users(db_conn, ldap_conn):
    """Track and cleanup users created during tests."""
    created = []
    yield created

    # Teardown: clean up in reverse order
    for uid in reversed(created):
        # Delete from LDAP
        try:
            ldap_conn.delete_s(f"uid={uid},ou=people,{LDAP_BASE_DN}")
        except ldap.NO_SUCH_OBJECT:
            pass
        # Delete from DB
        with db_conn.cursor() as cur:
            cur.execute("DELETE FROM provision_tokens WHERE uid = %s", (uid,))
            cur.execute("DELETE FROM qr_issuance_audit WHERE user_uid = %s", (uid,))
            cur.execute("DELETE FROM termination_events WHERE user_uid = %s", (uid,))


@pytest.fixture(autouse=True)
def clear_rate_limits(redis_conn):
    """Clear rate limit counters after each test."""
    yield
    redis_conn.flushdb()
```

**Step 3: Add test commands to Justfile**

Add to `Justfile`:
```makefile
# Run tests (ensures stack is up)
test:
    #!/usr/bin/env bash
    cd deploy/dev
    if ! docker compose ps --status running | grep -q "azblink-directory-api"; then
        echo "Starting stack..."
        docker compose up -d --wait
    fi
    cd ../..
    pip install -q -r tests/requirements.txt
    pytest tests/ -v --tb=short

# Fast test run (assumes stack is already up)
test-quick:
    pytest tests/ -v --tb=short

# Run specific test file
test-security:
    pytest tests/test_security.py -v

test-provisioning:
    pytest tests/test_provisioning.py -v

# Run with coverage
test-cov:
    pytest tests/ -v --cov=src/backend --cov-report=term-missing
```

**Step 4: Verify fixtures load without error**

Run: `pytest tests/conftest.py --collect-only`
Expected: No import errors, fixtures collected

**Step 5: Commit**

```bash
git add tests/requirements.txt tests/conftest.py Justfile
git commit -m "feat(tests): add test infrastructure with core fixtures"
```

---

## Task 2: Create Health Check Tests

**Files:**
- Create: `tests/test_health.py`

**Step 1: Create health check tests**

Create `tests/test_health.py`:
```python
"""Health endpoint tests."""

import pytest


class TestHealthEndpoints:
    """Health check endpoints for load balancers."""

    def test_liveness_check(self, client):
        """Basic liveness probe returns 200."""
        resp = client.get("/api/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True

    def test_deep_health_check_returns_checks(self, client):
        """Deep health check includes dependency status."""
        resp = client.get("/api/health/deep")
        # 200 when healthy, 503 when degraded
        assert resp.status_code in (200, 503)
        data = resp.json()
        assert "checks" in data
        assert "postgres" in data["checks"]
        assert "redis" in data["checks"]
        assert "ldap" in data["checks"]

    def test_deep_health_check_healthy_when_all_up(self, client):
        """Deep health returns ok=True when all deps healthy."""
        resp = client.get("/api/health/deep")
        # Stack should be healthy if tests are running
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["status"] == "healthy"
```

**Step 2: Run tests to verify they pass**

Run: `just test-quick`
Expected: 3 tests pass (health endpoints should work)

**Step 3: Commit**

```bash
git add tests/test_health.py
git commit -m "test(health): add health endpoint tests"
```

---

## Task 3: Create Rate Limiting Tests

**Files:**
- Create: `tests/test_security.py`

**Step 1: Create rate limiting tests**

Create `tests/test_security.py`:
```python
"""Security tests: rate limiting, termination, auth."""

import pytest


class TestRateLimiting:
    """Spec Section 0.3: Rate limiting requirements."""

    def test_bootstrap_rate_limit_5_per_hour(self, client):
        """Bootstrap endpoint limited to 5/hour."""
        # Make 5 requests (should all be allowed)
        for i in range(5):
            resp = client.post("/api/bootstrap", json={
                "tenant": f"ratelimit_test_{i}",
                "admin_email": f"admin{i}@test.com"
            })
            # May succeed or fail validation, but not rate limited
            assert resp.status_code != 429, f"Request {i+1} was rate limited unexpectedly"

        # 6th request should be rate limited
        resp = client.post("/api/bootstrap", json={
            "tenant": "ratelimit_test_6",
            "admin_email": "admin6@test.com"
        })
        assert resp.status_code == 429
        data = resp.json()
        assert data["error"] == "rate_limit_exceeded"

    def test_default_rate_limit_100_per_minute(self, client):
        """Default endpoints limited to 100/minute."""
        # Health endpoint uses default limit
        for i in range(100):
            resp = client.get("/api/health")
            assert resp.status_code == 200, f"Request {i+1} failed unexpectedly"

        # 101st request should be rate limited
        resp = client.get("/api/health")
        assert resp.status_code == 429

    def test_rate_limit_response_format(self, client):
        """Rate limit response has correct format."""
        # Exhaust bootstrap limit
        for _ in range(5):
            client.post("/api/bootstrap", json={"tenant": "t", "admin_email": "a@b.com"})

        resp = client.post("/api/bootstrap", json={"tenant": "t", "admin_email": "a@b.com"})
        assert resp.status_code == 429
        data = resp.json()
        assert data["ok"] is False
        assert data["error"] == "rate_limit_exceeded"
        assert "detail" in data
        assert "Retry-After" in resp.headers
```

**Step 2: Run tests**

Run: `pytest tests/test_security.py -v`
Expected: All rate limiting tests pass

**Step 3: Commit**

```bash
git add tests/test_security.py
git commit -m "test(security): add rate limiting tests"
```

---

## Task 4: Add User Termination Tests

**Files:**
- Modify: `tests/test_security.py`

**Step 1: Add helper function for creating test users**

Add to `tests/conftest.py`:
```python
def create_test_user(client, uid, created_users):
    """Helper to create a test user and track for cleanup."""
    resp = client.post("/api/users/create", json={
        "uid": uid,
        "cn": f"Test User {uid}",
        "sn": "Test",
        "mail": f"{uid}@test.com",
        "userPassword": "testpass123",
        "org_dn": f"ou=org,{LDAP_BASE_DN}"
    })
    if resp.status_code == 200:
        created_users.append(uid)
    return resp
```

**Step 2: Add termination tests to test_security.py**

Append to `tests/test_security.py`:
```python
import ldap as ldap_lib
from conftest import create_test_user, LDAP_BASE_DN


class TestUserTermination:
    """User termination flow tests."""

    def test_terminate_disables_ldap_account(self, client, created_users):
        """Termination must disable LDAP account."""
        uid = "terminate_test_1"
        password = "testpass123"

        # Create test user
        resp = create_test_user(client, uid, created_users)
        assert resp.status_code == 200

        # Verify LDAP bind works before termination
        test_conn = ldap_lib.initialize("ldap://localhost:1390")
        test_conn.simple_bind_s(f"uid={uid},ou=people,{LDAP_BASE_DN}", password)
        test_conn.unbind_s()

        # Terminate
        resp = client.post(f"/api/users/{uid}/terminate", json={
            "terminated_by": "admin@test.com",
            "reason": "test_termination"
        })
        assert resp.status_code == 200

        # Verify LDAP bind fails (account disabled)
        test_conn = ldap_lib.initialize("ldap://localhost:1390")
        with pytest.raises(ldap_lib.INVALID_CREDENTIALS):
            test_conn.simple_bind_s(f"uid={uid},ou=people,{LDAP_BASE_DN}", password)

    def test_terminate_revokes_active_tokens(self, client, db_conn, created_users):
        """Termination must revoke all active provision tokens."""
        uid = "terminate_test_2"

        # Create test user
        resp = create_test_user(client, uid, created_users)
        assert resp.status_code == 200

        # Generate QR (creates token)
        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200

        # Verify token exists and is active
        with db_conn.cursor() as cur:
            cur.execute("SELECT status FROM provision_tokens WHERE uid = %s", (uid,))
            row = cur.fetchone()
            assert row is not None
            assert row[0] == "active"

        # Terminate
        resp = client.post(f"/api/users/{uid}/terminate", json={
            "terminated_by": "admin@test.com",
            "reason": "test_termination"
        })
        assert resp.status_code == 200

        # Verify token is revoked
        with db_conn.cursor() as cur:
            cur.execute("SELECT status FROM provision_tokens WHERE uid = %s", (uid,))
            row = cur.fetchone()
            assert row[0] == "revoked_terminated"

    def test_terminate_records_audit_event(self, client, db_conn, created_users):
        """Termination must create audit record."""
        uid = "terminate_test_3"

        resp = create_test_user(client, uid, created_users)
        assert resp.status_code == 200

        # Terminate
        resp = client.post(f"/api/users/{uid}/terminate", json={
            "terminated_by": "admin@test.com",
            "reason": "policy_violation"
        })
        assert resp.status_code == 200

        # Verify audit record
        with db_conn.cursor() as cur:
            cur.execute(
                "SELECT terminated_by, reason FROM termination_events WHERE user_uid = %s",
                (uid,)
            )
            row = cur.fetchone()
            assert row is not None
            assert row[0] == "admin@test.com"
            assert row[1] == "policy_violation"

    def test_terminate_nonexistent_user_returns_404(self, client):
        """Terminating nonexistent user returns 404."""
        resp = client.post("/api/users/nonexistent_user_xyz/terminate", json={
            "terminated_by": "admin@test.com",
            "reason": "test"
        })
        assert resp.status_code == 404
```

**Step 3: Run termination tests**

Run: `pytest tests/test_security.py::TestUserTermination -v`
Expected: All termination tests pass

**Step 4: Commit**

```bash
git add tests/conftest.py tests/test_security.py
git commit -m "test(security): add user termination tests"
```

---

## Task 5: Create Provisioning Token Tests

**Files:**
- Create: `tests/test_provisioning.py`

**Step 1: Create provisioning token tests**

Create `tests/test_provisioning.py`:
```python
"""QR provisioning and token validation tests."""

import hashlib
import pytest
from conftest import create_test_user, LDAP_BASE_DN


class TestTokenValidation:
    """QR provisioning token validation."""

    def test_token_single_use_atomic(self, client, created_users):
        """Token can only be consumed once (atomic operation)."""
        uid = "provision_test_1"

        resp = create_test_user(client, uid, created_users)
        assert resp.status_code == 200

        # Get QR data with token
        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200
        qr_data = resp.json()

        # Token may be in different field names
        token = qr_data.get("provisionToken") or qr_data.get("provision_token")
        assert token is not None, f"No token in response: {qr_data}"

        # First consumption succeeds
        resp = client.post("/api/provision/validate", json={"token": token})
        assert resp.status_code == 200

        # Second consumption fails
        resp = client.post("/api/provision/validate", json={"token": token})
        assert resp.status_code == 400
        error = resp.json().get("error", "") or resp.json().get("detail", "")
        assert "ALREADY_CONSUMED" in error or "consumed" in error.lower()

    def test_expired_token_rejected(self, client, db_conn, created_users):
        """Expired tokens are rejected."""
        uid = "provision_test_2"

        resp = create_test_user(client, uid, created_users)
        assert resp.status_code == 200

        # Get QR data
        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200
        qr_data = resp.json()
        token = qr_data.get("provisionToken") or qr_data.get("provision_token")

        # Manually expire the token in DB
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with db_conn.cursor() as cur:
            cur.execute(
                "UPDATE provision_tokens SET expires_at = NOW() - INTERVAL '1 hour' WHERE token_hash = %s",
                (token_hash,)
            )

        # Attempt validation - should fail
        resp = client.post("/api/provision/validate", json={"token": token})
        assert resp.status_code == 400
        error = resp.json().get("error", "") or resp.json().get("detail", "")
        assert "EXPIRED" in error or "expired" in error.lower()

    def test_invalid_token_rejected(self, client):
        """Invalid tokens are rejected."""
        resp = client.post("/api/provision/validate", json={
            "token": "invalid_token_that_does_not_exist_12345"
        })
        assert resp.status_code == 400
        error = resp.json().get("error", "") or resp.json().get("detail", "")
        assert "NOT_FOUND" in error or "not found" in error.lower() or "invalid" in error.lower()

    def test_qr_generation_creates_token(self, client, db_conn, created_users):
        """QR generation creates a provision token in DB."""
        uid = "provision_test_3"

        resp = create_test_user(client, uid, created_users)
        assert resp.status_code == 200

        # No token should exist yet
        with db_conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM provision_tokens WHERE uid = %s", (uid,))
            assert cur.fetchone()[0] == 0

        # Generate QR
        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200

        # Token should now exist
        with db_conn.cursor() as cur:
            cur.execute("SELECT status FROM provision_tokens WHERE uid = %s", (uid,))
            row = cur.fetchone()
            assert row is not None
            assert row[0] == "active"


class TestQRCodeGeneration:
    """QR code generation tests."""

    def test_qrcode_rate_limit_10_per_minute(self, client, seed_user_uid):
        """QR endpoints limited to 10/minute per spec."""
        for i in range(10):
            resp = client.get(f"/api/users/{seed_user_uid}/qrcode")
            # May be 200 or 404 depending on user state
            assert resp.status_code != 429, f"Request {i+1} was rate limited"

        # 11th should be rate limited
        resp = client.get(f"/api/users/{seed_user_uid}/qrcode")
        assert resp.status_code == 429

    def test_qrcode_for_nonexistent_user_returns_404(self, client):
        """QR for nonexistent user returns 404."""
        resp = client.get("/api/users/nonexistent_user_xyz/qrcode")
        assert resp.status_code == 404
```

**Step 2: Run provisioning tests**

Run: `pytest tests/test_provisioning.py -v`
Expected: All provisioning tests pass

**Step 3: Commit**

```bash
git add tests/test_provisioning.py
git commit -m "test(provisioning): add token validation and QR tests"
```

---

## Task 6: Run Full Test Suite and Fix Issues

**Files:**
- Potentially modify: `tests/*.py` (if fixes needed)

**Step 1: Run full test suite**

Run: `just test`
Expected: All tests pass

**Step 2: If any tests fail, debug and fix**

Common issues:
- Seed user UID doesn't exist: Check `deploy/dev/Dockerfile.seed`
- Connection refused: Ensure stack is running with `just up`
- Rate limit tests interfering: Check `autouse` fixture clears Redis

**Step 3: Commit any fixes**

```bash
git add tests/
git commit -m "fix(tests): address test failures"
```

---

## Task 7: Add Test Documentation to CLAUDE.md

**Files:**
- Modify: `CLAUDE.md`

**Step 1: Add testing section to CLAUDE.md**

Add after "Development Commands" section:
```markdown
## Testing

```bash
just test          # Run all tests (starts stack if needed)
just test-quick    # Run tests (assumes stack is up)
just test-security # Run security tests only
just test-cov      # Run with coverage report
```

**Test structure:**
- `tests/conftest.py` - Shared fixtures
- `tests/test_health.py` - Health endpoints
- `tests/test_security.py` - Rate limits, termination
- `tests/test_provisioning.py` - QR tokens

Tests run against the real Docker stack (no mocks).
```

**Step 2: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: add testing section to CLAUDE.md"
```

---

## Summary

| Task | Description | Files |
|------|-------------|-------|
| 1 | Test infrastructure | `tests/requirements.txt`, `tests/conftest.py`, `Justfile` |
| 2 | Health check tests | `tests/test_health.py` |
| 3 | Rate limiting tests | `tests/test_security.py` |
| 4 | User termination tests | `tests/test_security.py`, `tests/conftest.py` |
| 5 | Provisioning token tests | `tests/test_provisioning.py` |
| 6 | Full suite validation | Fix any issues |
| 7 | Documentation | `CLAUDE.md` |
