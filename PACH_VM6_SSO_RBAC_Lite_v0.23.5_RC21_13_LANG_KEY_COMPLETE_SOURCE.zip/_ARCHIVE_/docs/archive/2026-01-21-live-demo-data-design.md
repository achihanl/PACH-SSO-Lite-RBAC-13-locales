# Live Demo Data Enhancement Design

**Date:** 2026-01-21
**Status:** Ready for Implementation

## Goal

Transform the Azblink Directory demo from static HTML mockups to a live, data-driven directory with 58 realistic users seeded into LDAP and PostgreSQL.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Dev Environment                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐     ┌─────────────┐     ┌──────────────┐  │
│  │   UI        │────▶│   API       │────▶│   OpenLDAP   │  │
│  │  :8001      │     │  :8000      │     │   :1390      │  │
│  │             │     │             │     │              │  │
│  │ - No mock   │     │ - Bug fixed │     │ - 58 users   │  │
│  │ - Live only │     │ - Full CRUD │     │ - 25+ OUs    │  │
│  └─────────────┘     └──────┬──────┘     │ - 8+ groups  │  │
│                             │            └──────────────┘  │
│  ┌─────────────┐            │                              │
│  │  Avatars    │            ▼            ┌──────────────┐  │
│  │  /avatars/  │     ┌─────────────┐     │  PostgreSQL  │  │
│  │  (cached)   │     │  Seed Script│     │   :5433      │  │
│  └─────────────┘     │  (one-time) │     │              │  │
│                      └─────────────┘     │ - OrgProfiles│  │
│                                          └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## Components

### 1. API Bug Fix

**Problem:** `ldap_client.py` uses `attributes=["dn"]` which is invalid - `dn` is not a requestable LDAP attribute.

**Fix:** Replace with `attributes=["objectClass"]` at lines 41 and 49.

**File:** `src/backend/ldap_client.py`

### 2. Seed Script

**Purpose:** Populate LDAP with 58 users, 25+ OUs, and groups on first startup.

**Behavior:**
- Check if >10 users exist (idempotent skip)
- Create organizational units (hierarchy)
- Create users with full profile attributes
- Download avatars from ui-avatars.com and cache locally
- Create/update group memberships
- Exit with code 0

**Files:**
- `deploy/dev/seed/seed_demo_data.py` - Main seed script
- `deploy/dev/Dockerfile.seed` - Container image

### 3. Docker Compose Integration

Add seed service that runs once after LDAP is healthy:

```yaml
seed:
  build:
    context: ../..
    dockerfile: deploy/dev/Dockerfile.seed
  container_name: azblink-seed
  networks:
    - azblink-net
  depends_on:
    openldap:
      condition: service_healthy
    postgres:
      condition: service_healthy
  environment:
    LDAP_URI: ldap://openldap:389
    LDAP_BIND_DN: cn=admin,dc=azblink,dc=com
    LDAP_BIND_PW: adminpassword
    AVATAR_OUTPUT_DIR: /avatars
  volumes:
    - avatar_cache:/avatars
  restart: "no"

directory-ui:
  # ... existing config ...
  volumes:
    - avatar_cache:/app/avatars:ro  # Mount cached avatars

volumes:
  avatar_cache:  # New shared volume
```

### 4. UI Changes

Remove all static mock data arrays and fetch exclusively from API.

**Files to modify:**
- `src/ui/directory_fixed.html`
- `src/ui/directory_mobile_fixed.html`
- `src/ui/directory_manager_fixed.html`
- `src/ui/directory_manager_org_setup_fixed.html`
- `src/ui/directory_provision_manager_fixed.html`
- `src/ui/my_profile.html`

**Pattern:**
```javascript
// Remove: DEMO_ORG_NODES, DEMO_PEOPLE, DEMO_GROUPS, DEMO_PROFILES, etc.

// DataSource becomes API-only:
const DataSource = {
  async getOrgTree() {
    const res = await apiFetch('/api/org/tree');
    if (!res.ok) throw new Error(res.detail || 'Failed to load');
    return res.tree;
  },
  // ...
};

// Error handling:
async function init() {
  try {
    const tree = await DataSource.getOrgTree();
    renderTree(tree);
  } catch (err) {
    showError(`Unable to load: ${err.message}`);
  }
}

// Avatar URLs:
const avatarUrl = `/avatars/${uid}.png`;  // Local cached
```

## Data Model

### LDAP User Attributes (inetOrgPerson)

| Attribute | Field | Example |
|-----------|-------|---------|
| uid | `uid` | `jsmith` |
| Full Name | `cn`, `displayName` | `John Smith` |
| First/Last | `givenName`, `sn` | `John` / `Smith` |
| Title | `title` | `Senior Engineer` |
| Email | `mail` | `john.smith@azblink.com` |
| Phone | `telephoneNumber` | `8801` |
| Mobile | `mobile` | `+886-912-345-678` |
| Location | `l` | `Taipei, TW` |
| Department | `ou` | `Engineering` |
| Manager | `manager` | `uid=rlin,ou=people,...` |
| Employee ID | `employeeNumber` | `AZB-0042` |
| Dept Code | `departmentNumber` | `ENG-001` |
| Office/Desk | `physicalDeliveryOfficeName` | `HQ-12F-A03` |
| Photo URL | `labeledURI` | `photo:/avatars/jsmith.png` |
| Hire Date | `description` | `Hired: 2023-06-15` |
| Password | `userPassword` | `demo123` |

**UC Authentication:** XMPP/SIP servers bind against LDAP using `uid` + `userPassword`. Server domains come from environment config.

### Organization Structure (58 users)

```
GlobalHQ
├── Executive (2)
│   ├── CEO - David Chang
│   └── Chief of Staff - Emily Wu
│
├── Engineering (18)
│   ├── CTO - Robert Lin ★
│   ├── Platform (8)
│   │   ├── Security (3) - Alex Chen ★, +2
│   │   └── EdgeSystems (3) - Sarah Kim ★, +2
│   ├── ProductEngineering (5) - James Miller ★, +4
│   └── QA (3)
│
├── Sales (10)
│   ├── CSO - Michael Torres
│   ├── Enterprise (4)
│   ├── SMB (3)
│   └── Solutions (2)
│
├── Marketing (6)
│   ├── CMO - Jennifer Park
│   ├── Brand (2) - Mei Wang ★, +1
│   └── DemandGen (2) - Kevin Huang ★, +1
│
├── Operations (6)
│   ├── COO - Richard Lee
│   ├── IT (3)
│   ├── Facilities (1)
│   └── Procurement (1)
│
├── Finance (4)
│   ├── CFO - Susan Chen
│   ├── Accounting (2)
│   └── FP&A (1)
│
├── HR (4)
│   ├── CHRO - Amanda Liu
│   ├── Recruiting (2)
│   └── PeopleOps (1)
│
├── Legal (3)
│   ├── GC - William Zhang
│   ├── Corporate - Laura Chen ★
│   └── Compliance (1)
│
└── CustomerSuccess (5)
    ├── VP CS - Nicole Wang
    ├── CSM (2)
    └── Support (2)

★ = 7 existing users to preserve
```

### Groups

**Department groups:**
- `cn=Engineering`, `cn=Sales`, `cn=Marketing`, `cn=Operations`
- `cn=Finance`, `cn=HR`, `cn=Legal`, `cn=CustomerSuccess`, `cn=Executive`

**Role groups:**
- `cn=IT-Admins` (existing)
- `cn=All-Staff` (existing, update)
- `cn=Managers` (existing, update)
- `cn=C-Suite` (new)
- `cn=Directors` (new)

### Avatars

- Source: `https://ui-avatars.com/api/?name={name}&size=256&background=random`
- Cached to: `/avatars/{uid}.png`
- Served by UI container at: `http://localhost:8001/avatars/{uid}.png`

## Files Summary

### Create

| File | Purpose |
|------|---------|
| `deploy/dev/seed/seed_demo_data.py` | Main seed script with all user/org data |
| `deploy/dev/Dockerfile.seed` | Container for seed script |

### Modify

| File | Changes |
|------|---------|
| `src/backend/ldap_client.py` | Fix `attributes=["dn"]` bug |
| `deploy/dev/docker-compose.yml` | Add seed service, avatar_cache volume |
| `src/ui/directory_fixed.html` | Remove DEMO_* arrays, API-only |
| `src/ui/directory_mobile_fixed.html` | Remove DEMO_* arrays, API-only |
| `src/ui/directory_manager_fixed.html` | Remove DEMO_* arrays, API-only |
| `src/ui/directory_manager_org_setup_fixed.html` | Remove DEMO_* arrays, API-only |
| `src/ui/directory_provision_manager_fixed.html` | Remove DEMO_* arrays, API-only |
| `src/ui/my_profile.html` | Remove mock user, API-only |

## Implementation Order

1. **Fix API bug** - Unblocks all API calls
2. **Create seed script** - Define all 58 users and org structure
3. **Update docker-compose** - Add seed service and volume
4. **Update UI files** - Remove mock data, use live API
5. **Test end-to-end** - Verify full flow works

## Success Criteria

- [ ] `docker compose up` seeds 58 users automatically on first run
- [ ] Subsequent `docker compose up` skips seeding (idempotent)
- [ ] All UI pages load data from live API
- [ ] Avatars display correctly from local cache
- [ ] Org tree navigation works with real LDAP data
- [ ] User search returns live results
- [ ] No `DEMO_*` arrays remain in UI code
