# API Shape Fixes: Spec Alignment Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Fix the 5 wrong-shaped endpoints + 1 missing endpoint + 1 schema fix so the API matches the spec (§10.2-10.6) exactly. Update all tests that reference the old shapes.

**Architecture:** Each endpoint fix is a route signature change (method + path), keeping existing LDAP/DB logic. Tests must update their HTTP calls. Old Pydantic request models may be simplified or removed when path params replace body fields.

**Tech Stack:** FastAPI, Pydantic, ldap3, SQLAlchemy Core, pytest + httpx

---

## Context for Implementer

**Current wrong shapes (code → spec):**
1. `POST /api/org/delete` with `OrgDeleteReq(dn)` → `DELETE /api/org/{dn:path}`
2. `POST /api/users/reset_password` with `UserResetPwdReq(uid, newPassword)` → `POST /api/users/{uid}/reset_password`
3. `POST /api/users/move_org` with `UserMoveOrgReq(uid, orgDn)` → `POST /api/users/{uid}/move_org`
4. `POST /api/groups/members/add` with `GroupMemberReq(groupDn, uid)` → `POST /api/groups/{cn}/members`
5. `POST /api/groups/members/remove` with `GroupMemberReq(groupDn, uid)` → `DELETE /api/groups/{cn}/members/{uid}`

**Missing endpoint:**
6. `PATCH /api/orgprofiles/{id}` → currently 405 (no route)

**Schema fix:**
7. `qr_issuance_audit.issued_by` is `nullable=True` → spec says NOT NULL

**Key files:**
- `src/backend/main.py` — All routes + Pydantic models
- `src/backend/ldap_client.py` — LDAP functions (already correct, take uid/dn params)
- `src/backend/orgdb.py` — PostgreSQL tables + OrgDB class
- `tests/test_org_groups.py` — Uses old org/delete and members/add|remove paths
- `tests/test_users.py` — Uses old reset_password and move_org paths
- `tests/test_lifecycle_audit.py` — Uses old reset_password path

**Hot reload:** Python changes in `src/backend/` auto-reload (~1s). No rebuild needed.

---

### Task 1: Fix org delete — `DELETE /api/org/{dn:path}`

**Files:**
- Modify: `src/backend/main.py:476-479` (replace route)
- Modify: `tests/test_org_groups.py:19,95` (update calls)

**Step 1: Update the route in main.py**

Replace:
```python
@app.post("/api/org/delete")
def api_org_delete(req: OrgDeleteReq, claims: Dict[str, Any] = Depends(require_admin)):
    res = delete_org_ou(req.dn)
    return {"ok": True, **res}
```

With:
```python
@app.delete("/api/org/{dn:path}")
def api_org_delete(dn: str, claims: Dict[str, Any] = Depends(require_admin)):
    """Delete an organization OU (Spec §10.2)."""
    res = delete_org_ou(dn)
    return {"ok": True, **res}
```

**Step 2: Update tests in test_org_groups.py**

Replace all `client.post("/api/org/delete", json={"dn": dn})` with:
```python
client.delete(f"/api/org/{dn}")
```

Specifically:
- Line 19: `client.post("/api/org/delete", json={"dn": dn})` → `client.delete(f"/api/org/{dn}")`
- Line 95: `resp = client.post("/api/org/delete", json={"dn": org_dn})` → `resp = client.delete(f"/api/org/{org_dn}")`

**Step 3: Run tests**

Run: `pytest tests/test_org_groups.py -v`

Expected: All PASS

**Step 4: Commit**

```bash
git add src/backend/main.py tests/test_org_groups.py
git commit -m "fix(org): change delete to DELETE /api/org/{dn} per spec §10.2"
```

---

### Task 2: Fix reset_password — `POST /api/users/{uid}/reset_password`

**Files:**
- Modify: `src/backend/main.py:602-609` (replace route)
- Modify: `tests/test_users.py:119,137` (update calls)
- Modify: `tests/test_lifecycle_audit.py:70` (update call)

**Step 1: Update the route in main.py**

Replace:
```python
@app.post("/api/users/reset_password")
def api_user_reset_password(req: UserResetPwdReq, claims: Dict[str, Any] = Depends(require_admin)):
    res = reset_user_password(req.uid, req.newPassword)
    try:
        ORGDB.record_lifecycle_event(req.uid, "password_reset", claims.get("sub", "unknown"))
    except Exception:
        pass
    return {"ok": True, **res}
```

With:
```python
@app.post("/api/users/{uid}/reset_password")
def api_user_reset_password(uid: str, req: UserResetPwdReq, claims: Dict[str, Any] = Depends(require_admin)):
    """Reset user password (Spec §10.3)."""
    user = get_user(uid)
    if not user:
        raise HTTPException(404, "User not found")
    res = reset_user_password(uid, req.newPassword)
    try:
        ORGDB.record_lifecycle_event(uid, "password_reset", claims.get("sub", "unknown"))
    except Exception:
        pass
    return {"ok": True, **res}
```

Also update `UserResetPwdReq` to remove the `uid` field (it's now a path param):
```python
class UserResetPwdReq(BaseModel):
    newPassword: str
    mustChange: Optional[bool] = True
```

**Step 2: Update tests in test_users.py**

Replace:
```python
resp = client.post("/api/users/reset_password", json={
    "uid": uid,
    "newPassword": new_password,
})
```
With:
```python
resp = client.post(f"/api/users/{uid}/reset_password", json={
    "newPassword": new_password,
})
```

Do the same for the nonexistent user test and test_lifecycle_audit.py.

**Step 3: Run tests**

Run: `pytest tests/test_users.py tests/test_lifecycle_audit.py -v`

Expected: All PASS

**Step 4: Commit**

```bash
git add src/backend/main.py tests/test_users.py tests/test_lifecycle_audit.py
git commit -m "fix(users): change reset_password to POST /api/users/{uid}/reset_password per spec §10.3"
```

---

### Task 3: Fix move_org — `POST /api/users/{uid}/move_org`

**Files:**
- Modify: `src/backend/main.py:612-614` (replace route)
- Modify: `tests/test_users.py:165` (update call)

**Step 1: Update the route in main.py**

Replace:
```python
@app.post("/api/users/move_org")
def api_user_move_org(req: UserMoveOrgReq, claims: Dict[str, Any] = Depends(require_admin)):
    return {"ok": True, **move_user_to_org(req.uid, req.orgDn)}
```

With:
```python
@app.post("/api/users/{uid}/move_org")
def api_user_move_org(uid: str, req: UserMoveOrgReq, claims: Dict[str, Any] = Depends(require_admin)):
    """Move user to a different org (Spec §10.3)."""
    user = get_user(uid)
    if not user:
        raise HTTPException(404, "User not found")
    return {"ok": True, **move_user_to_org(uid, req.orgDn)}
```

Also update `UserMoveOrgReq` to remove the `uid` field:
```python
class UserMoveOrgReq(BaseModel):
    orgDn: str
```

**Step 2: Update test in test_users.py**

Replace:
```python
move_resp = client.post("/api/users/move_org", json={
    "uid": uid,
    "orgDn": new_org_dn,
})
```
With:
```python
move_resp = client.post(f"/api/users/{uid}/move_org", json={
    "orgDn": new_org_dn,
})
```

**Step 3: Run tests**

Run: `pytest tests/test_users.py -v`

Expected: All PASS

**Step 4: Commit**

```bash
git add src/backend/main.py tests/test_users.py
git commit -m "fix(users): change move_org to POST /api/users/{uid}/move_org per spec §10.3"
```

---

### Task 4: Fix group member add — `POST /api/groups/{cn}/members`

**Files:**
- Modify: `src/backend/main.py:493-500` (replace route)
- Modify: `tests/test_org_groups.py:161,192,238` (update calls)

**Step 1: Update the route in main.py**

Replace:
```python
@app.post("/api/groups/members/add")
def api_group_add(req: GroupMemberReq, claims: Dict[str, Any] = Depends(require_admin)):
    conn = get_conn()
    user_dn = find_user_dn(conn, OU_PEOPLE, req.uid)
    conn.unbind()
    if not user_dn:
        raise HTTPException(404, "User not found")
    return {"ok": True, **group_add_member(req.groupDn, user_dn)}
```

With:
```python
@app.post("/api/groups/{cn}/members")
def api_group_add(cn: str, req: GroupMemberAddReq, claims: Dict[str, Any] = Depends(require_admin)):
    """Add a member to a group (Spec §10.4)."""
    group_dn = find_group_dn(cn)
    if not group_dn:
        raise HTTPException(404, f"Group not found: {cn}")
    conn = get_conn()
    user_dn = find_user_dn(conn, OU_PEOPLE, req.uid)
    conn.unbind()
    if not user_dn:
        raise HTTPException(404, "User not found")
    return {"ok": True, **group_add_member(group_dn, user_dn)}
```

Add new request model (replaces GroupMemberReq for add):
```python
class GroupMemberAddReq(BaseModel):
    uid: str
```

**Step 2: Update tests in test_org_groups.py**

Replace all `client.post("/api/groups/members/add", json={"groupDn": ..., "uid": ...})` with:
```python
client.post(f"/api/groups/{cn}/members", json={"uid": uid})
```

**Step 3: Run tests**

Run: `pytest tests/test_org_groups.py -v`

Expected: All PASS

**Step 4: Commit**

```bash
git add src/backend/main.py tests/test_org_groups.py
git commit -m "fix(groups): change member add to POST /api/groups/{cn}/members per spec §10.4"
```

---

### Task 5: Fix group member remove — `DELETE /api/groups/{cn}/members/{uid}`

**Files:**
- Modify: `src/backend/main.py:503-510` (replace route)
- Modify: `tests/test_org_groups.py:245` (update call)

**Step 1: Update the route in main.py**

Replace:
```python
@app.post("/api/groups/members/remove")
def api_group_remove(req: GroupMemberReq, claims: Dict[str, Any] = Depends(require_admin)):
    conn = get_conn()
    user_dn = find_user_dn(conn, OU_PEOPLE, req.uid)
    conn.unbind()
    if not user_dn:
        raise HTTPException(404, "User not found")
    return {"ok": True, **group_remove_member(req.groupDn, user_dn)}
```

With:
```python
@app.delete("/api/groups/{cn}/members/{uid}")
def api_group_remove(cn: str, uid: str, claims: Dict[str, Any] = Depends(require_admin)):
    """Remove a member from a group (Spec §10.4)."""
    group_dn = find_group_dn(cn)
    if not group_dn:
        raise HTTPException(404, f"Group not found: {cn}")
    conn = get_conn()
    user_dn = find_user_dn(conn, OU_PEOPLE, uid)
    conn.unbind()
    if not user_dn:
        raise HTTPException(404, "User not found")
    return {"ok": True, **group_remove_member(group_dn, user_dn)}
```

**Step 2: Update tests in test_org_groups.py**

Replace `client.post("/api/groups/members/remove", json={"groupDn": ..., "uid": ...})` with:
```python
client.delete(f"/api/groups/{cn}/members/{uid}")
```

**Step 3: Run tests**

Run: `pytest tests/test_org_groups.py -v`

Expected: All PASS

**Step 4: Commit**

```bash
git add src/backend/main.py tests/test_org_groups.py
git commit -m "fix(groups): change member remove to DELETE /api/groups/{cn}/members/{uid} per spec §10.4"
```

---

### Task 6: Add `PATCH /api/orgprofiles/{id}` endpoint

**Files:**
- Modify: `src/backend/main.py` (add endpoint after api_get_orgprofile)
- Modify: `src/backend/orgdb.py` (add `update_org_profile` method if missing)
- Create: `tests/test_orgprofile_patch.py`

**Step 1: Write the failing test**

Create `tests/test_orgprofile_patch.py`:
```python
"""OrgProfile PATCH tests (Spec §10.6)."""

import pytest
from conftest import LDAP_BASE_DN

OU_ORG = f"ou=org,{LDAP_BASE_DN}"


class TestOrgProfilePatch:
    """PATCH /api/orgprofiles/{id}."""

    def _create_profile(self, client, profile_id="patch_test_profile"):
        """Helper to create a test OrgProfile."""
        resp = client.post("/api/orgprofiles", json={
            "id": profile_id,
            "orgDn": OU_ORG,
            "orgName": "Patch Test Org",
            "orgKey": "patch-test",
            "bindRegistration": "open",
            "apps": [{"id": "chat", "label": "Chat"}],
        })
        return resp

    def test_patch_updates_org_name(self, client):
        """PATCH updates orgName field."""
        pid = "patch_test_1"
        self._create_profile(client, pid)

        resp = client.patch(f"/api/orgprofiles/{pid}", json={
            "orgName": "Updated Name",
        })
        assert resp.status_code == 200, f"PATCH failed: {resp.text}"
        data = resp.json()
        assert data["ok"] is True

        # Verify change persisted
        resp = client.get(f"/api/orgprofiles/{pid}")
        assert resp.json()["profile"]["orgName"] == "Updated Name"

    def test_patch_updates_multiple_fields(self, client):
        """PATCH can update multiple fields at once."""
        pid = "patch_test_2"
        self._create_profile(client, pid)

        resp = client.patch(f"/api/orgprofiles/{pid}", json={
            "orgName": "Multi Update",
            "bindRegistration": "invite",
        })
        assert resp.status_code == 200

        resp = client.get(f"/api/orgprofiles/{pid}")
        profile = resp.json()["profile"]
        assert profile["orgName"] == "Multi Update"
        assert profile["bindRegistration"] == "invite"

    def test_patch_nonexistent_returns_404(self, client):
        """PATCH nonexistent profile returns 404."""
        resp = client.patch("/api/orgprofiles/nonexistent_xyz_99", json={
            "orgName": "Ghost",
        })
        assert resp.status_code == 404
```

**Step 2: Run test to verify it fails**

Run: `pytest tests/test_orgprofile_patch.py -v`

Expected: FAIL with 405 Method Not Allowed

**Step 3: Add `update_org_profile` to orgdb.py**

Add method to OrgDB class (after `get_org_profile`):
```python
    def update_org_profile(self, profile_id: str, updates: dict) -> dict | None:
        """Update fields on an existing OrgProfile. Returns updated profile or None if not found."""
        eng = self.connect()
        with eng.begin() as conn:
            existing = conn.execute(
                select(org_profiles).where(org_profiles.c.id == profile_id)
            ).mappings().first()
            if not existing:
                return None
            # Merge updates into existing data
            current = dict(existing)
            for key, value in updates.items():
                if key in ("id",):  # Don't allow changing the ID
                    continue
                if key in current:
                    current[key] = value
            conn.execute(
                org_profiles.update()
                .where(org_profiles.c.id == profile_id)
                .values(**{k: v for k, v in current.items() if k != "id"})
            )
        return self.get_org_profile(profile_id)
```

**Step 4: Add endpoint in main.py**

Add after `api_get_orgprofile` (around line 1120):
```python
class OrgProfilePatchReq(BaseModel):
    orgName: Optional[str] = None
    orgKey: Optional[str] = None
    bindRegistration: Optional[str] = None
    apps: Optional[List[AppItem]] = None
    integrations: Optional[Integrations] = None
    policy: Optional[Policy] = None
    ssoProfile: Optional[SsoProfileConfig] = None


@app.patch("/api/orgprofiles/{profile_id}")
def api_patch_orgprofile(profile_id: str, req: OrgProfilePatchReq, claims: Dict[str, Any] = Depends(require_admin)):
    """Update OrgProfile fields (Spec §10.6)."""
    updates = {k: v for k, v in req.model_dump().items() if v is not None}
    if not updates:
        return {"ok": True, "modified": []}
    result = ORGDB.update_org_profile(profile_id, updates)
    if result is None:
        raise HTTPException(404, "OrgProfile not found")
    return {"ok": True, "profile": result}
```

**Step 5: Run tests**

Run: `pytest tests/test_orgprofile_patch.py -v`

Expected: All 3 PASS

**Step 6: Commit**

```bash
git add src/backend/main.py src/backend/orgdb.py tests/test_orgprofile_patch.py
git commit -m "feat(orgprofiles): add PATCH /api/orgprofiles/{id} endpoint per spec §10.6"
```

---

### Task 7: Fix `qr_issuance_audit.issued_by` nullable

**Files:**
- Modify: `src/backend/orgdb.py:78` (change nullable=True to nullable=False, add server_default)
- Modify: `src/backend/main.py` (ensure issued_by always passed)

**Step 1: Update table definition in orgdb.py**

Change line 78:
```python
    Column("issued_by", Text, nullable=True),
```
To:
```python
    Column("issued_by", Text, nullable=False, server_default="system"),
```

**Step 2: Verify all callers pass issued_by**

Check `record_qr_issuance` in orgdb.py — it already accepts `issued_by` param. Check main.py callers pass `claims.get("sub", "system")`.

Run: `grep -n "record_qr_issuance" src/backend/main.py`

If any caller passes `None`, fix it to pass `claims.get("sub", "system")`.

**Step 3: Drop and recreate the table in dev DB**

Run: `docker exec azblink-api-1 python -c "from orgdb import *; metadata.drop_all(create_engine('postgresql://azblink_directory:azblink_directory@postgres:5432/azblink_directory'), tables=[qr_issuance_audit]); print('dropped')"`

Or via psql:
```bash
just psql -c "DROP TABLE IF EXISTS qr_issuance_audit;"
```

Then the API hot-reload will recreate it via `metadata.create_all()`.

**Step 4: Run tests**

Run: `pytest tests/test_qr_format.py tests/test_qr_revoke.py -v`

Expected: All PASS

**Step 5: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "fix(audit): make qr_issuance_audit.issued_by NOT NULL per spec §11.1"
```

---

### Task 8: Full Validation

**Step 1: Run full test suite**

Run: `pytest tests/ -v`

Expected: All tests pass (109+ existing + new orgprofile tests)

**Step 2: Verify all spec endpoints match**

Hit each endpoint from spec §10.2-10.6 and verify correct HTTP method/path:
```bash
# Org delete
curl -s -X DELETE http://localhost:8081/api/org/ou=test,ou=org,dc=azblink,dc=com | jq .

# Reset password (path param)
curl -s -X POST http://localhost:8081/api/users/testuser/reset_password -H 'Content-Type: application/json' -d '{"newPassword":"x"}' | jq .

# Move org (path param)
curl -s -X POST http://localhost:8081/api/users/testuser/move_org -H 'Content-Type: application/json' -d '{"orgDn":"ou=org,dc=azblink,dc=com"}' | jq .

# Group member add
curl -s -X POST http://localhost:8081/api/groups/testgroup/members -H 'Content-Type: application/json' -d '{"uid":"testuser"}' | jq .

# Group member remove
curl -s -X DELETE http://localhost:8081/api/groups/testgroup/members/testuser | jq .

# OrgProfile PATCH
curl -s -X PATCH http://localhost:8081/api/orgprofiles/test-id -H 'Content-Type: application/json' -d '{"orgName":"x"}' | jq .
```

Expected: All return proper responses (200/404 with correct body), NOT 405 or generic "Not Found"

**Step 3: Verify old paths are gone**

```bash
# These should all return 405 or 404 "Not Found" (no route)
curl -s -X POST http://localhost:8081/api/org/delete -d '{}' | jq .
curl -s -X POST http://localhost:8081/api/users/reset_password -d '{}' | jq .
curl -s -X POST http://localhost:8081/api/users/move_org -d '{}' | jq .
curl -s -X POST http://localhost:8081/api/groups/members/add -d '{}' | jq .
curl -s -X POST http://localhost:8081/api/groups/members/remove -d '{}' | jq .
```

Expected: All 404 "Not Found" (no matching route)

**Step 4: Run tests twice for pollution check**

Run: `pytest tests/ -q && pytest tests/ -q`

Expected: Both runs pass identically

---

## Cleanup: Remove Dead Pydantic Models

After all tasks pass, remove `OrgDeleteReq` and `GroupMemberReq` from main.py if no longer referenced. `UserResetPwdReq` and `UserMoveOrgReq` keep their remaining fields but lose `uid`.

---
