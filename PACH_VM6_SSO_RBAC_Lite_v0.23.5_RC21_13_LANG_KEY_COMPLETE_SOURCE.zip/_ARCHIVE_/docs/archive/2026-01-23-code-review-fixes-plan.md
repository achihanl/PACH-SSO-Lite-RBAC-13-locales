# Code Review Fixes Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Fix all CRITICAL and HIGH severity issues found in the brutal code review of the audit/testing session commits.

**Architecture:** Fixes target three layers: API endpoint shape (main.py routes), data layer (orgdb.py table schemas + methods), and LDAP operations (ldap_client.py). Tests are updated to verify real behavior, not just "does the endpoint return 200."

**Tech Stack:** FastAPI, SQLAlchemy Core, ldap3, pytest, httpx

---

### Task 1: Fix Group Delete Endpoint (Wrong API Shape)

**Problem:** Spec says `DELETE /api/groups/{cn}` but we implemented `POST /api/groups/delete` with body `{groupDn: "..."}`. Also returns raw 500 for nonexistent groups.

**Files:**
- Modify: `src/backend/main.py:373-374` (remove GroupDeleteReq)
- Modify: `src/backend/main.py:519-523` (replace endpoint)
- Modify: `src/backend/ldap_client.py:289-300` (add find_group_dn helper, fix delete_group signature)
- Modify: `tests/test_org_groups.py:256-280` (fix test to use DELETE method)

**Step 1: Write the failing test**

In `tests/test_org_groups.py`, replace the existing `test_delete_group` with:

```python
    def test_delete_group(self, client, ldap_conn):
        """DELETE /api/groups/{cn} removes an empty group."""
        cn = "testgroup-delete-1"

        # Create a group
        resp = client.post("/api/groups/create", json={
            "orgDn": OU_ORG,
            "cn": cn,
        })
        assert resp.status_code == 200

        # Delete it using spec-compliant endpoint
        resp = client.delete(f"/api/groups/{cn}")
        assert resp.status_code == 200, f"Delete failed: {resp.text}"
        data = resp.json()
        assert data["ok"] is True

        # Verify it's gone
        resp = client.get("/api/groups")
        group_cns = [g["cn"] for g in resp.json()["groups"]]
        assert cn not in group_cns

    def test_delete_nonexistent_group_returns_404(self, client):
        """DELETE /api/groups/{cn} returns 404 for missing group."""
        resp = client.delete("/api/groups/nonexistent_group_xyz_99")
        assert resp.status_code == 404
```

**Step 2: Run test to verify it fails**

Run: `pytest tests/test_org_groups.py::TestGroupCRUD::test_delete_group tests/test_org_groups.py::TestGroupCRUD::test_delete_nonexistent_group_returns_404 -v`
Expected: FAIL (405 Method Not Allowed or 404 because route doesn't exist)

**Step 3: Implement the fix**

In `src/backend/ldap_client.py`, replace `delete_group`:

```python
def find_group_dn(cn: str) -> str | None:
    """Find a group's DN by its CN, searching under OU_GROUPS."""
    def _op():
        conn = get_conn()
        conn.search(OU_GROUPS, f"(cn={cn})", SUBTREE, attributes=["cn"])
        dn = conn.entries[0].entry_dn if conn.entries else None
        conn.unbind()
        return dn
    return safe_ldap(_op)


def delete_group(group_dn: str) -> Dict[str, Any]:
    """Delete a group entry by its DN."""
    def _op():
        conn = get_conn()
        if not entry_exists(conn, group_dn):
            conn.unbind()
            raise RuntimeError("Group not found")
        conn.delete(group_dn)
        if conn.result.get("description") != "success":
            conn.unbind()
            raise RuntimeError(f"LDAP group delete failed: {conn.result}")
        conn.unbind()
        return {"deleted": group_dn}
    return safe_ldap(_op)
```

In `src/backend/main.py`, add the import of `find_group_dn` and replace the endpoint:

```python
@app.delete("/api/groups/{cn}")
def api_group_delete(cn: str, claims: Dict[str, Any] = Depends(require_admin)):
    """Delete a group by CN (Spec §10.4)."""
    group_dn = find_group_dn(cn)
    if not group_dn:
        raise HTTPException(404, f"Group not found: {cn}")
    res = delete_group(group_dn)
    return {"ok": True, **res}
```

Remove the `GroupDeleteReq` model and the old `POST /api/groups/delete` endpoint.

**Step 4: Run test to verify it passes**

Run: `pytest tests/test_org_groups.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/backend/main.py src/backend/ldap_client.py tests/test_org_groups.py
git commit -m "fix(groups): change delete endpoint to DELETE /api/groups/{cn} per spec §10.4"
```

---

### Task 2: Fix QR Revoke to Actually Revoke Unified QR Tokens

**Problem:** `revoke_tokens_for_user` operates on `provision_tokens` table. Unified QR tokens are only recorded in `qr_issuance_audit`. Revoke is a no-op for unified QRs.

**Files:**
- Modify: `src/backend/orgdb.py:397-409` (add method to revoke qr_issuance_audit records)
- Modify: `src/backend/main.py:1014-1025` (call both revocation methods)
- Modify: `tests/test_qr_revoke.py` (test actual revocation after QR generation)

**Step 1: Write the failing test**

Replace `tests/test_qr_revoke.py` contents:

```python
"""QR token revocation tests (Spec §10.5)."""

import pytest
from conftest import create_test_user, LDAP_BASE_DN


class TestQRRevoke:
    """POST /api/users/{uid}/qrcode/revoke."""

    def test_revoke_after_qr_generation(self, client, created_users):
        """Generate QR, then revoke — tokens_revoked must be >= 1."""
        uid = "qr_revoke_real_1"
        create_test_user(client, uid, created_users)

        # Generate a unified QR (creates qr_issuance_audit record)
        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200

        # Revoke — should revoke the audit record
        resp = client.post(f"/api/users/{uid}/qrcode/revoke")
        assert resp.status_code == 200, f"Revoke failed: {resp.text}"
        data = resp.json()
        assert data["ok"] is True
        assert data["tokens_revoked"] >= 1, (
            f"Expected at least 1 token revoked after QR generation, got {data['tokens_revoked']}"
        )

    def test_revoke_idempotent(self, client, created_users):
        """Second revocation returns 0 (already revoked)."""
        uid = "qr_revoke_real_2"
        create_test_user(client, uid, created_users)

        # Generate then revoke
        client.get(f"/api/users/{uid}/qrcode")
        client.post(f"/api/users/{uid}/qrcode/revoke")

        # Second revoke returns 0
        resp = client.post(f"/api/users/{uid}/qrcode/revoke")
        assert resp.status_code == 200
        assert resp.json()["tokens_revoked"] == 0

    def test_revoke_nonexistent_user_returns_404(self, client):
        """Revoke for nonexistent user returns 404."""
        resp = client.post("/api/users/nonexistent_xyz_99/qrcode/revoke")
        assert resp.status_code == 404

    def test_revoke_with_no_tokens_returns_zero(self, client, created_users):
        """Revoke on user with no QR tokens returns 0."""
        uid = "qr_revoke_empty_1"
        create_test_user(client, uid, created_users)

        resp = client.post(f"/api/users/{uid}/qrcode/revoke")
        assert resp.status_code == 200
        assert resp.json()["tokens_revoked"] == 0
```

**Step 2: Run test to verify it fails**

Run: `pytest tests/test_qr_revoke.py::TestQRRevoke::test_revoke_after_qr_generation -v`
Expected: FAIL with `assert 0 >= 1`

**Step 3: Implement the fix**

In `src/backend/orgdb.py`, add after `revoke_tokens_for_user`:

```python
    def revoke_qr_issuance_for_user(self, uid: str) -> int:
        """Mark all unconsumed QR issuance audit records as revoked for a user."""
        eng = self.connect()
        with eng.begin() as conn:
            result = conn.execute(
                update(qr_issuance_audit)
                .where(
                    (qr_issuance_audit.c.user_uid == uid) &
                    (qr_issuance_audit.c.consumed == False)
                )
                .values(consumed=True, consumed_at=utcnow(), consumed_reason="admin_revoked")
            )
            return result.rowcount
```

In `src/backend/main.py`, update the revoke endpoint:

```python
@app.post("/api/users/{uid}/qrcode/revoke")
def api_user_qrcode_revoke(
    uid: str,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Revoke all active QR provisioning tokens for a user (Spec §10.5)."""
    user = get_user(uid)
    if not user:
        raise HTTPException(404, "User not found")

    # Revoke both unified QR audit records AND SSO provision tokens
    qr_revoked = ORGDB.revoke_qr_issuance_for_user(uid)
    sso_revoked = ORGDB.revoke_tokens_for_user(uid)
    return {"ok": True, "user_uid": uid, "tokens_revoked": qr_revoked + sso_revoked}
```

**Step 4: Run test to verify it passes**

Run: `pytest tests/test_qr_revoke.py -v`
Expected: PASS (all 4 tests)

**Step 5: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_qr_revoke.py
git commit -m "fix(qr): revoke now marks qr_issuance_audit records as consumed"
```

---

### Task 3: Fix auth_failure_audit Schema to Match Spec

**Problem:** Table is missing `username` and `user_agent` columns, has wrong column names, wrong nullability.

**Spec schema (SPEC.md:677-685):**
```sql
CREATE TABLE auth_failure_audit (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255),
    failure_reason VARCHAR(100) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    client_ip INET NOT NULL,
    user_agent TEXT,
    endpoint VARCHAR(255)
);
```

**Files:**
- Modify: `src/backend/orgdb.py:147-156` (fix table definition)
- Modify: `src/backend/orgdb.py` (fix `record_auth_failure` and `list_auth_failures` methods)
- Modify: `src/backend/main.py:200-204` (pass username and user_agent)

**Step 1: Write the failing test**

Add to `tests/test_audit.py`:

```python
class TestAuditAuthFailureSchema:
    """Verify auth_failure_audit has correct columns per spec."""

    def test_auth_failure_record_has_spec_fields(self, client):
        """Auth failure records contain all spec-required fields."""
        resp = client.get("/api/audit/auth_failures")
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        # Even with empty records, verify endpoint works
        # We'll verify field structure after triggering a failure
        assert isinstance(data["records"], list)
        # If there are records, they must have spec fields
        for record in data["records"]:
            assert "client_ip" in record
            assert "endpoint" in record
            assert "failure_reason" in record
            assert "username" in record
            assert "user_agent" in record
            assert "timestamp" in record
```

**Step 2: Run test to verify it fails**

Run: `pytest tests/test_audit.py::TestAuditAuthFailureSchema -v`
Expected: FAIL if any records exist (wrong field names), or PASS vacuously (empty list). The real verification is in Step 4.

**Step 3: Implement the fix**

In `src/backend/orgdb.py`, replace the `auth_failure_audit` table definition:

```python
auth_failure_audit = Table(
    "auth_failure_audit",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("username", String(255), nullable=True),
    Column("failure_reason", String(100), nullable=False),
    Column("timestamp", DateTime(timezone=True), nullable=False),
    Column("client_ip", String(45), nullable=False),
    Column("user_agent", Text, nullable=True),
    Column("endpoint", String(255), nullable=True),
)
```

Update `record_auth_failure` method:

```python
    def record_auth_failure(
        self,
        client_ip: str,
        endpoint: str,
        failure_reason: str,
        username: str | None = None,
        user_agent: str | None = None,
    ) -> None:
        """Record an authentication failure event."""
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(
                insert(auth_failure_audit).values(
                    username=username,
                    failure_reason=failure_reason,
                    client_ip=client_ip or "unknown",
                    user_agent=user_agent,
                    endpoint=endpoint,
                    timestamp=utcnow(),
                )
            )
```

Update `list_auth_failures` method to match new column names:

```python
    def list_auth_failures(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent auth failure records."""
        eng = self.connect()
        stmt = (
            select(auth_failure_audit)
            .order_by(auth_failure_audit.c.timestamp.desc())
            .limit(limit)
        )
        with eng.begin() as conn:
            rows = conn.execute(stmt).mappings().all()
        return [
            {
                "id": r["id"],
                "username": r["username"],
                "failure_reason": r["failure_reason"],
                "client_ip": r["client_ip"],
                "user_agent": r["user_agent"],
                "endpoint": r["endpoint"],
                "timestamp": r["timestamp"].isoformat() if r["timestamp"] else None,
            }
            for r in rows
        ]
```

In `src/backend/main.py`, update the auth failure recording call:

```python
    except Exception as e:
        client_ip = request.client.host if request.client else "unknown"
        user_agent = request.headers.get("user-agent")
        try:
            ORGDB.record_auth_failure(
                client_ip=client_ip,
                endpoint=request.url.path,
                failure_reason="invalid_token",
                username=None,  # Token was invalid, can't extract username
                user_agent=user_agent,
            )
        except Exception:
            pass  # Don't let audit failure break auth flow
        raise HTTPException(401, f"Invalid token: {e}")
```

**Step 4: Verify the table is recreated**

The table is created by `metadata.create_all()`. Since this is dev, restarting the API will recreate the table. Run:
`just logs` — verify no startup errors after container auto-reloads.

Then run: `pytest tests/test_audit.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_audit.py
git commit -m "fix(audit): align auth_failure_audit schema with spec §11.2"
```

---

### Task 4: Wrap All Audit Calls in try/except (Fire-and-Forget)

**Problem:** QR issuance audit and lifecycle audit calls are bare — if DB fails, the primary action fails with 500. Audit should NEVER break primary actions.

**Files:**
- Modify: `src/backend/main.py:586-587` (user create lifecycle)
- Modify: `src/backend/main.py:593-594` (password reset lifecycle)
- Modify: `src/backend/main.py:700` (suspend lifecycle)
- Modify: `src/backend/main.py:714` (unsuspend lifecycle)
- Modify: `src/backend/main.py:885-894` (QR issuance audit)

**Step 1: Write the failing test**

This is defensive code — hard to test DB failures directly. Instead, verify the pattern is consistent by code inspection. Write a smoke test:

In `tests/test_lifecycle_audit.py`, add:

```python
    def test_user_create_succeeds_even_if_audit_would_fail(self, client, created_users):
        """User creation must succeed regardless of audit logging status."""
        uid = "lifecycle_robust_1"
        resp = create_test_user(client, uid, created_users)
        # Primary action must succeed
        assert resp.status_code == 200
        assert resp.json()["ok"] is True
```

**Step 2: Run test (should pass already — this is a safeguard)**

Run: `pytest tests/test_lifecycle_audit.py::TestLifecycleAudit::test_user_create_succeeds_even_if_audit_would_fail -v`
Expected: PASS

**Step 3: Implement the fix**

In `src/backend/main.py`, wrap each bare audit call. Pattern:

For user create (`main.py:586-587`):
```python
    if res.get("status") == "created":
        try:
            ORGDB.record_lifecycle_event(req.uid, "created", claims.get("sub", "unknown"))
        except Exception:
            pass
```

For password reset (`main.py:593-594`):
```python
    res = reset_user_password(req.uid, req.newPassword)
    try:
        ORGDB.record_lifecycle_event(req.uid, "password_reset", claims.get("sub", "unknown"))
    except Exception:
        pass
    return {"ok": True, **res}
```

For suspend (`main.py:700`):
```python
    suspend_user(uid)
    try:
        ORGDB.record_lifecycle_event(uid, "suspended", claims.get("sub", "unknown"), req.reason)
    except Exception:
        pass
```

For unsuspend (`main.py:714`):
```python
    unsuspend_user(uid, req.newPassword)
    try:
        ORGDB.record_lifecycle_event(uid, "unsuspended", claims.get("sub", "unknown"))
    except Exception:
        pass
```

For QR issuance audit (`main.py:885-894`):
```python
    # Audit: record QR issuance (fire-and-forget)
    try:
        _token_hash = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        _issued_by = claims.get("sub", "unknown")
        ORGDB.record_qr_issuance(
            user_uid=uid,
            org_dn=org_dn,
            issued_by=_issued_by,
            token_hash=_token_hash,
            expires_at=datetime.fromtimestamp(payload["exp"], tz=timezone.utc),
        )
    except Exception:
        pass
```

**Step 4: Run full suite to verify nothing broke**

Run: `pytest tests/ -q`
Expected: All pass

**Step 5: Commit**

```bash
git add src/backend/main.py
git commit -m "fix(audit): wrap all audit calls in try/except (fire-and-forget pattern)"
```

---

### Task 5: Fix Token Hash Truncation and TOCTOU

**Problem:** Token hash uses `[:32]` (half the SHA-256). Two `utcnow()` calls for iat/exp. QR audit doesn't record client_ip or user_agent.

**Files:**
- Modify: `src/backend/main.py:879-886` (fix TOCTOU, remove truncation, add client_ip/user_agent)
- Modify: `src/backend/orgdb.py` (add client_ip, user_agent params to record_qr_issuance)
- Modify: `tests/test_qr_format.py:106` (fix meaningless assertion)

**Step 1: Write the failing test**

In `tests/test_qr_format.py`, replace `test_qr_payload_has_exp_field`:

```python
    def test_qr_payload_has_exp_field(self, client, created_users):
        """Payload exp is exactly iat + default TTL (3600s)."""
        uid = "qr_exp_1"
        create_test_user(client, uid, created_users)

        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200
        payload = resp.json()["payload"]
        assert "exp" in payload, "QR payload missing 'exp' field"
        assert isinstance(payload["exp"], int)
        assert payload["exp"] > payload["iat"], "exp must be after iat"
        # Default TTL is 3600s — allow 2s tolerance for processing time
        actual_ttl = payload["exp"] - payload["iat"]
        assert 3598 <= actual_ttl <= 3602, (
            f"exp - iat should be ~3600, got {actual_ttl}"
        )
```

**Step 2: Run test to verify it fails**

Run: `pytest tests/test_qr_format.py::TestQRUnifiedFormat::test_qr_payload_has_exp_field -v`
Expected: May PASS already (TOCTOU is sub-second), but the assertion is now meaningful.

**Step 3: Implement the fix**

In `src/backend/main.py`, replace the payload construction and audit block:

```python
    now = utcnow()
    payload = {
        "type": "ucchat-user-provision",
        "v": 1,
        "uid": uid,
        "userDn": user_dn,
        "orgDn": org_dn,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=ORG_QR_DEFAULT_TTL_SEC)).timestamp()),
        "nonce": secrets.token_urlsafe(16),
    }
    payload["sig"] = hmac_sig(payload)

    # Audit: record QR issuance (fire-and-forget)
    try:
        _token_hash = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        _issued_by = claims.get("sub", "unknown")
        ORGDB.record_qr_issuance(
            user_uid=uid,
            org_dn=org_dn,
            issued_by=_issued_by,
            token_hash=_token_hash,
            expires_at=datetime.fromtimestamp(payload["exp"], tz=timezone.utc),
            client_ip=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"),
        )
    except Exception:
        pass
```

In `src/backend/orgdb.py`, update `record_qr_issuance` to accept client_ip/user_agent:

```python
    def record_qr_issuance(
        self,
        user_uid: str,
        org_dn: str,
        issued_by: str,
        token_hash: str,
        expires_at: datetime,
        client_ip: str | None = None,
        user_agent: str | None = None,
    ) -> None:
        """Record a QR issuance event to the audit table."""
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(
                insert(qr_issuance_audit).values(
                    user_uid=user_uid,
                    org_dn=org_dn,
                    issued_by=issued_by,
                    issued_at=utcnow(),
                    token_hash=token_hash,
                    expires_at=expires_at,
                    consumed=False,
                    client_ip=client_ip,
                    user_agent=user_agent,
                )
            )
```

**Step 4: Run test to verify it passes**

Run: `pytest tests/test_qr_format.py tests/test_audit.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/backend/main.py src/backend/orgdb.py tests/test_qr_format.py
git commit -m "fix(qr): use full SHA-256 hash, fix TOCTOU, populate client_ip/user_agent"
```

---

### Task 6: Add Account Status Attribute for Suspend/Disable Queryability

**Problem:** `{SUSPENDED}` and `{DISABLED}` in userPassword are magic strings with no query mechanism. Admins can't list suspended users.

**Approach:** Use the `description` attribute (already in inetOrgPerson schema) to store account status. Set it alongside password changes. This avoids LDAP schema extensions.

**Files:**
- Modify: `src/backend/ldap_client.py:646-661` (suspend_user: also set description)
- Modify: `src/backend/ldap_client.py:620-642` (disable_user: also set description)
- Modify: `src/backend/ldap_client.py:664-675` (unsuspend_user: clear description)
- Modify: `tests/test_suspend.py` (verify description attribute)

**Step 1: Write the failing test**

Add to `tests/test_suspend.py`:

```python
    def test_suspended_user_has_status_attribute(self, client, created_users, ldap_conn):
        """Suspended user has description='SUSPENDED' for queryability."""
        uid = "suspend_status_1"
        client.post("/api/users/create", json={
            "uid": uid,
            "displayName": "Status Test",
            "mail": "status@test.com",
            "mobile": "1234567890",
            "password": "testpass123",
            "orgDn": f"ou=org,{LDAP_BASE_DN}",
        })
        created_users.append(uid)

        client.post(f"/api/users/{uid}/suspend", json={"reason": "test"})

        # Query LDAP for the description attribute
        from ldap3 import SUBTREE
        ldap_conn.search(
            f"ou=people,{LDAP_BASE_DN}",
            f"(uid={uid})",
            SUBTREE,
            attributes=["description"],
        )
        assert ldap_conn.entries, f"User {uid} not found"
        desc = str(ldap_conn.entries[0].description.value) if hasattr(ldap_conn.entries[0], "description") and ldap_conn.entries[0].description.value else ""
        assert desc == "SUSPENDED", f"Expected description='SUSPENDED', got '{desc}'"

    def test_unsuspended_user_has_status_cleared(self, client, created_users, ldap_conn):
        """After unsuspend, description is cleared."""
        uid = "suspend_status_2"
        client.post("/api/users/create", json={
            "uid": uid,
            "displayName": "Clear Status Test",
            "mail": "clearstatus@test.com",
            "mobile": "1234567890",
            "password": "testpass123",
            "orgDn": f"ou=org,{LDAP_BASE_DN}",
        })
        created_users.append(uid)

        client.post(f"/api/users/{uid}/suspend", json={"reason": "test"})
        client.post(f"/api/users/{uid}/unsuspend", json={"newPassword": "newpass"})

        from ldap3 import SUBTREE
        ldap_conn.search(
            f"ou=people,{LDAP_BASE_DN}",
            f"(uid={uid})",
            SUBTREE,
            attributes=["description"],
        )
        assert ldap_conn.entries
        desc = ldap_conn.entries[0].description.value if hasattr(ldap_conn.entries[0], "description") and ldap_conn.entries[0].description.value else None
        assert desc is None or desc == "", f"Expected empty description after unsuspend, got '{desc}'"
```

**Step 2: Run test to verify it fails**

Run: `pytest tests/test_suspend.py::TestUserSuspend::test_suspended_user_has_status_attribute -v`
Expected: FAIL (description not set)

**Step 3: Implement the fix**

In `src/backend/ldap_client.py`, update `suspend_user`:

```python
def suspend_user(uid: str) -> Dict[str, Any]:
    """Suspend a user by clearing their password and marking status."""
    def _op():
        conn = get_conn()
        user_dn = find_user_dn(conn, OU_PEOPLE, uid)
        if not user_dn:
            conn.unbind()
            raise RuntimeError("User not found")
        conn.modify(user_dn, {
            "userPassword": [(MODIFY_REPLACE, ["{SUSPENDED}"])],
            "description": [(MODIFY_REPLACE, ["SUSPENDED"])],
        })
        if conn.result.get("description") != "success":
            conn.unbind()
            raise RuntimeError(f"LDAP suspend failed: {conn.result}")
        conn.unbind()
        return {"ok": True, "user_dn": user_dn}
    return safe_ldap(_op)
```

Update `unsuspend_user`:

```python
def unsuspend_user(uid: str, new_password: str) -> Dict[str, Any]:
    """Unsuspend a user by setting a new password and clearing status."""
    def _op():
        conn = get_conn()
        user_dn = find_user_dn(conn, OU_PEOPLE, uid)
        if not user_dn:
            conn.unbind()
            raise RuntimeError("User not found")
        conn.modify(user_dn, {
            "userPassword": [(MODIFY_REPLACE, [ssha_password(new_password)])],
            "description": [(MODIFY_REPLACE, [])],
        })
        if conn.result.get("description") != "success":
            conn.unbind()
            raise RuntimeError(f"LDAP unsuspend failed: {conn.result}")
        conn.unbind()
        return {"ok": True, "user_dn": user_dn}
    return safe_ldap(_op)
```

Update `disable_user`:

```python
def disable_user(uid: str) -> Dict[str, Any]:
    """Disable user account (termination)."""
    def _op():
        conn = get_conn()
        user_dn = find_user_dn(conn, OU_PEOPLE, uid)
        if not user_dn:
            conn.unbind()
            raise RuntimeError("User not found")
        conn.modify(user_dn, {
            "userPassword": [(MODIFY_REPLACE, ["{DISABLED}"])],
            "description": [(MODIFY_REPLACE, ["TERMINATED"])],
        })
        if conn.result.get("description") != "success":
            conn.unbind()
            raise RuntimeError(f"LDAP disable user failed: {conn.result}")
        conn.unbind()
        return {"ok": True, "user_dn": user_dn, "disabled": True}
    return safe_ldap(_op)
```

**Step 4: Run test to verify it passes**

Run: `pytest tests/test_suspend.py -v`
Expected: PASS (all tests including new ones)

**Step 5: Commit**

```bash
git add src/backend/ldap_client.py tests/test_suspend.py
git commit -m "fix(ldap): set description attribute on suspend/disable for queryability"
```

---

### Task 7: Fix Test Quality Issues

**Problem:** Breakglass test leaks sys.path. CSV org path test has fragile cleanup. Existing test assertions are meaningless.

**Files:**
- Modify: `tests/test_breakglass.py:63` (restore sys.path after import)
- Modify: `tests/test_import_csv.py:61-85` (use fixture for org cleanup)

**Step 1: Fix breakglass sys.path leak**

In `tests/test_breakglass.py`, after the sys.modules restoration block (line 75), add:

```python
# Remove the backend path we inserted (avoid import conflicts)
_backend_path = os.path.join(os.path.dirname(__file__), "..", "src", "backend")
if _backend_path in sys.path:
    sys.path.remove(_backend_path)
```

**Step 2: Fix CSV org cleanup**

In `tests/test_import_csv.py`, modify `test_import_with_org_path` to use setup/teardown in the fixture rather than inline cleanup:

```python
    def test_import_with_org_path(self, client, cleanup_csv_users, ldap_conn):
        """Import user with orgPath creates org and places user."""
        csv_content = "uid,displayName,mail,mobile,password,orgPath\ncsv_org_1,Org User,org@test.com,5553333333,pass1,CSVTestOrg"
        resp = client.post("/api/users/import_csv", json={
            "csv": csv_content,
            "autoCreateOrg": True,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["created"] == 1

        # Cleanup org tree (user is under org's people sub-OU, not root people)
        from ldap3 import SUBTREE
        org_dn = f"ou=CSVTestOrg,ou=org,{LDAP_BASE_DN}"
        people_dn = f"ou=CSVTestOrg,ou=people,{LDAP_BASE_DN}"
        groups_dn = f"ou=CSVTestOrg,ou=groups,{LDAP_BASE_DN}"
        user_dn = f"uid=csv_org_1,{people_dn}"
        # Delete in correct order: leaf first
        for dn in [user_dn, people_dn, groups_dn, org_dn]:
            try:
                ldap_conn.delete(dn)
            except Exception:
                pass  # Ignore if already gone
```

**Step 3: Run tests**

Run: `pytest tests/test_breakglass.py tests/test_import_csv.py -v`
Expected: PASS

**Step 4: Commit**

```bash
git add tests/test_breakglass.py tests/test_import_csv.py
git commit -m "fix(tests): restore sys.path in breakglass, robust org cleanup in CSV test"
```

---

### Task 8: Full Suite Validation

**Step 1: Run full suite**

Run: `pytest tests/ -v`
Expected: All pass, 0 failures

**Step 2: Verify QR revoke actually revokes**

Run:
```bash
python -c "
import httpx
c = httpx.Client(base_url='http://localhost:8081')
c.post('/api/users/create', json={'uid':'final_verify','displayName':'FV','mail':'fv@t.com','mobile':'111','password':'p','orgDn':'ou=org,dc=azblink,dc=com'})
c.get('/api/users/final_verify/qrcode')
resp = c.post('/api/users/final_verify/qrcode/revoke')
print('Revoke after QR:', resp.json())
assert resp.json()['tokens_revoked'] >= 1, 'REVOKE STILL BROKEN'
# cleanup
from ldap3 import Server, Connection, SUBTREE
s = Server('ldap://localhost:1390')
conn = Connection(s, 'cn=admin,dc=azblink,dc=com', 'adminpassword', auto_bind=True)
conn.search('ou=people,dc=azblink,dc=com', '(uid=final_verify)', SUBTREE)
for e in conn.entries:
    conn.delete(e.entry_dn)
conn.unbind()
print('OK: Revoke actually works')
"
```

Expected: `Revoke after QR: {'ok': True, 'user_uid': 'final_verify', 'tokens_revoked': 1}`

**Step 3: Verify group delete uses correct HTTP method**

Run:
```bash
python -c "
import httpx
c = httpx.Client(base_url='http://localhost:8081')
# Old endpoint should NOT work
resp = c.post('/api/groups/delete', json={'groupDn': 'cn=fake,ou=groups,dc=azblink,dc=com'})
print('Old POST endpoint:', resp.status_code)  # Should be 404 or 405
# New endpoint
resp2 = c.delete('/api/groups/nonexistent_xyz')
print('New DELETE endpoint:', resp2.status_code)  # Should be 404
assert resp2.status_code == 404, 'DELETE endpoint not returning 404 for missing group'
print('OK: Group delete API shape is correct')
"
```

**Step 4: Verify auth_failure_audit schema**

Run:
```bash
python -c "
import httpx
c = httpx.Client(base_url='http://localhost:8081')
resp = c.get('/api/audit/auth_failures')
print('Auth failures endpoint:', resp.json())
# Check that response structure has spec fields (even if empty)
assert resp.json()['ok'] is True
print('OK: Auth failure endpoint works')
"
```

**Step 5: Final commit (if any loose changes)**

Run: `git status`
If clean: Done. If not: stage and commit remaining changes.
