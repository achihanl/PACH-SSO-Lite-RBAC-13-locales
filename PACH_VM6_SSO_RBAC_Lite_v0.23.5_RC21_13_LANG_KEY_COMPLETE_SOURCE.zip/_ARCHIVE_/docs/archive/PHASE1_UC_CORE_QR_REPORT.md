# Phase 1 UC Core QR: PRD & Demo Report

**Source:** `docs/prd/PHASE1_UC_CORE_QR_PRD.md`  
**Date:** 2025-01-25

---

## 1. Executive Summary

Phase 1 delivers **UC Core QR provisioning (QR#1)**: one QR scan → XMPP/SIP fully configured. No Authentik or SSO required. Design invariant: **UC must work when Authentik is not installed and Phase 2 is never deployed.**

| Attribute | Value |
|-----------|--------|
| PRD version | 1.0 |
| Status | Ready for Implementation |
| Target | Production-ready UC-only deployment |
| Est. effort | 8–10 developer days |

---

## 2. PRD Scope (Summary)

- **Payload:** `azblink.provisioning.v2` with `payload.uc` (tenant, xmpp, sip, credentials) and `payload.sso: null`.
- **Security:** HMAC-SHA256 signing, one-time token, rate limits (10/min on QR + consume).
- **APIs:** `GET /api/users/{uid}/qrcode`, `POST /api/provision/consume`, revoke optional.
- **Backend:** QR signing module, updated qrcode endpoint, consume endpoint, provision_tokens enhancement, migration `004_phase1_uc_qr.sql`.

---

## 3. Demo That Presents Phase 1

| Item | Location | Role |
|------|----------|------|
| **Demo folder** | `demo/qr-flow/` | All QR onboarding demos (QR#1 + QR#2) |
| **Phase 1 behavior** | ucChat tabs | “Scan QR #1” → UC Core only (Me + Chat/Call) |
| **Entry point** | `demo/qr-flow/index.html` | Single preview of all demos (incl. ucChat) |

**Files that demonstrate Phase 1 (QR#1):**

- `demo/qr-flow/ucchat_tabs_safenest.html`
- `demo/qr-flow/ucchat_tabs_ehub.html`
- `demo/qr-flow/ucchat_tabs_teampulse.html`

In each, **“Scan QR #1”** simulates Phase 1: Me + Chat (XMPP) and/or Call (SIP); **Apps** and **Directory** are not shown. **“Scan QR #2”** simulates Phase 2 (append Apps/Directory). The UI flow “one QR → UC only” is what the PRD specifies for Phase 1.

**Not Phase 1:** `demo/mobile/` is directory search/contact and deep links only; it does not present QR provisioning or the UC Core flow.

---

## 4. PRD vs Demo Alignment

| PRD concept | Demo representation |
|-------------|----------------------|
| One QR → UC configured | “Scan QR #1” shows Chat/Call/Me only |
| No SSO in Phase 1 | Apps/Directory appear only after QR#2 |
| XMPP + SIP | Toggle: Chat only / Call only / Chat+Call |
| Token one-time, signed payload | Not shown in offline HTML; backend/PRD only |

**Gaps:** Demos are **offline HTML** with simulated scan buttons. They do not show signing, token consumption, or `POST /api/provision/consume`. For a full Phase 1 story, pair the ucChat tabs (“Scan QR #1”) with the real portal flow (e.g. My Profile → QR display) and backend APIs.

---

## 5. Implementation Status (from PRD §2)

**Already in place:** User/Group/Org CRUD, HMAC helper, rate limiting (rate_limit.py), audit tables, token validate-and-consume in orgdb, break-glass.

**Needs work:**  
- P0: QR schema → `azblink.provisioning.v2`, unified QR endpoint with UC block, one-time token in UC block, `POST /api/provision/consume`.  
- P1: UC Server client stub, account soft-lock.  
- P2: CLI QR commands.  
- QR generation still uses legacy schema; termination flow partial (no UC client).

---

## 6. Recommendations

1. **Presenting Phase 1:** Use `demo/qr-flow/index.html` and navigate to any ucChat tabs demo; run “Scan QR #1” and toggle Chat/Call to show UC-only outcome.
2. **Closing the loop:** When backend implements PRD (v2 schema, consume endpoint), add a single “live” demo path: My Profile → fetch QR from API → show in UI (optional: camera/consume simulation).
3. **Docs:** In `demo/qr-flow/README.md`, state explicitly that QR#1 = Phase 1 (UC Core) and QR#2 = Phase 2 (SSO/App profile); link to `docs/prd/PHASE1_UC_CORE_QR_PRD.md` and Phase 2 PRD.

---

## 7. References

- PRD: `docs/prd/PHASE1_UC_CORE_QR_PRD.md`
- Demo: `demo/qr-flow/` (README, index.html, ucchat_tabs_*.html)
- Phase 2: `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md` (QR#2)
