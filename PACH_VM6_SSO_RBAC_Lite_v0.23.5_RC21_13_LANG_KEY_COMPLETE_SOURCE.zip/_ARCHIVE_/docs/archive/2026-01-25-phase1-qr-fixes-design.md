# Phase 1 UC Core QR - Bug Fixes Design

**Date:** 2026-01-25
**Status:** Draft
**Author:** Claude (code review follow-up)

## Overview

This document captures fixes for 11 issues identified during a brutal code review of the Phase 1 UC Core QR implementation. The issues range from CRITICAL (empty domains breaking production QR codes) to LOW (code style improvements).

## Scope

**In scope:**
- Startup validation for required UC environment variables
- Documentation updates (.env.example, README)
- Error handling improvements (fail vs silent swallow)
- Code cleanup (duplicate logic, import hacks, timestamp precision)

**Out of scope:**
- New features
- Migration runner infrastructure (document manual process instead)
- Domain format validation (trust operators)

## Success Criteria

1. Application refuses to start with missing/invalid UC configuration
2. All required environment variables documented in .env.example
3. QR generation fails explicitly if token cannot be stored
4. No silent failures that produce broken QR codes
5. All existing tests continue to pass

---

## Fix 1: Startup Validation for UC Environment Variables (CRITICAL)

**Problem:** Empty `UCCHAT_SIP_DOMAIN`, `UCCHAT_XMPP_WS_URL`, etc. produce broken QR codes with invalid URIs like `sip:user@`.

**Solution:** Add startup validation in `config.py` that fails if required UC variables are empty.

**Required variables (must be non-empty):**
- `UCCHAT_XMPP_DOMAIN`
- `UCCHAT_XMPP_WS_URL`
- `UCCHAT_SIP_DOMAIN`
- `UCCHAT_SIP_WSS_URL`

**Implementation:**
```python
# config.py - add at end of file
def _validate_uc_config():
    """Fail fast if UC provisioning config is incomplete."""
    missing = []
    if not UCCHAT_XMPP_DOMAIN:
        missing.append("UCCHAT_XMPP_DOMAIN")
    if not UCCHAT_XMPP_WS_URL:
        missing.append("UCCHAT_XMPP_WS_URL")
    if not UCCHAT_SIP_DOMAIN:
        missing.append("UCCHAT_SIP_DOMAIN")
    if not UCCHAT_SIP_WSS_URL:
        missing.append("UCCHAT_SIP_WSS_URL")
    if missing:
        raise RuntimeError(
            f"UC provisioning requires: {', '.join(missing)}. "
            "Set these environment variables or disable QR provisioning."
        )

_validate_uc_config()
```

**Also:** Remove the LDAP_TENANT fallback from UCCHAT_XMPP_DOMAIN:
```python
# Before
UCCHAT_XMPP_DOMAIN = os.getenv("UCCHAT_XMPP_DOMAIN", LDAP_TENANT)
# After
UCCHAT_XMPP_DOMAIN = os.getenv("UCCHAT_XMPP_DOMAIN", "")
```

---

## Fix 2: Document Manual Migration (HIGH)

**Problem:** `migrations/004_phase1_uc_qr.sql` exists but no runner.

**Solution:** Add migration instructions to CLAUDE.md and README.

**Add to CLAUDE.md under Development Commands:**
```markdown
## Database Migrations

For existing deployments, run migrations manually before upgrading:

```bash
# From deploy/dev directory
just psql < ../../migrations/004_phase1_uc_qr.sql
```

Fresh deployments don't need this - tables are created automatically.
```

---

## Fix 3: Update .env.example (HIGH)

**Problem:** Missing UC provisioning variables.

**Solution:** Add all Phase 1 variables with documentation comments.

**Add to .env.example:**
```bash
# UC Core QR Provisioning (Phase 1) - REQUIRED for QR features
UCCHAT_XMPP_DOMAIN=xmpp.example.com
UCCHAT_XMPP_WS_URL=wss://xmpp.example.com/ws
UCCHAT_SIP_DOMAIN=sip.example.com
UCCHAT_SIP_WSS_URL=wss://sip.example.com/ws

# QR Token TTL (optional - defaults shown)
# ORG_QR_DEFAULT_TTL_SEC=3600
# ORG_QR_MAX_TTL_SEC=86400
```

---

## Fix 4: Fail on Token Recording Error (MEDIUM)

**Problem:** `record_provision_token()` failures are silently swallowed, returning a QR code with a token that doesn't exist in the database.

**Solution:** Remove try/except around token recording. Let exceptions propagate.

**File:** `main.py` lines ~1059-1067

```python
# Before
try:
    ORGDB.record_provision_token(
        token_hash=token_hash,
        uid=uid,
        profile_id=org_dn,
        expires_at=exp_dt
    )
except Exception:
    pass  # Fire-and-forget

# After
ORGDB.record_provision_token(
    token_hash=token_hash,
    uid=uid,
    profile_id=org_dn,
    expires_at=exp_dt
)
# No try/except - let 500 propagate if DB fails
```

**Note:** Keep the audit recording (`record_qr_issuance`) as fire-and-forget since audit is not critical to functionality.

---

## Fix 5: Use Same Token Hash in Audit Table (MEDIUM)

**Problem:** `provision_tokens.token_hash` uses SHA256 of token string, but `qr_issuance_audit.token_hash` uses SHA256 of entire payload JSON. Confusing.

**Solution:** Use the same provision token hash in both tables.

**File:** `main.py` lines ~1069-1083

```python
# Before
_payload_hash = hashlib.sha256(json.dumps(signed_payload, sort_keys=True).encode()).hexdigest()
ORGDB.record_qr_issuance(
    ...
    token_hash=_payload_hash,  # Wrong hash!
    ...
)

# After
ORGDB.record_qr_issuance(
    ...
    token_hash=token_hash,  # Same hash as provision_tokens
    ...
)
```

**Cleanup:** Remove the unused `_payload_hash` variable.

---

## Fix 6: Fail on Weak Signing Secret (LOW)

**Problem:** Default signing secret is predictable. Operators might deploy without changing it.

**Solution:** Validate signing secret at startup.

**File:** `config.py`

```python
# Add to _validate_uc_config() or create separate function
def _validate_signing_secret():
    """Fail if signing secret is default or too short."""
    default = "CHANGE_ME__ORG_QR_SIGNING_SECRET"
    if ORG_QR_SIGNING_SECRET == default:
        raise RuntimeError(
            "ORG_QR_SIGNING_SECRET is set to default value. "
            "Generate a secure random secret: openssl rand -hex 32"
        )
    if len(ORG_QR_SIGNING_SECRET) < 32:
        raise RuntimeError(
            f"ORG_QR_SIGNING_SECRET must be at least 32 characters "
            f"(got {len(ORG_QR_SIGNING_SECRET)})"
        )

_validate_signing_secret()
```

---

## Fix 7: Remove Duplicate TTL Capping (LOW)

**Problem:** TTL capped in both `main.py` and `qr_signing.py`.

**Solution:** Remove from `main.py`, keep in `qr_signing.py`.

**File:** `main.py` lines ~1047-1054

```python
# Before
effective_ttl = min(
    ttl_sec if ttl_sec is not None else ORG_QR_DEFAULT_TTL_SEC,
    ORG_QR_MAX_TTL_SEC
)
signed_payload = sign_provisioning_payload(uc_payload, sso_payload=None, ttl_sec=effective_ttl)

# After
requested_ttl = ttl_sec if ttl_sec is not None else ORG_QR_DEFAULT_TTL_SEC
signed_payload = sign_provisioning_payload(uc_payload, sso_payload=None, ttl_sec=requested_ttl)
# qr_signing.py handles max TTL capping
```

---

## Fix 8: Single Timestamp in Token Validation (LOW)

**Problem:** `utcnow()` called twice in atomic update - tiny race window.

**Solution:** Capture timestamp once at start of method.

**File:** `orgdb.py` in `validate_and_consume_token()`

```python
# Before
result = conn.execute(
    update(provision_tokens)
    .where(
        ...
        & (provision_tokens.c.expires_at > utcnow())  # Called here
    )
    .values(used_at=utcnow(), status="consumed")      # And here
)

# After
def validate_and_consume_token(self, token_hash: str) -> tuple[bool, str, dict]:
    now = utcnow()  # Capture once

    with eng.begin() as conn:
        result = conn.execute(
            update(provision_tokens)
            .where(
                ...
                & (provision_tokens.c.expires_at > now)
            )
            .values(used_at=now, status="consumed")
        )
```

---

## Fix 9: Fix Import Paths in Tests (LOW)

**Problem:** `qr_signing.py` has try/except import hack for test compatibility.

**Solution:** Fix `conftest.py` to set up `sys.path` properly.

**File:** `tests/conftest.py` - add at top:

```python
import sys
from pathlib import Path

# Add src/backend to path for all tests
backend_path = Path(__file__).parent.parent / "src" / "backend"
sys.path.insert(0, str(backend_path))
```

**File:** `src/backend/qr_signing.py` - remove hack:

```python
# Remove this:
try:
    from config import ORG_QR_SIGNING_SECRET, ...
except ImportError:
    from src.backend.config import ORG_QR_SIGNING_SECRET, ...

# Replace with:
from config import ORG_QR_SIGNING_SECRET, ...
```

**Also:** Remove similar hacks from test files (`test_config.py`, `test_qr_signing_unit.py`).

---

## Testing Strategy

**Existing tests must pass** - no regressions.

**New tests needed:**

1. **Startup validation tests** (`test_config.py`)
   - `test_startup_fails_if_ucchat_xmpp_domain_empty`
   - `test_startup_fails_if_signing_secret_default`
   - `test_startup_fails_if_signing_secret_too_short`

2. **Token recording failure test** (`test_qrcode_v2.py`)
   - `test_qrcode_fails_if_db_unavailable` (mock DB error)

**Test environment update:**
- `deploy/dev/.env` must include valid UC variables for tests to pass
- Update `.env` alongside `.env.example`

---

## Implementation Order

Execute in this order to minimize risk:

| Step | Fix | Risk | Notes |
|------|-----|------|-------|
| 1 | Update `.env.example` and `.env` | None | Docs only |
| 2 | Update CLAUDE.md with migration docs | None | Docs only |
| 3 | Fix import paths in conftest.py | Low | Run tests after |
| 4 | Remove import hacks from modules | Low | Run tests after |
| 5 | Single timestamp in orgdb.py | Low | Run tests after |
| 6 | Remove duplicate TTL capping | Low | Run tests after |
| 7 | Use same token hash in audit | Low | Run tests after |
| 8 | Remove try/except from token recording | Medium | Run tests after |
| 9 | Add startup validation (UC vars) | Medium | Breaks startup without config |
| 10 | Add startup validation (signing secret) | Medium | Breaks startup without config |

**After each step:** Run `just test-quick` to verify no regressions.

---

## Rollback Plan

If issues arise in production:

1. **Startup validation breaking deployment:**
   - Set required env vars, or
   - Revert config.py validation functions

2. **Token recording failures surfacing:**
   - This is the fix working - investigate DB issues
   - Temporary: revert to try/except if needed

---

## Verification Checklist

After implementation:

- [ ] `just test-quick` passes (196+ tests)
- [ ] Fresh `docker-compose up` works with updated `.env`
- [ ] QR code contains valid domains/URLs
- [ ] `/api/provision/consume` works end-to-end
- [ ] Startup fails without required UC vars (intentional)
- [ ] Startup fails with default signing secret (intentional)
