# Design System Migration: shadcn/ui → @azblink/ui

> **Date:** 2026-02-07 | **Timeline:** 2 weeks | **Status:** COMPLETE — all tasks executed, consolidation done

## Context

Replace `src/frontend/`'s shadcn/ui (Radix UI + inline Tailwind) with `@azblink/ui` (Base UI + CSS Modules + design tokens). The `@azblink/ui` package lives in `azblink-ui/` and is linked via npm workspaces.

**What's already done (Phase 0-1):**
- npm workspace linking (`package.json` at root)
- `tsup` build pipeline (`azblink-ui/tsup.config.ts`)
- Light mode tokens (`tokens/tokens.css` with `[data-theme="light"]`)
- 20 component exports built and tested: Button, Toggle, Badge, Input, Label, Skeleton, Card (7), Table (8), `cn()`

**What remains (this plan):**
1. Fix API gaps between old and new components (variants, sizes, `asChild`)
2. Build 4 remaining components (Checkbox, AlertDialog, Menu, Tooltip)
3. Build ThemeProvider
4. Migrate 20 route/feature/layout files
5. Cleanup (remove Radix deps, delete shadcn dir, update globals.css, fonts)

---

## Critical API Gaps to Fix First

### Gap 1: Button Variants and Sizes

**Old shadcn variants used in codebase:** `default`, `destructive`, `outline`, `ghost`, `secondary`, `link`
**New @azblink/ui variants:** `primary`, `secondary`, `ghost`, `success`, `danger`
**Missing:** `outline`, `link`

**Old shadcn sizes used in codebase:** `default`, `sm`, `icon`
**New @azblink/ui sizes:** `sm`, `md`, `lg`
**Missing:** `icon`

**Old `asChild` prop used in 3 files:** `$uid.tsx` (1), `users/index.tsx` (1), `empty-state.tsx` (1)
**New @azblink/ui:** No `asChild` support. Base UI uses `render` prop instead.

**Variant mapping table (apply to every migration):**

| Old (shadcn) | New (@azblink/ui) | Notes |
|---|---|---|
| `default` (or no variant) | `primary` | Default maps cleanly |
| `destructive` | `danger` | Rename only |
| `outline` | `secondary` | Closest semantic match |
| `secondary` | `secondary` | Direct |
| `ghost` | `ghost` | Direct |
| `link` | (not used in codebase) | Defer — not in any route |

| Old Size | New Size | Notes |
|---|---|---|
| `default` (or no size) | `md` | Default maps cleanly |
| `sm` | `sm` | Direct |
| `icon` | `sm` + className override | Need `icon` size in @azblink/ui |

### Gap 2: Badge Variants

**Old shadcn variants used in codebase:** `default`, `secondary`, `outline`
**New @azblink/ui variants:** `success`, `warning`, `error`, `info`, `muted`, `purple`

| Old (shadcn) | New (@azblink/ui) | Notes |
|---|---|---|
| `default` (or no variant) | `info` | Primary colored badge |
| `secondary` | `muted` | Subdued badge |
| `outline` | `muted` + border override | Or add `outline` variant |

### Gap 3: `asChild` Support

Base UI uses `render` prop for composition instead of Radix's `asChild` + `Slot`:

```tsx
// OLD (shadcn/Radix)
<Button asChild>
  <Link to="/users/new">Add User</Link>
</Button>

// NEW (Base UI) — render prop
<Button render={<Link to="/users/new" />}>
  Add User
</Button>
```

**Files needing this change:** `$uid.tsx`, `users/index.tsx`, `empty-state.tsx`

---

## Task Sequence

### Task 1: Add Missing Button Variants and Sizes

**File:** `azblink-ui/primitives/Button/Button.types.ts`
**File:** `azblink-ui/primitives/Button/Button.module.css`

**Changes:**
- Add `'outline'` and `'link'` to `ButtonVariant` type
- Add `'icon'` to `ButtonSize` type
- Add `.outline` and `.link` CSS classes
- Add `.icon` CSS class (square button, no padding)
- The `render` prop comes from Base UI's `Button` component automatically — verify it passes through

**Test:** `cd azblink-ui && npm run build` — verify DTS includes new variants

**Commit:** `feat(ui): add outline/link/icon variants to Button`

---

### Task 2: Add Missing Badge Variants

**File:** `azblink-ui/primitives/Badge/Badge.types.ts`
**File:** `azblink-ui/primitives/Badge/Badge.module.css`

**Changes:**
- Add `'outline'` to `BadgeVariant` type
- Add `.outline` CSS class (border + transparent bg)
- Consider adding `'default'` as alias for `'info'` if needed

**Test:** `cd azblink-ui && npm run build`

**Commit:** `feat(ui): add outline variant to Badge`

---

### Task 3: Build Checkbox Component

**New files:**
- `azblink-ui/primitives/Checkbox/index.ts`
- `azblink-ui/primitives/Checkbox/Checkbox.tsx`
- `azblink-ui/primitives/Checkbox/Checkbox.module.css`

**Base UI import:** `import { Checkbox as BaseCheckbox } from '@base-ui/react/checkbox';`

**Base UI anatomy:**
```tsx
<BaseCheckbox.Root className={styles.root}>
  <BaseCheckbox.Indicator className={styles.indicator}>
    <CheckIcon />
  </BaseCheckbox.Indicator>
</BaseCheckbox.Root>
```

**Props to support** (matching current shadcn usage in `login.tsx`):
- `checked`, `defaultChecked`, `onCheckedChange`, `disabled`, `id`, `name`, `className`
- Include built-in `CheckIcon` SVG (no external dep)

**Current usage pattern (login.tsx):**
```tsx
<Checkbox id="remember" />
<Label htmlFor="remember">Remember me</Label>
```

**API design:** Export single `Checkbox` component that wraps `Checkbox.Root` + `Checkbox.Indicator` + built-in icon. Accept `ComponentProps<'button'>` compatible surface.

**Test:** `cd azblink-ui && npm run build`

**Commit:** `feat(ui): add Checkbox component`

---

### Task 4: Build AlertDialog Component

**New files:**
- `azblink-ui/primitives/AlertDialog/index.ts`
- `azblink-ui/primitives/AlertDialog/AlertDialog.tsx`
- `azblink-ui/primitives/AlertDialog/AlertDialog.module.css`

**Base UI import:** `import { AlertDialog as BaseAlertDialog } from '@base-ui/react/alert-dialog';`

**Base UI anatomy:**
```tsx
<BaseAlertDialog.Root>
  <BaseAlertDialog.Trigger />
  <BaseAlertDialog.Portal>
    <BaseAlertDialog.Backdrop />
    <BaseAlertDialog.Popup>
      <BaseAlertDialog.Title />
      <BaseAlertDialog.Description />
      <BaseAlertDialog.Close />
    </BaseAlertDialog.Popup>
  </BaseAlertDialog.Portal>
</BaseAlertDialog.Root>
```

**Exports needed** (matching current usage in `session-expired-modal.tsx`):

| Old shadcn export | New @azblink/ui export | Maps to |
|---|---|---|
| `AlertDialog` | `AlertDialog` | `BaseAlertDialog.Root` |
| `AlertDialogTrigger` | `AlertDialogTrigger` | `BaseAlertDialog.Trigger` |
| `AlertDialogContent` | `AlertDialogContent` | `BaseAlertDialog.Portal` + `.Backdrop` + `.Popup` (composed) |
| `AlertDialogHeader` | `AlertDialogHeader` | Pure styled `<div>` |
| `AlertDialogFooter` | `AlertDialogFooter` | Pure styled `<div>` |
| `AlertDialogTitle` | `AlertDialogTitle` | `BaseAlertDialog.Title` |
| `AlertDialogDescription` | `AlertDialogDescription` | `BaseAlertDialog.Description` |
| `AlertDialogAction` | `AlertDialogAction` | `BaseAlertDialog.Close` (action = close + submit) |
| `AlertDialogCancel` | `AlertDialogCancel` | `BaseAlertDialog.Close` |

**Key design decision:** `AlertDialogContent` should internally compose `Portal` + `Backdrop` + `Popup` — this matches shadcn's pattern where content auto-includes the overlay. Consumer code stays clean.

**Current usage (session-expired-modal.tsx):**
```tsx
<AlertDialog open={sessionExpiredModalOpen}>
  <AlertDialogContent>
    <AlertDialogHeader>
      <AlertDialogTitle>Session Expired</AlertDialogTitle>
      <AlertDialogDescription>...</AlertDialogDescription>
    </AlertDialogHeader>
    <AlertDialogFooter>
      <AlertDialogCancel onClick={hideSessionExpiredModal}>Dismiss</AlertDialogCancel>
      <AlertDialogAction onClick={handleLoginRedirect}>Log In Again</AlertDialogAction>
    </AlertDialogFooter>
  </AlertDialogContent>
</AlertDialog>
```

**Props:** `AlertDialog` accepts `open`, `onOpenChange`. `AlertDialogAction/Cancel` accept `onClick`, `variant`, `size`.

**Test:** `cd azblink-ui && npm run build`

**Commit:** `feat(ui): add AlertDialog component`

---

### Task 5: Build Menu Component (DropdownMenu replacement)

**New files:**
- `azblink-ui/primitives/Menu/index.ts`
- `azblink-ui/primitives/Menu/Menu.tsx`
- `azblink-ui/primitives/Menu/Menu.module.css`

**Base UI import:** `import { Menu as BaseMenu } from '@base-ui/react/menu';`

**Base UI anatomy:**
```tsx
<BaseMenu.Root>
  <BaseMenu.Trigger />
  <BaseMenu.Portal>
    <BaseMenu.Positioner sideOffset={8}>
      <BaseMenu.Popup>
        <BaseMenu.Item />
        <BaseMenu.Separator />
        <BaseMenu.Group>
          <BaseMenu.GroupLabel />
        </BaseMenu.Group>
        <BaseMenu.RadioGroup>
          <BaseMenu.RadioItem>
            <BaseMenu.RadioItemIndicator />
          </BaseMenu.RadioItem>
        </BaseMenu.RadioGroup>
        <BaseMenu.SubmenuRoot>
          <BaseMenu.SubmenuTrigger />
          <!-- nested portal/positioner/popup -->
        </BaseMenu.SubmenuRoot>
      </BaseMenu.Popup>
    </BaseMenu.Positioner>
  </BaseMenu.Portal>
</BaseMenu.Root>
```

**Export strategy:** Re-export Base UI's compound components with styled wrappers + Azblink naming.

| Old shadcn export | New @azblink/ui export | Maps to |
|---|---|---|
| `DropdownMenu` | `DropdownMenu` | `BaseMenu.Root` |
| `DropdownMenuTrigger` | `DropdownMenuTrigger` | `BaseMenu.Trigger` |
| `DropdownMenuContent` | `DropdownMenuContent` | `BaseMenu.Portal` + `.Positioner` + `.Popup` (composed) |
| `DropdownMenuLabel` | `DropdownMenuLabel` | `BaseMenu.GroupLabel` (inside a `BaseMenu.Group`) |
| `DropdownMenuItem` | `DropdownMenuItem` | `BaseMenu.Item` |
| `DropdownMenuSeparator` | `DropdownMenuSeparator` | `BaseMenu.Separator` |
| `DropdownMenuSub` | `DropdownMenuSub` | `BaseMenu.SubmenuRoot` |
| `DropdownMenuSubTrigger` | `DropdownMenuSubTrigger` | `BaseMenu.SubmenuTrigger` |
| `DropdownMenuSubContent` | `DropdownMenuSubContent` | composed (Portal + Positioner + Popup) |
| `DropdownMenuRadioGroup` | `DropdownMenuRadioGroup` | `BaseMenu.RadioGroup` |
| `DropdownMenuRadioItem` | `DropdownMenuRadioItem` | `BaseMenu.RadioItem` + `.RadioItemIndicator` |

**Key design decision:** Like AlertDialog, `DropdownMenuContent` should internally compose `Portal` + `Positioner` + `Popup` to keep the API surface identical to shadcn's.

**`asChild` on trigger:** Profile dropdown uses `<DropdownMenuTrigger asChild>`. Base UI trigger already renders as `<button>` — for composing with our `Button`, need `render` prop support.

**Current usage (profile-dropdown.tsx):**
```tsx
<DropdownMenu>
  <DropdownMenuTrigger asChild>
    <Button variant="ghost">...</Button>
  </DropdownMenuTrigger>
  <DropdownMenuContent align="end">
    <DropdownMenuLabel>My Account</DropdownMenuLabel>
    <DropdownMenuSeparator />
    <DropdownMenuItem onClick={...}>Profile</DropdownMenuItem>
    <DropdownMenuSub>
      <DropdownMenuSubTrigger>Theme</DropdownMenuSubTrigger>
      <DropdownMenuSubContent>
        <DropdownMenuRadioGroup value={theme} onValueChange={setTheme}>
          <DropdownMenuRadioItem value="dark">Dark</DropdownMenuRadioItem>
          <DropdownMenuRadioItem value="light">Light</DropdownMenuRadioItem>
          <DropdownMenuRadioItem value="system">System</DropdownMenuRadioItem>
        </DropdownMenuRadioGroup>
      </DropdownMenuSubContent>
    </DropdownMenuSub>
    <DropdownMenuSeparator />
    <DropdownMenuItem onClick={logout}>Log out</DropdownMenuItem>
  </DropdownMenuContent>
</DropdownMenu>
```

**Test:** `cd azblink-ui && npm run build`

**Commit:** `feat(ui): add DropdownMenu (Menu) component`

---

### Task 6: Build Tooltip Component

**New files:**
- `azblink-ui/primitives/Tooltip/index.ts`
- `azblink-ui/primitives/Tooltip/Tooltip.tsx`
- `azblink-ui/primitives/Tooltip/Tooltip.module.css`

**Base UI import:** `import { Tooltip as BaseTooltip } from '@base-ui/react/tooltip';`

**Base UI anatomy:**
```tsx
<BaseTooltip.Provider>
  <BaseTooltip.Root>
    <BaseTooltip.Trigger />
    <BaseTooltip.Portal>
      <BaseTooltip.Positioner sideOffset={8}>
        <BaseTooltip.Popup>
          <BaseTooltip.Arrow />
          Tooltip text
        </BaseTooltip.Popup>
      </BaseTooltip.Positioner>
    </BaseTooltip.Portal>
  </BaseTooltip.Root>
</BaseTooltip.Provider>
```

**Export mapping:**

| Old shadcn export | New @azblink/ui export | Maps to |
|---|---|---|
| `TooltipProvider` | `TooltipProvider` | `BaseTooltip.Provider` |
| `Tooltip` | `Tooltip` | `BaseTooltip.Root` |
| `TooltipTrigger` | `TooltipTrigger` | `BaseTooltip.Trigger` |
| `TooltipContent` | `TooltipContent` | `BaseTooltip.Portal` + `.Positioner` + `.Popup` (composed) |

**`asChild` on trigger:** Sidebar uses `<TooltipTrigger asChild>{linkContent}</TooltipTrigger>`. Base UI Trigger's `render` prop handles this.

**Current usage (sidebar.tsx):**
```tsx
<Tooltip>
  <TooltipTrigger asChild>{linkContent}</TooltipTrigger>
  <TooltipContent side="right">{item.label}</TooltipContent>
</Tooltip>
```

**Props:** `TooltipContent` accepts `side`, `sideOffset`, `align`, `className`, `children`.

**Test:** `cd azblink-ui && npm run build`

**Commit:** `feat(ui): add Tooltip component`

---

### Task 7: Build ThemeProvider

**New files:**
- `azblink-ui/providers/ThemeProvider.tsx`
- `azblink-ui/providers/index.ts`

**Responsibilities:**
- Manages `data-theme` attribute on `<html>` element
- Persists to `localStorage` (key: `azblink-theme`)
- Detects system preference via `matchMedia('(prefers-color-scheme: dark)')`
- Exposes `useTheme()` hook returning `{ theme, setTheme, resolvedTheme }`
- Theme values: `'dark' | 'light' | 'system'`

**Replaces:** `useUIStore().theme` / `useUIStore().setTheme` in Zustand `ui-store.ts`

**Test:** `cd azblink-ui && npm run build`

**Commit:** `feat(ui): add ThemeProvider`

---

### Task 8: Update `azblink-ui/index.ts` Exports

Add all new components to the barrel export:

```typescript
export { Checkbox } from './primitives/Checkbox';
export {
  AlertDialog, AlertDialogTrigger, AlertDialogContent,
  AlertDialogHeader, AlertDialogFooter, AlertDialogTitle,
  AlertDialogDescription, AlertDialogAction, AlertDialogCancel
} from './primitives/AlertDialog';
export {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent,
  DropdownMenuLabel, DropdownMenuItem, DropdownMenuSeparator,
  DropdownMenuSub, DropdownMenuSubTrigger, DropdownMenuSubContent,
  DropdownMenuRadioGroup, DropdownMenuRadioItem
} from './primitives/Menu';
export {
  Tooltip, TooltipTrigger, TooltipContent, TooltipProvider
} from './primitives/Tooltip';
export { ThemeProvider, useTheme } from './providers/ThemeProvider';
```

**Test:** `cd azblink-ui && npm run build` — verify all exports in `dist/index.d.ts`

**Commit:** `feat(ui): export all Phase 2 components`

---

### Task 9: Migrate Route Files — Batch 1 (Simplest)

**Strategy:** Change imports, adjust variant/size names per mapping table, replace `asChild` with `render` prop.

#### 9a. `src/frontend/src/routes/settings.tsx`
- Old: `Card, CardContent, CardHeader, CardTitle` from `@/components/ui/card`, `Skeleton` from `@/components/ui/skeleton`
- New: `import { Card, CardContent, CardHeader, CardTitle, Skeleton } from '@azblink/ui';`
- No variant/size changes needed (Card/Skeleton have no variants)

#### 9b. `src/frontend/src/routes/index.tsx`
- Old: `Card, CardContent, CardHeader, CardTitle` from `@/components/ui/card`, `Button` from `@/components/ui/button`, `Skeleton` from `@/components/ui/skeleton`
- New: `import { Card, CardContent, CardHeader, CardTitle, Button, Skeleton } from '@azblink/ui';`
- **Variant change:** `variant="outline"` → `variant="secondary"`
- Remove `@/lib/utils` import if only used for `cn` (import `cn` from `@azblink/ui` instead)

#### 9c. `src/frontend/src/routes/my-profile.tsx`
- Old: `Button`, `Badge`, `Card` (4), `Skeleton`
- New: Single `@azblink/ui` import
- **Variant changes:**
  - `Button variant="outline"` → `variant="secondary"`
  - `Badge variant="secondary"` → `variant="muted"`

#### 9d. `src/frontend/src/routes/directory/orgs/index.tsx`
- Old: `Button`, `Card` (4), `Skeleton`, `cn` from `@/lib/utils`
- New: Single `@azblink/ui` import
- No variant changes (Button uses no variant = default → primary)

**Test after each file:** `cd src/frontend && npx tsc --noEmit` — verify no type errors

**Commit:** `refactor(frontend): migrate batch-1 routes to @azblink/ui`

---

### Task 10: Migrate Route Files — Batch 2 (Forms)

#### 10a. `src/frontend/src/routes/login.tsx`
- Old: `Button`, `Input`, `Label`, `Checkbox`, `Card` (5)
- New: Single `@azblink/ui` import
- **Requires:** Checkbox component (Task 3) to be built first
- No variant/size changes on Button (uses default)

#### 10b. `src/frontend/src/routes/directory/users/new.tsx`
- Old: `Card` (4), `Button`, `Input`, `Label`
- New: Single `@azblink/ui` import
- **Variant change:** `Button variant="outline"` → `variant="secondary"`

#### 10c. `src/frontend/src/routes/directory/users/index.tsx`
- Old: `Input`, `Button`
- New: `import { Input, Button } from '@azblink/ui';`
- **Variant change:** `Button variant="outline"` → `variant="secondary"`
- **`asChild` change:**
  ```tsx
  // Old
  <Button asChild><Link to="/directory/users/new">Add User</Link></Button>
  // New
  <Button render={<Link to="/directory/users/new" />}>Add User</Button>
  ```

#### 10d. `src/frontend/src/routes/directory/users/$uid.tsx`
- Old: `Card` (4), `Badge`, `Button`, `Skeleton`
- New: Single `@azblink/ui` import
- **Variant changes:**
  - `Button variant="outline"` → `variant="secondary"` (3 instances)
  - `Button variant="ghost" size="icon"` → `variant="ghost" size="sm"` + icon className
  - `Button variant="ghost" size="sm"` → `variant="ghost" size="sm"` (same)
- **`asChild` change:** Line 85 `<Button variant="outline" asChild>` → use `render` prop

#### 10e. `src/frontend/src/routes/directory/groups/index.tsx`
- Old: `Input`, `Button`, `Card` (2), `Skeleton`
- New: Single `@azblink/ui` import
- No variant changes

**Test:** `cd src/frontend && npx tsc --noEmit`

**Commit:** `refactor(frontend): migrate batch-2 form routes to @azblink/ui`

---

### Task 11: Migrate Route Files — Batch 3 (Provisioning)

#### 11a. `src/frontend/src/routes/provisioning/tokens.tsx`
- Old: `Button`, `Badge`, `Table` (6), `Skeleton`, `cn` from `@/lib/utils`
- New: Single `@azblink/ui` import (including `cn`)
- **Variant changes:**
  - `Button variant="outline"` → `variant="secondary"` (2 instances)
  - `Button variant="ghost" size="sm"` → same
  - `Badge variant="outline"` → `variant="muted"` (or add outline variant per Task 2)
- **Note:** Badge has dynamic className via `cn(styles[status])` — verify CSS module class compat

#### 11b. `src/frontend/src/routes/provisioning/qr-generator.tsx`
- Old: `Card` (4), `Input`, `Button`, `cn`
- New: Single `@azblink/ui` import
- **Variant changes:**
  - `variant="outline"` → `variant="secondary"`
  - `variant="destructive"` → `variant="danger"`

**Test:** `cd src/frontend && npx tsc --noEmit`

**Commit:** `refactor(frontend): migrate provisioning routes to @azblink/ui`

---

### Task 12: Migrate Feature Components — Batch 1 (Simple)

#### 12a. `src/frontend/src/components/features/stat-card.tsx`
- Old: `Card, CardContent` from `@/components/ui/card`, `cn` from `@/lib/utils`
- New: `import { Card, CardContent, cn } from '@azblink/ui';`

#### 12b. `src/frontend/src/components/features/empty-state.tsx`
- Old: `Button` from `@/components/ui/button`, `cn` from `@/lib/utils`
- New: `import { Button, cn } from '@azblink/ui';`
- **`asChild` change:** Line 55 `<Button asChild variant={...}>` → use `render` prop
- **Variant mapping:** Uses `action.variant ?? 'default'` — need to map `'default'` → `'primary'` in the action type

#### 12c. `src/frontend/src/components/features/startup-check.tsx`
- Old: `Button` from `@/components/ui/button`
- New: `import { Button } from '@azblink/ui';`
- **Variant change:** `variant="outline"` → `variant="secondary"`

#### 12d. `src/frontend/src/components/features/health-status.tsx`
- Old: `Card` (4), `Badge` from ui, `cn` from utils
- New: `import { Card, CardContent, CardHeader, CardTitle, Badge, cn } from '@azblink/ui';`
- **Variant change:** `Badge variant="outline"` → `variant="muted"`

**Test:** `cd src/frontend && npx tsc --noEmit`

**Commit:** `refactor(frontend): migrate simple feature components to @azblink/ui`

---

### Task 13: Migrate Feature Components — Batch 2 (Complex)

#### 13a. `src/frontend/src/components/features/user-table.tsx`
- Old: `Table` (6), `Badge`, `Button`, `Skeleton`
- New: Single `@azblink/ui` import
- **Variant changes:**
  - `Badge variant="outline"` → `variant="muted"`
  - `Button variant="ghost" size="icon"` → `variant="ghost" size="sm"` + icon className

#### 13b. `src/frontend/src/components/features/qr-display.tsx`
- Old: `Card` (4), `Button`, `Badge`, `Skeleton`
- New: Single `@azblink/ui` import
- **Variant changes:**
  - `Badge variant="outline"` → `variant="muted"`
  - `Button variant="outline"` → `variant="secondary"` (3 instances)
  - `Button variant="secondary"` → `variant="secondary"` (same)

**Test:** `cd src/frontend && npx tsc --noEmit`

**Commit:** `refactor(frontend): migrate complex feature components to @azblink/ui`

---

### Task 14: Migrate Feature Components — Batch 3 (AlertDialog + Menu)

**Requires:** Tasks 4 and 5 (AlertDialog and Menu built)

#### 14a. `src/frontend/src/components/features/session-expired-modal.tsx`
- Old: 8 AlertDialog sub-components from `@/components/ui/alert-dialog`
- New: `import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogFooter, AlertDialogTitle, AlertDialogDescription, AlertDialogAction, AlertDialogCancel } from '@azblink/ui';`
- **API should match 1:1** if AlertDialog is designed per Task 4

#### 14b. `src/frontend/src/components/features/profile-dropdown.tsx`
- Old: 6 DropdownMenu sub-components + `DropdownMenuSub/SubTrigger/SubContent` + `RadioGroup/RadioItem`, `Button`, `Badge`
- New: All from `@azblink/ui`
- **`asChild` on trigger:**
  ```tsx
  // Old
  <DropdownMenuTrigger asChild>
    <Button variant="ghost">...</Button>
  </DropdownMenuTrigger>
  // New
  <DropdownMenuTrigger render={<Button variant="ghost" />}>
    ...
  </DropdownMenuTrigger>
  ```
  **Note:** Need to verify Base UI's `render` prop pattern works here — the trigger's children may need restructuring.
- **Variant changes:**
  - `Button variant="ghost"` → same
  - `Badge variant="secondary"` → `variant="muted"`

**Test:** `cd src/frontend && npx tsc --noEmit`

**Commit:** `refactor(frontend): migrate session modal and profile dropdown to @azblink/ui`

---

### Task 15: Migrate Layout Components

#### 15a. `src/frontend/src/components/layout/header.tsx`
- Old: `Button` from `@/components/ui/button`
- New: `import { Button } from '@azblink/ui';`
- **Variant changes:**
  - `variant="ghost" size="icon"` → `variant="ghost" size="sm"` + icon className (4 instances)
  - `variant="ghost"` → same

#### 15b. `src/frontend/src/components/layout/sidebar.tsx`
- Old: `Tooltip, TooltipTrigger, TooltipContent` from `@/components/ui/tooltip`, `cn` from `@/lib/utils`
- New: `import { Tooltip, TooltipTrigger, TooltipContent, cn } from '@azblink/ui';`
- **`asChild` change:**
  ```tsx
  // Old
  <TooltipTrigger asChild>{linkContent}</TooltipTrigger>
  // New
  <TooltipTrigger render={(props) => React.cloneElement(linkContent, props)}>
    {linkContent}
  </TooltipTrigger>
  ```
  **Note:** `linkContent` is a JSX variable — may need `render` prop with cloneElement pattern. Investigate Base UI's composition docs.

**Requires:** Task 6 (Tooltip built)

**Test:** `cd src/frontend && npx tsc --noEmit`

**Commit:** `refactor(frontend): migrate layout components to @azblink/ui`

---

### Task 16: Migrate `__root.tsx` + ThemeProvider

**File:** `src/frontend/src/routes/__root.tsx`

**Changes:**
- Replace `cn` import from `@/lib/utils` → `import { cn, ThemeProvider, useTheme } from '@azblink/ui';`
- Wrap app content in `<ThemeProvider>`
- Remove theme-related state from Zustand `ui-store.ts` (keep `sidebarCollapsed`, `sessionExpiredModalOpen`)

**File:** `src/frontend/src/stores/ui-store.ts`
- Remove `theme`, `setTheme` properties
- Keep `sidebarCollapsed`, `toggleSidebar`, `sessionExpiredModalOpen`, `showSessionExpiredModal`, `hideSessionExpiredModal`

**Requires:** Task 7 (ThemeProvider built)

**Test:** `cd src/frontend && npx tsc --noEmit && npm run dev` — verify app loads, theme toggle works

**Commit:** `refactor(frontend): integrate ThemeProvider, migrate __root.tsx`

---

### Task 17: Update `globals.css` and Theme Tokens

**File:** `src/frontend/src/styles/globals.css`

**Changes:**
- Add `@import '@azblink/ui/dist/index.css';` at top (after Tailwind import)
- This brings in the design tokens from `tokens.css` plus all component styles
- Remove old custom property definitions that are now covered by @azblink/ui tokens
- Keep Tailwind `@theme` block but update token references to use @azblink/ui variable names
- Keep `@layer base` rules but update to use new token names

**Dark/light mode switch:**
- Old: `.dark` class on `<html>`
- New: `data-theme="dark"` / `data-theme="light"` attribute on `<html>`
- Update any Tailwind `dark:` prefixed classes → `[data-theme="dark"]` or use CSS custom properties that auto-switch

**Test:** Visual inspection in browser — both dark and light modes

**Commit:** `refactor(frontend): update globals.css to use @azblink/ui tokens`

---

### Task 18: Font Migration

**File:** `src/frontend/index.html`

**Changes:**
- Replace Google Fonts link: Inter → Outfit, Fira Code → JetBrains Mono
- Old: `family=Inter:wght@...&family=Fira+Code:wght@...`
- New: `family=Outfit:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600`

**File:** `src/frontend/src/styles/globals.css`
- Update `--font-sans` to `'Outfit', sans-serif`
- Update `--font-mono` to `'JetBrains Mono', monospace`
- Or rely on `@azblink/ui/tokens.css` which already defines these

**Test:** Visual inspection — check for layout shifts on all pages

**Commit:** `refactor(frontend): migrate fonts to Outfit + JetBrains Mono`

---

### Task 19: Remove Radix Dependencies

**File:** `src/frontend/package.json`

Remove these dependencies:
```
@radix-ui/react-alert-dialog
@radix-ui/react-checkbox
@radix-ui/react-dropdown-menu
@radix-ui/react-label
@radix-ui/react-slot
@radix-ui/react-tooltip
```

**Also remove** `class-variance-authority` if no longer used (shadcn's CVA variant definitions are gone).

**Keep:** Any Radix packages still used by other libs (check `node_modules/.package-lock.json`).

**Test:** `cd src/frontend && npm install && npx tsc --noEmit && npm run build`

**Commit:** `chore(frontend): remove Radix UI dependencies`

---

### Task 20: Delete shadcn Directory

**Delete:** `src/frontend/src/components/ui/` (entire directory)

Files to delete:
- `alert-dialog.tsx`
- `badge.tsx`
- `button.tsx`
- `card.tsx`
- `checkbox.tsx`
- `dropdown-menu.tsx`
- `input.tsx`
- `label.tsx`
- `skeleton.tsx`
- `table.tsx`
- `tooltip.tsx`

**Also delete:** `src/frontend/components.json` (shadcn CLI config)

**Also consider:** `src/frontend/src/lib/utils.ts` — if only exports `cn()`, delete it (now from `@azblink/ui`)

**Test:** `cd src/frontend && npx tsc --noEmit && npm run build`

**Commit:** `chore(frontend): remove shadcn/ui components and config`

---

### Task 21: Update Vite Config

**File:** `src/frontend/vite.config.ts`

**Changes:**
- Remove `@radix-ui/*` from vendor chunk config (if present)
- Add `@base-ui/react` to vendor chunk or let Vite auto-split
- Add `@azblink/ui` to `optimizeDeps.include` if HMR has issues with workspace packages
- Verify CSS from `@azblink/ui` is properly included in the build

**Test:** `cd src/frontend && npm run build` — verify bundle sizes, no missing CSS

**Commit:** `chore(frontend): update Vite config for @azblink/ui`

---

### Task 22: E2E Smoke Test

**Run:** `just test` from repo root

**Verify:**
- Login flow works (Button, Input, Label, Checkbox, Card)
- Dashboard renders (Card, Button, Skeleton, stat-card)
- User list renders and links work (Input, Button, Table, Badge)
- User detail page renders (Card, Badge, Button, Skeleton)
- QR generator works (Card, Input, Button)
- Settings page renders (Card, Skeleton)
- Profile dropdown opens and theme toggle works (DropdownMenu, RadioGroup)
- Sidebar tooltips appear on collapse (Tooltip)
- Session expired modal appears when token expires (AlertDialog)

**Fix any issues found, then commit:** `test: verify design system migration end-to-end`

---

### Task 23: Update Documentation

**File:** `CLAUDE.md`
- Update "Frontend Development" section to reference `@azblink/ui` instead of shadcn/ui
- Update component locations from `src/frontend/src/components/ui/` to `@azblink/ui`
- Update `just ui-add` command reference (no longer relevant)

**File:** `docs/plans/2025-01-25-enterprise-ui-redesign.md`
- Add note that shadcn migration to @azblink/ui is complete

**File:** `azblink-ui/README.md` (if exists, or create)
- Document all available components and their APIs

**Commit:** `docs: update documentation for @azblink/ui migration`

---

## Execution Order & Dependencies

```
Task 1 (Button variants) ──┐
Task 2 (Badge variants) ───┤
Task 3 (Checkbox) ─────────┼── Task 8 (update exports) ──┐
Task 4 (AlertDialog) ──────┤                              │
Task 5 (Menu) ─────────────┤                              │
Task 6 (Tooltip) ──────────┤                              │
Task 7 (ThemeProvider) ─────┘                              │
                                                           │
Task 9 (migrate batch 1 routes) ──────────────────────────┤─ No deps
Task 10 (migrate batch 2 routes) ─────────────────────────┤─ Needs Task 3
Task 11 (migrate batch 3 routes) ─────────────────────────┤─ No deps
Task 12 (migrate simple features) ────────────────────────┤─ No deps
Task 13 (migrate complex features) ───────────────────────┤─ No deps
Task 14 (migrate AlertDialog+Menu features) ──────────────┤─ Needs Tasks 4,5
Task 15 (migrate layout) ────────────────────────────────┤─ Needs Task 6
Task 16 (ThemeProvider integration) ──────────────────────┤─ Needs Task 7
Task 17 (globals.css) ────────────────────────────────────┤
Task 18 (fonts) ──────────────────────────────────────────┤
                                                           │
Task 19 (remove Radix deps) ──────────────────────────────┤─ After all migrations
Task 20 (delete shadcn dir) ──────────────────────────────┤─ After all migrations
Task 21 (Vite config) ────────────────────────────────────┤─ After cleanup
Task 22 (E2E test) ───────────────────────────────────────┤─ After everything
Task 23 (docs) ───────────────────────────────────────────┘─ After everything
```

## Parallelization Opportunities

- Tasks 1-7 can all be done in parallel (independent component builds)
- Tasks 9, 11, 12 can start immediately after Task 8 (no new components needed)
- Tasks 10, 14, 15 need specific new components built first
- Tasks 19-23 are sequential cleanup after all migrations complete

## Risk Register

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| `render` prop doesn't work like `asChild` in all cases | 30% | Medium | Test each `asChild` usage individually; fallback to restructuring JSX |
| CSS Module class names collide with Tailwind utilities during transition | 15% | Low | Use `cn()` to merge; @azblink/ui classes have scoped module names |
| Base UI AlertDialog/Menu API doesn't match shadcn's convenience wrappers | 25% | Medium | Design wrapper components that hide API differences (Tasks 4,5) |
| Font change causes layout shifts | 10% | Low | Outfit has similar metrics to Inter; visual QA on all pages |
| `data-theme` attribute doesn't work with Tailwind `dark:` prefix | 20% | Medium | Replace `dark:` prefixes with CSS custom properties or use Tailwind v4 `@variant` |
| Workspace package CSS not included in Vite build | 15% | Medium | Add `@azblink/ui` to `optimizeDeps.include`; test early in Task 8 |

---

## Execution Log

**Completed 2026-02-07:**
- Tasks 1-8: Component gaps filled, new components built (Checkbox, AlertDialog, DropdownMenu, Tooltip, ThemeProvider), exports updated
- Tasks 9-13: All route, feature, and layout files migrated to `@azblink/ui`
- Tasks 14-15: AlertDialog, DropdownMenu, Tooltip migrations complete
- Task 16: ThemeProvider integrated into `main.tsx`, ui-store theme state removed
- Task 17: `globals.css` updated to use `[data-theme="dark"]`, then consolidated with `@theme inline` bridge
- Task 18: Fonts migrated to Outfit + JetBrains Mono
- Tasks 19-20: Radix deps removed, shadcn `components/ui/` directory deleted, `utils.ts` deleted
- Task 21: Vite config verified (chunks unchanged, workspace package auto-inlined)
- Task 22: Build passes clean — @azblink/ui 19.74KB JS + 14.26KB CSS, frontend 22 chunks in 3.36s
- Task 23: CLAUDE.md updated, this plan marked complete

**Consolidation (separate plan — `2026-02-07-design-system-consolidation.md`):**
- `globals.css` rewritten: `@theme inline` bridges design tokens → Tailwind utility classes
- Both dark mode blocks removed (tokens.css handles dark/light via `[data-theme]`)
- `@azblink/ui/tokens.css` and `@azblink/ui/styles.css` imported
- `components.json` (shadcn CLI config) deleted
- npm install pruned 48 stale packages

**Deviations from plan:**
- `outline` added as a real Button/Badge variant (not mapped to `secondary`) — eliminated variant mapping across 13+ files
- `icon` added as a real Button size (not approximated with `sm` + className)
- Tailwind CSS 4 `@theme inline` used instead of bare `@theme` for dynamic `var()` bridging (researched via Context7)
- Shadows moved from bare `@theme` to `@theme inline` to avoid self-referential variable loop
