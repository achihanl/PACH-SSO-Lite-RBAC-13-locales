# Full-Page Preview Enhancement Design

**Date:** 2026-01-21
**Status:** Ready for Implementation

## Goal

Transform the mockup preview page from a 2x2 grid layout to full-page previews with tab navigation, giving each mockup panel the full viewport height for better demonstration.

## Current vs New

### Current Layout
```
┌──────────────────┬──────────────────┐
│  Desktop Dir     │  Dir Manager     │
│  (640px height)  │  (640px height)  │
├──────────────────┼──────────────────┤
│  Mobile Dir      │  My Profile      │
│  (720px height)  │  (720px height)  │
└──────────────────┴──────────────────┘
```

### New Layout
```
┌─────────────────────────────────────────┐
│  Header: Title + Description            │
├─────────────────────────────────────────┤
│ [Tab 1] [Tab 2] [Tab 3] [Tab 4]         │
├─────────────────────────────────────────┤
│                                         │
│    Full-viewport iframe                 │
│    (100vh - header - tabs)              │
│                                         │
└─────────────────────────────────────────┘
```

## Components

### 1. Header Section
- Title: "Azblink Directory – HTML Mockup Preview"
- Subtitle: "Open and preview the mockup pages in your browser."
- Keep existing styling (gray text, centered)

### 2. Tab Bar
- 4 horizontal tabs with labels:
  1. "Desktop Directory"
  2. "Directory Manager"
  3. "Mobile Directory"
  4. "My Profile"
- Active tab: blue text, bold, blue underline
- Inactive tabs: gray text, hover turns blue
- Tabs stick below header

### 3. Preview Area
- Single iframe that shows/hides based on active tab
- Height: `calc(100vh - header - tabs)` for full viewport fill
- Width: 100%
- No border/shadow on the iframe itself (clean look)

## Behavior

1. **Tab switching**: Click tab → show corresponding iframe, hide others
2. **URL hash**: Update hash on tab change (`#desktop`, `#manager`, `#mobile`, `#profile`)
3. **Deep linking**: Load page with hash → activate that tab
4. **Default**: First tab (Desktop Directory) active on fresh load

## Technical Approach

### HTML Structure
```html
<body class="h-screen flex flex-col">
  <!-- Header -->
  <header class="p-4 border-b">...</header>

  <!-- Tab bar -->
  <nav class="flex border-b">
    <button data-tab="desktop" class="tab active">Desktop Directory</button>
    <button data-tab="manager" class="tab">Directory Manager</button>
    <button data-tab="mobile" class="tab">Mobile Directory</button>
    <button data-tab="profile" class="tab">My Profile</button>
  </nav>

  <!-- Preview panels -->
  <main class="flex-1 relative">
    <iframe id="desktop" src="directory_fixed.html" class="panel active"></iframe>
    <iframe id="manager" src="directory_manager_fixed.html" class="panel"></iframe>
    <iframe id="mobile" src="directory_mobile_fixed.html" class="panel"></iframe>
    <iframe id="profile" src="my_profile.html" class="panel"></iframe>
  </main>
</body>
```

### CSS
```css
.panel {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  display: none;
}
.panel.active {
  display: block;
}
.tab {
  padding: 0.75rem 1.5rem;
  color: #6b7280;
  border-bottom: 2px solid transparent;
}
.tab.active {
  color: #2563eb;
  font-weight: 600;
  border-bottom-color: #2563eb;
}
```

### JavaScript
```javascript
const tabs = document.querySelectorAll('.tab');
const panels = document.querySelectorAll('.panel');

function activateTab(tabId) {
  tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === tabId));
  panels.forEach(p => p.classList.toggle('active', p.id === tabId));
  history.replaceState(null, '', '#' + tabId);
}

tabs.forEach(tab => {
  tab.addEventListener('click', () => activateTab(tab.dataset.tab));
});

// Load from hash or default to first tab
const hash = location.hash.slice(1);
activateTab(hash || 'desktop');
```

## File to Modify

- `src/ui/index.html` - Complete rewrite

## Success Criteria

- [ ] All 4 mockups accessible via tabs
- [ ] Active tab visually distinguished
- [ ] iframe fills remaining viewport height
- [ ] URL hash updates on tab change
- [ ] Deep linking works (e.g., `/index.html#mobile` opens Mobile tab)
- [ ] Responsive - works on different screen sizes
