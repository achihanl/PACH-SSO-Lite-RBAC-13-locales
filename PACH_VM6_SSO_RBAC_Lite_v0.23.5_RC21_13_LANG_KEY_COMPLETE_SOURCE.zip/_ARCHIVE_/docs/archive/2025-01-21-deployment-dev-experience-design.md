# Deployment Dev Experience Design

**Date:** 2025-01-21
**Status:** Approved
**Goal:** Transform `deploy/` into a complete local dev environment with fast startup, hot reload, and OpenLDAP pre-seeded with test data.

---

## 1. Architecture Overview

### Directory Structure
```
deploy/
├── README.md                    # Quick-start guide
├── DEPLOYMENT_SPEC.md           # Full deployment specification
├── docker-compose.yml           # Dev stack (replaces current)
├── Dockerfile.api               # Pre-built API image
├── ldap/
│   └── bootstrap.ldif           # Org structure + test users
├── runtime/
│   └── breakglass.json          # Dev breakglass credentials
└── .env.example                 # Environment template
```

### Services Stack
1. **postgres:16** — Database, persistent volume
2. **openldap** (osixia/openldap:1.5.0) — Pre-seeded with demo org tree
3. **directory-api** — Pre-built image with deps, mounts `api/` for hot reload

### Key Improvements
- Pre-built image eliminates `pip install` on every restart (~30s → ~2s startup)
- Volume mount `api/` directory enables hot reload via uvicorn `--reload`
- OpenLDAP seeded with same data structure as demo mode
- Single `docker compose up` gets everything running

---

## 2. OpenLDAP Configuration

### Image & Settings
- Image: `osixia/openldap:1.5.0`
- Domain: `azblink.com` → `dc=azblink,dc=com`
- Admin DN: `cn=admin,dc=azblink,dc=com`
- Admin Password: `adminpassword`
- Ports: 389 (LDAP), 636 (LDAPS)

### Bootstrap LDIF Structure
```
dc=azblink,dc=com
├── ou=org                        # Organization tree
│   └── ou=GlobalHQ
│       ├── ou=Engineering
│       │   ├── ou=Platform
│       │   └── ou=Infrastructure
│       ├── ou=Marketing
│       └── ou=Legal
├── ou=people                     # User accounts (12 users)
│   ├── uid=alex (Alex Chen)
│   ├── uid=maria (Maria Santos)
│   ├── uid=james (James Wilson)
│   └── ...
└── ou=groups                     # Security groups
    ├── cn=IT-Admins
    ├── cn=All-Employees
    ├── cn=Managers
    └── cn=Finance
```

Data matches `DEMO_ORG_TREE`, `DEMO_USERS`, and `DEMO_GROUPS` from UI files exactly.

---

## 3. API Image & Hot Reload

### Dockerfile.api
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY api/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
```

### Volume Mounts
- `../api:/app` — Source code for hot reload
- `./runtime:/etc/azblink/directory` — Runtime config

### Startup Time Comparison
| Scenario | Current | New |
|----------|---------|-----|
| First run | ~45s | ~45s (docker build) |
| Subsequent runs | ~30s | ~2s |
| Code change | ~30s restart | ~1s auto-reload |

---

## 4. Environment Configuration

### .env.example
```bash
# Database
POSTGRES_USER=azblink_directory
POSTGRES_PASSWORD=azblink_directory
POSTGRES_DB=azblink_directory

# LDAP
LDAP_URI=ldap://openldap:389
LDAP_BASE_DN=dc=azblink,dc=com
LDAP_TENANT=azblink
LDAP_BIND_DN=cn=admin,dc=azblink,dc=com
LDAP_BIND_PW=adminpassword

# API
REQUIRE_OIDC_AUTH=false
ALLOW_BOOTSTRAP_WITHOUT_OIDC=true
ORG_QR_SIGNING_SECRET=dev_signing_secret_change_in_prod
```

---

## 5. Documentation

### README.md (~50 lines)
- Quick start commands
- Service URLs and credentials table
- Hot reload usage
- Useful commands

### DEPLOYMENT_SPEC.md (~200 lines)
1. Overview — Purpose, audience, prerequisites
2. Architecture — Service diagram, port mappings, data flow
3. Configuration — All environment variables with descriptions
4. LDAP Schema — DN structure, objectClasses, required attributes
5. Bootstrap Data — User/group/org definitions
6. Development Workflow — Build, run, test, debug
7. Troubleshooting — Common issues and solutions
8. Production Notes — What changes for prod deployment

---

## 6. Files to Create

| File | Purpose | ~Lines |
|------|---------|--------|
| `deploy/docker-compose.yml` | Full dev stack | 80 |
| `deploy/Dockerfile.api` | Pre-built Python image | 12 |
| `deploy/ldap/bootstrap.ldif` | Org tree, 12 users, 4 groups | 200 |
| `deploy/runtime/breakglass.json` | Dev breakglass credentials | 10 |
| `deploy/.env.example` | Environment variable template | 20 |
| `deploy/README.md` | Quick-start guide | 50 |
| `deploy/DEPLOYMENT_SPEC.md` | Full deployment specification | 200 |

---

## 7. Usage

```bash
cd v1.0-baseline/deploy

# First time (builds image)
docker compose up --build

# Subsequent runs (instant)
docker compose up

# View logs
docker compose logs -f directory-api

# Query LDAP
docker compose exec openldap ldapsearch -x -b "dc=azblink,dc=com"

# Reset all data
docker compose down -v
```

### UI Testing
```
http://localhost:8000/docs          # API docs
../ui/directory_fixed.html?api=http://localhost:8000
```
