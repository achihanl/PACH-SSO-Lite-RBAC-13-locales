# Deployment Dev Experience Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Transform `v1.0-baseline/deploy/` into a complete local dev environment with fast startup, hot reload, and OpenLDAP pre-seeded with test data matching the UI demo data.

**Architecture:** Three-service Docker Compose stack (Postgres, OpenLDAP, API) with pre-built Python image for fast restarts, volume-mounted source for hot reload, and LDIF-seeded OpenLDAP matching `DEMO_ORG_NODES`, `DEMO_PEOPLE`, and `DEMO_GROUPS` from `ui/directory_fixed.html`.

**Tech Stack:** Docker Compose 3.9, Python 3.11, osixia/openldap:1.5.0, Postgres 16, uvicorn with --reload

---

## Task 1: Create Dockerfile.api

**Files:**
- Create: `v1.0-baseline/deploy/Dockerfile.api`

**Context:** We install dependencies at build time for fast restarts. The source code is mounted at runtime via docker-compose volume. We install deps system-wide (not in /app) so the volume mount of /app doesn't shadow them.

**Step 1: Create the Dockerfile**

```dockerfile
FROM python:3.11-slim

# Install dependencies system-wide (not in /app) so volume mount doesn't shadow them
COPY api/requirements.txt /tmp/requirements.txt
RUN pip install --no-cache-dir -r /tmp/requirements.txt && rm /tmp/requirements.txt

# Working directory where source will be mounted
WORKDIR /app

# Source code mounted at runtime via docker-compose
# This enables hot reload without rebuild

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
```

**Step 2: Verify Dockerfile syntax**

Run: `docker build -f v1.0-baseline/deploy/Dockerfile.api -t test-dockerfile v1.0-baseline 2>&1 | head -20`
Expected: Build starts successfully (may fail on COPY, that's fine - we're just validating syntax)

**Step 3: Commit**

```bash
git add v1.0-baseline/deploy/Dockerfile.api
git commit -m "feat(deploy): add Dockerfile.api for pre-built Python image"
```

---

## Task 2: Create .env.example

**Files:**
- Create: `v1.0-baseline/deploy/.env.example`

**Step 1: Create the environment template**

```bash
# Database (Postgres 16)
POSTGRES_USER=azblink_directory
POSTGRES_PASSWORD=azblink_directory
POSTGRES_DB=azblink_directory

# LDAP (osixia/openldap)
LDAP_ORGANISATION=AZBlink
LDAP_DOMAIN=azblink.com
LDAP_ADMIN_PASSWORD=adminpassword

# API LDAP connection
LDAP_URI=ldap://openldap:389
LDAP_BASE_DN=dc=azblink,dc=com
LDAP_TENANT=azblink
LDAP_BIND_DN=cn=admin,dc=azblink,dc=com
LDAP_BIND_PW=adminpassword

# API authentication
REQUIRE_OIDC_AUTH=false
ALLOW_BOOTSTRAP_WITHOUT_OIDC=true

# API secrets
ORG_QR_SIGNING_SECRET=dev_signing_secret_change_in_prod

# API runtime config
BREAKGLASS_FILE=/etc/azblink/directory/breakglass.json
```

**Step 2: Verify file created**

Run: `cat v1.0-baseline/deploy/.env.example | wc -l`
Expected: ~20 lines

**Step 3: Commit**

```bash
git add v1.0-baseline/deploy/.env.example
git commit -m "feat(deploy): add .env.example template"
```

**Step 4: Add .env to .gitignore**

Append to `v1.0-baseline/deploy/.gitignore` (create if not exists):
```
.env
```

**Step 5: Commit gitignore**

```bash
git add v1.0-baseline/deploy/.gitignore
git commit -m "chore(deploy): ignore .env file"
```

---

## Task 3: Create bootstrap.ldif

**Files:**
- Create: `v1.0-baseline/deploy/ldap/bootstrap.ldif`

**Context:** This LDIF seeds OpenLDAP with data matching `DEMO_ORG_NODES`, `DEMO_PEOPLE`, and `DEMO_GROUPS` from `ui/directory_fixed.html`. The osixia/openldap image auto-loads `.ldif` files from `/container/service/slapd/assets/config/bootstrap/ldif/custom/`.

**Important:** Bootstrap LDIF only runs on first container start (when volumes are empty). If you modify bootstrap.ldif and want to reload, run `docker compose down -v` to delete volumes first.

**Step 1: Create ldap directory**

Run: `mkdir -p v1.0-baseline/deploy/ldap`

**Step 2: Create the bootstrap LDIF**

```ldif
# Bootstrap LDIF for AZBlink Directory Development
# Matches DEMO_ORG_NODES, DEMO_PEOPLE, DEMO_GROUPS from ui/directory_fixed.html
#
# Domain: dc=azblink,dc=com
# Admin: cn=admin,dc=azblink,dc=com / adminpassword

# ============================================================
# Organizational Units (top-level containers)
# ============================================================

dn: ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: org
description: Organization tree

dn: ou=people,dc=azblink,dc=com
objectClass: organizationalUnit
ou: people
description: User accounts

dn: ou=groups,dc=azblink,dc=com
objectClass: organizationalUnit
ou: groups
description: Security groups

# ============================================================
# Organization Tree (matches DEMO_ORG_NODES)
# ============================================================

# Global Headquarters (root)
dn: ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: GlobalHQ
description: Global Headquarters

# Engineering (under HQ)
dn: ou=Engineering,ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: Engineering
description: Engineering department

# Platform (under Engineering)
dn: ou=Platform,ou=Engineering,ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: Platform
description: Platform team

# Security (under Platform)
dn: ou=Security,ou=Platform,ou=Engineering,ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: Security
description: Security team

# Edge Systems (under Platform)
dn: ou=EdgeSystems,ou=Platform,ou=Engineering,ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: EdgeSystems
description: Edge Systems team

# Product Engineering (under Engineering)
dn: ou=ProductEngineering,ou=Engineering,ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: ProductEngineering
description: Product Engineering team

# Marketing (under HQ)
dn: ou=Marketing,ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: Marketing
description: Marketing department

# Brand (under Marketing)
dn: ou=Brand,ou=Marketing,ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: Brand
description: Brand team

# Demand Gen (under Marketing)
dn: ou=DemandGen,ou=Marketing,ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: DemandGen
description: Demand Generation team

# Legal (under HQ)
dn: ou=Legal,ou=GlobalHQ,ou=org,dc=azblink,dc=com
objectClass: organizationalUnit
ou: Legal
description: Legal department

# ============================================================
# People (matches DEMO_PEOPLE)
# Using inetOrgPerson objectClass for rich attributes
# ============================================================

# Robert Lin - VP Engineering (manager of alex, james)
dn: uid=robert,ou=people,dc=azblink,dc=com
objectClass: inetOrgPerson
objectClass: organizationalPerson
objectClass: person
uid: robert
cn: Robert Lin
sn: Lin
givenName: Robert
displayName: Robert Lin
title: VP of Engineering
mail: robert.lin@azblink.com
telephoneNumber: 8801
l: Taipei, TW
ou: Engineering
userPassword: password123

# Alex Chen - Senior NFV Architect (manager: robert, reports: sarah)
dn: uid=alex,ou=people,dc=azblink,dc=com
objectClass: inetOrgPerson
objectClass: organizationalPerson
objectClass: person
uid: alex
cn: Alex Chen
sn: Chen
givenName: Alex
displayName: Alex Chen
title: Senior NFV Architect
mail: a.chen@azblink.com
telephoneNumber: 8824
l: Taipei, TW
ou: Security
manager: uid=robert,ou=people,dc=azblink,dc=com
userPassword: password123

# Sarah Kim - Network Automation Engineer (manager: alex)
dn: uid=sarah,ou=people,dc=azblink,dc=com
objectClass: inetOrgPerson
objectClass: organizationalPerson
objectClass: person
uid: sarah
cn: Sarah Kim
sn: Kim
givenName: Sarah
displayName: Sarah Kim
title: Network Automation Engineer
mail: sarah.kim@azblink.com
telephoneNumber: 8842
l: Taipei, TW
ou: EdgeSystems
manager: uid=alex,ou=people,dc=azblink,dc=com
userPassword: password123

# James Miller - Product Engineer (manager: robert)
dn: uid=james,ou=people,dc=azblink,dc=com
objectClass: inetOrgPerson
objectClass: organizationalPerson
objectClass: person
uid: james
cn: James Miller
sn: Miller
givenName: James
displayName: James Miller
title: Product Engineer
mail: james.miller@azblink.com
telephoneNumber: 8831
l: Hsinchu, TW
ou: ProductEngineering
manager: uid=robert,ou=people,dc=azblink,dc=com
userPassword: password123

# Mei Wang - Brand Strategist
dn: uid=mei,ou=people,dc=azblink,dc=com
objectClass: inetOrgPerson
objectClass: organizationalPerson
objectClass: person
uid: mei
cn: Mei Wang
sn: Wang
givenName: Mei
displayName: Mei Wang
title: Brand Strategist
mail: mei.wang@azblink.com
telephoneNumber: 8702
l: Taipei, TW
ou: Brand
userPassword: password123

# Kevin Huang - Demand Generation Lead
dn: uid=kevin,ou=people,dc=azblink,dc=com
objectClass: inetOrgPerson
objectClass: organizationalPerson
objectClass: person
uid: kevin
cn: Kevin Huang
sn: Huang
givenName: Kevin
displayName: Kevin Huang
title: Demand Generation Lead
mail: kevin.huang@azblink.com
telephoneNumber: 8713
l: Taipei, TW
ou: DemandGen
userPassword: password123

# Laura Chen - Corporate Counsel
dn: uid=laura,ou=people,dc=azblink,dc=com
objectClass: inetOrgPerson
objectClass: organizationalPerson
objectClass: person
uid: laura
cn: Laura Chen
sn: Chen
givenName: Laura
displayName: Laura Chen
title: Corporate Counsel
mail: laura.chen@azblink.com
telephoneNumber: 8608
l: Taipei, TW
ou: Legal
userPassword: password123

# ============================================================
# Groups (matches DEMO_GROUPS + additional useful groups)
# Using groupOfNames objectClass
# ============================================================

# IT-Admins group
dn: cn=IT-Admins,ou=groups,dc=azblink,dc=com
objectClass: groupOfNames
cn: IT-Admins
description: IT Administrators with elevated privileges
member: uid=robert,ou=people,dc=azblink,dc=com
member: uid=alex,ou=people,dc=azblink,dc=com

# Engineering group
dn: cn=Engineering,ou=groups,dc=azblink,dc=com
objectClass: groupOfNames
cn: Engineering
description: All Engineering staff
member: uid=robert,ou=people,dc=azblink,dc=com
member: uid=alex,ou=people,dc=azblink,dc=com
member: uid=sarah,ou=people,dc=azblink,dc=com
member: uid=james,ou=people,dc=azblink,dc=com

# All-Staff group
dn: cn=All-Staff,ou=groups,dc=azblink,dc=com
objectClass: groupOfNames
cn: All-Staff
description: All employees
member: uid=robert,ou=people,dc=azblink,dc=com
member: uid=alex,ou=people,dc=azblink,dc=com
member: uid=sarah,ou=people,dc=azblink,dc=com
member: uid=james,ou=people,dc=azblink,dc=com
member: uid=mei,ou=people,dc=azblink,dc=com
member: uid=kevin,ou=people,dc=azblink,dc=com
member: uid=laura,ou=people,dc=azblink,dc=com

# Managers group
dn: cn=Managers,ou=groups,dc=azblink,dc=com
objectClass: groupOfNames
cn: Managers
description: People managers
member: uid=robert,ou=people,dc=azblink,dc=com
member: uid=alex,ou=people,dc=azblink,dc=com
```

**Step 3: Verify LDIF syntax (basic check)**

Run: `grep -c "^dn:" v1.0-baseline/deploy/ldap/bootstrap.ldif`
Expected: 24 (3 top-level OUs + 10 org nodes + 7 people + 4 groups)

**Step 4: Commit**

```bash
git add v1.0-baseline/deploy/ldap/bootstrap.ldif
git commit -m "feat(deploy): add OpenLDAP bootstrap LDIF with demo data"
```

---

## Task 4: Create breakglass.json

**Files:**
- Create: `v1.0-baseline/deploy/runtime/breakglass.json`

**Context:** The API's breakglass loader (`main.py:103-129`) requires `expires_at` to be a valid ISO datetime string and `allow_from` to match the client IP. For Docker, the API container sees requests from the Docker network gateway IP. We set `allow_from: ["0.0.0.0/0"]` to allow all IPs in dev (still time-limited). Set `mode: "admin_recovery"` to allow full API access during dev.

**Step 1: Create dev breakglass credentials**

```json
{
  "enabled": true,
  "mode": "admin_recovery",
  "allow_from": ["127.0.0.1", "::1", "172.16.0.0/12", "192.168.0.0/16", "10.0.0.0/8"],
  "expires_at": "2030-12-31T23:59:59+00:00",
  "note": "Development breakglass - long expiry for dev convenience. DO NOT use in production."
}
```

**Step 2: Create runtime directory and remove .keep**

Run: `mkdir -p v1.0-baseline/deploy/runtime && rm -f v1.0-baseline/deploy/runtime/.keep`

**Step 3: Commit**

```bash
git add v1.0-baseline/deploy/runtime/breakglass.json
git rm --cached v1.0-baseline/deploy/runtime/.keep 2>/dev/null || true
git commit -m "feat(deploy): add dev breakglass credentials"
```

---

## Task 5: Create docker-compose.yml

**Files:**
- Modify: `v1.0-baseline/deploy/docker-compose.yml` (replace entirely)

**Step 1: Replace docker-compose.yml**

```yaml
version: "3.9"

services:
  # PostgreSQL 16 - persistent database
  postgres:
    image: postgres:16
    container_name: azblink-postgres
    environment:
      POSTGRES_USER: ${POSTGRES_USER:-azblink_directory}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-azblink_directory}
      POSTGRES_DB: ${POSTGRES_DB:-azblink_directory}
    ports:
      - "5432:5432"
    volumes:
      - azblink_pg_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U azblink_directory"]
      interval: 5s
      timeout: 5s
      retries: 5

  # OpenLDAP - pre-seeded with demo org structure
  openldap:
    image: osixia/openldap:1.5.0
    container_name: azblink-openldap
    environment:
      LDAP_ORGANISATION: ${LDAP_ORGANISATION:-AZBlink}
      LDAP_DOMAIN: ${LDAP_DOMAIN:-azblink.com}
      LDAP_ADMIN_PASSWORD: ${LDAP_ADMIN_PASSWORD:-adminpassword}
      LDAP_CONFIG_PASSWORD: ${LDAP_ADMIN_PASSWORD:-adminpassword}
      LDAP_READONLY_USER: "false"
      LDAP_TLS: "false"
    ports:
      - "389:389"
      - "636:636"
    volumes:
      - azblink_ldap_data:/var/lib/ldap
      - azblink_ldap_config:/etc/ldap/slapd.d
      - ./ldap/bootstrap.ldif:/container/service/slapd/assets/config/bootstrap/ldif/custom/bootstrap.ldif:ro
    command: --copy-service
    healthcheck:
      test: ["CMD", "ldapsearch", "-x", "-H", "ldap://localhost:389", "-b", "dc=azblink,dc=com", "-D", "cn=admin,dc=azblink,dc=com", "-w", "adminpassword", "(objectClass=*)"]
      interval: 5s
      timeout: 5s
      retries: 10
      start_period: 10s

  # Directory API - pre-built image with hot reload
  directory-api:
    build:
      context: ..
      dockerfile: deploy/Dockerfile.api
    container_name: azblink-directory-api
    volumes:
      # Mount source code for hot reload
      - ../api:/app:ro
      # Runtime config (breakglass, etc)
      - ./runtime:/etc/azblink/directory:ro
    environment:
      # Database
      DATABASE_URL: postgresql+psycopg2://${POSTGRES_USER:-azblink_directory}:${POSTGRES_PASSWORD:-azblink_directory}@postgres:5432/${POSTGRES_DB:-azblink_directory}
      # LDAP
      LDAP_URI: ${LDAP_URI:-ldap://openldap:389}
      LDAP_BASE_DN: ${LDAP_BASE_DN:-dc=azblink,dc=com}
      LDAP_TENANT: ${LDAP_TENANT:-azblink}
      LDAP_BIND_DN: ${LDAP_BIND_DN:-cn=admin,dc=azblink,dc=com}
      LDAP_BIND_PW: ${LDAP_BIND_PW:-adminpassword}
      # Auth
      REQUIRE_OIDC_AUTH: ${REQUIRE_OIDC_AUTH:-false}
      ALLOW_BOOTSTRAP_WITHOUT_OIDC: ${ALLOW_BOOTSTRAP_WITHOUT_OIDC:-true}
      # Secrets
      ORG_QR_SIGNING_SECRET: ${ORG_QR_SIGNING_SECRET:-dev_signing_secret_change_in_prod}
      BREAKGLASS_FILE: ${BREAKGLASS_FILE:-/etc/azblink/directory/breakglass.json}
    ports:
      - "8000:8000"
    depends_on:
      postgres:
        condition: service_healthy
      openldap:
        condition: service_healthy

volumes:
  azblink_pg_data:
  azblink_ldap_data:
  azblink_ldap_config:
```

**Step 2: Validate compose file**

Run: `cd v1.0-baseline/deploy && docker compose config --quiet && echo "Valid compose file" || echo "Invalid compose file"`
Expected: "Valid compose file"

**Step 3: Commit**

```bash
git add v1.0-baseline/deploy/docker-compose.yml
git commit -m "feat(deploy): update docker-compose with OpenLDAP and pre-built API image"
```

---

## Task 6: Create README.md

**Files:**
- Create: `v1.0-baseline/deploy/README.md`

**Step 1: Create quick-start README**

```markdown
# AZBlink Directory - Local Development

Quick-start guide for running the Directory API locally with Docker Compose.

## Prerequisites

- Docker & Docker Compose v2+
- ~2GB disk space

## Quick Start

```bash
# First time (builds API image, ~45s)
docker compose up --build

# Subsequent runs (instant, ~2s)
docker compose up

# Background mode
docker compose up -d
```

## Services

| Service | URL | Credentials |
|---------|-----|-------------|
| Directory API | http://localhost:8000 | - |
| API Docs | http://localhost:8000/docs | - |
| PostgreSQL | localhost:5432 | azblink_directory / azblink_directory |
| OpenLDAP | localhost:389 | cn=admin,dc=azblink,dc=com / adminpassword |

## Hot Reload

The API auto-reloads when you edit files in `../api/`. Watch logs:

```bash
docker compose logs -f directory-api
```

## Test Data

OpenLDAP is pre-seeded with:
- **7 users**: robert, alex, sarah, james, mei, kevin, laura
- **4 groups**: IT-Admins, Engineering, All-Staff, Managers
- **10 org units**: GlobalHQ → Engineering/Marketing/Legal → sub-teams

All user passwords: `password123`

## Useful Commands

```bash
# View all logs
docker compose logs -f

# Query LDAP users
docker compose exec openldap ldapsearch -x -b "ou=people,dc=azblink,dc=com" -D "cn=admin,dc=azblink,dc=com" -w adminpassword

# Query LDAP org tree
docker compose exec openldap ldapsearch -x -b "ou=org,dc=azblink,dc=com" -D "cn=admin,dc=azblink,dc=com" -w adminpassword "(objectClass=organizationalUnit)"

# Postgres shell
docker compose exec postgres psql -U azblink_directory

# Reset everything (deletes all data)
docker compose down -v
```

## UI Testing

Open the UI with API backend:
```
../ui/directory_fixed.html?api=http://localhost:8000
```

## Troubleshooting

**API won't start?**
```bash
docker compose logs directory-api
```

**LDAP connection refused?**
Wait for OpenLDAP to fully initialize (~10s on first start).

**Reset to clean state:**
```bash
docker compose down -v
docker compose up --build
```

## See Also

- [DEPLOYMENT_SPEC.md](./DEPLOYMENT_SPEC.md) - Full deployment specification
```

**Step 2: Verify README created**

Run: `wc -l v1.0-baseline/deploy/README.md`
Expected: ~90 lines

**Step 3: Commit**

```bash
git add v1.0-baseline/deploy/README.md
git commit -m "docs(deploy): add quick-start README"
```

---

## Task 7: Create DEPLOYMENT_SPEC.md

**Files:**
- Create: `v1.0-baseline/deploy/DEPLOYMENT_SPEC.md`

**Step 1: Create detailed deployment specification**

```markdown
# AZBlink Directory - Deployment Specification

Complete technical specification for the Directory API development environment.

## 1. Overview

### Purpose
Local development environment for the AZBlink Directory API with:
- Pre-built Docker images for fast startup (~2s vs ~30s)
- Hot reload for Python code changes
- Pre-seeded OpenLDAP with realistic test data
- PostgreSQL for persistent application state

### Audience
- Developers working on Directory API
- QA testing directory features
- Demo/training environments

### Prerequisites
- Docker Engine 20.10+
- Docker Compose v2.0+
- 2GB available disk space
- Ports 389, 5432, 8000 available

## 2. Architecture

### Service Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        Docker Network                           │
│                                                                 │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────┐ │
│  │  PostgreSQL │    │  OpenLDAP   │    │   Directory API     │ │
│  │   :5432     │    │   :389      │    │      :8000          │ │
│  │             │◄───┤             │◄───┤                     │ │
│  │  App state  │    │  User/Org   │    │  ../api/ mounted    │ │
│  │  (orgdb)    │    │  directory  │    │  hot reload enabled │ │
│  └─────────────┘    └─────────────┘    └─────────────────────┘ │
│        │                  │                      │              │
│        ▼                  ▼                      ▼              │
│   [pg_data]         [ldap_data]           [source code]        │
│    volume           [ldap_config]          bind mount          │
│                       volumes                                   │
└─────────────────────────────────────────────────────────────────┘
```

### Port Mappings

| Port | Service | Protocol | Description |
|------|---------|----------|-------------|
| 389 | OpenLDAP | LDAP | Directory queries |
| 636 | OpenLDAP | LDAPS | TLS directory (disabled by default) |
| 5432 | PostgreSQL | PostgreSQL | Database |
| 8000 | Directory API | HTTP | REST API |

### Data Flow

1. **User request** → Directory API (:8000)
2. **Auth check** → LDAP bind verify (if OIDC disabled, breakglass)
3. **User/Group queries** → OpenLDAP (:389)
4. **Org/QR state** → PostgreSQL (:5432)
5. **Response** → JSON to client

## 3. Configuration

### Environment Variables

Copy `.env.example` to `.env` and customize:

```bash
cp .env.example .env
```

#### Database (PostgreSQL)

| Variable | Default | Description |
|----------|---------|-------------|
| `POSTGRES_USER` | azblink_directory | Database username |
| `POSTGRES_PASSWORD` | azblink_directory | Database password |
| `POSTGRES_DB` | azblink_directory | Database name |

#### LDAP (osixia/openldap)

| Variable | Default | Description |
|----------|---------|-------------|
| `LDAP_ORGANISATION` | AZBlink | Organization name |
| `LDAP_DOMAIN` | azblink.com | Domain → dc=azblink,dc=com |
| `LDAP_ADMIN_PASSWORD` | adminpassword | Admin bind password |

#### API LDAP Connection

| Variable | Default | Description |
|----------|---------|-------------|
| `LDAP_URI` | ldap://openldap:389 | LDAP server URI |
| `LDAP_BASE_DN` | dc=azblink,dc=com | Base DN for searches |
| `LDAP_TENANT` | azblink | Tenant identifier |
| `LDAP_BIND_DN` | cn=admin,dc=azblink,dc=com | Service account DN |
| `LDAP_BIND_PW` | adminpassword | Service account password |

#### API Authentication

| Variable | Default | Description |
|----------|---------|-------------|
| `REQUIRE_OIDC_AUTH` | false | Require OIDC tokens |
| `ALLOW_BOOTSTRAP_WITHOUT_OIDC` | true | Allow bootstrap endpoints |
| `ORG_QR_SIGNING_SECRET` | dev_signing_secret_change_in_prod | QR code signing key |
| `BREAKGLASS_FILE` | /etc/azblink/directory/breakglass.json | Emergency access config |

## 4. LDAP Schema

### DN Structure

```
dc=azblink,dc=com                    (domain root - auto-created)
├── ou=org                           (organization tree)
│   └── ou=GlobalHQ
│       ├── ou=Engineering
│       │   ├── ou=Platform
│       │   │   ├── ou=Security
│       │   │   └── ou=EdgeSystems
│       │   └── ou=ProductEngineering
│       ├── ou=Marketing
│       │   ├── ou=Brand
│       │   └── ou=DemandGen
│       └── ou=Legal
├── ou=people                        (user accounts)
│   ├── uid=robert
│   ├── uid=alex
│   ├── uid=sarah
│   ├── uid=james
│   ├── uid=mei
│   ├── uid=kevin
│   └── uid=laura
└── ou=groups                        (security groups)
    ├── cn=IT-Admins
    ├── cn=Engineering
    ├── cn=All-Staff
    └── cn=Managers
```

### Object Classes

#### organizationalUnit (org tree, containers)
```ldif
objectClass: organizationalUnit
ou: <unit name>
description: <optional description>
```

#### inetOrgPerson (users)
```ldif
objectClass: inetOrgPerson
objectClass: organizationalPerson
objectClass: person
uid: <username>
cn: <full name>
sn: <surname>
givenName: <first name>
displayName: <display name>
title: <job title>
mail: <email>
telephoneNumber: <extension>
l: <location>
ou: <department>
manager: <manager DN>
userPassword: <password>
```

#### groupOfNames (groups)
```ldif
objectClass: groupOfNames
cn: <group name>
description: <description>
member: <user DN>
member: <user DN>
...
```

## 5. Bootstrap Data

### Users (7 total)

| uid | Name | Title | Dept | Manager | Password |
|-----|------|-------|------|---------|----------|
| robert | Robert Lin | VP of Engineering | Engineering | - | password123 |
| alex | Alex Chen | Senior NFV Architect | Security | robert | password123 |
| sarah | Sarah Kim | Network Automation Engineer | EdgeSystems | alex | password123 |
| james | James Miller | Product Engineer | ProductEngineering | robert | password123 |
| mei | Mei Wang | Brand Strategist | Brand | - | password123 |
| kevin | Kevin Huang | Demand Generation Lead | DemandGen | - | password123 |
| laura | Laura Chen | Corporate Counsel | Legal | - | password123 |

### Groups (4 total)

| Group | Members |
|-------|---------|
| IT-Admins | robert, alex |
| Engineering | robert, alex, sarah, james |
| All-Staff | all 7 users |
| Managers | robert, alex |

## 6. Development Workflow

### Initial Setup

```bash
# Clone and navigate
cd v1.0-baseline/deploy

# Copy environment template
cp .env.example .env

# Build and start (first time, ~45s)
docker compose up --build
```

### Daily Development

```bash
# Start services (~2s)
docker compose up

# Or in background
docker compose up -d

# Watch API logs
docker compose logs -f directory-api

# Edit ../api/*.py files - changes auto-reload
```

### Testing Changes

```bash
# API health check
curl http://localhost:8000/health

# List users via API
curl http://localhost:8000/api/users

# List org tree via API
curl http://localhost:8000/api/org/tree

# Direct LDAP query
docker compose exec openldap ldapsearch -x \
  -b "ou=people,dc=azblink,dc=com" \
  -D "cn=admin,dc=azblink,dc=com" \
  -w adminpassword \
  "(objectClass=inetOrgPerson)" uid cn title
```

### Debugging

```bash
# API container shell
docker compose exec directory-api bash

# Check LDAP connectivity from API container
docker compose exec directory-api python -c "
import ldap3
conn = ldap3.Connection('ldap://openldap:389', 'cn=admin,dc=azblink,dc=com', 'adminpassword', auto_bind=True)
print('LDAP connected:', conn.bound)
"

# PostgreSQL shell
docker compose exec postgres psql -U azblink_directory

# View running containers
docker compose ps
```

### Clean Reset

```bash
# Stop and remove volumes (deletes all data)
docker compose down -v

# Rebuild from scratch
docker compose up --build
```

## 7. Troubleshooting

### API Fails to Start

**Symptom:** `directory-api` exits immediately
**Check:** `docker compose logs directory-api`
**Common causes:**
- Missing requirements in `requirements.txt`
- Syntax error in Python code
- Port 8000 already in use

### LDAP Connection Refused

**Symptom:** API logs show "LDAP connection refused"
**Check:** `docker compose logs openldap`
**Solution:** OpenLDAP takes ~10s to initialize on first start. Wait and retry.

### Database Connection Failed

**Symptom:** "could not connect to server"
**Check:** `docker compose ps` - verify postgres is running
**Check:** `docker compose logs postgres`
**Solution:** Wait for healthcheck to pass, or `docker compose restart directory-api`

### LDAP Data Not Found

**Symptom:** API returns empty users/groups
**Check:**
```bash
docker compose exec openldap ldapsearch -x -b "dc=azblink,dc=com" -D "cn=admin,dc=azblink,dc=com" -w adminpassword
```
**Solution:** If bootstrap.ldif wasn't loaded, `docker compose down -v` and restart.

### Hot Reload Not Working

**Symptom:** Code changes don't take effect
**Check:** Volume mount in `docker compose ps`
**Solution:** Ensure `../api` path is correct relative to `docker-compose.yml`

## 8. Production Notes

This development setup is **NOT** production-ready. For production:

| Aspect | Dev | Production |
|--------|-----|------------|
| LDAP password | adminpassword | Strong, rotated password |
| LDAP TLS | Disabled | Required (LDAPS or StartTLS) |
| DB password | azblink_directory | Strong, rotated password |
| OIDC auth | Disabled | Required |
| Breakglass | Always enabled | Disabled or time-limited |
| QR signing secret | Hardcoded | Vault/secrets manager |
| Volumes | Local Docker | Persistent storage (EBS, etc) |
| Networking | Host ports | Internal only, load balancer |

See main deployment documentation for production hardening checklist.
```

**Step 2: Verify spec created**

Run: `wc -l v1.0-baseline/deploy/DEPLOYMENT_SPEC.md`
Expected: ~280 lines

**Step 3: Commit**

```bash
git add v1.0-baseline/deploy/DEPLOYMENT_SPEC.md
git commit -m "docs(deploy): add comprehensive deployment specification"
```

---

## Task 8: Integration Test

**Files:**
- None (testing only)

**Step 1: Start the stack**

Run: `cd v1.0-baseline/deploy && docker compose up --build -d`
Expected: All 3 services start without errors

**Step 2: Wait for services**

Run: `sleep 15 && docker compose ps`
Expected: All containers show "Up" status

**Step 3: Test API responds**

Run: `curl -s http://localhost:8000/api/tenant | head -5`
Expected: JSON response with `{"ok":true,"tenant":"azblink",...}`

**Step 4: Test LDAP data loaded**

Run: `docker compose exec openldap ldapsearch -x -b "ou=people,dc=azblink,dc=com" -D "cn=admin,dc=azblink,dc=com" -w adminpassword "(uid=*)" uid | grep "uid:"`
Expected: 7 uid entries (robert, alex, sarah, james, mei, kevin, laura)

**Step 5: Test LDAP org tree**

Run: `docker compose exec openldap ldapsearch -x -b "ou=org,dc=azblink,dc=com" -D "cn=admin,dc=azblink,dc=com" -w adminpassword "(objectClass=organizationalUnit)" ou | grep "ou:"`
Expected: 10+ ou entries (GlobalHQ, Engineering, Platform, etc.)

**Step 6: Test LDAP groups**

Run: `docker compose exec openldap ldapsearch -x -b "ou=groups,dc=azblink,dc=com" -D "cn=admin,dc=azblink,dc=com" -w adminpassword "(objectClass=groupOfNames)" cn | grep "cn:"`
Expected: 4 cn entries (IT-Admins, Engineering, All-Staff, Managers)

**Step 7: Stop stack**

Run: `cd v1.0-baseline/deploy && docker compose down`
Expected: Clean shutdown

**Step 8: Final commit (if all tests pass)**

```bash
git add -A
git commit -m "feat(deploy): complete dev environment setup

- Pre-built API image for fast startup
- OpenLDAP with demo data matching UI
- Hot reload enabled
- README and full deployment spec"
```

---

## Summary

| Task | Description | Files |
|------|-------------|-------|
| 1 | Dockerfile.api | 1 new |
| 2 | .env.example + .gitignore | 2 new |
| 3 | bootstrap.ldif | 1 new |
| 4 | breakglass.json | 1 new |
| 5 | docker-compose.yml | 1 modified |
| 6 | README.md | 1 new |
| 7 | DEPLOYMENT_SPEC.md | 1 new |
| 8 | Integration test | 0 files |

**Total: 7 new files, 1 modified file, ~600 lines of config/docs**

---

## Review Notes (Critical Analysis)

**Fixed issues in this revision:**
1. Task 3 step 3 - corrected expected dn count from 21 to 24
2. Task 4 - breakglass.json now has valid `expires_at` datetime (was `null` which API rejects), added `mode` and `allow_from` for Docker network access
3. Task 1 - Dockerfile now installs deps to system Python (not /app) so volume mount doesn't shadow packages
4. Task 5 - Added OpenLDAP healthcheck; API now waits for healthy LDAP before starting
5. Task 2 - Added .gitignore for .env file
6. Task 8 step 3 - Changed test from non-existent `/health` to `/api/tenant`
7. Task 3 - Added note about bootstrap only running on fresh volumes
