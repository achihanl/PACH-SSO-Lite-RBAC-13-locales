# Live Demo Data Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Transform static HTML mockups into a live data-driven directory with 58 users seeded into LDAP.

**Architecture:** Seed script runs as Docker Compose init service, populates LDAP with users/OUs/groups, downloads avatars to shared volume. UI fetches exclusively from API, no mock data fallback.

**Tech Stack:** Python 3.11, ldap3, FastAPI, OpenLDAP, Docker Compose

---

## Task 1: Fix LDAP Client Bug

**Files:**
- Modify: `src/backend/ldap_client.py:41,49`

**Step 1: Fix find_user_dn function (line 41)**

Change `attributes=["dn"]` to `attributes=["uid"]` - dn is always returned automatically.

```python
# In find_user_dn function, line 41
# FROM:
        attributes=["dn"]
# TO:
        attributes=["uid"]
```

**Step 2: Fix entry_exists function (line 49)**

```python
# In entry_exists function, line 49
# FROM:
    conn.search(search_base=dn, search_filter="(objectClass=*)", search_scope="BASE", attributes=["dn"])
# TO:
    conn.search(search_base=dn, search_filter="(objectClass=*)", search_scope="BASE", attributes=["objectClass"])
```

**Step 3: Verify API now works**

```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/deploy/dev
docker compose restart directory-api
sleep 3
curl -s http://localhost:8000/api/org/tree | head -20
```

Expected: JSON response with org tree (not "Internal Server Error")

**Step 4: Commit**

```bash
git add src/backend/ldap_client.py
git commit -m "fix(ldap): replace invalid dn attribute request with objectClass

The dn (distinguished name) is always returned automatically by LDAP
and cannot be requested as an attribute. This was causing 'invalid
attribute type dn' errors on all API calls.

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 2: Create Seed Script Dockerfile

**Files:**
- Create: `deploy/dev/Dockerfile.seed`

**Step 1: Create Dockerfile**

```dockerfile
FROM python:3.11-slim

RUN pip install --no-cache-dir ldap3 requests

COPY deploy/dev/seed /seed

WORKDIR /seed

CMD ["python3", "seed_demo_data.py"]
```

**Step 2: Create seed directory**

```bash
mkdir -p /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/deploy/dev/seed
```

**Step 3: Commit**

```bash
git add deploy/dev/Dockerfile.seed
git commit -m "chore(deploy): add Dockerfile for seed script

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 3: Create Seed Script with 58 Users

**Files:**
- Create: `deploy/dev/seed/seed_demo_data.py`

**Step 1: Create seed script**

This is a large file. Create it with all 58 users, org structure, and groups.

```python
#!/usr/bin/env python3
"""
Seed demo data for Azblink Directory dev environment.
Idempotent - safe to run multiple times.
"""

import os
import sys
import time
import requests
from ldap3 import Server, Connection, ALL, SUBTREE

# Config from environment
LDAP_URI = os.getenv("LDAP_URI", "ldap://openldap:389")
LDAP_BIND_DN = os.getenv("LDAP_BIND_DN", "cn=admin,dc=azblink,dc=com")
LDAP_BIND_PW = os.getenv("LDAP_BIND_PW", "adminpassword")
BASE_DN = "dc=azblink,dc=com"
AVATAR_DIR = os.getenv("AVATAR_OUTPUT_DIR", "/avatars")

# Organizational Units (hierarchy)
# Format: (dn, description)
DEPARTMENTS = [
    # Top-level containers (already exist from bootstrap)
    # ("ou=org,dc=azblink,dc=com", "Organization tree"),
    # ("ou=people,dc=azblink,dc=com", "User accounts"),
    # ("ou=groups,dc=azblink,dc=com", "Security groups"),

    # GlobalHQ structure
    ("ou=Executive,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Executive team"),
    ("ou=Sales,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Sales department"),
    ("ou=Enterprise,ou=Sales,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Enterprise sales"),
    ("ou=SMB,ou=Sales,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "SMB sales"),
    ("ou=Solutions,ou=Sales,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Solutions engineering"),
    ("ou=Operations,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Operations department"),
    ("ou=IT,ou=Operations,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "IT team"),
    ("ou=Facilities,ou=Operations,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Facilities team"),
    ("ou=Procurement,ou=Operations,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Procurement team"),
    ("ou=Finance,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Finance department"),
    ("ou=Accounting,ou=Finance,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Accounting team"),
    ("ou=FPA,ou=Finance,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "FP&A team"),
    ("ou=HR,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Human Resources"),
    ("ou=Recruiting,ou=HR,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Recruiting team"),
    ("ou=PeopleOps,ou=HR,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "People Operations"),
    ("ou=Compliance,ou=Legal,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Compliance team"),
    ("ou=CustomerSuccess,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Customer Success"),
    ("ou=CSM,ou=CustomerSuccess,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Customer Success Managers"),
    ("ou=Support,ou=CustomerSuccess,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "Support team"),
    ("ou=QA,ou=Engineering,ou=GlobalHQ,ou=org,dc=azblink,dc=com", "QA team"),
]

# Users: 58 total (7 existing + 51 new)
# Format: dict with all LDAP attributes
USERS = [
    # === EXECUTIVE (2) ===
    {
        "uid": "dchang", "givenName": "David", "sn": "Chang",
        "cn": "David Chang", "displayName": "David Chang",
        "title": "Chief Executive Officer", "mail": "david.chang@azblink.com",
        "telephoneNumber": "8001", "mobile": "+886-912-001-001",
        "l": "Taipei, TW", "ou": "Executive",
        "employeeNumber": "AZB-0001", "departmentNumber": "EXEC-001",
        "physicalDeliveryOfficeName": "HQ-15F-CEO", "description": "Hired: 2020-01-15",
        "manager": None
    },
    {
        "uid": "ewu", "givenName": "Emily", "sn": "Wu",
        "cn": "Emily Wu", "displayName": "Emily Wu",
        "title": "Chief of Staff", "mail": "emily.wu@azblink.com",
        "telephoneNumber": "8002", "mobile": "+886-912-001-002",
        "l": "Taipei, TW", "ou": "Executive",
        "employeeNumber": "AZB-0002", "departmentNumber": "EXEC-002",
        "physicalDeliveryOfficeName": "HQ-15F-A01", "description": "Hired: 2021-03-01",
        "manager": "uid=dchang,ou=people,dc=azblink,dc=com"
    },

    # === ENGINEERING (18) - 7 existing (robert, alex, sarah, james + 4 more slots) + 11 new ===
    # CTO - Robert Lin (existing, skip)
    # Platform/Security - Alex Chen (existing, skip)
    # Platform/EdgeSystems - Sarah Kim (existing, skip)
    # ProductEngineering - James Miller (existing, skip)

    # New Engineering hires
    {
        "uid": "tchen", "givenName": "Tony", "sn": "Chen",
        "cn": "Tony Chen", "displayName": "Tony Chen",
        "title": "Security Engineer", "mail": "tony.chen@azblink.com",
        "telephoneNumber": "8825", "mobile": "+886-912-101-001",
        "l": "Taipei, TW", "ou": "Security",
        "employeeNumber": "AZB-0101", "departmentNumber": "ENG-SEC-002",
        "physicalDeliveryOfficeName": "HQ-12F-B02", "description": "Hired: 2023-06-15",
        "manager": "uid=alex,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "ywang", "givenName": "Yuki", "sn": "Wang",
        "cn": "Yuki Wang", "displayName": "Yuki Wang",
        "title": "Security Analyst", "mail": "yuki.wang@azblink.com",
        "telephoneNumber": "8826", "mobile": "+886-912-101-002",
        "l": "Taipei, TW", "ou": "Security",
        "employeeNumber": "AZB-0102", "departmentNumber": "ENG-SEC-003",
        "physicalDeliveryOfficeName": "HQ-12F-B03", "description": "Hired: 2024-01-10",
        "manager": "uid=alex,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "jlee", "givenName": "Jason", "sn": "Lee",
        "cn": "Jason Lee", "displayName": "Jason Lee",
        "title": "Edge Systems Engineer", "mail": "jason.lee@azblink.com",
        "telephoneNumber": "8843", "mobile": "+886-912-102-001",
        "l": "Taipei, TW", "ou": "EdgeSystems",
        "employeeNumber": "AZB-0103", "departmentNumber": "ENG-EDGE-002",
        "physicalDeliveryOfficeName": "HQ-12F-C02", "description": "Hired: 2023-08-20",
        "manager": "uid=sarah,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "lhuang", "givenName": "Lisa", "sn": "Huang",
        "cn": "Lisa Huang", "displayName": "Lisa Huang",
        "title": "Edge Systems Engineer", "mail": "lisa.huang@azblink.com",
        "telephoneNumber": "8844", "mobile": "+886-912-102-002",
        "l": "Hsinchu, TW", "ou": "EdgeSystems",
        "employeeNumber": "AZB-0104", "departmentNumber": "ENG-EDGE-003",
        "physicalDeliveryOfficeName": "HSC-3F-A01", "description": "Hired: 2024-02-01",
        "manager": "uid=sarah,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "mlin", "givenName": "Mike", "sn": "Lin",
        "cn": "Mike Lin", "displayName": "Mike Lin",
        "title": "Senior Product Engineer", "mail": "mike.lin@azblink.com",
        "telephoneNumber": "8832", "mobile": "+886-912-103-001",
        "l": "Hsinchu, TW", "ou": "ProductEngineering",
        "employeeNumber": "AZB-0105", "departmentNumber": "ENG-PROD-002",
        "physicalDeliveryOfficeName": "HSC-3F-B01", "description": "Hired: 2022-11-15",
        "manager": "uid=james,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "achiu", "givenName": "Amy", "sn": "Chiu",
        "cn": "Amy Chiu", "displayName": "Amy Chiu",
        "title": "Product Engineer", "mail": "amy.chiu@azblink.com",
        "telephoneNumber": "8833", "mobile": "+886-912-103-002",
        "l": "Hsinchu, TW", "ou": "ProductEngineering",
        "employeeNumber": "AZB-0106", "departmentNumber": "ENG-PROD-003",
        "physicalDeliveryOfficeName": "HSC-3F-B02", "description": "Hired: 2023-04-01",
        "manager": "uid=james,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "pwu", "givenName": "Peter", "sn": "Wu",
        "cn": "Peter Wu", "displayName": "Peter Wu",
        "title": "Product Engineer", "mail": "peter.wu@azblink.com",
        "telephoneNumber": "8834", "mobile": "+886-912-103-003",
        "l": "Hsinchu, TW", "ou": "ProductEngineering",
        "employeeNumber": "AZB-0107", "departmentNumber": "ENG-PROD-004",
        "physicalDeliveryOfficeName": "HSC-3F-B03", "description": "Hired: 2023-09-01",
        "manager": "uid=james,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "stsai", "givenName": "Sandy", "sn": "Tsai",
        "cn": "Sandy Tsai", "displayName": "Sandy Tsai",
        "title": "Junior Product Engineer", "mail": "sandy.tsai@azblink.com",
        "telephoneNumber": "8835", "mobile": "+886-912-103-004",
        "l": "Taipei, TW", "ou": "ProductEngineering",
        "employeeNumber": "AZB-0108", "departmentNumber": "ENG-PROD-005",
        "physicalDeliveryOfficeName": "HQ-12F-D01", "description": "Hired: 2024-07-01",
        "manager": "uid=james,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "qlin", "givenName": "Queena", "sn": "Lin",
        "cn": "Queena Lin", "displayName": "Queena Lin",
        "title": "QA Lead", "mail": "queena.lin@azblink.com",
        "telephoneNumber": "8851", "mobile": "+886-912-104-001",
        "l": "Taipei, TW", "ou": "QA",
        "employeeNumber": "AZB-0109", "departmentNumber": "ENG-QA-001",
        "physicalDeliveryOfficeName": "HQ-12F-E01", "description": "Hired: 2022-05-15",
        "manager": "uid=robert,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "hsu", "givenName": "Henry", "sn": "Su",
        "cn": "Henry Su", "displayName": "Henry Su",
        "title": "QA Engineer", "mail": "henry.su@azblink.com",
        "telephoneNumber": "8852", "mobile": "+886-912-104-002",
        "l": "Taipei, TW", "ou": "QA",
        "employeeNumber": "AZB-0110", "departmentNumber": "ENG-QA-002",
        "physicalDeliveryOfficeName": "HQ-12F-E02", "description": "Hired: 2023-03-01",
        "manager": "uid=qlin,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "gchen", "givenName": "Grace", "sn": "Chen",
        "cn": "Grace Chen", "displayName": "Grace Chen",
        "title": "QA Engineer", "mail": "grace.chen@azblink.com",
        "telephoneNumber": "8853", "mobile": "+886-912-104-003",
        "l": "Taipei, TW", "ou": "QA",
        "employeeNumber": "AZB-0111", "departmentNumber": "ENG-QA-003",
        "physicalDeliveryOfficeName": "HQ-12F-E03", "description": "Hired: 2024-01-15",
        "manager": "uid=qlin,ou=people,dc=azblink,dc=com"
    },

    # === SALES (10) ===
    {
        "uid": "mtorres", "givenName": "Michael", "sn": "Torres",
        "cn": "Michael Torres", "displayName": "Michael Torres",
        "title": "Chief Sales Officer", "mail": "michael.torres@azblink.com",
        "telephoneNumber": "8201", "mobile": "+886-912-201-001",
        "l": "Taipei, TW", "ou": "Sales",
        "employeeNumber": "AZB-0201", "departmentNumber": "SALES-001",
        "physicalDeliveryOfficeName": "HQ-14F-A01", "description": "Hired: 2021-06-01",
        "manager": "uid=dchang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "cyang", "givenName": "Chris", "sn": "Yang",
        "cn": "Chris Yang", "displayName": "Chris Yang",
        "title": "Enterprise Sales Director", "mail": "chris.yang@azblink.com",
        "telephoneNumber": "8211", "mobile": "+886-912-202-001",
        "l": "Taipei, TW", "ou": "Enterprise",
        "employeeNumber": "AZB-0202", "departmentNumber": "SALES-ENT-001",
        "physicalDeliveryOfficeName": "HQ-14F-B01", "description": "Hired: 2022-02-15",
        "manager": "uid=mtorres,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "dwang", "givenName": "Diana", "sn": "Wang",
        "cn": "Diana Wang", "displayName": "Diana Wang",
        "title": "Enterprise Account Executive", "mail": "diana.wang@azblink.com",
        "telephoneNumber": "8212", "mobile": "+886-912-202-002",
        "l": "Taipei, TW", "ou": "Enterprise",
        "employeeNumber": "AZB-0203", "departmentNumber": "SALES-ENT-002",
        "physicalDeliveryOfficeName": "HQ-14F-B02", "description": "Hired: 2023-01-10",
        "manager": "uid=cyang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "flin", "givenName": "Frank", "sn": "Lin",
        "cn": "Frank Lin", "displayName": "Frank Lin",
        "title": "Enterprise Account Executive", "mail": "frank.lin@azblink.com",
        "telephoneNumber": "8213", "mobile": "+886-912-202-003",
        "l": "Taipei, TW", "ou": "Enterprise",
        "employeeNumber": "AZB-0204", "departmentNumber": "SALES-ENT-003",
        "physicalDeliveryOfficeName": "HQ-14F-B03", "description": "Hired: 2023-05-01",
        "manager": "uid=cyang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "ichu", "givenName": "Ivan", "sn": "Chu",
        "cn": "Ivan Chu", "displayName": "Ivan Chu",
        "title": "Enterprise Account Executive", "mail": "ivan.chu@azblink.com",
        "telephoneNumber": "8214", "mobile": "+886-912-202-004",
        "l": "Taipei, TW", "ou": "Enterprise",
        "employeeNumber": "AZB-0205", "departmentNumber": "SALES-ENT-004",
        "physicalDeliveryOfficeName": "HQ-14F-B04", "description": "Hired: 2024-03-01",
        "manager": "uid=cyang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "nhuang", "givenName": "Nancy", "sn": "Huang",
        "cn": "Nancy Huang", "displayName": "Nancy Huang",
        "title": "SMB Sales Manager", "mail": "nancy.huang@azblink.com",
        "telephoneNumber": "8221", "mobile": "+886-912-203-001",
        "l": "Taipei, TW", "ou": "SMB",
        "employeeNumber": "AZB-0206", "departmentNumber": "SALES-SMB-001",
        "physicalDeliveryOfficeName": "HQ-14F-C01", "description": "Hired: 2022-08-15",
        "manager": "uid=mtorres,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "blee", "givenName": "Brian", "sn": "Lee",
        "cn": "Brian Lee", "displayName": "Brian Lee",
        "title": "SMB Account Executive", "mail": "brian.lee@azblink.com",
        "telephoneNumber": "8222", "mobile": "+886-912-203-002",
        "l": "Taipei, TW", "ou": "SMB",
        "employeeNumber": "AZB-0207", "departmentNumber": "SALES-SMB-002",
        "physicalDeliveryOfficeName": "HQ-14F-C02", "description": "Hired: 2023-07-01",
        "manager": "uid=nhuang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "jchou", "givenName": "Jenny", "sn": "Chou",
        "cn": "Jenny Chou", "displayName": "Jenny Chou",
        "title": "SMB Account Executive", "mail": "jenny.chou@azblink.com",
        "telephoneNumber": "8223", "mobile": "+886-912-203-003",
        "l": "Taipei, TW", "ou": "SMB",
        "employeeNumber": "AZB-0208", "departmentNumber": "SALES-SMB-003",
        "physicalDeliveryOfficeName": "HQ-14F-C03", "description": "Hired: 2024-01-15",
        "manager": "uid=nhuang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "rchang", "givenName": "Ryan", "sn": "Chang",
        "cn": "Ryan Chang", "displayName": "Ryan Chang",
        "title": "Solutions Architect", "mail": "ryan.chang@azblink.com",
        "telephoneNumber": "8231", "mobile": "+886-912-204-001",
        "l": "Taipei, TW", "ou": "Solutions",
        "employeeNumber": "AZB-0209", "departmentNumber": "SALES-SOL-001",
        "physicalDeliveryOfficeName": "HQ-14F-D01", "description": "Hired: 2022-04-01",
        "manager": "uid=mtorres,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "kwu", "givenName": "Karen", "sn": "Wu",
        "cn": "Karen Wu", "displayName": "Karen Wu",
        "title": "Solutions Engineer", "mail": "karen.wu@azblink.com",
        "telephoneNumber": "8232", "mobile": "+886-912-204-002",
        "l": "Taipei, TW", "ou": "Solutions",
        "employeeNumber": "AZB-0210", "departmentNumber": "SALES-SOL-002",
        "physicalDeliveryOfficeName": "HQ-14F-D02", "description": "Hired: 2023-02-01",
        "manager": "uid=rchang,ou=people,dc=azblink,dc=com"
    },

    # === MARKETING (6) - 2 existing (mei, kevin) + 4 new ===
    {
        "uid": "jpark", "givenName": "Jennifer", "sn": "Park",
        "cn": "Jennifer Park", "displayName": "Jennifer Park",
        "title": "Chief Marketing Officer", "mail": "jennifer.park@azblink.com",
        "telephoneNumber": "8701", "mobile": "+886-912-301-001",
        "l": "Taipei, TW", "ou": "Marketing",
        "employeeNumber": "AZB-0301", "departmentNumber": "MKT-001",
        "physicalDeliveryOfficeName": "HQ-13F-A01", "description": "Hired: 2021-09-01",
        "manager": "uid=dchang,ou=people,dc=azblink,dc=com"
    },
    # mei (existing) - Brand Strategist
    {
        "uid": "alin", "givenName": "Alice", "sn": "Lin",
        "cn": "Alice Lin", "displayName": "Alice Lin",
        "title": "Brand Designer", "mail": "alice.lin@azblink.com",
        "telephoneNumber": "8703", "mobile": "+886-912-302-001",
        "l": "Taipei, TW", "ou": "Brand",
        "employeeNumber": "AZB-0302", "departmentNumber": "MKT-BRAND-002",
        "physicalDeliveryOfficeName": "HQ-13F-B02", "description": "Hired: 2023-06-01",
        "manager": "uid=mei,ou=people,dc=azblink,dc=com"
    },
    # kevin (existing) - Demand Generation Lead
    {
        "uid": "vchen", "givenName": "Victor", "sn": "Chen",
        "cn": "Victor Chen", "displayName": "Victor Chen",
        "title": "Digital Marketing Specialist", "mail": "victor.chen@azblink.com",
        "telephoneNumber": "8714", "mobile": "+886-912-303-001",
        "l": "Taipei, TW", "ou": "DemandGen",
        "employeeNumber": "AZB-0303", "departmentNumber": "MKT-DG-002",
        "physicalDeliveryOfficeName": "HQ-13F-C02", "description": "Hired: 2023-10-01",
        "manager": "uid=kevin,ou=people,dc=azblink,dc=com"
    },

    # === OPERATIONS (6) ===
    {
        "uid": "rlee", "givenName": "Richard", "sn": "Lee",
        "cn": "Richard Lee", "displayName": "Richard Lee",
        "title": "Chief Operating Officer", "mail": "richard.lee@azblink.com",
        "telephoneNumber": "8401", "mobile": "+886-912-401-001",
        "l": "Taipei, TW", "ou": "Operations",
        "employeeNumber": "AZB-0401", "departmentNumber": "OPS-001",
        "physicalDeliveryOfficeName": "HQ-15F-B01", "description": "Hired: 2021-04-01",
        "manager": "uid=dchang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "slin", "givenName": "Steven", "sn": "Lin",
        "cn": "Steven Lin", "displayName": "Steven Lin",
        "title": "IT Manager", "mail": "steven.lin@azblink.com",
        "telephoneNumber": "8411", "mobile": "+886-912-402-001",
        "l": "Taipei, TW", "ou": "IT",
        "employeeNumber": "AZB-0402", "departmentNumber": "OPS-IT-001",
        "physicalDeliveryOfficeName": "HQ-11F-A01", "description": "Hired: 2022-01-15",
        "manager": "uid=rlee,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "dhuang", "givenName": "David", "sn": "Huang",
        "cn": "David Huang", "displayName": "David Huang",
        "title": "System Administrator", "mail": "david.huang@azblink.com",
        "telephoneNumber": "8412", "mobile": "+886-912-402-002",
        "l": "Taipei, TW", "ou": "IT",
        "employeeNumber": "AZB-0403", "departmentNumber": "OPS-IT-002",
        "physicalDeliveryOfficeName": "HQ-11F-A02", "description": "Hired: 2022-09-01",
        "manager": "uid=slin,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "cwang", "givenName": "Cindy", "sn": "Wang",
        "cn": "Cindy Wang", "displayName": "Cindy Wang",
        "title": "IT Support Specialist", "mail": "cindy.wang@azblink.com",
        "telephoneNumber": "8413", "mobile": "+886-912-402-003",
        "l": "Taipei, TW", "ou": "IT",
        "employeeNumber": "AZB-0404", "departmentNumber": "OPS-IT-003",
        "physicalDeliveryOfficeName": "HQ-11F-A03", "description": "Hired: 2023-11-01",
        "manager": "uid=slin,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "mchang", "givenName": "Mary", "sn": "Chang",
        "cn": "Mary Chang", "displayName": "Mary Chang",
        "title": "Office Manager", "mail": "mary.chang@azblink.com",
        "telephoneNumber": "8421", "mobile": "+886-912-403-001",
        "l": "Taipei, TW", "ou": "Facilities",
        "employeeNumber": "AZB-0405", "departmentNumber": "OPS-FAC-001",
        "physicalDeliveryOfficeName": "HQ-1F-A01", "description": "Hired: 2021-08-01",
        "manager": "uid=rlee,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "tlin", "givenName": "Tom", "sn": "Lin",
        "cn": "Tom Lin", "displayName": "Tom Lin",
        "title": "Procurement Specialist", "mail": "tom.lin@azblink.com",
        "telephoneNumber": "8431", "mobile": "+886-912-404-001",
        "l": "Taipei, TW", "ou": "Procurement",
        "employeeNumber": "AZB-0406", "departmentNumber": "OPS-PROC-001",
        "physicalDeliveryOfficeName": "HQ-11F-B01", "description": "Hired: 2023-03-01",
        "manager": "uid=rlee,ou=people,dc=azblink,dc=com"
    },

    # === FINANCE (4) ===
    {
        "uid": "suchen", "givenName": "Susan", "sn": "Chen",
        "cn": "Susan Chen", "displayName": "Susan Chen",
        "title": "Chief Financial Officer", "mail": "susan.chen@azblink.com",
        "telephoneNumber": "8501", "mobile": "+886-912-501-001",
        "l": "Taipei, TW", "ou": "Finance",
        "employeeNumber": "AZB-0501", "departmentNumber": "FIN-001",
        "physicalDeliveryOfficeName": "HQ-15F-C01", "description": "Hired: 2021-02-01",
        "manager": "uid=dchang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "jhuang", "givenName": "Joyce", "sn": "Huang",
        "cn": "Joyce Huang", "displayName": "Joyce Huang",
        "title": "Controller", "mail": "joyce.huang@azblink.com",
        "telephoneNumber": "8511", "mobile": "+886-912-502-001",
        "l": "Taipei, TW", "ou": "Accounting",
        "employeeNumber": "AZB-0502", "departmentNumber": "FIN-ACC-001",
        "physicalDeliveryOfficeName": "HQ-10F-A01", "description": "Hired: 2021-11-01",
        "manager": "uid=suchen,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "hchen", "givenName": "Helen", "sn": "Chen",
        "cn": "Helen Chen", "displayName": "Helen Chen",
        "title": "Senior Accountant", "mail": "helen.chen@azblink.com",
        "telephoneNumber": "8512", "mobile": "+886-912-502-002",
        "l": "Taipei, TW", "ou": "Accounting",
        "employeeNumber": "AZB-0503", "departmentNumber": "FIN-ACC-002",
        "physicalDeliveryOfficeName": "HQ-10F-A02", "description": "Hired: 2022-07-01",
        "manager": "uid=jhuang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "owu", "givenName": "Oscar", "sn": "Wu",
        "cn": "Oscar Wu", "displayName": "Oscar Wu",
        "title": "Financial Analyst", "mail": "oscar.wu@azblink.com",
        "telephoneNumber": "8521", "mobile": "+886-912-503-001",
        "l": "Taipei, TW", "ou": "FPA",
        "employeeNumber": "AZB-0504", "departmentNumber": "FIN-FPA-001",
        "physicalDeliveryOfficeName": "HQ-10F-B01", "description": "Hired: 2023-04-15",
        "manager": "uid=suchen,ou=people,dc=azblink,dc=com"
    },

    # === HR (4) ===
    {
        "uid": "aliu", "givenName": "Amanda", "sn": "Liu",
        "cn": "Amanda Liu", "displayName": "Amanda Liu",
        "title": "Chief Human Resources Officer", "mail": "amanda.liu@azblink.com",
        "telephoneNumber": "8601", "mobile": "+886-912-601-001",
        "l": "Taipei, TW", "ou": "HR",
        "employeeNumber": "AZB-0601", "departmentNumber": "HR-001",
        "physicalDeliveryOfficeName": "HQ-15F-D01", "description": "Hired: 2021-05-01",
        "manager": "uid=dchang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "elin", "givenName": "Eva", "sn": "Lin",
        "cn": "Eva Lin", "displayName": "Eva Lin",
        "title": "Recruiting Manager", "mail": "eva.lin@azblink.com",
        "telephoneNumber": "8611", "mobile": "+886-912-602-001",
        "l": "Taipei, TW", "ou": "Recruiting",
        "employeeNumber": "AZB-0602", "departmentNumber": "HR-REC-001",
        "physicalDeliveryOfficeName": "HQ-9F-A01", "description": "Hired: 2022-03-01",
        "manager": "uid=aliu,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "phuang", "givenName": "Peggy", "sn": "Huang",
        "cn": "Peggy Huang", "displayName": "Peggy Huang",
        "title": "Technical Recruiter", "mail": "peggy.huang@azblink.com",
        "telephoneNumber": "8612", "mobile": "+886-912-602-002",
        "l": "Taipei, TW", "ou": "Recruiting",
        "employeeNumber": "AZB-0603", "departmentNumber": "HR-REC-002",
        "physicalDeliveryOfficeName": "HQ-9F-A02", "description": "Hired: 2023-08-01",
        "manager": "uid=elin,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "wlin", "givenName": "Wendy", "sn": "Lin",
        "cn": "Wendy Lin", "displayName": "Wendy Lin",
        "title": "HR Business Partner", "mail": "wendy.lin@azblink.com",
        "telephoneNumber": "8621", "mobile": "+886-912-603-001",
        "l": "Taipei, TW", "ou": "PeopleOps",
        "employeeNumber": "AZB-0604", "departmentNumber": "HR-PO-001",
        "physicalDeliveryOfficeName": "HQ-9F-B01", "description": "Hired: 2022-10-01",
        "manager": "uid=aliu,ou=people,dc=azblink,dc=com"
    },

    # === LEGAL (3) - 1 existing (laura) + 2 new ===
    {
        "uid": "wzhang", "givenName": "William", "sn": "Zhang",
        "cn": "William Zhang", "displayName": "William Zhang",
        "title": "General Counsel", "mail": "william.zhang@azblink.com",
        "telephoneNumber": "8607", "mobile": "+886-912-701-001",
        "l": "Taipei, TW", "ou": "Legal",
        "employeeNumber": "AZB-0701", "departmentNumber": "LEGAL-001",
        "physicalDeliveryOfficeName": "HQ-15F-E01", "description": "Hired: 2021-07-01",
        "manager": "uid=dchang,ou=people,dc=azblink,dc=com"
    },
    # laura (existing) - Corporate Counsel
    {
        "uid": "nwu", "givenName": "Nina", "sn": "Wu",
        "cn": "Nina Wu", "displayName": "Nina Wu",
        "title": "Compliance Officer", "mail": "nina.wu@azblink.com",
        "telephoneNumber": "8609", "mobile": "+886-912-702-001",
        "l": "Taipei, TW", "ou": "Compliance",
        "employeeNumber": "AZB-0702", "departmentNumber": "LEGAL-COMP-001",
        "physicalDeliveryOfficeName": "HQ-10F-C01", "description": "Hired: 2023-01-15",
        "manager": "uid=wzhang,ou=people,dc=azblink,dc=com"
    },

    # === CUSTOMER SUCCESS (5) ===
    {
        "uid": "nicolew", "givenName": "Nicole", "sn": "Wang",
        "cn": "Nicole Wang", "displayName": "Nicole Wang",
        "title": "VP of Customer Success", "mail": "nicole.wang@azblink.com",
        "telephoneNumber": "8901", "mobile": "+886-912-801-001",
        "l": "Taipei, TW", "ou": "CustomerSuccess",
        "employeeNumber": "AZB-0801", "departmentNumber": "CS-001",
        "physicalDeliveryOfficeName": "HQ-13F-D01", "description": "Hired: 2022-01-01",
        "manager": "uid=dchang,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "jchen", "givenName": "Jack", "sn": "Chen",
        "cn": "Jack Chen", "displayName": "Jack Chen",
        "title": "Customer Success Manager", "mail": "jack.chen@azblink.com",
        "telephoneNumber": "8911", "mobile": "+886-912-802-001",
        "l": "Taipei, TW", "ou": "CSM",
        "employeeNumber": "AZB-0802", "departmentNumber": "CS-CSM-001",
        "physicalDeliveryOfficeName": "HQ-13F-E01", "description": "Hired: 2022-06-01",
        "manager": "uid=nicolew,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "ylin", "givenName": "Yvonne", "sn": "Lin",
        "cn": "Yvonne Lin", "displayName": "Yvonne Lin",
        "title": "Customer Success Manager", "mail": "yvonne.lin@azblink.com",
        "telephoneNumber": "8912", "mobile": "+886-912-802-002",
        "l": "Taipei, TW", "ou": "CSM",
        "employeeNumber": "AZB-0803", "departmentNumber": "CS-CSM-002",
        "physicalDeliveryOfficeName": "HQ-13F-E02", "description": "Hired: 2023-02-01",
        "manager": "uid=nicolew,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "ahuang", "givenName": "Andy", "sn": "Huang",
        "cn": "Andy Huang", "displayName": "Andy Huang",
        "title": "Support Engineer", "mail": "andy.huang@azblink.com",
        "telephoneNumber": "8921", "mobile": "+886-912-803-001",
        "l": "Taipei, TW", "ou": "Support",
        "employeeNumber": "AZB-0804", "departmentNumber": "CS-SUP-001",
        "physicalDeliveryOfficeName": "HQ-11F-C01", "description": "Hired: 2022-11-01",
        "manager": "uid=nicolew,ou=people,dc=azblink,dc=com"
    },
    {
        "uid": "bwang", "givenName": "Betty", "sn": "Wang",
        "cn": "Betty Wang", "displayName": "Betty Wang",
        "title": "Support Engineer", "mail": "betty.wang@azblink.com",
        "telephoneNumber": "8922", "mobile": "+886-912-803-002",
        "l": "Taipei, TW", "ou": "Support",
        "employeeNumber": "AZB-0805", "departmentNumber": "CS-SUP-002",
        "physicalDeliveryOfficeName": "HQ-11F-C02", "description": "Hired: 2023-09-01",
        "manager": "uid=nicolew,ou=people,dc=azblink,dc=com"
    },
]

# Groups
GROUPS = [
    # Department groups
    {"cn": "Sales", "description": "Sales department", "members": ["mtorres", "cyang", "dwang", "flin", "ichu", "nhuang", "blee", "jchou", "rchang", "kwu"]},
    {"cn": "Operations", "description": "Operations department", "members": ["rlee", "slin", "dhuang", "cwang", "mchang", "tlin"]},
    {"cn": "Finance", "description": "Finance department", "members": ["suchen", "jhuang", "hchen", "owu"]},
    {"cn": "HR", "description": "Human Resources", "members": ["aliu", "elin", "phuang", "wlin"]},
    {"cn": "CustomerSuccess", "description": "Customer Success department", "members": ["nicolew", "jchen", "ylin", "ahuang", "bwang"]},
    {"cn": "Executive", "description": "Executive team", "members": ["dchang", "ewu"]},
    # Role groups
    {"cn": "C-Suite", "description": "C-level executives", "members": ["dchang", "robert", "mtorres", "jpark", "rlee", "suchen", "aliu", "wzhang"]},
    {"cn": "Directors", "description": "Directors and VPs", "members": ["ewu", "cyang", "nhuang", "nicolew", "qlin"]},
]

# Existing users to skip (already in bootstrap.ldif)
EXISTING_USERS = {"robert", "alex", "sarah", "james", "mei", "kevin", "laura"}


def get_connection():
    """Connect to LDAP with retry."""
    max_retries = 30
    for i in range(max_retries):
        try:
            server = Server(LDAP_URI, get_info=ALL)
            conn = Connection(server, LDAP_BIND_DN, LDAP_BIND_PW, auto_bind=True)
            print(f"Connected to LDAP at {LDAP_URI}")
            return conn
        except Exception as e:
            print(f"LDAP connection attempt {i+1}/{max_retries} failed: {e}")
            time.sleep(2)
    raise RuntimeError(f"Could not connect to LDAP after {max_retries} attempts")


def check_already_seeded(conn) -> bool:
    """Return True if >10 users exist (skip seeding)."""
    conn.search(f"ou=people,{BASE_DN}", "(objectClass=inetOrgPerson)", search_scope=SUBTREE)
    count = len(conn.entries)
    print(f"Found {count} existing users")
    return count > 10


def ou_exists(conn, dn: str) -> bool:
    """Check if OU exists."""
    conn.search(dn, "(objectClass=*)", search_scope="BASE")
    return bool(conn.entries)


def create_ou(conn, dn: str, description: str):
    """Create OU if not exists."""
    if ou_exists(conn, dn):
        print(f"  OU exists: {dn}")
        return

    # Extract ou value from DN
    rdn = dn.split(",")[0]
    ou_val = rdn.split("=")[1] if "=" in rdn else rdn

    conn.add(dn, ["top", "organizationalUnit"], {"ou": ou_val, "description": description})
    if conn.result["result"] == 0:
        print(f"  Created OU: {dn}")
    else:
        print(f"  Failed to create OU {dn}: {conn.result}")


def user_exists(conn, uid: str) -> bool:
    """Check if user exists."""
    conn.search(f"ou=people,{BASE_DN}", f"(uid={uid})", search_scope=SUBTREE)
    return bool(conn.entries)


def create_user(conn, user: dict):
    """Create user with all attributes."""
    uid = user["uid"]

    if uid in EXISTING_USERS:
        print(f"  Skipping existing user: {uid}")
        return

    if user_exists(conn, uid):
        print(f"  User exists: {uid}")
        return

    dn = f"uid={uid},ou=people,{BASE_DN}"

    attrs = {
        "uid": uid,
        "cn": user["cn"],
        "sn": user["sn"],
        "givenName": user["givenName"],
        "displayName": user["displayName"],
        "title": user["title"],
        "mail": user["mail"],
        "telephoneNumber": user["telephoneNumber"],
        "mobile": user["mobile"],
        "l": user["l"],
        "ou": user["ou"],
        "employeeNumber": user["employeeNumber"],
        "departmentNumber": user["departmentNumber"],
        "physicalDeliveryOfficeName": user["physicalDeliveryOfficeName"],
        "description": user["description"],
        "userPassword": "demo123",
        "labeledURI": f"photo:/avatars/{uid}.png",
    }

    if user.get("manager"):
        attrs["manager"] = user["manager"]

    conn.add(dn, ["inetOrgPerson", "organizationalPerson", "person"], attrs)
    if conn.result["result"] == 0:
        print(f"  Created user: {uid}")
    else:
        print(f"  Failed to create user {uid}: {conn.result}")


def group_exists(conn, cn: str) -> bool:
    """Check if group exists."""
    conn.search(f"ou=groups,{BASE_DN}", f"(cn={cn})", search_scope=SUBTREE)
    return bool(conn.entries)


def create_or_update_group(conn, group: dict):
    """Create or update group with members."""
    cn = group["cn"]
    dn = f"cn={cn},ou=groups,{BASE_DN}"

    member_dns = [f"uid={uid},ou=people,{BASE_DN}" for uid in group["members"]]

    if group_exists(conn, cn):
        # Update members
        conn.modify(dn, {"member": [("MODIFY_REPLACE", member_dns)]})
        print(f"  Updated group: {cn}")
    else:
        # Create new group
        conn.add(dn, ["groupOfNames"], {
            "cn": cn,
            "description": group["description"],
            "member": member_dns
        })
        if conn.result["result"] == 0:
            print(f"  Created group: {cn}")
        else:
            print(f"  Failed to create group {cn}: {conn.result}")


def download_avatar(uid: str, name: str):
    """Download avatar from ui-avatars.com and save locally."""
    filepath = os.path.join(AVATAR_DIR, f"{uid}.png")

    if os.path.exists(filepath):
        print(f"  Avatar exists: {uid}.png")
        return

    # URL encode the name and use a consistent background
    import urllib.parse
    encoded_name = urllib.parse.quote(name)
    url = f"https://ui-avatars.com/api/?name={encoded_name}&size=256&background=random&format=png"

    try:
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200:
            with open(filepath, "wb") as f:
                f.write(resp.content)
            print(f"  Downloaded avatar: {uid}.png")
        else:
            print(f"  Failed to download avatar for {uid}: HTTP {resp.status_code}")
    except Exception as e:
        print(f"  Failed to download avatar for {uid}: {e}")


def main():
    print("=" * 60)
    print("Azblink Directory - Demo Data Seeder")
    print("=" * 60)

    # Connect to LDAP
    conn = get_connection()

    # Check if already seeded
    if check_already_seeded(conn):
        print("\n✓ Data already seeded (>10 users), skipping")
        print("=" * 60)
        return 0

    print("\nSeeding demo data...")

    # 1. Create OUs
    print("\n[1/4] Creating organizational units...")
    for dn, description in DEPARTMENTS:
        create_ou(conn, dn, description)

    # 2. Create users
    print("\n[2/4] Creating users...")
    for user in USERS:
        create_user(conn, user)

    # 3. Create/update groups
    print("\n[3/4] Creating/updating groups...")
    for group in GROUPS:
        create_or_update_group(conn, group)

    # 4. Download avatars
    print("\n[4/4] Downloading avatars...")
    os.makedirs(AVATAR_DIR, exist_ok=True)

    # Download for all users (existing + new)
    all_users_for_avatars = USERS + [
        {"uid": "robert", "displayName": "Robert Lin"},
        {"uid": "alex", "displayName": "Alex Chen"},
        {"uid": "sarah", "displayName": "Sarah Kim"},
        {"uid": "james", "displayName": "James Miller"},
        {"uid": "mei", "displayName": "Mei Wang"},
        {"uid": "kevin", "displayName": "Kevin Huang"},
        {"uid": "laura", "displayName": "Laura Chen"},
    ]

    for user in all_users_for_avatars:
        download_avatar(user["uid"], user["displayName"])

    # Final count
    conn.search(f"ou=people,{BASE_DN}", "(objectClass=inetOrgPerson)", search_scope=SUBTREE)
    user_count = len(conn.entries)

    conn.search(f"ou=org,{BASE_DN}", "(objectClass=organizationalUnit)", search_scope=SUBTREE)
    ou_count = len(conn.entries)

    conn.search(f"ou=groups,{BASE_DN}", "(objectClass=groupOfNames)", search_scope=SUBTREE)
    group_count = len(conn.entries)

    print("\n" + "=" * 60)
    print(f"✓ Seeding complete!")
    print(f"  - Users: {user_count}")
    print(f"  - OUs: {ou_count}")
    print(f"  - Groups: {group_count}")
    print(f"  - Avatars: {len(os.listdir(AVATAR_DIR))} files")
    print("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())
```

**Step 2: Commit**

```bash
git add deploy/dev/seed/seed_demo_data.py deploy/dev/Dockerfile.seed
git commit -m "feat(seed): add demo data seeder with 58 users

Creates organizational structure, users with full profile attributes,
department and role groups, and downloads cached avatars from
ui-avatars.com. Idempotent - skips if >10 users already exist.

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 4: Update Docker Compose

**Files:**
- Modify: `deploy/dev/docker-compose.yml`

**Step 1: Add seed service and avatar_cache volume**

Add after `directory-ui` service:

```yaml
  # One-time seed service - runs after LDAP is healthy
  seed:
    networks:
      - azblink-net
    build:
      context: ../..
      dockerfile: deploy/dev/Dockerfile.seed
    container_name: azblink-seed
    depends_on:
      openldap:
        condition: service_healthy
      postgres:
        condition: service_healthy
    environment:
      LDAP_URI: ldap://openldap:389
      LDAP_BIND_DN: cn=admin,dc=azblink,dc=com
      LDAP_BIND_PW: ${LDAP_ADMIN_PASSWORD:-adminpassword}
      AVATAR_OUTPUT_DIR: /avatars
    volumes:
      - avatar_cache:/avatars
    restart: "no"
```

**Step 2: Add avatar_cache volume to volumes section**

```yaml
volumes:
  azblink_pg_data:
  azblink_ldap_data:
  azblink_ldap_config:
  avatar_cache:
```

**Step 3: Mount avatar_cache in directory-ui service**

Add to directory-ui volumes:

```yaml
  directory-ui:
    # ... existing config ...
    volumes:
      - avatar_cache:/app/avatars:ro
```

**Step 4: Test deployment**

```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/deploy/dev
docker compose down -v  # Clean slate
docker compose up --build
```

Expected: Seed service runs, creates 58 users, downloads avatars, then exits.

**Step 5: Verify**

```bash
curl -s http://localhost:8000/api/users | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'Users: {len(d.get(\"users\", d))}')"
curl -s http://localhost:8001/avatars/dchang.png -o /dev/null -w "Avatar HTTP: %{http_code}\n"
```

Expected: ~58 users, Avatar HTTP: 200

**Step 6: Commit**

```bash
git add deploy/dev/docker-compose.yml
git commit -m "feat(deploy): add seed service and avatar cache volume

Seed service runs once after LDAP is healthy, populates demo data,
downloads avatars to shared volume. UI container mounts avatars
read-only at /app/avatars.

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 5: Update UI - directory_fixed.html

**Files:**
- Modify: `src/ui/directory_fixed.html`

**Step 1: Remove DEMO_ORG_NODES array**

Find and delete the entire `const DEMO_ORG_NODES = [...]` block (approximately lines containing org tree mock data).

**Step 2: Remove DEMO_PEOPLE array**

Find and delete the entire `const DEMO_PEOPLE = [...]` block.

**Step 3: Remove DEMO_GROUPS array**

Find and delete the entire `const DEMO_GROUPS = [...]` block.

**Step 4: Update DataSource to be API-only**

Replace the DataSource methods that have demo fallbacks with API-only versions. Change any `catch { return this._buildDemoTree() }` patterns to `catch { throw err }`.

**Step 5: Update avatar URLs**

Change avatar URL generation from:
```javascript
`https://ui-avatars.com/api/?name=${encodeURIComponent(name)}`
```
To:
```javascript
`/avatars/${uid}.png`
```

**Step 6: Add error UI**

Ensure there's an error display function and use it in init():
```javascript
function showError(msg) {
  document.body.innerHTML = `<div class="p-8 text-center">
    <p class="text-red-600 text-lg">${msg}</p>
    <p class="text-gray-500 mt-2">Check API connection in ⚙️ settings (bottom-right)</p>
  </div>`;
}
```

**Step 7: Test**

Open http://localhost:8001/directory_fixed.html - should load live data.

**Step 8: Commit**

```bash
git add src/ui/directory_fixed.html
git commit -m "refactor(ui): remove mock data from directory_fixed.html

UI now fetches exclusively from API. Avatars served from local cache.
Error state shown when API unavailable.

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 6: Update UI - directory_mobile_fixed.html

**Files:**
- Modify: `src/ui/directory_mobile_fixed.html`

**Steps:** Same pattern as Task 5:
1. Remove DEMO_* arrays
2. Update DataSource to API-only
3. Update avatar URLs to `/avatars/{uid}.png`
4. Add error handling
5. Test at http://localhost:8001/directory_mobile_fixed.html
6. Commit

```bash
git add src/ui/directory_mobile_fixed.html
git commit -m "refactor(ui): remove mock data from directory_mobile_fixed.html

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 7: Update UI - directory_manager_fixed.html

**Files:**
- Modify: `src/ui/directory_manager_fixed.html`

**Steps:** Same pattern as Task 5:
1. Remove DEMO_* arrays
2. Update DataSource to API-only
3. Update avatar URLs
4. Add error handling
5. Test at http://localhost:8001/directory_manager_fixed.html
6. Commit

```bash
git add src/ui/directory_manager_fixed.html
git commit -m "refactor(ui): remove mock data from directory_manager_fixed.html

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 8: Update UI - directory_manager_org_setup_fixed.html

**Files:**
- Modify: `src/ui/directory_manager_org_setup_fixed.html`

**Steps:** Same pattern:
1. Remove DEMO_* arrays
2. Update to API-only
3. Update avatar URLs
4. Test and commit

```bash
git add src/ui/directory_manager_org_setup_fixed.html
git commit -m "refactor(ui): remove mock data from directory_manager_org_setup_fixed.html

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 9: Update UI - directory_provision_manager_fixed.html

**Files:**
- Modify: `src/ui/directory_provision_manager_fixed.html`

**Steps:** Same pattern:
1. Remove DEMO_PROFILES, DEMO_ORG_TREE, DEMO_USERS, DEMO_GROUPS arrays
2. Update to API-only
3. Update avatar URLs
4. Test and commit

```bash
git add src/ui/directory_provision_manager_fixed.html
git commit -m "refactor(ui): remove mock data from directory_provision_manager_fixed.html

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 10: Update UI - my_profile.html

**Files:**
- Modify: `src/ui/my_profile.html`

**Steps:**
1. Remove any mock user data
2. Update to fetch current user from API (or use a demo user like `alex`)
3. Update avatar URL
4. Test and commit

```bash
git add src/ui/my_profile.html
git commit -m "refactor(ui): remove mock data from my_profile.html

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Task 11: End-to-End Testing

**Step 1: Clean restart**

```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/deploy/dev
docker compose down -v
docker compose up --build -d
```

**Step 2: Wait for seed to complete**

```bash
docker compose logs -f seed
# Wait for "Seeding complete!" message
```

**Step 3: Verify API**

```bash
# Users count
curl -s http://localhost:8000/api/users | python3 -c "import sys,json; print(len(json.load(sys.stdin)))"
# Expected: ~58

# Org tree
curl -s http://localhost:8000/api/org/tree | python3 -m json.tool | head -30

# Groups
curl -s http://localhost:8000/api/groups | python3 -m json.tool
```

**Step 4: Verify UI pages**

Open each in browser and verify data loads:
- http://localhost:8001/ (index)
- http://localhost:8001/directory_fixed.html
- http://localhost:8001/directory_mobile_fixed.html
- http://localhost:8001/directory_manager_fixed.html
- http://localhost:8001/my_profile.html

**Step 5: Verify avatars**

```bash
curl -s http://localhost:8001/avatars/dchang.png -o /dev/null -w "%{http_code}\n"
# Expected: 200
```

**Step 6: Verify idempotency**

```bash
docker compose restart seed
docker compose logs seed
# Expected: "Data already seeded (>10 users), skipping"
```

**Step 7: Final commit (if any fixes needed)**

```bash
git add -A
git commit -m "fix: address issues found in e2e testing

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Success Criteria Checklist

- [ ] `docker compose up` seeds 58 users automatically on first run
- [ ] Subsequent `docker compose up` skips seeding (idempotent)
- [ ] All UI pages load data from live API
- [ ] Avatars display correctly from local cache
- [ ] Org tree navigation works with real LDAP data
- [ ] User search returns live results
- [ ] No `DEMO_*` arrays remain in UI code
