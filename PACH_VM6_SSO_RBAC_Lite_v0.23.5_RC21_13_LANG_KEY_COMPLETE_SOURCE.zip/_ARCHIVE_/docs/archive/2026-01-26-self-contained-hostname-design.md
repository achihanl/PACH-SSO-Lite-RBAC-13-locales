# Self-Contained Hostname Configuration Design

**Date:** 2026-01-26
**Status:** Approved
**Problem:** Hardcoded `azblink-ad.keithmoc.dev` couples stack to external service

## Goals

- Zero-config default: stack works immediately after `just up`
- Path-based routing only: Traefik routes by URL path, not hostname
- VM-packaging ready: Vagrant/Packer distribution requires no hostname knowledge
- Optional restriction: `ALLOWED_HOSTS` pattern documented for future use

## Design Principles

1. **Self-contained** - No external DNS/tunnel dependencies baked in
2. **Works out-of-box** - `localhost`, IP addresses, tunnels all work without config
3. **Single source of truth** - Host restriction (if needed) configured in `.env` only
4. **Defense-in-depth** - Production VMs sit behind outer reverse proxy for real hostname routing

## Implementation

### Docker Compose Router Rules

**Before (hardcoded):**
```yaml
- "traefik.http.routers.api.rule=(Host(`azblink-ad.keithmoc.dev`) || Host(`localhost`)) && PathPrefix(`/api`)"
- "traefik.http.routers.ui.rule=Host(`azblink-ad.keithmoc.dev`) || Host(`localhost`)"
```

**After (path-only):**
```yaml
- "traefik.http.routers.api.rule=PathPrefix(`/api`)"
- "traefik.http.routers.ui.rule=PathPrefix(`/`)"
```

Routing priority preserved:
- API router: `priority=10` (higher) → matches `/api/*` first
- UI router: `priority=1` (lower) → catches everything else

### Environment Configuration

Add to `.env.example`:
```bash
# Hostname restriction (optional - usually not needed)
# By default, Traefik accepts requests on any hostname.
# The stack works via localhost, IP address, or tunnel without config.
# If you need to restrict: uncomment and set ALLOWED_HOSTS, then
# update docker-compose.yml router rules to use Host() matching.
# ALLOWED_HOSTS=localhost,myapp.example.com
```

### CORS (Existing Pattern)

`CORS_ORIGINS` in `.env` already controls browser access:
```bash
CORS_ORIGINS=http://localhost:8081,http://127.0.0.1:8081
```

Deployers add their hostname here for browser API access. This is the appropriate layer for access control.

## Files Changed

| File | Change |
|------|--------|
| `deploy/dev/docker-compose.yml` | Remove hardcoded hostnames from Traefik labels |
| `deploy/dev/.env.example` | Add commented `ALLOWED_HOSTS` documentation |
| `docs/plans/2026-01-22-traefik-proxy-design.md` | Update to reflect path-only routing |

## Migration

- Backward compatible: no action required for existing users
- Existing `.env` files don't need modification
- `just down && just up` picks up new routing rules

## Future Considerations

For Vagrant/Packer VM packaging:
- VM boots with working stack on any hostname
- Outer infrastructure (cloud LB, nginx, k8s ingress) handles production hostname routing
- Internal Traefik focuses on path-based service routing only
