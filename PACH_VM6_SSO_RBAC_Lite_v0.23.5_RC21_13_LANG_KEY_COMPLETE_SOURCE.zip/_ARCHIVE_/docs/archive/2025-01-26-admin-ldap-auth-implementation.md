# Admin LDAP Authentication Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add username/password login to the admin dashboard using LDAP bind authentication with JWT session tokens.

**Architecture:** Backend receives credentials, performs LDAP bind to verify, returns signed JWT. Frontend stores token, sends with all API requests, redirects to /login when unauthenticated.

**Tech Stack:** Python (FastAPI, PyJWT, ldap3), TypeScript (React 19, TanStack Router, Zustand, shadcn/ui)

**Design doc:** `docs/plans/2025-01-26-admin-ldap-authentication-design.md`

---

## Task 1: Add JWT Configuration

**Files:**
- Modify: `src/backend/config.py`

**Step 1: Add JWT environment variables**

Add these lines after the OIDC section (~line 50):

```python
# ----------------------------
# JWT Authentication (LDAP login)
# ----------------------------
JWT_SECRET = os.getenv("JWT_SECRET", "")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = int(os.getenv("JWT_EXPIRY_HOURS", "8"))
JWT_REMEMBER_DAYS = int(os.getenv("JWT_REMEMBER_DAYS", "7"))


def _validate_jwt_secret():
    """Warn if JWT_SECRET is not set (required for LDAP login)."""
    if not JWT_SECRET:
        import warnings
        warnings.warn(
            "JWT_SECRET not set. LDAP login will be disabled. "
            "Generate with: openssl rand -hex 32",
            RuntimeWarning
        )


_validate_jwt_secret()
```

**Step 2: Add to dev environment**

Edit `deploy/dev/.env.example` and add:

```bash
# JWT Authentication
JWT_SECRET=dev_jwt_secret_change_in_prod_openssl_rand_hex_32
```

**Step 3: Commit**

```bash
git add src/backend/config.py deploy/dev/.env.example
git commit -m "feat(auth): add JWT configuration for LDAP login"
```

---

## Task 2: Create Auth Module with LDAP Bind

**Files:**
- Create: `src/backend/auth.py`
- Test: `tests/test_auth.py`

**Step 1: Write the failing test**

Create `tests/test_auth.py`:

```python
"""Authentication endpoint tests."""

import pytest
from conftest import LDAP_BASE_DN, SEED_USER_UID


class TestAuthLogin:
    """POST /api/auth/login tests."""

    def test_login_valid_credentials(self, client):
        """Login with valid LDAP user returns token."""
        resp = client.post("/api/auth/login", json={
            "username": SEED_USER_UID,
            "password": "password123",  # Default seed password
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert "token" in data
        assert "user" in data
        assert data["user"]["uid"] == SEED_USER_UID

    def test_login_invalid_password(self, client):
        """Login with wrong password returns 401."""
        resp = client.post("/api/auth/login", json={
            "username": SEED_USER_UID,
            "password": "wrongpassword",
        })
        assert resp.status_code == 401
        data = resp.json()
        assert data["ok"] is False
        assert data["error"] == "INVALID_CREDENTIALS"

    def test_login_nonexistent_user(self, client):
        """Login with unknown user returns 401 (same error as wrong password)."""
        resp = client.post("/api/auth/login", json={
            "username": "nonexistent_user_xyz",
            "password": "anypassword",
        })
        assert resp.status_code == 401
        data = resp.json()
        assert data["ok"] is False
        assert data["error"] == "INVALID_CREDENTIALS"

    def test_login_missing_fields(self, client):
        """Login without username or password returns 422."""
        resp = client.post("/api/auth/login", json={})
        assert resp.status_code == 422

    def test_login_remember_me_extends_expiry(self, client):
        """Login with remember=true returns longer expiry."""
        import jwt
        from datetime import datetime, timezone

        resp = client.post("/api/auth/login", json={
            "username": SEED_USER_UID,
            "password": "password123",
            "remember": True,
        })
        assert resp.status_code == 200
        data = resp.json()

        # Decode without verification to check exp claim
        token_data = jwt.decode(data["token"], options={"verify_signature": False})
        exp = datetime.fromtimestamp(token_data["exp"], tz=timezone.utc)
        now = datetime.now(timezone.utc)

        # Should be > 24 hours (remember mode is 7 days)
        delta = exp - now
        assert delta.days >= 1, f"Expected > 1 day expiry, got {delta}"
```

**Step 2: Run test to verify it fails**

```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack
just test-quick tests/test_auth.py -v
```

Expected: FAIL with 404 (endpoint doesn't exist)

**Step 3: Create auth module**

Create `src/backend/auth.py`:

```python
"""LDAP bind authentication with JWT token generation.

Authenticates users against LDAP and issues JWT tokens for session management.
Designed as phase 1 of hybrid auth (LDAP now, OIDC later).
"""

from datetime import datetime, timezone, timedelta
from typing import Optional
import jwt
from pydantic import BaseModel, Field
from ldap3 import Server, Connection, ALL
from ldap3.core.exceptions import LDAPBindError, LDAPException

from config import (
    LDAP_URI,
    LDAP_USE_SSL,
    LDAP_BASE_DN,
    OU_PEOPLE,
    JWT_SECRET,
    JWT_ALGORITHM,
    JWT_EXPIRY_HOURS,
    JWT_REMEMBER_DAYS,
    OIDC_ADMIN_GROUP,
)
from ldap_client import find_user_dn, get_conn


class LoginRequest(BaseModel):
    """Login request payload."""
    username: str = Field(..., min_length=1, max_length=64)
    password: str = Field(..., min_length=1, max_length=128)
    remember: bool = False


class LoginUser(BaseModel):
    """User info returned after successful login."""
    uid: str
    dn: str
    displayName: str
    email: str
    isAdmin: bool
    groups: list[str]


class LoginResponse(BaseModel):
    """Successful login response."""
    ok: bool = True
    token: str
    user: LoginUser
    expiresAt: str  # ISO timestamp


class LoginError(BaseModel):
    """Failed login response."""
    ok: bool = False
    error: str
    detail: str


def _get_user_bind_connection(user_dn: str, password: str) -> Optional[Connection]:
    """Attempt LDAP bind with user credentials. Returns connection or None."""
    try:
        server = Server(LDAP_URI, get_info=ALL, use_ssl=LDAP_USE_SSL)
        conn = Connection(server, user=user_dn, password=password, auto_bind=True)
        return conn
    except LDAPBindError:
        return None
    except LDAPException:
        return None


def _fetch_user_details(user_dn: str) -> dict:
    """Fetch user attributes using service account."""
    conn = get_conn()
    conn.search(
        search_base=user_dn,
        search_filter="(objectClass=*)",
        search_scope="BASE",
        attributes=["uid", "displayName", "mail", "memberOf"]
    )
    if not conn.entries:
        conn.unbind()
        return {}

    entry = conn.entries[0]
    uid = entry.uid.value if hasattr(entry, "uid") else ""
    display_name = entry.displayName.value if hasattr(entry, "displayName") else uid
    mail = entry.mail.value if hasattr(entry, "mail") else ""

    # Extract group CNs from memberOf DNs
    groups = []
    if hasattr(entry, "memberOf"):
        for group_dn in entry.memberOf.values:
            # Extract CN from DN like "cn=IT-Admins,ou=groups,dc=azblink,dc=com"
            if group_dn.lower().startswith("cn="):
                cn = group_dn.split(",")[0][3:]
                groups.append(cn)

    conn.unbind()
    return {
        "uid": uid,
        "displayName": display_name,
        "mail": mail,
        "groups": groups,
    }


def _generate_jwt(user_data: dict, user_dn: str, remember: bool) -> tuple[str, datetime]:
    """Generate JWT token with user claims."""
    now = datetime.now(timezone.utc)

    if remember:
        expires = now + timedelta(days=JWT_REMEMBER_DAYS)
    else:
        expires = now + timedelta(hours=JWT_EXPIRY_HOURS)

    is_admin = OIDC_ADMIN_GROUP in user_data.get("groups", [])

    payload = {
        "uid": user_data["uid"],
        "dn": user_dn,
        "displayName": user_data.get("displayName", user_data["uid"]),
        "email": user_data.get("mail", ""),
        "isAdmin": is_admin,
        "groups": user_data.get("groups", []),
        "iat": int(now.timestamp()),
        "exp": int(expires.timestamp()),
    }

    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token, expires


def authenticate_user(request: LoginRequest) -> LoginResponse | LoginError:
    """Authenticate user via LDAP bind and return JWT token.

    Flow:
    1. Look up user DN by uid
    2. Attempt LDAP bind with user's password
    3. Fetch user attributes (displayName, mail, memberOf)
    4. Generate JWT token
    5. Return token + user info
    """
    if not JWT_SECRET:
        return LoginError(
            error="AUTH_DISABLED",
            detail="JWT authentication not configured"
        )

    # Step 1: Find user DN
    admin_conn = get_conn()
    user_dn = find_user_dn(admin_conn, OU_PEOPLE, request.username)
    admin_conn.unbind()

    if not user_dn:
        # Don't reveal whether user exists
        return LoginError(
            error="INVALID_CREDENTIALS",
            detail="Invalid username or password"
        )

    # Step 2: Verify password via LDAP bind
    user_conn = _get_user_bind_connection(user_dn, request.password)
    if not user_conn:
        return LoginError(
            error="INVALID_CREDENTIALS",
            detail="Invalid username or password"
        )
    user_conn.unbind()

    # Step 3: Fetch user details
    user_data = _fetch_user_details(user_dn)
    if not user_data:
        return LoginError(
            error="INVALID_CREDENTIALS",
            detail="Invalid username or password"
        )

    # Step 4: Generate JWT
    token, expires = _generate_jwt(user_data, user_dn, request.remember)

    # Step 5: Return response
    return LoginResponse(
        token=token,
        user=LoginUser(
            uid=user_data["uid"],
            dn=user_dn,
            displayName=user_data.get("displayName", user_data["uid"]),
            email=user_data.get("mail", ""),
            isAdmin=OIDC_ADMIN_GROUP in user_data.get("groups", []),
            groups=user_data.get("groups", []),
        ),
        expiresAt=expires.isoformat(),
    )


def verify_jwt_token(token: str) -> dict:
    """Verify and decode a JWT token. Raises jwt.InvalidTokenError on failure."""
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
```

**Step 4: Add endpoint to main.py**

Add import at top of `src/backend/main.py` (after other imports, ~line 52):

```python
from auth import LoginRequest, LoginResponse, LoginError, authenticate_user
```

Add endpoint after health check section (~line 291):

```python
# ----------------------------
# Authentication (LDAP login)
# ----------------------------
@app.post("/api/auth/login", response_model=LoginResponse | LoginError)
def api_auth_login(request: LoginRequest, req: Request):
    """Authenticate user via LDAP bind and return JWT token."""
    result = authenticate_user(request)

    if isinstance(result, LoginError):
        # Log failed attempt
        client_ip = req.client.host if req.client else "unknown"
        try:
            ORGDB.record_auth_failure(
                client_ip=client_ip,
                endpoint="/api/auth/login",
                failure_reason=result.error,
                username=request.username,
                user_agent=req.headers.get("user-agent"),
            )
        except Exception:
            pass  # Don't let audit failure break auth flow

        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=401, content=result.model_dump())

    return result
```

**Step 5: Run test to verify it passes**

```bash
just test-quick tests/test_auth.py -v
```

Expected: PASS (may need seed user password adjustment)

**Step 6: Commit**

```bash
git add src/backend/auth.py src/backend/main.py tests/test_auth.py
git commit -m "feat(auth): add LDAP bind login endpoint with JWT tokens"
```

---

## Task 3: Add shadcn/ui Components

**Files:**
- Create: `src/frontend/src/components/ui/alert-dialog.tsx` (via CLI)
- Create: `src/frontend/src/components/ui/dropdown-menu.tsx` (via CLI)
- Create: `src/frontend/src/components/ui/checkbox.tsx` (via CLI)
- Create: `src/frontend/src/components/ui/label.tsx` (via CLI)

**Step 1: Add required shadcn components**

```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend
npx shadcn@latest add alert-dialog dropdown-menu checkbox label
```

Select defaults when prompted.

**Step 2: Verify components installed**

```bash
ls -la src/components/ui/
```

Should show: `alert-dialog.tsx`, `dropdown-menu.tsx`, `checkbox.tsx`, `label.tsx`

**Step 3: Commit**

```bash
git add src/frontend/src/components/ui/ src/frontend/package.json src/frontend/package-lock.json
git commit -m "feat(ui): add shadcn alert-dialog, dropdown-menu, checkbox, label"
```

---

## Task 4: Update Auth Store

**Files:**
- Modify: `src/frontend/src/stores/auth-store.ts`

**Step 1: Rewrite auth store with login/logout actions**

Replace entire contents of `src/frontend/src/stores/auth-store.ts`:

```typescript
/**
 * Auth state store
 * - JWT token management
 * - User session info
 * - Login/logout actions
 * - Expiration tracking
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { getApi } from '@/lib/api-client';

export interface AuthUser {
  uid: string;
  dn: string;
  displayName: string;
  email: string;
  isAdmin: boolean;
  groups: string[];
}

interface LoginResponse {
  ok: boolean;
  token: string;
  user: AuthUser;
  expiresAt: string;
}

interface AuthState {
  token: string | null;
  user: AuthUser | null;
  expiresAt: number | null; // Unix timestamp (ms)
  rememberMe: boolean;

  // Actions
  login: (username: string, password: string, remember?: boolean) => Promise<void>;
  logout: () => void;
  isAuthenticated: () => boolean;
  isExpired: () => boolean;
  setRememberMe: (remember: boolean) => void;
}

// Storage key switches based on remember me preference
const STORAGE_KEY = 'azblink-auth';

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      token: null,
      user: null,
      expiresAt: null,
      rememberMe: false,

      login: async (username: string, password: string, remember = false) => {
        const api = getApi();
        const response = await api.post<LoginResponse>('/auth/login', {
          username,
          password,
          remember,
        });

        if (!response.ok) {
          throw new Error('Login failed');
        }

        set({
          token: response.token,
          user: response.user,
          expiresAt: new Date(response.expiresAt).getTime(),
          rememberMe: remember,
        });
      },

      logout: () => {
        set({
          token: null,
          user: null,
          expiresAt: null,
        });
        // Clear both storages
        sessionStorage.removeItem(STORAGE_KEY);
        localStorage.removeItem(STORAGE_KEY);
      },

      isAuthenticated: () => {
        const { token, expiresAt } = get();
        if (!token || !expiresAt) return false;
        return Date.now() < expiresAt;
      },

      isExpired: () => {
        const { token, expiresAt } = get();
        if (!token) return false; // Never logged in, not "expired"
        if (!expiresAt) return true;
        return Date.now() >= expiresAt;
      },

      setRememberMe: (remember: boolean) => set({ rememberMe: remember }),
    }),
    {
      name: STORAGE_KEY,
      storage: createJSONStorage(() => {
        // Use localStorage if rememberMe was checked, otherwise sessionStorage
        // This is checked when rehydrating
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          try {
            const parsed = JSON.parse(stored);
            if (parsed.state?.rememberMe) {
              return localStorage;
            }
          } catch {
            // Fall through to sessionStorage
          }
        }
        return sessionStorage;
      }),
      partialize: (state) => ({
        token: state.token,
        user: state.user,
        expiresAt: state.expiresAt,
        rememberMe: state.rememberMe,
      }),
    }
  )
);
```

**Step 2: Verify TypeScript compiles**

```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend
npx tsc --noEmit
```

Expected: No errors

**Step 3: Commit**

```bash
git add src/frontend/src/stores/auth-store.ts
git commit -m "feat(auth): update auth store with login/logout actions"
```

---

## Task 5: Update UI Store for Session Modal

**Files:**
- Modify: `src/frontend/src/stores/ui-store.ts`

**Step 1: Add session expired modal state**

Add to the interface and store in `src/frontend/src/stores/ui-store.ts`:

```typescript
/**
 * UI state store for app-wide UI state
 * - Sidebar collapsed state (persisted)
 * - Command palette open state
 * - Session expired modal state
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UIState {
  sidebarCollapsed: boolean;
  commandPaletteOpen: boolean;
  sessionExpiredModalOpen: boolean;

  toggleSidebar: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
  openCommandPalette: () => void;
  closeCommandPalette: () => void;
  showSessionExpiredModal: () => void;
  hideSessionExpiredModal: () => void;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      commandPaletteOpen: false,
      sessionExpiredModalOpen: false,

      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
      openCommandPalette: () => set({ commandPaletteOpen: true }),
      closeCommandPalette: () => set({ commandPaletteOpen: false }),
      showSessionExpiredModal: () => set({ sessionExpiredModalOpen: true }),
      hideSessionExpiredModal: () => set({ sessionExpiredModalOpen: false }),
    }),
    {
      name: 'azblink-ui',
      partialize: (state) => ({
        sidebarCollapsed: state.sidebarCollapsed,
        // Don't persist modal states
      }),
    }
  )
);
```

**Step 2: Commit**

```bash
git add src/frontend/src/stores/ui-store.ts
git commit -m "feat(ui): add session expired modal state to UI store"
```

---

## Task 6: Update API Client for Auth Handling

**Files:**
- Modify: `src/frontend/src/lib/api-client.ts`

**Step 1: Update onUnauthorized to trigger modal**

Replace the `onUnauthorized` section and add auth-aware handling:

```typescript
/**
 * Typed API client for AZBlink Directory backend
 * Matches FRONTEND_API_CONTRACTS.md §6.1
 */

import { extractError } from './errors';

export interface ApiClientConfig {
  baseUrl: string;
  getAuthToken?: () => Promise<string | null>;
  onUnauthorized?: (hadToken: boolean) => void;
  onRateLimited?: (retryAfter: number) => void;
}

let apiClient: ReturnType<typeof createApiClient> | null = null;

export function createApiClient(config: ApiClientConfig) {
  const { baseUrl, getAuthToken, onUnauthorized, onRateLimited } = config;

  async function request<T>(
    method: string,
    path: string,
    body?: unknown,
    params?: Record<string, unknown>
  ): Promise<T> {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };

    const token = await getAuthToken?.();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    // Build URL with query params
    let url = `${baseUrl}${path}`;
    if (params) {
      const searchParams = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          searchParams.append(key, String(value));
        }
      });
      const queryString = searchParams.toString();
      if (queryString) {
        url += `?${queryString}`;
      }
    }

    const response = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    // Handle rate limiting
    if (response.status === 429) {
      const retryAfter = parseInt(response.headers.get('Retry-After') || '60');
      onRateLimited?.(retryAfter);
      throw await extractError(response);
    }

    // Handle unauthorized
    if (response.status === 401) {
      // Pass whether we had a token (session expired vs never logged in)
      onUnauthorized?.(!!token);
      throw await extractError(response);
    }

    // Handle other errors
    if (!response.ok) {
      throw await extractError(response);
    }

    return response.json();
  }

  return {
    get: <T>(path: string, params?: Record<string, unknown>) =>
      request<T>('GET', path, undefined, params),
    post: <T>(path: string, body?: unknown) =>
      request<T>('POST', path, body),
    patch: <T>(path: string, body?: unknown) =>
      request<T>('PATCH', path, body),
    delete: <T>(path: string) =>
      request<T>('DELETE', path),
  };
}

export function initializeApi(config: ApiClientConfig) {
  apiClient = createApiClient(config);
}

export function getApi() {
  if (!apiClient) {
    throw new Error('API client not initialized. Call initializeApi first.');
  }
  return apiClient;
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/lib/api-client.ts
git commit -m "feat(api): update unauthorized handler to distinguish session expiry"
```

---

## Task 7: Create Session Expired Modal

**Files:**
- Create: `src/frontend/src/components/features/session-expired-modal.tsx`

**Step 1: Create the modal component**

```typescript
/**
 * Session expired modal
 * Shown when API returns 401 for a user who had an active session
 * Non-dismissable - user must choose to log in again or cancel
 */

import { useNavigate, useLocation } from '@tanstack/react-router';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useUIStore } from '@/stores/ui-store';
import { useAuthStore } from '@/stores/auth-store';
import { Clock } from 'lucide-react';

export function SessionExpiredModal() {
  const { sessionExpiredModalOpen, hideSessionExpiredModal } = useUIStore();
  const { logout } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLoginAgain = () => {
    hideSessionExpiredModal();
    logout();
    // Preserve current path for redirect after login
    const redirectPath = encodeURIComponent(location.pathname);
    navigate({ to: '/login', search: { redirect: redirectPath } });
  };

  const handleCancel = () => {
    hideSessionExpiredModal();
    // User stays on page but won't be able to make API calls
  };

  return (
    <AlertDialog open={sessionExpiredModalOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center">
              <Clock className="h-5 w-5 text-amber-600" />
            </div>
            <AlertDialogTitle>Session Expired</AlertDialogTitle>
          </div>
          <AlertDialogDescription className="pt-2">
            Your session has expired due to inactivity. Please log in again to
            continue working.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={handleCancel}>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={handleLoginAgain}>
            Log in again
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/session-expired-modal.tsx
git commit -m "feat(ui): add session expired modal component"
```

---

## Task 8: Create Profile Dropdown

**Files:**
- Create: `src/frontend/src/components/features/profile-dropdown.tsx`

**Step 1: Create the dropdown component**

```typescript
/**
 * Profile dropdown menu for header
 * Shows user info, admin badge, navigation links, and logout
 */

import { useNavigate } from '@tanstack/react-router';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuthStore } from '@/stores/auth-store';
import { ChevronDown, User, Settings, LogOut, Shield } from 'lucide-react';

export function ProfileDropdown() {
  const { user, logout, isAuthenticated } = useAuthStore();
  const navigate = useNavigate();

  if (!isAuthenticated() || !user) {
    return null;
  }

  // Get initials from display name
  const initials = user.displayName
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const handleLogout = () => {
    logout();
    navigate({ to: '/login' });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-10 gap-2 px-2">
          <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center">
            <span className="text-accent-foreground text-sm font-medium">
              {initials}
            </span>
          </div>
          <span className="hidden lg:block text-sm font-medium max-w-[120px] truncate">
            {user.displayName}
          </span>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium">{user.displayName}</p>
            <p className="text-xs text-muted-foreground truncate">
              {user.email || user.uid}
            </p>
          </div>
        </DropdownMenuLabel>

        {user.isAdmin && (
          <>
            <DropdownMenuSeparator />
            <div className="px-2 py-1.5">
              <Badge variant="secondary" className="gap-1">
                <Shield className="h-3 w-3" />
                Administrator
              </Badge>
            </div>
          </>
        )}

        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={() => navigate({ to: '/my-profile' })}>
          <User className="mr-2 h-4 w-4" />
          My Profile
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => navigate({ to: '/settings' })}>
          <Settings className="mr-2 h-4 w-4" />
          Settings
        </DropdownMenuItem>

        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={handleLogout} className="text-red-600">
          <LogOut className="mr-2 h-4 w-4" />
          Log out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/profile-dropdown.tsx
git commit -m "feat(ui): add profile dropdown component"
```

---

## Task 9: Create Login Page

**Files:**
- Create: `src/frontend/src/routes/login.tsx`

**Step 1: Create the login route component**

```typescript
/**
 * Login page - standalone (no sidebar/header)
 * LDAP bind authentication with optional "remember me"
 */

import { useState } from 'react';
import { createFileRoute, useNavigate, useSearch } from '@tanstack/react-router';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuthStore } from '@/stores/auth-store';
import { Loader2, Lock } from 'lucide-react';

export const Route = createFileRoute('/login')({
  validateSearch: (search: Record<string, unknown>) => ({
    redirect: (search.redirect as string) || '/',
  }),
  component: LoginPage,
});

function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const { login, isAuthenticated } = useAuthStore();
  const navigate = useNavigate();
  const { redirect } = useSearch({ from: '/login' });

  // If already authenticated, redirect
  if (isAuthenticated()) {
    navigate({ to: redirect || '/' });
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!username.trim() || !password) {
      toast.error('Please enter username and password');
      return;
    }

    setIsLoading(true);

    try {
      await login(username.trim(), password, rememberMe);
      toast.success('Login successful');
      navigate({ to: redirect || '/' });
    } catch (error) {
      // Vague error message for security
      toast.error('Invalid username or password');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo and title */}
        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 rounded-xl bg-slate-900 items-center justify-center mb-4">
            <span className="text-white font-bold text-xl">AZ</span>
          </div>
          <h1 className="text-2xl font-semibold text-slate-900">AZBlink Directory</h1>
          <p className="text-slate-600 mt-1">Admin Portal</p>
        </div>

        {/* Login card */}
        <Card>
          <CardHeader className="space-y-1">
            <CardTitle className="text-xl">Sign in</CardTitle>
            <CardDescription>
              Enter your credentials to access the admin dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  disabled={isLoading}
                  autoComplete="username"
                  autoFocus
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isLoading}
                  autoComplete="current-password"
                />
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked === true)}
                  disabled={isLoading}
                />
                <Label
                  htmlFor="remember"
                  className="text-sm font-normal cursor-pointer"
                >
                  Remember me
                </Label>
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  'Sign in'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-sm text-slate-500 mt-6 flex items-center justify-center gap-1">
          <Lock className="h-3 w-3" />
          Secured by LDAP authentication
        </p>
      </div>
    </div>
  );
}
```

**Step 2: Regenerate route tree**

```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack/src/frontend
npx @tanstack/router-cli generate
```

**Step 3: Commit**

```bash
git add src/frontend/src/routes/login.tsx src/frontend/src/routeTree.gen.ts
git commit -m "feat(ui): add login page with LDAP authentication"
```

---

## Task 10: Update Header with Profile Dropdown

**Files:**
- Modify: `src/frontend/src/components/layout/header.tsx`

**Step 1: Replace static profile button with dropdown**

Replace the Profile section at the end of the header (~line 71-78):

```typescript
/**
 * Top header component
 * Layout: enterprise-ui-redesign.md §4.1
 * Height: 56px, fixed position, z-30
 */

import { Menu, Search, Bell, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUIStore } from '@/stores/ui-store';
import { ProfileDropdown } from '@/components/features/profile-dropdown';

export function Header() {
  const { toggleSidebar, openCommandPalette } = useUIStore();

  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-surface border-b border-border z-header flex items-center px-4">
      {/* Left section */}
      <div className="flex items-center gap-4 flex-shrink-0">
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleSidebar}
          className="h-10 w-10"
          aria-label="Toggle sidebar"
        >
          <Menu className="h-5 w-5" />
        </Button>

        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-md bg-accent flex items-center justify-center">
            <span className="text-accent-foreground font-bold text-sm">AZ</span>
          </div>
          <span className="font-semibold text-text hidden sm:block">AZBlink</span>
        </div>
      </div>

      {/* Center - Search (absolute positioned for true centering) */}
      <div className="absolute left-1/2 -translate-x-1/2 w-full max-w-xl px-4 hidden md:block">
        <button
          onClick={openCommandPalette}
          className="w-full h-10 px-4 flex items-center gap-2 text-muted-foreground bg-muted rounded-md hover:bg-slate-200 transition-colors"
        >
          <Search className="h-4 w-4" />
          <span className="flex-1 text-left text-sm">Search anything...</span>
          <kbd className="hidden lg:inline-flex h-5 items-center gap-1 rounded border border-border bg-surface px-1.5 font-mono text-xs text-muted-foreground">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right section */}
      <div className="flex items-center gap-2 ml-auto flex-shrink-0">
        <Button
          variant="ghost"
          size="icon"
          className="h-10 w-10 md:hidden"
          onClick={openCommandPalette}
          aria-label="Search"
        >
          <Search className="h-5 w-5" />
        </Button>

        <Button variant="ghost" size="icon" className="h-10 w-10" aria-label="Notifications">
          <Bell className="h-5 w-5" />
        </Button>

        <Button variant="ghost" size="icon" className="h-10 w-10" aria-label="Help">
          <HelpCircle className="h-5 w-5" />
        </Button>

        {/* Profile dropdown */}
        <ProfileDropdown />
      </div>
    </header>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/layout/header.tsx
git commit -m "feat(ui): replace static profile button with dropdown"
```

---

## Task 11: Add Route Protection

**Files:**
- Modify: `src/frontend/src/routes/__root.tsx`

**Step 1: Add auth check and redirect logic**

Update `__root.tsx` to check auth and redirect:

```typescript
/**
 * Root route - App shell with header, sidebar, and content area
 * Layout matches enterprise-ui-redesign.md §3.1
 * Includes auth protection - redirects to /login if not authenticated
 */

import { useEffect } from 'react';
import { createRootRoute, Outlet, useNavigate, useLocation } from '@tanstack/react-router';
import { TanStackRouterDevtools } from '@tanstack/react-router-devtools';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { Breadcrumb } from '@/components/layout/breadcrumb';
import { SessionExpiredModal } from '@/components/features/session-expired-modal';
import { useUIStore } from '@/stores/ui-store';
import { useAuthStore } from '@/stores/auth-store';
import { useKeyboardShortcuts } from '@/hooks/use-keyboard';
import { cn } from '@/lib/utils';

// Routes that don't require authentication
const PUBLIC_ROUTES = ['/login'];

export const Route = createRootRoute({
  component: RootLayout,
});

function RootLayout() {
  const { sidebarCollapsed } = useUIStore();
  const { isAuthenticated } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  useKeyboardShortcuts();

  const isPublicRoute = PUBLIC_ROUTES.includes(location.pathname);
  const isAuthed = isAuthenticated();

  useEffect(() => {
    // Redirect to login if not authenticated and not on public route
    if (!isAuthed && !isPublicRoute) {
      const redirectPath = encodeURIComponent(location.pathname);
      navigate({ to: '/login', search: { redirect: redirectPath } });
    }
  }, [isAuthed, isPublicRoute, location.pathname, navigate]);

  // For public routes (login), render without shell
  if (isPublicRoute) {
    return (
      <>
        <Outlet />
        {import.meta.env.DEV && <TanStackRouterDevtools />}
      </>
    );
  }

  // For protected routes, show loading or redirect will happen via useEffect
  if (!isAuthed) {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />

      <main
        className={cn(
          'pt-14 transition-all duration-200',
          sidebarCollapsed ? 'ml-16' : 'ml-64'
        )}
      >
        <Breadcrumb />
        <div className="p-6">
          <Outlet />
        </div>
      </main>

      {/* Session expired modal */}
      <SessionExpiredModal />

      {import.meta.env.DEV && <TanStackRouterDevtools />}
    </div>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/routes/__root.tsx
git commit -m "feat(auth): add route protection with login redirect"
```

---

## Task 12: Update main.tsx with Session Expiry Handler

**Files:**
- Modify: `src/frontend/src/main.tsx`

**Step 1: Update API initialization to handle session expiry**

```typescript
/**
 * Application entry point
 * - Initializes API client with auth handlers
 * - Verifies backend services on startup
 * - Sets up React Query and Router providers
 * - Mounts app to DOM
 */

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { RouterProvider, createRouter } from '@tanstack/react-router';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { Toaster } from 'sonner';
import { routeTree } from './routeTree.gen';
import { initializeApi } from '@/lib/api-client';
import { useAuthStore } from '@/stores/auth-store';
import { useUIStore } from '@/stores/ui-store';
import { StartupCheck } from '@/components/features/startup-check';
import '@/styles/globals.css';

// Initialize API client with auth handlers
initializeApi({
  baseUrl: import.meta.env.VITE_API_BASE || '/api',
  getAuthToken: () => Promise.resolve(useAuthStore.getState().token),
  onUnauthorized: (hadToken: boolean) => {
    if (hadToken) {
      // Had a token but got 401 → session expired
      useUIStore.getState().showSessionExpiredModal();
    } else {
      // No token → redirect to login
      window.location.href = '/login';
    }
  },
  onRateLimited: (retryAfter) => {
    console.warn(`Rate limited. Retry after ${retryAfter}s`);
  },
});

// Create query client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: 1,
    },
  },
});

// Create router
const router = createRouter({
  routeTree,
  context: { queryClient },
  defaultPreload: 'intent',
});

// Type registration for router
declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

// Render app with startup health check
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <StartupCheck>
        <RouterProvider router={router} />
      </StartupCheck>
      <Toaster position="bottom-right" richColors />
      {import.meta.env.DEV && (
        <ReactQueryDevtools initialIsOpen={false} />
      )}
    </QueryClientProvider>
  </StrictMode>
);
```

**Step 2: Commit**

```bash
git add src/frontend/src/main.tsx
git commit -m "feat(auth): wire up session expiry handler in API client"
```

---

## Task 13: Add JWT_SECRET to Docker Environment

**Files:**
- Modify: `deploy/dev/docker-compose.yml`
- Modify: `deploy/dev/.env` (local file, don't commit actual secret)

**Step 1: Add JWT_SECRET to docker-compose.yml**

Find the `api` service and add JWT_SECRET to environment:

```yaml
    environment:
      # ... existing vars ...
      JWT_SECRET: ${JWT_SECRET:-dev_jwt_secret_change_in_prod_openssl_rand_hex_32}
```

**Step 2: Update local .env file**

```bash
echo 'JWT_SECRET=dev_jwt_secret_change_in_prod_openssl_rand_hex_32' >> deploy/dev/.env
```

**Step 3: Commit docker-compose changes**

```bash
git add deploy/dev/docker-compose.yml deploy/dev/.env.example
git commit -m "feat(deploy): add JWT_SECRET to docker environment"
```

---

## Task 14: Integration Test

**Step 1: Rebuild and restart stack**

```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack
just down && just up-bg
```

**Step 2: Run backend tests**

```bash
just test-quick tests/test_auth.py -v
```

Expected: All PASS

**Step 3: Build and test frontend**

```bash
cd src/frontend
npm run build
npm run dev
```

**Step 4: Manual verification**

1. Open http://localhost:3000 → should redirect to /login
2. Enter invalid credentials → should show error toast
3. Enter valid credentials (seed user) → should redirect to dashboard
4. Click profile dropdown → should show user info and logout
5. Click logout → should redirect to /login
6. Wait for token expiry (or manually clear token) → make API call → should show session expired modal

**Step 5: Commit any fixes from testing**

```bash
git add -A
git commit -m "fix(auth): integration test fixes"
```

---

## Task 15: Final Cleanup and Documentation

**Step 1: Update CLAUDE.md if needed**

Add note about auth testing to CLAUDE.md if helpful.

**Step 2: Final commit**

```bash
git add -A
git commit -m "docs: update documentation for LDAP authentication"
```

---

## Summary

| Task | Description | Est. Time |
|------|-------------|-----------|
| 1 | Add JWT configuration | 3 min |
| 2 | Create auth module + tests | 15 min |
| 3 | Add shadcn components | 3 min |
| 4 | Update auth store | 5 min |
| 5 | Update UI store | 3 min |
| 6 | Update API client | 3 min |
| 7 | Create session expired modal | 5 min |
| 8 | Create profile dropdown | 5 min |
| 9 | Create login page | 10 min |
| 10 | Update header | 3 min |
| 11 | Add route protection | 5 min |
| 12 | Update main.tsx | 3 min |
| 13 | Update docker environment | 3 min |
| 14 | Integration test | 10 min |
| 15 | Final cleanup | 5 min |

**Total estimated time:** ~80 minutes

---

**Dependencies to verify before starting:**
- Docker stack running (`just ps`)
- Seed user exists with known password
- Node.js and npm available for frontend
