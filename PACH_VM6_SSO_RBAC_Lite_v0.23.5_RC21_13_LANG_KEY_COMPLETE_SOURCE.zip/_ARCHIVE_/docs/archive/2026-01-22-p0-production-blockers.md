# P0 Production Blockers Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Fix the three critical blockers preventing production deployment: rate limiting, one-time token enforcement, and user termination.

**Architecture:** Add Redis for rate limiting state; extend PostgreSQL schema for audit tables; implement token validation middleware and termination endpoint with ordered cleanup actions.

**Tech Stack:** FastAPI, Redis (via redis-py), slowapi (rate limiting), SQLAlchemy Core, existing LDAP client.

---

## Prerequisites

Before starting, ensure you have the dev environment running:

```bash
cd deploy/dev && just up
```

---

## Task 1: Add Redis to Docker Compose

**Files:**
- Modify: `deploy/dev/docker-compose.yml`

**Step 1: Add Redis service to docker-compose.yml**

Add after the `postgres` service (around line 20):

```yaml
  # Redis - rate limiting and caching
  redis:
    networks:
      - azblink-net
    image: redis:7-alpine
    container_name: azblink-redis
    ports:
      - "6379:6379"
    volumes:
      - azblink_redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 5s
      timeout: 5s
      retries: 5
```

**Step 2: Add redis volume**

Add to the `volumes:` section (around line 154):

```yaml
  azblink_redis_data:
```

**Step 3: Add Redis environment to directory-api service**

Add to directory-api environment section (around line 77):

```yaml
      REDIS_URL: ${REDIS_URL:-redis://redis:6379/0}
```

**Step 4: Add Redis dependency to directory-api**

Update directory-api `depends_on` section:

```yaml
    depends_on:
      postgres:
        condition: service_healthy
      openldap:
        condition: service_healthy
      redis:
        condition: service_healthy
```

**Step 5: Restart stack to verify**

Run: `cd deploy/dev && just down && just up`

Expected: All services healthy including redis.

**Step 6: Commit**

```bash
git add deploy/dev/docker-compose.yml
git commit -m "feat(infra): add Redis service for rate limiting

Adds Redis 7 Alpine to dev stack with health checks.
Required for rate limiting implementation."
```

---

## Task 2: Add Redis and Rate Limiting Dependencies

**Files:**
- Modify: `src/backend/requirements.txt`

**Step 1: Add dependencies**

Add these lines to `src/backend/requirements.txt`:

```
redis>=5.0
slowapi>=0.1.9
```

**Step 2: Rebuild API container**

Run: `just api-rebuild`

Expected: Container rebuilds with new dependencies.

**Step 3: Commit**

```bash
git add src/backend/requirements.txt
git commit -m "feat(deps): add redis and slowapi for rate limiting"
```

---

## Task 3: Add Redis Configuration

**Files:**
- Modify: `src/backend/config.py`

**Step 1: Add Redis config variables**

Add after the BREAKGLASS_FILE section (around line 58):

```python
# ----------------------------
# Redis (rate limiting, caching)
# ----------------------------
REDIS_URL = os.getenv("REDIS_URL", "redis://127.0.0.1:6379/0")
```

**Step 2: Verify hot reload picks up change**

Run: `just logs`

Expected: No errors on API startup.

**Step 3: Commit**

```bash
git add src/backend/config.py
git commit -m "feat(config): add REDIS_URL configuration"
```

---

## Task 4: Create Rate Limiting Module

**Files:**
- Create: `src/backend/rate_limit.py`

**Step 1: Create the rate limiting module**

Create `src/backend/rate_limit.py`:

```python
"""rate_limit.py

Redis-backed rate limiting using slowapi.

Limits per spec Section 0.3:
- /api/bootstrap: 5/hour
- /api/users/create: 20/minute
- /api/users/*/qrcode*: 10/minute
- Auth failures: 5/5min (handled separately in auth)
- Default: 100/minute
"""

from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from fastapi import Request
from fastapi.responses import JSONResponse
import redis

from config import REDIS_URL


def _get_redis_storage():
    """Return redis storage URI for slowapi."""
    return f"redis://{REDIS_URL.split('://', 1)[-1]}"


# Key function extracts client IP
def get_client_ip(request: Request) -> str:
    # Check X-Forwarded-For for reverse proxy setups
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return get_remote_address(request)


# Create limiter with Redis backend
limiter = Limiter(
    key_func=get_client_ip,
    storage_uri=REDIS_URL,
    strategy="fixed-window",
)


def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded):
    """Custom 429 response for rate limit exceeded."""
    return JSONResponse(
        status_code=429,
        content={
            "ok": False,
            "error": "rate_limit_exceeded",
            "detail": str(exc.detail),
            "retry_after": exc.retry_after,
        },
        headers={"Retry-After": str(exc.retry_after)},
    )


# Rate limit decorators for different endpoint categories
# Usage: @limit_bootstrap on endpoint function

LIMIT_BOOTSTRAP = "5/hour"
LIMIT_USER_CREATE = "20/minute"
LIMIT_QR = "10/minute"
LIMIT_DEFAULT = "100/minute"
```

**Step 2: Verify file created**

Run: `ls -la src/backend/rate_limit.py`

Expected: File exists.

**Step 3: Commit**

```bash
git add src/backend/rate_limit.py
git commit -m "feat(security): add rate limiting module with Redis backend

Implements spec Section 0.3 rate limits:
- Bootstrap: 5/hour
- User create: 20/minute
- QR endpoints: 10/minute
- Default: 100/minute"
```

---

## Task 5: Integrate Rate Limiting into FastAPI App

**Files:**
- Modify: `src/backend/main.py`

**Step 1: Add imports at top of main.py**

Add after the existing imports (around line 10):

```python
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from rate_limit import (
    limiter,
    rate_limit_exceeded_handler,
    LIMIT_BOOTSTRAP,
    LIMIT_USER_CREATE,
    LIMIT_QR,
    LIMIT_DEFAULT,
)
```

**Step 2: Register limiter with FastAPI app**

Add after the app creation (around line 47, after `app = FastAPI(...)`):

```python
# Rate limiting
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)
```

**Step 3: Add rate limit to bootstrap endpoint**

Modify the `/api/bootstrap` endpoint (around line 322):

```python
@app.post("/api/bootstrap")
@limiter.limit(LIMIT_BOOTSTRAP)
def api_bootstrap(request: Request, claims: Dict[str, Any] = Depends(require_admin)):
    return {"ok": True, **bootstrap_base_ous()}
```

Note: Added `request: Request` parameter - required for rate limiting.

**Step 4: Add rate limit to user create endpoint**

Modify the `/api/users/create` endpoint (around line 431):

```python
@app.post("/api/users/create")
@limiter.limit(LIMIT_USER_CREATE)
def api_user_create(request: Request, req: UserCreateReq, claims: Dict[str, Any] = Depends(require_admin)):
```

**Step 5: Add rate limit to QR endpoints**

Modify `/api/users/{uid}/qrcode` (around line 549):

```python
@app.get("/api/users/{uid}/qrcode")
@limiter.limit(LIMIT_QR)
def api_user_qrcode(request: Request, uid: str, claims: Dict[str, Any] = Depends(require_user)):
```

Modify `/api/users/{uid}/qrcodes` (around line 587):

```python
@app.get("/api/users/{uid}/qrcodes")
@limiter.limit(LIMIT_QR)
def api_user_qrcodes(request: Request, uid: str, claims: Dict[str, Any] = Depends(require_user)):
```

**Step 6: Verify API starts without errors**

Run: `just logs`

Expected: API starts, no import errors.

**Step 7: Test rate limiting works**

Run: `for i in {1..6}; do curl -s http://localhost:8081/api/bootstrap -X POST | jq .ok; done`

Expected: First 5 return `true` or auth error, 6th returns rate limit error.

**Step 8: Commit**

```bash
git add src/backend/main.py
git commit -m "feat(security): integrate rate limiting on critical endpoints

Applies rate limits:
- POST /api/bootstrap: 5/hour
- POST /api/users/create: 20/minute
- GET /api/users/{uid}/qrcode*: 10/minute"
```

---

## Task 6: Create Audit Tables Schema

**Files:**
- Modify: `src/backend/orgdb.py`

**Step 1: Add termination_events table definition**

Add after the `provision_tokens` table definition (around line 96):

```python
termination_events = Table(
    "termination_events",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("user_uid", String(255), nullable=False),
    Column("user_dn", Text, nullable=True),
    Column("org_dn", Text, nullable=True),
    Column("terminated_by", String(255), nullable=False),
    Column("reason", String(100), nullable=False),
    Column("timestamp", DateTime(timezone=True), nullable=False),
    Column("actions_taken", Text, nullable=False),  # JSON string
    Column("ldap_disabled", Boolean, nullable=True),
    Column("tokens_revoked", Integer, nullable=True),
    Column("authentik_sessions_revoked", Integer, nullable=True),
    Column("uc_sessions_terminated", Integer, nullable=True),
)
```

**Step 2: Add qr_issuance_audit table for enhanced tracking**

Add after termination_events:

```python
qr_issuance_audit = Table(
    "qr_issuance_audit",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("user_uid", String(255), nullable=False),
    Column("org_dn", Text, nullable=True),
    Column("issued_by", String(255), nullable=True),
    Column("issued_at", DateTime(timezone=True), nullable=False),
    Column("token_hash", String(64), nullable=False),
    Column("expires_at", DateTime(timezone=True), nullable=False),
    Column("consumed", Boolean, nullable=False, default=False),
    Column("consumed_at", DateTime(timezone=True), nullable=True),
    Column("consumed_reason", String(50), nullable=True),
    Column("client_ip", String(45), nullable=True),
    Column("user_agent", Text, nullable=True),
)
```

**Step 3: Add OrgDB methods for termination events**

Add after the provision_tokens methods (around line 255):

```python
    # -----------------
    # Termination events
    # -----------------
    def record_termination(
        self,
        user_uid: str,
        user_dn: str | None,
        org_dn: str | None,
        terminated_by: str,
        reason: str,
        actions_taken: dict,
        ldap_disabled: bool | None = None,
        tokens_revoked: int | None = None,
        authentik_sessions_revoked: int | None = None,
        uc_sessions_terminated: int | None = None,
    ) -> int:
        """Record a user termination event. Returns the event ID."""
        import json
        eng = self.connect()
        with eng.begin() as conn:
            result = conn.execute(
                insert(termination_events).values(
                    user_uid=user_uid,
                    user_dn=user_dn,
                    org_dn=org_dn,
                    terminated_by=terminated_by,
                    reason=reason,
                    timestamp=utcnow(),
                    actions_taken=json.dumps(actions_taken),
                    ldap_disabled=ldap_disabled,
                    tokens_revoked=tokens_revoked,
                    authentik_sessions_revoked=authentik_sessions_revoked,
                    uc_sessions_terminated=uc_sessions_terminated,
                )
            )
            return result.inserted_primary_key[0]

    def revoke_tokens_for_user(self, uid: str) -> int:
        """Revoke all active provision tokens for a user. Returns count revoked."""
        eng = self.connect()
        with eng.begin() as conn:
            result = conn.execute(
                update(provision_tokens)
                .where(
                    (provision_tokens.c.uid == uid) &
                    (provision_tokens.c.status == "active")
                )
                .values(status="revoked_terminated", used_at=utcnow())
            )
            return result.rowcount
```

**Step 4: Verify API restarts without errors**

Run: `just logs`

Expected: Tables created automatically via `metadata.create_all()`.

**Step 5: Verify tables exist**

Run: `just psql -c "\dt"`

Expected: See `termination_events` and `qr_issuance_audit` tables.

**Step 6: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "feat(db): add termination_events and qr_issuance_audit tables

Schema for user termination audit trail per spec Section 6.2
and enhanced QR issuance tracking per spec Section 11."
```

---

## Task 7: Add LDAP Account Disable Function

**Files:**
- Modify: `src/backend/ldap_client.py`

**Step 1: Add disable_user function**

Add after `move_user_to_org` function (around line 565):

```python
def disable_user(uid: str) -> Dict[str, Any]:
    """Disable a user account by renaming to disabled-{uid}.

    Note: OpenLDAP doesn't have userAccountControl like AD.
    We disable by:
    1. Clearing the userPassword (prevents bind)
    2. Optionally renaming the entry to mark it disabled

    For now, we just clear the password which prevents login.
    """
    def _op():
        conn = get_conn()
        user_dn = find_user_dn(conn, OU_PEOPLE, uid)
        if not user_dn:
            raise RuntimeError("User not found")

        # Clear password to prevent authentication
        # Using a known-invalid hash that can never match
        conn.modify(user_dn, {"userPassword": [(MODIFY_REPLACE, ["{DISABLED}"])]})
        if conn.result.get("description") != "success":
            raise RuntimeError(f"LDAP disable user failed: {conn.result}")

        conn.unbind()
        return {"ok": True, "user_dn": user_dn, "disabled": True}

    return safe_ldap(_op)
```

**Step 2: Verify hot reload**

Run: `just logs`

Expected: No errors.

**Step 3: Commit**

```bash
git add src/backend/ldap_client.py
git commit -m "feat(ldap): add disable_user function for termination flow

Disables user by setting password to invalid hash.
Used by termination endpoint to prevent login."
```

---

## Task 8: Implement User Termination Endpoint

**Files:**
- Modify: `src/backend/main.py`

**Step 1: Add import for disable_user**

Update the ldap_client imports (around line 21):

```python
from ldap_client import (
    bootstrap_base_ous,
    get_org_tree,
    create_org_ou,
    rename_org_ou,
    delete_org_ou,
    list_groups,
    create_group,
    group_add_member,
    group_remove_member,
    list_users,
    list_users_for_org,
    get_user,
    get_user_groups,
    get_group_members,
    create_user,
    reset_user_password,
    move_user_to_org,
    get_conn,
    find_user_dn,
    disable_user,
)
```

**Step 2: Add Pydantic model for termination request**

Add after `ImportCsvReq` model (around line 308):

```python
class UserTerminateReq(BaseModel):
    reason: str = Field(..., description="Reason for termination (e.g., employment_ended)")
    immediate: bool = Field(default=True, description="If true, terminate immediately")
```

**Step 3: Add termination endpoint**

Add after the `/api/users/move_org` endpoint (around line 463):

```python
@app.post("/api/users/{uid}/terminate")
@limiter.limit(LIMIT_USER_CREATE)  # Same limit as create - admin action
def api_user_terminate(
    request: Request,
    uid: str,
    req: UserTerminateReq,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Terminate a user account per spec Section 6.2.

    Actions performed in order:
    1. Disable LDAP account
    2. Invalidate all provisioning tokens
    3. Revoke Authentik sessions (if configured)
    4. Signal UC Server to kill sessions (if configured)
    5. Log termination event
    """
    # Get user info first
    user = get_user(uid)
    if not user:
        raise HTTPException(404, "User not found")

    user_dn = user.get("dn")
    org_dn = user.get("orgDn")
    terminated_by = claims.get("sub", "unknown")

    actions = {}

    # 1. Disable LDAP account
    try:
        disable_user(uid)
        actions["ldap_disabled"] = True
        ldap_disabled = True
    except Exception as e:
        actions["ldap_disabled"] = False
        actions["ldap_error"] = str(e)
        ldap_disabled = False

    # 2. Invalidate all provisioning tokens
    try:
        tokens_revoked = ORGDB.revoke_tokens_for_user(uid)
        actions["tokens_revoked"] = tokens_revoked
    except Exception as e:
        tokens_revoked = 0
        actions["tokens_revoked_error"] = str(e)

    # 3. Revoke Authentik sessions (placeholder - not implemented yet)
    # TODO: Implement when Authentik integration is added
    authentik_sessions_revoked = None
    actions["authentik_sessions"] = "not_configured"

    # 4. Signal UC Server (placeholder - not implemented yet)
    # TODO: Implement when UC Server API is available
    uc_sessions_terminated = None
    actions["uc_sessions"] = "not_configured"

    # 5. Log termination event
    event_id = ORGDB.record_termination(
        user_uid=uid,
        user_dn=user_dn,
        org_dn=org_dn,
        terminated_by=terminated_by,
        reason=req.reason,
        actions_taken=actions,
        ldap_disabled=ldap_disabled,
        tokens_revoked=tokens_revoked,
        authentik_sessions_revoked=authentik_sessions_revoked,
        uc_sessions_terminated=uc_sessions_terminated,
    )

    return {
        "ok": True,
        "status": "terminated",
        "user_uid": uid,
        "event_id": event_id,
        "actions": {
            "ldap_disabled": ldap_disabled,
            "tokens_revoked": tokens_revoked,
            "authentik_sessions_revoked": authentik_sessions_revoked,
            "uc_sessions_terminated": uc_sessions_terminated,
        },
        "timestamp": iso(utcnow()),
    }
```

**Step 4: Verify hot reload**

Run: `just logs`

Expected: No errors.

**Step 5: Test endpoint exists**

Run: `curl -s http://localhost:8081/api/docs | grep -o 'terminate'`

Expected: Shows "terminate" in OpenAPI docs.

**Step 6: Commit**

```bash
git add src/backend/main.py
git commit -m "feat(api): add POST /api/users/{uid}/terminate endpoint

Implements user termination flow per spec Section 6.2:
1. Disables LDAP account
2. Revokes all provision tokens
3. Logs termination event with audit trail

Authentik and UC Server integration are placeholders."
```

---

## Task 9: Add Token Consumption Validation

**Files:**
- Modify: `src/backend/orgdb.py`

**Step 1: Add token validation method**

Add after `get_provision_token` method (around line 255):

```python
    def validate_and_consume_token(self, token_hash: str) -> tuple[bool, str, dict]:
        """Validate a provision token and mark it consumed if valid.

        Returns: (valid, error_message, token_data)

        Error messages:
        - "TOKEN_NOT_FOUND": Token doesn't exist
        - "TOKEN_ALREADY_CONSUMED": Token was already used
        - "TOKEN_EXPIRED": Token has expired
        - "": No error, token is valid
        """
        eng = self.connect()

        # Get token
        token = self.get_provision_token(token_hash)
        if not token:
            return False, "TOKEN_NOT_FOUND", {}

        # Check if already consumed
        if token.get("status") != "active":
            return False, "TOKEN_ALREADY_CONSUMED", token

        # Check expiration
        expires_at = token.get("expires_at")
        if expires_at and expires_at < utcnow():
            return False, "TOKEN_EXPIRED", token

        # Mark as consumed
        with eng.begin() as conn:
            conn.execute(
                update(provision_tokens)
                .where(provision_tokens.c.token_hash == token_hash)
                .values(used_at=utcnow(), status="consumed")
            )

        token["status"] = "consumed"
        return True, "", token
```

**Step 2: Verify hot reload**

Run: `just logs`

Expected: No errors.

**Step 3: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "feat(db): add token validation and consumption method

Implements one-time token enforcement per spec Section 0.2:
- Validates token exists and is active
- Checks expiration
- Marks consumed atomically
- Returns structured error codes"
```

---

## Task 10: Add Token Validation Endpoint

**Files:**
- Modify: `src/backend/main.py`

**Step 1: Add token validation request model**

Add after `UserTerminateReq` model:

```python
class TokenValidateReq(BaseModel):
    token: str = Field(..., description="The provision token to validate")
```

**Step 2: Add token validation endpoint**

Add after the termination endpoint:

```python
@app.post("/api/provision/validate")
@limiter.limit(LIMIT_QR)
def api_provision_validate(
    request: Request,
    req: TokenValidateReq,
):
    """Validate and consume a one-time provision token.

    This endpoint is called by mobile clients after scanning a QR code.
    The token is single-use: once consumed, it cannot be used again.

    Returns:
    - ok: true if token is valid and was consumed
    - error: error code if validation failed
    - uid: user ID associated with the token (if valid)
    """
    # Hash the token to look up
    token_hash = hashlib.sha256(req.token.encode("utf-8")).hexdigest()

    valid, error, token_data = ORGDB.validate_and_consume_token(token_hash)

    if not valid:
        # Return appropriate error
        status_code = 400
        if error == "TOKEN_NOT_FOUND":
            status_code = 404
        elif error == "TOKEN_EXPIRED":
            status_code = 410  # Gone
        elif error == "TOKEN_ALREADY_CONSUMED":
            status_code = 409  # Conflict

        raise HTTPException(
            status_code=status_code,
            detail={"ok": False, "error": error},
        )

    return {
        "ok": True,
        "uid": token_data.get("uid"),
        "profile_id": token_data.get("profile_id"),
        "consumed_at": iso(utcnow()),
    }
```

**Step 3: Verify hot reload**

Run: `just logs`

Expected: No errors.

**Step 4: Commit**

```bash
git add src/backend/main.py
git commit -m "feat(api): add POST /api/provision/validate endpoint

Mobile clients call this to validate and consume QR provision tokens.
Implements one-time token enforcement per spec Section 0.2."
```

---

## Task 11: Add Health Check Endpoints

**Files:**
- Modify: `src/backend/main.py`

**Step 1: Add basic health endpoint**

Add after the CORS middleware setup (around line 55):

```python
@app.get("/api/health")
def api_health():
    """Basic liveness check - always returns 200 if app is running."""
    return {"ok": True, "status": "healthy"}
```

**Step 2: Add deep health endpoint**

Add after the basic health endpoint:

```python
@app.get("/api/health/deep")
def api_health_deep(claims: Dict[str, Any] = Depends(require_user)):
    """Deep health check - verifies LDAP, PostgreSQL, and Redis connectivity."""
    import redis as redis_client
    from config import REDIS_URL

    checks = {}

    # Check PostgreSQL
    try:
        ORGDB.connect().execute(select(1))
        checks["postgresql"] = {"status": "healthy"}
    except Exception as e:
        checks["postgresql"] = {"status": "unhealthy", "error": str(e)}

    # Check LDAP
    try:
        conn = get_conn()
        conn.unbind()
        checks["ldap"] = {"status": "healthy"}
    except Exception as e:
        checks["ldap"] = {"status": "unhealthy", "error": str(e)}

    # Check Redis
    try:
        r = redis_client.from_url(REDIS_URL)
        r.ping()
        checks["redis"] = {"status": "healthy"}
    except Exception as e:
        checks["redis"] = {"status": "unhealthy", "error": str(e)}

    # Overall status
    all_healthy = all(c.get("status") == "healthy" for c in checks.values())

    return {
        "ok": all_healthy,
        "status": "healthy" if all_healthy else "degraded",
        "checks": checks,
    }
```

**Step 3: Add missing import for select**

Ensure `select` is imported from sqlalchemy. Check if it's already there; if not, the import should be added.

Add at top of file if needed:

```python
from sqlalchemy import select
```

**Step 4: Verify hot reload**

Run: `just logs`

Expected: No errors.

**Step 5: Test health endpoints**

Run: `curl -s http://localhost:8081/api/health | jq`

Expected: `{"ok": true, "status": "healthy"}`

**Step 6: Commit**

```bash
git add src/backend/main.py
git commit -m "feat(api): add health check endpoints

GET /api/health - basic liveness
GET /api/health/deep - verifies LDAP, PostgreSQL, Redis connectivity

Required for load balancer and orchestrator health probes."
```

---

## Task 12: Final Integration Test

**Step 1: Restart the full stack**

Run: `cd deploy/dev && just down && just up`

**Step 2: Verify all services healthy**

Run: `just ps`

Expected: All containers show "healthy" status.

**Step 3: Test rate limiting**

Run:
```bash
for i in {1..6}; do
  echo "Request $i:"
  curl -s -w "\nHTTP %{http_code}\n" http://localhost:8081/api/health
  sleep 0.1
done
```

Expected: All requests succeed (health endpoint has default 100/min limit).

**Step 4: Test termination endpoint exists**

Run: `curl -s http://localhost:8081/api/docs | grep -c terminate`

Expected: Returns 1 or more (endpoint is documented).

**Step 5: Test deep health**

Run: `curl -s http://localhost:8081/api/health/deep | jq`

Expected: Shows all three services (postgresql, ldap, redis) as healthy.

**Step 6: Final commit**

```bash
git add -A
git commit -m "test: verify P0 production blockers implementation

All critical blockers addressed:
- Rate limiting with Redis backend
- One-time token enforcement
- User termination with audit trail
- Health check endpoints"
```

---

## Summary

After completing all tasks, the following P0 blockers are resolved:

| Blocker | Solution | Files Modified |
|---------|----------|----------------|
| No rate limiting | Redis + slowapi | docker-compose.yml, requirements.txt, config.py, rate_limit.py, main.py |
| Token enforcement | validate_and_consume_token | orgdb.py, main.py |
| No termination | POST /api/users/{uid}/terminate | ldap_client.py, orgdb.py, main.py |
| No health checks | GET /api/health, /api/health/deep | main.py |

**Remaining work for full production readiness (P1/P2):**
- CORS lockdown (requires frontend origin list)
- QR schema alignment (requires mobile team coordination)
- Database migrations (for future schema changes)
- Authentik integration (when needed)
