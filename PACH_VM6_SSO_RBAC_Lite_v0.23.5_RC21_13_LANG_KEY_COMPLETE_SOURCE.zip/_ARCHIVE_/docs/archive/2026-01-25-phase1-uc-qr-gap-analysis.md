# Phase 1 UC Core QR: Implementation Gap Analysis

**Date:** 2026-01-25
**PRD:** `docs/prd/PHASE1_UC_CORE_QR_PRD.md`
**Backend:** `src/backend/`
**Status:** Analysis Complete

---

## Executive Summary

Phase 1 PRD requires a unified QR provisioning system with schema `azblink.provisioning.v2`. The current backend implements ~60% of the required functionality but uses a legacy schema (`ucchat-user-provision` v1). Key gaps are schema migration and the `/provision/consume` endpoint.

**Estimated effort:** ~4 developer days (PRD estimates 8-10, but significant infrastructure exists).

---

## 1. API Endpoint Mapping

### PRD-Required Endpoints

| Endpoint | Purpose | Status | Notes |
|----------|---------|--------|-------|
| `GET /api/users/{uid}/qrcode` | Generate unified QR with v2 schema | **Partial** | Exists but uses v1 schema |
| `POST /api/provision/consume` | Consume token, return session creds | **Missing** | `/provision/validate` is similar |
| `POST /api/users/{uid}/qrcode/revoke` | Revoke all tokens for user | **Done** | `main.py:1059-1071` |

### Existing Related Endpoints (Not in PRD)

| Endpoint | Purpose | Disposition |
|----------|---------|-------------|
| `GET /api/users/{uid}/qrcodes` | Dual QR#1 + QR#2 | Keep for backward compat |
| `POST /api/provision/validate` | Token validation | Extend or rename to `/consume` |

---

## 2. QR Schema Gap

### Current Schema (`main.py:913-923`)

```json
{
  "type": "ucchat-user-provision",
  "v": 1,
  "uid": "alice",
  "userDn": "uid=alice,ou=people,...",
  "orgDn": "ou=Engineering,ou=org,...",
  "iat": 1704067200,
  "exp": 1704070800,
  "nonce": "abc123",
  "sig": "..."
}
```

### PRD-Required Schema (`azblink.provisioning.v2`)

```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": {
      "tenant": "example",
      "xmpp": { "domain": "...", "wsUrl": "..." },
      "sip": { "domain": "...", "wssUrl": "..." },
      "credentials": { "username": "alice", "token": "one-time-token" }
    },
    "sso": null
  },
  "iat": 1704067200,
  "exp": 1704070800,
  "nonce": "abc123",
  "sig": "..."
}
```

### Schema Differences

| Aspect | Current | Required | Severity |
|--------|---------|----------|----------|
| Schema identifier | `type: "ucchat-user-provision"` | `schema: "azblink.provisioning.v2"` | P0 |
| Structure | Flat | Nested `payload.uc` / `payload.sso` | P0 |
| Credentials token | Not included | `credentials.token` (one-time) | P0 |
| XMPP/SIP config | Not in `/qrcode` | Required in UC block | P0 |
| SSO placeholder | N/A | `payload.sso: null` | P1 |

---

## 3. Infrastructure Status

### Already Implemented

| Component | Location | Status |
|-----------|----------|--------|
| HMAC-SHA256 signing | `main.py:89-92` | ✅ |
| QR PNG generation | `main.py:94-107` | ✅ |
| Redis rate limiting | `rate_limit.py` | ✅ |
| Provision tokens table | `orgdb.py:86-96` | ✅ |
| Atomic token consumption | `orgdb.py:342-384` | ✅ |
| QR issuance audit | `orgdb.py:117-132` | ✅ |
| Token revocation | `orgdb.py:423-435` | ✅ |
| Break-glass recovery | `main.py:126-186` | ✅ |
| Health endpoints | `main.py:235-289` | ✅ |

### Missing Components

| Component | PRD Reference | Priority |
|-----------|---------------|----------|
| `qr_signing.py` module | Section 4.1 Task 1 | P1 |
| `verify_provisioning_payload()` | Section 3.2 | P0 |
| Device tracking columns | Section 3.5.1 | P1 |
| `ORG_QR_MAX_TTL_SEC` config | Section 3.6.1 | P1 |
| Database indexes | Section 3.5.1 | P2 |

---

## 4. `/provision/consume` Gap

### Architecture Context: Plane A Authentication

Per the dual authentication plane architecture (Master Spec §4.1), Phase 1 uses **Plane A (UC Authentication)** which authenticates via direct LDAP bind. The mobile client:

1. Receives UC configuration from QR (domains, WebSocket URLs, username)
2. User enters their LDAP password on the mobile device
3. Mobile connects to XMPP/SIP using direct LDAP bind authentication

**The QR provides configuration, not credentials.** The one-time token prevents QR reuse/sharing but is NOT used for UC service authentication.

### Current: `/api/provision/validate`

**Location:** `main.py:761-802`

```python
# Request
{ "token": "..." }

# Response
{ "ok": true, "uid": "alice", "profile_id": "...", "consumed_at": "..." }
```

### Required: `/api/provision/consume`

```python
# Request
{
  "token": "...",
  "deviceId": "device-uuid",
  "clientInfo": { "platform": "ios", "version": "2.1.0" }
}

# Response (Phase 1 - LDAP bind auth)
{
  "ok": true,
  "uid": "alice",
  "consumed_at": "...",
  "config": {
    "xmpp": { "jid": "alice@uc.example.com" },
    "sip": { "uri": "sip:alice@sip.example.com" },
    "authMethod": "ldap_bind"
  }
}
```

**Note:** No passwords are returned. The `authMethod: "ldap_bind"` instructs the mobile client to prompt the user for their LDAP password and authenticate directly against the UC services.

### Gaps

1. **Device info capture** - Not implemented
2. **Response structure** - Return `config` with `authMethod`, not session passwords
3. **Endpoint name** - `/validate` vs `/consume`

---

## 5. Database Migration Required

### New Columns for `provision_tokens`

```sql
ALTER TABLE provision_tokens ADD COLUMN IF NOT EXISTS
    consumed_by_device_id VARCHAR(128);

ALTER TABLE provision_tokens ADD COLUMN IF NOT EXISTS
    consumed_from_ip VARCHAR(45);

ALTER TABLE provision_tokens ADD COLUMN IF NOT EXISTS
    client_platform VARCHAR(32);

ALTER TABLE provision_tokens ADD COLUMN IF NOT EXISTS
    client_version VARCHAR(32);
```

### New Indexes

```sql
CREATE INDEX IF NOT EXISTS idx_provision_tokens_uid_status
    ON provision_tokens(uid, status);

CREATE INDEX IF NOT EXISTS idx_provision_tokens_expires
    ON provision_tokens(expires_at) WHERE status = 'active';
```

---

## 6. Configuration Gap

| Variable | Status |
|----------|--------|
| `ORG_QR_MAX_TTL_SEC` | **Missing** - add to `config.py` |

All other required variables exist.

---

## 7. Rate Limiting Status

| Endpoint | PRD Limit | Current | Status |
|----------|-----------|---------|--------|
| `GET /users/{uid}/qrcode` | 10/min | 10/min | ✅ |
| `POST /provision/consume` | 10/min | N/A | Apply when created |
| `POST /users/create` | 20/min | 20/min | ✅ |
| `POST /bootstrap` | 5/hour | 5/hour | ✅ |

---

## 8. Implementation Tasks

### P0 - Must Have

1. **Update QR schema to v2** - Modify `/api/users/{uid}/qrcode`
2. **Add one-time token to QR** - Generate and store token, include in payload
3. **Create `/api/provision/consume`** - Extend `/validate` with session response

### P1 - Should Have

4. **Extract `qr_signing.py` module** - `sign_provisioning_payload()` + `verify_provisioning_payload()`
5. **Add device tracking** - Migration + `update_provision_token_device()` method
6. **Add `ORG_QR_MAX_TTL_SEC`** - Config validation

### P2 - Nice to Have

7. **Add database indexes** - Performance optimization
8. **Update `/qrcodes` endpoint** - Align with v2 schema (backward compat)

---

## 9. Out of Scope (Phase 2)

| Item | Reason |
|------|--------|
| `payload.sso` with Authentik config | PRD: "Always null in Phase 1" |
| UC Server session API | PRD: "Phase 1 uses LDAP-bind auth" |
| Authentik session revocation | Placeholder only |
| CLI QR commands | PRD Priority P2 |

---

## 10. Testing Requirements

Existing test infrastructure in `tests/` covers:
- Health endpoints
- Rate limiting
- Token validation

New tests needed:
- `test_qrcode_endpoint_returns_v2_schema`
- `test_token_consumed_once_only`
- `test_expired_token_rejected`
- `test_consume_returns_config_with_ldap_auth_method`

---

## Appendix: File Change Summary

| File | Changes |
|------|---------|
| `src/backend/main.py` | Update `/qrcode`, add `/consume` |
| `src/backend/qr_signing.py` | **New** - signing module |
| `src/backend/orgdb.py` | Add device tracking method, update schema |
| `src/backend/config.py` | Add `ORG_QR_MAX_TTL_SEC` |
| `migrations/004_phase1_uc_qr.sql` | **New** - device columns + indexes |
| `tests/test_provisioning.py` | Add v2 schema tests |

---

## Appendix: Verification Record

**Verified:** 2026-01-25

**Verified Against:**
- Master Spec: `specs/v2.0/Directory_Portal_Specification_v4.1.md`
- Phase 1 PRD: `docs/prd/PHASE1_UC_CORE_QR_PRD.md`

**Verification Summary:**

| Section | Status | Notes |
|---------|--------|-------|
| Scope (Phase 1 QR#1 only) | ✅ | SSO deferred to Phase 2 |
| QR Schema (`azblink.provisioning.v2`) | ✅ | `tenant` field as safe extension |
| API Endpoints | ✅ | `/consume` returns config, not passwords |
| Token Flow (atomic consumption) | ✅ | Existing implementation correct |
| Database Schema | ✅ | Structured device fields preferred |
| Rate Limiting | ✅ | Apply `LIMIT_QR` to `/consume` |
| Configuration | ✅ | Add `ORG_QR_MAX_TTL_SEC` |

**Key Architecture Decision:**
Phase 1 uses **Plane A (UC Authentication)** with direct LDAP bind. The `/provision/consume` endpoint returns `authMethod: "ldap_bind"` — no session passwords are returned. Users authenticate directly to UC services using their LDAP credentials.
