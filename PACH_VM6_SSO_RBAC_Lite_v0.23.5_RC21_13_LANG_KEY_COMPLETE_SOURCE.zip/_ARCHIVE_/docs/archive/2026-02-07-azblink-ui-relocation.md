# @azblink/ui Package Relocation & Cleanup Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Move `azblink-ui/` from repo root to `src/frontend/packages/azblink-ui/`, fix the stale lock file, and verify all Docker containers and deployment configs work with the new structure.

**Architecture:** The `@azblink/ui` design system package currently lives at the repo root as an npm workspace sibling to `src/frontend/`. Moving it under `src/frontend/packages/` co-locates it with its only consumer, simplifies the Docker build context, and follows standard monorepo conventions. The npm package name `@azblink/ui` does NOT change — only filesystem paths. All React imports (`import { Button } from '@azblink/ui'`) remain untouched.

**Tech Stack:** npm workspaces, Vite 6, Docker Compose, tsup, Tailwind CSS 4

---

## What Changes and What Doesn't

| Category | Changes? | Details |
|---|---|---|
| **React source imports** | NO | `import { ... } from '@azblink/ui'` unchanged (package name, not path) |
| **CSS imports** | NO | `@import "@azblink/ui/tokens.css"` unchanged |
| **npm package name** | NO | Still `@azblink/ui` in package.json |
| **Root package.json** | YES | Workspace array path update |
| **Vite config aliases** | YES | `../../azblink-ui/` → `./packages/azblink-ui/` |
| **Dockerfile.ui-dev** | YES | COPY paths and --workspace flags |
| **Dockerfile.ui-react** | YES | COPY paths and --workspace flags |
| **docker-compose.yml** | YES | Volume mount path |
| **CLAUDE.md** | YES | Directory descriptions |
| **Lock files** | YES | Regenerated (also fixes stale Radix entries) |

---

### Task 1: Move the directory

**Action:** `git mv` the `azblink-ui/` directory to its new home.

**Step 1: Create the packages directory**

```bash
mkdir -p src/frontend/packages
```

**Step 2: Move with git history preservation**

```bash
git mv azblink-ui src/frontend/packages/azblink-ui
```

**Step 3: Verify the move**

```bash
ls src/frontend/packages/azblink-ui/package.json
# Should exist and contain "name": "@azblink/ui"
```

**DO NOT COMMIT YET** — the workspace references are broken until we fix them in the next tasks.

---

### Task 2: Update root package.json workspace definition

**Files:**
- Modify: `package.json` (repo root)

**Step 1: Update workspace paths**

```json
{
  "name": "azb-azblink-directory-and-identity-stack",
  "private": true,
  "workspaces": [
    "src/frontend/packages/azblink-ui",
    "src/frontend"
  ]
}
```

**Why `azblink-ui` is listed first:** npm resolves workspaces in order. Since `src/frontend` depends on `@azblink/ui`, the dependency must be registered first.

**Step 2: Verify syntax**

```bash
node -e "console.log(JSON.parse(require('fs').readFileSync('package.json','utf8')).workspaces)"
# Expected: [ 'src/frontend/packages/azblink-ui', 'src/frontend' ]
```

---

### Task 3: Update Vite config aliases

**Files:**
- Modify: `src/frontend/vite.config.ts` (lines 84-86)

The dev-mode aliases resolve `@azblink/ui` to source for HMR. The relative path changes because the frontend and azblink-ui are now closer:

**Old (lines 82-88):**
```typescript
...(!process.env.NODE_ENV || process.env.NODE_ENV === 'development'
  ? {
      '@azblink/ui/tokens.css': path.resolve(__dirname, '../../azblink-ui/tokens/tokens.css'),
      '@azblink/ui/styles.css': path.resolve(__dirname, '../../azblink-ui/dist/index.css'),
      '@azblink/ui': path.resolve(__dirname, '../../azblink-ui/index.ts'),
    }
  : {}),
```

**New:**
```typescript
...(!process.env.NODE_ENV || process.env.NODE_ENV === 'development'
  ? {
      '@azblink/ui/tokens.css': path.resolve(__dirname, './packages/azblink-ui/tokens/tokens.css'),
      '@azblink/ui/styles.css': path.resolve(__dirname, './packages/azblink-ui/dist/index.css'),
      '@azblink/ui': path.resolve(__dirname, './packages/azblink-ui/index.ts'),
    }
  : {}),
```

**Why `./packages/` not `../packages/`:** `__dirname` is `src/frontend/`, and `packages/azblink-ui/` is directly inside it.

---

### Task 4: Update Dockerfile.ui-dev

**Files:**
- Modify: `deploy/dev/Dockerfile.ui-dev`

All references to `azblink-ui/` at root level must change to `src/frontend/packages/azblink-ui/`. The build context is `../..` (repo root), so paths are relative to repo root.

**Full replacement content:**

```dockerfile
# Dev-only: Vite dev server with HMR (source mounted at runtime)
# - Production builds still use Dockerfile.ui-react (multi-stage → nginx)
# - Source code is volume-mounted by docker-compose, not COPYed
# - @azblink/ui source is also mounted for live design system editing
FROM node:22-alpine
WORKDIR /app

# Copy workspace root + package files for dependency resolution
COPY package.json package-lock.json ./
COPY src/frontend/packages/azblink-ui/package.json ./src/frontend/packages/azblink-ui/
COPY src/frontend/package.json ./src/frontend/

# Install all workspace deps
# Node_modules live at /app/node_modules (workspace root) and are NOT
# shadowed by volume mounts — we only mount source subdirs, not roots.
RUN npm ci --workspace=src/frontend/packages/azblink-ui --workspace=src/frontend

# Source is mounted at runtime via docker-compose volumes:
#   ../../src/frontend/packages/azblink-ui → /app/src/frontend/packages/azblink-ui (design system)
#   ../../src/frontend/src                 → /app/src/frontend/src                  (app source)
#
# Vite resolves @azblink/ui through the workspace symlink in node_modules,
# aliased to source (not dist) for direct HMR — see vite.config.ts.

EXPOSE 5173

# Vite dev server — listens on all interfaces for Docker networking
CMD ["npx", "--workspace=src/frontend", "vite", "--host", "0.0.0.0", "--port", "5173"]
```

**Key changes from original (line by line):**
- Line 10: `azblink-ui/package.json` → `src/frontend/packages/azblink-ui/package.json`
- Line 10 container path: `./azblink-ui/` → `./src/frontend/packages/azblink-ui/`
- Line 16: `--workspace=azblink-ui` → `--workspace=src/frontend/packages/azblink-ui`
- Lines 19-20: Updated comments

---

### Task 5: Update Dockerfile.ui-react

**Files:**
- Modify: `deploy/dev/Dockerfile.ui-react`

Same pattern — all `azblink-ui/` → `src/frontend/packages/azblink-ui/`.

**Full replacement content:**

```dockerfile
# Production build: multi-stage → npm install → vite build → nginx static serving
# For dev with HMR, see Dockerfile.ui-dev (used by docker-compose in dev)
# Build stage — npm workspaces (root + azblink-ui + frontend)
FROM node:22-alpine AS builder
WORKDIR /app

# Build-time version args (passed from docker-compose)
ARG GIT_HASH=unknown
ARG GIT_BRANCH=unknown
ARG BUILD_TIME=unknown

# Set as env vars for Vite to pick up
ENV VITE_GIT_HASH=$GIT_HASH
ENV VITE_GIT_BRANCH=$GIT_BRANCH
ENV VITE_BUILD_TIME=$BUILD_TIME

# Copy workspace root + package files for dependency resolution
COPY package.json package-lock.json ./
COPY src/frontend/packages/azblink-ui/package.json ./src/frontend/packages/azblink-ui/
COPY src/frontend/package.json ./src/frontend/

# Install all workspace dependencies
RUN npm ci --workspace=src/frontend/packages/azblink-ui --workspace=src/frontend

# Copy @azblink/ui source and build it first
COPY src/frontend/packages/azblink-ui/ ./src/frontend/packages/azblink-ui/
RUN npm run build --workspace=src/frontend/packages/azblink-ui

# Copy frontend source and build
COPY src/frontend/ ./src/frontend/
RUN npm run build --workspace=src/frontend

# Production stage — nginx serves the SPA
FROM nginx:alpine
COPY --from=builder /app/src/frontend/dist /usr/share/nginx/html
COPY deploy/dev/nginx-react.conf /etc/nginx/conf.d/default.conf
EXPOSE 8001
CMD ["nginx", "-g", "daemon off;"]
```

**Key changes from original:**
- Line 19: `azblink-ui/package.json` → `src/frontend/packages/azblink-ui/package.json`
- Line 23: `--workspace=azblink-ui` → `--workspace=src/frontend/packages/azblink-ui`
- Line 26: `COPY azblink-ui/` → `COPY src/frontend/packages/azblink-ui/`
- Line 27: `--workspace=azblink-ui` → `--workspace=src/frontend/packages/azblink-ui`

**Note on line 30 `COPY src/frontend/ ./src/frontend/`:** This now also copies `packages/azblink-ui/` as a subdirectory. However, because `COPY src/frontend/packages/azblink-ui/` was already done on line 26, Docker layer caching still works correctly — the duplicate files in the second COPY are harmless and the layer is a no-op for those paths.

---

### Task 6: Update docker-compose.yml volume mount

**Files:**
- Modify: `deploy/dev/docker-compose.yml` (line 134)

**Old (line 134):**
```yaml
      - ../../azblink-ui:/app/azblink-ui
```

**New:**
```yaml
      - ../../src/frontend/packages/azblink-ui:/app/src/frontend/packages/azblink-ui
```

The container-side path must match the `WORKDIR /app` + the relative path that npm workspaces expect. Since the workspace is now `src/frontend/packages/azblink-ui`, the container path must be `/app/src/frontend/packages/azblink-ui`.

---

### Task 7: Regenerate lock files (fixes stale Radix entries too)

**Files:**
- Delete + regenerate: `package-lock.json` (root)
- Delete + regenerate: `src/frontend/package-lock.json`

**Step 1: Delete stale lock files**

```bash
rm -f package-lock.json src/frontend/package-lock.json
```

**Step 2: Install from scratch**

```bash
npm install
```

This will:
- Create a fresh `package-lock.json` at root with correct workspace paths
- Resolve `@azblink/ui` → `src/frontend/packages/azblink-ui` symlink
- Remove stale `@radix-ui/*` entries from the frontend lock file
- Remove stale `class-variance-authority`, standalone `clsx`, `tailwind-merge` from frontend

**Step 3: Verify workspace symlink**

```bash
ls -la node_modules/@azblink/ui
# Expected: symlink → ../../src/frontend/packages/azblink-ui
```

**Step 4: Verify no Radix in lock file**

```bash
grep -c "@radix-ui" package-lock.json
# Expected: 0 (or only transitive deps if @base-ui/react depends on some)
```

---

### Task 8: Update CLAUDE.md

**Files:**
- Modify: `CLAUDE.md`

**Changes needed in these sections:**

**Hot Reload Rules table (around line 97):**
```markdown
| `azblink-ui/primitives/**/*` | None - Vite HMR | (wait ~1s) |
| `azblink-ui/tokens/**/*` | None - Vite HMR | (wait ~1s) |
```
→
```markdown
| `src/frontend/packages/azblink-ui/primitives/**/*` | None - Vite HMR | (wait ~1s) |
| `src/frontend/packages/azblink-ui/tokens/**/*` | None - Vite HMR | (wait ~1s) |
```

**Decision flow (around line 104):**
```markdown
3. Edited `azblink-ui/` primitives/tokens? → Do nothing, Vite HMR handles it (source alias)
```
→
```markdown
3. Edited `src/frontend/packages/azblink-ui/` primitives/tokens? → Do nothing, Vite HMR handles it (source alias)
```

**Key directories (around lines 129-132):**
```markdown
- `azblink-ui/` - @azblink/ui design system (npm workspace package)
- `azblink-ui/primitives/` - Component implementations (Button, Card, Table, Badge, etc.)
- `azblink-ui/tokens/` - Design tokens (CSS custom properties, dark-first)
- `azblink-ui/providers/` - ThemeProvider
```
→
```markdown
- `src/frontend/packages/azblink-ui/` - @azblink/ui design system (npm workspace package)
- `src/frontend/packages/azblink-ui/primitives/` - Component implementations (Button, Card, Table, Badge, etc.)
- `src/frontend/packages/azblink-ui/tokens/` - Design tokens (CSS custom properties, dark-first)
- `src/frontend/packages/azblink-ui/providers/` - ThemeProvider
```

**Hot Reload Rules table (around line 93-94):**
```markdown
| `azblink-ui/package.json` | Rebuild UI | `just ui` |
```
→
```markdown
| `src/frontend/packages/azblink-ui/package.json` | Rebuild UI | `just ui` |
```

---

### Task 9: Update Justfile comment

**Files:**
- Modify: `Justfile` (line 41)

**Old:**
```
# - @azblink/ui: Hot reload via Vite alias to source (design system changes)
```

**New:**
```
# - @azblink/ui: Hot reload via Vite alias to source in src/frontend/packages/azblink-ui/
```

---

### Task 10: Update documentation references

**Files:**
- Modify: `docs/plans/2026-02-07-design-system-consolidation.md` (lines 64-65)

**Old:**
```css
@import "../../azblink-ui/tokens/tokens.css";
@import "../../azblink-ui/dist/index.css";
```

**New:**
```css
@import "./packages/azblink-ui/tokens/tokens.css";
@import "./packages/azblink-ui/dist/index.css";
```

**Note:** The other docs (migration plan, React spec, tech stack) reference the npm package name `@azblink/ui`, not filesystem paths, so they don't need changes.

---

### Task 11: Commit all changes

**Step 1: Stage everything**

```bash
git add -A
```

**Step 2: Review staged changes**

```bash
git status
git diff --cached --stat
```

Expected changes:
- `azblink-ui/` → `src/frontend/packages/azblink-ui/` (rename, many files)
- `package.json` (root) — workspace path update
- `package-lock.json` (root) — regenerated
- `src/frontend/package-lock.json` — deleted (root lock file handles it now)
- `src/frontend/vite.config.ts` — alias paths
- `deploy/dev/Dockerfile.ui-dev` — COPY + workspace paths
- `deploy/dev/Dockerfile.ui-react` — COPY + workspace paths
- `deploy/dev/docker-compose.yml` — volume mount
- `CLAUDE.md` — directory references
- `Justfile` — comment
- `docs/plans/2026-02-07-design-system-consolidation.md` — path reference

**Step 3: Commit**

```bash
git commit -m "refactor: move @azblink/ui to src/frontend/packages/azblink-ui

Co-located design system with its frontend consumer.
Updated all workspace, Docker, Vite, and documentation references.
Regenerated lock files (also removes stale @radix-ui entries)."
```

---

### Task 12: Verify local build

**Step 1: Clean install**

```bash
rm -rf node_modules src/frontend/node_modules
npm install
```

**Step 2: Build @azblink/ui**

```bash
npm run build --workspace=src/frontend/packages/azblink-ui
```

Expected: `src/frontend/packages/azblink-ui/dist/` populated with `index.js`, `index.d.ts`, `index.css`

**Step 3: Build frontend**

```bash
npm run build --workspace=src/frontend
```

Expected: `src/frontend/dist/` populated, build completes without errors

**Step 4: Verify workspace symlink works**

```bash
ls -la node_modules/@azblink/ui
# Expected: symlink → ../../src/frontend/packages/azblink-ui
```

---

### Task 13: Verify Docker dev container

**Step 1: Rebuild and start the stack**

```bash
just down && just up
```

**Step 2: Check container starts**

```bash
just ps
# Expected: azblink-directory-ui is running/healthy
```

**Step 3: Check UI loads**

```bash
just browse
# Or: curl -s http://localhost:8081/ | head -5
```

**Step 4: Check HMR works**

Make a trivial change to `src/frontend/packages/azblink-ui/tokens/tokens.css` (e.g., add a comment). Watch the Docker UI container logs:

```bash
just logs-ui
# Expected: Vite picks up the change, HMR update logged
```

Revert the trivial change.

**Step 5: Check design system component HMR**

Make a trivial change to `src/frontend/packages/azblink-ui/primitives/Button/Button.module.css` (e.g., add a comment). Verify HMR triggers in the browser.

Revert the trivial change.

---

### Task 14: Verify Docker production build

**Step 1: Build the production image**

```bash
cd deploy/dev && docker compose build directory-ui-prod 2>&1 || docker build -f Dockerfile.ui-react -t azblink-ui-prod ../..
```

If `directory-ui-prod` isn't a service name, build directly:

```bash
cd deploy/dev && docker build -f Dockerfile.ui-react -t azblink-ui-test ../..
```

**Step 2: Verify the image built successfully**

```bash
docker run --rm azblink-ui-test ls /usr/share/nginx/html/
# Expected: index.html, assets/, etc.
```

**Step 3: Clean up test image**

```bash
docker rmi azblink-ui-test
```

---

## Execution Order

```
Task 1  (git mv)                ─── must be first
Task 2  (root package.json)     ─── depends on Task 1
Task 3  (vite.config.ts)        ─── depends on Task 1
Task 4  (Dockerfile.ui-dev)     ─── depends on Task 1
Task 5  (Dockerfile.ui-react)   ─── depends on Task 1
Task 6  (docker-compose.yml)    ─── depends on Task 1
   ↕ Tasks 2-6 can run in parallel after Task 1
Task 7  (lock file regen)       ─── depends on Tasks 1+2
Task 8  (CLAUDE.md)             ─── independent
Task 9  (Justfile)              ─── independent
Task 10 (docs)                  ─── independent
   ↕ Tasks 8-10 can run in parallel
Task 11 (commit)                ─── depends on ALL above
Task 12 (local build verify)    ─── depends on Task 11
Task 13 (Docker dev verify)     ─── depends on Task 11
Task 14 (Docker prod verify)    ─── depends on Task 11
   ↕ Tasks 12-14 can run in parallel
```

## Risk Register

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| `npm ci` fails in Docker with new workspace path | 20% | High | Verify locally first (Task 12), then Docker (Task 13) |
| Vite HMR breaks for @azblink/ui in Docker bind mount | 15% | Medium | Volume mount path verified in Task 6; test HMR in Task 13 |
| `git mv` loses file history | 5% | Low | git tracks renames; `git log --follow` preserves history |
| Production Dockerfile COPY duplicates files | 0% | None | Harmless — Docker deduplicates layers; build time negligible |
| Lock file has unexpected resolutions | 10% | Medium | Manual review of `npm ls @azblink/ui` after Task 7 |

## Rollback

If anything goes wrong:

```bash
git checkout HEAD -- .
npm install
just down && just up
```

This restores all files to pre-migration state.
