# React UI Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Replace the existing static HTML mockups in `src/ui/` with a React 19 SPA using the tech stack defined in `docs/plans/2025-01-25-react-tech-stack.md`.

**Architecture:** Vite-powered React 19 app with TanStack Router (file-based routing), TanStack Query (server state), Zustand (UI state), shadcn/ui (components), and Tailwind CSS 4.x (styling). The app communicates with the existing FastAPI backend at `/api`.

**Tech Stack:** React 19.2, Vite 7, TanStack Router 1.x, TanStack Query 5.x, Zustand 5.x, shadcn/ui (new-york), Tailwind CSS 4.x, Lucide React

---

## Phase 1: Project Foundation

### Task 1: Initialize Vite React Project

**Files:**
- Create: `src/frontend/package.json`
- Create: `src/frontend/vite.config.ts`
- Create: `src/frontend/tsconfig.json`
- Create: `src/frontend/index.html`

**Step 1: Create project directory structure**

```bash
mkdir -p src/frontend/src/{routes,components,lib,stores,hooks,types,styles}
```

**Step 2: Create package.json**

```json
{
  "name": "azblink-directory-ui",
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
    "format": "prettier --write \"src/**/*.{ts,tsx,css}\""
  },
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "@tanstack/react-query": "^5.60.0",
    "@tanstack/react-router": "^1.114.0",
    "zustand": "^5.0.0",
    "sonner": "^1.7.0",
    "lucide-react": "^0.468.0",
    "clsx": "^2.1.0",
    "tailwind-merge": "^2.6.0",
    "class-variance-authority": "^0.7.1"
  },
  "devDependencies": {
    "vite": "^6.0.0",
    "@vitejs/plugin-react": "^4.3.0",
    "@tailwindcss/vite": "^4.0.0",
    "tailwindcss": "^4.0.0",
    "@tanstack/router-plugin": "^1.114.0",
    "@tanstack/react-query-devtools": "^5.60.0",
    "typescript": "^5.7.0",
    "@types/react": "^19.0.0",
    "@types/react-dom": "^19.0.0",
    "@types/node": "^22.0.0",
    "eslint": "^9.0.0",
    "prettier": "^3.4.0",
    "prettier-plugin-tailwindcss": "^0.6.0"
  }
}
```

**Step 3: Create vite.config.ts**

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { TanStackRouterVite } from '@tanstack/router-plugin/vite'
import path from 'path'

export default defineConfig({
  plugins: [
    TanStackRouterVite({
      target: 'react',
      autoCodeSplitting: true,
    }),
    react(),
    tailwindcss(),
  ],

  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },

  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8081',
        changeOrigin: true,
      },
    },
  },

  build: {
    outDir: 'dist',
    sourcemap: true,
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-react': ['react', 'react-dom'],
          'vendor-tanstack': ['@tanstack/react-query', '@tanstack/react-router'],
          'vendor-ui': ['lucide-react', 'sonner'],
        },
      },
    },
  },
})
```

**Step 4: Create tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    },
    "types": ["vite/client"]
  },
  "include": ["src"]
}
```

**Step 5: Create index.html**

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet" />
    <title>AZBlink Directory</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

**Step 6: Install dependencies**

Run: `cd src/frontend && npm install`
Expected: Package installation completes, node_modules created

**Step 7: Commit**

```bash
git add src/frontend/package.json src/frontend/vite.config.ts src/frontend/tsconfig.json src/frontend/index.html
git commit -m "feat(frontend): initialize Vite React 19 project

- Add package.json with React 19, TanStack, Zustand, shadcn deps
- Configure Vite with TanStack Router plugin and API proxy
- Set up TypeScript with strict mode and path aliases

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 2: Configure Tailwind CSS with Design Tokens

**Files:**
- Create: `src/frontend/src/styles/globals.css`
- Create: `src/frontend/postcss.config.js`

**Step 1: Create globals.css with design tokens**

```css
@import "tailwindcss";

@theme {
  /* Colors - from enterprise-ui-redesign.md §2.1 */
  --color-primary: #0F172A;
  --color-primary-foreground: #FFFFFF;
  --color-secondary: #334155;
  --color-secondary-foreground: #FFFFFF;
  --color-accent: #0369A1;
  --color-accent-light: #0EA5E9;
  --color-accent-foreground: #FFFFFF;
  --color-success: #059669;
  --color-success-light: #ECFDF5;
  --color-success-foreground: #065F46;
  --color-warning: #D97706;
  --color-warning-light: #FFFBEB;
  --color-warning-foreground: #92400E;
  --color-destructive: #DC2626;
  --color-destructive-light: #FEF2F2;
  --color-destructive-foreground: #991B1B;
  --color-muted: #F1F5F9;
  --color-muted-foreground: #64748B;
  --color-border: #E2E8F0;
  --color-background: #F8FAFC;
  --color-surface: #FFFFFF;
  --color-text: #020617;
  --color-text-muted: #64748B;

  /* Spacing - from enterprise-ui-redesign.md §2.3 */
  --spacing-1: 4px;
  --spacing-2: 8px;
  --spacing-3: 12px;
  --spacing-4: 16px;
  --spacing-5: 20px;
  --spacing-6: 24px;
  --spacing-8: 32px;
  --spacing-10: 40px;
  --spacing-12: 48px;
  --spacing-16: 64px;

  /* Border Radius - from enterprise-ui-redesign.md §2.4 */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
  --radius-xl: 16px;
  --radius-full: 9999px;

  /* Shadows - from enterprise-ui-redesign.md §2.5 */
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);

  /* Z-Index - from enterprise-ui-redesign.md §3.3 */
  --z-sidebar: 20;
  --z-header: 30;
  --z-dropdown: 40;
  --z-modal: 50;
  --z-toast: 60;

  /* Typography */
  --font-sans: 'Inter', system-ui, sans-serif;
  --font-mono: 'Fira Code', monospace;
}

@layer base {
  * {
    @apply border-border;
  }

  body {
    @apply bg-background text-text font-sans antialiased;
  }

  /* Focus visible for accessibility */
  :focus-visible {
    @apply outline-2 outline-accent outline-offset-2;
  }
}
```

**Step 2: Create postcss.config.js**

```javascript
export default {
  plugins: {},
}
```

**Step 3: Run dev server to verify Tailwind is working**

Run: `cd src/frontend && npm run dev`
Expected: Dev server starts at http://localhost:3000 (may error on missing main.tsx - that's OK for now)

**Step 4: Commit**

```bash
git add src/frontend/src/styles/globals.css src/frontend/postcss.config.js
git commit -m "feat(frontend): add Tailwind CSS with design tokens

- Configure CSS variables for colors, spacing, radius, shadows
- Set up base layer with body styles and focus states
- Design tokens match enterprise-ui-redesign.md specs

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 3: Set Up shadcn/ui Configuration

**Files:**
- Create: `src/frontend/components.json`
- Create: `src/frontend/src/lib/utils.ts`

**Step 1: Create components.json**

```json
{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "new-york",
  "rsc": false,
  "tsx": true,
  "tailwind": {
    "config": "",
    "css": "src/styles/globals.css",
    "baseColor": "slate",
    "cssVariables": true,
    "prefix": ""
  },
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components/ui",
    "lib": "@/lib",
    "hooks": "@/hooks"
  },
  "iconLibrary": "lucide"
}
```

**Step 2: Create utils.ts**

```typescript
/**
 * Utility functions for className merging
 * - cn: Combines clsx for conditional classes with tailwind-merge for deduplication
 */

import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
```

**Step 3: Install shadcn/ui CLI and add base components**

Run: `cd src/frontend && npx shadcn@latest add button card input badge`
Expected: Components added to `src/components/ui/`

**Step 4: Commit**

```bash
git add src/frontend/components.json src/frontend/src/lib/utils.ts src/frontend/src/components/ui/
git commit -m "feat(frontend): configure shadcn/ui with base components

- Add components.json for shadcn CLI configuration
- Create cn() utility for className merging
- Install button, card, input, badge components

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 4: Create TypeScript Types from API Contracts

**Files:**
- Create: `src/frontend/src/types/api.ts`
- Create: `src/frontend/src/types/user.ts`
- Create: `src/frontend/src/types/qr.ts`
- Create: `src/frontend/src/types/audit.ts`
- Create: `src/frontend/src/types/index.ts`

**Step 1: Create api.ts (base types)**

```typescript
/**
 * Base API types matching FRONTEND_API_CONTRACTS.md §2.1
 */

/** Standard API response wrapper */
export interface ApiResponse<T = unknown> {
  ok: boolean;
  error?: string;
  detail?: string;
  [key: string]: T | boolean | string | undefined;
}

/** API error response */
export interface ApiErrorResponse {
  ok: false;
  error: string;
  detail?: string;
}

/** ISO 8601 timestamp string */
export type ISOTimestamp = string;

/** Unix epoch timestamp (seconds) */
export type UnixTimestamp = number;

/** LDAP Distinguished Name */
export type DN = string;

/** User identifier (LDAP uid) */
export type UID = string;

/** HTTP error codes */
export const HTTP_ERRORS = {
  400: 'BAD_REQUEST',
  401: 'UNAUTHORIZED',
  403: 'FORBIDDEN',
  404: 'NOT_FOUND',
  409: 'CONFLICT',
  410: 'GONE',
  429: 'RATE_LIMIT_EXCEEDED',
  500: 'INTERNAL_ERROR',
  503: 'SERVICE_UNAVAILABLE',
} as const;

/** Rate limit error response */
export interface RateLimitError extends ApiErrorResponse {
  error: 'rate_limit_exceeded';
  retryAfter?: number;
}

/** Type guard for API errors */
export function isApiError(response: unknown): response is ApiErrorResponse {
  return typeof response === 'object' && response !== null &&
         'ok' in response && response.ok === false;
}
```

**Step 2: Create user.ts**

```typescript
/**
 * User management types matching FRONTEND_API_CONTRACTS.md §2.3
 */

import type { DN, UID, ISOTimestamp } from './api';

export interface User {
  uid: UID;
  dn: DN;
  displayName: string;
  mail: string;
  mobile: string;
  orgDn: DN;
  title?: string;
  memberOf?: string[];
}

export interface UserCreateRequest {
  uid: UID;
  displayName?: string;
  mail?: string;
  mobile?: string;
  orgDn?: DN;
  title?: string;
  password: string;
  groups?: string[];
}

export interface UserUpdateRequest {
  displayName?: string;
  mail?: string;
  mobile?: string;
}

export interface UserTerminateRequest {
  reason: string;
  immediate?: boolean;
}

export interface UserSuspendRequest {
  reason: string;
}

export interface UserUnsuspendRequest {
  newPassword: string;
}

export interface TerminationResponse {
  ok: true;
  status: 'terminated';
  user_uid: UID;
  event_id: number;
  actions: {
    ldap_disabled: boolean;
    tokens_revoked: number;
    authentik_sessions_revoked: number | null;
    uc_sessions_terminated: number | null;
  };
  timestamp: ISOTimestamp;
}

export interface Group {
  cn: string;
  dn: DN;
  description?: string;
  members?: DN[];
}

export interface OrgTreeNode {
  dn: DN;
  name: string;
  children: OrgTreeNode[];
}
```

**Step 3: Create qr.ts**

```typescript
/**
 * QR provisioning types matching FRONTEND_API_CONTRACTS.md §2.2, §2.4, §2.5
 */

import type { UID, DN, UnixTimestamp, ISOTimestamp } from './api';

/** UC Configuration in QR payload */
export interface UCConfig {
  tenant: string;
  xmpp: {
    domain: string;
    wsUrl: string;
  };
  sip: {
    domain: string;
    wssUrl: string;
  };
  credentials: {
    username: UID;
    token: string;
  };
}

/** SSO Configuration (Phase 2) */
export interface SSOConfig {
  enabled: boolean;
  issuer: string;
  clientId: string;
}

/** QR Payload v2 schema */
export interface ProvisioningPayloadV2 {
  schema: 'azblink.provisioning.v2';
  payload: {
    uc: UCConfig;
    sso: SSOConfig | null;
  };
  iat: UnixTimestamp;
  exp: UnixTimestamp;
  nonce: string;
  sig: string;
}

/** GET /api/users/{uid}/qrcode response */
export interface QRCodeResponse {
  ok: true;
  uid: UID;
  orgDn: DN;
  qrType: 'unified' | 'split';
  payload: ProvisioningPayloadV2;
  pngBase64: string;
}

/** GET /api/users/{uid}/qrcode query params */
export interface QRCodeParams {
  ttl_sec?: number;
}

/** POST /api/users/{uid}/qrcode/revoke response */
export interface QRRevokeResponse {
  ok: true;
  user_uid: UID;
  tokens_revoked: number;
}

/** Token consumption error codes */
export type TokenError =
  | 'INVALID_SIGNATURE'
  | 'TOKEN_NOT_FOUND'
  | 'TOKEN_ALREADY_CONSUMED'
  | 'TOKEN_EXPIRED';

export function isTokenError(error: string): error is TokenError {
  return ['INVALID_SIGNATURE', 'TOKEN_NOT_FOUND',
          'TOKEN_ALREADY_CONSUMED', 'TOKEN_EXPIRED'].includes(error);
}

/** Validate QR payload structure */
export function validateQRPayload(payload: unknown): payload is ProvisioningPayloadV2 {
  if (typeof payload !== 'object' || payload === null) return false;
  const p = payload as ProvisioningPayloadV2;

  return (
    p.schema === 'azblink.provisioning.v2' &&
    typeof p.payload?.uc?.credentials?.token === 'string' &&
    typeof p.exp === 'number' &&
    typeof p.sig === 'string'
  );
}

/** Check if QR is expired */
export function isQRExpired(payload: ProvisioningPayloadV2): boolean {
  return Math.floor(Date.now() / 1000) > payload.exp;
}
```

**Step 4: Create audit.ts**

```typescript
/**
 * Audit types matching FRONTEND_API_CONTRACTS.md §2.6
 */

import type { UID, DN, ISOTimestamp } from './api';

export interface QRIssuanceAuditRecord {
  id: number;
  user_uid: UID;
  org_dn: DN;
  issued_by: string;
  issued_at: ISOTimestamp;
  token_hash: string;
  expires_at: ISOTimestamp;
  consumed: boolean;
  consumed_at?: ISOTimestamp;
  consumed_reason?: string;
  client_ip?: string;
  user_agent?: string;
}

export interface TerminationAuditRecord {
  id: number;
  user_uid: UID;
  user_dn: DN;
  org_dn: DN;
  terminated_by: string;
  terminated_at: ISOTimestamp;
  reason: string;
  actions_taken: {
    ldap_disabled: boolean;
    tokens_revoked: number;
    authentik_sessions_revoked?: number;
    uc_sessions_terminated?: number;
  };
}

export interface UserLifecycleRecord {
  id: number;
  uid: UID;
  event_type: 'created' | 'suspended' | 'unsuspended' | 'password_reset' | 'terminated';
  performed_by: string;
  performed_at: ISOTimestamp;
  details?: string;
}
```

**Step 5: Create index.ts barrel export**

```typescript
/**
 * Type exports for AZBlink Directory frontend
 */

export * from './api';
export * from './user';
export * from './qr';
export * from './audit';
```

**Step 6: Commit**

```bash
git add src/frontend/src/types/
git commit -m "feat(frontend): add TypeScript types from API contracts

- Add base API types (ApiResponse, errors, type guards)
- Add user management types (User, Groups, Org)
- Add QR provisioning types (payload v2, responses)
- Add audit types (issuance, termination records)

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 5: Create API Client

**Files:**
- Create: `src/frontend/src/lib/api-client.ts`
- Create: `src/frontend/src/lib/errors.ts`

**Step 1: Create errors.ts**

```typescript
/**
 * Error handling utilities for API responses
 * Matches FRONTEND_API_CONTRACTS.md §4
 */

import { ApiErrorResponse, HTTP_ERRORS, isApiError } from '@/types';

/** Token-specific errors */
export const TOKEN_ERRORS = {
  INVALID_SIGNATURE: { status: 400, message: 'Signature verification failed' },
  TOKEN_NOT_FOUND: { status: 404, message: 'Token does not exist' },
  TOKEN_ALREADY_CONSUMED: { status: 409, message: 'Token was already used' },
  TOKEN_EXPIRED: { status: 410, message: 'Token has expired' },
} as const;

/** User management errors */
export const USER_ERRORS = {
  USER_NOT_FOUND: { status: 404, message: 'User not found' },
  USER_ALREADY_EXISTS: { status: 409, message: 'User already exists' },
  INVALID_ORG_DN: { status: 400, message: 'Invalid organization DN' },
} as const;

/** Extract error from HTTP response */
export async function extractError(response: Response): Promise<ApiErrorResponse> {
  try {
    const body = await response.json();
    if (isApiError(body)) return body;
    // Handle FastAPI HTTPException format
    if (body.detail) {
      if (typeof body.detail === 'object') {
        return { ok: false, ...body.detail };
      }
      return { ok: false, error: 'API_ERROR', detail: body.detail };
    }
  } catch {
    // Non-JSON response
  }
  return {
    ok: false,
    error: HTTP_ERRORS[response.status as keyof typeof HTTP_ERRORS] || 'UNKNOWN_ERROR',
    detail: response.statusText,
  };
}
```

**Step 2: Create api-client.ts**

```typescript
/**
 * Typed API client for AZBlink Directory backend
 * Matches FRONTEND_API_CONTRACTS.md §6.1
 */

import { extractError } from './errors';

export interface ApiClientConfig {
  baseUrl: string;
  getAuthToken?: () => Promise<string | null>;
  onUnauthorized?: () => void;
  onRateLimited?: (retryAfter: number) => void;
}

let apiClient: ReturnType<typeof createApiClient> | null = null;

export function createApiClient(config: ApiClientConfig) {
  const { baseUrl, getAuthToken, onUnauthorized, onRateLimited } = config;

  async function request<T>(
    method: string,
    path: string,
    body?: unknown,
    params?: Record<string, unknown>
  ): Promise<T> {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };

    const token = await getAuthToken?.();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    // Build URL with query params
    let url = `${baseUrl}${path}`;
    if (params) {
      const searchParams = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          searchParams.append(key, String(value));
        }
      });
      const queryString = searchParams.toString();
      if (queryString) {
        url += `?${queryString}`;
      }
    }

    const response = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    // Handle rate limiting
    if (response.status === 429) {
      const retryAfter = parseInt(response.headers.get('Retry-After') || '60');
      onRateLimited?.(retryAfter);
      throw await extractError(response);
    }

    // Handle unauthorized
    if (response.status === 401) {
      onUnauthorized?.();
      throw await extractError(response);
    }

    // Handle other errors
    if (!response.ok) {
      throw await extractError(response);
    }

    return response.json();
  }

  return {
    get: <T>(path: string, params?: Record<string, unknown>) =>
      request<T>('GET', path, undefined, params),
    post: <T>(path: string, body?: unknown) =>
      request<T>('POST', path, body),
    patch: <T>(path: string, body?: unknown) =>
      request<T>('PATCH', path, body),
    delete: <T>(path: string) =>
      request<T>('DELETE', path),
  };
}

export function initializeApi(config: ApiClientConfig) {
  apiClient = createApiClient(config);
}

export function getApi() {
  if (!apiClient) {
    throw new Error('API client not initialized. Call initializeApi first.');
  }
  return apiClient;
}
```

**Step 3: Commit**

```bash
git add src/frontend/src/lib/api-client.ts src/frontend/src/lib/errors.ts
git commit -m "feat(frontend): add typed API client with error handling

- Create api-client with typed get/post/patch/delete methods
- Handle rate limiting (429) with Retry-After header
- Handle unauthorized (401) with callback
- Add error extraction for FastAPI responses

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 6: Create Zustand UI Store

**Files:**
- Create: `src/frontend/src/stores/ui-store.ts`
- Create: `src/frontend/src/stores/auth-store.ts`

**Step 1: Create ui-store.ts**

```typescript
/**
 * UI state store for app-wide UI state
 * - Sidebar collapsed state (persisted)
 * - Command palette open state
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UIState {
  sidebarCollapsed: boolean;
  commandPaletteOpen: boolean;
  toggleSidebar: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
  openCommandPalette: () => void;
  closeCommandPalette: () => void;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      commandPaletteOpen: false,
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
      openCommandPalette: () => set({ commandPaletteOpen: true }),
      closeCommandPalette: () => set({ commandPaletteOpen: false }),
    }),
    { name: 'azblink-ui' }
  )
);
```

**Step 2: Create auth-store.ts**

```typescript
/**
 * Auth state store
 * - Current user info (when REQUIRE_OIDC_AUTH=true)
 * - Token management
 * - Login/logout actions
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AuthState {
  token: string | null;
  user: {
    uid: string;
    displayName: string;
    email: string;
    isAdmin: boolean;
  } | null;
  setToken: (token: string | null) => void;
  setUser: (user: AuthState['user']) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      token: null,
      user: null,
      setToken: (token) => set({ token }),
      setUser: (user) => set({ user }),
      logout: () => set({ token: null, user: null }),
    }),
    { name: 'azblink-auth' }
  )
);
```

**Step 3: Commit**

```bash
git add src/frontend/src/stores/
git commit -m "feat(frontend): add Zustand stores for UI and auth state

- Create ui-store with sidebar/command palette state (persisted)
- Create auth-store with token/user state (persisted)
- Use zustand persist middleware for localStorage

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 7: Create TanStack Query Keys and Hooks

**Files:**
- Create: `src/frontend/src/lib/queries/keys.ts`
- Create: `src/frontend/src/lib/queries/users.ts`
- Create: `src/frontend/src/lib/queries/health.ts`

**Step 1: Create keys.ts**

```typescript
/**
 * Query key factory for TanStack Query
 * Matches FRONTEND_API_CONTRACTS.md §6.2
 */

export const queryKeys = {
  // Users
  users: ['users'] as const,
  user: (uid: string) => ['users', uid] as const,
  userGroups: (uid: string) => ['users', uid, 'groups'] as const,
  userQR: (uid: string) => ['users', uid, 'qrcode'] as const,

  // Organizations
  orgTree: ['org', 'tree'] as const,
  orgUsers: (orgDn: string, includeSub?: boolean) =>
    ['org', orgDn, 'users', { includeSub }] as const,

  // Groups
  groups: ['groups'] as const,
  groupMembers: (cn: string) => ['groups', cn, 'members'] as const,

  // Audit
  audit: {
    qrIssuance: (limit?: number) => ['audit', 'qr_issuance', { limit }] as const,
    terminations: (limit?: number) => ['audit', 'terminations', { limit }] as const,
  },

  // Health
  health: ['health'] as const,
};
```

**Step 2: Create users.ts**

```typescript
/**
 * TanStack Query options for user endpoints
 */

import { queryOptions } from '@tanstack/react-query';
import { getApi } from '../api-client';
import { queryKeys } from './keys';
import type { User, Group } from '@/types';

export const usersQueryOptions = () =>
  queryOptions({
    queryKey: queryKeys.users,
    queryFn: () => getApi().get<{ users: User[] }>('/users'),
    staleTime: 30_000,
  });

export const userQueryOptions = (uid: string) =>
  queryOptions({
    queryKey: queryKeys.user(uid),
    queryFn: () => getApi().get<{ user: User }>(`/users/${uid}`),
    staleTime: 60_000,
    enabled: !!uid,
  });

export const userGroupsQueryOptions = (uid: string) =>
  queryOptions({
    queryKey: queryKeys.userGroups(uid),
    queryFn: () => getApi().get<{ groups: Group[] }>(`/users/${uid}/groups`),
    staleTime: 60_000,
    enabled: !!uid,
  });
```

**Step 3: Create health.ts**

```typescript
/**
 * TanStack Query options for health endpoint
 */

import { queryOptions } from '@tanstack/react-query';
import { getApi } from '../api-client';
import { queryKeys } from './keys';

export interface HealthResponse {
  status: string;
  ldap: string;
  database: string;
  redis?: string;
  version?: string;
}

export const healthQueryOptions = () =>
  queryOptions({
    queryKey: queryKeys.health,
    queryFn: () => getApi().get<HealthResponse>('/health'),
    staleTime: 10_000,
    refetchInterval: 30_000,
  });
```

**Step 4: Commit**

```bash
git add src/frontend/src/lib/queries/
git commit -m "feat(frontend): add TanStack Query key factory and hooks

- Create query key factory for cache management
- Add user query options with staleTime config
- Add health query options with auto-refetch

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 8: Create Application Entry Point and Root Route

**Files:**
- Create: `src/frontend/src/main.tsx`
- Create: `src/frontend/src/routes/__root.tsx`

**Step 1: Create main.tsx**

```typescript
/**
 * Application entry point
 * - Initializes API client
 * - Sets up React Query and Router providers
 * - Mounts app to DOM
 */

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { RouterProvider, createRouter } from '@tanstack/react-router';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { Toaster } from 'sonner';
import { routeTree } from './routeTree.gen';
import { initializeApi } from '@/lib/api-client';
import { useAuthStore } from '@/stores/auth-store';
import '@/styles/globals.css';

// Initialize API client
initializeApi({
  baseUrl: import.meta.env.VITE_API_BASE || '/api',
  getAuthToken: () => Promise.resolve(useAuthStore.getState().token),
  onUnauthorized: () => useAuthStore.getState().logout(),
  onRateLimited: (retryAfter) => {
    console.warn(`Rate limited. Retry after ${retryAfter}s`);
  },
});

// Create query client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: 1,
    },
  },
});

// Create router
const router = createRouter({
  routeTree,
  context: { queryClient },
  defaultPreload: 'intent',
});

// Type registration for router
declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

// Render app
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
      <Toaster position="bottom-right" richColors />
      {import.meta.env.DEV && (
        <ReactQueryDevtools initialIsOpen={false} />
      )}
    </QueryClientProvider>
  </StrictMode>
);
```

**Step 2: Create __root.tsx**

```typescript
/**
 * Root route - App shell with header, sidebar, and content area
 * Layout matches enterprise-ui-redesign.md §3.1
 */

import { createRootRoute, Outlet } from '@tanstack/react-router';
import { TanStackRouterDevtools } from '@tanstack/router-devtools';

export const Route = createRootRoute({
  component: RootLayout,
});

function RootLayout() {
  return (
    <div className="min-h-screen bg-background">
      {/* TODO: Add Header component */}
      {/* TODO: Add Sidebar component */}
      <main className="p-6">
        <Outlet />
      </main>
      {import.meta.env.DEV && <TanStackRouterDevtools />}
    </div>
  );
}
```

**Step 3: Create index route placeholder**

Create: `src/frontend/src/routes/index.tsx`

```typescript
/**
 * Dashboard route - /
 */

import { createFileRoute } from '@tanstack/react-router';

export const Route = createFileRoute('/')({
  component: Dashboard,
});

function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-text">Dashboard</h1>
      <p className="text-muted-foreground">Welcome to AZBlink Directory</p>
    </div>
  );
}
```

**Step 4: Generate route tree**

Run: `cd src/frontend && npx @tanstack/router-cli generate`
Expected: `routeTree.gen.ts` created

**Step 5: Run dev server to verify app loads**

Run: `cd src/frontend && npm run dev`
Expected: App loads at http://localhost:3000 showing "Dashboard" heading

**Step 6: Commit**

```bash
git add src/frontend/src/main.tsx src/frontend/src/routes/ src/frontend/src/routeTree.gen.ts
git commit -m "feat(frontend): add app entry point and root route

- Create main.tsx with providers (Query, Router, Toaster)
- Create root layout with placeholder for header/sidebar
- Create index route with dashboard placeholder
- Generate TanStack Router route tree

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Phase 2: App Shell Components

### Task 9: Create Header Component

**Files:**
- Create: `src/frontend/src/components/layout/header.tsx`

**Step 1: Create header.tsx**

```typescript
/**
 * Top header component
 * Layout: enterprise-ui-redesign.md §4.1
 * Height: 56px, fixed position, z-30
 */

import { Menu, Search, Bell, HelpCircle, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUIStore } from '@/stores/ui-store';

export function Header() {
  const { toggleSidebar, openCommandPalette } = useUIStore();

  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-surface border-b border-border z-header flex items-center px-4">
      {/* Left section */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleSidebar}
          className="h-10 w-10"
          aria-label="Toggle sidebar"
        >
          <Menu className="h-5 w-5" />
        </Button>

        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-md bg-accent flex items-center justify-center">
            <span className="text-accent-foreground font-bold text-sm">AZ</span>
          </div>
          <span className="font-semibold text-text hidden sm:block">AZBlink</span>
        </div>
      </div>

      {/* Center - Search */}
      <div className="flex-1 max-w-xl mx-4 hidden md:block">
        <button
          onClick={openCommandPalette}
          className="w-full h-10 px-4 flex items-center gap-2 text-muted-foreground bg-muted rounded-md hover:bg-slate-200 transition-colors"
        >
          <Search className="h-4 w-4" />
          <span className="flex-1 text-left text-sm">Search...</span>
          <kbd className="hidden lg:inline-flex h-5 items-center gap-1 rounded border border-border bg-surface px-1.5 font-mono text-xs text-muted-foreground">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right section */}
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className="h-10 w-10 md:hidden"
          onClick={openCommandPalette}
          aria-label="Search"
        >
          <Search className="h-5 w-5" />
        </Button>

        <Button variant="ghost" size="icon" className="h-10 w-10" aria-label="Notifications">
          <Bell className="h-5 w-5" />
        </Button>

        <Button variant="ghost" size="icon" className="h-10 w-10" aria-label="Help">
          <HelpCircle className="h-5 w-5" />
        </Button>

        {/* Profile */}
        <Button variant="ghost" className="h-10 gap-2 px-2">
          <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center">
            <span className="text-accent-foreground text-sm font-medium">AD</span>
          </div>
          <span className="hidden lg:block text-sm font-medium">Admin</span>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </Button>
      </div>
    </header>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/layout/header.tsx
git commit -m "feat(frontend): add Header component with search trigger

- Fixed header with logo, search bar, notifications, profile
- Mobile-responsive with icon-only search on small screens
- Command palette trigger (⌘K shortcut display)

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 10: Create Sidebar Component

**Files:**
- Create: `src/frontend/src/components/layout/sidebar.tsx`

**Step 1: Create sidebar.tsx**

```typescript
/**
 * Sidebar navigation component
 * Layout: enterprise-ui-redesign.md §4.2
 * Width: 256px expanded, 64px collapsed
 */

import { Link, useRouterState } from '@tanstack/react-router';
import {
  LayoutDashboard,
  Users,
  Building2,
  FolderTree,
  QrCode,
  KeyRound,
  Settings,
  User,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useUIStore } from '@/stores/ui-store';

interface NavItem {
  label: string;
  href: string;
  icon: React.ElementType;
}

interface NavSection {
  label: string;
  items: NavItem[];
}

const navigation: NavSection[] = [
  {
    label: 'Overview',
    items: [
      { label: 'Dashboard', href: '/', icon: LayoutDashboard },
    ],
  },
  {
    label: 'Directory',
    items: [
      { label: 'Users', href: '/directory/users', icon: Users },
      { label: 'Groups', href: '/directory/groups', icon: Building2 },
      { label: 'Organizations', href: '/directory/orgs', icon: FolderTree },
    ],
  },
  {
    label: 'Provisioning',
    items: [
      { label: 'QR Generator', href: '/provisioning/qr-generator', icon: QrCode },
      { label: 'Tokens', href: '/provisioning/tokens', icon: KeyRound },
    ],
  },
  {
    label: 'Account',
    items: [
      { label: 'My Profile', href: '/my-profile', icon: User },
      { label: 'Settings', href: '/settings', icon: Settings },
    ],
  },
];

export function Sidebar() {
  const { sidebarCollapsed } = useUIStore();
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;

  return (
    <aside
      className={cn(
        'fixed top-14 left-0 bottom-0 bg-slate-50 border-r border-border z-sidebar transition-all duration-200',
        sidebarCollapsed ? 'w-16' : 'w-64'
      )}
    >
      <nav className="h-full overflow-y-auto py-4">
        {navigation.map((section) => (
          <div key={section.label} className="mb-6">
            {!sidebarCollapsed && (
              <h3 className="px-4 mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                {section.label}
              </h3>
            )}
            <ul className="space-y-1 px-2">
              {section.items.map((item) => {
                const isActive = currentPath === item.href ||
                  (item.href !== '/' && currentPath.startsWith(item.href));
                const Icon = item.icon;

                return (
                  <li key={item.href}>
                    <Link
                      to={item.href}
                      className={cn(
                        'flex items-center gap-3 h-10 px-3 rounded-md transition-colors',
                        isActive
                          ? 'bg-sky-50 text-accent border-l-2 border-accent'
                          : 'text-slate-600 hover:bg-slate-100',
                        sidebarCollapsed && 'justify-center px-0'
                      )}
                      title={sidebarCollapsed ? item.label : undefined}
                    >
                      <Icon className="h-5 w-5 flex-shrink-0" />
                      {!sidebarCollapsed && (
                        <span className="text-sm font-medium">{item.label}</span>
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/layout/sidebar.tsx
git commit -m "feat(frontend): add Sidebar component with navigation

- Collapsible sidebar (64px collapsed, 256px expanded)
- Section labels with icon-only mode when collapsed
- Active state with accent border and background
- Smooth transition animations

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 11: Create Breadcrumb Component

**Files:**
- Create: `src/frontend/src/components/layout/breadcrumb.tsx`
- Create: `src/frontend/src/hooks/use-breadcrumb.ts`

**Step 1: Create use-breadcrumb.ts**

```typescript
/**
 * Hook to generate breadcrumb segments from current route
 */

import { useRouterState } from '@tanstack/react-router';
import { useMemo } from 'react';

interface BreadcrumbSegment {
  label: string;
  href: string;
  current: boolean;
}

const routeLabels: Record<string, string> = {
  '': 'Home',
  'directory': 'Directory',
  'users': 'Users',
  'groups': 'Groups',
  'orgs': 'Organizations',
  'provisioning': 'Provisioning',
  'qr-generator': 'QR Generator',
  'tokens': 'Tokens',
  'my-profile': 'My Profile',
  'settings': 'Settings',
};

export function useBreadcrumb(): BreadcrumbSegment[] {
  const routerState = useRouterState();
  const pathname = routerState.location.pathname;

  return useMemo(() => {
    const segments = pathname.split('/').filter(Boolean);

    if (segments.length === 0) {
      return [{ label: 'Home', href: '/', current: true }];
    }

    const breadcrumbs: BreadcrumbSegment[] = [
      { label: 'Home', href: '/', current: false },
    ];

    let currentPath = '';
    segments.forEach((segment, index) => {
      currentPath += `/${segment}`;
      const isLast = index === segments.length - 1;

      // Check if segment looks like a UID (dynamic route param)
      const isDynamic = !routeLabels[segment];
      const label = isDynamic ? segment : routeLabels[segment] || segment;

      breadcrumbs.push({
        label,
        href: currentPath,
        current: isLast,
      });
    });

    return breadcrumbs;
  }, [pathname]);
}
```

**Step 2: Create breadcrumb.tsx**

```typescript
/**
 * Breadcrumb bar component
 * Layout: enterprise-ui-redesign.md §4.3
 * Height: 48px, sticky position
 */

import { Link } from '@tanstack/react-router';
import { ChevronRight } from 'lucide-react';
import { useBreadcrumb } from '@/hooks/use-breadcrumb';

interface BreadcrumbProps {
  actions?: React.ReactNode;
}

export function Breadcrumb({ actions }: BreadcrumbProps) {
  const segments = useBreadcrumb();

  return (
    <div className="sticky top-0 h-12 bg-surface border-b border-border z-10 flex items-center justify-between px-6">
      <nav className="flex items-center gap-1 text-sm" aria-label="Breadcrumb">
        {segments.map((segment, index) => (
          <div key={segment.href} className="flex items-center gap-1">
            {index > 0 && (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )}
            {segment.current ? (
              <span className="font-medium text-text">{segment.label}</span>
            ) : (
              <Link
                to={segment.href}
                className="text-muted-foreground hover:text-text transition-colors"
              >
                {segment.label}
              </Link>
            )}
          </div>
        ))}
      </nav>

      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}
```

**Step 3: Commit**

```bash
git add src/frontend/src/components/layout/breadcrumb.tsx src/frontend/src/hooks/use-breadcrumb.ts
git commit -m "feat(frontend): add Breadcrumb component with route hook

- Auto-generate breadcrumbs from current route path
- Support for dynamic route params (user UIDs, etc)
- Optional actions slot for page-level buttons
- Sticky positioning with proper z-index

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 12: Integrate App Shell in Root Layout

**Files:**
- Modify: `src/frontend/src/routes/__root.tsx`

**Step 1: Update __root.tsx with app shell**

```typescript
/**
 * Root route - App shell with header, sidebar, and content area
 * Layout matches enterprise-ui-redesign.md §3.1
 */

import { createRootRoute, Outlet } from '@tanstack/react-router';
import { TanStackRouterDevtools } from '@tanstack/router-devtools';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { Breadcrumb } from '@/components/layout/breadcrumb';
import { useUIStore } from '@/stores/ui-store';
import { cn } from '@/lib/utils';

export const Route = createRootRoute({
  component: RootLayout,
});

function RootLayout() {
  const { sidebarCollapsed } = useUIStore();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />

      <main
        className={cn(
          'pt-14 transition-all duration-200',
          sidebarCollapsed ? 'ml-16' : 'ml-64'
        )}
      >
        <Breadcrumb />
        <div className="p-6">
          <Outlet />
        </div>
      </main>

      {import.meta.env.DEV && <TanStackRouterDevtools />}
    </div>
  );
}
```

**Step 2: Run dev server to verify app shell**

Run: `cd src/frontend && npm run dev`
Expected: App shows header, sidebar, breadcrumb, and dashboard content

**Step 3: Commit**

```bash
git add src/frontend/src/routes/__root.tsx
git commit -m "feat(frontend): integrate app shell in root layout

- Add Header, Sidebar, Breadcrumb to root layout
- Responsive main content offset based on sidebar state
- Smooth transitions on sidebar collapse/expand

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 13: Add Keyboard Shortcuts Hook

**Files:**
- Create: `src/frontend/src/hooks/use-keyboard.ts`
- Modify: `src/frontend/src/routes/__root.tsx`

**Step 1: Create use-keyboard.ts**

```typescript
/**
 * Keyboard shortcuts hook
 * - ⌘K / Ctrl+K: Open command palette
 * - ⌘B / Ctrl+B: Toggle sidebar
 */

import { useEffect } from 'react';
import { useUIStore } from '@/stores/ui-store';

export function useKeyboardShortcuts() {
  const { openCommandPalette, toggleSidebar } = useUIStore();

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      // Check for ⌘/Ctrl modifier
      const isMod = event.metaKey || event.ctrlKey;

      if (isMod && event.key === 'k') {
        event.preventDefault();
        openCommandPalette();
      }

      if (isMod && event.key === 'b') {
        event.preventDefault();
        toggleSidebar();
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [openCommandPalette, toggleSidebar]);
}
```

**Step 2: Add hook to root layout**

Update `src/frontend/src/routes/__root.tsx`:

Add import:
```typescript
import { useKeyboardShortcuts } from '@/hooks/use-keyboard';
```

Add in RootLayout function before return:
```typescript
useKeyboardShortcuts();
```

**Step 3: Commit**

```bash
git add src/frontend/src/hooks/use-keyboard.ts src/frontend/src/routes/__root.tsx
git commit -m "feat(frontend): add keyboard shortcuts (⌘K, ⌘B)

- ⌘K / Ctrl+K opens command palette
- ⌘B / Ctrl+B toggles sidebar
- Global listener in root layout

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Phase 3: Core Feature Components

### Task 14: Create Stat Card Component

**Files:**
- Create: `src/frontend/src/components/features/stat-card.tsx`

**Step 1: Create stat-card.tsx**

```typescript
/**
 * Stat card for dashboard metrics
 * Design: enterprise-ui-redesign.md §4.6
 */

import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface StatCardProps {
  label: string;
  value: string | number;
  change?: {
    value: string;
    positive?: boolean;
  };
  icon?: React.ReactNode;
  className?: string;
}

export function StatCard({ label, value, change, icon, className }: StatCardProps) {
  return (
    <Card className={cn('', className)}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{label}</p>
            <p className="text-3xl font-semibold text-text mt-1">{value}</p>
            {change && (
              <p
                className={cn(
                  'text-sm mt-1',
                  change.positive ? 'text-success' : 'text-destructive'
                )}
              >
                {change.value}
              </p>
            )}
          </div>
          {icon && (
            <div className="h-10 w-10 rounded-md bg-muted flex items-center justify-center text-muted-foreground">
              {icon}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/stat-card.tsx
git commit -m "feat(frontend): add StatCard component for dashboard metrics

- Display label, value, optional change indicator
- Optional icon slot
- Follows enterprise design spec

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 15: Create Health Status Component

**Files:**
- Create: `src/frontend/src/components/features/health-status.tsx`

**Step 1: Create health-status.tsx**

```typescript
/**
 * Health status display for dashboard
 * Shows LDAP, PostgreSQL, Redis connection status
 */

import { useSuspenseQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { healthQueryOptions } from '@/lib/queries/health';
import { cn } from '@/lib/utils';

interface StatusItemProps {
  label: string;
  status: string;
}

function StatusItem({ label, status }: StatusItemProps) {
  const isHealthy = status === 'connected' || status === 'ok' || status === 'healthy';
  const isNA = status === 'n/a' || status === 'disabled';

  return (
    <div className="flex items-center justify-between py-2">
      <span className="text-sm text-muted-foreground">{label}</span>
      <Badge
        variant="outline"
        className={cn(
          isHealthy && 'border-success text-success bg-success-light',
          !isHealthy && !isNA && 'border-destructive text-destructive bg-destructive-light',
          isNA && 'border-muted-foreground text-muted-foreground bg-muted'
        )}
      >
        <span
          className={cn(
            'h-2 w-2 rounded-full mr-2',
            isHealthy && 'bg-success',
            !isHealthy && !isNA && 'bg-destructive',
            isNA && 'bg-muted-foreground'
          )}
        />
        {status}
      </Badge>
    </div>
  );
}

export function HealthStatus() {
  const { data } = useSuspenseQuery(healthQueryOptions());

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">System Health</CardTitle>
      </CardHeader>
      <CardContent className="divide-y divide-border">
        <StatusItem label="LDAP" status={data.ldap || 'unknown'} />
        <StatusItem label="PostgreSQL" status={data.database || 'unknown'} />
        <StatusItem label="Redis" status={data.redis || 'n/a'} />
        <StatusItem label="Authentik" status="n/a" />
      </CardContent>
    </Card>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/health-status.tsx
git commit -m "feat(frontend): add HealthStatus component for system monitoring

- Display LDAP, PostgreSQL, Redis, Authentik status
- Color-coded badges (green/red/gray)
- Auto-refetch via TanStack Query

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 16: Create User Table Component

**Files:**
- Create: `src/frontend/src/components/features/user-table.tsx`
- Install: `npx shadcn@latest add table skeleton`

**Step 1: Install table and skeleton components**

Run: `cd src/frontend && npx shadcn@latest add table skeleton`
Expected: Table and skeleton components added

**Step 2: Create user-table.tsx**

```typescript
/**
 * User table component for Users list page
 * Design: enterprise-ui-redesign.md §5.2
 */

import { Link } from '@tanstack/react-router';
import { MoreHorizontal, QrCode, Key, User as UserIcon } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import type { User } from '@/types';
import { cn } from '@/lib/utils';

interface UserTableProps {
  users: User[];
  isLoading?: boolean;
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

function getOrgName(orgDn: string): string {
  // Extract org name from DN like "ou=Engineering,ou=org,dc=azblink,dc=com"
  const match = orgDn.match(/^ou=([^,]+)/);
  return match ? match[1] : orgDn;
}

export function UserTable({ users, isLoading }: UserTableProps) {
  if (isLoading) {
    return <UserTableSkeleton />;
  }

  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="w-[300px]">User</TableHead>
            <TableHead>Organization</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="w-[80px]">QR#1</TableHead>
            <TableHead className="w-[80px]">QR#2</TableHead>
            <TableHead className="w-[60px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user.uid} className="hover:bg-muted/30">
              <TableCell>
                <Link
                  to="/directory/users/$uid"
                  params={{ uid: user.uid }}
                  className="flex items-center gap-3 group"
                >
                  <div className="h-9 w-9 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
                    <span className="text-accent-foreground text-sm font-medium">
                      {getInitials(user.displayName || user.uid)}
                    </span>
                  </div>
                  <div className="min-w-0">
                    <p className="font-medium text-text group-hover:text-accent truncate">
                      {user.displayName || user.uid}
                    </p>
                    <p className="text-sm text-muted-foreground truncate">
                      {user.mail}
                    </p>
                  </div>
                </Link>
              </TableCell>
              <TableCell className="text-muted-foreground">
                {getOrgName(user.orgDn)}
              </TableCell>
              <TableCell>
                <Badge
                  variant="outline"
                  className="border-success text-success bg-success-light"
                >
                  Active
                </Badge>
              </TableCell>
              <TableCell>
                <QrCode className="h-4 w-4 text-success" />
              </TableCell>
              <TableCell>
                <Key className="h-4 w-4 text-muted-foreground" />
              </TableCell>
              <TableCell>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function UserTableSkeleton() {
  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="w-[300px]">User</TableHead>
            <TableHead>Organization</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="w-[80px]">QR#1</TableHead>
            <TableHead className="w-[80px]">QR#2</TableHead>
            <TableHead className="w-[60px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {Array.from({ length: 5 }).map((_, i) => (
            <TableRow key={i}>
              <TableCell>
                <div className="flex items-center gap-3">
                  <Skeleton className="h-9 w-9 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-48" />
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <Skeleton className="h-4 w-24" />
              </TableCell>
              <TableCell>
                <Skeleton className="h-5 w-16" />
              </TableCell>
              <TableCell>
                <Skeleton className="h-4 w-4" />
              </TableCell>
              <TableCell>
                <Skeleton className="h-4 w-4" />
              </TableCell>
              <TableCell>
                <Skeleton className="h-8 w-8" />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
```

**Step 3: Commit**

```bash
git add src/frontend/src/components/ui/ src/frontend/src/components/features/user-table.tsx
git commit -m "feat(frontend): add UserTable component with loading skeleton

- Sortable columns with avatar, name, email, org, status
- QR status icons (green/gray)
- Loading skeleton state
- Click row to navigate to user detail

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 17: Create QR Display Component

**Files:**
- Create: `src/frontend/src/components/features/qr-display.tsx`

**Step 1: Create qr-display.tsx**

```typescript
/**
 * QR code display component for provisioning
 * Design: enterprise-ui-redesign.md §5.4
 */

import { Copy, Download, Mail } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import type { QRCodeResponse } from '@/types';

interface QRDisplayProps {
  data: QRCodeResponse | null;
  isLoading?: boolean;
  onRegenerate?: () => void;
}

export function QRDisplay({ data, isLoading, onRegenerate }: QRDisplayProps) {
  if (isLoading) {
    return <QRDisplaySkeleton />;
  }

  if (!data) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <p className="text-muted-foreground">Select a user to generate QR code</p>
        </CardContent>
      </Card>
    );
  }

  const handleCopyLink = async () => {
    // In a real implementation, this would copy a deep link
    await navigator.clipboard.writeText(data.payload.uc.credentials.token);
    toast.success('Token copied to clipboard');
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = `data:image/png;base64,${data.pngBase64}`;
    link.download = `qr-${data.uid}-${Date.now()}.png`;
    link.click();
    toast.success('QR code downloaded');
  };

  const handleEmail = () => {
    // In a real implementation, this would open email compose
    toast.info('Email functionality coming soon');
  };

  // Calculate expiry from payload
  const expiresAt = new Date(data.payload.exp * 1000);
  const expiresIn = Math.max(0, Math.floor((expiresAt.getTime() - Date.now()) / 1000 / 60));

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium">QR Code for {data.uid}</CardTitle>
          <Badge variant="outline" className="text-xs">
            Expires in {expiresIn}m
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* QR Image */}
        <div className="flex justify-center p-4 bg-white rounded-lg border border-border">
          <img
            src={`data:image/png;base64,${data.pngBase64}`}
            alt={`QR code for ${data.uid}`}
            className="w-64 h-64"
          />
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={handleCopyLink}>
            <Copy className="h-4 w-4 mr-2" />
            Copy Link
          </Button>
          <Button variant="outline" className="flex-1" onClick={handleDownload}>
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
          <Button variant="outline" className="flex-1" onClick={handleEmail}>
            <Mail className="h-4 w-4 mr-2" />
            Email
          </Button>
        </div>

        {/* Regenerate */}
        {onRegenerate && (
          <Button variant="secondary" className="w-full" onClick={onRegenerate}>
            Regenerate QR Code
          </Button>
        )}

        {/* Info */}
        <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t border-border">
          <p>
            <strong>Type:</strong> {data.qrType === 'unified' ? 'UC Core (QR#1)' : 'Split'}
          </p>
          <p>
            <strong>Schema:</strong> {data.payload.schema}
          </p>
          <p>
            <strong>SSO:</strong> {data.payload.payload.sso ? 'Enabled' : 'Disabled'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

function QRDisplaySkeleton() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <Skeleton className="h-5 w-32" />
          <Skeleton className="h-5 w-24" />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-center p-4 bg-white rounded-lg border border-border">
          <Skeleton className="w-64 h-64" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-10 flex-1" />
          <Skeleton className="h-10 flex-1" />
          <Skeleton className="h-10 flex-1" />
        </div>
      </CardContent>
    </Card>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/components/features/qr-display.tsx
git commit -m "feat(frontend): add QRDisplay component for provisioning

- Display QR code image from base64
- Copy link, download, email actions
- Expiry countdown badge
- Loading skeleton state

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Phase 4: Route Pages

### Task 18: Create Dashboard Page

**Files:**
- Modify: `src/frontend/src/routes/index.tsx`

**Step 1: Update index.tsx with full dashboard**

```typescript
/**
 * Dashboard route - /
 * Design: enterprise-ui-redesign.md §5.1
 */

import { createFileRoute } from '@tanstack/react-router';
import { Suspense } from 'react';
import { useSuspenseQuery } from '@tanstack/react-query';
import { Users, Building2, FolderTree, QrCode, Plus, Upload } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { StatCard } from '@/components/features/stat-card';
import { HealthStatus } from '@/components/features/health-status';
import { usersQueryOptions } from '@/lib/queries/users';

export const Route = createFileRoute('/')({
  component: Dashboard,
});

function Dashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-text">Dashboard</h1>

      {/* Stats Row */}
      <Suspense fallback={<StatsRowSkeleton />}>
        <StatsRow />
      </Suspense>

      {/* Quick Actions + Health */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base font-medium">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Plus className="h-5 w-5" />
              <span>New User</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <QrCode className="h-5 w-5" />
              <span>Generate QR</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Upload className="h-5 w-5" />
              <span>Bulk Import</span>
            </Button>
          </CardContent>
        </Card>

        <Suspense fallback={<HealthStatusSkeleton />}>
          <HealthStatus />
        </Suspense>
      </div>

      {/* Recent Activity placeholder */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-medium">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No recent activity to display.</p>
        </CardContent>
      </Card>
    </div>
  );
}

function StatsRow() {
  const { data } = useSuspenseQuery(usersQueryOptions());
  const userCount = data.users?.length ?? 0;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard
        label="Users"
        value={userCount}
        change={{ value: '+3 today', positive: true }}
        icon={<Users className="h-5 w-5" />}
      />
      <StatCard
        label="Groups"
        value={12}
        icon={<Building2 className="h-5 w-5" />}
      />
      <StatCard
        label="Organizations"
        value={5}
        icon={<FolderTree className="h-5 w-5" />}
      />
      <StatCard
        label="Pending QR Scans"
        value={8}
        icon={<QrCode className="h-5 w-5" />}
      />
    </div>
  );
}

function StatsRowSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i}>
          <CardContent className="p-6">
            <Skeleton className="h-4 w-16 mb-2" />
            <Skeleton className="h-8 w-12" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function HealthStatusSkeleton() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <Skeleton className="h-5 w-24" />
      </CardHeader>
      <CardContent className="space-y-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex justify-between">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-5 w-24" />
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
```

**Step 2: Commit**

```bash
git add src/frontend/src/routes/index.tsx
git commit -m "feat(frontend): complete Dashboard page with stats and health

- Stats row with user count from API, placeholder metrics
- Quick actions (New User, Generate QR, Bulk Import)
- Health status card with Suspense loading
- Recent activity placeholder

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 19: Create Users List Page

**Files:**
- Create: `src/frontend/src/routes/directory/users/index.tsx`
- Create: `src/frontend/src/routes/directory/route.tsx`

**Step 1: Create directory/route.tsx (layout wrapper)**

```typescript
/**
 * Directory section layout wrapper
 */

import { createFileRoute, Outlet } from '@tanstack/react-router';

export const Route = createFileRoute('/directory')({
  component: DirectoryLayout,
});

function DirectoryLayout() {
  return <Outlet />;
}
```

**Step 2: Create directory/users/index.tsx**

```typescript
/**
 * Users list page - /directory/users
 * Design: enterprise-ui-redesign.md §5.2
 */

import { createFileRoute, Link } from '@tanstack/react-router';
import { Suspense } from 'react';
import { useSuspenseQuery } from '@tanstack/react-query';
import { Plus, Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { UserTable } from '@/components/features/user-table';
import { usersQueryOptions } from '@/lib/queries/users';

export const Route = createFileRoute('/directory/users/')({
  component: UsersPage,
});

function UsersPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-text">Users</h1>
        <Button asChild>
          <Link to="/directory/users/new">
            <Plus className="h-4 w-4 mr-2" />
            New User
          </Link>
        </Button>
      </div>

      {/* Search and Filter */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            className="pl-10"
          />
        </div>
        <Button variant="outline">
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </Button>
      </div>

      {/* Users Table */}
      <Suspense fallback={<UserTable users={[]} isLoading />}>
        <UsersTableWrapper />
      </Suspense>
    </div>
  );
}

function UsersTableWrapper() {
  const { data } = useSuspenseQuery(usersQueryOptions());
  return <UserTable users={data.users || []} />;
}
```

**Step 3: Generate route tree**

Run: `cd src/frontend && npx @tanstack/router-cli generate`
Expected: Route tree updated

**Step 4: Commit**

```bash
git add src/frontend/src/routes/directory/
git commit -m "feat(frontend): add Users list page with search and table

- Directory layout wrapper for nested routes
- Users list with search input and filter button
- UserTable with Suspense loading
- New User button (link to create page)

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 20: Create User Detail Page

**Files:**
- Create: `src/frontend/src/routes/directory/users/$uid.tsx`

**Step 1: Create $uid.tsx**

```typescript
/**
 * User detail page - /directory/users/:uid
 * Design: enterprise-ui-redesign.md §5.3
 */

import { createFileRoute, Link } from '@tanstack/react-router';
import { Suspense } from 'react';
import { useSuspenseQuery } from '@tanstack/react-query';
import { ArrowLeft, QrCode, Edit, MoreHorizontal } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { userQueryOptions, userGroupsQueryOptions } from '@/lib/queries/users';

export const Route = createFileRoute('/directory/users/$uid')({
  component: UserDetailPage,
});

function UserDetailPage() {
  const { uid } = Route.useParams();

  return (
    <div className="space-y-6">
      {/* Back link */}
      <Link
        to="/directory/users"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-text"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Users
      </Link>

      <Suspense fallback={<UserDetailSkeleton />}>
        <UserDetailContent uid={uid} />
      </Suspense>
    </div>
  );
}

function UserDetailContent({ uid }: { uid: string }) {
  const { data: userData } = useSuspenseQuery(userQueryOptions(uid));
  const { data: groupsData } = useSuspenseQuery(userGroupsQueryOptions(uid));

  const user = userData.user;
  const groups = groupsData?.groups || [];

  const getInitials = (name: string) =>
    name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);

  return (
    <>
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="h-16 w-16 rounded-full bg-accent flex items-center justify-center">
            <span className="text-accent-foreground text-xl font-semibold">
              {getInitials(user.displayName || user.uid)}
            </span>
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-text">
              {user.displayName || user.uid}
            </h1>
            <p className="text-muted-foreground">{user.mail}</p>
            <div className="flex items-center gap-2 mt-2">
              <Badge
                variant="outline"
                className="border-success text-success bg-success-light"
              >
                Active
              </Badge>
              <span className="text-sm text-muted-foreground">
                {user.title || 'No title'}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" asChild>
            <Link to="/provisioning/qr-generator" search={{ uid }}>
              <QrCode className="h-4 w-4 mr-2" />
              Generate QR
            </Link>
          </Button>
          <Button variant="outline">
            <Edit className="h-4 w-4 mr-2" />
            Edit
          </Button>
          <Button variant="ghost" size="icon">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Info */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base font-medium">Profile</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
            <InfoItem label="UID" value={user.uid} />
            <InfoItem label="Email" value={user.mail} />
            <InfoItem label="Mobile" value={user.mobile || 'Not set'} />
            <InfoItem label="Title" value={user.title || 'Not set'} />
            <InfoItem label="Organization" value={getOrgName(user.orgDn)} />
            <InfoItem label="DN" value={user.dn} className="col-span-2 font-mono text-xs" />
          </CardContent>
        </Card>

        {/* Groups */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base font-medium">Groups</CardTitle>
            <Button variant="ghost" size="sm">
              Manage
            </Button>
          </CardHeader>
          <CardContent>
            {groups.length === 0 ? (
              <p className="text-sm text-muted-foreground">No groups assigned</p>
            ) : (
              <div className="space-y-2">
                {groups.map((group) => (
                  <div
                    key={group.dn}
                    className="flex items-center justify-between py-2 border-b border-border last:border-0"
                  >
                    <span className="text-sm font-medium">{group.cn}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}

function InfoItem({
  label,
  value,
  className,
}: {
  label: string;
  value: string;
  className?: string;
}) {
  return (
    <div className={className}>
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd className="text-sm font-medium text-text mt-1 break-all">{value}</dd>
    </div>
  );
}

function getOrgName(orgDn: string): string {
  const match = orgDn.match(/^ou=([^,]+)/);
  return match ? match[1] : orgDn;
}

function UserDetailSkeleton() {
  return (
    <>
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <Skeleton className="h-16 w-16 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-7 w-48" />
            <Skeleton className="h-4 w-64" />
            <Skeleton className="h-5 w-32" />
          </div>
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-10 w-20" />
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardContent className="p-6 space-y-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-4 w-full" />
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-4 w-full" />
            ))}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
```

**Step 2: Generate route tree**

Run: `cd src/frontend && npx @tanstack/router-cli generate`
Expected: Route tree updated

**Step 3: Commit**

```bash
git add src/frontend/src/routes/directory/users/\$uid.tsx src/frontend/src/routeTree.gen.ts
git commit -m "feat(frontend): add User detail page with profile and groups

- User header with avatar, name, email, status
- Profile card with LDAP attributes
- Groups card with manage button
- Generate QR and Edit action buttons

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 21: Create QR Generator Page

**Files:**
- Create: `src/frontend/src/routes/provisioning/route.tsx`
- Create: `src/frontend/src/routes/provisioning/qr-generator.tsx`
- Create: `src/frontend/src/lib/queries/qr.ts`

**Step 1: Create qr.ts query**

```typescript
/**
 * TanStack Query options for QR endpoints
 */

import { queryOptions, useMutation, useQueryClient } from '@tanstack/react-query';
import { getApi } from '../api-client';
import { queryKeys } from './keys';
import type { QRCodeResponse, QRRevokeResponse } from '@/types';
import { toast } from 'sonner';

export const qrCodeQueryOptions = (uid: string, ttl?: number) =>
  queryOptions({
    queryKey: queryKeys.userQR(uid),
    queryFn: () =>
      getApi().get<QRCodeResponse>(`/users/${uid}/qrcode`, ttl ? { ttl_sec: ttl } : undefined),
    staleTime: 0, // Always fetch fresh
    gcTime: 0, // Don't cache
    enabled: !!uid,
  });

export function useRevokeQR(uid: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => getApi().post<QRRevokeResponse>(`/users/${uid}/qrcode/revoke`),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.userQR(uid) });
      toast.success(`Revoked ${data.tokens_revoked} token(s)`);
    },
    onError: () => {
      toast.error('Failed to revoke tokens');
    },
  });
}
```

**Step 2: Create provisioning/route.tsx**

```typescript
/**
 * Provisioning section layout wrapper
 */

import { createFileRoute, Outlet } from '@tanstack/react-router';

export const Route = createFileRoute('/provisioning')({
  component: ProvisioningLayout,
});

function ProvisioningLayout() {
  return <Outlet />;
}
```

**Step 3: Create provisioning/qr-generator.tsx**

```typescript
/**
 * QR Generator page - /provisioning/qr-generator
 * Design: enterprise-ui-redesign.md §5.4
 */

import { createFileRoute } from '@tanstack/react-router';
import { Suspense, useState } from 'react';
import { useSuspenseQuery, useQuery } from '@tanstack/react-query';
import { Search, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { QRDisplay } from '@/components/features/qr-display';
import { usersQueryOptions } from '@/lib/queries/users';
import { qrCodeQueryOptions, useRevokeQR } from '@/lib/queries/qr';
import type { User } from '@/types';
import { cn } from '@/lib/utils';

export const Route = createFileRoute('/provisioning/qr-generator')({
  component: QRGeneratorPage,
  validateSearch: (search: Record<string, unknown>) => ({
    uid: (search.uid as string) || undefined,
  }),
});

function QRGeneratorPage() {
  const { uid: preselectedUid } = Route.useSearch();
  const [selectedUid, setSelectedUid] = useState<string | null>(preselectedUid || null);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-text">QR Generator</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Select User</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search users..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Suspense
              fallback={
                <div className="space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="h-12 bg-muted animate-pulse rounded-md" />
                  ))}
                </div>
              }
            >
              <UserList
                searchQuery={searchQuery}
                selectedUid={selectedUid}
                onSelect={setSelectedUid}
              />
            </Suspense>
          </CardContent>
        </Card>

        {/* QR Display */}
        {selectedUid ? (
          <QRSection uid={selectedUid} />
        ) : (
          <QRDisplay data={null} />
        )}
      </div>
    </div>
  );
}

function UserList({
  searchQuery,
  selectedUid,
  onSelect,
}: {
  searchQuery: string;
  selectedUid: string | null;
  onSelect: (uid: string) => void;
}) {
  const { data } = useSuspenseQuery(usersQueryOptions());
  const users = data.users || [];

  const filteredUsers = users.filter(
    (user) =>
      user.uid.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.displayName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.mail?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (filteredUsers.length === 0) {
    return <p className="text-sm text-muted-foreground">No users found</p>;
  }

  return (
    <div className="space-y-1 max-h-[400px] overflow-y-auto">
      {filteredUsers.map((user) => (
        <UserListItem
          key={user.uid}
          user={user}
          isSelected={user.uid === selectedUid}
          onSelect={() => onSelect(user.uid)}
        />
      ))}
    </div>
  );
}

function UserListItem({
  user,
  isSelected,
  onSelect,
}: {
  user: User;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const getInitials = (name: string) =>
    name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);

  return (
    <button
      onClick={onSelect}
      className={cn(
        'w-full flex items-center gap-3 p-2 rounded-md text-left transition-colors',
        isSelected ? 'bg-accent/10 border border-accent' : 'hover:bg-muted'
      )}
    >
      <div className="h-9 w-9 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
        <span className="text-accent-foreground text-sm font-medium">
          {getInitials(user.displayName || user.uid)}
        </span>
      </div>
      <div className="min-w-0">
        <p className="font-medium text-text text-sm truncate">
          {user.displayName || user.uid}
        </p>
        <p className="text-xs text-muted-foreground truncate">{user.mail}</p>
      </div>
    </button>
  );
}

function QRSection({ uid }: { uid: string }) {
  const { data, isLoading, refetch, isFetching } = useQuery(qrCodeQueryOptions(uid));
  const revokeMutation = useRevokeQR(uid);

  return (
    <div className="space-y-4">
      <QRDisplay
        data={data ?? null}
        isLoading={isLoading}
        onRegenerate={() => refetch()}
      />
      {data && (
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => refetch()}
            disabled={isFetching}
          >
            <RefreshCw className={cn('h-4 w-4 mr-2', isFetching && 'animate-spin')} />
            Regenerate
          </Button>
          <Button
            variant="destructive"
            className="flex-1"
            onClick={() => revokeMutation.mutate()}
            disabled={revokeMutation.isPending}
          >
            Revoke All Tokens
          </Button>
        </div>
      )}
    </div>
  );
}
```

**Step 4: Generate route tree**

Run: `cd src/frontend && npx @tanstack/router-cli generate`
Expected: Route tree updated

**Step 5: Commit**

```bash
git add src/frontend/src/lib/queries/qr.ts src/frontend/src/routes/provisioning/
git commit -m "feat(frontend): add QR Generator page with user selection

- User search and selection list
- QR code generation with TanStack Query
- Regenerate and revoke actions
- Pre-selection via URL search param

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Phase 5: Docker Integration

### Task 22: Create Production Dockerfile for React App

**Files:**
- Create: `deploy/dev/Dockerfile.ui-react`
- Modify: `deploy/dev/docker-compose.yml`
- Create: `deploy/dev/nginx-react.conf`

**Step 1: Create Dockerfile.ui-react**

```dockerfile
# Build stage
FROM node:22-alpine AS builder
WORKDIR /app

# Copy package files
COPY src/frontend/package*.json ./
RUN npm ci

# Copy source
COPY src/frontend/ ./

# Build
RUN npm run build

# Production stage
FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY deploy/dev/nginx-react.conf /etc/nginx/conf.d/default.conf
EXPOSE 8001
CMD ["nginx", "-g", "daemon off;"]
```

**Step 2: Create nginx-react.conf**

```nginx
server {
    listen 8001;
    root /usr/share/nginx/html;
    index index.html;

    # SPA fallback
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Static assets with long cache
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # HTML files - no cache
    location ~* \.html$ {
        expires -1;
        add_header Cache-Control "no-store, no-cache, must-revalidate";
    }

    # Health check
    location /health {
        return 200 'ok';
        add_header Content-Type text/plain;
    }
}
```

**Step 3: Update docker-compose.yml to use new Dockerfile**

The docker-compose.yml already references `Dockerfile.ui`. To switch:
- Option A: Rename `Dockerfile.ui-react` to `Dockerfile.ui` (replaces old HTML UI)
- Option B: Create separate service for React UI

For now, we'll document the path forward but not modify docker-compose.yml yet.

**Step 4: Commit**

```bash
git add deploy/dev/Dockerfile.ui-react deploy/dev/nginx-react.conf
git commit -m "feat(deploy): add Docker config for React UI build

- Multi-stage Dockerfile with Node 22 builder
- Nginx production server with SPA fallback
- Asset caching headers
- Health check endpoint

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 23: Add UI Development Commands to Justfile

**Files:**
- Modify: `Justfile`

**Step 1: Add React UI commands to Justfile**

Add the following commands after the existing UI commands:

```just
# =============================================================================
# React UI Development
# =============================================================================

# Start React UI dev server (hot reload, proxies to API)
ui-dev:
    cd src/frontend && npm run dev

# Install React UI dependencies
ui-install:
    cd src/frontend && npm install

# Build React UI for production
ui-build:
    cd src/frontend && npm run build

# Add shadcn/ui component (e.g., just ui-add dialog)
ui-add component:
    cd src/frontend && npx shadcn@latest add {{component}}

# Lint React UI code
ui-lint:
    cd src/frontend && npm run lint

# Format React UI code
ui-format:
    cd src/frontend && npm run format

# Generate TanStack Router route tree
ui-routes:
    cd src/frontend && npx @tanstack/router-cli generate
```

**Step 2: Commit**

```bash
git add Justfile
git commit -m "feat(justfile): add React UI development commands

- ui-dev: Start dev server with hot reload
- ui-install: Install dependencies
- ui-build: Production build
- ui-add: Add shadcn components
- ui-lint/ui-format: Code quality
- ui-routes: Generate route tree

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 24: Create Environment Configuration

**Files:**
- Create: `src/frontend/.env.example`
- Create: `src/frontend/.gitignore`

**Step 1: Create .env.example**

```bash
# API Configuration
VITE_API_BASE=/api

# Feature flags
VITE_ENABLE_DEVTOOLS=true

# Auth (for future OIDC integration)
# VITE_OIDC_ISSUER=
# VITE_OIDC_CLIENT_ID=
```

**Step 2: Create .gitignore**

```gitignore
# Dependencies
node_modules/

# Build output
dist/

# Environment
.env
.env.local
.env.*.local

# Logs
*.log
npm-debug.log*

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Generated
src/routeTree.gen.ts
```

**Step 3: Commit**

```bash
git add src/frontend/.env.example src/frontend/.gitignore
git commit -m "feat(frontend): add environment config and gitignore

- .env.example with API base and feature flags
- .gitignore for node_modules, dist, env files

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Phase 6: Testing and Documentation

### Task 25: Create Basic E2E Test

**Files:**
- Create: `src/frontend/e2e/dashboard.spec.ts`
- Create: `src/frontend/playwright.config.ts`

**Step 1: Install Playwright**

Add to package.json devDependencies:
```json
"@playwright/test": "^1.48.0"
```

Run: `cd src/frontend && npm install`

**Step 2: Create playwright.config.ts**

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
  },
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});
```

**Step 3: Create dashboard.spec.ts**

```typescript
import { test, expect } from '@playwright/test';

test.describe('Dashboard', () => {
  test('should display dashboard heading', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
  });

  test('should display stats cards', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByText('Users')).toBeVisible();
    await expect(page.getByText('Groups')).toBeVisible();
  });

  test('should navigate to users page', async ({ page }) => {
    await page.goto('/');
    await page.click('text=Users');
    await expect(page).toHaveURL(/\/directory\/users/);
  });

  test('should open command palette with keyboard shortcut', async ({ page }) => {
    await page.goto('/');
    await page.keyboard.press('Meta+k');
    // Command palette would open - test placeholder for now
  });
});
```

**Step 4: Add test script to package.json**

Add to scripts:
```json
"test": "playwright test",
"test:ui": "playwright test --ui"
```

**Step 5: Commit**

```bash
git add src/frontend/playwright.config.ts src/frontend/e2e/ src/frontend/package.json
git commit -m "feat(frontend): add Playwright E2E test setup

- Configure Playwright with dev server integration
- Add dashboard smoke tests
- Navigation and keyboard shortcut tests

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

### Task 26: Update CLAUDE.md with Frontend Information

**Files:**
- Modify: `CLAUDE.md`

**Step 1: Add frontend section to CLAUDE.md**

Add after the existing "Hot Reload Rules" section:

```markdown
## Frontend Development (React UI)

The admin UI is being rebuilt with React 19. Source is in `src/frontend/`.

**Stack:** Vite 7, React 19, TanStack Router, TanStack Query, Zustand, shadcn/ui, Tailwind CSS 4

```bash
# Development
just ui-dev         # Start dev server at http://localhost:3000 (proxies /api)
just ui-add dialog  # Add shadcn component
just ui-routes      # Regenerate route tree

# Building
just ui-build       # Production build to dist/
```

**Key directories:**
- `src/frontend/src/routes/` - File-based routing (TanStack Router)
- `src/frontend/src/components/ui/` - shadcn/ui components
- `src/frontend/src/components/features/` - Domain components
- `src/frontend/src/lib/queries/` - TanStack Query hooks
- `src/frontend/src/stores/` - Zustand state stores
- `src/frontend/src/types/` - TypeScript types (from API contracts)

**Design docs:**
- `docs/plans/2025-01-25-enterprise-ui-redesign.md` - UI/UX design system
- `docs/plans/2025-01-25-react-tech-stack.md` - Tech stack decisions
- `docs/api/FRONTEND_API_CONTRACTS.md` - API types and endpoints
```

**Step 2: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: add frontend development section to CLAUDE.md

- React stack overview and commands
- Key directory structure
- Links to design documentation

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

---

## Summary

This implementation plan covers:

1. **Phase 1: Project Foundation** (Tasks 1-8)
   - Vite + React 19 project setup
   - Tailwind CSS with design tokens
   - shadcn/ui configuration
   - TypeScript types from API contracts
   - API client with error handling
   - Zustand stores
   - TanStack Query setup
   - App entry point and routing

2. **Phase 2: App Shell Components** (Tasks 9-13)
   - Header with search trigger
   - Collapsible sidebar navigation
   - Breadcrumb with route hook
   - Keyboard shortcuts (⌘K, ⌘B)

3. **Phase 3: Core Feature Components** (Tasks 14-17)
   - Stat cards for dashboard
   - Health status display
   - User table with skeleton
   - QR code display

4. **Phase 4: Route Pages** (Tasks 18-21)
   - Dashboard with stats and health
   - Users list with search
   - User detail with groups
   - QR Generator with user selection

5. **Phase 5: Docker Integration** (Tasks 22-24)
   - Production Dockerfile
   - Nginx configuration
   - Justfile commands
   - Environment configuration

6. **Phase 6: Testing and Documentation** (Tasks 25-26)
   - Playwright E2E tests
   - CLAUDE.md updates

---

**Plan complete and saved to `docs/plans/2025-01-25-react-ui-implementation.md`.**

**Two execution options:**

1. **Subagent-Driven (this session)** - I dispatch fresh subagent per task, review between tasks, fast iteration

2. **Parallel Session (separate)** - Open new session with executing-plans, batch execution with checkpoints

**Which approach?**
