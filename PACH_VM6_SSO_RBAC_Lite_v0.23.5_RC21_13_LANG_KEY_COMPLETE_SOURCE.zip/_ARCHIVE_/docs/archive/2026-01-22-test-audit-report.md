# Backend API Test Audit Report

> **Date:** 2026-01-22 (updated 2026-01-23)
> **Spec:** specs/v1.0/SPEC.md (v2.0 production-ready)
> **Test Suite:** tests/ (pytest + httpx integration tests)

---

## 1. Execution Results

**Run:** `pytest tests/ -v` (2026-01-23)
**Result:** 66 passed, 1 skipped, 0 failed (8.26s)

| Test File | Tests | Pass | Skip | Coverage |
|-----------|-------|------|------|----------|
| `test_bootstrap.py` | 4 | 4 | 0 | 100% |
| `test_health.py` | 3 | 3 | 0 | 100% |
| `test_org_groups.py` | 10 | 10 | 0 | 100% |
| `test_orgprofiles.py` | 8 | 8 | 0 | 100% |
| `test_provisioning.py` | 5 | 5 | 0 | 100% |
| `test_qr_format.py` | 10 | 10 | 0 | 100% |
| `test_qr_signing.py` | 8 | 8 | 0 | 100% |
| `test_security.py` | 9 | 8 | 1 | 100% |
| `test_users.py` | 10 | 10 | 0 | 100% |

**Skipped:** `test_default_rate_limit_100_per_minute` — health endpoints exempt by design (load balancer probes).

### Key Findings

1. **Rate Limiting Works:** Bootstrap 5/hour and QR 10/min both enforced correctly
2. **Token Atomicity Confirmed:** Single-use enforcement via atomic UPDATE prevents race conditions
3. **Termination Flow Complete:** LDAP disable + token revoke + audit record all verified end-to-end
4. **Expired/Invalid Tokens Rejected:** 410 for expired, 404 for not found, 409 for consumed
5. **Health Checks Reliable:** Both liveness and deep health check pass, deep validates all 3 deps

---

## 2. Spec Coverage Gap Matrix

| Spec § | Requirement | Status | Evidence |
|--------|-------------|--------|----------|
| 0.1 | QR HMAC-SHA256 signing | ✅ TESTED | test_qr_signing.py (8 tests) |
| 0.1 | Tampered payload rejected | ✅ TESTED | test_qr_signing.py:tampered |
| 0.1 | Payload expiry check | ❌ NOT TESTED | QR-level exp not in current impl |
| 0.1 | Nonce uniqueness | ✅ TESTED | test_qr_signing.py:nonce (iat) |
| 0.2 | Token single-use | ✅ TESTED | test_provisioning.py:12 |
| 0.2 | Expired token rejected | ✅ TESTED | test_provisioning.py:44 |
| 0.2 | Consumed token rejected | ✅ TESTED | test_provisioning.py:12 |
| 0.3 | Bootstrap 5/hour | ✅ TESTED | test_security.py:9 |
| 0.3 | User create 20/min | ✅ TESTED | test_security.py:rate_limit |
| 0.3 | QR 10/min | ✅ TESTED | test_provisioning.py:84 |
| 0.3 | Auth failure 5/5min | ❌ NOT TESTED | |
| 0.3 | Default 100/min | ⏭️ SKIPPED | Health exempt; needs non-exempt endpoint |
| 0.3 | 429 response format | ✅ TESTED | test_security.py:47 |
| 5.1 | Unified QR schema v2 | ✅ TESTED | test_qr_format.py (4 tests) |
| 5.1 | QR contains UC block | ✅ TESTED | test_qr_format.py:xmpp,sip |
| 5.1 | QR contains SSO when enabled | ✅ TESTED | test_qr_format.py:qr2_absent |
| 5.3 | Unified endpoint | ✅ TESTED | test_qr_format.py:response_structure |
| 5.3 | Split mode endpoint | ✅ TESTED | test_qr_format.py (6 tests) |
| 6.1 | Provisioning end-to-end | ⚠️ PARTIAL | Token validation, not full QR→scan |
| 6.2 | Terminate → LDAP disable | ✅ TESTED | test_security.py:69 |
| 6.2 | Terminate → token revoke | ✅ TESTED | test_security.py:94 |
| 6.2 | Terminate → audit event | ✅ TESTED | test_security.py:131 |
| 6.2 | Terminate response JSON | ✅ TESTED | test_security.py:response_shape |
| 10.1 | GET /api/health | ✅ TESTED | test_health.py:9 |
| 10.1 | GET /api/health/deep | ✅ TESTED | test_health.py:16 |
| 10.1 | GET /api/tenant | ✅ TESTED | test_bootstrap.py:tenant |
| 10.1 | POST /api/bootstrap success | ✅ TESTED | test_bootstrap.py (3 tests) |
| 10.2 | Org CRUD (4 endpoints) | ✅ TESTED | test_org_groups.py (5 tests) |
| 10.3 | User CRUD (8 endpoints) | ✅ TESTED | test_users.py (10 tests) |
| 10.4 | Group CRUD (5 endpoints) | ✅ TESTED | test_org_groups.py (5 tests) |
| 10.5 | QR revoke | ❌ NOT TESTED | |
| 10.6 | OrgProfile CRUD (6 endpoints) | ✅ TESTED | test_orgprofiles.py (8 tests) |
| 12 | Break-glass bypass | ❌ NOT TESTED | |

**Coverage (initial audit): 10/36 requirements tested (28%)**

**Coverage (after expansion): 28/36 requirements tested (78%)**

---

## 3. Prioritized Test Backlog

### Tier 1: CRITICAL — Security & Compliance

#### 1.1 QR Payload Signing (Spec §0.1)

**Why critical:** Entire provisioning security chain depends on payload integrity.

**Test cases:**

```python
class TestQRPayloadSigning:
    def test_qr_response_contains_signature(self, client, created_users):
        """QR output must include 'sig' field."""
        uid = create_user(...)
        resp = client.get(f"/api/users/{uid}/qrcode")
        data = resp.json()
        assert "sig" in data

    def test_qr_signature_valid_hmac(self, client, created_users):
        """Signature must be valid HMAC-SHA256 of canonical payload."""
        uid = create_user(...)
        resp = client.get(f"/api/users/{uid}/qrcode")
        data = resp.json()
        sig = data.pop("sig")
        message = json.dumps(data, sort_keys=True, separators=(',', ':'))
        expected = hmac.new(SECRET.encode(), message.encode(), hashlib.sha256).hexdigest()
        assert hmac.compare_digest(sig, expected)

    def test_qr_tampered_payload_rejected_on_verify(self):
        """Tampered payload fails signature verification."""
        # Generate valid QR, modify payload, verify fails

    def test_qr_nonce_unique_across_issuances(self, client, created_users):
        """Each QR issuance has unique nonce."""
        uid = create_user(...)
        nonces = set()
        for _ in range(5):
            resp = client.get(f"/api/users/{uid}/qrcode")
            nonces.add(resp.json()["nonce"])
        assert len(nonces) == 5
```

#### 1.2 User Create Rate Limit (Spec §0.3)

```python
def test_user_create_rate_limit_20_per_minute(self, client, created_users):
    """User creation limited to 20/minute."""
    for i in range(20):
        resp = client.post("/api/users/create", json={...})
        assert resp.status_code != 429
    resp = client.post("/api/users/create", json={...})
    assert resp.status_code == 429
```

#### 1.3 Auth Failure Rate Limit (Spec §0.3)

```python
def test_auth_failure_lockout_5_per_5_minutes(self, client):
    """5 auth failures in 5 min triggers 429."""
    # Requires REQUIRE_OIDC_AUTH=true or LDAP bind endpoint
    # May need to test via invalid OIDC token on protected endpoint
```

#### 1.4 Termination Response Shape (Spec §6.2)

```python
def test_terminate_response_shape(self, client, created_users):
    """Response matches spec JSON structure."""
    uid = create_user(...)
    resp = client.post(f"/api/users/{uid}/terminate", json={"reason": "test"})
    data = resp.json()
    assert data["status"] == "terminated"
    assert data["user_uid"] == uid
    assert "actions" in data
    actions = data["actions"]
    assert "ldap_disabled" in actions
    assert "tokens_revoked" in actions
```

---

### Tier 2: HIGH — Core Functionality

#### 2.1 QR Output Format (Spec §5.1, §5.3)

```python
class TestQROutputFormat:
    def test_qr_unified_schema(self, client, created_users):
        """QR uses schema 'azblink.provisioning.v2'."""
        resp = client.get(f"/api/users/{uid}/qrcode")
        data = resp.json()
        assert data["schema"] == "azblink.provisioning.v2"

    def test_qr_contains_uc_block(self, client, created_users):
        """QR always contains uc.xmpp and uc.sip config."""
        data = client.get(f"/api/users/{uid}/qrcode").json()
        assert "uc" in data["payload"]
        assert "xmpp" in data["payload"]["uc"]
        assert "sip" in data["payload"]["uc"]

    def test_qr_sso_null_when_not_configured(self, client, created_users):
        """SSO block is null when org has no SSO profile."""
        data = client.get(f"/api/users/{uid}/qrcode").json()
        assert data["payload"]["sso"] is None

    def test_qr_split_mode_returns_two_codes(self, client, created_users):
        """mode=split returns legacy format with separate QR codes."""
        resp = client.get(f"/api/users/{uid}/qrcode?mode=split")
        # Validate split response structure
```

#### 2.2 Bootstrap Success Path (Spec §10.1)

```python
class TestBootstrap:
    def test_bootstrap_creates_base_ous(self, client, ldap_conn):
        """Bootstrap creates ou=people and ou=groups."""
        resp = client.post("/api/bootstrap", json={
            "tenant": "bootstrap_test",
            "admin_email": "admin@test.com"
        })
        assert resp.status_code == 200
        # Verify OUs exist in LDAP

    def test_bootstrap_idempotent(self, client):
        """Calling bootstrap twice doesn't error."""
        # Second call should succeed or return appropriate status
```

#### 2.3 OrgProfile CRUD (Spec §10.6)

```python
class TestOrgProfileCRUD:
    def test_create_orgprofile(self, client, db_conn):
        """Create org profile with required fields."""
    def test_list_orgprofiles(self, client):
        """List returns all profiles."""
    def test_get_orgprofile_by_id(self, client):
        """Get specific profile by ID."""
    def test_delete_orgprofile(self, client, db_conn):
        """Delete removes profile."""
    def test_rotate_qr_key(self, client):
        """Rotate updates nonce/key, old QRs invalid."""
```

#### 2.4 User CRUD Happy Paths (Spec §10.3)

```python
class TestUserCRUD:
    def test_create_user_returns_dn(self, client, created_users):
        """Successful creation returns user DN."""
    def test_get_user_by_uid(self, client, seed_user_uid):
        """Get existing user returns profile."""
    def test_list_users(self, client):
        """List users returns array with pagination."""
    def test_reset_password(self, client, created_users):
        """Password reset allows new login."""
```

---

### Tier 3: MEDIUM — Operational

#### 3.1 Org CRUD (Spec §10.2)

```python
class TestOrgCRUD:
    def test_org_tree(self, client):
    def test_create_org(self, client, ldap_conn):
    def test_rename_org(self, client, ldap_conn):
    def test_delete_empty_org(self, client, ldap_conn):
    def test_delete_org_with_users_fails(self, client):
```

#### 3.2 Group CRUD (Spec §10.4)

```python
class TestGroupCRUD:
    def test_create_group(self, client, ldap_conn):
    def test_add_member_to_group(self, client):
    def test_remove_member_from_group(self, client):
    def test_list_groups(self, client):
    def test_list_group_members(self, client):
```

#### 3.3 Default Rate Limit (Spec §0.3)

```python
def test_default_rate_limit_on_users_list(self, client):
    """Users endpoint uses default 100/min limit."""
    for i in range(100):
        resp = client.get("/api/users")
        assert resp.status_code != 429
    resp = client.get("/api/users")
    assert resp.status_code == 429
```

#### 3.4 CSV Import (Spec §10.3)

```python
class TestCSVImport:
    def test_import_valid_csv(self, client, created_users):
    def test_import_csv_with_invalid_rows(self, client):
    def test_import_csv_duplicate_uid_handling(self, client):
```

---

### Tier 4: LOW — Edge Cases & Advanced

#### 4.1 Break-Glass (Spec §12)

```python
class TestBreakGlass:
    def test_breakglass_bypasses_auth_when_enabled(self):
        """With valid breakglass.json, protected endpoints accessible."""
    def test_breakglass_expired_not_honored(self):
        """Expired breakglass file doesn't grant access."""
    def test_breakglass_mode_bootstrap_only(self):
        """bootstrap_only mode only bypasses bootstrap/tenant."""
```

Note: These tests require write access to `/etc/azblink/directory/breakglass.json` inside the container.

#### 4.2 User Suspend/Unsuspend (Spec §6.3)

```python
class TestUserSuspension:
    def test_suspend_blocks_login(self):
    def test_unsuspend_restores_login(self):
```

Note: These endpoints may not be implemented yet. Test should confirm 404/501 if absent.

#### 4.3 QR Token Revocation (Spec §10.5)

```python
def test_revoke_active_qr_tokens(self, client, db_conn, created_users):
    """POST /api/users/{uid}/qrcode/revoke marks tokens revoked."""
```

---

## 4. Recommended Next Sprint

**Implement Tier 1 first (4 items, ~12 test cases):** These are security requirements with zero coverage. QR signing is the single biggest gap — the entire mobile provisioning security model depends on it being correctly implemented and tested.

**Then Tier 2 (4 items, ~16 test cases):** These validate the core user-facing functionality. QR output format testing is especially important since mobile clients parse this directly.

**Estimated new test count:** +28 tests → total 42 tests (from 14 today)

---

## 5. Test Infrastructure Notes

**Current strengths:**
- Real integration tests (no mocks) against Docker stack
- Clean fixture pattern with auto-cleanup
- Redis flush between tests prevents rate limit bleed
- Direct DB access for assertions and setup

**Gaps to address:**
- No OIDC testing (auth mode is `REQUIRE_OIDC_AUTH=false`)
- No container-level testing (breakglass needs file writes inside container)
- LDAP cleanup silently fails if user doesn't exist (no error handling in teardown)
- QR signing secret not accessible from test — need env var or config fixture
