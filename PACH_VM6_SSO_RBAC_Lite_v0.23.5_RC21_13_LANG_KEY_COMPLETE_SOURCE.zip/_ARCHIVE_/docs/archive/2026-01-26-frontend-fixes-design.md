# Frontend UI Fixes Design

**Date:** 2026-01-26
**Status:** Ready for Implementation
**Scope:** 6 issues across header, sidebar, and missing routes

---

## 1. Issues Addressed

| # | Issue | Description |
|---|-------|-------------|
| 1 | Header alignment | Search bar not centered; right buttons not grouped |
| 2 | Sidebar collapse animation | Section titles disappear jarringly; no tooltips on collapsed items |
| 3 | Missing `/directory/groups` | Route not implemented |
| 4 | Missing `/directory/orgs` | Route not implemented |
| 5 | Missing `/provisioning/tokens` | Route not implemented |
| 6 | Missing `/my-profile` | Route not implemented |
| 7 | Missing `/settings` | Route not implemented |

---

## 2. Header Layout Fix

**Problem:** `flex-1` on search pushes it left instead of centering.

**Solution:** Use absolute positioning for true center alignment.

```
┌─────────────────────────────────────────────────────────────────────┐
│ [☰] [AZ] AZBlink    │    [🔍 Search anything... ⌘K]    │  [🔔][?][👤▾] │
│      LEFT           │           CENTER                 │     RIGHT     │
│   (flex-shrink-0)   │  (absolute left-1/2 -translate)  │   (ml-auto)   │
└─────────────────────────────────────────────────────────────────────┘
```

**Implementation:**
- Left section: `flex items-center gap-4 flex-shrink-0`
- Center section: `absolute left-1/2 -translate-x-1/2` (md+ screens)
- Right section: `flex items-center gap-2 ml-auto flex-shrink-0`

---

## 3. Sidebar Collapse Improvements

### 3.1 Section Dividers

Replace text labels with horizontal lines when collapsed:

```
Expanded:           Collapsed:
┌──────────────┐    ┌────┐
│ DIRECTORY    │    │────│  ← subtle line
│ 👤 Users     │    │ 👤 │
│ 👥 Groups    │    │ 👥 │
│ 🏢 Orgs      │    │ 🏢 │
│              │    │    │
│ PROVISIONING │    │────│
│ 📱 QR Gen    │    │ 📱 │
└──────────────┘    └────┘
```

**Implementation:**
```tsx
{sidebarCollapsed ? (
  <div className="mx-3 my-4 border-t border-slate-200" />
) : (
  <h3 className="px-4 mb-2 text-xs font-medium uppercase">{section.label}</h3>
)}
```

### 3.2 Tooltips on Collapsed Items

- Custom tooltip component (not native `title` attribute)
- Positioned to the right of nav item (`left-full ml-2`)
- Z-index: `z-50` (above header z-30, sidebar z-20)

**Z-index stack:**
```
z-50: Tooltips
z-40: Dropdowns
z-30: Header
z-20: Sidebar
z-10: Breadcrumb
```

---

## 4. Missing Routes

### 4.1 File Structure

```
src/frontend/src/routes/
├── directory/
│   ├── groups/
│   │   └── index.tsx        ← NEW
│   └── orgs/
│       └── index.tsx        ← NEW
├── provisioning/
│   └── tokens.tsx           ← NEW
├── my-profile.tsx           ← NEW
└── settings.tsx             ← NEW
```

### 4.2 Query Hooks

```
src/frontend/src/lib/queries/
├── groups.ts                ← NEW (GET /api/groups)
├── orgs.ts                  ← NEW (GET /api/org/tree)
└── audit.ts                 ← NEW (GET /api/audit/qr_issuance)
```

---

## 5. Page Designs

### 5.1 `/directory/groups`

**API:** `GET /api/groups`

**Layout:**
- Header: "Groups" title + "Create Group" button
- Search input
- Table: Name, Members count, Description, Actions

**Empty state:**
- Icon: 👥
- Message: "No groups yet"
- Subtext: "Create groups to organize users by role or team"
- CTA: "Create your first group"

### 5.2 `/directory/orgs`

**API:** `GET /api/org/tree`

**Layout:**
- Header: "Organizations" title + "Create Org Unit" button
- Tree view showing hierarchy with expand/collapse
- Each node shows: name, user count, actions menu

**Empty state:**
- Icon: 🏢
- Message: "No organizations yet"
- Subtext: "Organizations help structure your directory"
- CTA: "Create your first organization"

### 5.3 `/provisioning/tokens`

**API:** `GET /api/audit/qr_issuance`

**Layout:**
- Header: "Provisioning Tokens" + Export/Refresh buttons
- Filters: Search, Type dropdown, Status dropdown, Date range
- Table: Token (truncated), User, Type (QR#1/QR#2), Created, Status, Actions

**Status badges:**
- 🟢 Used (emerald)
- 🟡 Active (amber)
- 🔴 Expired/Revoked (red)

**Empty state:**
- Icon: 🎟️
- Message: "No tokens issued yet"
- Subtext: "Tokens are created when you generate QR codes"
- CTA: "Go to QR Generator"

### 5.4 `/my-profile`

**API:** `GET /api/users/{uid}` (current user from auth context)

**Layout:**
- Header with avatar, name, email, org, role
- Account Details section: UID, Email, Phone, Organization, Member since
- Groups section: Badge list of group memberships

**No auth fallback:** Show demo data with banner indicating demo mode.

### 5.5 `/settings`

**API:** `GET /api/health/deep`

**Layout:**
- System Status card: LDAP, PostgreSQL, Authentik connection status
- Authentication section: OIDC Required, Bootstrap Allowed
- API Configuration: Base URL, Version

**Read-only display** - configuration changes require environment updates.

---

## 6. Shared Components

### 6.1 Tooltip Component

**File:** `components/ui/tooltip.tsx`

```tsx
interface TooltipProps {
  content: string;
  children: React.ReactNode;
  side?: 'top' | 'right' | 'bottom' | 'left';
}
```

### 6.2 Empty State Component

**File:** `components/features/empty-state.tsx`

```tsx
interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  action?: {
    label: string;
    href?: string;
    onClick?: () => void;
  };
}
```

---

## 7. Implementation Order

1. **Tooltip component** - Needed by sidebar
2. **Header fix** - Layout correction
3. **Sidebar improvements** - Dividers + tooltips
4. **Empty state component** - Needed by all new pages
5. **Query hooks** - groups, orgs, audit
6. **New route pages** - Can be parallelized
7. **Route regeneration** - `just ui-routes`

---

## 8. Testing Checklist

- [ ] Header: Search visually centered on desktop
- [ ] Header: Right buttons grouped and aligned right
- [ ] Sidebar: Divider lines appear when collapsed
- [ ] Sidebar: Tooltips appear on hover when collapsed
- [ ] Sidebar: Tooltips render above header (z-index)
- [ ] Groups page: Loads data from API
- [ ] Groups page: Shows empty state when no data
- [ ] Orgs page: Loads tree from API
- [ ] Orgs page: Shows empty state when no data
- [ ] Tokens page: Loads audit data
- [ ] Tokens page: Shows empty state when no data
- [ ] Profile page: Shows current user or demo fallback
- [ ] Settings page: Shows system status from health API
