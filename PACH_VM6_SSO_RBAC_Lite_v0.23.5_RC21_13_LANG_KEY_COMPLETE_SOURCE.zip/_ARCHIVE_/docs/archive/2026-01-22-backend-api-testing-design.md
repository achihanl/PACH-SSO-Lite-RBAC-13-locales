# Backend API Testing Design

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Comprehensive integration test suite for `src/backend/` API with focus on security-critical paths.

**Architecture:** pytest + httpx tests run outside Docker, hitting the real API stack (Postgres, Redis, OpenLDAP). No mocks. Tests use seed data and clean up after themselves.

**Tech Stack:** pytest, httpx, psycopg2, python-ldap, redis

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     pytest test suite                        │
│  tests/                                                      │
│    conftest.py          (fixtures: client, db, cleanup)     │
│    test_security.py     (auth, rate limits, termination)    │
│    test_provisioning.py (QR flow, token validation)         │
│    test_crud.py         (users, orgs, groups - later)       │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ HTTP via httpx
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   Docker Compose Stack                       │
│  ┌─────────────┐  ┌──────────┐  ┌───────┐  ┌──────────┐    │
│  │ directory-api│  │ postgres │  │ redis │  │ openldap │    │
│  │  :8081/api  │  │  :5433   │  │ :6380 │  │  :1390   │    │
│  └─────────────┘  └──────────┘  └───────┘  └──────────┘    │
└─────────────────────────────────────────────────────────────┘
```

**Key points:**
- Tests run *outside* Docker, hitting the API at `localhost:8081`
- No mocks - real LDAP binds, real Postgres queries, real Redis rate limits
- Tests use the same stack as local development (`just up`)
- Direct DB/LDAP access in fixtures for setup/cleanup only (not for assertions)

---

## Test File Organization

```
tests/
├── conftest.py           # Shared fixtures
├── test_security.py      # P0: Auth, rate limits, termination
├── test_provisioning.py  # P0: QR generation, token validation
├── test_health.py        # Health endpoints (quick smoke tests)
└── test_crud.py          # P1: Users, orgs, groups CRUD (later)
```

---

## Core Fixtures (conftest.py)

```python
import os
import pytest
import httpx
import psycopg2
import ldap
import redis

# Seed data constants
SEED_USER_UID = "jsmith"
SEED_ORG_DN = "ou=Engineering,ou=org,dc=azblink,dc=com"
SEED_ADMIN_DN = "cn=admin,dc=azblink,dc=com"
LDAP_BASE_DN = "dc=azblink,dc=com"

@pytest.fixture(scope="session")
def api_base_url():
    """Base URL for the running API."""
    return os.getenv("API_URL", "http://localhost:8081")

@pytest.fixture
def client(api_base_url):
    """HTTP client for API calls."""
    with httpx.Client(base_url=api_base_url, timeout=30) as c:
        yield c

@pytest.fixture(scope="session")
def db_conn():
    """Direct Postgres connection for setup/cleanup."""
    conn = psycopg2.connect(
        host="localhost",
        port=5433,
        database="azblink_directory",
        user="azblink_directory",
        password="azblink_directory",
    )
    conn.autocommit = True
    yield conn
    conn.close()

@pytest.fixture(scope="session")
def ldap_conn():
    """Direct LDAP connection for setup/cleanup."""
    conn = ldap.initialize("ldap://localhost:1390")
    conn.simple_bind_s("cn=admin,dc=azblink,dc=com", "adminpassword")
    yield conn
    conn.unbind_s()

@pytest.fixture(scope="session")
def redis_conn():
    """Redis connection for rate limit management."""
    r = redis.Redis(host="localhost", port=6380, db=0)
    yield r
    r.close()

@pytest.fixture
def seed_user_uid():
    """UID of a user that exists in seed data."""
    return SEED_USER_UID

@pytest.fixture
def created_users(client, db_conn, ldap_conn):
    """Track and cleanup users created during tests."""
    created = []
    yield created

    # Teardown: clean up in reverse order
    for uid in reversed(created):
        # Delete from LDAP
        try:
            ldap_conn.delete_s(f"uid={uid},ou=people,{LDAP_BASE_DN}")
        except ldap.NO_SUCH_OBJECT:
            pass
        # Delete tokens from DB
        with db_conn.cursor() as cur:
            cur.execute("DELETE FROM provision_tokens WHERE uid = %s", (uid,))
            cur.execute("DELETE FROM qr_issuance_audit WHERE user_uid = %s", (uid,))
            cur.execute("DELETE FROM termination_events WHERE user_uid = %s", (uid,))

@pytest.fixture(autouse=True)
def clear_rate_limits(redis_conn):
    """Clear rate limit counters before each test."""
    yield
    redis_conn.flushdb()
```

---

## Security-Critical Test Cases (Priority)

### test_security.py - Rate Limiting

```python
import pytest
import httpx

class TestRateLimiting:
    """Spec Section 0.3: Rate limiting requirements."""

    def test_bootstrap_rate_limit_5_per_hour(self, client):
        """Bootstrap endpoint limited to 5/hour."""
        for i in range(5):
            resp = client.post("/api/bootstrap", json={
                "tenant": "test",
                "admin_email": f"admin{i}@test.com"
            })
            # May succeed or fail validation, but not rate limited
            assert resp.status_code in (200, 400, 422)

        # 6th request should be rate limited
        resp = client.post("/api/bootstrap", json={
            "tenant": "test",
            "admin_email": "admin6@test.com"
        })
        assert resp.status_code == 429
        assert resp.json()["error"] == "rate_limit_exceeded"

    def test_qr_endpoint_rate_limit_10_per_minute(self, client, seed_user_uid):
        """QR endpoints limited to 10/minute."""
        for i in range(10):
            resp = client.get(f"/api/users/{seed_user_uid}/qrcode")
            assert resp.status_code in (200, 404)

        # 11th request should be rate limited
        resp = client.get(f"/api/users/{seed_user_uid}/qrcode")
        assert resp.status_code == 429

    def test_user_create_rate_limit_20_per_minute(self, client, created_users):
        """User creation limited to 20/minute."""
        for i in range(20):
            resp = client.post("/api/users/create", json={
                "uid": f"ratelimit_test_{i}",
                "cn": f"Rate Limit Test {i}",
                "sn": "Test",
                "mail": f"ratelimit{i}@test.com",
                "userPassword": "testpass123",
                "org_dn": "ou=org,dc=azblink,dc=com"
            })
            if resp.status_code == 200:
                created_users.append(f"ratelimit_test_{i}")

        # 21st request should be rate limited
        resp = client.post("/api/users/create", json={
            "uid": "ratelimit_test_21",
            "cn": "Rate Limit Test 21",
            "sn": "Test",
            "mail": "ratelimit21@test.com",
            "userPassword": "testpass123",
            "org_dn": "ou=org,dc=azblink,dc=com"
        })
        assert resp.status_code == 429
```

### test_security.py - User Termination

```python
class TestUserTermination:
    """User termination flow - disables access and revokes tokens."""

    def test_terminate_disables_ldap_account(self, client, created_users, ldap_conn):
        """Termination must disable LDAP account."""
        # Create test user
        uid = "terminate_test_1"
        password = "testpass123"
        resp = client.post("/api/users/create", json={
            "uid": uid,
            "cn": "Terminate Test",
            "sn": "Test",
            "mail": "terminate@test.com",
            "userPassword": password,
            "org_dn": "ou=org,dc=azblink,dc=com"
        })
        assert resp.status_code == 200
        created_users.append(uid)

        # Verify LDAP bind works before termination
        test_conn = ldap.initialize("ldap://localhost:1390")
        test_conn.simple_bind_s(f"uid={uid},ou=people,dc=azblink,dc=com", password)
        test_conn.unbind_s()

        # Terminate
        resp = client.post(f"/api/users/{uid}/terminate", json={
            "terminated_by": "admin@test.com",
            "reason": "test_termination"
        })
        assert resp.status_code == 200

        # Verify LDAP bind fails (account disabled)
        test_conn = ldap.initialize("ldap://localhost:1390")
        with pytest.raises(ldap.INVALID_CREDENTIALS):
            test_conn.simple_bind_s(f"uid={uid},ou=people,dc=azblink,dc=com", password)

    def test_terminate_revokes_active_tokens(self, client, db_conn, created_users):
        """Termination must revoke all active provision tokens."""
        # Create test user
        uid = "terminate_test_2"
        resp = client.post("/api/users/create", json={
            "uid": uid,
            "cn": "Terminate Test 2",
            "sn": "Test",
            "mail": "terminate2@test.com",
            "userPassword": "testpass123",
            "org_dn": "ou=org,dc=azblink,dc=com"
        })
        assert resp.status_code == 200
        created_users.append(uid)

        # Generate QR (creates token)
        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200

        # Verify token exists and is active
        with db_conn.cursor() as cur:
            cur.execute(
                "SELECT status FROM provision_tokens WHERE uid = %s",
                (uid,)
            )
            row = cur.fetchone()
            assert row is not None
            assert row[0] == "active"

        # Terminate
        resp = client.post(f"/api/users/{uid}/terminate", json={
            "terminated_by": "admin@test.com",
            "reason": "test_termination"
        })
        assert resp.status_code == 200

        # Verify token is revoked
        with db_conn.cursor() as cur:
            cur.execute(
                "SELECT status FROM provision_tokens WHERE uid = %s",
                (uid,)
            )
            row = cur.fetchone()
            assert row[0] == "revoked_terminated"

    def test_terminate_records_audit_event(self, client, db_conn, created_users):
        """Termination must create audit record."""
        uid = "terminate_test_3"
        resp = client.post("/api/users/create", json={
            "uid": uid,
            "cn": "Terminate Test 3",
            "sn": "Test",
            "mail": "terminate3@test.com",
            "userPassword": "testpass123",
            "org_dn": "ou=org,dc=azblink,dc=com"
        })
        assert resp.status_code == 200
        created_users.append(uid)

        # Terminate
        resp = client.post(f"/api/users/{uid}/terminate", json={
            "terminated_by": "admin@test.com",
            "reason": "policy_violation"
        })
        assert resp.status_code == 200

        # Verify audit record
        with db_conn.cursor() as cur:
            cur.execute(
                "SELECT terminated_by, reason FROM termination_events WHERE user_uid = %s",
                (uid,)
            )
            row = cur.fetchone()
            assert row is not None
            assert row[0] == "admin@test.com"
            assert row[1] == "policy_violation"
```

---

### test_provisioning.py - Token Validation

```python
import pytest
import httpx

class TestTokenValidation:
    """QR provisioning token validation."""

    def test_token_single_use_atomic(self, client, created_users):
        """Token can only be consumed once (atomic operation)."""
        uid = "provision_test_1"
        resp = client.post("/api/users/create", json={
            "uid": uid,
            "cn": "Provision Test",
            "sn": "Test",
            "mail": "provision@test.com",
            "userPassword": "testpass123",
            "org_dn": "ou=org,dc=azblink,dc=com"
        })
        assert resp.status_code == 200
        created_users.append(uid)

        # Get QR data with token
        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200
        qr_data = resp.json()
        token = qr_data.get("provisionToken") or qr_data.get("provision_token")
        assert token is not None

        # First consumption succeeds
        resp = client.post("/api/provision/validate", json={"token": token})
        assert resp.status_code == 200

        # Second consumption fails
        resp = client.post("/api/provision/validate", json={"token": token})
        assert resp.status_code == 400
        assert "ALREADY_CONSUMED" in resp.json().get("error", "")

    def test_expired_token_rejected(self, client, db_conn, created_users):
        """Expired tokens are rejected."""
        uid = "provision_test_2"
        resp = client.post("/api/users/create", json={
            "uid": uid,
            "cn": "Provision Test 2",
            "sn": "Test",
            "mail": "provision2@test.com",
            "userPassword": "testpass123",
            "org_dn": "ou=org,dc=azblink,dc=com"
        })
        assert resp.status_code == 200
        created_users.append(uid)

        # Get QR data
        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200
        qr_data = resp.json()
        token = qr_data.get("provisionToken") or qr_data.get("provision_token")

        # Manually expire the token in DB
        import hashlib
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with db_conn.cursor() as cur:
            cur.execute(
                "UPDATE provision_tokens SET expires_at = NOW() - INTERVAL '1 hour' WHERE token_hash = %s",
                (token_hash,)
            )

        # Attempt validation - should fail
        resp = client.post("/api/provision/validate", json={"token": token})
        assert resp.status_code == 400
        assert "EXPIRED" in resp.json().get("error", "")

    def test_invalid_token_rejected(self, client):
        """Invalid tokens are rejected."""
        resp = client.post("/api/provision/validate", json={
            "token": "invalid_token_that_does_not_exist"
        })
        assert resp.status_code == 400
        assert "NOT_FOUND" in resp.json().get("error", "")
```

---

### test_health.py - Health Endpoints

```python
class TestHealthEndpoints:
    """Health check endpoints for load balancers."""

    def test_liveness_check(self, client):
        """Basic liveness probe."""
        resp = client.get("/api/health")
        assert resp.status_code == 200
        assert resp.json()["ok"] is True

    def test_deep_health_check(self, client):
        """Deep health check verifies all dependencies."""
        resp = client.get("/api/health/deep")
        # Should be 200 when healthy, 503 when degraded
        assert resp.status_code in (200, 503)
        data = resp.json()
        assert "checks" in data
        assert "postgres" in data["checks"]
        assert "redis" in data["checks"]
        assert "ldap" in data["checks"]
```

---

## CI Integration

### Justfile additions

```makefile
# Run tests (ensures stack is up)
test:
    #!/usr/bin/env bash
    cd deploy/dev
    if ! docker compose ps --status running | grep -q "azblink-directory-api"; then
        echo "Starting stack..."
        docker compose up -d --wait
    fi
    cd ../..
    pytest tests/ -v --tb=short

# Fast test run (assumes stack is already up)
test-quick:
    pytest tests/ -v --tb=short

# Run specific test file
test-security:
    pytest tests/test_security.py -v

test-provisioning:
    pytest tests/test_provisioning.py -v

# Run with coverage
test-cov:
    pytest tests/ -v --cov=src/backend --cov-report=term-missing
```

### GitHub Actions workflow

```yaml
# .github/workflows/test.yml
name: Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Install test dependencies
        run: pip install pytest httpx psycopg2-binary python-ldap redis

      - name: Start services
        run: |
          cd deploy/dev
          docker compose up -d --wait

      - name: Run tests
        run: just test-quick

      - name: Stop services
        if: always()
        run: cd deploy/dev && docker compose down
```

---

## Test Dependencies

Add to project root or `tests/requirements.txt`:

```
pytest>=8.0
httpx>=0.27
psycopg2-binary>=2.9
python-ldap>=3.4
redis>=5.0
pytest-cov>=4.0
```

---

## Implementation Priority

1. **P0 - Security tests** (`test_security.py`)
   - Rate limiting
   - User termination flow

2. **P0 - Provisioning tests** (`test_provisioning.py`)
   - Token validation
   - Single-use enforcement

3. **P1 - Health tests** (`test_health.py`)
   - Liveness/readiness probes

4. **P2 - CRUD tests** (`test_crud.py`)
   - Users, orgs, groups
   - To be implemented later
