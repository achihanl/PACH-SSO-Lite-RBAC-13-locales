# Repo Reorganization Plan: Spec-Driven Development

**Date:** 2026-01-21
**Status:** Proposed
**Goal:** Reorganize repository to support spec-driven development workflow

---

## Rationale

Current structure mixes specs, implementation, and demos without clear traceability. This makes it hard to:
- Know what's implemented vs specified
- Track progress against specs
- Plan milestones based on spec sections

---

## Target Structure

```
azblink-AD/
├── specs/                              # Source of truth (what to build)
│   └── v1.0/
│       ├── SPEC.md                     # Main architecture spec
│       ├── API_CONTRACT.md             # API surface definition
│       ├── DATA_MODEL.md               # LDAP + PostgreSQL schemas
│       └── SECURITY.md                 # Security requirements
│
├── milestones/                         # Progress tracking
│   ├── v1.0-baseline/
│   │   ├── CHECKLIST.md                # Spec compliance checklist
│   │   ├── GAP_ANALYSIS.md             # Gap report
│   │   └── PROGRESS.md                 # Implementation status
│   └── v1.1-security/
│       └── CHECKLIST.md
│
├── src/                                # Implementation
│   ├── backend/                        # Python API
│   │   ├── main.py
│   │   ├── config.py
│   │   ├── ldap_client.py
│   │   ├── orgdb.py
│   │   ├── oidc_verify.py
│   │   ├── qr_signing.py               # To extract
│   │   ├── breakglass.py               # To extract
│   │   ├── rate_limit.py               # To create
│   │   ├── termination.py              # To create
│   │   ├── audit.py                    # To create
│   │   ├── uc_client.py                # To create
│   │   ├── authentik_client.py         # To create
│   │   └── requirements.txt
│   ├── cli/
│   │   └── directoryctl.py
│   ├── ui/                             # Admin UIs (to create)
│   └── migrations/                     # SQL migrations (to create)
│
├── demo/                               # Standalone demos
│   ├── qr-flow/
│   │   ├── index.html
│   │   ├── ucchat_tabs_safenest.html
│   │   ├── ucchat_tabs_ehub.html
│   │   ├── ucchat_tabs_teampulse.html
│   │   └── README.md
│   └── api-examples/                   # Future
│
├── deploy/                             # Deployment configs
│   ├── dev/
│   │   ├── docker-compose.yml
│   │   ├── Dockerfile.api
│   │   ├── .env.example
│   │   ├── ldap/bootstrap.ldif
│   │   └── runtime/breakglass.json
│   └── prod/                           # Future
│       └── docker-compose.full.yml
│
└── docs/                               # Generated/operational docs
    ├── plans/                          # Design documents
    └── api.md                          # OpenAPI (to generate)
```

---

## Migration Steps

### Phase 1: Create New Structure

```bash
# Create new directories
mkdir -p specs/v1.0
mkdir -p milestones/v1.0-baseline
mkdir -p milestones/v1.1-security
mkdir -p src/backend
mkdir -p src/cli
mkdir -p src/ui
mkdir -p src/migrations
mkdir -p demo/qr-flow
mkdir -p deploy/dev
mkdir -p deploy/prod
```

### Phase 2: Move Specs

```bash
# Move and rename main spec
mv v1.0-baseline/specs/AZBLINK_DIRECTORY_AUTHENTIK_COMPLETE_GUIDE_v2.md specs/v1.0/SPEC.md

# Keep legacy specs for reference
mv v1.0-baseline/specs/AZBLINK_DIRECTORY_AUTHENTIK_COMPLETE_GUIDE.md specs/v1.0/SPEC_v1.md
mv v1.0-baseline/specs/ldap_architecture_summary.md specs/v1.0/LDAP_ARCHITECTURE.md
mv v1.0-baseline/specs/Demo_Data_to_API_Mapping.md specs/v1.0/API_MAPPING.md
mv v1.0-baseline/specs/authentik/ specs/v1.0/authentik/
```

### Phase 3: Move Implementation

```bash
# Move backend code
mv v1.0-baseline/api/*.py src/backend/
mv v1.0-baseline/api/requirements.txt src/backend/

# Move CLI to proper location
mv src/backend/directoryctl.py src/cli/
```

### Phase 4: Move Demos

```bash
# Move demo files
mv v1.0-baseline/demo/*.html demo/qr-flow/
mv v1.0-baseline/demo/README.md demo/qr-flow/
```

### Phase 5: Move Deploy Configs

```bash
# Move to dev environment
mv v1.0-baseline/deploy/* deploy/dev/
```

### Phase 6: Setup Milestones

```bash
# Move gap analysis to milestones
mv v1.0-baseline-report.md milestones/v1.0-baseline/GAP_ANALYSIS.md
```

### Phase 7: Cleanup

```bash
# Remove empty v1.0-baseline after migration
rmdir v1.0-baseline/specs
rmdir v1.0-baseline/api
rmdir v1.0-baseline/demo
rmdir v1.0-baseline/deploy
rmdir v1.0-baseline/docs
rmdir v1.0-baseline/ui
rmdir v1.0-baseline
```

### Phase 8: Update Docker Paths

Update `deploy/dev/docker-compose.yml`:
- Change `../api:/app:ro` to `../../src/backend:/app:ro`
- Update Dockerfile context path

Update `deploy/dev/Dockerfile.api`:
- Change COPY paths to reference `src/backend`

---

## Milestone Tracking Template

### milestones/v1.0-baseline/CHECKLIST.md

```markdown
# v1.0 Baseline Spec Compliance Checklist

## Spec Reference: specs/v1.0/SPEC.md

### Section 0: Security Requirements
- [ ] 0.1 QR Payload Signing - Partial (schema mismatch)
- [ ] 0.2 One-Time Token Enforcement - Partial (no validation)
- [ ] 0.3 Rate Limiting - Not Started

### Section 3: Components
- [x] OpenLDAP
- [x] PostgreSQL
- [ ] Redis
- [ ] Authentik (optional)

### Section 6: User Lifecycle
- [ ] 6.1 Provisioning Flow - Partial
- [ ] 6.2 Termination Flow - Not Started
- [ ] 6.3 Suspension Flow - Not Started

### Section 10: API Surface
- [x] Bootstrap/Info: 2/4
- [x] Organizations: 4/4
- [ ] Users: 6/10
- [ ] Groups: 3/5
- [ ] QR Provisioning: 2/4
- [ ] Audit: 0/3
```

---

## Benefits

1. **Traceability**: Every implementation file maps to spec sections
2. **Progress Visibility**: Checklists show what's done vs pending
3. **Milestone Planning**: Easy to define v1.1, v1.2 based on spec sections
4. **Separation of Concerns**: Specs (what) vs src (how) vs deploy (where)
5. **Demo Isolation**: Demos don't mix with production code

---

## Post-Migration Tasks

1. Update all import paths in Python files
2. Update docker-compose volume mounts
3. Update any CI/CD scripts
4. Create initial CHECKLIST.md for v1.0-baseline
5. Create v1.1-security milestone with P0 items from gap analysis
