# DataTable Enhancement Design

> Feature-rich table component for `/directory/users` with pagination, search, filters, and column visibility.

## Context

- **Current state:** Simple `UserTable` using shadcn/ui `<Table>` primitives with no interactivity
- **Scale:** 500–5,000 users (client-side filtering viable)
- **Stack:** React 19, TanStack Query, Zustand, shadcn/ui, Tailwind CSS 4

## Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Table library | TanStack Table | Headless, composable, same ecosystem as Query/Router |
| Column visibility | Dropdown menu | Simple, matches existing "Filters" button pattern |
| Filtering | Preset dropdowns | Known filterable fields; faster than filter builder |
| Virtualization | Deferred | Not critical at 500-5000 rows; add later if needed |
| State persistence | Zustand store | Matches existing `ui-store.ts` pattern |

## Design System Integration

### Design Tokens

All components use tokens from `globals.css` to support light/dark mode:

| Component Part | Token | Tailwind Class |
|----------------|-------|----------------|
| Table container border | `--color-border` | `border-border` |
| Header row background | `--color-muted` | `bg-muted/50` |
| Row hover | `--color-muted` | `hover:bg-muted/30` |
| Text primary | `--color-text` | `text-text` |
| Text secondary | `--color-muted-foreground` | `text-muted-foreground` |
| Dropdown background | `--color-popover` | `bg-popover` |
| Dropdown shadow | `--shadow-md` | `shadow-md` |
| Focus ring | `--color-ring` | `focus-visible:ring-ring` |
| Cell padding | `--spacing-2` | `p-2` |
| Container radius | `--radius-md` | `rounded-lg` |

### Z-Index Layering

From `globals.css` z-index scale:

| Element | Z-Index | Rationale |
|---------|---------|-----------|
| Sticky `<thead>` | `z-10` | Above table body, below app chrome |
| Filter/Column dropdowns | `z-40` (`--z-dropdown`) | Above sticky header |
| Pagination | none | Not overlapping, no z needed |

### Dark Mode

- All colors use CSS custom properties from `globals.css`
- Dark mode handled automatically via `.dark` class or `prefers-color-scheme`
- No hardcoded hex values in components

## Component Architecture

```
src/frontend/src/
├── components/
│   ├── ui/
│   │   └── data-table/
│   │       ├── index.tsx            # Main DataTable component
│   │       ├── column-toggle.tsx    # Column visibility dropdown
│   │       ├── pagination.tsx       # Pagination controls
│   │       └── filters.tsx          # Filter dropdown component
│   └── features/
│       └── user-table.tsx           # User-specific column defs + filters
├── stores/
│   └── table-store.ts               # Table preferences (Zustand persist)
├── routes/
│   └── directory/users/
│       └── index.tsx                # Page layout (100vh, toolbar, table)
```

**Data flow:**
1. Page fetches users via TanStack Query
2. Passes `users[]` to `UserTable`
3. `UserTable` defines columns, passes to `DataTable`
4. `DataTable` manages pagination/sorting/filtering via TanStack Table state
5. Column visibility and page size persisted via `table-store.ts`

## State Persistence

Follows existing `ui-store.ts` pattern using Zustand persist middleware:

```tsx
// stores/table-store.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface TablePreferences {
  columnVisibility: Record<string, boolean>;
  pageSize: number;
}

interface TableState {
  tables: Record<string, TablePreferences>;  // keyed by tableId
  getTablePrefs: (tableId: string) => TablePreferences;
  setColumnVisibility: (tableId: string, visibility: Record<string, boolean>) => void;
  setPageSize: (tableId: string, size: number) => void;
  resetTable: (tableId: string) => void;
}

export const useTableStore = create<TableState>()(
  persist(
    (set, get) => ({
      tables: {},
      getTablePrefs: (tableId) => get().tables[tableId] ?? { columnVisibility: {}, pageSize: 25 },
      setColumnVisibility: (tableId, visibility) =>
        set((s) => ({
          tables: { ...s.tables, [tableId]: { ...s.tables[tableId], columnVisibility: visibility } },
        })),
      setPageSize: (tableId, size) =>
        set((s) => ({
          tables: { ...s.tables, [tableId]: { ...s.tables[tableId], pageSize: size } },
        })),
      resetTable: (tableId) =>
        set((s) => {
          const { [tableId]: _, ...rest } = s.tables;
          return { tables: rest };
        }),
    }),
    { name: 'azblink-tables' }
  )
);
```

## DataTable API

```tsx
<DataTable
  columns={columns}
  data={users}
  tableId="users"                   // Used for persistence key
  searchPlaceholder="Search users..."
  searchColumn="global"
  defaultPageSize={25}
  pageSizeOptions={[25, 50, 100]}
  enableColumnVisibility
  enablePagination
  enableSorting
  filterPresets={[
    { id: 'status', label: 'Status', options: ['Active', 'Suspended'] },
    { id: 'org', label: 'Organization', options: orgList },
    { id: 'hasQr1', label: 'Has QR#1', options: ['Yes', 'No'] },
  ]}
/>
```

**Column definition:**

```tsx
const columns: ColumnDef<User>[] = [
  {
    accessorKey: 'displayName',
    header: 'User',
    cell: ({ row }) => <UserCell user={row.original} />,
    enableHiding: false,
  },
  {
    accessorKey: 'orgDn',
    header: 'Organization',
    cell: ({ getValue }) => getOrgName(getValue()),
  },
  {
    accessorKey: 'mail',
    header: 'Email',
    meta: { defaultHidden: true },
  },
]
```

## Layout

```
┌─────────────────────────────────────────────┐
│  Sidebar  │  Header (sticky)                │
│  z-20     │  z-30                           │
│           ├─────────────────────────────────│
│           │  Page Title + "New User" btn    │  ← flex-none
│           │  Search | Filters | Columns     │  ← flex-none
│           ├─────────────────────────────────│
│           │  Table Header (sticky, z-10)    │  ← sticky top-0
│           │─────────────────────────────────│
│           │  Table Body                     │  ← overflow-auto
│           │    row 1 ... row n              │
│           ├─────────────────────────────────│
│           │  Pagination                     │  ← flex-none
└───────────┴─────────────────────────────────┘
```

**Key CSS:**

```tsx
// routes/directory/users/index.tsx
<div className="flex flex-col h-full">
  {/* Fixed toolbar */}
  <div className="flex-none space-y-4 pb-4">
    <PageHeader />
    <Toolbar />
  </div>

  {/* Scrollable table */}
  <div className="flex-1 min-h-0 flex flex-col">
    <DataTable className="flex-1 overflow-hidden" />
  </div>
</div>

// Inside DataTable
<div className="flex flex-col h-full border border-border rounded-lg overflow-hidden">
  <div className="overflow-auto flex-1">
    <table className="w-full">
      <thead className="sticky top-0 z-10 bg-muted/50">...</thead>
      <tbody>...</tbody>
    </table>
  </div>
  <div className="flex-none border-t border-border bg-surface p-2">
    <Pagination />
  </div>
</div>
```

## Search & Filters

**Global search:**
- Single input searches `displayName`, `mail`, `uid`, `orgDn`
- Debounced 300ms
- Uses TanStack Table `globalFilterFn: 'includesString'`

**Filter presets dropdown:**

```
┌─────────────────────────┐
│ Filters           ✕     │  ← bg-popover shadow-md z-40
├─────────────────────────┤
│ Status                  │
│ ○ All  ● Active  ○ Susp │
├─────────────────────────┤
│ Organization            │
│ [Select org...      ▾]  │
├─────────────────────────┤
│ Has QR#1                │
│ ○ All  ○ Yes  ○ No      │
├─────────────────────────┤
│ [Clear all]             │
└─────────────────────────┘
```

Active filters shown as removable badges: `Status: Active ✕`

## Column Visibility

```
┌─────────────────────────┐
│ Columns           ✕     │  ← bg-popover shadow-md z-40
├─────────────────────────┤
│ ☑ User                  │  ← cannot hide
│ ☑ Organization          │
│ ☑ Status                │
│ ☐ Email                 │  ← hidden by default
│ ☐ Mobile                │
│ ☐ Title                 │
│ ☑ QR#1                  │
│ ☑ QR#2                  │
│ ☐ Groups                │
├─────────────────────────┤
│ [Reset to default]      │
└─────────────────────────┘
```

- Persisted via `useTableStore` (Zustand)
- Columns with `enableHiding: false` always visible
- Columns with `meta: { defaultHidden: true }` hidden initially

## Pagination

```
┌─────────────────────────────────────────────────────────┐
│ Showing 1-25 of 1,247 users    │  [25 ▾]  │ ‹ 1 2 3 ... 50 › │
└─────────────────────────────────────────────────────────┘
```

- Page sizes: 25, 50, 100
- Keyboard: ←/→ arrows navigate pages
- Shows filtered count when active: `Showing 1-25 of 89 users (filtered from 1,247)`
- Page size persisted via `useTableStore`

## Implementation

**Dependency:**

```bash
npm install @tanstack/react-table
```

**Files to create:**

| File | Purpose | ~Lines |
|------|---------|--------|
| `components/ui/data-table/index.tsx` | Core DataTable | ~150 |
| `components/ui/data-table/column-toggle.tsx` | Column dropdown | ~60 |
| `components/ui/data-table/pagination.tsx` | Pagination | ~80 |
| `components/ui/data-table/filters.tsx` | Filter dropdown | ~50 |
| `stores/table-store.ts` | Zustand persistence | ~50 |

**Files to modify:**

| File | Changes |
|------|---------|
| `components/features/user-table.tsx` | Rewrite with TanStack Table columns |
| `routes/directory/users/index.tsx` | 100vh layout, wire toolbar state |

## Out of Scope

- Column reordering (drag-and-drop)
- Row selection / bulk actions
- Server-side pagination
- Virtualization (add `@tanstack/react-virtual` later if needed)
- CSV export

## Future Reuse

The `DataTable` component will be reusable for:
- `/directory/groups` — Groups table
- `/directory/orgs` — Organizations table
- `/audit` — Audit log table
