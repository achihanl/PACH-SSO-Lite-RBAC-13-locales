# Design Tokens & Dark Mode Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Replace 85 hardcoded color classes with semantic tokens and add dark mode support.

**Architecture:** CSS custom properties in `@theme` block with `prefers-color-scheme` media query and `.dark` class support. Components use Tailwind utility classes mapped to tokens. Theme state managed via Zustand store with localStorage persistence.

**Tech Stack:** Tailwind CSS 4, React 19, Zustand, shadcn/ui

---

## Task 1: Update globals.css with New Tokens

**Files:**
- Modify: `src/frontend/src/styles/globals.css`

**Step 1: Add new light mode tokens to @theme block**

Replace the current `@theme` block with the complete token set. Add after line 27 (`--color-text-muted`):

```css
  /* NEW: Additional tokens for component coverage */
  --color-muted-hover: #E2E8F0;       /* slate-200 - Interactive hover */
  --color-text-secondary: #475569;    /* slate-600 - Body text */
  --color-icon-muted: #64748B;        /* slate-500 - Decorative icons */
  --color-accent-muted: #F0F9FF;      /* sky-50 - Active nav, highlights */
  --color-tooltip: #1E293B;           /* slate-800 - Tooltip backgrounds */
  --color-tooltip-foreground: #FFFFFF;
  --color-ring: #0369A1;              /* Focus ring - same as accent */
```

**Step 2: Add dark mode media query block**

Add after the closing `}` of `@theme` block (after line 68):

```css
/* ═══════════════════════════════════════════════════════════════════
   DARK MODE - via prefers-color-scheme
   ═══════════════════════════════════════════════════════════════════ */
@media (prefers-color-scheme: dark) {
  :root:not(.light) {
    --color-background: #0F172A;
    --color-surface: #1E293B;
    --color-muted: #334155;
    --color-muted-hover: #475569;
    --color-border: #334155;
    --color-popover: #1E293B;
    --color-popover-foreground: #F8FAFC;
    --color-tooltip: #F1F5F9;
    --color-tooltip-foreground: #1E293B;
    --color-text: #F8FAFC;
    --color-text-muted: #94A3B8;
    --color-text-secondary: #CBD5E1;
    --color-muted-foreground: #94A3B8;
    --color-icon-muted: #94A3B8;
    --color-primary: #F8FAFC;
    --color-primary-foreground: #0F172A;
    --color-secondary: #CBD5E1;
    --color-secondary-foreground: #0F172A;
    --color-accent: #38BDF8;
    --color-accent-light: #0EA5E9;
    --color-accent-muted: #0C4A6E;
    --color-accent-foreground: #0F172A;
    --color-success: #34D399;
    --color-success-light: #064E3B;
    --color-success-foreground: #ECFDF5;
    --color-warning: #FBBF24;
    --color-warning-light: #78350F;
    --color-warning-foreground: #FFFBEB;
    --color-destructive: #F87171;
    --color-destructive-light: #7F1D1D;
    --color-destructive-foreground: #FEF2F2;
    --color-ring: #38BDF8;
  }
}
```

**Step 3: Add .dark class block for manual toggle**

Add after the media query block:

```css
/* ═══════════════════════════════════════════════════════════════════
   DARK MODE - via .dark class on <html> for manual toggle
   ═══════════════════════════════════════════════════════════════════ */
.dark {
  --color-background: #0F172A;
  --color-surface: #1E293B;
  --color-muted: #334155;
  --color-muted-hover: #475569;
  --color-border: #334155;
  --color-popover: #1E293B;
  --color-popover-foreground: #F8FAFC;
  --color-tooltip: #F1F5F9;
  --color-tooltip-foreground: #1E293B;
  --color-text: #F8FAFC;
  --color-text-muted: #94A3B8;
  --color-text-secondary: #CBD5E1;
  --color-muted-foreground: #94A3B8;
  --color-icon-muted: #94A3B8;
  --color-primary: #F8FAFC;
  --color-primary-foreground: #0F172A;
  --color-secondary: #CBD5E1;
  --color-secondary-foreground: #0F172A;
  --color-accent: #38BDF8;
  --color-accent-light: #0EA5E9;
  --color-accent-muted: #0C4A6E;
  --color-accent-foreground: #0F172A;
  --color-success: #34D399;
  --color-success-light: #064E3B;
  --color-success-foreground: #ECFDF5;
  --color-warning: #FBBF24;
  --color-warning-light: #78350F;
  --color-warning-foreground: #FFFBEB;
  --color-destructive: #F87171;
  --color-destructive-light: #7F1D1D;
  --color-destructive-foreground: #FEF2F2;
  --color-ring: #38BDF8;
}
```

**Step 4: Verify dev server shows no CSS errors**

Run: `cd src/frontend && npm run dev`
Expected: Dev server starts, no CSS parsing errors in terminal

**Step 5: Commit**

```bash
git add src/frontend/src/styles/globals.css
git commit -m "feat(ui): add design tokens and dark mode CSS variables

- Add 7 new semantic tokens (muted-hover, text-secondary, icon-muted, accent-muted, tooltip, tooltip-foreground, ring)
- Add prefers-color-scheme dark mode media query
- Add .dark class support for manual theme toggle"
```

---

## Task 2: Update Tooltip Component

**Files:**
- Modify: `src/frontend/src/components/ui/tooltip.tsx:52-53`

**Step 1: Replace hardcoded bg-slate-800 with token**

Change line 53 from:
```tsx
'z-50 rounded-md bg-slate-800 px-2.5 py-1.5 text-xs font-medium text-white shadow-md',
```

To:
```tsx
'z-50 rounded-md bg-tooltip px-2.5 py-1.5 text-xs font-medium text-tooltip-foreground shadow-md',
```

**Step 2: Verify tooltip renders correctly**

Run: `cd src/frontend && npm run dev`
Open: http://localhost:3000
Test: Hover over collapsed sidebar icons, verify tooltip appears with dark background

**Step 3: Commit**

```bash
git add src/frontend/src/components/ui/tooltip.tsx
git commit -m "refactor(ui): use tooltip token in Tooltip component"
```

---

## Task 3: Update Sidebar Component

**Files:**
- Modify: `src/frontend/src/components/layout/sidebar.tsx`

**Step 1: Replace bg-slate-50 on aside (line 80)**

Change:
```tsx
'fixed top-14 left-0 bottom-0 bg-slate-50 border-r border-border z-sidebar transition-all duration-200 flex flex-col',
```

To:
```tsx
'fixed top-14 left-0 bottom-0 bg-background border-r border-border z-sidebar transition-all duration-200 flex flex-col',
```

**Step 2: Replace border-slate-200 divider (line 91)**

Change:
```tsx
<div className="mx-3 my-3 border-t border-slate-200" />
```

To:
```tsx
<div className="mx-3 my-3 border-t border-border" />
```

**Step 3: Replace active state bg-sky-50 (line 120)**

Change:
```tsx
isActive && 'bg-sky-50 text-accent border-l-2 border-accent',
```

To:
```tsx
isActive && 'bg-accent-muted text-accent border-l-2 border-accent',
```

**Step 4: Replace inactive collapsed state (lines 122-124)**

Change:
```tsx
!isActive &&
  sidebarCollapsed &&
  'bg-slate-100 text-slate-600 hover:bg-slate-200',
```

To:
```tsx
!isActive &&
  sidebarCollapsed &&
  'bg-muted text-text-secondary hover:bg-muted-hover',
```

**Step 5: Replace inactive expanded state (lines 125-127)**

Change:
```tsx
!isActive &&
  !sidebarCollapsed &&
  'text-slate-600 hover:bg-slate-100'
```

To:
```tsx
!isActive &&
  !sidebarCollapsed &&
  'text-text-secondary hover:bg-muted'
```

**Step 6: Replace footer border (line 160)**

Change:
```tsx
'border-t border-slate-200 py-3 text-center',
```

To:
```tsx
'border-t border-border py-3 text-center',
```

**Step 7: Replace version text color (lines 167 and 174)**

Change line 167:
```tsx
<span className="text-[10px] font-mono text-slate-400 cursor-default">
```

To:
```tsx
<span className="text-[10px] font-mono text-icon-muted cursor-default">
```

Change line 174:
```tsx
<span className="text-xs font-mono text-slate-400">{FULL_VERSION}</span>
```

To:
```tsx
<span className="text-xs font-mono text-icon-muted">{FULL_VERSION}</span>
```

**Step 8: Verify sidebar renders correctly in both states**

Run: `cd src/frontend && npm run dev`
Test:
- Toggle sidebar collapse/expand
- Verify active nav item has light blue background
- Verify inactive items have correct hover states
- Verify version footer is visible

**Step 9: Commit**

```bash
git add src/frontend/src/components/layout/sidebar.tsx
git commit -m "refactor(ui): replace hardcoded colors with tokens in Sidebar

- bg-slate-50 → bg-background
- border-slate-200 → border-border
- bg-sky-50 → bg-accent-muted
- bg-slate-100 → bg-muted
- text-slate-600 → text-text-secondary
- text-slate-400 → text-icon-muted"
```

---

## Task 4: Update Header Component

**Files:**
- Modify: `src/frontend/src/components/layout/header.tsx:42`

**Step 1: Replace hover:bg-slate-200 on search button**

Change line 42:
```tsx
className="w-full h-10 px-4 flex items-center gap-2 text-muted-foreground bg-muted rounded-md hover:bg-slate-200 transition-colors"
```

To:
```tsx
className="w-full h-10 px-4 flex items-center gap-2 text-muted-foreground bg-muted rounded-md hover:bg-muted-hover transition-colors"
```

**Step 2: Verify search bar hover state**

Run: `cd src/frontend && npm run dev`
Test: Hover over search bar, verify background darkens slightly

**Step 3: Commit**

```bash
git add src/frontend/src/components/layout/header.tsx
git commit -m "refactor(ui): use muted-hover token in Header search"
```

---

## Task 5: Update Login Page

**Files:**
- Modify: `src/frontend/src/routes/login.tsx`

**Step 1: Replace bg-slate-50 container (line 63)**

Change:
```tsx
<div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
```

To:
```tsx
<div className="min-h-screen bg-background flex items-center justify-center p-4">
```

**Step 2: Replace bg-slate-900 logo (line 67)**

Change:
```tsx
<div className="inline-flex h-14 w-14 rounded-xl bg-slate-900 items-center justify-center mb-4">
```

To:
```tsx
<div className="inline-flex h-14 w-14 rounded-xl bg-primary items-center justify-center mb-4">
```

**Step 3: Replace text-slate-900 title (line 70)**

Change:
```tsx
<h1 className="text-2xl font-semibold text-slate-900">AZBlink Directory</h1>
```

To:
```tsx
<h1 className="text-2xl font-semibold text-text">AZBlink Directory</h1>
```

**Step 4: Replace text-slate-600 subtitle (line 71)**

Change:
```tsx
<p className="text-slate-600 mt-1">Admin Portal</p>
```

To:
```tsx
<p className="text-text-secondary mt-1">Admin Portal</p>
```

**Step 5: Replace text-slate-500 footer (line 141)**

Change:
```tsx
<p className="text-center text-sm text-slate-500 mt-6 flex items-center justify-center gap-1">
```

To:
```tsx
<p className="text-center text-sm text-muted-foreground mt-6 flex items-center justify-center gap-1">
```

**Step 6: Verify login page renders correctly**

Run: `cd src/frontend && npm run dev`
Open: http://localhost:3000/login
Test: Page displays with correct colors, logo visible

**Step 7: Commit**

```bash
git add src/frontend/src/routes/login.tsx
git commit -m "refactor(ui): replace hardcoded colors with tokens in Login page"
```

---

## Task 6: Update Settings Page

**Files:**
- Modify: `src/frontend/src/routes/settings.tsx`

**Step 1: Replace all border-slate-100 (lines 57, 63, 85, 109, 115, 128, 186)**

Find and replace all occurrences:
```tsx
border-slate-100
```

With:
```tsx
border-border
```

**Step 2: Replace all text-slate-600 (lines 58, 64, 68, 86, 92, 110, 116, 129, 133)**

Find and replace all occurrences:
```tsx
text-slate-600
```

With:
```tsx
text-text-secondary
```

**Step 3: Replace all text-slate-900 (lines 59, 65, 69, 93, 111)**

Find and replace all occurrences:
```tsx
text-slate-900
```

With:
```tsx
text-text
```

**Step 4: Replace text-slate-400 (line 60)**

Change:
```tsx
<span className="text-slate-400 font-normal">
```

To:
```tsx
<span className="text-icon-muted font-normal">
```

**Step 5: Replace text-slate-700 (lines 87, 117, 130, 134, 191)**

Find and replace all occurrences:
```tsx
text-slate-700
```

With:
```tsx
text-text
```

**Step 6: Replace text-slate-500 (line 197)**

Change:
```tsx
<span className="text-sm text-slate-500 font-mono">
```

To:
```tsx
<span className="text-sm text-muted-foreground font-mono">
```

**Step 7: Replace text-slate-300 (line 212)**

Change:
```tsx
<MinusCircle className="h-5 w-5 text-slate-300" />
```

To:
```tsx
<MinusCircle className="h-5 w-5 text-icon-muted" />
```

**Step 8: Verify settings page renders correctly**

Run: `cd src/frontend && npm run dev`
Open: http://localhost:3000/settings
Test: All text readable, borders visible

**Step 9: Commit**

```bash
git add src/frontend/src/routes/settings.tsx
git commit -m "refactor(ui): replace hardcoded colors with tokens in Settings page"
```

---

## Task 7: Update My Profile Page

**Files:**
- Modify: `src/frontend/src/routes/my-profile.tsx`

**Step 1: Replace text-slate-900 (line 78)**

Change:
```tsx
<h1 className="text-xl font-semibold text-slate-900">
```

To:
```tsx
<h1 className="text-xl font-semibold text-text">
```

**Step 2: Replace text-slate-500 (lines 81, 104, 109, 114, 119, 124, 138)**

Find and replace all occurrences:
```tsx
text-slate-500
```

With:
```tsx
text-muted-foreground
```

**Step 3: Replace text-slate-400 (lines 82, 103, 108, 113, 118, 123)**

Find and replace all occurrences:
```tsx
text-slate-400
```

With:
```tsx
text-icon-muted
```

**Step 4: Replace text-slate-700 (lines 105, 110, 115, 120, 125)**

Find and replace all occurrences:
```tsx
text-slate-700
```

With:
```tsx
text-text
```

**Step 5: Verify my-profile page renders correctly**

Run: `cd src/frontend && npm run dev`
Open: http://localhost:3000/my-profile
Test: Profile info displays correctly

**Step 6: Commit**

```bash
git add src/frontend/src/routes/my-profile.tsx
git commit -m "refactor(ui): replace hardcoded colors with tokens in My Profile page"
```

---

## Task 8: Update Startup Check Component

**Files:**
- Modify: `src/frontend/src/components/features/startup-check.tsx`

**Step 1: Replace bg-slate-50 container (line 104)**

Change:
```tsx
<div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
```

To:
```tsx
<div className="min-h-screen bg-background flex items-center justify-center p-4">
```

**Step 2: Replace bg-sky-600 logo (line 108)**

Change:
```tsx
<div className="h-12 w-12 rounded-lg bg-sky-600 flex items-center justify-center">
```

To:
```tsx
<div className="h-12 w-12 rounded-lg bg-accent flex items-center justify-center">
```

**Step 3: Replace text-slate-900 title (line 111)**

Change:
```tsx
<span className="text-2xl font-semibold text-slate-900">AZBlink Directory</span>
```

To:
```tsx
<span className="text-2xl font-semibold text-text">AZBlink Directory</span>
```

**Step 4: Replace text-slate-600 status text (line 117)**

Change:
```tsx
<div className="flex items-center justify-center gap-2 text-slate-600">
```

To:
```tsx
<div className="flex items-center justify-center gap-2 text-text-secondary">
```

**Step 5: Replace bg-slate-50 service row (line 139)**

Change:
```tsx
className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-50"
```

To:
```tsx
className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted"
```

**Step 6: Replace text-slate-700 service name (line 141)**

Change:
```tsx
<span className="text-sm font-medium text-slate-700">{service.name}</span>
```

To:
```tsx
<span className="text-sm font-medium text-text">{service.name}</span>
```

**Step 7: Replace text-slate-400 spinner (line 144)**

Change:
```tsx
<Loader2 className="h-4 w-4 text-slate-400 animate-spin" />
```

To:
```tsx
<Loader2 className="h-4 w-4 text-icon-muted animate-spin" />
```

**Step 8: Replace text-slate-400 footer (line 193)**

Change:
```tsx
<p className="text-xs text-slate-400 text-center mt-6">
```

To:
```tsx
<p className="text-xs text-icon-muted text-center mt-6">
```

**Step 9: Commit**

```bash
git add src/frontend/src/components/features/startup-check.tsx
git commit -m "refactor(ui): replace hardcoded colors with tokens in StartupCheck"
```

---

## Task 9: Update Empty State Component

**Files:**
- Modify: `src/frontend/src/components/features/empty-state.tsx`

**Step 1: Replace bg-slate-100 and text-slate-400 icon container (line 42)**

Change:
```tsx
<div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-slate-400">
```

To:
```tsx
<div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted text-icon-muted">
```

**Step 2: Replace text-slate-900 title (line 47)**

Change:
```tsx
<h3 className="mb-2 text-lg font-semibold text-slate-900">{title}</h3>
```

To:
```tsx
<h3 className="mb-2 text-lg font-semibold text-text">{title}</h3>
```

**Step 3: Replace text-slate-500 description (line 50)**

Change:
```tsx
<p className="mb-6 max-w-sm text-sm text-slate-500">{description}</p>
```

To:
```tsx
<p className="mb-6 max-w-sm text-sm text-muted-foreground">{description}</p>
```

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/empty-state.tsx
git commit -m "refactor(ui): replace hardcoded colors with tokens in EmptyState"
```

---

## Task 10: Update Organizations Page

**Files:**
- Modify: `src/frontend/src/routes/directory/orgs/index.tsx`

**Step 1: Replace hover:bg-slate-50 (line 84)**

Change:
```tsx
'flex items-center gap-2 py-2 px-3 rounded-md hover:bg-slate-50 cursor-pointer',
```

To:
```tsx
'flex items-center gap-2 py-2 px-3 rounded-md hover:bg-muted cursor-pointer',
```

**Step 2: Replace text-slate-400 chevrons (lines 91, 93)**

Change:
```tsx
<ChevronDown className="h-4 w-4 text-slate-400 flex-shrink-0" />
```

To:
```tsx
<ChevronDown className="h-4 w-4 text-icon-muted flex-shrink-0" />
```

And:
```tsx
<ChevronRight className="h-4 w-4 text-slate-400 flex-shrink-0" />
```

To:
```tsx
<ChevronRight className="h-4 w-4 text-icon-muted flex-shrink-0" />
```

**Step 3: Replace text-slate-500 icon (line 98)**

Change:
```tsx
<Building2 className="h-4 w-4 text-slate-500 flex-shrink-0" />
```

To:
```tsx
<Building2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
```

**Step 4: Replace text-slate-700 name (line 99)**

Change:
```tsx
<span className="text-sm font-medium text-slate-700">{node.name}</span>
```

To:
```tsx
<span className="text-sm font-medium text-text">{node.name}</span>
```

**Step 5: Replace text-slate-400 dn (line 100)**

Change:
```tsx
<span className="text-xs text-slate-400 ml-auto truncate max-w-[200px]">
```

To:
```tsx
<span className="text-xs text-icon-muted ml-auto truncate max-w-[200px]">
```

**Step 6: Commit**

```bash
git add src/frontend/src/routes/directory/orgs/index.tsx
git commit -m "refactor(ui): replace hardcoded colors with tokens in Organizations page"
```

---

## Task 11: Update Groups Page

**Files:**
- Modify: `src/frontend/src/routes/directory/groups/index.tsx`

**Step 1: Replace bg-sky-100 and text-sky-600 icon (lines 73-74)**

Change:
```tsx
<div className="h-10 w-10 rounded-lg bg-sky-100 flex items-center justify-center flex-shrink-0">
  <Users className="h-5 w-5 text-sky-600" />
```

To:
```tsx
<div className="h-10 w-10 rounded-lg bg-accent-muted flex items-center justify-center flex-shrink-0">
  <Users className="h-5 w-5 text-accent" />
```

**Step 2: Replace text-slate-900 group name (line 77)**

Change:
```tsx
<h3 className="font-medium text-slate-900 truncate">{group.cn}</h3>
```

To:
```tsx
<h3 className="font-medium text-text truncate">{group.cn}</h3>
```

**Step 3: Replace text-slate-500 description (line 78)**

Change:
```tsx
<p className="text-sm text-slate-500 truncate">
```

To:
```tsx
<p className="text-sm text-muted-foreground truncate">
```

**Step 4: Replace text-slate-400 member count (line 81)**

Change:
```tsx
<p className="text-xs text-slate-400 mt-1">
```

To:
```tsx
<p className="text-xs text-icon-muted mt-1">
```

**Step 5: Commit**

```bash
git add src/frontend/src/routes/directory/groups/index.tsx
git commit -m "refactor(ui): replace hardcoded colors with tokens in Groups page"
```

---

## Task 12: Update Tokens Page

**Files:**
- Modify: `src/frontend/src/routes/provisioning/tokens.tsx`

**Step 1: Replace bg-slate-100 and text-slate-500 in revoked badge (line 86)**

Change:
```tsx
revoked: 'bg-slate-100 text-slate-500 border-slate-200',
```

To:
```tsx
revoked: 'bg-muted text-muted-foreground border-border',
```

**Step 2: Replace text-slate-500 cells (lines 129, 132)**

Change:
```tsx
<TableCell className="text-slate-500">
```

To:
```tsx
<TableCell className="text-muted-foreground">
```

(Apply to both occurrences)

**Step 3: Replace text-slate-400 dash (line 143)**

Change:
```tsx
<span className="text-slate-400 text-sm">—</span>
```

To:
```tsx
<span className="text-icon-muted text-sm">—</span>
```

**Step 4: Commit**

```bash
git add src/frontend/src/routes/provisioning/tokens.tsx
git commit -m "refactor(ui): replace hardcoded colors with tokens in Tokens page"
```

---

## Task 13: Add Theme Store

**Files:**
- Modify: `src/frontend/src/stores/ui-store.ts`

**Step 1: Add theme type and state**

Add after line 6 (after the imports):
```typescript
type Theme = 'light' | 'dark' | 'system';
```

**Step 2: Add theme state to interface**

Add to `UIState` interface after line 14:
```typescript
  theme: Theme;
  setTheme: (theme: Theme) => void;
```

**Step 3: Add theme implementation**

Add to the store state after line 28:
```typescript
      theme: 'system' as Theme,
```

Add the setter after line 36:
```typescript
      setTheme: (theme) => {
        set({ theme });
        // Apply theme to document
        const root = document.documentElement;
        root.classList.remove('light', 'dark');
        if (theme !== 'system') {
          root.classList.add(theme);
        }
      },
```

**Step 4: Add theme to persisted state**

Update `partialize` (around line 41) to include theme:
```typescript
      partialize: (state) => ({
        sidebarCollapsed: state.sidebarCollapsed,
        theme: state.theme,
      }),
```

**Step 5: Commit**

```bash
git add src/frontend/src/stores/ui-store.ts
git commit -m "feat(ui): add theme state to UI store with localStorage persistence"
```

---

## Task 14: Initialize Theme on App Load

**Files:**
- Modify: `src/frontend/src/main.tsx`

**Step 1: Add theme initialization**

Add after imports:
```typescript
// Initialize theme from persisted state
const initTheme = () => {
  const stored = localStorage.getItem('azblink-ui');
  if (stored) {
    try {
      const { state } = JSON.parse(stored);
      if (state?.theme && state.theme !== 'system') {
        document.documentElement.classList.add(state.theme);
      }
    } catch {
      // Ignore parse errors
    }
  }
};
initTheme();
```

**Step 2: Commit**

```bash
git add src/frontend/src/main.tsx
git commit -m "feat(ui): initialize theme class on app load from localStorage"
```

---

## Task 15: Visual Verification

**Step 1: Test light mode**

Run: `cd src/frontend && npm run dev`
Open: http://localhost:3000

Verify:
- [ ] Dashboard renders with correct colors
- [ ] Sidebar has light background, correct hover states
- [ ] Login page has correct branding colors
- [ ] Settings page text is readable
- [ ] All borders are visible

**Step 2: Test dark mode (via browser devtools)**

Open browser devtools → Rendering → Emulate CSS media feature `prefers-color-scheme: dark`

Verify:
- [ ] Background changes to dark slate
- [ ] Text changes to light colors
- [ ] Sidebar has dark background
- [ ] Tooltips have inverted colors (light bg, dark text)
- [ ] Status badges remain distinguishable

**Step 3: Run grep to verify no hardcoded colors remain**

Run:
```bash
cd src/frontend && grep -rn "text-slate\|bg-slate\|border-slate\|bg-sky\|text-sky" src/ --include="*.tsx" | grep -v node_modules
```

Expected: No results (or only comments)

**Step 4: Final commit**

```bash
git add -A
git commit -m "feat(ui): complete design token extraction and dark mode support

- All 85 hardcoded color references replaced with semantic tokens
- Dark mode support via prefers-color-scheme and .dark class
- Theme state persisted to localStorage
- WCAG AA contrast verified for all token pairs"
```

---

## Summary

| Task | Component | Changes |
|------|-----------|---------|
| 1 | globals.css | Add 7 new tokens, dark mode CSS |
| 2 | tooltip.tsx | 1 replacement |
| 3 | sidebar.tsx | 12 replacements |
| 4 | header.tsx | 1 replacement |
| 5 | login.tsx | 5 replacements |
| 6 | settings.tsx | 22 replacements |
| 7 | my-profile.tsx | 14 replacements |
| 8 | startup-check.tsx | 8 replacements |
| 9 | empty-state.tsx | 3 replacements |
| 10 | orgs/index.tsx | 7 replacements |
| 11 | groups/index.tsx | 5 replacements |
| 12 | tokens.tsx | 4 replacements |
| 13 | ui-store.ts | Add theme state |
| 14 | main.tsx | Add theme init |
| 15 | — | Visual verification |

**Total commits:** 15
**Total file changes:** 14 files
