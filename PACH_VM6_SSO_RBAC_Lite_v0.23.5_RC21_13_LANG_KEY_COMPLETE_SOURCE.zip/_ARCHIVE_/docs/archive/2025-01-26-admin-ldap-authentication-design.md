# Admin LDAP Authentication Design

> **Date:** 2025-01-26
> **Status:** Approved
> **Scope:** Frontend login flow + backend LDAP bind authentication

---

## Overview

Add username/password authentication for the admin dashboard using LDAP bind verification. This is phase 1 of a hybrid approach—SSO/OIDC integration will be added later.

**Key decisions:**
- Admins are regular users in `ou=people` with `IT-Admins` group membership
- JWT tokens (stateless), 8-hour expiration (7 days with "remember me")
- Unauthenticated users redirect to `/login`
- Session expired modal for gentle UX on token expiry

---

## Backend Design

### New Endpoint: `POST /api/auth/login`

**Request:**
```json
{
  "username": "alice",
  "password": "secret123",
  "remember": false
}
```

**Response (success):**
```json
{
  "ok": true,
  "token": "eyJhbG...",
  "user": {
    "uid": "alice",
    "dn": "uid=alice,ou=people,dc=azblink,dc=com",
    "displayName": "Alice Smith",
    "email": "alice@example.com",
    "isAdmin": true,
    "groups": ["IT-Admins", "Engineering"]
  },
  "expiresAt": "2025-01-27T04:00:00Z"
}
```

**Response (failure):**
```json
{
  "ok": false,
  "error": "INVALID_CREDENTIALS",
  "detail": "Invalid username or password"
}
```

### Authentication Flow

1. Receive username/password
2. Look up user DN in `ou=people` by `uid`
3. Attempt LDAP bind with user's DN + provided password
4. If bind succeeds, fetch user attributes (`displayName`, `mail`, `memberOf`)
5. Check `memberOf` for `IT-Admins` group → set `isAdmin`
6. Generate JWT with claims: `uid`, `dn`, `displayName`, `email`, `isAdmin`, `groups`, `exp`
7. Sign JWT with `JWT_SECRET` environment variable
8. Return token + user info

### JWT Structure

```json
{
  "uid": "alice",
  "dn": "uid=alice,ou=people,dc=azblink,dc=com",
  "displayName": "Alice Smith",
  "email": "alice@example.com",
  "isAdmin": true,
  "groups": ["IT-Admins", "Engineering"],
  "iat": 1706270400,
  "exp": 1706299200
}
```

### Token Expiration

| Mode | Duration |
|------|----------|
| Default | 8 hours |
| Remember me | 7 days |

### New Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `JWT_SECRET` | (required) | Secret for signing JWTs |
| `JWT_EXPIRY_HOURS` | `8` | Default token expiration |
| `JWT_REMEMBER_DAYS` | `7` | Expiration with "remember me" |

### Security Considerations

- Error messages are vague ("Invalid username or password") to prevent user enumeration
- LDAP bind uses user's own credentials, not service account
- Failed login attempts should be logged (already have `record_auth_failure` in orgdb)

---

## Frontend Design

### New Route: `/login`

Standalone login page (no sidebar/header).

**Layout:**
- Centered card on gray-50 background
- AZBlink logo + "Directory Admin" title
- Form: username, password, "Remember me" checkbox
- Submit button with loading state
- Footer: "Secured by LDAP authentication"

**Behavior:**
- Focus username field on mount
- Submit on Enter key
- Disable button while submitting
- Show toast error on failure
- Redirect to `?redirect` param or `/` on success

### Route Protection

**Protected routes (require auth):**
- `/` (dashboard)
- `/directory/*` (users, groups, orgs)
- `/provisioning/*` (QR generator, tokens)
- `/settings`
- `/my-profile`

**Public routes:**
- `/login`

**Guard logic:**
```
On navigation to protected route:
  If no token or token expired:
    Redirect to /login?redirect={originalPath}
```

### Auth Store Updates

```typescript
interface AuthState {
  token: string | null;
  user: {
    uid: string;
    dn: string;
    displayName: string;
    email: string;
    isAdmin: boolean;
    groups: string[];
  } | null;
  expiresAt: number | null;

  login: (username: string, password: string, remember?: boolean) => Promise<void>;
  logout: () => void;
  isAuthenticated: () => boolean;
  isExpired: () => boolean;
}
```

**Storage:**
- Default → `sessionStorage`
- Remember me → `localStorage`

### Session Expired Modal

**Trigger:** API returns 401 when user has existing token

**Content:**
- Icon + "Session Expired" heading
- Message: "Your session has expired due to inactivity. Please log in again to continue."
- Buttons: "Cancel" (close modal), "Log in again" (redirect to /login)

**Behavior:**
- Non-dismissable (no click-outside or ESC)
- "Log in again" preserves current path in redirect param
- Only show once per expiration event

### Profile Dropdown

**Location:** Top-right of header

**Contents:**
- User's display name
- Email
- Admin badge (if `isAdmin`)
- Divider
- My Profile link
- Settings link
- Divider
- Log out button

---

## Implementation Plan

### Files to Create

| File | Purpose |
|------|---------|
| `src/backend/auth.py` | LDAP bind auth + JWT generation |
| `src/frontend/src/routes/login.tsx` | Login page component |
| `src/frontend/src/components/features/session-expired-modal.tsx` | Session expired dialog |
| `src/frontend/src/components/features/profile-dropdown.tsx` | Header profile menu |

### Files to Modify

| File | Changes |
|------|---------|
| `src/backend/main.py` | Add `/api/auth/login` endpoint |
| `src/backend/config.py` | Add JWT env vars |
| `src/frontend/src/stores/auth-store.ts` | Add login action, expiry tracking |
| `src/frontend/src/stores/ui-store.ts` | Add session expired modal state |
| `src/frontend/src/lib/api-client.ts` | Update `onUnauthorized` handler |
| `src/frontend/src/components/layout/header.tsx` | Add profile dropdown |
| `src/frontend/src/routes/__root.tsx` | Add route guard logic |

### Dependencies

- **Backend:** `PyJWT` (already present)
- **Frontend:** None new (shadcn/ui has AlertDialog, DropdownMenu)

---

## Future: SSO Integration (Phase 2)

When Authentik/OIDC is ready:

1. Add "Sign in with SSO" button to login page
2. Implement OIDC authorization code flow
3. Backend validates OIDC tokens alongside LDAP JWTs
4. User can choose LDAP or SSO login method

The hybrid approach allows graceful degradation—if Authentik is down, LDAP auth still works.

---

## Testing Checklist

- [ ] Login with valid admin credentials → success, redirects to dashboard
- [ ] Login with valid non-admin credentials → success, `isAdmin: false`
- [ ] Login with invalid password → error toast, stays on login page
- [ ] Login with non-existent user → same error as invalid password
- [ ] Access protected route without token → redirect to /login
- [ ] Token expires during session → modal appears
- [ ] "Remember me" checked → token persists after browser restart
- [ ] Profile dropdown shows correct user info
- [ ] Logout clears token and redirects to /login
