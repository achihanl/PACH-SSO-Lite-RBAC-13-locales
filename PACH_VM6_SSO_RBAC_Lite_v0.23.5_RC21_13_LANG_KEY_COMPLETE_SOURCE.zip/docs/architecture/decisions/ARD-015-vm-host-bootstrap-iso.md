---
# ARD metadata — authoritative source of truth.
# The summary block below is maintained BY HAND and must be kept consistent with
# these fields. No generator exists: `just new-ard` and the regenerating
# pre-commit hook this template used to reference were never built.
status: proposed
accepted_at:
decision_effective_date:
supersedes: []
superseded_by: []
pr:
spec_sections_affected: ["06-deployment"]
---
<!-- summary:begin -->
Status **proposed** — a produced ISO now installs **unattended** end to end,
twice, but only under qemu (2026-08-06; see Amendments). The one attempt on real
hardware (`azb-ad`, 2026-08-05) fell back to a hand-install and its cause is
still unproven. Flip to `accepted` (with `accepted_at` and `pr`) once a real host
has been bootstrapped unattended **and** converged — the local run establishes
the mechanism, not the lane. Supersedes nothing; superseded by nothing.
Affects `spec/06-deployment.md`.
<!-- summary:end -->

# ARD-015: Per-VM autoinstall ISO as the host bootstrap lane

## Context

`deploy/ansible` converges a host that already exists, is reachable over SSH,
and has a known address. Nothing recorded how a host reaches that state. In
practice it was done by hand over VNC, once, and the steps lived in somebody's
memory.

The hypervisor hosting these VMs offers exactly one input channel: upload an
ISO, attach it as CD/DVD, boot UEFI, watch a VNC console. There is no cloud-init
drive, no disk image import, and no API. The control node reaches the hypervisor
over a VPN tunnel, and a freshly-booted VM has no route back to it.

That single constraint — one file in, no callback — determines the whole design:
everything the new host needs must travel inside the ISO.

## Decision

- `deploy/bootstrap-iso/` builds a **per-VM** unattended Ubuntu 24.04 autoinstall
  ISO. A host config (`hosts/<name>.env`) renders `/autoinstall.yaml`; the ISO is
  produced by `just bootstrap-iso <name>`.
- The ISO is produced by **copying** the source ISO with
  `xorriso -boot_image any replay` and overlaying three paths — `/autoinstall.yaml`,
  `/boot/grub/grub.cfg`, and `/azb/` — rather than extract-and-repack. `replay`
  reproduces the source's El Torito records verbatim, so the signed shim, GRUB
  and kernel stay byte-identical and Secure Boot is unaffected.
- Autoinstall config is delivered **root-of-medium** (`/autoinstall.yaml` plus
  `autoinstall` on the kernel command line), not via a `ds=nocloud` datasource.
- **Networking defaults to DHCP** with a netplan `en*` match, so the virtual NIC
  name — which varies by hypervisor and cannot be determined from the control
  node — never has to be known. Where the address must be predictable in
  advance, it is pinned by a **DHCP reservation against the vNIC MAC**, not by
  static config in the ISO.
- The assigned address is read back on the VNC console: `/etc/issue` carries it
  pre-login via agetty's `\4` escape, and `azb-netinfo` (shipped in the ISO,
  installed to `/usr/local/bin`) prints interfaces, routing, DNS, SSH state,
  host-key fingerprints and a ready-made `hosts.ini` line.
- **Scope is bounded to reachability.** The ISO installs the OS, one user, one
  key, an address and `qemu-guest-agent`. Docker, `just`, git and the application
  remain `host_prep` + `azblink_app`'s responsibility. The handoff contract is
  *"SSH-reachable at a known address with a known key"* and nothing more.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Universal ISO + `ds=nocloud;s=http://provisioner/` seed | The standard recommendation, and unusable here. The provisioner would sit on the control-node side of the VPN; an installing VM has a DHCP lease and no route to it, so it would hang fetching `user-data` and be finished by hand over VNC — the manual step this exists to remove. |
| Golden disk image shipped inside a restore ISO (Clonezilla `ocs-iso`) | Saves ~5 minutes of install time on an operation run a few times a year, and costs a golden-image lifecycle: sysprep, machine-id and host-key scrubbing, and a rebuild on every base-image update. It also duplicates what `host_prep`/`azblink_app` already do idempotently, creating a second definition of what is on a host that will drift from the first. |
| Static addressing baked per VM | Requires knowing the NIC name, which is hypervisor-dependent and only obtainable by a throwaway boot. A DHCP reservation achieves the same predictability, keeps addressing in one place, and survives a hypervisor upgrade renaming the interface. Retained as an option for segments with no DHCP. |
| Extract ISO, edit tree, repack with `-as mkisofs` | The widely-published recipe, and wrong for 24.04: the live-server ISO no longer ships `isolinux/`, so the standard `-b isolinux/isolinux.bin` invocation fails outright, and hand-reconstructed El Torito flags are a recurring source of ISOs that will not boot under UEFI. |
| Document the manual VNC install instead | The status quo. It is not reproducible, not reviewable, and not diffable, and it puts a 20-step console procedure on the critical path of every new host. |

## Consequences

**Positive**

- Host creation becomes a reviewable artifact: a four-line host config plus a
  template, in git, instead of a console procedure in somebody's memory.
- No platform capability is required. The design survives the hypervisor
  offering nothing but an upload button.
- The install has no network dependency on the control node, so it works
  regardless of VPN routing at boot time.
- `just bootstrap-iso-test` boots the ISO under qemu/OVMF locally, so a
  misconfiguration costs 90 seconds rather than a multi-GB upload over the VPN.

**Negative**

- One ISO per VM, ~3 GB each, and each must be uploaded. Acceptable because host
  creation is rare; it would not be at higher volume.
- A source ISO must be kept on the build host, and re-fetched for each Ubuntu
  release the fleet moves to.
- `xorriso` becomes a workstation dependency. Builds run where the upload
  browser is — the ISO goes to the hypervisor through a web form, so producing
  it on the LAN dev box would mean shipping 3 GB there and pulling it back.
  `deploy/bootstrap-iso/{src,out}` consequently need Mutagen ignore entries as
  well as gitignore ones, since Mutagen does not read `.gitignore`.

**Neutral**

- The ISO carries a sha512crypt console password. Host configs are gitignored
  for that reason, and the password is a console/`become` credential only — SSH
  is key-only (`allow-pw: false`).
- Because scope is deliberately bounded to reachability, the bootstrap lane has
  no opinion about the application. Changing what is installed on a host remains
  an Ansible change, which is the intent.

## References

- Related ARDs: ARD-010 (production deployment artifact — the converge this
  bootstrap hands off to)
- PR: (pending)
- Spec sections: `spec/06-deployment.md` § 6.8
- Implementation: `deploy/bootstrap-iso/`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link.
     Body above this heading is frozen once status=accepted. -->

### 2026-08-05 — first real boot did not apply the autoinstall

`azb-ad` was installed from a produced ISO and came up **hand-installed**: no
sshd, no `azb-netinfo`, `/etc/issue` unmodified, and apt left pointing at a
detached CD. The ISO itself was not at fault — its `grub.cfg` and
`autoinstall.yaml` were extracted afterwards and both were well-formed.

What this exposed is that the decision's unattended guarantee rested on
`set default` alone, which governs only the timeout path. The stock menu keeps
*Try or Install Ubuntu Server* as a bootable interactive entry, so a single
keystroke on the VNC console defeats it — and the resulting host is
indistinguishable from one where the ISO was never read, which is what made the
diagnosis slow.

Closed in this PR: every stock casper entry now carries `autoinstall` and the
build refuses to ship an ISO with an interactive installer entry;
`/etc/azb-bootstrap` records whether autoinstall applied; the target's
`deb cdrom:` apt source is disabled so a delivered host can install packages;
and the rendered-YAML check is a hard failure rather than a silent skip when
PyYAML is missing.

**Not closed:** the actual cause for `azb-ad` was never isolated — the keystroke
path is the hypothesis the evidence best supports, not a confirmed finding. The
remaining evidence is `/var/log/installer/autoinstall-user-data` on that host.
Status stays `proposed` until a VM installs unattended end-to-end.

### 2026-08-05 — the hand-installed host was converged and cut over

The box was reached over SSH once `openssh-server` was installed by hand, and
`host_prep` + `azblink_app` converged onto it cleanly. `deploy/ansible` now
targets it: `inventories/dev/hosts.ini` and `server_host` moved from
`192.168.11.126` to `192.168.11.136`.

That is a deliberate separation of two things this ARD has been conflating. The
**converge** lane works — it does not care how the host came to exist. The
**bootstrap** lane is still unvalidated, because the host it handed off was
produced by a manual VNC install, which is precisely the procedure this ARD
exists to replace. Status therefore stays `proposed`. A cutover is not an
acceptance criterion; an unattended install is.

Two further readings from the live host, which sharpen the amendment above
without closing it:

- The root LV is 49G inside a 98G partition — subiquity's default 50%. The
  `lvextend` late-command never ran, confirming that **no** late-command ran,
  not merely that the marker file is absent.
- `/var/log/installer/` holds only `casper-md5check.json` and `media-info`. The
  absence of `autoinstall-user-data` was expected to be decisive, but
  `curtin-install.log` and the subiquity logs are missing too — the whole
  log-copy is absent, so the missing file does not isolate an interactive
  install the way the previous amendment anticipated. The keystroke path remains
  the best-supported hypothesis and remains unproven.

### 2026-08-06 — a produced ISO installs unattended, under qemu

Two consecutive ISOs built from `hosts/azb-isotest.env` were booted locally
under qemu + OVMF and installed **with no console interaction at all**. Both
reached a login prompt and answered SSH on a key-only account. On both:

- `/etc/azb-bootstrap` contains `azb-autoinstall=applied` — the acceptance
  criterion, met for the first time.
- The consumed config carries no interactive sections, and its `identity`,
  `ssh`, `network` and `packages` blocks match what `build.py` rendered, so the
  installer demonstrably read *our* file rather than falling back to a default.
- `AZB_GROW_ROOT` works: curtin created a 10 GiB root LV and the late-command
  grew it to 17.32 G on a 20 G disk.

This closes the *mechanism* question the two amendments above left open. It does
**not** meet this ARD's own bar, which is an unattended install **and** a
converge on a real host: a local qemu guest is neither. Status stays `proposed`.

**A baseline that partly re-reads the `azb-ad` evidence.**
`/var/log/installer/autoinstall-user-data` is present (4043 bytes) on both
successful runs, so a successful unattended install does write it. `azb-ad`
lacks not just that file but `curtin-install.log` and the subiquity logs, which
*any* subiquity run — interactive included — would leave behind. So the missing
set is evidence against a completed subiquity install of any kind on that host,
which is a different claim from the keystroke hypothesis and neither confirms
nor retires it. Still unproven; recorded so the next real install can settle it.

**A caveat on using that file as evidence.** `autoinstall-user-data` is
subiquity's *normalized post-install* config, not a verbatim copy: its
`late-commands` list comes back **empty** even on a run where the late-commands
provably executed. It establishes which autoinstall was consumed and nothing
about whether late-commands ran — `/etc/azb-bootstrap` is the only check for
that.

**Defect found and fixed by this run.** The marker recorded sshd state with
`systemctl is-enabled ssh`, which prints `disabled` on 24.04 because sshd is
socket-activated (`ssh.service` disabled, `ssh.socket` enabled) — so a healthy
box reported as broken from the very file added to end that ambiguity in one
`cat`. It now records both units by name. Verified on a guest and through a
full rebuild-and-reinstall.

**Two prerequisites were unavailable, not merely unrun.** PyYAML could not be
installed as the README directs because pip is globally configured with
`require-virtualenv`; the guard deps now live in a venv outside the repo. qemu
was not installed at all, so `just bootstrap-iso-test` — the loop that makes a
mistake cost 90 seconds instead of a multi-GB VPN upload — had never been
runnable. Both are workstation setup, not repo state, and are the reason this
validation had not happened sooner.
