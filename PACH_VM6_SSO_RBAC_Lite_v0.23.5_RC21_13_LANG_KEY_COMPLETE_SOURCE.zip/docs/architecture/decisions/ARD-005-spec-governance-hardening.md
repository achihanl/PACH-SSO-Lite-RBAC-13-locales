---
status: accepted
accepted_at: 2026-04-20
decision_effective_date: 2026-04-20
supersedes: []
superseded_by: []
pr: ""
spec_sections_affected: []
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-04-20 • **Effective:** 2026-04-20
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** — (governance meta-ARD; amends SOP.md)
<!-- summary:end -->

# ARD-005: Spec Governance Hardening

## Context

Between 2026-03-17 and 2026-04-19 (33 days) twelve+ architectural PRs shipped without ARDs or spec-section updates. `docs/architecture/README.md`'s `spec-meta.last_updated` froze at 2026-03-17 while single-LDAP, Authentik OIDC, profile-services, QR removal, account-lock model, WebSocket/SSE activity bus, and sealed-box credential delivery all landed. PRDs at `docs/prd/` and `specs/v2.0/` described a system that no longer existed. The existing SOP had the right rules but no enforcement; `[TARGET v2.0]` markers and the "significant" heuristic trigger were subjective; changelog edits were mistaken for a drift guard (a changelog reports what shipped — by then, drift already exists).

## Decision

Install pre-merge enforcement + archive migration + retro-ARDs for the four load-bearing decisions that shipped unrecorded. Specifically:

- `tools/arch_guard.py` — surface-path coverage (full), ARD immutability, ARD↔spec consistency, marker consistency, CLAUDE.md anchor scope, ARD-POST back-pressure, archive immunity. Seven rules; rule IDs cited in failure messages.
- `docs/archive/` — physical move of `docs/prd/`, `specs/v2.0/`, `docs/plans/` via `git mv`; nested CLAUDE.md marks tree read-only; guard exempts the path.
- ARD metadata migrates to authoritative YAML frontmatter; summary auto-rendered between `<!-- summary:begin/end -->` markers by a pre-commit hook (Phase 1b). No dual-write.
- `.github/CODEOWNERS` on governance paths; CI uses sparse-checkout from `main` so a PR cannot neuter its own guard (eng-review E1.1 → B).
- `--warn-only` rollout for ≥2 zero-false-positive weeks OR 60 days elapsed (whichever first); then flip to `--fail`.
- Retro-ARDs 006–009 backfill load-bearing decisions (WebSocket/SSE bus, sealed-box crypto, QR removal, account-lock model) with dual timestamps — `accepted_at` (real merge date) + `decision_effective_date` (date original decision shipped). Preserves audit integrity without backdating process history.
- `spec-meta.version` bumps `1.1.0 → 2.0.0` post-spec sync (Phase 2).

Full design: `docs/architecture/proposals/2026-04-19-spec-governance-hardening.md`. Implementation plan: `docs/architecture/proposals/2026-04-19-spec-governance-hardening-plan.md`.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Changelog-based guard (towncrier / changie / scriv fragment tooling) | A changelog reports what shipped; drift happens pre-merge. Wrong layer. Dropped after user pushback during brainstorm. |
| Gate on any commit trailer anywhere in PR | Gameable: throwaway commit carries trailer, behavioural commits don't. Upgraded to full-coverage per outside-voice Tension B2. |
| Cross-repo reusable-workflow `uses: ./…@main` syntax | Invalid for same-repo. Replaced with sparse-checkout of `main` into `_trusted/` prefix. |
| Dual-metadata write (frontmatter + manually-synced markdown summary table) | Synchronisation debt. Frontmatter is sole source; summary auto-rendered via pre-commit. |
| Backdate retro-ARDs to original PR merge date | Rewrites process history. Dual timestamps preserve audit integrity. |
| Single Phase 1 PR (guard + scaffolder + git-cliff + PR template all together) | Too heavy for calibration. Split 1a (enforcement core) + 1b (friction reducers) per outside-voice Tension C2. |

## Consequences

**Positive:**
- Drift detectable at PR gate, not at release.
- ARDs acquire decision-integrity guarantees (immutability, bidirectionality, marker resolution).
- Single truth source for architecture (`docs/architecture/`).
- Commit-trailer convention gives the changelog a scope-grouped "Architecture" section for free via git-cliff (Phase 1b).

**Negative:**
- Initial `surfaces.yaml` will have false positives + negatives. `--warn-only` calibration window absorbs this.
- CODEOWNERS + branch protection adds one review hop for governance-path PRs. Mitigated by small maintainer set.
- Emergency-lane abuse risk (`ARD-POST: placeholder`); mitigated by Rule 6 back-pressure (open followups ≥7d block new arch PRs).

**Neutral:**
- Retro-ARDs 006–009 are ~1 page each; low cognitive cost.
- `docs/architecture/CHANGELOG.md` retired; root CHANGELOG gains "Architecture" group via cliff.toml scope grouping (Phase 1b).

## References

- Design proposal: `docs/architecture/proposals/2026-04-19-spec-governance-hardening.md`
- Implementation plan: `docs/architecture/proposals/2026-04-19-spec-governance-hardening-plan.md`
- CEO plan: summarised in proposal §GSTACK REVIEW REPORT; full transcript lives in the repo owner's gstack workspace (not committed to share repo).
- Outside-voice review: cursor-agent + gpt-5.3-codex-high (12 findings — 2 CRIT / 5 HIGH / 4 MED / 1 LOW)
- Eng review: `/plan-eng-review` (5 issues; E1.1=sparse-checkout, E2.1=PyYAML+shim)
- PR: (this ARD lands in the Phase-0 PR; field patched into frontmatter post-merge)

## Amendments

<!-- None yet. First amendment will be added post-merge if corrections surface. -->

### 2026-09-18 — PR reference recorded here, not in frontmatter

§ References says the `pr:` field would be "patched into frontmatter post-merge".
That never happened, and it can no longer happen: guard rule 2 compares the whole
file above `## Amendments` — frontmatter included — against the base-ref blob, so
any edit to `pr:` on an `accepted` ARD fails `ard-immutability`. The instruction
the record left for itself is unexecutable by the rule the record installed.

This ARD landed in **#99** (`c9ed57f`, 2026-04-20, "feat(arch): install spec
governance foundations (Phase 0)"). `pr:` stays empty; this entry is the
reference. Anyone wanting the field itself populated has to decide whether rule 2
should exempt frontmatter — a change to the guard, not to this file.
