---
status: accepted
accepted_at: 2026-07-29
decision_effective_date: 2026-07-29
supersedes: []
superseded_by: []
pr: "#226"
spec_sections_affected: ["02-component-architecture", "08-integration-points"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-07-29 • **Effective:** 2026-07-29 • **PR:** #226
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 02-component-architecture, 08-integration-points
<!-- summary:end -->

# ARD-011: Redis Cross-Worker Event Fan-Out & Middleware Ordering Invariant

## Context

PR #226 (merged 2026-07-29, "decompose god modules into routers/, db/, schemas/") shipped two architectural decisions as drive-by fixes inside a mechanical refactor, and neither was recorded properly. Commit `82f398d` fixed a live production bug — `ActivityBus` (`src/backend/activity_bus.py`) held subscriber queues in process memory with no cross-worker delivery, so on the production path (`deploy/dev/Dockerfile.api` runs `--workers ${UVICORN_WORKERS:-2}` when `UVICORN_RELOAD` is unset) an admin's WebSocket on worker A never saw an event published by worker B — silently dropping roughly half of every real-time feed with no error and no log line. Commit `568b097` fixed a second bug of the same shape while splitting 100 routes out of `main.py`: `CORSMiddleware` was the first middleware added, which under Starlette's LIFO registration made it the innermost layer, so a `403` from `IPBlockingMiddleware` shipped without `Access-Control-Allow-Origin` and a blocked admin saw an opaque browser network error instead of the real status.

Both commits carry an `ARD:` trailer, and both trailers are wrong. `82f398d` cites `ARD-004` (Profile Services Restructuring; `spec_sections_affected: ["03-data-architecture", "05-provisioning"]`) to justify a new cross-process transport. `568b097` cites `ARD-002` (Authentik-Only OIDC Authentication; `spec_sections_affected: ["02-component-architecture", "04-authentication", "07-security"]`) to justify a middleware-ordering fix that lives entirely in `08-integration-points`. Neither cited ARD's `spec_sections_affected` covers the surface actually touched — `tools/arch_guard.py` (currently `--warn-only`) would flag both once enforced. Issue #232 ("Correct the architecture trailers across all seven decomposition commits") is blocked on this ARD existing so `82f398d` has something real to cite in a follow-up trailer correction; this record is that ARD.

## Decision

### Decision 1 — Redis as the cross-worker activity-event transport

- `ActivityBus.publish_sync()` now publishes to a shared Redis channel (`azblink:activity`) instead of only fanning out to the local process's `asyncio.Queue` subscribers. Every worker runs a `run_listener()` task that subscribes to that channel and relays received events into its own local queues via `deliver_local()`.
- Delivery path: `publish_sync()` → Redis `PUBLISH` → every worker's listener (including the publishing worker's own) → local queues. The publishing worker takes the same path as every other worker — there is exactly one delivery per subscriber, with no special-cased shortcut for local delivery on the publisher.
- The Redis client is not a new connection: `deps.ip_block_redis` (already built for `rate_limit.py` / `IPBlockingMiddleware`) is passed into `init_activity_bus(redis_client=ip_block_redis)` and reused.
- **Deliberate degradation, not a bug:** if `ip_block_redis` is `None` (Redis not configured) or a `publish()` call raises, `publish_sync()` falls back to `deliver_local()` — local-only delivery, the pre-existing behavior. This is correct for single-worker dev (`UVICORN_RELOAD=1`, one process, nothing to fan out across) and for a Redis outage in production (the app must not crash-loop because its realtime feed degraded).
- The fallback transition is logged once, not never and not per event: a `logger.warning(..., exc_info=True)` fires the first time a publish fails and sets `_redis_degraded = True`; subsequent failures are silent until a successful publish logs `logger.info("... recovered")` and clears the flag. This is a deliberate lesson from the bug this commit fixes: the original in-memory-only behavior was invisible precisely because nothing ever logged it, so a loud one-shot transition (rather than silence, and rather than a log line per dropped event under sustained outage) is the chosen middle ground.

### Decision 2 — Middleware ordering is a load-bearing invariant, pinned by contract test

- Starlette's `app.add_middleware()` inserts at position 0 of the middleware stack, so the **last** middleware added is the **outermost** at request time.
- `src/backend/main.py` now adds middleware in this order: `IPBlockingMiddleware`, `RequestAuditMiddleware`, `MetricsMiddleware`, `RequestIDMiddleware`, `CORSMiddleware`. That produces this runtime nesting, outermost first:

  ```
  CORS → RequestID → Metrics → RequestAudit → IPBlocking → routes
  ```

- **Why load-bearing:** before this change `CORSMiddleware` was added first and therefore ended up innermost. A response generated by an outer middleware (e.g. a `403` from `IPBlockingMiddleware`) never passed back out through `CORSMiddleware`, so it shipped without `Access-Control-Allow-Origin`. A browser reports that as an opaque network error, not the real HTTP status — a blocked admin saw "something went wrong" instead of "your IP is blocked."
- **Accepted trade-off:** CORS now sits outside `RequestIDMiddleware`. A CORS preflight (`OPTIONS`) that `CORSMiddleware` answers by itself, without calling further into the stack, carries no `X-Request-ID` header. `tests/contract/test_middleware_order.py` records the team's own justification for accepting this: `CORSMiddleware` emits no log lines, and every request that reaches application code still passes through `RequestIDMiddleware` first — so the gap is confined to responses nothing ever needed to correlate in the logs.
- Pinned by `tests/contract/test_middleware_order.py`: an exact-order snapshot test (`test_full_middleware_order_is_pinned`), an outermost-CORS test, a RequestID-second test, a Metrics-outside-IPBlocking test, and a live-request regression test (`test_blocked_ip_403_carries_cors_headers`) that asserts a blocked-IP `403` actually carries `access-control-allow-origin`.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Sticky sessions / worker affinity for WebSocket clients (route each admin's connection to a fixed worker) | Doesn't fix SSE or cross-worker publish; only relocates the coupling to the load balancer, and this deployment has no load balancer in front of uvicorn workers — Traefik round-robins to any worker. |
| Single-worker deployment (`UVICORN_WORKERS=1`) as the production default | Sidesteps the bug but throws away the concurrency headroom the multi-worker default exists for; the bug would resurface the moment anyone bumped the worker count without knowing why it mattered. |
| A dedicated Redis connection for `ActivityBus`, separate from `ip_block_redis` | Redis is already a runtime dependency (`rate_limit.py`, `IPBlockingMiddleware`); a second connection for the same store buys isolation the two use cases don't need and adds a config knob nobody asked for. |
| Silent fallback to local-only delivery (no log line) when Redis is unavailable | This is exactly the behavior that made the original bug invisible for however long it shipped undetected — the fix's entire point is that degraded delivery must be observable. |
| Log every event during a Redis outage, not just the state transition | Under a sustained outage this floods the log with an entry per event for no added information over the initial warning; state-transition logging (once down, once recovered) carries the same operational signal at a bounded cost. |
| Leave `CORSMiddleware` first-added (innermost) | Status quo bug: rejections from any outer middleware (`IPBlocking`, `RequestAudit`) ship without CORS headers, and a blocked/rate-limited browser client sees an opaque network failure instead of the real status. |
| Move `RequestIDMiddleware` outside `CORSMiddleware` instead, so preflights also get an `X-Request-ID` | `CORSMiddleware` never logs, so there is nothing to correlate on a preflight it answers alone; reordering to fix a non-problem would put CORS one layer further from "outermost, wraps everything," which is the property Decision 2 exists to guarantee. |

## Consequences

**Positive**
- Real-time WebSocket/SSE delivery is now correct under the production default of `UVICORN_WORKERS=2` (or any N > 1); previously roughly half of all activity events were silently dropped depending on which worker handled the subscriber's connection versus which worker handled the publish.
- A degraded or unconfigured Redis no longer takes down the realtime feed or the app — it degrades to the pre-existing single-worker-equivalent behavior, loudly, once.
- Blocked/rate-limited clients now receive a real, CORS-readable HTTP status instead of an opaque browser network error; `test_blocked_ip_403_carries_cors_headers` regression-guards this.
- Both fixes have dedicated automated coverage: `tests/unit/test_activity_bus_fanout.py` (11 tests: fake Redis, routing decision, no-double-delivery, both fallback paths, log-once-then-recover, N-worker simulation for N in {1,2,4}) and `tests/contract/test_middleware_order.py` (exact-order snapshot + live-request CORS-header assertion).
- Closes the trailer gap `arch_guard.py` will flag once it leaves `--warn-only`: this ARD gives `82f398d` a citation whose `spec_sections_affected` actually covers `02-component-architecture` (issue #232's stated blocker). `568b097`'s `ARD-002` mis-citation and the rest of the seven-commit trailer sweep remain issue #232's scope, not this ARD's — this record does not itself amend those commits' trailers.

**Negative / trade-offs**
- A CORS preflight answered directly by `CORSMiddleware` carries no `X-Request-ID`, so that narrow response class is not correlatable in structured logs by request ID. Accepted because `CORSMiddleware` itself never logs and every request reaching application code still passes through `RequestIDMiddleware`.
- During a Redis outage, cross-worker delivery is lost for the outage's duration — subscribers on a worker that didn't handle the publish see nothing until Redis recovers. This is the accepted degradation, not a defect: the alternative (blocking or crashing on publish failure) is worse for availability, but it means realtime delivery has an availability dependency on Redis that did not exist when delivery was purely in-process (at the cost of the multi-worker drop bug this ARD fixes).
- `ActivityBus` and `IPBlockingMiddleware` / `rate_limit.py` now share one Redis client (`deps.ip_block_redis`) rather than each owning an independent connection; a Redis outage affects both subsystems' degraded-mode behavior simultaneously rather than in isolation.

## References

- Commits: `82f398d` (`fix(realtime): fan activity events across uvicorn workers via Redis` — Decision 1), `568b097` (`refactor(api): split 100 routes into routers/, fix CORS middleware ordering` — Decision 2), both part of PR #226
- Issues: #227 (this ARD), #232 ("Correct the architecture trailers across all seven decomposition commits" — documents both mis-citations and is blocked on this ARD existing)
- Code: `src/backend/activity_bus.py` (`ActivityBus`, `publish_sync`, `run_listener`), `src/backend/main.py` (`app.add_middleware(...)` block), `src/backend/deps.py` (`ip_block_redis`), `deploy/dev/Dockerfile.api` (`--workers ${UVICORN_WORKERS:-2}` on the non-reload path)
- Tests: `tests/unit/test_activity_bus_fanout.py`, `tests/contract/test_middleware_order.py`
- Surface mapping: `docs/architecture/surfaces.yaml` — `cross_process_boundaries` (`src/backend/activity_bus.py`) → `02-component-architecture`; `api_contracts` (`src/backend/main.py`) → `08-integration-points`
- Related ARDs: ARD-004 (Profile Services — the mis-cited trailer on `82f398d`; does not cover this surface), ARD-002 (Authentik-Only OIDC — the mis-cited trailer on `568b097`; does not cover this surface), ARD-008 (Observability Stack — `MetricsMiddleware`, one of the layers this ARD's ordering invariant pins)
- Spec sections: `02-component-architecture`, `08-integration-points`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->

### 2026-07-29 — Errata: the trailers this ARD was meant to correct no longer exist (#232)

This ARD's Context describes two commits carrying wrong `ARD:` trailers, and issue #232 was
opened to repoint them. Both are now unreachable, and the record on `main` is worse than #232
assessed. Recording it here rather than rewriting history.

**PR #226 was squash-merged.** `403be17` has a single parent (`c3b6030`), so `82f398d`,
`568b097`, `4eb5237`, `2fa9226` and `3e3c836` are not ancestors of `main` — they exist only on a
deleted branch. #232's plan (force-push the corrected trailers to the open PR) has no target.

**What `main` actually carries.** The squash collapsed all ten commits' trailers into one:
`Spec-Patch: 06`. Run against that commit, the guard reports five uncovered surfaces:

```
api_contracts (08-integration-points)          cross_process_boundaries (02-component-architecture)
ci_release_gates (06-deployment)               data_contracts (03-data-architecture, 08-integration-points)
ldap_schema (02-component-architecture, 03-data-architecture)
```

`Spec-Patch: 06` fails to cover even `ci_release_gates` → `06-deployment`, because the Spec-Patch
lane requires the commit to *edit* the named spec section and `403be17` did not.

**Correct citations, for the record.** This ARD (`02-component-architecture`,
`08-integration-points`) is what `82f398d` and `568b097` should have cited. The `03-data-architecture`
surfaces (`orgdb.py` via `data_contracts`, `ldap_client.py` via `ldap_schema`) remain undeclared, and
the connection-release semantics change in `2fa9226` is decisional — it asserts new behaviour, which
the Spec-Patch lane explicitly may not. That lane question is unresolved and carried forward on #232
rather than closed by silence here.

**Why no history rewrite.** Correcting the literal git record would mean force-pushing `main`,
invalidating every clone and the merged PR reference, to fix metadata on a commit whose content is
not in dispute. The trailer regime exists to keep the spec honest, and an append-only erratum does
that at a fraction of the blast radius.

**A second trap, found while fixing the first.** The guard parses trailers with
`git interpret-trailers --parse`, which recognises only the **last contiguous block** of the message.
A blank line between an `ARD:` trailer and a following `Co-Authored-By:` silently voids the `ARD:`
line — it is present to a human reader and invisible to the guard. The commits adding ARD-011 and
ARD-012 both had this shape; they passed only because `docs/architecture/decisions/**` is not a
surface path in `surfaces.yaml`, so no coverage was required. Any commit that touches a real surface
with that layout will report an uncovered surface while appearing to carry a valid trailer. This is
not hypothetical for this repo: every agent-authored commit here appends a `Co-Authored-By:` block.
Worth a lint or a note in SOP §Enforcement before `--fail` mode lands (#234).

**The systemic finding.** `arch-guard-post-merge.yml` exists precisely to catch this — its header
reads "squash-merge can collapse trailers that existed on the PR." It ran on `403be17` and printed
the correct five-surface WARN, then filed nothing: it invoked the guard with `--warn-only`, which
exits `0` even while reporting failures, so its `steps.guard.outcome == 'failure'` condition was
unreachable. The detector for this exact failure mode was itself silently disabled. Fixed in the PR
carrying this amendment; the removal must not be reintroduced when `arch-guard.yml` flips to
`--fail` mode (#234).

### 2026-07-31 — Activity-feed slot lifetime tracks connection lifetime (#236)

`activity_websocket` caps a principal at `MAX_WS_CONNECTIONS_PER_USER` concurrent
feeds, shared with the SSE fallback. The cap was sound; its accounting was not.

The handler never read from the socket — it only awaited the event queue and
sent — so a client close was not observed when it happened. The handler stayed
parked until an event arrived or the 30s heartbeat fired, and only the
*subsequent* send failed and unwound to the `finally` that releases the slot. A
disconnected client therefore held its slot for up to 30 seconds.

At a cap of 3, reloading the dashboard four times inside that window exhausted
the budget, and the refusal surfaced only as a console `403` on the WebSocket
handshake — no UI signal. Reloading is what people do when a page looks stale, so
the failure mode was self-reinforcing. Four open tabs did the same thing.

- **Disconnect detection.** A concurrent `websocket.receive()` task now races the
  queue read; whichever resolves first is acted on. Inbound frames carry no
  meaning (the feed is server-push only) and are discarded — the task exists to
  make a close observable at the moment it occurs. The queue read is created once
  and re-created only after it yields, so a heartbeat tick cannot cancel an
  in-flight `get()` and drop an event.
- **Cap raised 3 → 8.** The cap's job is to bound the per-subscriber queues the
  bus fans out to, not to ration tabs. 8 preserves the bound with room for how the
  console is actually used. This became a fair number to pick only once slot
  lifetime tracked connection lifetime — before that, the ceiling was being spent
  on sockets that had already gone away.
- **Unchanged:** the in-process `_ws_connections` counter and the single-worker
  constraint it inherits from the activity bus. Making the cap correct across
  workers is a different decision and is not taken here.
- **Coverage:** `tests/test_activity_realtime.py::test_disconnect_releases_slot_promptly`
  saturates the cap, asserts the next connection is refused, then closes one and
  claims the freed slot within 5s — comfortably inside the 30s heartbeat, so a
  pass means the close was observed rather than aged out. Every pre-existing test
  opened a single socket and closed it cleanly, which passed either way.

**PR:** #234-batch · **Spec:** §08-integration-points.

### 2026-08-01 — The carried-forward lane question is resolved (#264)

The 2026-07-29 errata amendment above found that `2fa9226`'s connection-release semantics
change is **decisional** — it asserts new behaviour, which the `Spec-Patch` lane explicitly may
not — and carried that question forward on #232 rather than closing it by silence.

It is now closed, in the direction the errata implied. The change is recorded as
[ARD-013 — LDAP Connection Lifecycle](ARD-013-ldap-connection-lifecycle.md), which ratifies the
shipped design: unpooled connections, release guaranteed at the operation boundary by
`safe_ldap()`'s `ContextVar` bucket, and the invariant that every `get_conn()` call must run
inside `safe_ldap()` or `ldap_conn()`. `spec/02-component-architecture.md` § 2 gains the
matching as-built subsection and `spec/03-data-architecture.md` § 1 the matching access-pattern
row.

Two things are deliberately **not** changed by that record:

- **The trailer on `403be17` stays wrong.** #226 was squash-merged, so its seven commits are not
  ancestors of `main` and no force-push has a target. #232 closed as unactionable on exactly that
  ground; this erratum remains the record. ARD-013 is a retro-record with
  `decision_effective_date: 2026-07-29`, not a re-litigation of the merge.
- **The guard still cannot see the backlog.** It evaluates new diffs only, so a decisional change
  that reached `main` under a wrong trailer is invisible to it forever after. ARD-013 was the one
  known instance; finding any others would need a sweep the guard does not perform. Noted, not
  fixed here.

**PR:** #264 · **Spec:** §02-component-architecture, §03-data-architecture.
