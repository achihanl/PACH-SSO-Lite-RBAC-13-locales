---
status: accepted
accepted_at: 2026-10-02
decision_effective_date: 2026-10-02
supersedes: []
superseded_by: []
pr: "#330"
spec_sections_affected: ["03-data-architecture", "04-authentication", "06-deployment", "08-integration-points"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-10-02 • **Effective:** 2026-10-02 • **PR:** #330 (decision; implemented by #332 E2, #333 E2b, #334 E4; E3, E5 pending)
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 03-data-architecture, 04-authentication, 06-deployment, 08-integration-points
<!-- summary:end -->

# ARD-018: Headless First-Party Client Login

## Context

ARD-002 puts every web UI, SafeNest included, behind Authentik OIDC with no
fallback. The only Plane B login path built so far is the browser PKCE redirect
to Authentik's own login page (spec 04 §2). SafeNest wants to keep its own
login form and still use azb-AD's identities. Later first-party apps will ask
the same, so this is decided once, for a class of clients.

Three facts constrain the answer:

- An endpoint in azb-AD that takes a password would bring back what ARD-002
  deleted (`POST /api/auth/login`). It would also put every client's passwords
  through azb-AD.
- The Authentik flow executor can be driven by a backend with no browser. A
  relay that runs it, then `/authorize` (PKCE), then `/token`, gets real
  Authentik tokens for LDAP-sourced users (gap report G4, tested 2026-10-01).
- ARD-007 left `sync_groups=false` as a non-goal. SafeNest keeps role
  membership in LDAP, so its roles reach the token only if role groups sync.
  A plain `groupOfNames` imports nothing under `object_uniqueness_field=uid`
  (G14, tested 2026-10-02).

Full analysis, probes and the decision log:
`docs/reports/2026-09-25-safenest-headless-login-gap-report.md`.

## Decision

**A registered first-party headless client** is an app whose own backend relays
its login form to the Authentik flow executor and gets Authentik tokens back.
azb-AD adds no login endpoint and never sees the password. This is a second way
into Plane B, not a fallback: the tokens, issuer and revocation are Authentik's.

**Registration.** One JSON env value, `AUTHENTIK_FIRST_PARTY_CLIENTS`, maps each
`client_id` to its redirect URIs. The seed gives each client its own
confidential provider and application. Per-client env names are not used: they
break on the hyphen in `safenest-a1` (G13). Onboarding a client is config, a
spec 08 registry row, and a client secret read once into the client's vault.

**Rules every client must meet.** These are admission criteria, not per-client
options:

1. Confidential client. Grants `authorization_code` and `refresh_token` only,
   PKCE S256.
2. Uses the shared headless flow `headless-first-party-auth` only, never the
   brand default flow.
3. Access token 15 minutes, refresh token 7 days.
4. The relay never logs a password or a raw flow response. It forwards
   `X-Forwarded-For`.
5. MFA fails closed. If the flow returns `ak-stage-authenticator-validate` and
   the client has not built that step, the relay refuses the login and sends the
   user to web sign-in. It never skips the stage.
6. Logout revokes the refresh token at `POST /application/o/revoke/` and drops
   the client's own session; the relay discards its flow-executor cookies. It
   does not delete the Authentik session, because that needs an admin-API token
   the relay must not hold.
7. The client accepts a token only with `aud=<client_id>`, an issuer on its
   allow-list, and `exp` present.

**Tokens and audience.** `aud` is the `client_id`. The issuer is
`<host>/application/o/<client_id>/`, where `<host>` is the exact host string the
relay calls. azb-AD's own API does not add first-party `client_id`s to
`OIDC_ACCEPTED_AUDIENCES`, so it keeps rejecting their tokens (G19).

**Access per client.** Each application has a group policy binding to the
`<client_id>-*` groups. A user in none of them is refused at `/authorize` (G11).

**Role groups.**

- Named `<client_id>-<role>`, lowercase, at the top level of `ou=groups`.
- Created only by azb-AD, through `/api/groups/*`. That path adds the
  `uidObject` class with `uid=<cn>` so the group syncs (G14) and enforces the
  name rules (G17). Client apps create no LDAP groups.
- Membership is managed by azb-AD admins through the same API. A
  building-scoped or client-scoped admin grant needs its own ARD.

**Group sync (amends ARD-007).** The `azblink-ldap` source syncs groups, scoped
to registered clients only. The filter is
`(&(objectClass=groupOfNames)(|(cn=<client_a>-*)(cn=<client_b>-*)…))`, with
`group_membership_field: member` and the `openldap-cn` name mapping. `IT-Admins`
and every other group are never synced, so azb-AD admin access is unchanged.
After any membership change to a registered client's group, the directory API
triggers a source sync, so a removed role is gone by the next refresh. Users stay
keyed on `uid`.

**Lockout.** Authentik's username-keyed reputation policy on the shared flow
trips at 3 failures, below ppolicy's `pwdMaxFailure` of 5. A burst through a
relay then blocks that username in Authentik only, and the LDAP account (XMPP,
SIP) stays usable (G1). `AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS` lists each
relay's egress CIDR. This is required before any real users.

**Relay path.** The relay calls Authentik on the docker network
(`http://authentik-server:9000`), or a sibling VM calls the published port. The
Cloudflare tunnel is not a supported relay path: through it Authentik sees
`cloudflared`, not the relay (G2).

**SafeNest, the first client.**

- One client per building box, `safenest-<building>`. The building id matches
  `^[a-z0-9]{2,16}$` and has no hyphen, so `safenest-a1-*` cannot match
  `safenest-a1annex-*` groups.
- Roles are per building: `safenest-<building>-{admin,staff,resident,visitor}`.
  The token's `groups` claim lists every group the user has, so each box honours
  only its own building's groups.
- One shared azb-AD is the only directory. A building is a client, not a tenant.
- The dev client is `safenest-dev`, redirect URI
  `http://localhost:5173/auth/callback`.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Password endpoint in azb-AD (B2) | Brings back the endpoint ARD-002 deleted and routes every client's passwords through azb-AD. B1 keeps the password in the client that collected it. |
| Branded Authentik redirect | Keeps browser SSO, but the client loses its own login form, which is the requirement. Still open to any client that prefers it. |
| One rule set per client | Each later client would reopen TTL, MFA and logout. Fixed rules make onboarding a config change. |
| One azb-AD per building | Splits the directory a resident or staff member needs across boxes. Buildings differ in role, not in identity. |
| Global role groups (`safenest-admin`) | An admin in building A who is a resident in B would get admin on B's box. The access binding limits who logs in, not which role applies. |
| Sync every LDAP group | Would merge LDAP's own `cn=IT-Admins` with the seed's Authentik `IT-Admins`, which grants azb-AD admin (G12). |
| `entryUUID` as the uniqueness field | Fixes group sync but re-keys every synced user. The `uidObject` class on role groups is local to the new groups. |
| Clients create their own LDAP groups | Needs an LDAP write credential in each client and skips the name checks. |
| Delete the Authentik session on logout | Needs an admin-API token in every relay. Refresh-token revoke plus a 15-minute access token bounds the exposure. |

## Consequences

- **Positive:** a client keeps its own login form with no new azb-AD endpoint
  and no password passing through azb-AD. One identity still serves UC (Plane A)
  and web (Plane B). A new client is about 1–2 h of config.
- **Negative / trade-offs:** no browser SSO between a headless client and other
  apps; the user signs in again. After logout the access token stays valid until
  it expires (at most 15 minutes). A role removal reaches the client at its next
  refresh, not immediately. The client's backend sees the password, so a
  compromised relay leaks credentials for the users who log in through it.
- **Risks:** anyone who can write `ou=groups` can create a `<client>-*` group and
  so grant a role. Group writes stay behind azb-AD's `user_management` and LDAP
  admin, and E2b gets a `/security-review`. Authentik flow-executor changes can
  break relays; the E4 contract test runs per registered client.
- **ARD-002 Plane B** gains this client class. **ARD-007** loses its "no group
  sync" non-goal for registered clients' groups only; admin RBAC through LDAP
  groups stays deferred.

## References

- Related ARDs: ARD-002 (amended), ARD-007 (amended), ARD-006, ARD-017
- Gap report and decision log: `docs/reports/2026-09-25-safenest-headless-login-gap-report.md`
  (decisions 1–20, gaps G1–G21)
- Contract tests: `tests/test_headless_first_party_login.py` (E4). The probes they replace,
  `tools/safenest-headless-probe/`, are in git history only
- Decision PR: #330 (E1). Implementing PRs: #332 E2 (seed clients), #333 E2b (group
  sync), #334 E4 (contract tests). Still to come: E3 (shared flow), E5 (lockout and
  trusted proxies). Accepted once E2, E2b and E4 had merged.
- Spec sections: `spec/03-data-architecture.md`, `spec/04-authentication.md`, `spec/06-deployment.md`,
  `spec/08-integration-points.md`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link.
     Body above this heading is frozen once status=accepted. -->

### 2026-10-02: E5 as built, where the lockout check sits and what it guarantees (#338)

The mechanism is unchanged: Authentik's username-keyed reputation policy on the shared flow,
tripping at 3 failures. An adversarial review and live probes showed that three settings are
needed for the Lockout paragraph to hold:

- The policy is bound, negated, on the password stage's own binding, which Authentik re-evaluates
  on every request before the LDAP bind. A deny stage after it stops the flow unless the password
  stage succeeded, and fails closed. The same guard on the user-login binding covers flow plans
  stored in sessions before the deny stage existed. A deny stage in front of the password stage is evaluated once
  per executor session, so a session identified while the score was clean still reached the bind.
- `check_ip` is off. Otherwise every user behind one relay shares the relay's row.
- The tenant's `reputation_upper_limit` is 0. With the default +5, a user's own sign-ins bank extra
  failures and ppolicy's 5 locks LDAP first.

The guarantee holds for sequential traffic through the shared flow. It does not cover parallel
requests (all pass the check before a failure is recorded), a reputation row's expiry (24 h after
its first failure, while ppolicy keeps failures until a successful bind), the brand default flow
(not throttled), or LDAP binds outside Authentik. Closing those needs ppolicy changes
(`pwdMaxFailure` margin, `pwdFailureCountInterval`), which are an owner decision. A successful
sign-in no longer heals a score; an admin unblocks a user by deleting that username's reputation
rows (spec 08).

### 2026-10-07: the lockout on web sign-in, ppolicy's failure window, and the parallel bound (G22–G24) (#345)

The owner approved closing the three limits above. Live probes on dev changed one of them.

- **G22, web sign-in.** The brand flow `default-authentication-flow` binds LDAP in its password stage too,
  so it gets the same lockout: the same reputation check, guard and deny stage, its own `<flow>-*` objects,
  and the same username rows. This widens the Lockout paragraph from "the shared flow" to both flows. The
  password binding's policy engine mode must be `all`, because the flow's own "password needed" policy
  outvotes a negated check under `any` (probe: under `any`, a throttled user signed in). The login-binding
  guard is required here as well (probe: with neither the guard nor the deny stage, a throttled user got a
  session with no password). Trade-off: anyone who can reach Authentik can block any username on web
  sign-in for 24 h with 3 attempts, `akadmin` included. Spec 08 has the unblock runbook, including the path
  for when no admin can sign in.
- **G24, ppolicy forgets.** `pwdFailureCountInterval` goes from 0 to 3600. That is below the reputation
  rows' 24 h, so LDAP forgets one lockout's failures before Authentik does, and above `pwdLockoutDuration`
  (300), so a lock that ends does not grant 5 fresh tries. Probe: two 3-failure lockouts separated by the
  interval leave LDAP unlocked; with 0 the second one locks it. This is LDAP-wide (XMPP binds too). It also
  caps direct LDAP guessing that never trips the lock at 4 per hour.
- **G23, parallel requests: measured, not closed.** The gap report sized the race at 8 per server replica
  (`web.workers × web.threads`), which made a `pwdMaxFailure` margin of `3 + 8 × replicas + 1` (12) look
  sufficient. On 2026.5 the web workers are ASGI and Django runs each request in its own thread, so
  `web.threads` limits nothing.
  - 32 of 32 and then 90 of 96 parallel password POSTs reached the check before any failure was recorded.
    The other 6 failed on database connections.
  - A 16-wide burst locked an LDAP account.
  - The bound is the connection pool, so no margin closes it, and raising `pwdMaxFailure` would only give
    direct LDAP binds more guesses. `pwdMaxFailure` stays 5, and the "trips below 5" wording stands.
  - The accepted residual: one burst per username per reputation-row lifetime locks LDAP for 300 s. For a
    local account the same burst buys that many password guesses instead of 3.
  - Closing it needs a pre-bind atomic reservation per username. That is a new mechanism and would need its
    own amendment.

The remaining limits are LDAP binds outside Authentik and the unthrottled minutes between a row's expiry and
its cleanup.

### 2026-10-08: an atomic bind budget closes the parallel bound and the expiry window (G23) (#355)

The 2026-10-07 amendment left G23 open: it needed a pre-bind atomic reservation per username. This adds
one. The reputation check stays as the 24 h block users and admins see. The budget sits next to it on the
same password binding and caps what reaches LDAP.

- **Mechanism.** On every password POST, an expression policy on the password binding reserves one of the
  username's 3 binds. The reservation is a single Postgres `INSERT … ON CONFLICT DO UPDATE … WHERE … RETURNING`
  on a counter row, so parallel POSTs cannot all pass. When no row comes back, the reservation is refused, and
  the existing deny stage ends the flow. Once a stage has authenticated the user, the deny and login guard
  hands back that session's reservation. The guard does this once per session, using a key it pops from the
  server-side session. So successes do not use up the budget, and failures stay counted. A refused attempt
  reserves nothing.
- **Shared and normalised.** Both flows use one counter per username, so web sign-in and a relay cannot
  each spend 3 binds. The key is the pending user's username after NFKC, whitespace collapsing and
  lowercasing. Identification already resolves case variants and email to the same user. The normalisation
  covers anything that reaches the bind under another spelling.
- **Window.** The counter resets when 3900 s pass with no reservation. That is `pwdFailureCountInterval`
  (3600) plus a margin for a bind still running. So the budget refills only after LDAP has dropped every
  failure it counted. The reset is done in the reservation statement itself. It does not depend on
  Authentik's cleanup task, which closes the window where an expired reputation row hid failures (up to
  5 min).
- **Store.** The counter is a `Reputation` row with identifier `ldap-bind-budget:<username>` and IP `::`.
  `ReputationPolicy` matches identifiers exactly and no client has IP `::`, so the reputation check never
  sees the row. An admin can still see and delete it. Authentik 2026.5 keeps its cache, sessions and tasks
  in Postgres. Redis is not involved: stopping it changed nothing (probe below).
- **Fail closed.** The budget binding is not negated and has `failure_result` false. If the policy errors
  or the database is unreachable, the bind is refused. The seed also enforces `re_evaluate_policies` on the
  password binding, because both checks depend on it. It also makes policy-binding repairs with PUT, because
  2026.5 answers PATCH on a policy binding with 405.
- **Trade-offs.** At most 3 password sign-ins per username can be in flight at once. The rest are refused,
  and a retry works. Unblocking now needs the budget row deleted as well as the reputation rows (spec 08
  runbook).

Live probes on dev, using the same method as #345: a synced LDAP user, sessions identified first, then
wrong-password POSTs released together.

| Probe | Before | After |
|---|---|---|
| 2 prior failures, 32 parallel | 32 reached the bind; LDAP locked | 1 reached; LDAP 3 failures, unlocked |
| 2 prior failures, 96 parallel | 90 reached (6 HTTP errors); LDAP locked | 1 reached (6 HTTP errors, no bind); unlocked |
| 0 prior, 96 parallel, both flows, 5 name spellings | n/a | 3 reached (6 HTTP errors, no bind); unlocked |
| Reputation rows deleted after 3 failures, 32 parallel | n/a | 0 reached |
| Budget policy errors, right password, then 16 parallel | n/a | refused; 0 reached |
| Redis stopped, 32 parallel | n/a | 3 reached; sign-in works |
| 10 parallel right passwords, both flows | n/a | 3 signed in, 7 refused; counter back to 0 |

Remaining limit: LDAP binds outside Authentik, such as XMPP. The budget leaves them a margin of 1 below
`pwdMaxFailure` and does not count them.

### 2026-10-20: naming rules become invariants (ARD-019)

ARD-019 relies on the `<client_id>-<role>` convention for a scoped grant, so three rules now hold for
every caller: first-party client ids may not nest (`safenest` beside `safenest-a1` is refused by the
seed's `parse_first_party_clients` and by the API at startup), a client's role groups never carry
RBAC permissions (422), and user uids starting with `<client_id>-` and org names equal to a client
id are reserved (422; an admin may still create the org at onboarding). See ARD-019 §1 and §4.

### 2026-10-21: a source throttle in front of the username lockout (audit blocker B5) (#385)

The owner chose on 2026-10-21 to build this instead of accepting the risk. Before, 3 wrong passwords
from anywhere blocked a username on both flows for 24 h. So anyone who could reach Authentik could
lock out any user, `akadmin` included (the trade-off the 2026-10-07 amendment accepted). The username
lockout and the bind budget stay. In front of them, each source now gets a smaller share.

- **Source.** The client IP Authentik records, `ak_client_ip` in a policy. Authentik's Go server
  honours `X-Forwarded-For` only from `AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS` (default loopback;
  each relay's egress /32 is added there, as the Lockout paragraph already requires). From any other
  peer, the IP is the socket peer and a spoofed header is ignored. Nothing new is configured.
- **Mechanism.** The bind-budget policy on the password binding does three things on each password
  POST, in this order:
  - It refuses when the source's reputation row for the username (identifier = username, IP = source,
    the row Authentik's `login_failed` writes) sums to −2 or less.
  - It reserves one of the source's 2 binds for the username. This is a second budget row, identifier
    `ldap-bind-budget:<username>` and IP = source, reserved with the same atomic upsert and 3900 s window.
  - It then reserves one of the username's 3 binds (the `::` row). If that is refused, it gives the
    source's reservation back.
  A success gives both back through the existing guard. A session that took its reservation before
  this change holds only the username's, and the guard still returns it.
- **What it guarantees.** One source can spend at most 2 of a username's 3 failures, whether its
  requests are sequential or parallel. After that it is refused, even with the right password. The
  username never reaches −3 from one source, so the user still signs in from any other source.
  Failures from two or more sources still block the username as before, and LDAP still sees at most 3.
- **Trade-offs.**
  - A user who mistypes twice in one place is refused there until the row expires (24 h) or an admin
    unlocks. Before, 3 typos refused them everywhere.
  - At most 2 sign-ins per username per source can be in flight at once (was 3 per username).
  - Everyone behind one address is one source: a NAT, or a front proxy that is not on the trusted list.
    For example, the dev Cloudflare tunnel's `cloudflared`, or a relay left off the list. Through such
    a path, 2 failures block that username for everyone on the path.
- **Residual.** Two attacker sources still block a username for 24 h. Raising the per-username limit
  is bounded by ppolicy's `pwdMaxFailure` of 5 and XMPP's margin (2026-10-08 amendment).
- **Unblock.** Unchanged. The source budget rows share the `ldap-bind-budget:<username>` identifier,
  so the spec 08 runbook and `POST /api/users/{uid}/unlock` already delete them.

Live tests on a private stack (fresh Authentik 2026.5, default trusted CIDRs). The relay is the server
container's loopback setting `X-Forwarded-For` (`tests/test_source_throttle.py`):

| Probe | Result |
|---|---|
| 4 wrong passwords from one relayed IP | 2 reached LDAP, 2 refused; that IP refused with the right password; the user signed in from another IP on both flows, and directly |
| 16 parallel wrong passwords from one relayed IP | 2 reached LDAP; the user signed in from another IP |
| 4 wrong passwords from an untrusted peer, a different spoofed `X-Forwarded-For` each | 2 reached LDAP, 2 refused; no row names a spoofed IP |
| 2 + 1 wrong passwords from two relayed IPs | username blocked everywhere; LDAP 3 failures, unlocked |
| 8 parallel right passwords from one source | 2 signed in; every reservation back to 0 |

### 2026-10-22: the production relay path (ARD-021)

The Relay path paragraph named the docker network or a sibling VM's published port. In
production a relay is a building box on a routed private path with a static IP (its /32 in
`authentik_trusted_proxy_cidrs`). It resolves the public host name to the directory box's
private IP and calls Authentik over TLS on `:443`, where Authentik terminates TLS itself. So
`<host>` in the issuer rule is `https://<azblink_public_host>`, the same string browsers get,
and Authentik still sees the relay's own address. The Cloudflare tunnel remains unsupported
for relays. See ARD-021 §3.

### 2026-10-22: clients registered at runtime (ARD-022)

A first-party client is also registered by `POST /api/clients/onboard` (ARD-022), which builds
the same provider, application and `<client_id>-*` access policy the seed builds, and adds the
client's `(cn=<client_id>-*)` term to the LDAP source. The registry the API acts on is
`AUTHENTIK_FIRST_PARTY_CLIENTS` plus the `first_party_clients` table; where they differ, the env
entry wins. The nested-id refusal applies across both: the onboard call refuses a nesting id
(409), and a nesting row is skipped at load. The seed keeps every group-filter term already on the
source, and creates the headless flow even with no env client. Where this differs from the body,
this amendment wins.
