---
# ARD metadata — authoritative source of truth.
# The summary block below is maintained BY HAND and must be kept consistent with
# these fields. No generator exists: `just new-ard` and the regenerating
# pre-commit hook this template used to reference were never built.
status: proposed              # proposed | accepted | superseded | deprecated
accepted_at:                  # YYYY-MM-DD — date this ARD file was merged. Blank until accepted.
decision_effective_date:      # YYYY-MM-DD — date original decision shipped (for retro-ARDs only; same as accepted_at for forward-looking).
supersedes: []                # list of ARD-XXX this replaces; [] if none
superseded_by: []             # list of ARD-YYY that replaced this; [] if none
pr:                           # implementing PR number ("#NN") — blank if decision-only (PR-1 of §6.1)
spec_sections_affected: []    # e.g. ["04-authentication", "07-security"]
---
<!-- summary:begin -->
<!-- Hand-written restatement of the frontmatter above. Keep the two in sync. -->
<!-- summary:end -->

# ARD-NNN: Title

## Context

Why did this decision need to be made? What problem or constraint triggered it?

<!-- 2-5 sentences. Written for both humans and AI agents — include enough context
     that an agent arriving fresh can understand the "before" state. -->

## Decision

What was decided? Be specific about what changed.

<!-- Bullet points preferred. Include the "what" and "how". -->

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Option A    | ...          |
| Option B    | ...          |

## Consequences

Positive, negative, and neutral impacts.

## References

- Related ARDs: ARD-XXX
- PR: #NN
- Spec sections: `spec/NN-section.md`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link.
     Body above this heading is frozen once status=accepted. -->
