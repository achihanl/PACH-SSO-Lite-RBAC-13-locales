---
status: accepted
accepted_at: 2026-03-17
decision_effective_date: 2026-03-17
supersedes: []
superseded_by: []
pr: "#78, #79"
spec_sections_affected: ["03-data-architecture", "05-provisioning"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-03-17 • **Effective:** 2026-03-17 • **PR:** #78, #79
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 03-data-architecture, 05-provisioning
<!-- summary:end -->

# ARD-004: Profile Services Restructuring

## Context

Config templates (profiles) stored XMPP/SIP configuration as flat columns directly on the `config_templates` row (`xmpp_enabled`, `sip_enabled`, `xmpp_domain`, `xmpp_ws_url`, `sip_domain`, `sip_wss_url`, `next_extension`, `ext_range_start`, `ext_range_end`). Adding a new service type (e.g., Matrix, WebRTC) would require adding new columns via schema migration and updating all backend/frontend code that reads or writes profile fields. SSO config and QR settings columns were also embedded directly on the profile row, adding complexity that was no longer needed.

## Decision

Restructure UC services into an extensible `profile_services` child table:

- **Remove SSO + QR** (PR #78): Drop `sso_config`, `qr_settings` columns from `config_templates`. Delete `qr_signing.py`, QR endpoints, SSO config endpoints, and all related frontend components. Rename `provision_tokens` to `device_provisions`.
- **Create `profile_services` table** (PR #79): Child of `config_templates` with CASCADE delete. Each row represents one service type per profile.
  - `service_type` discriminator column (e.g., `xmpp`, `sip`, or any future string)
  - `config` JSON column validated per type by Pydantic models
  - Optional `next_counter`, `counter_start`, `counter_end` for service-specific allocation (e.g., SIP extensions)
  - `enabled` boolean for independent toggling
  - `UNIQUE(profile_id, service_type)` constraint
- **UID allocation stays on profile**: `next_uid_number`, `uid_range_start`, `uid_range_end` remain on `config_templates` (shared across services).
- **Device cap stays on profile**: `max_devices_per_user` is policy, not per-service.
- **Unknown service types accepted**: Freeform JSON config for extensibility.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Add more flat columns per service type | Does not scale -- each new service requires migration + code changes across stack |
| JSON blob with all services in one column | Loses relational querying, counter atomicity, and per-service constraints |
| Separate tables per service type | Over-normalized -- adds N tables per N service types, complex JOINs |

## Consequences

- **Positive:** New service types can be added without schema migrations -- just insert a `profile_services` row with any `service_type` string
- **Positive:** Each service is independently toggleable and configurable with its own allocation counters
- **Positive:** Cleaner profile schema -- `config_templates` only holds identity, policy, and shared UID allocation
- **Negative:** Slightly more complex queries (JOIN required to get service data with profile)
- **Negative:** Migration 025 required to move existing XMPP/SIP data from columns to child rows
- **Risks:** Existing integrations that expect flat profile fields must be updated (addressed in PR #79)

## References

- Design spec: `docs/superpowers/specs/2026-03-17-profile-services-restructuring-design.md`
- Implementation plan: `docs/superpowers/plans/2026-03-17-profile-services-restructuring.md`
- Migration: `migrations/024_remove_sso_qr.sql`, `migrations/025_profile_services.sql`
- PR #78: SSO + QR removal
- PR #79: Profile services restructuring

## Amendments

<!-- None yet. -->
