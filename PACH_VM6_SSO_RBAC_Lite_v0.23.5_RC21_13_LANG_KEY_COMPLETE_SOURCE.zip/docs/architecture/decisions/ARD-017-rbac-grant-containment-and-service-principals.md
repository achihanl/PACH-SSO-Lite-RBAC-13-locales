---
status: accepted
accepted_at: 2026-09-18
decision_effective_date: 2026-09-11
supersedes: []
superseded_by: []
pr: "#304"
spec_sections_affected: ["04-authentication", "06-deployment", "07-security", "08-integration-points"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-09-18 • **Effective:** 2026-09-11 • **PR:** #304
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 04-authentication, 06-deployment, 07-security, 08-integration-points
<!-- summary:end -->

# ARD-017: RBAC Grant Containment and API-to-API Service Principals

## Context

Three gaps stood between this directory and production use by other platforms
(2026-09-11 SSO scout report):

- **Privilege escalation.** `PATCH /api/groups/{cn}/permissions` and
  `POST /api/groups/{cn}/members` were gated on `user_management` alone and
  never compared the grant with the caller's own rights. Any `group_member_roles`
  row confers the whole group's permissions (the `role` value is not consulted),
  so a delegated user manager could give itself `system_configuration` either by
  editing a group it belongs to or by joining a group that already carries it.
  Reproduced against the dev stack: HTTP 200.
- **No service identity for the REST API.** The only machine path was
  `client_credentials` on the web app's *public* provider with a per-user
  `app_password` — a service impersonating a human. API keys were dropped in
  migration 018 and nothing replaced them.
- **API docs unreachable and undeclared.** FastAPI served `/docs` and
  `/openapi.json` at the app root, outside Traefik's `PathPrefix(/api)` router,
  and the document declared no security scheme.

## Decision

- **Grant containment.** `auth.assert_can_confer(claims, perms)` runs on every
  write that grants RBAC permissions — setting a group's permissions (only the
  newly added ones count), adding a member, and upserting a member role. A caller
  outside `OIDC_ADMIN_GROUP` may confer only permissions it already holds; else
  403. It fails **closed** (503) when the RBAC store is unreachable — unlike the
  read ladder's ARD-012 §3 fall-through, a grant never proceeds unverified.
  Removing permissions is always allowed.
- **Service principals.** Each API-to-API caller gets a dedicated **confidential**
  Authentik provider whose `grant_types` is `client_credentials` only, named
  exactly its `client_id` (seeded from `AUTHENTIK_SERVICE_CLIENTS`). Authentik
  mints tokens for its generated account `ak-<client_id>-client_credentials`.
  - `OIDC_ACCEPTED_AUDIENCES` (CSV, default `OIDC_AUDIENCE`) admits the service
    `aud`; the per-provider issuer joins `OIDC_ACCEPTED_ISSUERS`.
  - `OIDC_SERVICE_PERMISSIONS="client_id:perm|perm,…"` declares each service's
    RBAC grants statically. They apply only when `azp` is that `client_id` **and**
    `preferred_username` is the generated account name, so a human's app-password
    token minted via the same provider gains nothing.
  - The `ak-` uid prefix is reserved at `POST /api/users/create` so an LDAP entry
    can never collide with a service principal once synced.
- **API docs.** Served at `/api/docs`, `/api/redoc`, `/api/openapi.json`;
  `DOCS_ENABLED` defaults on in dev environments and off elsewhere. An
  `HTTPBearer` scheme is declared (declaration only; verification unchanged).

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Gate permission writes on `system_configuration` | Still lets a `system_configuration` holder grant anything, and blocks legitimate delegation of lesser rights. Containment is the general rule. |
| Reintroduce API keys | Second credential store, second revocation path; Authentik already issues short-lived, revocable service tokens. |
| Service RBAC via `group_member_roles` rows | Rows are written through LDAP group membership; service accounts have no LDAP entry. Static config is auditable and survives a PostgreSQL outage. |
| Map service permissions from token `scope` | Needs a custom Authentik scope mapping per permission; deferred until a service needs per-request scope narrowing. |

## Consequences

- Delegated operators can no longer escalate; `tests/test_rbac.py::TestRBACNoEscalation`
  pins it and fails against the previous implementation.
- A new integrating service costs one `AUTHENTIK_SERVICE_CLIENTS` entry, one
  accepted issuer/audience, and one `OIDC_SERVICE_PERMISSIONS` entry — a config
  change and restart, not code. Pinned by `TestServiceClientRBAC`.
- Service grants live in env, not the admin UI; changing them is a deploy.
- The web provider still carries `client_credentials` for the test suite's user
  M2M fixture (`TODOS.md`); moving it off is follow-up work.
- OpenAPI baseline gains `securitySchemes.HTTPBearer` and per-operation
  `security` on 92 of 98 operations.

## References

- Related ARDs: ARD-002, ARD-006, ARD-009, ARD-012
- PR: #304 (merged 2026-09-11)
- Spec sections: `spec/04-authentication.md`, `spec/06-deployment.md`,
  `spec/07-security.md`, `spec/08-integration-points.md`

## Amendments

### 2026-10-20: a third grant kind, the client-scoped principal (ARD-019)

ARD-019 adds a grant beside the admin group and RBAC permissions: a service client listed in
`OIDC_SERVICE_CLIENT_SCOPES` is bound to one first-party client and may run nine user and group
calls on that client's roles and users. It uses this ARD's identity check (`azp` and
`ak-<azp>-client_credentials`). It holds no RBAC permission, so `require_permission`,
`require_directory_read` and `assert_can_confer` treat it as holding nothing, and startup refuses a
principal that is both scoped and listed with permissions in `OIDC_SERVICE_PERMISSIONS`. See ARD-019.
