---
status: accepted
accepted_at: 2026-07-29
decision_effective_date: 2026-07-29
supersedes: []
superseded_by: []
pr:
spec_sections_affected: ["04-authentication", "07-security"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-07-29 • **Effective:** 2026-07-29 • **PR:** —
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 04-authentication, 07-security
<!-- summary:end -->

# ARD-012: Authorization Posture When the Authorization Stores Are Unreachable

## Context

Authorization in this system reads state from PostgreSQL on every request: account locks, RBAC
permission grants, IP-block records, and the auth-failure audit trail. Every one of those reads is
wrapped in a bare `except Exception` that swallows the failure and continues. The net effect is that
a PostgreSQL outage silently degrades authorization rather than failing it.

That posture predates PR #226 — it was implicit in three `except Exception` blocks buried in
`main.py` and could not be tested at all, because reaching those branches meant importing a module
that opened a database connection at import time. PR #226 extracted the auth ladder into
`src/backend/auth.py` and added `tests/unit/test_auth_fail_open.py`, which pins the behaviour. Those
tests deliberately assert *what is*, not *what should be*. A test file is not a ruling, and nobody
had decided whether an operator losing PostgreSQL should also lose lock enforcement.

The degradation is broader than "authorization falls back to the OIDC admin group". Five distinct
behaviours change when PostgreSQL is unreachable:

| Site | Behaviour when PostgreSQL is down | Silent? |
|------|-----------------------------------|---------|
| `auth.py:191-206` — `check_account_locked` | Lock enforcement skipped entirely; a locked account with a valid OIDC token is admitted | Yes |
| `auth.py:242-247` — `get_user_permissions` | RBAC lookup fails; falls through to the OIDC admin-group check | Logs per occurrence |
| `auth.py:277-282` — `require_directory_read` | Same fall-through for directory reads | Logs per occurrence |
| `auth.py:157-166` — `record_auth_failure` | No audit record written for the outage window | Yes |
| `auth.py:169-183` — `count_failures_by_ip` / `block_ip` | No new IP auto-blocks are created | Yes |
| `rate_limit.py:200-215` — `is_ip_blocked` | Fails open; the Redis `blocked_ip:` cache still enforces recent blocks for its 60s TTL, after which blocking stops entirely | Yes |

Read together, the current posture is simultaneously too permissive for the wrong principals and too
restrictive for the right ones. An OIDC admin whose account has been explicitly locked walks
straight in, and the abuse controls that would notice silently stop. Meanwhile a legitimate
non-admin operator is denied outright, because their RBAC grants are exactly the state that has
become unreadable. The people who should keep working cannot; the accounts that should be blocked
can.

The obvious alternative — fail closed — is not free here. ARD-002 removed breakglass entirely, so a
hard fail-closed posture converts a PostgreSQL outage into a total admin lockout with no recovery
path short of restoring the database.

## Decision

The ruling is **availability-preserving enforcement**: keep lock enforcement real during a
single-store outage by giving it a second place to read from, and fail closed only when
authorization state is genuinely unknowable.

### 1. Account-lock state is mirrored into Redis; the lock check reads through

- Lock records are dual-written: PostgreSQL remains authoritative, and each lock is mirrored to
  Redis under a key namespace (`azblink:account_lock:<uid>`) with a TTL that covers the lock
  duration. This is the pattern `rate_limit.py:189-207` already uses for `blocked_ip:`, applied to
  the second deny-signal that needs it.
- `check_account_locked` consults PostgreSQL first and falls back to the Redis mirror when the
  PostgreSQL read raises. A hit means locked; the request is denied exactly as it is today.
- **Fail closed only when both stores are unreachable.** If neither PostgreSQL nor Redis can answer,
  lock state is unknown and the request is denied with `503`, not admitted.

### 2. The mirror must be provably complete, or it does not get trusted

A cache that holds only positive entries is safe to read as authoritative *only* if every lock
reached it. A lock created while Redis was down would be absent, and a miss would read as "not
locked" — silently reintroducing the hole this ARD closes.

The implementation must therefore carry a completeness sentinel: a key established by a full
re-sync from PostgreSQL and cleared whenever a mirror write fails. During a PostgreSQL outage the
Redis mirror is trusted **only while the sentinel is present**. An absent sentinel means the mirror
may be incomplete, which is the both-stores-unknowable case and therefore fails closed.

### 3. The remaining degradations stay fail-open, deliberately

- **RBAC permission lookup** (`get_user_permissions`) continues to fall through to the OIDC
  admin-group check. Group membership arrives in the verified token itself and needs no store, so
  admin access survives an outage by construction. This is the property that keeps a PostgreSQL
  outage recoverable at all under ARD-002's no-breakglass rule, and it is retained on purpose.
- **Auth-failure audit** (`record_auth_failure`) and **IP auto-block creation**
  (`count_failures_by_ip` / `block_ip`) continue to fail open. Both are write paths; failing the
  request because a write failed converts a degraded audit trail into a denial of service, which is
  a strictly worse trade.
- **`is_ip_blocked`** continues to fail open past the Redis cache TTL. Unlike account locks, IP
  blocks are an automated abuse-control heuristic rather than an administrator's explicit decision
  about a principal, and the same completeness problem applies without the same stakes.

### 4. Every degraded path logs on state transition

All six sites adopt log-once-per-transition semantics: one warning when authorization enters
degraded mode, one info when it recovers — never silence, never a line per request. Four of the six
sites are fully silent today, which is the same failure mode ARD-011 records for the activity-bus
Redis fallback: degradation nobody can observe is indistinguishable from correct operation, and that
is precisely how this posture survived undecided for as long as it did.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Ratify the current fail-open posture as-is | Costs nothing to adopt, but leaves an explicitly locked administrator able to regain admin access for the full duration of any PostgreSQL outage. A lock is an administrator's deliberate decision about a principal; silently suspending it during an infrastructure failure inverts the intent at exactly the moment the account is most likely to matter. |
| Hard fail-closed on any authorization-state read failure | The lock check cannot complete for *anyone* during an outage, so this denies every user rather than just locked ones. With no breakglass under ARD-002, a single-store outage becomes a total admin lockout — including lockout of the operators who would restore the database. Trades a narrow, bounded exposure for an unbounded availability failure. |
| Fail closed on lock enforcement, fail open on group membership, with no Redis mirror | The intuitively appealing middle path, and it does not actually work: without a second store to read from, "fail closed on lock enforcement" still denies everyone, because the check cannot answer for any principal. It is hard fail-closed wearing a narrower label. The Redis mirror is what makes the middle path implementable rather than rhetorical. |
| Cache lock state in process memory instead of Redis | Per-worker memory diverges across the `UVICORN_WORKERS:-2` default — the same class of bug ARD-011 fixed for activity events. An admin-issued lock would be enforced by whichever worker happened to observe it. |
| Trust a positive-only Redis mirror without a completeness sentinel | A lock written while Redis was unavailable is absent from the mirror, so a miss reads as "not locked" and the locked account is admitted during the next PostgreSQL outage. That is the exact hole this ARD exists to close, reintroduced one layer down. |

## Consequences

**Positive**

- An explicitly locked account stays locked during a PostgreSQL outage, which is the security
  property the current posture loses.
- Availability is preserved in the common case. Single-store outages are the overwhelmingly likely
  failure; the ruling only denies in the both-stores-down case.
- Failing closed when both stores are down costs little in practice: with neither PostgreSQL nor
  Redis reachable, the API cannot serve most endpoints anyway. The ruling adds enforcement to a
  state that is already an outage rather than manufacturing a new one.
- Degraded authorization becomes observable for the first time at four of the six sites.
- `tests/unit/test_auth_fail_open.py` gets a decision to be measured against. Its assertions on lock
  enforcement will need rewriting to match the ruling; its assertions on the RBAC and audit paths
  are ratified as-is by §3 above.

**Negative / trade-offs**

- A bounded staleness window. An administrator issuing a lock during a PostgreSQL outage cannot
  reach the authoritative store at all, and a lock issued normally propagates to the mirror on
  write; the exposure is the interval between a mirror-write failure and the sentinel being cleared.
- Authorization gains a second infrastructure dependency. Redis moves from an optimisation
  (`blocked_ip:` caching, activity fan-out) to a component whose absence changes authorization
  behaviour. ARD-011 already made realtime delivery depend on it; this extends that dependency into
  the auth path.
- Both-stores-down now denies rather than admitting OIDC admins. Recovery requires restoring either
  store — there is no breakglass under ARD-002 and `DEV_AUTH_TOKEN` is never set in production. This
  is accepted on the reasoning above: that state is already a full outage.
- Implementation cost is real and is not carried by this ARD. The dual-write, the sentinel, the
  re-sync on startup and the test rewrite land in a follow-up ticket.

**Neutral**

- No change to the OIDC verification path itself. This ARD governs what happens *after* a token
  verifies, when the stores behind authorization cannot answer.

## References

- Implementation follow-up: #242, covering §1–§4 and the rewrite of the pinned lock assertions. This
  record is decision-only (PR-1 of SOP §6.1), hence a blank `pr:` field.
- Code: `src/backend/auth.py` (`_claims_from_auth_header`, `require_permission`,
  `require_directory_read`), `src/backend/rate_limit.py` (`IPBlockingMiddleware.dispatch`),
  `src/backend/deps.py` (`ip_block_redis`)
- Tests: `tests/unit/test_auth_fail_open.py` (pins the pre-ruling behaviour), `tests/contract/test_auth_matrix.py`
- Issues: #228 (this ARD), #226 (the decomposition that made the behaviour visible and testable)
- Related ARDs: ARD-002 (Authentik-Only OIDC — removed breakglass, which is why hard fail-closed is
  expensive here), ARD-009 (Directory-Read Authorization & Lock-DoS Hardening — established the lock
  and directory-read gates this ARD governs the degraded behaviour of), ARD-011 (Redis Cross-Worker
  Fan-Out — established both the shared `ip_block_redis` client and the log-once-per-transition
  convention adopted in §4)
- Spec sections: `04-authentication`, `07-security`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->

### 2026-07-31 — The sentinel carries a TTL; §1's dual-write premise was wrong

Implementing §1–§4 surfaced a factual error in this record's own premise, corrected here
rather than silently diverged from in code.

**§1 states that "a lock issued normally propagates to the mirror on write."** No lock is
issued normally. `OrgDB.lock_account()` has **no production caller**: ARD-009/H4 removed the
auto-lock path (it let an attacker lock any victim, including admins, by naming them in a
signature-invalid token) and no administrator lock endpoint replaced it. `POST /api/users/{uid}/unlock`
and `GET /api/users/{uid}/lock-status` exist; there is no lock endpoint. Rows therefore enter
`account_locks` only out-of-band, where a dual-write cannot observe them.

That breaks §2's soundness argument as written. A sentinel established by a one-time
re-sync at startup would assert a completeness the mirror does not have the moment anyone
inserts a lock directly — and a mirror miss then reads as "not locked", which is precisely
the failure §2 exists to prevent.

**Amendment.** The completeness sentinel is a TTL'd key refreshed by each successful full
re-sync, not a one-time flag:

- `azblink:account_lock_mirror:synced`, TTL = 2 × the re-sync interval (120 s at a 60 s interval).
- A lifespan background task re-syncs from PostgreSQL every interval and renews the sentinel
  only on success. A failed or skipped pass never extends the claim.
- A failed mirror write still clears the sentinel immediately, as §2 requires.
- Consequently: re-sync stalls → sentinel lapses → mirror untrusted → lock check fails closed.

Staleness is bounded by one re-sync interval instead of being unbounded, and the failure
direction is "deny and make the operator notice" rather than "admit silently".

Dual-write in `lock_account`/`unlock_account` is implemented anyway. It is correct the moment
a lock endpoint exists, and it narrows the window to approximately zero for any lock issued
in-code.

**Not decided here:** whether the missing administrator lock endpoint should exist at all.
The system can unlock an account it has no supported way to lock. That is a product gap
rather than a degraded-store question, and it is out of scope for this record.

Implemented in PR #257 (#242).
