---
status: accepted
accepted_at: 2026-03-02
decision_effective_date: 2026-03-02
supersedes: []
superseded_by: []
pr: "#12"
spec_sections_affected: ["02-component-architecture", "03-data-architecture", "05-provisioning"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-03-02 • **Effective:** 2026-03-02 • **PR:** #12
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 02-component-architecture, 03-data-architecture, 05-provisioning
<!-- summary:end -->

# ARD-001: Single-LDAP Architecture

## Context

The original architecture used two separate LDAPs: an AD LDAP for identity (inetOrgPerson) and a UED LDAP for UC service attributes (XMPP/SIP). A UED Sync microservice bridged them via an async `sync_events` PostgreSQL queue. This introduced an entire microservice (`src/ued-sync/`) with its own container, 215+ tests, and HTTP API; an async event queue with background worker, retry logic, and Fernet encryption for service-to-service auth; and eventually consistent provisioning where UC credentials were not available until the worker processed the event. The realization was that separate LDAP servers were unnecessary — the XMPP/SIP schemas can be loaded directly into AD's OpenLDAP, and UC attributes can be written onto the same `inetOrgPerson` entry at user creation time.

## Decision

Collapse to a single LDAP. Both identity (inetOrgPerson) and UC service attributes (posixAccount + AsteriskPjsip*) live on the same DN in one OpenLDAP instance. UC attributes are added via LDAP MODIFY_ADD immediately after user creation — synchronous, atomic, no queue.

Key changes:

- **Removed:** UED Sync microservice (`src/ued-sync/`), sync_worker, ued_sync_client, ued_discovery, ued_crypto
- **Removed:** `sync_events` PostgreSQL table, all UED env vars and Docker service
- **Added:** `build_uc_attrs()` and `add_uc_attrs_to_user()` in `ldap_client.py` — two-step LDAP write (create inetOrgPerson, then MODIFY_ADD UC objectClasses + attrs)
- **Added:** Profile UC toggle fields (`xmpp_enabled`, `sip_enabled`) and endpoint fields (`xmpp_domain`, `sip_domain`, `xmpp_ws_url`, `sip_wss_url`) on `config_templates`
- **Added:** `provisioning.py` — UC resource allocation (UID numbers via atomic `UPDATE...RETURNING`, SIP extension allocation, 24-char random SIP password generation)
- **Changed:** QR code assembles service endpoints directly from profile fields (not UED discovery cache)
- **Schema:** Only `pjsip-combined` schema (modern Asterisk + XMPP); dropped legacy `sip-legacy` and standalone `xmpp-only`
- **LDAP schema loading:** Asterisk PJSIP LDIF ships with the project, loaded during OpenLDAP container init — identical between dev and prod
- **Credential model:** `userPassword` (SSHA) = login + XMPP bind; `AstAuthPassword` (24-char random plaintext) = SIP digest only
- **ObjectClasses:** `posixAccount` (auxiliary) for POSIX identity; `account` objectClass is NOT used (it is structural and conflicts with inetOrgPerson)

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Keep two-LDAP with simplified sync | Still requires microservice maintenance, adds latency and failure modes for no benefit at current scale |
| Event-driven UC provisioning (async queue) | Adds latency between user creation and UC availability; failure modes require retry/dead-letter handling; unnecessary complexity |
| Store UC attrs in PostgreSQL instead of LDAP | XMPP/SIP servers expect LDAP — would require custom auth adapters; LDAP is the natural home for directory-style attributes |
| Single atomic LDAP ADD (identity + UC in one operation) | Design doc initially proposed this, but implementation uses two-step (create then MODIFY_ADD) for cleaner separation of identity vs UC provisioning logic |

## Consequences

- **Positive:** Simpler deployment (one LDAP, no sync service), atomic provisioning (UC available immediately after creation), fewer failure modes, ~500 lines of sync infrastructure removed, eliminated entire UED Sync container and its 215+ tests
- **Negative / trade-offs:** Tight coupling between identity and UC on same LDAP entry (acceptable at current scale); LDAP entry grows larger with UC attrs (mitigated: attrs are small, <1KB per user); `posixAccount` objectClass added to all UC-enabled users adds POSIX semantics (uidNumber, gidNumber, homeDirectory, loginShell) even when not strictly needed for XMPP-only users
- **Risks:** If LDAP server fails, both identity and UC are unavailable (mitigated: single point of failure already existed with the AD LDAP; production deployments can run OpenLDAP with replication)

## References

- Design: `docs/plans/2026-03-02-single-ldap-architecture-design.md`
- Implementation plan: `docs/plans/2026-03-02-single-ldap-implementation-plan.md`
- Migration: `migrations/017_single_ldap.sql`
- LDAP schema: `specs/v2.0/Directory_Portal_LDAP_Schema_v4.2.ldif`

## Amendments

<!-- None yet. -->
