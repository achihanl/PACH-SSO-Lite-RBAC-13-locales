---
status: accepted
accepted_at: 2026-08-01
decision_effective_date: 2026-08-01
supersedes: []
superseded_by: []
pr:
spec_sections_affected: ["SOP"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-08-01 • **Effective:** 2026-08-01 • **PR:** —
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** SOP
<!-- summary:end -->

# ARD-014: Backend Module Governance — Explicit Exemption Over Silent Ungovernedness

## Context

`surfaces.yaml` governs `src/backend/*.py` by **enumeration**: a top-level module is either named
in some surface's glob list or it is ungoverned, and an ungoverned file can never require a trailer.
Nothing detected the second case. A new module was therefore silently ungoverned the day it landed
and stayed that way until a human happened to read the config closely.

That is not hypothetical — it is the shape of every governance defect this repo has fixed:

- **#249** — `auth.py`, the entire authorization ladder, was ungoverned while the 156-line
  `oidc_verify.py` beside it was governed. The governed file was the small one.
- **#255** — `deploy/dev/openldap-schema/` had never existed, so `ldap_schema` governed nothing
  where the real LDIFs live.
- **#252 / #259** — `account_lock_mirror.py` was covered only by accident, via a
  `src/backend/**/*lock*` glob that was inert for its stated purpose and instead matched
  `requirements.lock`. `degraded.py` was ungoverned outright between #257 and #259.

Each was caught by eye. At the time of this record, 9 of 56 backend modules matched no surface glob,
including `provisioning.py` and `ldap_provisioning.py`. The guard runs in fail mode since #234, so
the gap now matters more: the check says something true about the surfaces it knows, and nothing at
all about the files missing from that list.

**A second defect surfaced while implementing this.** `section_map` maps `governance_metadata` and
`ci_release_gates` to the literal section `SOP`, but rule 3 built its set of valid
`spec_sections_affected` values from `docs/architecture/spec/*.md` — and `SOP.md` lives one level
up, at `docs/architecture/SOP.md`. Any ARD declaring `"SOP"` therefore failed rule 3, so
`ARD: ARD-NNN` could never cover either surface and `Spec-Patch: SOP` was the only lane. That lane
explicitly may not assert new behaviour. The consequence: **a decisional change to the guard's own
machinery had no valid lane at all** — it could only be mislabelled as a Spec-Patch or pushed
through the emergency lane. This is #247's defect in its third location and the one place it matters
most, since it is the surface that governs governance. It blocks this very record, which is how it
was found.

## Decision

### 1. Rule 8 — a top-level backend module must be governed or explicitly exempt

A PR touching a `src/backend/*.py` that matches no surface glob and is not listed under a new
`exempt:` key in `surfaces.yaml` fails the guard. The failure names both remedies.

### 2. `exempt:` is a decision, not a bypass

The key holds paths that carry no architectural content, each with a comment saying why. This is
deliberately *not* the same as "matches no surface": the point is to convert a silent default into a
written judgement made once, when the file is added. `surfaces.yaml` is itself on
`governance_metadata`, so adding an exemption needs the same trailer coverage as adding a surface —
the cost is the mechanism.

### 3. Scope is top-level only, non-recursive

`routers/`, `db/` and `schemas/` are governed by `**` globs, so a new file there inherits coverage
and needs no decision. Only the top level is enumerated, so only the top level can leak. Extending
the rule recursively would fail PRs for files that are already covered.

Deleted paths are skipped — removing an ungoverned module is not a governance failure.

### 4. The nine judgement calls

Classification is the real cost of this decision, not the ~40 lines of guard code. Made once, here:

| Module | Lines | Disposition | Reasoning |
|---|---:|---|---|
| `ldap_provisioning.py` | 166 | `ldap_schema` | Creates DIT entries under `ou=clients` with a specific objectClass set (ARD-006) |
| `ldap_activity.py` | 288 | `ldap_schema` | Parses slapd's stats-log format; the other half of ARD-006, coupled to the directory's own shape |
| `provisioning.py` | 70 | `data_contracts` | Allocates UID numbers and SIP extensions by mutating `profile_services` counters |
| `uc_validation.py` | 124 | `data_contracts` | Decides which extension ranges, domains and service configs may enter the UC model |
| `response_utils.py` | 55 | `api_contracts` | Holds the exception-to-HTTP mappings — the status code every failure exits with |
| `activity_types.py` | 26 | `cross_process_boundaries` | The event vocabulary crossing ARD-011's Redis pub/sub boundary |
| `config.py` | 384 | `deploy_topology` | Declares every env var the compose files and Ansible set, and holds the production-safety assertions |
| `version_cache.py` | 44 | **exempt** | A TTL cache in front of the version probe (TD-1). Decides nothing; the endpoint it serves is governed via `routers/system.py` |
| `_version.py` | 2 | **exempt** | Two constants written by release tooling |

`ldap_activity.py` and `ldap_provisioning.py` go to `ldap_schema` rather than `data_contracts`
because what makes them risky is their coupling to the directory, not the tables their output lands
in — `db/ldap_inventory.py` already governs those.

`config.py` is the most-edited of the nine and therefore buys the most friction; see *Consequences*.

### 5. Rule 3 accepts `"SOP"` as a spec section

`"SOP"` resolves to `docs/architecture/SOP.md` rather than a file under `spec/`. This makes the
`ARD:` lane real for `governance_metadata` and `ci_release_gates` for the first time. Unknown
sections are still rejected, and the allowance is anchored to that file existing — one name, not a
relaxation.

**Shipped separately, in #269, ahead of this record.** `arch-guard` CI overlays `tools/` from
`main` (`ref: main`), so a PR that both fixes rule 3 and adds an ARD declaring `"SOP"` is judged by
the guard that predates the fix and fails on its own record — which is exactly what happened on the
first attempt at this PR. Stacking does not help, because the overlay ref is `main` rather than the
PR's base. Landing the fix alone was the only route to a green guard on both changes; this record is
what it was unblocking.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Report-only drift check (scheduled job listing ungoverned modules, failing nothing) | Cheap, and it relies on someone reading the report — which is exactly the status quo that produced #249, #252, #255 and #259. Those were all discoverable by looking; the failure was that nobody looked at the right moment. A report is a fifth chance to not look. |
| Accept it — document in SOP that the backend is governed by enumeration and rely on review | Zero cost and zero mechanism. Review is what missed the four defects above; three of them survived multiple PRs. This is the honest do-nothing option and it was seriously considered, but it makes the fail-mode guard (#234) claim a completeness it does not have. |
| Govern all nine — no `exempt:` key | Simpler config, and it directly contradicts #255: a surface that matches a file with no architectural content is coverage by coincidence, which reads as governance in review while protecting nothing. `_version.py` holds two constants; demanding a trailer for it teaches people that trailers are noise. |
| Make the rule recursive over `src/backend/**` | Fails PRs for files already covered by the `**` globs on `routers/`, `db/` and `schemas/`, and would need a second exemption mechanism for the subpackages. The leak is specific to enumeration, so the fix should be too. |
| Infer governance from imports or module size | Automatic, and wrong in both directions — `auth.py` (#249) was large *and* imported everywhere while ungoverned, and `_version.py` is imported widely while carrying nothing. Architectural significance is a judgement, not a metric. |
| Use `Spec-Patch: SOP` for this change and file the lane gap separately | The lane may not assert new behaviour, and a new failing guard rule plainly does. Using it here would repeat precisely the mislabelling ARD-013 exists to condemn, in the PR that adds an enforcement mechanism. The lane gap is a blocker for this record, not a follow-up to it. |

## Consequences

**Positive**

- A new ungoverned top-level backend module is now impossible to add silently. The check fires at
  the diff that introduces it, when the author still has the context to classify it.
- The nine long-standing ambiguities are resolved and written down rather than rediscovered.
- `tests/arch_guard/test_real_surfaces.py` gains a whole-tree assertion that every top-level module
  is governed or exempt. Rule 8 only sees modules a PR touches, so it cannot notice one that was
  classified and later dropped from the config; that test can.
- The `ARD:` lane exists for `governance_metadata` and `ci_release_gates` for the first time, so
  future decisions about the guard can be recorded as decisions.

**Negative / trade-offs**

- **`config.py` will generate real friction.** It is the most-edited of the nine, and adding a
  single env var now needs `Spec-Patch: 06` plus an edit to `spec/06-deployment.md`. This is
  accepted on the strength of the production-safety assertions it holds — weakening a prod tripwire
  is exactly the change that must not land unrecorded — but it is the classification most likely to
  be revisited, and revisiting it is a legitimate outcome rather than a failure of this record.
- **The `exempt:` list is a governance surface that can be abused.** Adding a path there is a valid
  way to make the rule stop complaining. It requires a trailer and shows up in review as an explicit
  claim that a file carries no architectural content — but the guard cannot tell a considered
  exemption from a lazy one.
- **Only the top level is protected.** A new *subpackage* under `src/backend/` matching no `**` glob
  would be ungoverned and rule 8 would not see it. Narrower than the general problem, deliberately;
  the general problem is "enumeration has no completeness check", and this closes it only where the
  repo actually enumerates.
- **Rule 8 is per-PR.** It cannot see the backlog, the same limitation ARD-011's 2026-08-01
  amendment records for the trailer regime. The whole-tree test is the compensating control, and it
  runs only in CI, not in the guard.

**Neutral**

- No runtime, API, schema or LDAP change. This governs the governance config.
- The seven newly-governed modules gain no new requirements beyond a trailer on PRs that touch them;
  their behaviour is untouched.

## References

- Issues: #265 (this decision), #259 (where the gap was raised and deferred), #249, #252, #255,
  #247 (the lane defect, first two locations)
- Code: `tools/arch_guard.py` (`_check_backend_module_governance`, `_check_ard_consistency`),
  `tools/_lib/surfaces.py` (`is_exempt`, `exempt` loading), `docs/architecture/surfaces.yaml`
- Tests: `tests/arch_guard/test_backend_module_governance.py`,
  `tests/arch_guard/test_real_surfaces.py`
- Related ARDs: ARD-005 (spec-governance hardening — established the surface/trailer regime this
  extends), ARD-006 (the two LDAP modules classified here), ARD-011 (the event vocabulary
  classified here; and the per-PR blindness its 2026-08-01 amendment records), ARD-013 (the
  Spec-Patch lane rule this record declines to break)
- SOP: `docs/architecture/SOP.md § Enforcement` (rule 8)

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->

### 2026-09-18 — PR reference

Landed in **#268** (`02be244`, 2026-08-02, "feat(arch): detect ungoverned backend
modules, and give governance an ARD lane"). § References names #265, which is the
issue this decision answers, not the PR that shipped it; the README ARD table
carries the same #265. Recorded here rather than in `pr:` because rule 2 freezes
frontmatter on an accepted ARD (see ARD-005 § Amendments 2026-09-18).
