---
status: accepted
accepted_at: 2026-09-18
decision_effective_date: 2026-07-03
supersedes: []
superseded_by: []
pr: "#184"
spec_sections_affected: ["04-authentication", "06-deployment"]
---
<!-- summary:begin -->
<!-- Auto-generated from frontmatter. Do not edit by hand. -->
<!-- summary:end -->

# ARD-007: Authentik LDAP Source (LDAP-backed Web SSO)

## Context

ARD-002 made Authentik the sole web-auth path, backed by Authentik's internal
user DB — disjoint from the platform OpenLDAP that holds every UC user's
`userPassword`. A directory user provisioned for XMPP/SIP could not log into the
web admin UI; the two stores shared no identities (0 LDAP sources in Authentik).
ARD-006 shipped provisioned LDAP clients (`ou=clients`, read-minus-secrets),
giving us a dogfoodable, least-privilege bind account.

## Decision

Federate identity one-directionally: Authentik reads the platform OpenLDAP via an
LDAP **source**. LDAP stays the source of truth; Authentik's user store becomes
LDAP-backed. ARD-002 is preserved (Authentik remains the sole web-auth path) and
the core invariant holds (Authentik depends on LDAP, never the reverse — UC works
with Authentik absent).

- **Sync account:** dogfooded provisioned client `cn=authentik-sync,ou=clients`
  (ARD-006), read-minus-secrets. Sync reads only uid/cn/mail; it never reads a
  password.
- **Login:** Authentik `LDAPBackend` binds AS the user to validate the password —
  no password copied into Authentik (`sync_users_password=false`). Identical
  `userPassword` the PED uses.
- **Uniqueness:** `object_uniqueness_field=uid` (the model default `objectSid` is
  AD-only and would import zero OpenLDAP users).
- **Authorization (safe by default):** sync grants no admin rights. `require_admin`
  gates on `OIDC_ADMIN_GROUP`; `require_permission` checks ORGDB RBAC by
  `preferred_username` first. **Activation note:** synced usernames = uid = the
  ORGDB permission key, so any pre-existing (previously inert) RBAC grants for
  directory users activate when sync ships. This is intended but is an
  authorization-activation event, not a no-op.
- **Deactivation:** `delete_not_found_objects=false`; Plane A termination/suspend
  swaps `userPassword`→`{DISABLED}`/`{SUSPENDED}`, so bind-based login fails
  without deleting the Authentik account. Live session revocation still relies on
  `terminate_user_access()` (ARD-002).
- **Groups:** `sync_groups=false` (directory-driven admin RBAC via LDAP group sync
  is a non-goal here — deferred).
- **Secret lifecycle:** the provision API mints the secret show-once. Dev: the seed
  self-provisions (rotate-on-409). Prod: the secret is provisioned once and supplied
  via vault → `AUTHENTIK_LDAP_SYNC_PASSWORD`; the seed does not self-provision.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Amend ARD-002 | ARD-002's decision (Authentik sole web-auth path) is unchanged; this adds where identities come from — a new capability. ARDs are append-only. Precedent: ARD-006 chose a new ARD over amending ARD-001. |
| Copy password hashes into Authentik (`sync_users_password=true`) | Read-minus-secrets can't read `userPassword`, and duplicating the hash widens the leak surface. Bind-based login needs no copy. |
| Reverse federation (Authentik LDAP outpost as the PED's directory) | Breaks the single-LDAP UC model — UC attrs live only on the platform LDAP. |
| LDAP group sync for admin RBAC now | Larger surface; admin grant stays manual/ORGDB for v1. Deferred, not rejected. |

## Consequences

**Positive:** one identity for UC + web SSO; least-privilege dogfooded bind account; no password copy; ARD-002 + UC-without-Authentik invariant intact.

**Negative / trade-offs:** freshly provisioned users can't SSO until the next sync (latency); LDAP-deleted users leave orphaned (deactivated-on-bind) Authentik accounts; the prod secret must be provisioned out-of-band into vault (the API mints show-once).

**Risks:** a wrong `object_uniqueness_field` imports zero users silently (mitigated: explicit `uid` + integration test asserts import + link). The `ou=clients` read ACL must remain secret-complete (ARD-006 guard).

## References

- Design: `docs/superpowers/specs/2026-07-03-authentik-ldap-source-design.md`
- Plan: `docs/superpowers/plans/2026-07-03-authentik-ldap-source.md`
- Related ARDs: ARD-002 (Authentik-only auth — this makes its store LDAP-backed; ARD-002 already references "next LDAP Source sync ~5 min"), ARD-006 (provisioned clients — the sync account), ARD-001 (single LDAP)
- PR: #184 (merged 2026-07-03)
- Spec: `spec/04-authentication.md`, `spec/06-deployment.md`
- Cross-ref: `spec/08-integration-points.md:104` already notes `userPassword ... web login (via Authentik LDAP source)`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->

### 2026-10-02 — group sync for registered client role groups (ARD-018)

The `sync_groups=false` non-goal is narrowed. The source syncs `<client_id>-*`
groups of registered first-party clients only, scoped by `group_object_filter`.
Those groups carry `uidObject` + `uid=<cn>`, because `object_uniqueness_field=uid`
skips a plain `groupOfNames` (tested 2026-10-02). `IT-Admins` and all other groups
stay unsynced: LDAP-driven admin RBAC is still deferred. See
[ARD-018](ARD-018-headless-first-party-client-login.md).
