---
status: accepted
accepted_at: 2026-07-03
decision_effective_date: 2026-07-02
supersedes: []
superseded_by: []
pr: "#179, #181"
spec_sections_affected: ["03-data-architecture", "08-integration-points"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-07-03 • **Effective:** 2026-07-02 • **PR:** #179, #181
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 03-data-architecture, 08-integration-points
<!-- summary:end -->

# ARD-006: LDAP Client Provisioning & Reconciliation

## Context

External servers (e.g. the UED PED80) bind directly to the platform OpenLDAP for XMPP SASL and directory reads. The #179 passive inventory tailed slapd stats to attribute each bind, but two collisions defeated attribution: off-host clients are NAT-masked to the single docker-gateway IP, and a client binding as `cn=admin` (the platform API's own bind DN) folds into the API's own inventory row. The result was that the directory could not say "this bind is the PED, that one is the API" — there was no per-client identity to attribute against. Verifying #179 against the real PED80 exposed the gap empirically and triggered this decision.

## Decision

Treat external LDAP clients as first-class, individually-attributed identities that the platform provisions and reconciles. Two shipped increments, one model:

- **Detection (#179):** a lifespan-managed collector tails the slapd stats log into `(bind_dn, source_ip)` sessions upserted to a `ldap_clients` inventory; `classify()` maps each session to a `service`; admins acknowledge / block / label rows.
- **Provisioning (#181):** dedicated per-client credentials live under a new **`ou=clients,dc=azblink,dc=com`** subtree (config `LDAP_CLIENTS_OU`). Each entry is `cn=<client_id>,ou=clients,…` (`organizationalRole` + `simpleSecurityObject`, holding an SSHA `userPassword`); `client_id` is a constrained slug. The OU is created idempotently at startup by `ensure_clients_ou()`.
- **One static group ACL** — a single bootstrap ldif (`deploy/dev/ldap/ldap-clients-acl.ldif`) grants read-minus-secrets to `dn.children="ou=clients,…"`. It is applied by osixia via EXTERNAL at OpenLDAP init because the app's `cn=admin` **data** bind cannot write `cn=config`. No per-client `cn=config` edits.
- **Intent registry** `ldap_provisioned_clients` (migration 029) stores only `client_id`, `bind_dn`, `label`, `created_by`, timestamps, `revoked_at` — **no secret column**; the SSHA hash lives only in LDAP; secrets are strong-generated (or operator-supplied + strength-validated), shown once, never persisted.
- **Reconciliation:** `classify()` gains an ordered rule before the `uid=` fallback — a bind DN under `ou=clients` → service `provisioned_client`, inserted `status="acknowledged"` (auto-acknowledged) on first observation. Provisioning records intent; the passive detector confirms it on first bind.
- **Surfaces:** admin-only API `/api/settings/ldap/clients/provisioned` (create / list / rotate / revoke), `directoryctl ldap-client` CLI parity, and a `/configuration/ldap-clients` UI page.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Amend ARD-001 (Single-LDAP) instead of a new ARD | ARD-001 is a distinct, frozen decision — collapse two LDAPs into one for identity+UC colocation. External-client attribution/provisioning is a **new capability** (new subtree, component, data flow, security surface), not a clarification of that decision. Amendments are append-only extensions of the *same* decision. |
| Per-client `cn=config` ACL for each provisioned client | Doesn't scale (N rules to audit) and the app's `cn=admin` data bind cannot write `cn=config` anyway. One group rule over `dn.children="ou=clients"` is static and auditable. |
| Store client secrets in the Postgres registry | Duplicates the credential and widens the leak surface. The hash stays only in LDAP; the registry holds intent only. |
| Place clients under `ou=people` / reuse person entries | Pollutes the identity tree; person entries carry UC secret attrs that would need special-casing. A dedicated non-person subtree keeps the ACL boundary clean. |
| Source-IP-only attribution (no provisioning) | Defeated by NAT (all off-host clients collapse to the gateway IP) and shared bind DNs. Per-client identity is the only reliable signal. |

## Consequences

**Positive**
- Every external client is individually named and attributed; credentials rotate/revoke independently; one ACL to audit; secrets never persisted outside LDAP; passive detection needs no client cooperation.

**Negative / trade-offs**
- **Uniform read-minus-secrets is a blanket policy, not per-client scoping.** A client that legitimately must read a secret attr — e.g. Asterisk PJSIP realtime reading `AstAuthPassword` for SIP digest auth — cannot be served without an ACL exception. Deferred (see Amendments).
- `provision()` writes the LDAP entry then the registry row (two writes, not one transaction). Mitigated by a compensating LDAP delete on registry-insert failure (`fix(ldap-clients)` follow-up), but still not atomic across a process crash between the two writes.
- The ACL is security-critical and non-obvious: a read-grant ACL **must enumerate every secret attr**, because OpenLDAP applies the first matching `to attrs=` rule and any unlisted secret falls through to the catch-all `to *`. A directory-wide UC-secret leak (plaintext `azbXmppBindPassword`, `AstAuthPassword`, `AstAuthMd5Cred`) was caught in adversarial review and fixed before merge; a negative regression test (`test_provisioned_client_cannot_read_uc_secrets`) guards it.

**Risks**
- The bootstrap-ldif ACL applies only at OpenLDAP init (EXTERNAL). A hand-edited `cn=config` grant is superseded on `just reset` — operators must provision through the platform, not by editing `cn=config` directly.

## References

- PRs: #179 (detection / inventory), #181 (provisioning)
- Spec: `spec/03-data-architecture.md`, `spec/08-integration-points.md` (LDAP Client Inventory + Client Provisioning)
- Migrations: `migrations/028_ldap_clients.sql`, `migrations/029_ldap_provisioned_clients.sql`
- ACL: `deploy/dev/ldap/ldap-clients-acl.ldif`
- Related ARDs: ARD-001 (Single-LDAP — the shared OpenLDAP this subtree lives in)
- Design: `docs/superpowers/specs/2026-07-02-ldap-client-provisioning-design.md`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->

- **Open follow-up (undecided):** per-client ACL scoping to permit a bounded exception for SIP/Asterisk-as-provisioned-client (which must read `AstAuthPassword`), currently forbidden by the uniform read-minus-secrets policy. To be addressed only when Asterisk is wired to a provisioned credential.
