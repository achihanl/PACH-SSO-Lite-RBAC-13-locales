---
status: accepted
accepted_at: 2026-09-18
decision_effective_date: 2026-07-04
supersedes: []
superseded_by: []
pr: "#186"
spec_sections_affected: ["06-deployment", "07-security", "08-integration-points"]
---
<!-- summary:begin -->
<!-- Auto-generated from frontmatter. Do not edit by hand. -->
<!-- summary:end -->

# ARD-008: Observability Stack (metrics, logs, dashboards, alerting)

## Context

The platform shipped with **no observability system** (audit 2026-07-03):

- No metrics (no `/metrics`, no request/latency/error/resource telemetry).
- Stdlib `logging`, **unconfigured** (no level/format), plain-text, per-container
  `json-file` with **no rotation** — unbounded disk growth (P1, confirmed live).
- No log aggregation, dashboards, alerting, or tracing.
- No `restart:` policy on 5 core services → crash = silent extended outage.
- Health endpoints existed but nothing scraped/recorded/alerted on them.

The operator needs a single live view of platform health, and the deployment
model is "dev is a shadow of production" — the stack must be prod-shaped, with
the only dev↔prod difference being a thin internal/external exposure layer.

## Decision

Add a self-hosted observability stack, delivered **dev-first, prod-parity**, in
the same compose used by ansible for prod:

- **Collector:** Grafana **Alloy** (single agent) — scrapes `directory-api:8000/metrics`,
  host metrics (node exporter over `/host/*`), and tails **azblink-`*`-scoped**
  Docker logs → parses JSON → Loki.
- **Stores:** **Prometheus** (metrics, 15d, internal-only) + **Loki** (logs, 7d,
  internal-only).
- **Viz + alerting:** **Grafana** (the only externally-exposed obs UI) with
  provisioned datasources, a single **Operator Dashboard**, and 4 **Grafana-managed**
  alert rules (UI-only, no external routing): target-down, **service-down**,
  API 5xx ratio, host disk.
- **Foundation (P0):** compose `logging:` rotation on every service, `restart:
  unless-stopped` on the 5 core services, Traefik `INFO` + access logs, backend
  **structured JSON logging** (`LOG_LEVEL`) + **`X-Request-ID`** correlation +
  **`/metrics`** (prometheus_client: request count/latency/in-flight, rate-limit
  rejections).
- **Per-service health:** backend gauge **`azblink_service_up{service}`** — a 20s
  lifespan probe of 11 platform services (authoritative reachability), because
  cAdvisor cannot run on this host (see Alternatives).
- **Boundary:** Prometheus/Loki/Alloy are internal-only in both envs; only Grafana
  is exposed. Prod delta (deferred, tracked tech debt) = tunnel + Authentik OIDC +
  Traefik auth on Grafana, Redis password/TLS, LDAPS — the obs stack itself is
  byte-identical dev↔prod.
- **Fault isolation:** `directory-api` has **no `depends_on`** on any obs service;
  obs failure = blind, never an outage.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Classic separate collectors (node-exporter + cAdvisor + Promtail) | More containers; Promtail deprecation-bound; Alloy unifies collection |
| Docker Loki logging-driver plugin | Host-level plugin dependency; couples container logging to Loki uptime |
| cAdvisor for per-container CPU/mem + container-based health tiles | **Incompatible with this host**: Docker 29 containerd-snapshotter image store (`overlayfs`) has no classic layerdb → cAdvisor reports zero containers. Replaced with `azblink_service_up` probe (better signal); host CPU/mem/disk retained via node exporter |
| External alert push (Alertmanager → Telegram/email) | User chose Grafana-UI-only notifications; Alertmanager dropped |
| OpenTelemetry + Tempo tracing | Deferred; `X-Request-ID` groundwork laid for later |

## Consequences

- **Positive:** disk-bounded logs (closes P1); auto-restart on the core plane;
  live per-service health + API golden signals + host resources + searchable logs;
  config-as-code (dev==prod, reproducible); no `privileged` containers (cAdvisor
  dropped).
- **Negative / trade-offs:** ~4 new obs containers; **no per-container CPU/mem**
  panels on this host (containerd-snapshotter); Grafana alerts are UI-only (no
  push until a receiver is configured).
- **Neutral / deferred (tech debt):** production exposure/TLS/auth boundary
  (Grafana behind tunnel + OIDC, Redis/LDAP TLS); optional tracing; frontend RUM.

## References

- Related ARDs: ARD-003 (Authentik dev stack), ARD-002 (Authentik OIDC — reused for prod Grafana auth)
- Design spec: `docs/superpowers/specs/2026-07-03-observability-stack-design.md`
- PR: #186 (merged 2026-07-04)
- Spec sections: `06-deployment`, `07-security`, `08-integration-points`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->

### 2026-10-21 — Alerts leave the box; identity alerts (decision D-d)

This amendment wins over the Decision's "UI-only, no external routing" and the
rejected "External alert push" alternative. Production needs a page when the
identity plane breaks, not a red row nobody is looking at.

- **Routing.** Grafana's own notifier, still no Alertmanager. Ansible renders
  `obs/grafana/provisioning/alerting/notifications.yml` from
  `roles/azblink_app/templates/grafana_notifications.yml.j2`: one contact point
  `azb-oncall` as the root policy's receiver, a generic **webhook** to a push
  service (`alert_webhook_url`, a vault value the owner fills; preflight refuses a
  prod converge without it), plus **email** only when `alert_smtp_host` and
  `alert_email_to` are both set. The URL reaches Grafana as `$ALERT_WEBHOOK_URL`
  from `.env`, never in the world-readable file. No webhook URL = no file, so dev
  and CI keep the old UI-only behaviour. Email is a second channel, not a
  failover: Grafana sends to both.
- **Five identity rules** (group `azblink-identity`):
  - *Authentik down*: `azblink_service_up` for `authentik` and the new
    `authentik-worker`, now probed on `/-/health/ready/` (was a TCP connect to
    the server only). They leave the generic service-down rule.
  - *Lockout spike*: new gauge `azblink_locked_identities{source}`. `authentik`
    counts usernames the seed's throttle refuses (reputation sum <= -3 or a spent
    bind budget, read from `/policies/reputation/scores/`); `ldap` counts ppolicy
    locks, terminations excluded. Fires on 5 new locks within 15 minutes.
  - *LDAP bind failure rate*: a Loki rule over slapd's stats lines,
    more than 20 `RESULT tag=97 err=49` in 5 minutes.
  - *TLS certificate expiry*: new gauge `azblink_tls_cert_not_after_seconds{target}`
    for each `TLS_EXPIRY_TARGETS` host:port; under 14 days, or unreadable, fires.
  - *Backup age*: the backup job writes
    `azblink_backup_last_success_timestamp_seconds` to a `.prom` file in
    `/var/lib/azblink/metrics` on the host, read by Alloy's textfile collector.
    Over 26 hours, or no metric at all, fires.
- **Not covered here:** a "revocation failed" alert (needs the B1 remainder to
  emit a signal first).

### 2026-10-24 — Alerting outlives its host; probes follow the compose set; revocation pages

This amendment wins over the 2026-10-21 amendment where they differ. Found by the
2026-10-22 production-readiness review (findings 10, 12, 13) (PR: TBD).

- **Probes follow the compose set (finding 10).** Prod probed the dev-only `directory-ui`,
  so "Platform service down" fired from go-live, and nothing probed cloudflared. The UI
  probe now comes from `UI_PROBE_URL`, which `docker-compose.prod.yml` points at
  `directory-ui-prod`, and `docker-compose.tls.yml` adds `EDGE_PROBE_TARGETS`: cloudflared's
  `/ready` (200 only while connected to Cloudflare) and the `edge` hop. A unit test merges
  each compose set and fails on a probe of a service that set does not run.
- **Dead-man's switch (finding 12).** With `alert_heartbeat_url` set, an always-firing
  heartbeat rule goes only to contact point `azb-heartbeat`, every 5-6 minutes, with resolve
  messages off. An external service pages when the posts stop, which is the one page that
  does not depend on this host. Prod preflight requires the URL, distinct from the on-call
  webhook.
- **Second channel or written acceptance (finding 12).** Prod preflight refuses one channel
  unless `alert_single_channel_accepted` records who accepted the risk, when and why. Email
  stays the second channel.
- **Delivery is proven and watched (finding 12).** `verify.yml` sends a test notification
  through every integration and fails the converge on any failure. Alloy scrapes Grafana,
  and **Alert delivery failing** fires on `grafana_alerting_notifications_failed_total`.
  Heartbeat and delivery rules ship in `notifications.yml`, so dev and CI carry neither.
- **Revocation incomplete (finding 13).** This replaces "Not covered here" above. A failed
  Authentik step in suspend or terminate logs `revocation incomplete: ...` at ERROR, and the
  critical Loki rule of that name fires on any such line in 15 minutes. It is a log rule,
  not a counter, because the API runs several Uvicorn workers without a shared metrics
  registry.

Open, the owner's to decide: the dead-man service, and a second channel or the written
acceptance of one.
