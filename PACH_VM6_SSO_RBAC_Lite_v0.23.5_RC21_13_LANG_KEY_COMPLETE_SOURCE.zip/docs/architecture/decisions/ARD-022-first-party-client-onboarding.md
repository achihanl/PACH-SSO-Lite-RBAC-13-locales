---
status: accepted
accepted_at: 2026-10-22
decision_effective_date: 2026-10-22
supersedes: []
superseded_by: []
pr:
spec_sections_affected: ["03-data-architecture", "04-authentication", "06-deployment", "07-security", "08-integration-points"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-10-22 (owner's request; owner choice and coordinator decision in t-0046) • **Effective:** 2026-10-22 • **PR:** (this PR, decision + implementation)
**Supersedes:** — (amends ARD-019 §1 "the grant is static config" and ARD-018's env-only registry) • **Superseded by:** —
**Spec sections affected:** 03-data-architecture, 04-authentication, 06-deployment, 07-security, 08-integration-points
<!-- summary:end -->

# ARD-022: First-Party Client Onboarding in One Call

## Context

Onboarding a SafeNest building `<c>` = `safenest-<b>` took five hand-run steps in three
places (spec 08, "Onboarding a building's roster writer" and "… phones"):

1. **Deploy config.** `AUTHENTIK_FIRST_PARTY_CLIENTS`, `AUTHENTIK_SERVICE_CLIENTS`,
   `OIDC_SERVICE_CLIENT_SCOPES`, `OIDC_ACCEPTED_AUDIENCES` and one issuer per host in
   `OIDC_ACCEPTED_ISSUERS`. The API reads all five at import (`config.py`), so a new
   building needed a converge and an API restart. ARD-019 §1: "The grant is static
   config. Changing it is a deploy."
2. **Authentik.** `authentik-seed` builds the login client, the service client and the
   `(cn=<c>-*)` term of the LDAP source's group filter, from that env.
3. **LDAP, by an admin.** The org `ou=<c>` and the role groups `<c>-<role>`.
4. **SIP, by admins.** A profile with a SIP range disjoint from every other (ARD-020,
   2026-10-21 amendment), assigned to the org, the org's SIP context, the PBX identity.
5. **XMPP, by SafeNest's dev script.** The read-only search client `<c>-ejabberd` and the
   bridge user `<c>.xmpp-bridge`, owned by the building.

The owner asked for clients (SafeNest buildings) added in azb-AD to be integrated
automatically. On 2026-10-22 the t-0046 thread put two choices to the owner: the owner chose
the PostgreSQL registry and a dedicated call, and the project coordinator confirmed the
decision under that mandate. Because the call removes the deploy as the review step for a
new login application, the coordinator made four guards part of it (§5).

## Decision

### 1. One call

`POST /api/clients/onboard`, admin group only (`require_admin`), body
`{clientId, redirectUris, roles?, sipRangeStart?, sipBlockSize?, sipContext?}`.
It converges, in this order, and each step is idempotent:

| Step | What it ensures |
|---|---|
| `registry` | row in `first_party_clients`: `<c>`, principal `<c>-directory`, roles, redirect URIs |
| `ldap_org` | `ou=<c>` under `ou=org` with its people and groups mirrors (and its `org_profiles` row); `cn=<c>-<role>,ou=groups` per role |
| `authentik` | login client `<c>` as ARD-018 builds it; service client `<c>-directory` as ARD-017 builds it, with an application policy admitting only `ak-<c>-directory-client_credentials` (audit B2); `(cn=<c>-*)` in the LDAP source's group filter; a background sync |
| `sip_profile` | a profile assigned to exactly `ou=<c>,ou=org`, reused if one is; else named `<c>`, `active`, with its own UID block (10 000 above every profile's UID range) and a SIP service whose range is `sipBlockSize` (default 100, at most `SIP_RANGE_MAX_SIZE`) from `sipRangeStart` or above every SIP range; the org's `azbSipContext` (default `default`) |
| `ldap_clients` | PBX client `cn=<c>,ou=pbx,ou=clients` (ARD-020 §4) and XMPP search client `cn=<c>-ejabberd,ou=clients` |
| `xmpp_bridge` | `uid=<c>.xmpp-bridge,ou=<c>,ou=people`: owned, in no group, no UC attributes |

- **Repeating the call resumes.** A step that fails answers 502 naming the step; the
  steps before it stay done. A repeat creates nothing that exists and reports
  `created: []`.
- **Secrets.** LDAP secrets (PBX, ejabberd, bridge) are generated, stored only as hashes,
  and returned once, by the call that creates them; afterwards they are rotated through
  the existing routes. The two Authentik client secrets are Authentik's: returned on
  every call, as any admin can read them from Authentik.
- **Refusals.** 409: `<c>` nests with a registered id either way (ARD-019 §1); `<c>-directory`
  holds `OIDC_SERVICE_PERMISSIONS` or is bound to another client; `ou=<c>,ou=people` already
  holds users and `<c>` is not yet registered (they would become owned, ARD-019 threat
  model); a new client whose `<c>` or `<c>-directory` already exists in Authentik (§5); a
  repeat asks for another SIP block than the one it has; the SIP block overlaps. 422: bad id,
  role, block size or redirect URI (§5). 429: rate limit (§5). 503: Authentik's admin API
  unset, or the registry store or the audit log down.
- **Ids.** `clientId` matches `^[a-z0-9]+(-[a-z0-9]+)*$`, 2–39 characters, so `<c>-ejabberd`
  fits a provisioned LDAP client id, which grows from 31 to 48 characters.

### 2. The registry is env plus PostgreSQL

- Table `first_party_clients(client_id PK, service_client_id UNIQUE, roles, redirect_uris,
  created_by, created_at)`. Only the onboard call writes it.
- The registry the API acts on is the env one (still checked at startup, unchanged) plus
  those rows. An env entry wins: a row naming an env client adds nothing, and its
  principal keeps the env roles. A row whose id nests with another is skipped with an
  ERROR log line.
- **No store per request.** Readers use an in-process snapshot, reloaded every 10 s and
  right after an onboard in the same process. Another worker sees a new client within
  10 s. While PostgreSQL is down the last snapshot stays (env only before the first
  load), so ARD-019 §8 ("the scope … needs no store") still holds per call.
- Every reader of the env registry reads the snapshot instead: the scoped principal's
  binding (`auth.client_scope`), role-group ownership (`client_group_owner`, so the
  reserved `<c>-` uid prefix too), reserved org names, the PBX client check.

### 3. Token trust follows the registry

`verify_bearer_token` accepts, for each scoped principal in the snapshot, its `aud` and
its issuer at every host already accepted: for each accepted issuer
`<prefix>/application/o/<app>/`, `<prefix>/application/o/<c>-directory/` is accepted too.
No per-client issuer or audience configuration is needed. The login client `<c>` is never
added: this API keeps refusing first-party tokens (ARD-018, G19).

### 4. The seed keeps what the API added

- The seed's LDAP source group filter is the env clients plus every `(cn=<id>-*)` term
  already on the source, so a reseed never drops an onboarded client's groups.
- The seed creates the shared headless flow even with no env client, so the onboard
  call has a flow to bind on a fresh install.

### 5. Guards in place of the deploy review

A converge used to be where someone looked at a new login application before it existed.
The call keeps a check at each point that review covered:

1. **Admin group only.** `require_admin`: the token's `OIDC_ADMIN_GROUP`. No RBAC permission,
   no scoped principal, no service client reaches it (403).
2. **Every onboard and change is audited.** Each call writes an `onboard_client` row in
   `admin_action_audit`, which `/api/audit/events` serves as an admin action:
   - `phase: started` before any change, with the requested values and the registry row it
     replaces (`previous`: roles, redirect URIs). If that row cannot be written, nothing is
     changed (503): an onboard never goes unrecorded.
   - `phase: finished` with what was created, or `phase: failed` with the status and what was
     created before it stopped. `phase: refused` for a 409 before any change.
   - No secret is ever in a row.
3. **Strict ids and redirect URIs.** `clientId` is `^[a-z0-9]+(-[a-z0-9]+)*$`, 2–39 characters.
   Redirect URIs (1–10, distinct, at most 512 characters) are absolute, with a host, no
   wildcard (`*`), no user info, no fragment, no whitespace, and `https` outside a dev
   environment (`ENVIRONMENT` not in `development|dev|test|ci`); Authentik matches them
   `strict`. A new client whose `<c>` or `<c>-directory` already names a provider or
   application in Authentik is refused (409): the call only converges objects it created,
   and never rewrites, say, `azblink-directory` for a client named `azblink`.
4. **Rate limit.** 10 calls a minute per client address (429), refusals included.

## Alternatives Considered

| Alternative | Why rejected |
|---|---|
| Keep the env registry; the call emits the env and inventory lines to add | Still a converge and a restart per building: not automatic. The owner chose the PostgreSQL registry |
| Read the registry from PostgreSQL on every request | Breaks ARD-019 §8: a scoped principal would fail on any PostgreSQL blip, and every request pays a query |
| Fan out a change event across workers (Redis) instead of a 10 s reload | Exact, but one more cross-process message for a write that happens once per building. 10 s is below anything a building notices |
| Onboard inside `POST /api/org/create` with a flag | Puts Authentik calls and secrets into org create; a separate call keeps org create as it is |
| Scope claim minted by Authentik (ARD-019 option B) | Rejected there for the same reasons; unchanged |

## Threat model

| Path | Blocked by |
|---|---|
| A non-admin onboards a client to own an org's users | Admin group only. `org_management` cannot reach it |
| A stolen admin token registers a login app pointing at an attacker's host | Admin token compromise already owns the directory; the call adds the `started` audit row (written before any change, or no change), https-only exact redirect URIs, and 10 calls a minute |
| A client id chosen to collide with an existing Authentik provider (`azblink` → `azblink-directory`) | 409 for a new client when `<c>` or `<c>-directory` exists in Authentik; found on the t-0046 private stack, where the unguarded call rewrote the admin UI's provider |
| Open redirect or code theft through a loose redirect URI | Strict matching, no wildcard, no fragment or user info, https outside dev |
| Onboard over an existing org whose people are then owned | 409 while `ou=<c>,ou=people` holds users and `<c>` is new |
| Nested ids (`safenest` beside `safenest-a1`) | Refused at onboard (409) and skipped at load; env checked at startup as before |
| A person's app password mints a token through `<c>-directory` | The application policy (B2) |
| Token from an unregistered principal | `aud`/`iss` are added only for registry principals |
| Registry rows tampered in PostgreSQL | Same trust as every other PostgreSQL table holding RBAC grants (ARD-017); rows are audited at write (`onboard_client`) |
| Stale snapshot after a row is deleted | Up to 10 s, as for any reload; deregistration is not an API call (out of scope) |

## Consequences

- A building is one admin call: no converge, no restart, no hand steps in Authentik or
  LDAP. SafeNest gets every value it needs in the response.
- ARD-019 §1's "changing it is a deploy" holds for env clients only; onboarded clients
  change by the onboard call. ARD-018 and ARD-019 gain amendments pointing here.
- Up to 10 s after an onboard, another API worker may refuse the new principal (401).
- The API now creates Authentik providers, applications and policies, which only the
  seed did. The two code paths build the same objects and must stay in step
  (`authentik_client.py` beside `seed_authentik.py`).
- Deregistration stays manual (docs/runbooks/client-lifecycle.md, #389); the registry
  row is one more thing it deletes.
- Migration `030_first_party_clients.sql`; fresh deployments create the table at startup.

## Test plan

`tests/test_client_onboard.py` against the real stack, onboarding a throwaway `onb<hex>`:
every object exists with the right shape; the scoped principal creates, enables SIP
(extension in the block), adds to its group, and gets 404 on another client's group,
with no restart; the PBX reads the SIP secret; the ejabberd client searches without
secrets; the bridge binds; a group member signs in through the login client and the
API refuses that token; a person's app password gets `invalid_grant`; a repeat is a
no-op; nesting, bad input, non-admin, an occupied people OU and a changed block are
refused; every call and a redirect-URI change leave `onboard_client` rows without secrets;
wildcard, fragment, user-info and scheme-less redirect URIs are 422; `azblink` (whose
service client would be `azblink-directory`) is 409 and leaves that provider untouched; the
eleventh call in a minute is 429. Unit: the redirect-URI rules, https only outside dev. `tests/unit/test_first_party_registry_unit.py`: merge rules, the last snapshot
surviving a PostgreSQL outage, and the derived `aud`/`iss`.

## References

- Related ARDs: ARD-017, ARD-018 (amended), ARD-019 (amended), ARD-020
- Spec: `spec/03-data-architecture.md`, `spec/04-authentication.md` §3,
  `spec/06-deployment.md` §6.5, `spec/07-security.md` §3, `spec/08-integration-points.md`
- SafeNest handoff: the t-0046 report (herdr thread library)

## Amendments

### 2026-10-22: independent verification fixes (t-0051)

An independent verifier failed the first implementation. Where this amendment differs from the body
above, it wins.

1. **Env clients are never onboarded.** The body's "a row naming an env client adds nothing" did not
   hold: the takeover check was skipped for every id in the registry snapshot, which includes the env
   clients, so onboarding `safenest-dev` rewrote the seed's redirect URIs and returned its secrets. Now
   a `clientId` in `AUTHENTIK_FIRST_PARTY_CLIENTS` answers 409, and the "already exists in Authentik"
   and "people OU already holds users" checks are skipped only when a `first_party_clients` row for
   `<c>` exists, never on the snapshot.
2. **Authentik client secrets are returned once.** §1 said they come back on every call because any
   admin can read them in Authentik. That is false: the seed's `IT-Admins` group is not an Authentik
   superuser. Each Authentik secret, like each LDAP secret, is returned only by the call that creates
   its provider. The Authentik step now runs last, so no later step can fail after a provider is
   created and lose its secret. If the Authentik step itself fails between the two providers, the
   secret of the one created is lost; rotate it with an Authentik superuser
   (docs/runbooks/client-lifecycle.md).
3. **ARD-019 invariant 1 at onboard.** A `<c>-*` group that already carries RBAC permissions answers
   409, before any change. Without it, every member of that group would become a directory operator
   the moment `<c>` exists (its login policy and source sync admit the group).
4. **Two read-modify-writes are serialised.** Choosing the UID block (the maximum of every profile's
   range) and inserting the profile run in one transaction under advisory lock `client-uid-blocks`.
   Reading and writing the LDAP source's group filter run under advisory lock
   `ldap-source-group-filter`. The seed also writes that filter and takes no lock (it has no
   PostgreSQL connection); it runs at deploy, and it keeps every term already there.

### 2026-10-22: B2 refusal and policy engine mode follow the registry

- The API's B2 refusal (`auth._foreign_service_token`, #390, ARD-017) treats every scoped
  principal in the registry as a service client, onboarded ones included: a person's token minted
  through `<c>-directory` answers 401 here even if a provider lacked its access policy.
- The onboard call creates its two applications with `policy_engine_mode: all` (and converges an
  existing one of its own to it), as the seed does for its apps (#397), so a later binding cannot
  outvote the access policy.

### 2026-10-22: relay addresses of onboarded clients (coordinator decision)

`X-Forwarded-For` trust stays deploy-time (ARD-021): Authentik reads it from env. Where this
amendment differs from the body above, it wins.

- The onboard call takes an optional `relayIp` (one canonical IPv4 host, not unspecified, loopback
  or multicast) and stores it on the registry row (`first_party_clients.relay_ip`, migration `031`,
  also applied at startup). A repeat without `relayIp` keeps it. The call does not trust it.
- When a relay IP is stored, the response carries `relay: {ip, operatorStep}`. The step is: add the
  client to `authentik_onboarded_clients` and `<c>: <ip>` to `authentik_relay_ips`, then converge.
- Preflight (`relay_checks.py`) accepts a relay IP for an id in `authentik_onboarded_clients`, and
  requires one for a listed client, as for an env client. An onboarded client that does not use the relay
  path is in neither list, and no converge is refused because of it. An id may not be in both
  `authentik_first_party_clients` and `authentik_onboarded_clients`.
