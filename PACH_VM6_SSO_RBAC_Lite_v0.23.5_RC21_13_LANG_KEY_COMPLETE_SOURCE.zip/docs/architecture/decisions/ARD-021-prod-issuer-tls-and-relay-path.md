---
status: accepted
accepted_at: 2026-10-22
decision_effective_date: 2026-10-21
supersedes: []
superseded_by: []
pr:
spec_sections_affected: ["04-authentication", "06-deployment", "07-security"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-10-22 (owner decision D-b, 2026-10-21) • **Effective:** 2026-10-21 • **PR:** (this PR, decision + implementation)
**Supersedes:** — (replaces ARD-010's LAN-plaintext transport; see the ARD-010 amendment) • **Superseded by:** —
**Spec sections affected:** 04-authentication, 06-deployment, 07-security
<!-- summary:end -->

# ARD-021: Production Issuer, TLS and Relay Path

## Context

ARD-010 made production LAN-internal: plaintext HTTP for the admin UI and Authentik,
plaintext LDAP published on every interface, and TLS as an opt-in overlay nobody
loaded. Three things have changed since:

- **Clients outside the LAN.** SafeNest runs one box per building (ARD-018). Each box
  relays its users' logins to Authentik and calls the directory API as a scoped principal
  (ARD-019). A building is not on the directory's LAN.
- **The issuer is a contract.** Authentik stamps `iss` from the scheme and host it was
  reached on. SafeNest pins its issuer allow-list, and the API pins
  `OIDC_ACCEPTED_ISSUERS`. A host string that differs by scheme, port or name breaks
  every token. The 2026-10-08 audit (G7, decision 14) asked for one string, chosen once.
- **Plaintext credentials on the wire.** Browser logins, relay logins (which carry
  passwords), LDAP binds and the PBX's SIP-secret read (ARD-020 §4) all cross the
  network.

The owner decided D-b on 2026-10-21 ("use your recommendations"): one public HTTPS host
for browsers, relays on a routed private path with a static IP per box, TLS by default,
and LDAPS. Later the same day the owner chose how: browser TLS comes through the
existing Cloudflare tunnel setup (cloudflared already fronts public dev Authentik),
not ACME.

## Decision

### 1. One host string, two paths

Production has one public host name, `azblink_public_host` (owner to confirm; for example
`id.azblink.com`). Its issuer is `https://<azblink_public_host>/application/o/<client>/`
for every client, on both paths below, byte for byte.

### 2. Browsers: Cloudflare tunnel to one origin

- A cloudflared connector runs on the production box (`docker-compose.tls.yml`). It uses
  its own tunnel token from vault and dials out, so nothing listens publicly. Cloudflare
  terminates TLS at its edge.
- The tunnel sends the whole host to Traefik's `web` entrypoint. Traefik serves the admin
  UI (`/`), the directory API (`/api`) and Authentik's root paths (`/application/`,
  `/if/`, `/flows/`, `/api/v3/`, `/static/`, `/media/`, `/ws/`, `/-/`, `/source/`,
  `/outpost.goauthentik.io/`) on that one host. The UI and its issuer share an origin, so
  OIDC discovery and the token call are same-origin.
- Traefik sets `X-Forwarded-Proto: https` on the Authentik router. Authentik takes the
  scheme from that header and the host from `Host` (probed on 2026.5), which gives the
  https issuer. This is truthful because the `web` entrypoint is reachable only from the
  tunnel and loopback.
- Through the tunnel, Authentik sees one peer for every browser. That is acceptable: the
  lockout is keyed on the username with `check_ip` off (ARD-018 amendment, #338).

### 3. Relays: routed private path, same name, TLS

- The production box has a static IP on a routed private path, `azblink_private_ip`.
  Each relay box has its own static IP, listed as a /32 in
  `authentik_trusted_proxy_cidrs` (ARD-018).
- A relay resolves `azblink_public_host` to `azblink_private_ip` (a hosts entry or split
  DNS) and trusts one CA (`azblink_tls_ca`). It therefore calls the same URLs as a browser
  and gets the same `iss`.
- Authentik terminates its own TLS on `<private ip>:443` (its `:9443` listener). No proxy
  sits between the relay and Authentik, so Authentik still sees the relay's address, and
  the `X-Forwarded-For` trust from ARD-018 keeps working. The seed points the brand's web
  certificate at the keypair Authentik's worker discovers in `/certs/<host>/`.
- The directory API is served over TLS by Traefik's `websecure` entrypoint on
  `<private ip>:8443`.
- OpenLDAP serves LDAPS on `<private ip>:636`. Plaintext `:389` stays only on the docker
  network, for the API and Authentik's LDAP source.
- One certificate for `azblink_public_host` serves all three relay-path listeners. The
  recommended source is a Cloudflare Origin CA certificate, with the Origin CA root as
  the CA relays trust; any CA the owner controls also works. The chain and CA live in
  group_vars, and the private key in vault. Rotating it is a re-converge: a hash of the
  chain is part of each reader's environment, so compose recreates the readers.

### 4. Plaintext stays on loopback

On the production path, the plaintext listeners (Traefik `web` `:8081`, Authentik
`:9000`, LDAP `:389`) and the ops ports bind `127.0.0.1`. The relay path's TLS listeners
bind `azblink_private_ip`. `preflight.yml` refuses a production converge that is not in
this shape, and `verify.yml` checks the relay path the way a relay sees it.

The one exception is a PBX that cannot do TLS (UED on the PED80, ARD-020 §4). It needs
plaintext LDAP. The preferred fix is a private tunnel to loopback. If that is impossible,
`azblink_allow_plaintext_ldap: true` lets `ldap_publish` bind the private IP, and the
host firewall must limit it to the PBX's /32. That opt-in is a written exception, not a
default.

### 5. Out of scope

- Cloudflare Access on the public host (optional; the PR lists the clicks). With one
  origin, the UI's credential-less fetches no longer need path bypasses.
- Mutual TLS for relays, and an IP+username throttle (lockout DoS, B5).
- Grafana behind OIDC (ARD-008 phase 4); it stays loopback.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| LAN HTTP for the pilot (ARD-010 as is) | Relay logins carry passwords; buildings are not on the LAN; the issuer would change later and break every client's allow-list. |
| ACME (Let's Encrypt) on public `:80`/`:443` | Needs inbound ports and public DNS pointing at the box; the owner chose the tunnel. |
| Relays through the Cloudflare tunnel | Authentik would see cloudflared, not the relay, so the per-relay `X-Forwarded-For` trust (ARD-018) breaks; Access would need service tokens on every relay. |
| Traefik terminates TLS for Authentik on the relay path | Authentik would see Traefik's container address; trusting it means trusting a docker-network address for `X-Forwarded-For`, which ARD-018 forbids. |
| A second name for the relay path (for example `auth-relay.<domain>`) | A second issuer for every client to allow-list, and the service-client issuers double again. One name with a hosts entry is simpler. |
| Two public hosts (UI and Authentik), as on dev | Cross-origin discovery and token calls need Access bypasses (dev, 2026-10-08); one origin needs none. |
| Authentik picks the certificate by SNI | Probed on 2026.5: discovery imports the keypair, but `:9443` serves the brand's web certificate and ignores SNI matches. The seed sets it. |

## Consequences

- **Positive:** one issuer string for every client and path. No plaintext password or
  LDAP bind leaves the box. Nothing on the box listens publicly. A prod converge in the
  old LAN shape fails preflight instead of shipping plaintext.
- **Negative / trade-offs:** each relay box needs a hosts entry and the CA. Cloudflare is
  in the browser path, so its outage is a browser outage (relays are unaffected).
  Authentik sees one address for all browsers. A certificate change reaches Authentik's
  `:443` on its own refresh, about 3-5 minutes later.
- **Neutral:** dev and CI are unchanged. Every new knob defaults to the open dev value,
  and `docker-compose.tls.yml` is loaded only by the prod inventory.
- **Owner actions:** confirm the host name; create the tunnel and its public hostname,
  and the Origin CA certificate, in the Cloudflare dashboard (listed in the PR); give the
  box and each relay a static private IP and a route.

## References

- Related ARDs: ARD-010 (transport decision replaced; amendment added), ARD-018 (relay
  path made concrete; amendment added), ARD-019, ARD-020 §4 (PBX without TLS)
- Audits: 2026-10-08 readiness audit (G7, decision 14, plan item #5); 2026-10-21 re-audit
  (B3)
- Files: `deploy/dev/docker-compose.tls.yml`, `deploy/dev/traefik/tls.yml`,
  `deploy/ansible/roles/azblink_app/{templates/env.j2,tasks/config.yml,tasks/preflight.yml,tasks/verify.yml}`,
  `deploy/ansible/inventories/prod/`
- Spec sections: `spec/04-authentication.md`, `spec/06-deployment.md`, `spec/07-security.md`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link.
     Body above this heading is frozen once status=accepted. -->

### 2026-10-22: browsers share one source under the source throttle (ARD-018 amendment 2026-10-21, #385)

#385 landed while this ARD was in review. It throttles password attempts per source IP: one source
may spend 2 of a username's 3 failures. On the browser path of §2, Authentik's peer is Traefik and
Traefik's peer is cloudflared, neither of which is a trusted proxy. So every browser is one source:
2 wrong passwords through the public host refuse that username's browser sign-in for 24 h, or until
an admin unlocks it. Relays (§3) keep their own addresses and are unaffected, and so are LDAP binds.
That is the B5 risk class again for browser sign-in, at a threshold of 2, not 3.

Passing the visitor address through is not a header-trust switch. Cloudflare appends to a
client-supplied `X-Forwarded-For`, so its first entry is attacker-chosen. Only `CF-Connecting-IP`
is set by Cloudflare alone. Closing this needs that value to reach Authentik as the client IP: for
example, cloudflared and Traefik at fixed addresses on a dedicated edge network, Traefik rewriting
the header, and Authentik trusting only Traefik. That is a follow-up change. Until it lands, the residual
is open: either the owner accepts it for the pilot, or the follow-up ships before go-live. Prod is
not converged yet, so nothing is exposed.

The cert-expiry alert (ARD-008 amendment, #384) now watches the three relay-path listeners
(`alert_tls_targets` in the prod inventory example).

### 2026-10-22: relay boxes, the relay-path probe, and SIP and XMPP on the path

Where this amendment differs from the body, it wins. It adds to §3; nothing above changes.

1. **One static address per relay box.** The inventory names each first-party client's relay box:
   `authentik_relay_ips: {<client_id>: <IPv4>}`. `env.j2` trusts each as a `/32` for
   `X-Forwarded-For`, beside loopback and `authentik_trusted_proxy_cidrs`, which is kept for any
   other single host. `preflight.yml` refuses a production converge where a client has no relay
   address, a relay address names a client that is not a first-party client, a value is not one
   canonical IPv4 (a trailing newline or a leading zero fails), is unspecified, loopback or
   multicast or is the box's own private IP, two clients share an address, or a trusted entry is
   not one host of its family (IPv4 `/32`, IPv6 `/128`), is invalid, or is unspecified, loopback
   or multicast. The checks parse with Python's `ipaddress` (`filter_plugins/relay_checks.py`), and
   CI runs the real preflight task against good and bad inventories
   (`tests/unit/test_preflight_relay.py`). A shared or wide entry would let
   one box speak for another at the source throttle (ARD-018 amendment 2026-10-21). Reachability
   of the private IP itself stays with the routed network's ACL; the box does not firewall it.
2. **The path is watched as a relay sees it.** `directory-api` probes the three listeners every
   20 s: TLS verified for the public name against the relay CA, Authentik's discovery `issuer`
   equal to `https://<host>/application/o/azblink-directory/`, and `/api/health`. The result is
   `azblink_relay_path_up{listener}`, and a **Relay path down** alert (critical, 3 minutes) goes
   to the webhook. The existing expiry alert reads certificates over the docker network; this one
   catches what only a relay would see: a wrong certificate or name, a changed issuer, a missing
   published port.
3. **SIP and XMPP on the path, tested.** A simulator overlay (`docker-compose.relay-sim.yml`,
   test stacks and CI only) runs the real TLS overlay with a throwaway CA and puts a trusted relay,
   an untrusted box, an Asterisk PBX and ejabberd on a separate network at static addresses.
   `tests/test_relay_path.py` shows, on every PR:
   - the relay gets `https://<host>/application/o/<client>/` as the issuer, for discovery and for
     a token, over Authentik's own TLS listener;
   - Authentik records the relay's forwarded client IP and ignores the untrusted box's;
   - the PBX, bound as `cn=<c>,ou=pbx,ou=clients` over plaintext `:389` as UED would be (§4
     exception), registers an owned user (`200`, wrong secret `401`), rings a second phone,
     refuses a suspended user at once and accepts them again after unsuspend, routes `default`
     and `all` but not `from-internal`, and never registers another org's user;
   - ejabberd, bound over LDAPS as a provisioned client with the canonical active-user filter,
     logs an owned user in and refuses a wrong password, a suspended user and a terminated user.
4. **The PED80 itself is not in this change.** Its UED cannot be scripted (no SSH; md5 waits on
   Azblink, ARD-020 amendment 1). The live steps are a checklist in the PR for when the path to
   the PED80 exists.

### 2026-10-22: browser source from CF-Connecting-IP, trusted only from cloudflared

Where this amendment differs from the body or an earlier amendment, it wins. It closes the known issue
recorded in the first 2026-10-22 amendment: on the browser path every browser was one source at the
throttle. The owner decided the source is `CF-Connecting-IP`, trusted only from cloudflared.

1. **One trusted peer per hop, at fixed addresses.** A dedicated `edge` network (`azblink_edge_net`, a
   /24 prefix) holds cloudflared `.2`, the edge `.3`, Traefik `.4` and Authentik `.5`. The tunnel's
   public hostname maps to `http://edge:80`, not `http://traefik:80` (§2 changes accordingly).
   Docker assigns dynamic addresses only from `.128/25`, and every member is pinned below it, so no
   container that joins the network takes a trusted address. Preflight refuses a relay IP inside
   the edge prefix.
2. **The edge (nginx) sets the address.** It takes `CF-Connecting-IP` as the client address only when
   the peer is cloudflared's `.2`; from any other peer the peer itself is the address. It replaces
   `X-Forwarded-For` with that one address and sets the other forwarding headers itself. It never
   appends: on 2026.5 Authentik records the first `X-Forwarded-For` entry from a trusted peer
   (probed), and Cloudflare forwards the visitor's own `X-Forwarded-For` in front of the real
   address, so appending would let the visitor choose its source.
3. **Traefik and Authentik each trust one address.** Traefik's `web` entrypoint trusts forwarded
   headers only from `.3`. Authentik trusts `.4` (beside loopback and the relays' `/32`s) and is
   reached by Traefik over the `edge` network. Relays (§3) are unchanged.
4. **Tested.** On the simulator (CI), a box at cloudflared's address sending `CF-Connecting-IP` and a
   spoofed `X-Forwarded-For` is recorded as its `CF-Connecting-IP`; a second box on the edge network
   is recorded as its own address. On the topology before this change both were recorded as
   Traefik's address. Discovery through the edge still gives the public issuer.

### 2026-10-24: cloudflared reaches the edge and nothing else (review-2 M8)

Where this amendment differs from the body or an earlier amendment, it wins. The tunnel's target is
set in the Cloudflare dashboard and nothing on the box checks it. With cloudflared on the `edge`
network, a target of `http://traefik:80` (the older dev pattern), Authentik or the API worked, and
every browser became one source again: Traefik does not trust cloudflared, so the B5 lockout class
came back while `verify.yml` stayed green.

1. **cloudflared gets its own network.** `azblink_edge_net` stays one /24, now split in two: `edge`
   (`.0/25`, dynamic addresses only from `.64/26`) holds the edge `.3`, Traefik `.4`, Authentik `.5`
   and the API `.6`; `tunnel` (`.128/25`, dynamic only from `.192/26`) holds cloudflared `.130` and
   the edge `.131`, and nothing else. A tunnel target naming any other container is unreachable,
   so it fails at once with a 502. The edge trusts `CF-Connecting-IP` only from `.130`. Not
   covered: ports the box publishes on its private IP stay reachable, because `tunnel` cannot be `internal` (cloudflared dials out): above all Authentik's own TLS listener (`authentik_https_publish`, `:443`). A target there still answers and makes every browser one source; only
   `http://edge:80` is right.
4. **Off the shared tunnel network.** The base file puts Traefik and Authentik on the external
   `cloudflare-tunnel` network (the dev box's shared tunnel). The TLS overlay replaces their
   networks (`!override`) with `azblink-net` and `edge`, and ansible creates that network only
   outside the TLS set, so no other cloudflared on the box reaches either service.
2. **The probe reads `/ready` through the edge.** The API shares no network with cloudflared, so the
   edge relays `edge:2000/ready` to cloudflared's metrics port; the `cloudflared` probe target is
   that URL.
3. **Tested.** `tests/unit/test_browser_edge_config.py` checks every compose file a stack loads:
   cloudflared (and the simulator's stand-in) is on `tunnel` only, and only the edge shares it. On
   the simulator, `tests/test_relay_path.py` shows the stand-in reaches the edge and cannot reach
   Traefik, Authentik or the API by name or address, which a box on the `edge` network can.
