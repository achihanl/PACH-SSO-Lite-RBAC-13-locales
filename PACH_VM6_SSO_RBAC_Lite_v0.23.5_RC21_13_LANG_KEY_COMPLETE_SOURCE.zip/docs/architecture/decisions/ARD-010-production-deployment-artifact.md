---
status: accepted
accepted_at: 2026-09-18
decision_effective_date: 2026-07-15
supersedes: []
superseded_by: []
pr: "#206"
spec_sections_affected: ["06-deployment", "07-security", "08-integration-points"]
---
<!-- summary:begin -->
<!-- Auto-generated from frontmatter. Do not edit by hand. -->
<!-- summary:end -->

# ARD-010: Production Deployment Artifact (compose topology + secret/port hardening + LDAP demo-user removal)

## Context

Until now production reused the dev compose verbatim: `inventories/prod/group_vars/all/main.yml.example` set `deploy_subdir: "deploy/dev"` and the deploy task invoked the single `docker-compose.yml` unchanged. The production-readiness audit (2026-07-10) found **no production deployment artifact existed**, and that this one fact was the parent of a P0 plus most P1s: a Vite dev server served the admin UI, Grafana shipped `admin/admin`, Redis had no password, the Traefik dashboard ran `--api.insecure=true`, all operational ports published on `0.0.0.0`, and the LDAP bootstrap seeded demo IT-Admins with the repo-published password `password123`.

Two facts sharpen the risk. **ARD-007 is enabled in production**, so Authentik authenticates web admins against OpenLDAP by bind — making those `password123` demo IT-Admins a full web-admin bypass on any fresh LDAP volume, not merely a Plane-A (XMPP/SIP) credential. And `deploy/install.sh` (a documented `curl | sudo bash` "Remote Server Install") copied `.env.example` verbatim, leaving `DEV_AUTH_TOKEN` and default credentials live on a network-reachable host (the P0).

Owner decisions taken 2026-07-10: production is **LAN-internal** (plaintext transport on the trusted LAN is accepted; TLS is an optional overlay), **Ansible is the sole production deployment path**, and **a live VM already carries demo users** (so the cutover must clean up, not just prevent).

## Decision

- **`deploy/install.sh` removed.** Ansible (`deploy/ansible/`) is the sole production deployment path.
- **Base + override compose topology** (`deploy_subdir` stays `deploy/dev` so relative build contexts and `./ldap`/`./obs` mounts resolve):
  - base `docker-compose.yml` = **prod-safe skeleton** (no demo LDAP data, no `seed` service);
  - `docker-compose.dev.yml` = demo LDAP mount + `seed` service (dev only);
  - `docker-compose.prod.yml` = **additive only** (per-service resource limits + the vault-rendered `bootstrap.admin.ldif` mount);
  - `docker-compose.tls.yml` = **opt-in** TLS overlay (Traefik `websecure` / documented cloudflared sidecar), not loaded by default.
  - Selected by new inventory vars `azblink_compose_files` / `azblink_compose_profiles` threaded into the `docker_compose_v2` task.
- **UI served from a real build in prod:** compose `profiles` split — `directory-ui` (`[dev]`, Vite/HMR) vs a new `directory-ui-prod` (`[prod]`) that wires the existing `Dockerfile.ui-react` → nginx. `VITE_OIDC_*` are baked as build-args at deploy time.
- **Secret/port hardening in-base via `${VAR:-devdefault}`** (every default reproduces today's dev behavior, so dev does not regress): operational ports (postgres, redis, grafana, traefik dashboard, authentik 9443) bind loopback in prod; Grafana admin credentials, Redis `requirepass` (propagated to the backend and both Authentik services), and Traefik `--api.insecure` are templated from `env.j2`/vault. App + browser-OIDC entrypoints (traefik `:8081`, authentik `:9000`) stay LAN-open.
- **LDAP demo-user elimination + ARD-007 hardening:** demo people move to `bootstrap.demo.ldif` (dev override only); the prod real-admin and `cn=authentik-sync` bind account are rendered from vault (`ldap_bootstrap.ldif.j2` → `bootstrap.admin.ldif`); `assert_production_config_safe` gains an `ORG_QR_SIGNING_SECRET` default check, and the Ansible `preflight.yml` gate rejects the shipped `AUTHENTIK_SECRET_KEY` / `AUTHENTIK_BOOTSTRAP_PASSWORD` (container-only secrets the API process cannot see) alongside every other secret default.
- **Two independent guards:** an Ansible `preflight.yml` assert fails the converge if any shipped-default secret remains; a runtime `assert_no_demo_identities` (lifespan, prod-only) is **non-bricking** — it logs CRITICAL and raises a health flag rather than crash-looping, and an idempotent purge task in `ldap_admin.yml` removes demo identities already present on existing volumes.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Keep reusing the dev compose verbatim | The status-quo source of the P0 + most P1s |
| Fork a full separate prod compose | ~400 lines of identical services would drift between two files |
| Pure compose profiles, no override files | Volume mounts (demo LDIF, admin LDIF) cannot be profile-gated |
| Redefine `directory-ui` in a prod override via `!override`/`!reset` | Compose merge-tag fragility; the profiles split is cleaner and composes with the seed/UI dev↔prod gating |
| Mandatory TLS (Traefik `:443`/ACME in base) | Owner accepted plaintext on the trusted LAN; shipped as an opt-in overlay instead |
| Runtime demo-user assert hard-fails (crash-loop) | Would brick the existing VM's upgrade converge; non-bricking warn + health flag + purge task chosen |

## Consequences

- **Positive:** eliminates the P0 (`install.sh`) and collapses the deploy-surface P1s (Vite-in-prod, exposed admin ports, default Grafana/Redis creds); a fresh production deploy has no default-credential admin path on either the Authentik or LDAP plane; dev is unchanged because every prod knob defaults to today's value.
- **Negative / trade-offs:** production remains plaintext on the LAN until the TLS overlay is opted in (owner-accepted); the base compose gains env-interpolation complexity; `deploy_subdir: deploy/dev` for prod is semantically odd (a rename to a neutral path is deferred).
- **Neutral / deferred:** backup + a real migration runner (Bucket B — this artifact ships only commented `backup.yml`/`migrate.yml` hooks); TLS-by-default; Grafana behind Authentik OIDC (ARD-008 Phase 4).

## References

- Related ARDs: ARD-003 (Authentik dev stack), ARD-007 (Authentik LDAP source — the reason demo LDAP admins are a web-admin bypass), ARD-008 (observability — Grafana prod hardening deferred there, partially addressed here)
- Production-readiness audit: 2026-07-10 (multi-agent; ranked blockers)
- Supersedes the D1 "install.sh remains the curl|bash quick-path" decision in `docs/superpowers/specs/2026-06-21-ansible-deploy-baseline-design.md`
- PR: #206 (merged 2026-07-15)
- Spec sections: `06-deployment`, `07-security`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->

### 2026-10-22: backup lane built

Where this amendment differs from the body, it wins.

The backup half of Bucket B is built (PR: TBD). The `azblink_backup` role replaces the
`backup.yml` placeholder: a nightly systemd timer runs `azblink-backup`, which writes one archive
holding `slapcat` of `cn=config` and the directory, `pg_dump -Fc` of both databases and a Redis
RDB snapshot. It keeps 14 days, encrypts with `gpg --symmetric`, and mirrors the archives over
SSH to an off-host target held in vault. It runs on its own timer, not before each deploy: an
upgrade takes a backup by hand first (runbook). `azblink-backup restore` restores all four
stores; a restore drill on a private stack passed on 2026-10-22
(`docs/runbooks/backup-restore.md`).

The stack stays single-node: one Authentik server and worker, one Postgres per database, one
OpenLDAP, no replica. Losing the host means a rebuild from the newest archive, up to 24 hours of
changes lost. The owner's acceptance of that for the pilot, and the choice of off-host target
(decision D-c), are still open. The migration runner stays deferred.

### 2026-10-22: the transport decision is replaced by ARD-021

This amendment wins over the body where they differ. The owner's 2026-07-10 decision
"production is LAN-internal, plaintext on the trusted LAN, TLS an opt-in overlay" no longer
holds. Since ARD-021, production loads `docker-compose.tls.yml`. Browsers reach one public
HTTPS host through a Cloudflare tunnel, and relays reach the same name over TLS on a routed
private path. Every plaintext listener (Traefik `:8081`, Authentik `:9000`, LDAP `:389`) binds
loopback, and `preflight.yml` refuses the old LAN shape. The "Mandatory TLS" row under
Alternatives is now the decision, though not through ACME. The rest of this ARD (Ansible as
the only path, base + override topology, secret gates, demo-user removal) stands.

Found while testing ARD-021: the base OpenLDAP healthcheck bound with the literal dev
password, so on a vault password `openldap` never became healthy and `directory-api` never
started. It now binds with the container's own `LDAP_ADMIN_PASSWORD`.

### 2026-10-22: the API's Authentik token is created, and the demo purge is marker-based and opt-in

Where this amendment differs from the body, it wins. Found by the 2026-10-22
production-readiness review (blocker 2, finding 7).

**API token.** The vault holds `authentik_api_token` apart from
`authentik_bootstrap_token`, but Authentik creates only the bootstrap token, so in
prod the API's token did not exist and every Admin API call (suspend, terminate,
unlock) answered 403 while the API reported `partial=true`. The token stays a
separate vault secret, revocable and rotatable without touching the bootstrap token:
the seed, which runs on every converge, creates the non-expiring `api` token
`azblink-directory-api` for `akadmin` with the vault key, and resets the key when
the vault changes. `verify.yml` proves it from inside the API container
(`/api/v3/core/users/me/`, admin required). It is still an admin token; narrowing
it to a dedicated account is open.

**Demo purge.** The body's purge deleted fixed names (`jchen`, `Finance`, ...) on
every non-dev converge, so it deleted real users and groups that shared a demo name.
It now deletes only entries the demo seed marked with `businessCategory:
azblink-demo`, never the real admin or the OIDC admin group, and runs only when the
inventory sets `azblink_purge_demo_identities: true`. Demo entries written before the
marker are no longer purged; `assert_no_demo_identities` still reports them for
removal by hand.

### 2026-10-24: the host can neither read nor delete its off-host backups

Where this amendment differs from the body or the 2026-10-22 backup amendment, it wins.
Found by the 2026-10-22 production-readiness review (finding 11): the off-host copy was an
`rsync --delete-after` mirror, the host held the symmetric passphrase and a delete-capable
key, retention was 14 days with no longer tier, and a DR converge started the timer before
the restore. Clearing the backup directory, a DR host's first run, or root on the host each
wiped the off-host history (PR: TBD).

- **Encryption to a public key.** Archives are encrypted to `backup_encryption_public_key`;
  the private half lives off-host and comes back only for a restore
  (`azblink-backup restore FILE --yes --key KEY`, imported into a throwaway keyring). The
  role refuses a private key, a target without the public key, and the old
  `backup_encryption_passphrase`, and deletes the passphrase file.
- **Push-only, append-only target.** Each run uploads only its new archive, with no delete
  option. Before sending, a dry-run delete probe must be refused: the target's key is
  restricted to `rrsync -wo -no-del`, and a target that accepts deletes fails the run (no
  success metric, so "Backup too old" fires). `rrsync` alone does not stop a same-name
  overwrite, so the target's root cron runs `azblink-backup seal`, which moves each
  finished upload into `sealed/<UTC date>/` out of the backup account's reach.
- **Retention tiers.** 14 dailies, then the newest archive of each ISO week for 12 weeks.
  The host ages its own archives by the date in their names. The target never trusts a
  name the host chose: `azblink-backup prune-sealed` keeps or drops whole seal-date
  directories that hold an archive, and `seal` creates a day only when it moves something.
  Name-based pruning there let junk named for each past week's last second win every
  weekly slot, and empty day directories let a missed night or Sunday displace a week's
  real archives (verifier t-0075).
- **Target freshness.** The owner chose healthchecks.io for a second dead-man check on the
  target: `azblink-backup check-fresh` pings it hourly only while an archive was sealed in
  the last 26 hours, by the target-set ctime. It catches a host that stops uploading while
  faking its own metrics and heartbeat.
- **DR.** `backup_timer_enabled: false` converges the role with the timer stopped; the
  runbook's new-host steps use it until the restore is verified.

Open, the owner's to decide: the target itself (an SSH box the owner runs, or an
object-lock bucket, which this lane does not implement).

### 2026-10-26: migration lane built

Where this amendment differs from the body, it wins.

The migration half of Bucket B is built (PR #428). An existing install is an upgrade, and
`create_all` never alters a table, so the converge now owns the PostgreSQL schema step.

- **Before the new API, not after.** `migrate.yml` runs after `config.yml` and before
  `deploy.yml`: it starts `postgres` alone and runs `python -m db.migrate /migrations` in a
  one-off `directory-api` container of the new release. A refusal fails the converge while
  the old stack still serves. Running it after `up` would start the new API on the old
  schema first.
- **A ledger with a baseline, not schema fingerprinting.** `schema_migrations` names each
  applied file. An install from before the ledger records the files up to `029` without
  running them: every release from v0.5.0 (before the Ansible deploy existed) to v0.19.0
  has the same columns, types, defaults, indexes and unique constraints, and only added
  tables. Later files run. Older files are not idempotent (`025` reads columns it drops),
  so replaying every file was not an option.
- **Check, then refuse; never guess.** After the files and `create_all`, the live schema
  must match this release's exactly. The reference is `create_all` into a scratch schema in
  the same transaction, and the comparison covers every column's type, nullability and
  default, every index, no unknown column, and no table that a file up to `029` dropped.
  If that check fails, or a file fails, or the ledger names files this release lacks (a
  downgrade), the whole transaction rolls back. A column-presence check alone was not
  enough: a v0.2.0/v0.3.0 schema has every current column (its extra SIP/XMPP columns are
  nullable), so it would have baselined and stranded the data `024`/`025` move (verifier
  t-0104). Every install older than v0.5.0 is refused, checked against each tag's own
  `create_all`. The operator then migrates it by hand or installs fresh and imports the
  LDAP data (README, "Upgrading an install").
- **A dump only when it matters.** When an existing install has files to run, the converge
  writes `pg_dump -Fc` to `/var/backups/azblink/pre-migrate-<UTC>.dump` first. The runner's
  rollback covers a failing file; the dump covers a migration that succeeds and is wrong.
- **LDAP and Authentik need no new step.** `ldap_source.yml` already applies the client ACL,
  `azbSipContext`, the ppolicy lockout and the `unique` overlay to an initialized volume and
  refuses duplicates first; the Authentik seed converges on every `up`.
- **Proof.** `tools/upgrade_drill.py` (workflow `upgrade.yml`, on schema and compose changes
  and nightly) upgrades a seeded v0.19.0 private stack with the PR's tree.

No new dependency: the runner uses SQLAlchemy's inspector, already in the lockfile.

### 2026-10-26: a prod converge refuses backups that stay on the host

Where this amendment differs from the body or the earlier backup amendments, it wins.
Found by the 2026-10-26 release-readiness audit (t-0092): an empty `backup_offhost_target`
only printed a warning, so a prod host could converge with every backup on its own disk,
lost with it (PR: #427).

- **Preflight refuses it.** Every non-dev converge (the preflight's existing gate:
  `azblink_environment` not development, dev, test or ci) needs `backup_offhost_target`,
  `backup_offhost_ssh_key` and an armored `backup_encryption_public_key`, before anything
  is deployed. The backup role's own check runs only after the app is up.
- **Written acceptance.** As with one alert channel (ARD-008 amendment 2026-10-24), a prod
  host may keep backups on its own disk only when `backup_local_only_accepted` records who
  accepted that, when and why. The fresh-host test sets it: its throwaway VM has no target.
