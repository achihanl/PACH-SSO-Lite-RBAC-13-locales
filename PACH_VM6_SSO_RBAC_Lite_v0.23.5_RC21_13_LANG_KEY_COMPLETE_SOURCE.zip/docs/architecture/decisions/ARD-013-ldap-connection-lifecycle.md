---
status: accepted
accepted_at: 2026-08-01
decision_effective_date: 2026-07-29
supersedes: []
superseded_by: []
pr: "#226"
spec_sections_affected: ["02-component-architecture", "03-data-architecture"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-08-01 • **Effective:** 2026-07-29 • **PR:** #226
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 02-component-architecture, 03-data-architecture
<!-- summary:end -->

# ARD-013: LDAP Connection Lifecycle — No Pooling, Release Guaranteed at the Operation Boundary

## Context

`ldap_client.py` is the only component that talks to OpenLDAP for identity and UC data (**03 § 1**).
Before PR #226 it held 53 `conn.unbind()` calls and zero `try`/`finally` blocks — every release sat
on the happy path. `get_conn()` dials a fresh TCP connection and performs a bind on every call;
there is no pooling. Any exception between connect and unbind therefore leaked both a socket and a
file descriptor.

The worst case is the one that matters. `safe_ldap()` catches `LDAPException` and converts it to
`LdapUnavailableError` so the API can answer `503`. On that path the connection was never released,
so a *failing* directory leaked one descriptor per request — the load grew precisely when the
directory was least able to absorb it, until the process hit its `ulimit`. The recovery behaviour
of the whole LDAP plane depended on a leak that got worse the longer the outage ran.

Commit `2fa9226` fixed this inside PR #226 and shipped carrying `Spec-Patch: 02`. That lane covers
non-decisional edits and explicitly may not assert new behaviour, which this does: it establishes a
release guarantee the system did not previously have, and a rule about how every future LDAP call
site must be written. ARD-011's 2026-07-29 errata amendment flagged the mismatch and carried the
question forward on #232 rather than closing it by silence; #232 closed as unactionable on its
metadata half (PR #226 was squash-merged, so the trailers cannot be corrected without rewriting
`main`) and #264 carried the substance here. This record closes it: the behaviour is live on `main`
and now has a decision behind it.

## Decision

Ratify the shipped design. LDAP connections are **unpooled**, and their release is guaranteed at the
**operation boundary** rather than at each call site.

### 1. One connect-and-bind per operation; no pooling

`get_conn()` opens a new `ldap3.Connection` with `auto_bind=True` on every call. This is deliberate,
not an omission. Every operation pays a TCP handshake plus a bind round-trip, and connection state
never outlives the operation that opened it. See § *Consequences* for when this stops being the
right trade.

### 2. Release is centralised in `safe_ldap()`, not distributed across call sites

Every operation in `ldap_client.py` has the same shape — an inner `_op()` that calls `get_conn()`,
does its work, and unbinds on the way out. The release is therefore made structural at that
boundary:

- `get_conn()` appends each connection it opens to a bucket held on a `ContextVar`
  (`_open_conns`), when one is active.
- `safe_ldap()` installs a fresh bucket, runs the operation, and in a `finally` releases every
  connection in it — on success, on the `LDAPException` it converts, and on any other exception.
- `_release()` swallows failures from `unbind()`, so an already-closed or already-dead connection
  neither raises nor aborts the loop over the remaining connections.
- The pre-existing explicit `conn.unbind()` calls are left in place and become the first (and only
  effective) release. `_release()` tolerating the second is what makes leaving them safe.

### 3. `ContextVar`, not a module-level global

FastAPI runs sync (`def`) handlers in a threadpool, and 98 of the 100 route handlers are `def`
rather than `async def`. A module global would be shared across concurrently-executing requests, so
one request's `finally` could release another's live connection. `ContextVar` scopes the bucket to
the executing context; `safe_ldap()` resets its token in the same `finally`, so no bucket outlives
its operation.

### 4. Callers outside `safe_ldap()` use the `ldap_conn()` context manager

`safe_ldap()` covers only operations defined inside `ldap_client.py`. Callers elsewhere that reach
for `get_conn()` directly get no bucket and therefore no cover. `ldap_conn()` is the supported entry
point for them: it opens a connection and releases it in a `finally`.

### 5. The invariant

> **Every `get_conn()` call must execute inside either a `safe_ldap()` operation or an
> `ldap_conn()` block.**

A call outside both is a leak on every exception path, exactly as before this change. As of this
record every caller on `main` satisfies it: `ldap_provisioning.py` reaches `get_conn()` only from
inside `safe_ldap(_op)` (and `_delete_ldap_entry()` additionally carries its own `try`/`finally`),
and `routers/users.py`, `routers/groups.py`, `routers/settings.py`, `routers/dashboard.py`,
`routers/system.py`, `observability.py` and `main.py` all use `ldap_conn()`. Nothing enforces this;
see *Consequences*.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Add a connection pool | Addresses the per-operation connect cost, which is the real long-term argument, but does not by itself fix this bug — an operation that fails to return its connection exhausts the pool instead of the file-descriptor table, converting a slow leak into a fast hang. Release discipline is the prerequisite for pooling, not an alternative to it. A pool remains the right answer if connect cost becomes measurable; it is a larger change and was not smuggled into a bug fix. |
| Wrap each of the 34 call sites in `try`/`finally` | Correct, and 34 independent chances to get it wrong — plus one more for every operation added afterwards. Centralising at the one boundary every operation already passes through makes the guarantee structural rather than a convention that has to hold 34 times. |
| Module-level list instead of a `ContextVar` | 98 of 100 handlers are sync `def`, so FastAPI runs them in a threadpool and several execute concurrently in one process. A shared global would let one request's release loop unbind another request's in-flight connection — a data-corruption-class bug traded for a leak. |
| A decorator or `ExitStack` applied per operation | Same defect as the per-call-site fix: it depends on every present and future operation remembering to apply it. `safe_ldap()` is already mandatory for the error mapping, so hanging the guarantee there costs nothing extra and cannot be forgotten independently. |
| Let garbage collection close the socket | CPython refcounting would eventually reclaim most connections, but not deterministically and not under the case that matters: a propagating exception holds its traceback, which holds the frame, which holds the connection. `ldap3.Connection` does not document an unbind-on-`__del__`. Relying on this is relying on an implementation detail to fix a resource leak, precisely on the paths where it is least likely to hold. |

## Consequences

**Positive**

- No LDAP connection leaks on any failure path, including the `LDAPException` → `LdapUnavailableError`
  conversion that made a struggling directory degrade faster the longer it struggled.
- The guarantee lives in one function. Reviewing it means reading `safe_ldap()` and `ldap_conn()`,
  not auditing every call site.
- `tests/unit/test_ldap_conn_lifecycle.py` pins it with 8 tests and needs no running directory —
  `get_conn` is patched, so nothing dials out. It covers release on success, on `LDAPException`, on
  an arbitrary exception, across a multi-connection operation, tolerance of a double unbind,
  tolerance of an unbind that itself raises, no bucket leaking between operations, and the
  `ldap_conn()` helper.

**Negative / trade-offs**

- **Per-operation connect-and-bind cost is retained.** Every LDAP operation pays a TCP handshake and
  a bind round-trip. Acceptable at current load and against a directory on the same Docker network;
  it is the first thing to revisit if LDAP latency becomes a profile hotspot.
- **The § 5 invariant is unenforced.** A new `get_conn()` caller written outside both wrappers leaks
  exactly as the pre-#226 code did, and nothing detects it — no lint rule, no test, no guard. The
  invariant currently holds because someone checked, which is the same posture #265 raises about
  surface coverage: governance by enumeration with no mechanism behind it. Filing a check is
  deliberately not done here — it is a real piece of work, not a clause.
- **The happy path now unbinds twice.** The explicit `conn.unbind()` calls were kept rather than
  removed, so a successful operation calls `unbind()` and then `_release()` calls it again. Harmless
  by construction, and `test_existing_explicit_unbind_is_not_double_released` asserts exactly that —
  but it means those 53 calls are now redundant rather than load-bearing, and a reader cannot tell
  which mechanism is doing the work.
- **`get_conn()`'s behaviour is context-dependent and invisible at the call site.** Whether a
  connection is tracked depends on whether a `safe_ldap()` frame is active further up the stack.
  Reading `get_conn()` alone does not reveal that; the docstring carries the whole explanation.

**Neutral**

- No wire-contract, schema, or LDAP-DIT change. This governs how the client holds connections, not
  what it reads or writes through them.
- ARD-001's single-LDAP model is untouched — this is the connection discipline for the one
  directory that model establishes, not a change to it.

## References

- PR: #226 (commit `2fa9226`, "fix(ldap): guarantee connection release on every failure path").
  Squash-merged as `403be17`, which is why the original `Spec-Patch: 02` trailer cannot be corrected
  in place.
- Issues: #264 (this record), #232 (closed as unactionable on its metadata half)
- Code: `src/backend/ldap_client.py` (`get_conn`, `_open_conns`, `_release`, `ldap_conn`,
  `safe_ldap`), `src/backend/ldap_provisioning.py` (`_delete_ldap_entry`, `provision`, `rotate`,
  `revoke`)
- Tests: `tests/unit/test_ldap_conn_lifecycle.py`
- Related ARDs: ARD-001 (Single-LDAP — the directory this client is the sole path to), ARD-006 (LDAP
  Client Provisioning — `ldap_provisioning.py` reaches `get_conn()` through `safe_ldap()` and
  inherits this guarantee), ARD-011 (whose 2026-07-29 errata amendment flagged that this change
  needed a decision record and carried the question forward)
- Spec sections: `spec/02-component-architecture.md` § 2, `spec/03-data-architecture.md` § 1

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->
