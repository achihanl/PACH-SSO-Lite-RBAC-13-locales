---
status: accepted
accepted_at: 2026-03-04
decision_effective_date: 2026-03-04
supersedes: []
superseded_by: []
pr: "#13"
spec_sections_affected: ["02-component-architecture", "04-authentication", "07-security"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-03-04 • **Effective:** 2026-03-04 • **PR:** #13
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 02-component-architecture, 04-authentication, 07-security
<!-- summary:end -->

# ARD-002: Authentik-Only OIDC Authentication

## Context

The previous authentication system supported three modes simultaneously: LDAP-based JWT login (`POST /api/auth/login` in `auth.py`), Authentik OIDC, and a breakglass fallback (file-based emergency admin credentials). Three auth paths meant three sets of tests, three code paths in middleware, and confusing configuration toggles (`REQUIRE_OIDC_AUTH`, `ALLOW_BOOTSTRAP_WITHOUT_OIDC`, `JWT_SECRET`, `JWT_ALGORITHM`, `BREAKGLASS_FILE`). The breakglass mechanism had no audit trail. The `_claims_from_auth_header` function contained branching logic for JWT vs OIDC vs breakglass, and `require_admin`/`require_permission` had bypass paths when `REQUIRE_OIDC_AUTH` was false.

## Decision

Authentik OIDC is the sole authentication path for the web admin UI (Plane B). No fallback. No breakglass.

Two clean authentication planes:

- **Plane A (UC/LDAP):** XMPP, SIP, VPN, and MQTT authenticate via LDAP bind against the single LDAP. Always available. No IdP dependency. Unchanged by this decision.
- **Plane B (SSO/Authentik):** All web UIs (AZBlink Directory admin, Nextcloud, SafeNest) behind Authentik OIDC. No fallback, no breakglass.

Key changes:

- **Deleted:** `src/backend/auth.py` (207 lines — LDAP JWT login, `authenticate_user`, `LoginRequest`, `LoginResponse`)
- **Deleted:** `POST /api/auth/login` endpoint from `main.py`
- **Deleted:** Breakglass mechanism (`_load_breakglass`, `_breakglass_allows`, `ADMIN_RECOVERY_PREFIXES`, `BOOTSTRAP_OPEN_PATHS`)
- **Deleted:** `tests/test_auth.py`, `tests/test_breakglass.py`
- **Deleted:** Breakglass subcommand from `directoryctl.py` CLI
- **Created:** `src/backend/authentik_client.py` — Authentik Admin API v3 client for session/token revocation on user termination (stateless, urllib-based)
- **Created:** `src/frontend/src/lib/oidc.ts` — PKCE S256 browser flow (Web Crypto API, no deps)
- **Created:** `src/frontend/src/routes/auth/callback.tsx` — OIDC callback handler (code exchange, userinfo fetch, auth store update)
- **Simplified:** `_claims_from_auth_header` to OIDC-only path (no JWT/breakglass branches)
- **Simplified:** `require_admin` and `require_permission` — removed `if not REQUIRE_OIDC_AUTH` bypass
- **Rewrote:** Auth store (`auth-store.ts`) — OIDC token lifecycle replaces JWT `login()`; logout redirects to Authentik end-session
- **Rewrote:** Login page (`login.tsx`) — "Sign in with Authentik" redirect replaces LDAP credential form
- **Added:** `DEV_AUTH_TOKEN` env var for dev/test bypass (monkeypatched `verify_bearer_token` in test fixture; returns synthetic admin claims; never set in production)
- **Termination flow:** `authentik_client.terminate_user_access()` revokes sessions + OAuth2 tokens via Authentik Admin API (fire-and-forget; without this, web sessions persist until next LDAP Source sync ~5 min)
- **Config removed:** `REQUIRE_OIDC_AUTH`, `ALLOW_BOOTSTRAP_WITHOUT_OIDC`, `JWT_SECRET`, `JWT_ALGORITHM`, `JWT_EXPIRY_HOURS`, `JWT_REMEMBER_DAYS`, `BREAKGLASS_FILE`
- **Config added:** `AUTHENTIK_API_URL`, `AUTHENTIK_API_TOKEN`, `DEV_AUTH_TOKEN`, `VITE_OIDC_ISSUER`, `VITE_OIDC_CLIENT_ID`, `VITE_OIDC_REDIRECT_URI`, `VITE_OIDC_ADMIN_GROUP`

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Keep breakglass as emergency fallback | No audit trail, security risk, adds complexity to auth middleware; admin can use Authentik admin console (port 9000) or `directoryctl` CLI for emergency LDAP/Postgres operations |
| LDAP JWT as primary, OIDC optional | Diverges from SSO-first strategy; maintaining two auth backends doubles testing burden; three code paths in middleware |
| Local user database for admin accounts | Adds another data store to maintain; Authentik already handles user management, MFA, and session lifecycle |
| Keep dual-auth with feature toggle | `REQUIRE_OIDC_AUTH` toggle created confusion about which mode was active; dead code paths accumulate when the toggle is rarely flipped |

## Consequences

- **Positive:** Single auth path (~300 lines removed), cleaner codebase, Authentik handles session management and MFA, consistent audit trail through Authentik, test fixture rewrite was zero-touch for 120+ test callsites (same `auth_headers` signature, only validation mechanism changed)
- **Negative / trade-offs:** Web UI unavailable when Authentik is down (acceptable: UC continues via Plane A; admin can use `directoryctl` CLI or wait for Authentik recovery); Authentik end-session endpoint does NOT revoke tokens — explicit `DELETE /api/v3/oauth2/access_tokens/{id}/` required in termination flow
- **Risks:** Single point of failure for admin UI access (mitigated: Authentik is deployed as part of the dev stack; production deployments can run Authentik HA); Authentik API breaking changes could affect `authentik_client.py` (mitigated: pinned to 2025.8, client has error handling)

## References

- Design: `docs/plans/sessions/2026-03-04-authentik-only-auth-design.md`
- Implementation plan: `docs/plans/2026-03-04-authentik-only-auth.md`
- Knowledge: `docs/knowledge/patterns/dual-auth-plane-sso-overlay.md`
- Knowledge: `docs/knowledge/libraries/authentik-admin-api-v3.md`

## Amendments

### 2026-10-02 — headless first-party clients (ARD-018)

Plane B gains a second way in for **registered first-party headless clients**: the
client's backend relays its own login form to the Authentik flow executor and gets
Authentik tokens. It is not a fallback and adds no azb-AD login endpoint, so the
"no fallback, no breakglass" decision stands. SafeNest is the first such client.
Admission rules: [ARD-018](ARD-018-headless-first-party-client-login.md).
