---
status: accepted
accepted_at: 2026-10-20
decision_effective_date: 2026-10-20
supersedes: []
superseded_by: []
pr: "#369"
spec_sections_affected: ["03-data-architecture", "05-provisioning", "06-deployment", "07-security", "08-integration-points"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-10-20 (owner) • **Effective:** 2026-10-20 • **PR:** #369 (decision only; implementation follows)
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 03-data-architecture, 05-provisioning, 06-deployment, 07-security, 08-integration-points
<!-- summary:end -->

# ARD-020: Client SIP Provisioning, Layered SIP Context and PBX Read Access

## Context

SafeNest phase 4 moves its ejabberd and its PBX (UED on the Azblink PED80, "SIP in
LDAP") onto azb-AD. ejabberd already works through a read-only provisioned client.
SIP does not, for four reasons:

- **The extension is allocated but stored nowhere.** `allocate_uc_resources`
  (`src/backend/provisioning.py:34-71`) takes an extension from the profile's SIP
  counter (`src/backend/db/templates.py:332-352`), and `build_uc_attrs` accepts it
  (`src/backend/ldap_client.py:37-126`), but no attribute carries it. Every `Ast*Id`,
  `AstAccountName` and `AstAuthUsername` is the uid. SafeNest's intercom dials
  extensions (`users.sipExtension`, 6001…).
- **A scoped principal cannot write SIP.** ARD-019 admits nine calls. Scoped create
  refuses `profileId`, and `reset_password` never touches `AstAuthPassword`. So a
  SafeNest-created entry has no PJSIP classes, no `uidNumber` and no extension.
- **The context is fixed.** `AstEndpointContext` is `from-internal` for everyone
  (`ldap_client.py:107`). SafeNest rows carry `sipContext` `default` or `all`.
- **No PBX can read the SIP secret.** ACL rule {2}
  (`deploy/dev/ldap/ldap-clients-acl.ldif`) lets only `self` and `cn=admin` read
  `AstAuthPassword`. Provisioned clients under `ou=clients` read everything else
  (rule {3}).

What is known about UED. REF is Azblink's vendor kit (`azblink-ldap-testing`, outside
this repo); RPT is `docs/reports/2026-04-17-sip-sso-e2e-report.md`.

- **UED keys accounts on `AstAccountName`.** Its only mapping knob is `sfilter`,
  default `(AstAccountName=*)` (RPT:291, RPT:354). The SIP-in-LDAP page has seven
  fields: `binding`, `host`, `port`, `basedn`, `user`, `pass`, `sfilter`
  (`playbooks/web-configure/azblink-server-sip-config.yml:188`). It has no auth-type
  field and no TLS field.
- **In the vendor model the extension is the endpoint name.** The same value goes into
  `AstAccountName`, `AstAuthUsername`, `AstAorId`, `AstAuthId`, `AstEndpointId`,
  `AstEndpointAors` and `AstEndpointAuth`, while the LDAP `uid` stays separate
  (`uid=humi6830`, `AstAccountName: 6830`; REF `addComboPJ:12,32-44`,
  `useradd2.php:101-125`). UED's default dial pattern is `_68XX` (RPT:95).
- **The only proven REGISTER used `AstAuthType=userpass` with a plaintext
  `AstAuthPassword`** (RPT §14.3). Every vendor example does the same (REF
  `addComboPJ:37-39`, `useradd2.php:111-115`). The vendor scripts compute an HA1 and
  never write it (`addComboPJ:3,9`). The schema allows `AstAuthMd5Cred` (REF
  `asteriskAUX.ldap-schema:949-954, 2198-2212`). Whether UED renders it as PJSIP
  `md5_cred` is unknown.
- **Proven only with `cn=admin` and basedn `dc=azblink,dc=com`.** `%1` substitution
  in `sfilter` is unproven (RPT:161).
- **Realm.** UED's default is `azblink2` (RPT:146); our run pinned `asterisk` to match
  `AstAuthRealm` (RPT:231).
- **Reload.** Changes took effect only after `binding=on` and a VoIP stop/start
  (RPT §5). Whether UED re-reads LDAP between restarts is unknown.
- **Context.** INVITE routing on UED needed `AstEndpointContext=all`, not
  `from-internal` (RPT §14.2 item 6); the vendor sets `all` (REF `addComboPJ:45`).
- **The `*Id` attributes are needed** although the schema marks them MAY (RPT:355).

Other facts:

- `suspend_user` and `disable_user` (`ldap_client.py:1235-1320`) change
  `userPassword`, `description` and (terminate) `pwdAccountLockedTime`. They leave
  `AstAuthPassword` as it is. Once a PBX can read it, a suspended or terminated
  user's phone keeps registering.
- The extension counter is monotonic per profile and never checks LDAP, so an
  extension set by hand (migration) can collide with a later allocation.
- An org has at most one assigned profile (`config_template_assignments.org_dn` is
  unique).
- azb-AD's minimal `asterisk-pjsip.schema` gives `AstAttrType:1` to `AstAccountName`
  (upstream `AstContext`; `AstAccountName` is upstream `:39`) and `AstObjectClass:1`
  to `AsteriskAccount` (upstream `:7`). The two schemas cannot be loaded together.
  This ARD adds no upstream Asterisk attribute and leaves the clash for a separate fix.

Out of scope: the read-only client `safenest-dev-ejabberd` and the user
`safenest-dev.xmpp-bridge`, which SafeNest's own script provisions.

## Decision

### 1. Extension (item 3): the endpoint name is the extension

When SIP is enabled, `build_uc_attrs` writes the allocated extension into
`AstAccountName`, `AstAuthUsername`, `AstAorId`, `AstAuthId`, `AstEndpointId`,
`AstEndpointAors` and `AstEndpointAuth`. The LDAP `uid` is unchanged. No new
attribute: `AstAccountName` is where the extension is stored.

- **Unique per profile.** No two entries with the same `azblinkProfileId` share an
  extension. One client org has one profile, and its PBX searches that org (§4), so
  this is the PBX's namespace. Two buildings may both use 6001.
- Allocation and an explicit value (§2) both run under a PostgreSQL advisory lock
  keyed on the profile, check LDAP for the value, and skip a taken one. The `unique`
  overlay cannot scope per profile.
- The extension is fixed once SIP is enabled. Changing it renames the endpoint and
  every phone's username.
- Device provisioning seals `sipUsername` from `AstAuthUsername`, not the uid
  (`src/backend/routers/provisioning.py:546`).
- Existing SIP entries (endpoint name = uid) are migrated by the implementation PR:
  allocate an extension, rewrite the seven attributes, recompute the HA1 (§4).

| Option | Trade-off | Verdict |
|---|---|---|
| A. New `azbSipExtension` on `azblinkUser` | Our OID arc, exact semantics. But UED has no mapping for it (one `sfilter`, accounts keyed on `AstAccountName`), so the PBX would never dial it. **Unverified, leaning no** | Rejected |
| B. `telephoneNumber` | Already in `inetOrgPerson`. Means a public number, multi-valued, and UED does not read it either | Rejected |
| C. Upstream `AstExtension` / `AstAccountCallerID` | `AstExtension` is a dialplan attribute; the upstream schema clashes with ours on OIDs | Rejected |
| **D. `AstAccountName` and the `*Id` attributes = extension** | The vendor model and the only shape with evidence (REF `addComboPJ`, `useradd2.php`). SafeNest's phones already register with the extension as username (its chan_sip `AstAccountName`), so migration changes no phone. Costs: azb-AD's existing SIP endpoints are renamed, and the device payload's `sipUsername` changes value | **Chosen** |

Security: none new. The extension is an address, not a credential.

### 2. Scoped SIP writes (item 4)

One new route, admitted to the ARD-019 principal for **owned and contained** users
(`routers/_client_scope.py:write_target`), and to `user_management` holders:

`PUT /api/users/{uid}/sip` with body `{password?, extension?, context?}`.

- The first call enables SIP. It adds `posixAccount`, the PJSIP classes,
  `azblinkProfileId` and `uidNumber`, and the §1 attributes. Later calls change only
  `password` and `context`; `extension` after enable answers 409.
- **The profile is the org's.** For a scoped caller it is the profile assigned to
  `ou=<c>,ou=org`; the principal never names one. No assigned profile, or one with no
  enabled SIP service, answers 409. A user already carrying another profile answers 403.
- `password`: optional. Omitted on enable, azb-AD generates one and returns it once.
  Supplied, it must be at least 12 characters. Migration copies SafeNest's clear
  `sipPassword`, so phones keep their secret.
- `extension`: optional, enable only. Omitted, allocated. Supplied, it must lie in the
  profile's SIP counter range and be free in that profile (409 otherwise).
- `context`: the user level of §3.
- Counts in the per-`azp` write bucket (ARD-019 §6). Audited as `scoped_set_sip`
  with the changed field names and the extension and context values. The password is
  never recorded.
- ARD-019's create stays as it is: no `profileId`. A new resident costs a create plus
  this call.

| Option | Trade-off | Verdict |
|---|---|---|
| **A. One `PUT /sip` route, org's profile** | Covers phase-3 users that already exist and new ones; one place for the checks | **Chosen** |
| B. Admit `profileId` on scoped create | New users only; existing owned users stay without SIP | Rejected alone |
| C. Admit `AstAuthPassword` in `PATCH` | Mixes credentials into identity edits; no enable path | Rejected |
| D. Extend `reset_password` with `sipPassword` | No enable, no extension | Rejected |

Security: the building controls the SIP secret of its own contained users, the same
reach it has over `userPassword` today. It cannot reach adopted users or other orgs.

### 3. Layered SIP context (item 5)

Add `azbSipContext` (`AZBlinkAttr:8`, values `default` or `all`, enforced by the API)
as MAY on `azblinkUser`, `azblinkGroup` and `azblinkOrganization`.

**Resolution** (most specific wins):

1. the user's own `azbSipContext`;
2. else the user's groups that carry one. A client role group `<c>-*` counts only for
   users under `ou=<c>,ou=people`, so a building cannot change an adopted user's
   context. If several groups disagree, `default` wins (least privilege, independent
   of order);
3. else the org of the user's own DN (`_infer_org_dn_from_user_dn`);
4. else `from-internal`, today's value, so no existing endpoint moves. On UED,
   `from-internal` did not route an INVITE (RPT §14.2), so every client org gets its
   default set at onboarding.

**Materialised.** The PBX reads one attribute, so azb-AD writes the resolved value to
`AstEndpointContext`. It recomputes the affected users on: a context write at any
level, member add or remove, `move_org`, and SIP enable. A failed fan-out is repaired
by repeating the call, which recomputes every affected user.

**Who sets each level:**

| Level | Admins | Scoped principal |
|---|---|---|
| User | `user_management` | owned and contained users, via `PUT /sip` |
| Group | `user_management` (`PATCH /api/groups/{cn}` gains `sipContext`) | in-scope groups, via the same field (one more admitted call) |
| Org | `org_management` | no |

| Option | Trade-off | Verdict |
|---|---|---|
| **A. Per-level attribute, materialised into `AstEndpointContext`** | PBX unchanged; values live on the entry and survive renames. Fan-out writes on group and org changes | **Chosen** |
| B. PBX resolves the layers | UED reads static attributes; it cannot | Rejected |
| C. Settings in a PostgreSQL table keyed on DN | Breaks on rename and move; one more store to fail | Rejected |
| D. OpenLDAP collective attributes | Subtree only (no group level); needs `COLLECTIVE` attributes; untested on `osixia/openldap:1.5.0` | Rejected |

Security: the meaning of `all` is the PBX dialplan's. If `all` reaches outside lines,
a building can grant it to its own users only.

### 4. PBX bind DN (item 6)

One PBX identity per first-party client: `cn=<c>,ou=pbx,ou=clients,<base>`.

**Which secret it reads depends on the verification gate** (§ Verification before
acceptance):

- **Gate passes: HA1 only.** azb-AD writes `AstAuthMd5Cred` =
  `MD5(<extension>:<realm>:<password>)` beside `AstAuthPassword` on every SIP write,
  and sets `AstAuthType=md5`. The PBX reads only `AstAuthMd5Cred`.
- **Gate fails or is not run: plaintext.** `AstAuthType` stays `userpass`, and the PBX
  reads `AstAuthPassword`.

Either way:

- **Reads:** that one secret, for entries exactly `uid=<uid>,ou=<c>,ou=people,<base>`
  (owned users) that are not suspended or terminated. The ACL is one static rule
  before {2}, with no per-client `cn=config` edit:

  ```text
  to dn.regex="^uid=[^,]+,ou=([^,]+),ou=people,dc=azblink,dc=com$"
     filter=(!(|(description=SUSPENDED)(description=TERMINATED)))
     attrs=<AstAuthMd5Cred | AstAuthPassword>
     by dn.exact,expand="cn=$1,ou=pbx,ou=clients,dc=azblink,dc=com" read
     by * break
  ```

  The filter keys on `description`, not `pwdAccountLockedTime`, which a ppolicy
  lockout also sets. Unsuspend restores access without a new secret.
- **Non-secret attributes.** The PBX must search and read every other `Ast*`
  attribute, `uid` and the containers above. Rule {3} grants that to every child of
  `ou=clients` (`read` includes search). It also lets the PBX read other orgs'
  non-secret entries, as any provisioned client can today.
- **Scoping the box.** UED takes one bind DN and one password. Each box is configured
  with basedn `ou=<c>,ou=people,<base>` and the default `sfilter`. `%1` in `sfilter` is
  unproven and not used. The ACL bounds the secret whatever the box is configured with.
- **Realm.** Each box's UED realm is pinned to `SIP_AUTH_REALM` (`asterisk`), not
  UED's default `azblink2`. For HA1 this is mandatory: a different realm fails every
  REGISTER. Changing `SIP_AUTH_REALM` later invalidates every stored HA1.
- **No TLS.** UED has no TLS field, so the bind password and the secret cross the
  network in clear. The box-to-LDAP path must be private (same host network or a
  tunnel). This is a further reason to prefer HA1.
- **Revocation latency is UED's.** If UED reads LDAP only at a VoIP restart, then
  hiding the secret on suspend takes effect only at the next restart, and a new user
  registers only then. azb-AD cannot shorten that from its side. The gate measures
  it; if UED caches, the runbook makes a VoIP restart part of suspend and onboarding.
- **Provisioning:** `POST /api/settings/ldap/clients/provisioned` gains
  `kind: "ldap" | "pbx"` (default `ldap`). `pbx` requires a registered first-party
  client id whose `ou=<c>,ou=org` exists, and creates the entry under `ou=pbx`.
  `rotate` and `DELETE` work unchanged. `system_configuration` only; the scoped
  principal cannot provision one. Generic clients live one level under `ou=clients`
  and cannot collide with `ou=pbx`.

Device provisioning keeps reading the plaintext through the API's `cn=admin` bind.

| Option | Trade-off | Verdict |
|---|---|---|
| **A. HA1 only (`AstAuthMd5Cred`), owned and active users** | No plaintext leaves azb-AD. HA1 still registers as that user on that realm, so it is password-equivalent there, but useless elsewhere. **Unverified on UED** | **Chosen if the gate passes** |
| **B. Plaintext `AstAuthPassword`, same bounds and filter** | The only proven shape. A PBX compromise, or a sniffed bind, yields every owned user's clear SIP secret | **Chosen if the gate fails** |
| C. One shared PBX DN for all clients | One entry. Any PBX reads every building's secrets | Rejected |
| D. Reuse a generic provisioned client with a name convention (`<c>-pbx`) | An admin provisioning `foo-pbx` for something else silently gets `ou=foo`'s secrets | Rejected |

## Verification before acceptance

The owner accepted on 2026-10-20 with this test as the gate for §4. It runs once, on the
PED80 VM (192.168.122.220), with the owner present, before any box is cut over. Until it
passes, §4 means option B.

1. **Setup.** Create one throwaway user in a test org with the §1 shape (extension as
   endpoint name), `AstAuthType=md5`, `AstAuthMd5Cred` = `MD5(<ext>:asterisk:<pw>)`,
   and **no** `AstAuthPassword`. Provision a PBX DN for that org. Point UED SIP-in-LDAP
   at it: basedn `ou=<org>,ou=people,dc=azblink,dc=com`, default `sfilter`, realm
   `asterisk`. Stop and start VoIP once.
2. **Rendering.** `asterisk -rx "pjsip show auth <ext>"` shows `auth_type` md5 and a
   `md5_cred`, and `pjsip show endpoint <ext>` exists.
3. **REGISTER.** A softphone with username `<ext>` and `<pw>` gets `200 OK`; a wrong
   password gets `401`.
4. **Suspend without a restart.** Suspend the user and wait 5 minutes. Re-REGISTER is
   refused. Record how long it took, or that it needed a VoIP restart.
5. **New user without a restart.** Create a second user. Record whether it registers
   before a VoIP restart.
6. **Context.** An INVITE from a `from-internal` endpoint routes, or does not (§3).

Steps 1–3 decide A or B. Steps 4–5 set the suspend and onboarding runbook. Step 6
confirms the onboarding rule for org defaults. Results go in an amendment here.

## Threat model

| Path | Blocked by |
|---|---|
| Building sets SIP on an adopted or another org's user | `write_target`: 404 / 403 |
| Building takes another building's extension | Uniqueness per profile; the profile is the org's |
| Building widens an adopted user's context | Client role groups count only for that client's owned users |
| PBX of building B reads building A's secrets | `expand` binds `$1` to the PBX's own `<c>` |
| Suspended or terminated user keeps a working phone | ACL filter hides the secret; bounded by UED's reload (§4) |
| Sniffed LDAP traffic | Private box-to-LDAP path; HA1 if the gate passes |
| PBX compromise | One secret kind, owned active users of one client. Revoke: `DELETE` or `rotate` the PBX client |

## Consequences

- SafeNest needs, per building: one PBX client, an assigned profile with SIP on
  `ou=<c>,ou=org`, an org context default, and a `PUT /sip` per resident. Migration
  passes `password` and `extension`, so phones keep both username and secret.
  SafeNest secrets shorter than 12 characters are refused; SafeNest checks before
  migrating.
- UED configuration per box: basedn, PBX DN, realm `asterisk`, default `sfilter`.
- azb-AD's existing SIP endpoints are renamed from uid to extension, and the sealed
  device payload's `sipUsername` changes value: installed devices re-provision.
- Schema: one attribute on the azblink arc; the ACL gains one rule; dev and prod LDAP
  config both change.
- The OID clash with upstream Asterisk stays; fixing it is a separate change.

## Test plan

New cases in `tests/test_client_scope.py` and `tests/test_uc_attrs.py`:

1. Create with a SIP profile writes the extension into all seven §1 attributes, and
   `AstAuthMd5Cred` when §4 option A is in force.
2. Scoped `PUT /sip` on an owned contained user: enable, then password only. Adopted
   user 404, non-contained 403, org without SIP profile 409, `extension` after enable 409.
3. Explicit extension taken, or outside range: 409. Allocation skips a hand-set value.
4. Context: user beats group beats org beats `from-internal`. Two groups disagree →
   `default`. A building group does not change an adopted user. Member remove
   recomputes.
5. PBX DN reads the §4 secret of its own owned user. It cannot read another org's,
   cannot read the other secret kind, and cannot read it while the user is suspended.
   It reads it again after unsuspend.
6. `kind: "pbx"` for an unregistered client or missing org: 422.
7. Audit rows `scoped_set_sip` carry no password.
8. Device provisioning seals `sipUsername` = extension.

## References

- Related ARDs: ARD-001, ARD-004, ARD-006, ARD-017, ARD-019
- RPT: `docs/reports/2026-04-17-sip-sso-e2e-report.md` (§5, §8, §13.2, §14)
- UED form: `playbooks/web-configure/azblink-server-sip-config.yml`
- Vendor kit (outside this repo): `azblink-ldap-testing/addComboPJ`, `useradd2.php`,
  `asteriskAUX.ldap-schema`
- SafeNest: `azb-safenest/docs/runs/20261008-sso-phase-3/PLAN.md` § Phase 4,
  `G18-ASK.md` § Not part of G18
- Spec sections: `spec/03-data-architecture.md`, `spec/05-provisioning.md`,
  `spec/06-deployment.md`, `spec/07-security.md`, `spec/08-integration-points.md`

## Amendments

### 2026-10-20: accepted by the owner, as recommended

The owner accepted every recommendation above:

1. **Extension: option D.** The endpoint name is the extension, because UED keys
   accounts on `AstAccountName` and has no mapping for a custom attribute.
2. **Scoped SIP writes:** `PUT /api/users/{uid}/sip`, owned and contained users, the
   org's profile.
3. **Context:** user > group > org > `from-internal`, materialised into
   `AstEndpointContext`; org defaults set at onboarding.
4. **PBX read, gated:** HA1 (`AstAuthMd5Cred`, `AstAuthType=md5`) only if the PED80
   REGISTER test (§ Verification before acceptance, steps 1–3) passes. Otherwise
   plaintext `AstAuthPassword`. Both sit behind the suspend/terminate ACL filter.

Decision only. Spec sections change in the implementation PR, which also records the
gate's results here.

### 2026-10-20: verification results

The § Verification before acceptance test ran on PED80 (192.168.122.220) on 2026-10-20,
06:22–06:30 UTC, against the option-D shape at `52d0d64` (herdr thread t-0021). These
results follow from the owner's conditional acceptance; where they differ from the body
above, this amendment wins.

What the test showed about UED: asterisk reads PJSIP objects live from LDAP through
realtime (`res_ldap.conf`), one lookup per request. There is no SSH, so
`pjsip show auth` could not be run.

1. **§4 resolves to option B.** `AstAuthType=md5` with a 32-hex `AstAuthMd5Cred` and no
   `AstAuthPassword` answered `500` to REGISTER before any challenge, for right and wrong
   passwords alike. The variants `MD5`, `digest`, a plaintext password alongside, and a
   VoIP stop/start all gave the same result. `userpass` with `AstAuthPassword` on the same
   entry gave `200`, and a wrong password `401`. Most likely `res_ldap.conf` does not map
   `md5_cred`; this is inferred, since the file could not be read. So:
   - `AstAuthType` stays `userpass`, and the PBX reads plaintext `AstAuthPassword`.
   - The §4 ACL rule names `attrs=AstAuthPassword`. It must cover `AstAuthPassword`,
     not only `AstAuthMd5Cred`.
   - HA1 is deferred. azb-AD does not write `AstAuthMd5Cred` until it is re-tested.
   - **Re-test condition:** Azblink confirms that UED's `res_ldap.conf` maps `md5_cred`
     to `AstAuthMd5Cred`, or provides a shell to run `pjsip show auth`. Then re-run
     verification steps 1–3. Only a pass there moves §4 to option A, by amendment.
2. **Option D is confirmed, with corrected wording.** All seven attributes set to the
   extension, uid separate: REGISTER with the extension as username → `200`. UED keys the
   endpoint on `AstEndpointId`, with `AstAorId` and `AstAuthUsername` for the AoR and the
   digest username. Changing `AstEndpointId` alone broke registration; changing
   `AstAccountName` alone did not change the registered name. `AstAccountName` is still
   required, because the default `sfilter` `(AstAccountName=*)` selects on it. Read
   Context and §1 ("UED keys accounts on `AstAccountName`") with this correction. UED
   offers no attribute mapping, so option A stays rejected.
3. **§3 fallback becomes `default`.** An INVITE from a `from-internal` endpoint got `404
   Not Found`; with `default` or `all`, the same INVITE got `200`. UED's dialplan has only
   `default`, `middle` and `all`. Step 4 of the §3 resolution is now `default`, the more
   restrictive of SafeNest's two values. Existing azb-AD SIP endpoints all carry
   `from-internal`, so none of them can place calls on UED today. The implementation PR's
   migration (§1) rewrites them to the resolved context.
4. **Propagation and the revocation bound.** All without a VoIP restart:
   - LDAP changes apply in about 1 s: a new user registers, a removed secret gets `401`
     on the next REGISTER, a restored secret gets `200`, and a deleted user gets `401`
     at once.
   - The runbook needs no VoIP restart for suspend or onboarding; the §4 "Revocation
     latency is UED's" bullet no longer applies.
   - An existing registration stays in `pjsip show contacts` until its Expires runs out.
     A suspended user's new REGISTERs and outgoing INVITEs fail at once, but calls to
     their already-registered phone can still reach it until then.
   - The threat-model row "bounded by UED's reload" reads "bounded by the phone's
     registration expiry".
5. **Least-privilege bind works, and the §4 rule is required.**
   - UED accepted a non-admin bind DN under `ou=clients` with basedn
     `ou=<org>,ou=people,dc=azblink,dc=com`, and loaded the endpoint.
   - Without the §4 rule, ACL rule {2} hides `AstAuthPassword`, so REGISTER got `401`;
     the admin bind got `200`.
   - Binding as the user itself cannot search the org OU.
   - The ACL change itself was not made. The implementation PR adds the rule, and its
     test plan case 5 covers it.

No other part of the decision changes. The probe scripts that re-run the gate are in the
t-0021 thread library (`t21.py`, `ued.py`, `q4.py`).

### 2026-10-20: implementation

Built as decided, with the verification-results amendment applied (option B, option D, fallback
`default`). Where this amendment differs from the body above, it wins.

What was built:

- §1: `build_uc_attrs` writes the extension into the seven naming attributes. Allocation and an
  explicit value both run under `OrgDB.sip_extension_lock` (a `pg_advisory_xact_lock` keyed on the
  profile), check LDAP for `(azblinkProfileId=p)(AstAccountName=ext)`, and skip or refuse a taken
  value. The device payload seals `sipUsername` from `AstAuthUsername`. No `AstAuthMd5Cred`.
- §2: `PUT /api/users/{uid}/sip`, as in spec 05 §5.4.
- §3: `azbSipContext` (`AZBlinkAttr:8`) and the resolution, recomputed on context writes at every
  level, member add and remove, `move_org`, SIP enable, and group delete.
- §4: `kind: "pbx"` and ACL rule `{2}` on `attrs=AstAuthPassword`; the UC-secret rule is now `{3}`
  and the `ou=clients` read rule `{4}`.
- Migration: `tools/migrate_ard020_sip.py`, run inside the API container (spec 05).

Deviations from the body, each with its reason:

1. **Same extension after enable answers 200.** The body says `extension` after enable answers 409.
   A different value still does; the value the user already has is accepted as a no-op, so a
   migration call that is retried after a lost response does not fail.
2. **An admin caller uses the profile of the user's own org.** The body defines the profile only
   for a scoped caller. For `user_management` holders it is the profile assigned to the org of the
   user's DN, with the same 409 and 403 rules.
3. **The org level has a route: `POST /api/org/sip_context {dn, sipContext}`** (`org_management`).
   The body names no route. At every level an explicit `null` clears the value.
4. **Group delete also recomputes its members.** Not in the body's trigger list; without it a
   deleted group's context would stay materialised on its former members.
5. **The PBX registry row is keyed on the client id.** `ldap_provisioned_clients.client_id` is
   unique, so a PBX and a generic client cannot share an id (409). Their DNs never collide, and
   `rotate` and `DELETE` work by the same id unchanged. List rows report `kind`.
6. **Org level means exactly the org entry of the user's own DN**, with no walk up to ancestor
   orgs, as the body says. Stated because nested orgs could suggest otherwise.
7. **`middle` is not admitted.** UED's dialplan also has `middle`, but §3 admits `default` and
   `all` only; adding a value is a further amendment.
8. **A scoped group `PATCH` sends only `sipContext`** (422 for any other field), and may target an
   in-scope group even when it is nested in another group: a group's context reaches only its
   direct members, so ARD-019's nesting refusal for member writes does not apply.
9. **Migration details.** An entry without `azblinkProfileId` takes its org's assigned profile,
   which is then recorded on the entry. An entry with no SIP profile on itself or its org is
   skipped, listed, and makes the script exit 1. There is no HA1 to recompute (amendment 1). The
   dev directory held no SIP entries on 2026-10-20.
10. **The API tolerates a directory without `azbSipContext`.** It reads every level as unset there
    and answers a context write 503 `sip_context_unavailable`, so the code can merge before the
    schema reaches dev or prod. The body assumed both change together.
11. **Two concurrent enables of one user:** the second answers 409 `already_enabled` instead of
    overwriting the first one's extension.

### 2026-10-20: inactive users (owner)

`PUT /api/users/{uid}/sip` refuses a suspended or terminated user with 409; the body was silent.

### 2026-10-21: disjoint, capped SIP ranges (owner)

Where this amendment differs from the body or an earlier amendment, it wins.

azb-AD owns the SIP number space for every system it serves (SafeNest and others), and each PBX
supports a limited number of accounts. So:

1. **Disjoint.** A profile's SIP range (`counter_start`..`counter_end`) may not share an
   extension with another profile's SIP range, drafts and disabled services included. Adding a
   SIP service, or changing its range, answers 409 naming the other profile. The check and the
   write run in one transaction under an advisory lock. This replaces §1's "two profiles may use
   the same number" for allocated ranges.
2. **Capped.** A range is at most `SIP_RANGE_MAX_SIZE` extensions wide (config, default 1000),
   else 422. Each block is sized to its PBX's capacity, up to that ceiling; there is no separate
   per-profile capacity field.
3. **Existing data is not rewritten.** A range that breaks either rule stays valid until someone
   changes it; any change must then satisfy both. On 2026-10-21 dev held two SIP profiles:
   Standard Profile 1000-1999 (passes) and safenest-dev 6000-9999 (4000 wide, over the cap, no
   overlap). Narrowing safenest-dev is a separate, owner-approved step.
4. **Clone.** A cloned profile's SIP service starts without a range, since copying it would
   overlap the source.
