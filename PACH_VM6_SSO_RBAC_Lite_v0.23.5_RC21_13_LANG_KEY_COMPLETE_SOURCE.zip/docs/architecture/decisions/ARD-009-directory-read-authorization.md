---
status: accepted
accepted_at: 2026-07-06
decision_effective_date: 2026-07-06
supersedes: []
superseded_by: []
pr: "#187, #196"
spec_sections_affected: ["07-security", "08-integration-points"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-07-06 • **Effective:** 2026-07-06 • **PR:** #187, #196
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 07-security, 08-integration-points
<!-- summary:end -->

# ARD-009: Directory-Read Authorization & Lock-DoS Hardening

## Context

Before this change every endpoint behind `require_user` (`_claims_from_auth_header`) was reachable by **any** authenticated OIDC principal. Under the D1 decision (2026-07-05, **Model A — one deployment per tenant**) self-service users authenticate only for `/api/me*`, yet they could still read arbitrary-target sensitive directory data: enumerate any user's provisioned devices and stats, and read org-profile config (integration/policy blocks + nonce). This is the residual of the production-readiness audit's **C1** finding once org-profile *mutations* were already permission-gated. Separately, the DS-1 account-lock counter keyed on a username lifted from an **unverified** JWT, letting an attacker lock any named victim — including admins — with a forged token (**H4**).

Both fixes shipped to `main` as the verified tranche of the audit (PRs **#187**/**#196**) under the emergency `ARD-POST: placeholder` lane, which filed an `arch-post-followup` issue with a 7-day clock. This retro-ARD converts that placeholder into the numbered record for the **shipped** behavior (C1 read-authz + H4). The still-unstarted parts of the source proposal — M1 machine identity and finer per-target/per-tenant ownership — are out of scope here and remain future work.

## Decision

- **New `require_directory_read` dependency** (`src/backend/main.py`) authorizes sensitive arbitrary-target directory reads. It admits a caller who holds **any** management permission in `_MANAGEMENT_PERMISSIONS` — `user_management`, `org_management`, `device_provisioning`, `audit_log_access`, `system_configuration` — **or** is a member of `OIDC_ADMIN_GROUP`; otherwise `403 "Directory read requires an operator role"`. It is **fail-closed**: an RBAC-lookup error does not grant access.
- **Applied to four reads:** `GET /api/users/{uid}/devices`, `GET /api/users/{uid}/stats`, `GET /api/orgprofiles`, `GET /api/orgprofiles/{profile_id}`. The org-profile *mutation* `POST /api/orgprofiles` was already gated on `require_permission("device_provisioning")` under Model A and is unchanged.
- **Self-service stays open.** `/api/me*` (including `/api/me/devices`) remains on `require_user`, scoped to the caller's own identity. Operators/admins are **never** blocked by the gate (backward compatible).
- **H4 — lock-DoS removed.** `_claims_from_auth_header` no longer auto-locks the account named in a signature-invalid token. The unverified username is recorded for **audit only** (`record_auth_failure(username=…)`), never used to lock. Abuse control for bad-token floods is IP-based blocking (DS-2, XFF-spoof-resistant via H5). Account lock stays an **explicit admin action** (`/api/users/{uid}/unlock`, `/api/users/{uid}/lock-status`) and is still enforced **after** successful token verification.
- **Model A framing.** This is the authorization-tightening realization of C1 under Model A; `org_profiles.tenant` stays an org-grouping column, not a cross-customer isolation boundary. Model B (shared-instance multi-tenancy) is explicitly *not* decided here.
- **Coverage.** `tests/test_rbac.py::TestC1DirectoryReadAuthz` proves, via the real-OIDC `non_admin_client`, that a non-admin gets `403` on all four gated reads, an admin is never `403`, and non-admin self-service `/api/me/devices` returns `200`.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Leave all reads on `require_user` (status quo) | Any authenticated self-service user could enumerate every user's devices/stats and read org-profile config — the C1 over-exposure the audit flagged. |
| Full Model B isolation (tenant claim + per-tenant LDAP subtrees + query predicate) | D1 chose Model A (2026-07-05). B multiplies LDAP schema, provisioning, and Authentik seeding work and is easy to get subtly wrong; deferred to its own ARD if shared instances become a real requirement. |
| Per-endpoint `require_permission("…")` instead of one shared gate | Directory reads legitimately span several management roles; picking one permission per route is arbitrary. A single "any operator permission OR admin" dependency is one auditable chokepoint. |
| Target-scoped ownership checks now (proposal C1 §3) | Correct end-state but larger; Model A's blast radius is a single tenant, so the coarse operator gate closes the exposure without threading a `Principal`/scope through every `orgdb` call. Left as follow-up. |
| Gate the aggregate-browse endpoints too | Would turn off "any authenticated employee can browse the company directory" — an **unresolved product decision** (address-book visibility). Left open (see Consequences). |
| Keep username-keyed auto-lock (H4 status quo) | The username comes from an unverified token; Authentik (not this API) performs password auth, so a bad token here is not evidence of a password-guess against the named user. Auto-locking on it let an attacker lock any victim. |

## Consequences

**Positive**
- Self-service users can no longer enumerate arbitrary users' devices/stats or read org-profile config; the sensitive-read surface is operator-only.
- An attacker can no longer lock arbitrary accounts (including admins) via a forged-token username; lock is admin-driven and post-verification only.
- One auditable authorization chokepoint (`require_directory_read`), fail-closed on RBAC-lookup error; regression-guarded by `tests/test_rbac.py`.
- The `arch-post-followup` from the `ARD-POST: placeholder` on #187/#196 is resolved by this record.

**Negative / trade-offs**
- `require_directory_read` is a **coarse** "any management permission OR admin" gate, not target-scoped ownership: an operator holding a single unrelated management permission can read all four surfaces. Finer per-target/per-tenant ownership checks (proposal C1 §3) are not implemented.
- **Two-tier, per-route split.** `GET /api/users/{uid}` (the identity record itself) stays browsable on `require_user`, while its sub-resources `/devices` and `/stats` are gated. This is intentional (sensitive sub-resources vs. address-book identity) but the boundary is per-route, not uniform.

**Open follow-up — UNRESOLVED product decision (no decision asserted here)**
- The aggregate directory **browse** endpoints remain on `require_user`, so any authenticated employee can browse the directory: `GET /api/users`, `GET /api/users/search`, `GET /api/users/{uid}`, `GET /api/users/{uid}/groups`, `GET /api/org/tree`, `GET /api/orgs/*`, `GET /api/groups*`. Whether this **"address-book visibility"** is intended, or whether these should also move behind `require_directory_read`, is a **product-owner decision** deliberately deferred out of this ARD. This record does **not** decide it.
- Also unstarted from the same proposal, each its own future ARD: **M1** machine identity (per-agent service principals) and the **target/tenant-scoped ownership** model (Model B, if shared instances are ever sold).

## References

- PRs: #187 (C1 directory-read authz + H4 lock-DoS removal), #196 (production-readiness hardening — tranche 1 of #187)
- Proposal: `docs/architecture/proposals/2026-07-05-tenant-isolation-and-machine-identity.md` (findings C1, H4; D1 = Model A)
- Code: `src/backend/main.py` — `require_directory_read`, `_MANAGEMENT_PERMISSIONS`, `_claims_from_auth_header`
- Tests: `tests/test_rbac.py::TestC1DirectoryReadAuthz`
- Spec sections: `07-security`, `08-integration-points`
- Related ARDs: ARD-002 (Authentik-only OIDC — the auth plane this gate sits on), ARD-004 (Profile services — the org-profile reads now gated)

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->

### 2026-07-08 — Aggregate directory browse resolved to operator-only (address-book decision)

The **open follow-up** in *Consequences* (the aggregate directory *browse*
endpoints left on `require_user`) is now **decided**: the product owner resolved
address-book visibility to **operator-only**. These twelve GET reads move behind
`require_directory_read`, matching the sensitive per-target reads gated in the
original decision:

`GET /api/users`, `/api/users/search`, `/api/users/{uid}`,
`/api/users/{uid}/groups`, `/api/org/tree`, `/api/org/users`, `/api/orgs/tree`,
`/api/orgs/detail`, `/api/orgs/users`, `/api/groups`, `/api/groups/{cn}`,
`/api/groups/{cn}/members`.

- This **supersedes** the "*any authenticated employee can browse the directory*"
  framing recorded (as deliberately undecided) in the original *Consequences*.
  A self-service (non-operator) OIDC principal now receives `403` on directory
  browse; only operators (`_MANAGEMENT_PERMISSIONS`) and admins may enumerate.
  Self-service `/api/me*` is unchanged, as is `/api/tenant` (config metadata)
  and the self-service `/api/provision/device*` endpoints (caller-scoped).
- **Consistency note:** this closes the per-route split noted in *Consequences* —
  `GET /api/users/{uid}` now sits behind the same gate as its `/devices` and
  `/stats` sub-resources. `/api/org/users` is included for parity with
  `/api/orgs/users` (identical exposure) though it was not in the original
  enumerated list.
- **Coverage:** `tests/test_rbac.py::TestC1DirectoryReadAuthz.GATED` is extended
  with all twelve endpoints; non-admin → `403`, admin/operator unaffected,
  self-service `/api/me/devices` → `200`. The stale "UNVERIFIED DRAFT" note on
  `require_directory_read` is removed (the gate is verified + merged).
- **Admin-UI impact:** the admin console is operator/admin-facing (ARD-002,
  Plane B); its directory queries (`lib/queries/*`) run as operators, so
  legitimate flows are unaffected. Verified against the live stack.

**PR:** release-prep v0.13.0 · **Spec:** §07-security bumped.

### 2026-07-31 — `GET /api/me` answers 200 for an unprovisioned principal (#237)

The amendment above states that "self-service `/api/me*` is unchanged". That
remains true of its **authorization** — the route stays on `require_user`, which
was the deliberate choice this ARD records. What changes is its **response for a
principal with no LDAP entry**, which the original decision never addressed
because it was reasoning about who may read *other* people's records, not about
what the directory owes a caller reading their own.

`GET /api/me` previously returned `404 User not found in directory` whenever
`ldap_client.get_user(uid)` came back empty. Under ARD-002, Authentik owns
authentication and nothing guarantees an authenticated principal exists in LDAP,
so that state is legitimate and reachable in production, not only in dev:

- an Authentik-side admin such as `akadmin`, or anyone created in the IdP but not
  provisioned into the directory;
- the synthetic dev-auth principal, which by construction has no entry.

Leaving these on `404` conflated "you do not exist" with "your profile is not in
the directory yet", and gave the frontend nothing to act on. Because
`useLanguageSync` is mounted in the app root and reads this endpoint on mount, it
also meant a console error on **every** authenticated page load.

- **New shape:** `200 {ok, provisioned: bool, user: {...}}`. When
  `provisioned` is `false` the `user` object carries the same key set as a
  directory-backed one, populated only from OIDC claims (`uid`, `displayName`,
  `mail`), with `accountStatus: "unprovisioned"`. Callers need no shape-awareness;
  a language-preference read simply sees no preference.
- **Unchanged:** `PATCH /api/me` and the `/api/me` password routes still `404`.
  They act on a directory entry, and there is none to act on. The distinction is
  the point — reading your own identity is always answerable, writing to a
  directory record is not.
- **Not chosen:** provisioning an LDAP entry at first login would remove the state
  entirely, but that is a far larger change and belongs with the tenant-isolation
  work. This ARD records that unprovisioned-but-authenticated is a state the API
  represents honestly, not one it eliminates.

**PR:** #234-batch · **Spec:** §08-integration-points.
