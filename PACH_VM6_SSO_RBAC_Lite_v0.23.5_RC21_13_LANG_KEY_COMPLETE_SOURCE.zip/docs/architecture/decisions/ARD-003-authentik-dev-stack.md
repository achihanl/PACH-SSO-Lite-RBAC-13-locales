---
status: accepted
accepted_at: 2026-03-04
decision_effective_date: 2026-03-04
supersedes: []
superseded_by: []
pr: "#14"
spec_sections_affected: ["06-deployment", "08-integration-points"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-03-04 • **Effective:** 2026-03-04 • **PR:** #14
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 06-deployment, 08-integration-points
<!-- summary:end -->

# ARD-003: Authentik Dev Stack

## Context

After ARD-002 made Authentik OIDC the sole auth path for the web admin UI, the dev/test environment needed a local OIDC IdP for end-to-end login flow testing without external infrastructure. Previously, dev testing used `DEV_AUTH_TOKEN` bypass exclusively, which doesn't exercise the real OIDC flow (PKCE code challenge, token exchange, userinfo fetch, consent screen). The absence of a local Authentik instance meant OIDC-related bugs could only be caught in staging or production.

## Decision

Add Authentik to the Docker Compose dev stack as a local OIDC Identity Provider.

Key additions:

- **`authentik-postgres`** — separate PostgreSQL instance for Authentik's own schema (sharing AZBlink's Postgres would risk migration conflicts)
- **`authentik-server`** — Authentik 2025.8 web server (`:9000`), joined to both `azblink-net` and `cloudflare-tunnel` networks
- **`authentik-worker`** — Authentik background worker (shares same image, `worker` command)
- **`authentik-seed`** — one-shot container (`restart: "no"`) running `deploy/dev/authentik-seed/seed_authentik.py`
- **Redis reuse** — Authentik 2025.8 requires Redis; reuses AZBlink's existing Redis service

Seed script creates (idempotent, safe to run multiple times):

- OAuth2 provider (`public` client type, PKCE required, `azblink-directory` client ID, 8h access / 7d refresh tokens)
- Application linked to the provider with launch URL
- IT-Admins group with `akadmin` assigned
- Test users (alanl/alanl123!) added to IT-Admins group
- Redirect URIs for localhost (`:8081`), LAN IP (`192.168.4.111:8081`), and Cloudflare tunnel (`azblink-ad.keithmoc.dev`)

OIDC dual-URL handling:

- Backend uses Docker-internal URL (`http://authentik-server:9000/application/o/azblink-directory/`) for JWKS/discovery fetching
- Frontend uses Cloudflare tunnel URL (`https://authentik.keithmoc.dev/application/o/azblink-directory/`) for browser login redirects
- `OIDC_ACCEPTED_ISSUERS` (comma-separated) handles both issuers in token validation, because Authentik stamps the `iss` claim based on the URL used to access it

Bootstrap strategy:

- Zero-touch via environment variables (`AUTHENTIK_BOOTSTRAP_PASSWORD`, `AUTHENTIK_BOOTSTRAP_TOKEN`, `AUTHENTIK_SECRET_KEY`), read on first startup only
- `AUTHENTIK_BOOTSTRAP_TOKEN=dev-authentik-api-token` provides API access for the seed script
- First startup takes ~60s for Authentik DB migrations before API is reachable (seed script polls 30x5s)

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Mock OIDC provider (e.g., simple JWT issuer) | Doesn't test real Authentik API behaviors; misses gotchas (redirect_uris format, invalidation_flow requirement, signing_key for JWKS, property_mappings for scopes) |
| Shared remote Authentik instance | Dev environment should be self-contained; network dependency for local development; risk of shared state between developers |
| Keycloak as alternative IdP | Project uses Authentik in production; testing against different IdP misses Authentik-specific behaviors and API quirks |
| DEV_AUTH_TOKEN bypass only (no local IdP) | Sufficient for automated tests but doesn't exercise the real OIDC browser flow; bugs in PKCE, callback handling, and consent would go undetected |

## Consequences

- **Positive:** Full end-to-end OIDC testing locally; discovered 5+ Authentik API gotchas during implementation (documented in `CLAUDE.md` section "Authentik API Gotchas"); dev stack is fully self-contained; `DEV_AUTH_TOKEN` preserved for CI test suite (no Authentik needed in automated tests)
- **Negative / trade-offs:** Dev stack is heavier (~60s Authentik startup for DB migrations on first boot); requires separate PostgreSQL instance for Authentik; Docker Compose file grows larger (4 new services); Authentik 2025.8 still requires Redis (later versions removed this dependency but may have breaking changes)
- **Risks:** Authentik version updates may break seed script API calls (mitigated: pinned to 2025.8; seed script has detailed error handling and idempotent operations); `AUTHENTIK_BOOTSTRAP_TOKEN` is created on first startup only and cannot be changed via env vars afterward

## References

- Design: `docs/plans/2026-03-04-authentik-dev-stack-design.md`
- Implementation plan: `docs/plans/2026-03-04-authentik-dev-stack-plan.md`
- Seed script: `deploy/dev/authentik-seed/seed_authentik.py`
- Gotchas documented: `CLAUDE.md` section "Authentik API Gotchas (2025.8+)"
- Knowledge: `docs/knowledge/libraries/authentik-admin-api-v3.md`
- Knowledge: `docs/knowledge/libraries/authentik-oidc-provider.md`

## Amendments

### 2026-10-22: 15-minute admin access token, converged on every seed run

This amendment wins over the body's "8h access / 7d refresh tokens".

- The `azblink-directory` provider issues a 15-minute access token. The refresh token stays at 7 days.
  The admin UI already refreshes within 5 minutes of expiry, so a session still lasts the refresh
  token, while a leaked or revoked access token now outlives its revocation by at most 15 minutes
  instead of 8 hours.
- Token validity is no longer create-time only. On every run the seed patches the access and refresh
  token validity it declares onto an existing provider (the web provider, service clients and
  first-party clients), so an install seeded before this change converges on its next seed run. A
  run that finds the values current patches nothing.

Applies to production too: the same seed script configures every environment's Authentik (§06).
