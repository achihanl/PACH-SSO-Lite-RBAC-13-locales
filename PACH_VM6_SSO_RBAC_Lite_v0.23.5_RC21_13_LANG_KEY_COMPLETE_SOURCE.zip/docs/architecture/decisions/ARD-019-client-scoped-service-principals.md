---
status: accepted
accepted_at: 2026-10-20
decision_effective_date: 2026-10-20
supersedes: []
superseded_by: []
pr:
spec_sections_affected: ["03-data-architecture", "04-authentication", "06-deployment", "07-security", "08-integration-points"]
---
<!-- summary:begin -->
**Status:** accepted • **Accepted:** 2026-10-20 • **Effective:** 2026-10-20 • **PR:** #353 (decision); implementation in the PR that accepts it
**Supersedes:** — • **Superseded by:** —
**Spec sections affected:** 03-data-architecture, 04-authentication, 06-deployment, 07-security, 08-integration-points
<!-- summary:end -->

# ARD-019: Client-Scoped Service Principals

## Context

A first-party client (ARD-018) owns a namespace in this directory: its role
groups `<c>-<role>` and, once onboarded, the org `ou=<c>`. Today it can only
read that namespace through azb-AD admins. SafeNest phase 3 needs each building
box to write its own roster: create residents, edit them, reset their
passwords, suspend them, and move people between its role groups (gap report
G18, decision 17; SafeNest's ask is `azb-safenest/docs/runs/20261008-sso-phase-3/G18-ASK.md`,
items A1–A4).

The only grant that admits those writes is `user_management`, and it is
directory-wide:

- Every user write and every group write checks just that one permission
  (`src/backend/routers/users.py:294,326,406,420,434,567,597,619,721`,
  `src/backend/routers/groups.py:190,227,253,275,317,337,359`). No route looks
  at *which* user or group is the target.
- ARD-017 contains *who may grant* a permission (`assert_can_confer`,
  `src/backend/auth.py:300-321`). It does not restrict *what* a holder may
  touch. A service principal's grants are a flat set of permission names
  (`OIDC_SERVICE_PERMISSIONS`, `src/backend/config.py:86-91`).
- So a SafeNest box holding `user_management` could reset any user's password
  (`users.py:405-416`), add itself or anyone to LDAP `IT-Admins`, edit every
  other building's `safenest-<b>-*` groups, export the directory
  (`users.py:188-193`), and terminate users.

Facts the design builds on:

- **The namespace already exists.** `client_group_owner()` maps a group cn to
  its first-party client (`src/backend/ldap_client.py:541-547`). `create_group()`
  forces those groups to be lowercase and to sit directly under `ou=groups`
  (`ldap_client.py:559-563`, G17).
- **Org OUs mirror into people.** `create_org_ou()` creates
  `ou=<c>,ou=people` and `ou=<c>,ou=groups` beside `ou=<c>,ou=org`
  (`ldap_client.py:408-440`). A user created with `orgDn=ou=<c>,ou=org,<base>`
  lands in `uid=<uid>,ou=<c>,ou=people,<base>`.
- **Service principals have no LDAP entry.** Authentik mints their tokens for
  the account `ak-<client_id>-client_credentials`, and ARD-017 trusts a service
  grant only when `azp` and that username both match (`auth.py:286-297`).
- **Users and groups both carry `uid`.** Client role groups get `uidObject`
  with `uid=<cn>` (`ldap_client.py:582-584`, G14), and the Authentik LDAP source
  keys users and groups on the same field. Only `ak-` is reserved at user
  create (`users.py:327-330`).
- **Group writes are not audited.** `routers/groups.py` never calls
  `record_admin_action`. User writes are, except `reset_password`, which logs a
  lifecycle event with the hashed OIDC `sub` as actor (`users.py:411-414`).
- **Rate limits key on client IP only** (`src/backend/rate_limit.py:109,139`).

## Decision

**A client-scoped service principal** is an ARD-017 service client whose only
grant is a scope: one registered first-party client `<c>`. Within that scope it
may run nine calls on the existing routes. Outside it, it holds nothing.

### 1. Principal and grant

- The principal is a separate `client_credentials` service client, seeded from
  `AUTHENTIK_SERVICE_CLIENTS` like any other (ARD-017). For SafeNest:
  `safenest-<b>-directory`. It is never the login client `safenest-<b>`, which
  ARD-018 rule 1 keeps to `authorization_code` + `refresh_token`.
- One new env value binds it to its client:
  `OIDC_SERVICE_CLIENT_SCOPES="<service_client_id>:<first_party_client_id>,…"`,
  for example `safenest-b2-directory:safenest-b2`. Same CSV shape as
  `OIDC_SERVICE_PERMISSIONS`.
- The identity check is ARD-017's: the scope applies only when `azp` is the
  service client id **and** `preferred_username` is
  `ak-<azp>-client_credentials`.
- Startup refuses (process exits) when:
  - the first-party client is not in `AUTHENTIK_FIRST_PARTY_CLIENTS`;
  - a service client in `OIDC_SERVICE_CLIENT_SCOPES` has a non-empty entry in
    `OIDC_SERVICE_PERMISSIONS` (one principal is either scoped or holds RBAC
    permissions, never both). An empty entry `<id>:` is allowed: prod's
    `env.j2` renders one for every service client;
  - two registered first-party ids nest, i.e. one starts with `<other>-`
    (`safenest` and `safenest-a1`). Today `client_group_owner()` resolves such a
    pair by sort order, and the ARD-018 access policy `<client_id>-*` would let
    `safenest-a1-*` members sign in to `safenest`. This check goes in the seed's
    `parse_first_party_clients` (`deploy/dev/authentik-seed/seed_authentik.py:104-129`)
    and in `config.py` alike.
- The scope confers no RBAC permission. `require_permission`,
  `require_directory_read` and `assert_can_confer` treat the principal as
  holding nothing, so every route not listed in §3 answers 403, as today.
- The grant is static config, like ARD-017's. Changing it is a deploy.

### 2. What is in scope

| Term | Definition (all exact, all lowercase) |
|---|---|
| In-scope group | DN is exactly `cn=<c>-<role>,ou=groups,<base>` where `<role>` matches `^[a-z0-9]+$`. Not `client_group_owner()`'s case-insensitive prefix. The hyphen-free role means `safenest-a1-admin` can never be in scope for a client `safenest`. Only azb-AD admins create these groups; the principal cannot |
| Owned user | DN is exactly `uid=<uid>,ou=<c>,ou=people,<base>`: created through this scope, or placed there by an azb-AD admin |
| Contained | An owned user whose every group membership is an in-scope group, who has no RBAC permission (`ORGDB.get_user_permissions` is empty), and who is not in Authentik's `OIDC_ADMIN_GROUP` |
| Member | Any user, of any OU, who is a member of an in-scope group. Called *adopted* when not owned |

Writes to a user's identity or credentials need **owned and contained**. An
owned user that an azb-AD admin has since put into `IT-Admins`, another
client's group, or any group carrying RBAC permissions is no longer the
building's to write.

### 3. Admitted calls

Only these nine. The other `user_management` routes stay closed to the
principal (403): `GET /api/users`, `/search`, `/export`, `import_csv`,
`move_org`, `terminate`, `lock-status`, `unlock`, group create, delete,
`PATCH`, `/permissions`, member `/role`.

| Call | Admitted when | Returns to the principal |
|---|---|---|
| `GET /api/users/{uid}` | owned, or a member | owned: the full user. Adopted: `uid`, `dn`, `displayName`, `accountStatus` only |
| `GET /api/users/{uid}/groups` | owned, or a member | in-scope groups only |
| `POST /api/users/create` | `orgDn` is exactly `ou=<c>,ou=org,<base>`; body has only `uid`, `displayName`, `mail`, `mobile`, `orgDn`, `password`; no `groups`, no `profileId` | 201 `created`, or 409 (§5) |
| `PATCH /api/users/{uid}` | owned and contained | `displayName`, `mail`, `mobile` (the whole of `UserUpdateReq` today) |
| `POST /api/users/{uid}/reset_password` | owned and contained | |
| `POST /api/users/{uid}/suspend` | owned and contained | |
| `POST /api/users/{uid}/unsuspend` | owned and contained | |
| `POST /api/groups/{cn}/members` | `cn` in scope; `uid` is any existing user under `ou=people` | |
| `DELETE /api/groups/{cn}/members/{uid}` | `cn` in scope | |

Refusals:

- A target that is out of scope answers **404**, the same body as a missing
  one, so the grant cannot probe which uids or groups exist elsewhere.
- An owned user that is not contained answers **403**: the building already
  knows the user exists, and 404 would send its adapter into a create that then
  collides.
- A create that collides answers **409** (§5).
- A body field outside the admitted set answers **422**.

`profileId` (UC provisioning) is SafeNest phase 4. A building-scoped profile is
admitted then, by amendment.

### 4. Invariants for every caller

These close escalation paths that exist whether or not a principal is scoped:

1. **Client role groups never carry RBAC permissions.**
   `PATCH /api/groups/{cn}/permissions` with a non-empty list on a
   `<client>-*` group answers 422, for admins too. Otherwise one admin mistake
   would make every building admin a directory operator. `assert_can_confer`
   stays as the backstop: a principal holding nothing gets 403 adding anyone
   to a group that carries permissions.
2. **User uids under a client prefix are reserved.** `POST /api/users/create`
   refuses a uid that starts with any registered `<client_id>-`, as it refuses
   `ak-` today. Such a uid would collide with a role group's `uid` in the
   Authentik source (G14).
3. **uid is unique across the whole `ou=people` subtree** (A4.2).
   `create_user()` checks only the exact DN (`ldap_client.py:1055`), so `bob`
   can exist in `ou=people` and in `ou=safenest-b2,ou=people` at once, and
   `find_user_dn` (`ldap_client.py:292-301`) acts on whichever comes first.
   Enforce it in LDAP with the `unique` overlay on `uid` over `ou=people`
   (`ldap:///ou=people,<base>?uid?sub`). Also check before the add, so the API
   can answer 409 rather than a bare constraint error.
4. **Membership writes are idempotent** (A4.3). Adding an existing member or
   removing an absent one answers 200 with `changed: false`. Today LDAP's
   `attributeOrValueExists` / `noSuchAttribute` surfaces as a 500
   (`ldap_client.py:609-633`), so a retry after a lost response fails.
5. **`mail` is unique for scoped writes.** A scoped create or `PATCH` that sets
   a `mail` already on another entry answers 409. The headless flow identifies
   users by email or username (spec 08 First-Party Headless Login); two
   entries sharing an email is unexplored, and a building must not be able to
   create that situation for an admin's address.
6. **Org names equal to a registered client id are reserved.**
   `POST /api/org/create` and `/api/org/rename` (`org_management`,
   `src/backend/routers/orgs.py:81,108`) refuse a name equal to a registered
   first-party id unless the caller is in `OIDC_ADMIN_GROUP`. Otherwise an org
   operator could rename any org to `ou=<c>` and hand its users to that client.

### 5. Create collisions (A4.1)

Today a create that hits an existing DN answers 201 with `status: "exists"` and
then runs the `groups` block against the existing entry
(`users.py:334`, "intentional"). For a scoped caller that would add a stranger
to the building's group. For the scoped principal, a create whose uid exists
anywhere under `ou=people` answers **409** and writes nothing. Unscoped
callers keep today's behaviour.

### 6. Rate limit per principal (A4.4)

Scoped calls are limited per `azp`, not per client IP: one bucket per
principal, `LIMIT_SCOPED_WRITE = "600/minute"` across the seven admitted
writes. A 200-resident import then finishes in under a minute. The key comes
from the verified claims (set on `request.state` by the auth dependency).
It is never taken from an unverified token decode, which would let a forged
token drain another building's budget. Unscoped callers keep the per-IP limits.
A batch create endpoint is not added: per-`azp` limiting makes it unnecessary.

### 7. Suspend revokes Authentik tokens (A4.5)

**Recommended, owner decision.** `suspend` today changes `userPassword` and
`description` only (`src/backend/routers/users.py:563-591`), so the user's
Authentik refresh token keeps minting access tokens. Only `terminate` calls
`terminate_user_access` (`users.py:497`). For every caller, scoped or not,
suspend revokes the user's Authentik sessions, access tokens and refresh
tokens. An Authentik failure does not fail the suspend; it is logged and
audited, as termination does. SafeNest is safe either way: every token passes
SafeNest's own row check, and deactivate also removes the role group. The
revocation itself ships with readiness-audit plan row 2 (terminate also misses
refresh tokens). This ARD records the decision because a scoped principal's
deactivate depends on it.

### 8. Degraded stores

- The scope is static config and needs no store (as ARD-017).
- The owned and member checks read LDAP. LDAP down fails the call, as it does
  for every route.
- The contained check reads PostgreSQL (`get_user_permissions`) and Authentik
  (admin group membership). If either cannot answer, the write is refused with
  503, like `assert_can_confer`. A delegated write never goes ahead without
  that check. This is not ARD-012 §3's read fall-through, which applies to
  token-held admin claims.

### 9. Implementation shape (for the follow-up PR)

- One dependency in `auth.py` resolves `(claims, scope)`: `scope` is the
  first-party client id for a scoped principal, else `None`. On the nine
  routes it replaces `require_permission("user_management")` and
  `require_directory_read`. Unscoped callers keep the existing checks.
- One module holds the target checks (`in_scope_group`, `owned`, `contained`,
  `member`). Every admitted route calls it, so no route carries its own copy
  of the rules.
- No new tables, no admin UI.

## Threat model

The attacker holds a scoped principal's client secret, or is a compromised
building box. Blast radius by design: one client's role groups, and the
identity and credentials of its own contained users.

| Escalation path | How it would work | Blocked by |
|---|---|---|
| Add self to `IT-Admins` | Member add with the principal's own uid | The principal has no LDAP entry; `IT-Admins` is not in scope (404). LDAP `IT-Admins` never syncs into Authentik, whose own `IT-Admins` grants azb-AD admin (G12, ARD-018) |
| Add an owned user to `IT-Admins`, another client's group, or any RBAC group | Member add on that group | Group not in scope (404) |
| Make an in-scope group confer RBAC | `PATCH /api/groups/<c>-admin/permissions` | Route closed to the principal (403). Invariant 1 refuses it for every caller (422) |
| Rename a group into scope | Rename `IT-Admins` to `<c>-admin`, or move a group to the top of `ou=groups` | No group rename route exists: `PATCH /api/groups/{cn}` changes description and type only (`groups.py:336-355`). Scope needs the exact DN. Raw LDAP renames need the LDAP admin |
| Rename an org into scope | `POST /api/org/rename` (`org_management`) renames another org to `ou=<c>` before that client is onboarded, or a stale `ou=<c>` exists. Its users become owned (the mirror rename, `ldap_client.py:443-470`) | Invariant 6. Onboarding checks `ou=<c>,ou=people` is empty or absent. Renaming `ou=<c>` away fails closed: its users stop being owned |
| Move a privileged user into the building OU | `move_org` (`user_management`) puts an admin into `ou=<c>,ou=people`; the building then resets that admin's password | Containment: that user has memberships or permissions outside the scope (403). Covers LDAP groups, RBAC permissions, and Authentik's admin group |
| Nested groups | An in-scope group made a `member` of `IT-Admins` by raw LDAP; or a group DN added as a member of an in-scope group | The API never nests: member add resolves the uid under `ou=people` only (`groups.py:236-240`). The scope check refuses an in-scope group that is itself a member of any group (403). Whether the Authentik LDAP source expands nested `groupOfNames` is untested |
| User attribute edits | Change an owned user's `mail` to an admin's address; set `manager`, `title`, `profileId` | Scoped `PATCH` admits `displayName`, `mail`, `mobile` only. `mail` must be unique (invariant 5). `uid` is immutable |
| Credential takeover | `reset_password` or `unsuspend` on any user | Owned and contained only (else 404/403). `terminate`, `unlock`, `lock-status` are closed. The building controls `userPassword` and `azbXmppBindPassword` (`ldap_client.py:1128-1150`) of its own users only |
| Create over an existing user | `POST /api/users/create` with a uid that exists | 409, nothing written (§5). uid unique across `ou=people` (invariant 3). `ak-` and `<client>-` uids reserved (invariant 2) |
| Cross-client reach | Act on `safenest-b3-*` from `safenest-b2-directory` | Exact `<c>-<role>` match with hyphen-free role; nested client ids refused at startup (§1) |
| Token confusion | A human's app-password token minted through the service provider; a first-party login token | ARD-017's `azp` + `ak-` username check. `aud=safenest-*` login tokens are not accepted by this API (G19, `config.py:79-81`) |
| Probe the directory | Read or write arbitrary uids and read the status codes | Target refusals answer 404. Residual: member add with an arbitrary uid reveals whether it exists, which adoption needs. Bounded by the per-`azp` limit and audited (`scoped_denied`, `scoped_adopt`). Adopted reads return four fields |
| Volume | Mass create or churn | Per-`azp` limit (§6) |
| Stolen secret | Use the principal from elsewhere | Blast radius above. Revoke: rotate the provider secret or delete the provider (spec 08), or drop the scope entry and restart |

Out of scope: a human building manager acting in azb-AD's own UI. SafeNest's
UI relays through its principal. Per-human delegation would be option C below,
under a later ARD.

## Audit requirements

1. Every admitted scoped write records `admin_action_audit`
   (`src/backend/db/tables.py:185-195`): `actor` = `ak-<azp>-client_credentials`,
   `action` one of `scoped_create_user`, `scoped_update_user`,
   `scoped_reset_password`, `scoped_suspend`, `scoped_unsuspend`,
   `scoped_member_add`, `scoped_member_remove`. `detail` carries `client`
   (`<c>`), `target` (`owned` / `adopted`) and the changed field names. A
   member add of an adopted user is recorded as `scoped_adopt`.
2. Every target refusal (404, 403 containment, 409) records `scoped_denied`
   with the route, target and reason. The caller sees 404; the operator sees
   the attempt.
3. Password values never appear in audit or logs. The scoped
   `reset_password` and `unsuspend` record the actor through `extract_actor`,
   not `claims["sub"]` (`users.py:413`).
4. Group membership writes are audited for every caller, not only scoped ones
   (none are today). A scoped principal's history means little without the
   admin writes around it. This overlaps readiness-audit plan row 10; whichever
   lands first does it.
5. Audit writes stay fail-open with one log line per degraded transition
   (ARD-012 §3, §4). A failed audit write does not fail the roster write.
6. All of it is readable through `/api/audit/events`, filtered by actor.

## Alternatives Considered

| Alternative | Trade-offs | Verdict |
|---|---|---|
| **A. Client-scoped service principal** (this ARD): static grant binding one service client to one first-party client; the namespace comes from the conventions ARD-018 already enforces | No new store, no UI; survives a PostgreSQL outage for the grant itself. Reuses ARD-017's identity check and ARD-018's naming. A scope change is a deploy. Only service principals, one client each. Scope rules depend on naming conventions, so the conventions become invariants (§4) | **Chosen** |
| **B. Scope claim minted by Authentik**: a custom scope mapping per client emits e.g. `azb_scope: safenest-b2` in the service token | The grant lives in Authentik, so it can be changed without a deploy. But one custom mapping per client, and list claims merge-append across mappings (#279). An Authentik admin-API holder can then widen any client's directory rights. The API cannot validate the mapping at startup. ARD-017 already deferred token-scope mapping for the same reasons | Rejected |
| **C. Delegated ownership records**: a PostgreSQL table `(principal, resource_type, resource_id, rights)` managed in the admin UI, per group and per user | Most flexible: per-group rights, human delegates, no naming convention. But a new store and UI, a rights matrix to design and test, and rename handling for every resource. Fails closed on any PostgreSQL outage. The existing `group_member_roles` `owner` role is inert (keyed on the hashed `sub`, `groups.py:209-213`), so nothing can be reused. Nothing needs it yet | Rejected now; the path if per-human delegation is ever asked for |
| Give the box `user_management` and trust it | Zero work. One compromised box owns the directory | Rejected (G18) |
| OpenLDAP ACLs, box writes LDAP directly | Native and fine-grained. But it bypasses every API invariant: `uidObject` on role groups, the Authentik sync trigger, audit, revocation, the uid checks | Rejected |
| A dedicated roster API (`/api/clients/{c}/roster/*`) | Clean separation, no dual-mode routes. But it is a second write path for users and groups to keep in step with the first, and SafeNest's adapter already targets the existing routes | Rejected |

## Consequences

- SafeNest phase 3 is unblocked by one service client per building, one
  `OIDC_SERVICE_CLIENT_SCOPES` entry, one accepted audience and issuer, and
  the `ou=<c>` org created at onboarding. That is config, not code, from the
  second building on.
- Any later first-party client gets the same grant without design work.
- Nine routes gain a second admission path. All of it goes through one
  dependency and one check module, and the tests below pin each route.
- Six invariants apply to every caller (§4): client role groups carry no RBAC
  permissions, `<client>-` uids are reserved, uids are unique across
  `ou=people`, membership writes are idempotent, scoped `mail` is unique, and
  client-id org names are reserved. An existing duplicate uid
  or permissioned role group would block deployment of the `unique` overlay and
  must be cleaned first. The implementation checks for them.
- Suspend gains an Authentik dependency for revocation, best-effort.
- The `unique` overlay must be confirmed available in `osixia/openldap:1.5.0`
  and added to the dev and prod LDAP config. Untested.
- Prod: #351 renders `AUTHENTIK_SERVICE_CLIENTS`, `OIDC_ACCEPTED_AUDIENCES`,
  `OIDC_SERVICE_PERMISSIONS` and the service issuers from the inventory var
  `authentik_service_clients` (`deploy/ansible/roles/azblink_app/templates/env.j2:63-71`).
  The implementation adds `OIDC_SERVICE_CLIENT_SCOPES` beside them. A scoped
  principal goes in with an empty permission list, which renders `<id>:`.
- On acceptance, ARD-017 and ARD-018 each gain an amendment pointing here:
  ARD-017 for the third grant kind beside the admin group and RBAC
  permissions, ARD-018 for the nested-id refusal and invariants 1, 2 and 6.

## Test plan

New `tests/test_client_scope.py` against the real stack, with a dev scoped
principal `safenest-dev-directory:safenest-dev` and the org `ou=safenest-dev`.
Each case fails against today's code.

| # | Case | Expect |
|---|---|---|
| 1 | Each of the nine calls on an owned throwaway in `ou=safenest-dev` | 2xx; Authentik role sync triggered for member writes |
| 2 | `PATCH`, `reset_password`, `suspend` on an adopted demo user | 404 |
| 3 | Any write on an `IT-Admins` member not in a `safenest-dev-*` group | 404 |
| 4 | Member add to `safenest-other-resident`, `IT-Admins`, `Safenest-Dev-Admin`, a `safenest-dev-*` group under an org OU | 404 |
| 5 | Create with another `orgDn`, with `groups`, with `profileId`, with `title` | 403 / 422; nothing written |
| 6 | Create of an existing uid (same OU, other OU) | 409; no membership change |
| 7 | Every closed route (`GET /api/users`, `/export`, `terminate`, group create, `/permissions`, `/role`, `move_org`, …) | 403 |
| 8 | Owned user then added to `IT-Admins` (LDAP), to an RBAC group, to Authentik's admin group | 403 on `PATCH` / `reset_password` / `suspend` |
| 9 | Owned user moved out of `ou=safenest-dev` by an admin | 404 on writes |
| 10 | In-scope group made a member of another group by raw LDAP | 403 on member writes |
| 11 | Member add twice; remove twice | 200, `changed: false` on the repeat |
| 12 | Scoped `PATCH` setting another entry's `mail` | 409 |
| 13 | 601 scoped writes in one minute from one `azp`; an unscoped admin from the same IP meanwhile | 429 for the principal only |
| 14 | Human app-password token through the service provider | 403 on every route |
| 15 | Audit rows for cases 1, 2, 6 (`scoped_*`, `scoped_denied`, `scoped_adopt`), no password values | present |
| 16 | PostgreSQL stopped: owned-user write | 503; reads of owned users still work |
| 17 | Suspend (scoped and admin): the user's Authentik refresh token | rejected at `/token` (if §7 accepted) |
| 18 | Startup with a scope naming an unregistered client, a scoped principal with non-empty permissions, nested first-party ids; and with an empty `<id>:` permission entry | refuses to start for the first three, starts for the last (unit test on config parsing) |
| 19 | Invariants for unscoped callers: `/permissions` on a `<client>-*` group, create uid `safenest-dev-x`, duplicate uid across OUs, non-admin org rename to `safenest-dev` | 422 / 422 / 409 / 422 |

`tests/test_rbac.py::TestRBACNoEscalation` and `TestServiceClientRBAC` keep
passing unchanged. The OpenAPI baseline gains the 409 responses.

## References

- Related ARDs: ARD-007, ARD-009, ARD-012, ARD-017 (amended on acceptance),
  ARD-018 (amended on acceptance)
- Gap report: `docs/reports/2026-09-25-safenest-headless-login-gap-report.md`
  rows G12, G14, G17, G18; decisions 13, 17, 18
- SafeNest's requirements: `azb-safenest/docs/runs/20261008-sso-phase-3/G18-ASK.md` (A1–A4)
- Spec sections: `spec/03-data-architecture.md` (§2.1 tree, §2.4 groups),
  `spec/07-security.md` (§3 authorization model, §4 audit),
  `spec/08-integration-points.md` (API-to-API, First-Party Headless Login)

## Amendments

### 2026-10-20: accepted, with four owner decisions

The owner accepted this ARD with these decisions. Where one narrows the body above, the decision wins.

1. **Option A.** One scoped service principal per first-party client (for SafeNest,
   `safenest-<b>-directory`), bound by `OIDC_SERVICE_CLIENT_SCOPES`.
2. **§7 accepted for every caller.** Suspend revokes the user's Authentik sessions, access tokens
   and refresh tokens, whoever calls it. Terminate gains refresh-token revocation in the same change.
3. **Adoption accepted.** An existing user anywhere under `ou=people` may be added to a client's
   in-scope groups. A read of an adopted user returns `uid`, `dn`, `displayName` and `accountStatus` only.
4. **In-scope groups are a fixed role list per client**, not any `<c>-<role>` an admin creates. Each
   `OIDC_SERVICE_CLIENT_SCOPES` entry names its roles:
   `<service_client_id>:<first_party_client_id>:<role>|<role>|…`, for SafeNest
   `safenest-b2-directory:safenest-b2:admin|staff|resident|visitor`. An in-scope group is exactly
   `cn=<c>-<role>,ou=groups,<base>` for a listed role. Each role still matches `^[a-z0-9]+$`, and
   startup refuses an entry without roles.

`spec_sections_affected` gains 04-authentication and 06-deployment at acceptance: the auth ladder now
refuses a scoped principal on every route outside §3, and deployment gains the `unique` overlay and
`OIDC_SERVICE_CLIENT_SCOPES`.

### 2026-10-20: as built, and what containment means for placing users

Implemented as accepted, with these details:

- The target checks live in `src/backend/routers/_client_scope.py`, beside the routes that use them,
  so they fall under the `api_contracts` surface. The route dependencies are
  `require_scope_or_permission("user_management")` and `require_scope_or_directory_read` in `auth.py`.
- `uid` must be unique for every caller (409), and the `unique` overlay backs it. Suspend revokes
  sessions, access tokens and refresh tokens. Session revocation had used `session['pk']`, which
  Authentik 2026.5 does not return, so terminate had never revoked a session; both now use `uuid`.
- A member write that changes nothing answers `changed: false` and does not queue an LDAP source sync.

Containment applies to owned users only. An adopted user may hold any other group or permission: the
building can still add and remove them in its own groups, and never writes their identity (404). Two
consequences for whoever places users and groups (spec 08, onboarding a building's roster writer):

- A person who belongs to two buildings must be adopted (an entry in `ou=people`), never owned. An
  owned user who holds any group, RBAC permission or Authentik admin seat outside that building's
  `<c>-<role>` groups gets 403 on every identity write.
- Any group created under the org's own `ou=<c>,ou=groups` makes that building's owned users
  non-contained, since only the top-level `cn=<c>-<role>,ou=groups` is in scope.

### 2026-10-21: uidNumber unique across the directory

Invariant 3 makes `uid` unique under `ou=people`. `uidNumber` had no such rule, and the counter
alone cannot give one: every profile has its own uid range, a new profile defaults to Standard
Profile's 5000-65533, so two profiles hand out the same number. Both entries are accepted, and any
POSIX consumer (ejabberd, UED, a host's NSS) that resolves by number sees two accounts. This
amendment adds, and wins over the body where they differ:

- **`uidNumber` is unique across the whole directory**, not only `ou=people`. A second
  `olcUniqueURI` on the same `unique` overlay, `ldap:///<base>?uidNumber?sub`, refuses a second
  holder by add or modify. The scope is the base, not `ou=people`, because a uidNumber is a
  system-wide POSIX id: a consumer searching from the base cannot tell a `posixAccount` under
  `ou=clients` from one under `ou=people`. Nothing outside `ou=people` holds one today, so the wider
  scope constrains nothing that exists and covers any service account that gains `posixAccount`.
  The `uid` URI stays at `ou=people`: each URI is its own domain.
- **Allocation skips a held number** (`provisioning.allocate_uid_number`), as extension
  allocation already does per profile (ARD-020 §1). The overlay is the backstop for a race between
  two profiles. A lost race on `PUT /api/users/{uid}/sip` answers 409; on `POST /api/users/create`
  the user is created without UC services and the response carries a warning naming the uidNumber.
- **Rollout.** A fresh volume gets both URIs from `deploy/dev/ldap/unique-config.ldif`. A running
  directory gets the new URI from ansible (`ldap_source.yml`), which first refuses existing
  duplicate uidNumbers, or by hand with `deploy/dev/ldap/unique-uidnumber.ldif`.

### 2026-10-21: suspend and terminate cut off SSO, not only revoke

§7 revoked sessions and tokens, and §7's "deactivate also removes the role group" was never built
(readiness audit blocker 1). This amendment adds, and wins over §7 where they differ:

- **Suspend deactivates the Authentik user** (`is_active=false`) after revoking its sessions and
  tokens; **unsuspend reactivates it**. Measured on Authentik 2026.5 (t-0036 probe, private stack):
  an inactive user's refresh grant and app-password grant answer `invalid_grant`, sign-in is denied,
  and deactivation deletes the user's access and refresh tokens, which reactivation does not
  restore. The LDAP source sync never writes `is_active` for OpenLDAP entries, so it sticks.
  Deactivating last also wipes a token a refresh minted while the deletes ran.
- **Terminate does the same, and also** deletes the user's app passwords and queues the LDAP
  source sync, which drops the groups `disable_user` removed (§7's role-group removal).
- **`POST /api/users/{uid}/unlock` also lifts the web sign-in block**: it deletes the username's
  reputation rows and its `ldap-bind-budget:<uid>` row (spec 08 unblock runbook, step 1). It still
  does not touch a ppolicy lock.
- **A failure is surfaced, and the call still answers 200.** Each Authentik step runs even if an
  earlier one failed; a failure is logged at ERROR and lands in the audit row as `authentik_error`,
  and the response carries `partial: true` and a warning, as terminate's already did. The LDAP write
  has landed by then, so a 5xx would misreport the account's state; every step is idempotent, so
  repeating the call is the retry.

### 2026-10-22: the grant can also come from the client registry (ARD-022)

§1 says the grant is static config and a change is a deploy. That stays true for principals in
`OIDC_SERVICE_CLIENT_SCOPES`. A principal can now also be bound by `POST /api/clients/onboard`
(admin group only, ARD-022), which writes `first_party_clients`. The API reads env plus those rows
from an in-process snapshot reloaded every 10 s, keeping the last one while PostgreSQL is down, so
§8's "needs no store" still holds per call. Its `aud` and per-host issuer are accepted from the
registry. The §1 startup checks run at the onboard call for registry entries (409). Where this
differs from the body, this amendment wins.
