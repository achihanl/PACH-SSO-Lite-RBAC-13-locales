<!-- spec-meta: { scenario: "agent-onboard-client", version: "1.52.0", last_updated: "2026-10-24" } -->
# Scenario: an AI agent onboards a building client

The end-to-end run an AI agent makes to add a building client to azb-AD, written so the E2E suite
(`src/frontend/e2e/journey/`, Playwright project `journey`, workflow `.github/workflows/e2e.yml`)
can execute it step by step. It describes what the suite does today, what the agent path adds, and
which steps no test covers yet.

The behaviour under test is ARD-022 (`POST /api/clients/onboard`, spec §08 "Onboarding a building
in one call") with its relay amendment (#405, and #411's follow-ups). This document adds no behaviour: where it and §08 or
ARD-022 differ, they win and this document is wrong.

## Status of the interfaces it relies on

| Interface | Where | State on 2026-10-24 |
|---|---|---|
| `POST /api/clients/onboard`, `relayIp` included | `src/backend/routers/clients.py`, `schemas/clients.py` | merged (#405 for `relayIp`) |
| Admin journey: sign-in, onboard with the session token, LDAP/Authentik/SIP/XMPP checks | `add-client.spec.ts` test 1, `stack.ts` | merged (#406, 7c7d009) |
| MCP server `tools/directory-mcp`, tool `onboard_client` | `tools/directory-mcp/server.py` | merged (#410). Steps A1–A6 and every `callTool` below use it |
| Journey test 2, "an AI agent adds a client through the MCP server" | `add-client.spec.ts` test 2, `journey/mcp.ts` | merged (#410) |
| Admin UI Add client screen `/configuration/clients/new`, optional relay IP field included | `AddClientPage.tsx`, `onboard.ts` | merged (#409). Only the admin path (H2) uses it; the agent never does |
| Relay IP follow-ups: 409 for a relay IP another client uses, `relayIp: null` clears it | `routers/clients.py` | merged (#411). A7 steps 4 and 5 |

Test and step names below are those on main after #409, #410 and #411.

**The MCP tool sends `relayIp`.** `onboard_client` takes
`clientId, redirectUris, roles?, sipRangeStart?, sipBlockSize?, sipContext?, relayIp?, adminToken?`.
It checks `relayIp` the way the request model does (one canonical IPv4 host, not unspecified,
loopback or multicast) and sends it only when given, so a repeat without it keeps the stored one.
It drops a `null` `relayIp` like an omitted one, so **the tool cannot clear a relay IP**: #411's
clear (`relayIp: null` in the request body) is an API call only (A7 step 5). The Add client
screen has an optional **Relay IP** field, checked like the request model and sent only when
filled, and shows a stored relay with `relay.operatorStep`. An empty field leaves `relayIp` out, so
the screen cannot clear a relay IP either. The agent path does not depend on the screen.

## Actors

| Actor | Identity | Holds |
|---|---|---|
| Operator | a human `IT-Admins` member; in the suite, the seeded web admin `mei` / `password123` (README § Preseed Accounts) | the admin access token (15 min, #391) it hands to the agent |
| Agent | no identity of its own. In the suite, the plain JSON-RPC client `journey/mcp.ts` stands in for the agent's host | the MCP server's stdio session |
| MCP server | `tools/directory-mcp/server.py`, child process of the agent's host | `DIRECTORY_API_URL`, `DIRECTORY_ADMIN_TOKEN` (env), or `adminToken` per call |
| Directory API | `directory-api` | admin check `require_admin` (token's `OIDC_ADMIN_GROUP`) |
| Building | the onboarded client, acting through its service client `<c>-directory`, its PBX (`pbx-sim`) and its ejabberd (`xmpp-sim`) | the five secrets the onboard returns |

The agent acts as the operator: every API call carries the operator's token, so every ARD-022 §5
guard applies to it unchanged.

## Preconditions

1. **Stack.** A fresh disposable stack, never dev: the scenario leaves its clients behind and, in F8,
   stops Authentik. The stack is `e2e.yml`'s:

   ```bash
   docker compose --env-file deploy/dev/.env --env-file deploy/dev/relay-sim/sim.env --profile dev \
     -f deploy/dev/docker-compose.yml -f deploy/dev/docker-compose.dev.yml \
     -f deploy/dev/docker-compose.tls.yml -f .github/ci/compose.ci.yml \
     -f deploy/dev/docker-compose.relay-sim.yml up -d
   ```

   with `RELAY_SIM_NET` and `AZBLINK_EDGE_NET` set to subnets no other stack uses (CI: `10.231.44`,
   `10.231.43`), and `deploy/dev/.env` copied from `.env.example` (`ENVIRONMENT=development`, so
   `http` redirect URIs pass; `SIP_RANGE_MAX_SIZE` unset, so 1000).
2. **Ready.** `GET /api/health/deep` answers `.ok == true`, and the `authentik-seed` container has
   exited 0 (not only the OIDC discovery URL answering): the sign-in needs the seed's LDAP source and
   its `IT-Admins` sync.
3. **Seed state.** `mei` is in Authentik `IT-Admins`. The LDAP source `azblink-ldap` exists. The env
   registry holds one client, `safenest-dev` (`AUTHENTIK_FIRST_PARTY_CLIENTS`). `pbx-sim` and
   `xmpp-sim` run their shipped configs (`relayctl.py` in `relay-sim` reaches them on
   `<project>_relay-path`).
4. **MCP server.** Python 3.12 with `tools/directory-mcp/requirements.txt` (`mcp==2.3.0`) on `PATH`
   as `python3` (or `MCP_PYTHON`). Its unit tests pass first (`cd tools/directory-mcp && pytest`).
5. **Rate budget.** The onboard call allows 10 calls a minute per client address, refusals included
   (ARD-022 §5). Every call in this document comes from the runner's one address, so the suite either
   keeps any 60 s window under 10 calls or empties the limiter first (the backend suite flushes the
   stack's Redis, `fresh_rate_window`). A call counts once it reaches the handler: every 409, the
   handler's own 422s, 502 and 503. F6 (403) and F7 (401) are refused earlier by the auth
   dependency, and A3 and A7 step 1 never leave the MCP server. The agent run makes more counted
   calls than one window allows, so the suite empties the limiter before A7, before F10 and after
   F10.

Environment the suite reads. `e2e.yml` sets the first four; the rest fall back to the defaults in
`playwright.config.ts`, `journey/stack.ts`, `journey/mcp.ts` and the spec file, which match the CI
stack:

| Variable | Value on the CI stack | Set by | Used for |
|---|---|---|---|
| `BASE_URL` | `http://localhost:28081` | `e2e.yml` | UI and API; also the MCP server's `DIRECTORY_API_URL` |
| `AUTHENTIK_URL` | `http://localhost:29000` | `e2e.yml` | token endpoint, Admin API checks |
| `E2E_PROJECT` | `azblink-ci` | `e2e.yml` | finding containers by compose label |
| `E2E_SHOTS_DIR` | `e2e-shots` | `e2e.yml` | numbered screenshots (artifact `e2e-screenshots`) |
| `AUTHENTIK_API_TOKEN` | `dev-authentik-api-token` | default | Admin API checks |
| `LDAP_BASE_DN`, `LDAP_BIND_PW` | `dc=azblink,dc=com`, `adminpassword` | default | `ldapsearch` inside `openldap` |
| `E2E_ADMIN_USER`, `E2E_ADMIN_PASSWORD` | `mei`, `password123` | default | the operator's sign-in |
| `MCP_SERVER`, `MCP_PYTHON` | `../../tools/directory-mcp/server.py`, `python3` | default | how `journey/mcp.ts` starts the server |

## Fixtures

`<c>` is the client id, fresh per run. `<base>` is `LDAP_BASE_DN`.

| Fixture | Value | Note |
|---|---|---|
| client id, agent path | `e2eai` + 6 hex (`randomBytes(3)`) | admin path uses `e2e` + 6 hex; both match `^[a-z0-9]+(-[a-z0-9]+)*$`, 2–39 chars |
| redirect URIs | `["${BASE_URL}/client-callback"]` | one exact URI; `http` passes only because the stack is a dev environment |
| roles | `["admin", "resident"]` | groups `<c>-admin`, `<c>-resident` |
| SIP | `sipBlockSize: 10`; `sipRangeStart` and `sipContext` omitted | API picks a start above every profile's SIP range; context `default` |
| relay IP (A7 only) | `relay-sim`'s address on `<project>_relay-path` | one canonical IPv4 host |
| resident | uid `<c>r1`, display name `Journey Resident`, password `Journey-Pass-2026!` | created by the building, not the agent |
| resident SIP password | `Journey-Sip-2026` | extension assigned by the API |
| XMPP domain | `xmpp.relay.test` | `deploy/dev/relay-sim/ejabberd.yml` |
| wrong passwords | SIP `Wrong-Sip-Secret-1`, XMPP `Wrong-Pass-1!` | negative checks |
| stale token | `not-a-live-admin-token` | F7 |

The onboard arguments, used verbatim by every step that says "the fixture arguments":

```json
{
  "clientId": "<c>",
  "redirectUris": ["http://localhost:28081/client-callback"],
  "roles": ["admin", "resident"],
  "sipBlockSize": 10
}
```

The response every assertion reads (spec §08; `relay` since #405):

```text
{ok, clientId, created: [...], orgDn, groups: [dn, ...],
 loginClient: {clientId, clientSecret, issuerPath}, directoryClient: {clientId, clientSecret, roles},
 sip: {profileId, rangeStart, rangeEnd, context}, pbx: {bindDn, secret}, ejabberd: {bindDn, secret},
 xmppBridge: {uid, dn, password}, relay: null | {ip, operatorStep}}
```

## The run

Each step names the exact call, the expected result, and the assertion the suite makes. "Tool call"
means a JSON-RPC `tools/call` on the MCP server's stdio; its result is
`{isError?, content: [{type: "text", text}], structuredContent?}`.

### H1. The operator signs in and hands over a token

1. Browser: `GET /login` → button **Sign in with Authentik** → Authentik **Email or Username** =
   `mei` → **Log in** → password `password123` → **Continue** → consent **Continue** if shown →
   heading **Dashboard**.
2. Read the token: `JSON.parse(localStorage.getItem('azblink-auth')).state.token`.

Assert: the Dashboard heading is visible within 30 s, and the token is non-empty.

### H2. (Admin path only) the operator onboards in the UI

Not part of the agent run; listed because the same suite runs it first. **Add Client** in the
sidebar → fields **Client ID**, **Redirect URI 1**, **SIP block size (optional)** → **Add client**;
the screen's `POST /api/clients/onboard` answers 200 within 180 s. The five secrets are on screen
once (test ids `secret-<key>`) and in neither `localStorage`, `sessionStorage` nor the URL. Adding
it again shows no secrets. The admin path leaves **Relay IP (optional)** empty; the relay is the
agent's step A7.

### A1. The agent's host starts the MCP server

Spawn `python3 tools/directory-mcp/server.py` with `DIRECTORY_API_URL=<BASE_URL>` and
`DIRECTORY_ADMIN_TOKEN=<token from H1>`. JSON-RPC over stdio, one message per line:

```json
{"jsonrpc": "2.0", "id": 1, "method": "initialize",
 "params": {"protocolVersion": "2025-06-18", "capabilities": {},
            "clientInfo": {"name": "azblink-e2e-journey", "version": "1"}}}
{"jsonrpc": "2.0", "method": "notifications/initialized"}
```

Assert: `initialize` answers a result, not an error. The suite keeps the server's stderr for A4.

### A2. The agent finds the tool

```json
{"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
```

Assert: the tool names are exactly `["onboard_client"]`.

### A3. Invalid arguments never reach the API

Tool call `onboard_client` with the fixture arguments and `clientId: "Not-Valid"`.

Expected: a tool error from the server's own argument check; the API is not called.
Assert: `isError === true`. (That no request was sent is asserted by the server's unit tests
against a fake API; the E2E cannot observe it.)

Agent rule: a validation error is the agent's mistake. Fix the argument; never retry it unchanged.

### A4. The agent onboards the client

Tool call `onboard_client` with the fixture arguments. Allow 300 s (the server's own timeout).

Expected: `isError` falsy; `structuredContent` is the response above.

Assert:

- `clientId == <c>`, `orgDn == ou=<c>,ou=org,<base>`.
- `groups == [cn=<c>-admin,ou=groups,<base>, cn=<c>-resident,ou=groups,<base>]`.
- `created` contains `org`, `group:<c>-admin`, `group:<c>-resident`, `pbx`, `ejabberd`,
  `xmpp_bridge`, `ldap_source_group_filter`, `login_client`, `service_client`.
- All five secrets are non-empty: `loginClient.clientSecret`, `directoryClient.clientSecret`,
  `pbx.secret`, `ejabberd.secret`, `xmppBridge.password`.
- `loginClient.issuerPath == /application/o/<c>/`; `directoryClient.clientId == <c>-directory`.
- `sip.rangeEnd - sip.rangeStart + 1 == 10`, `sip.context == "default"`; `relay` is `null`.
- The server's stderr contains none of the five secrets and not the admin token.

Agent rule: the five secrets come back from this call only. The agent hands them to the operator
once, through the channel the operator named, and repeats them nowhere else (no summary, log or
later message).

### A5. The client lands in every system

The same checks for either path (#410's `landsEverywhere`):

| System | Check | Assert |
|---|---|---|
| LDAP | `ldapsearch -s base` as `cn=admin,<base>` inside `openldap`, for each of `ou=<c>,ou=org,<base>`, `ou=<c>,ou=people,<base>`, `cn=<c>-admin,ou=groups,<base>`, `cn=<c>-resident,ou=groups,<base>`, `pbx.bindDn`, `ejabberd.bindDn`, `xmppBridge.dn` | each returns exactly that DN |
| LDAP (shape) | the three returned DNs | `pbx.bindDn == cn=<c>,ou=pbx,ou=clients,<base>`, `ejabberd.bindDn == cn=<c>-ejabberd,ou=clients,<base>`, `xmppBridge.dn == uid=<c>.xmpp-bridge,ou=<c>,ou=people,<base>` (uncovered in E2E: U1) |
| UI | `/directory/orgs`, `/configuration/ldap-clients` | `<c>` and `<c>-ejabberd` are visible |
| Authentik | Admin API `GET /providers/oauth2/?client_id=<id>` and `GET /core/applications/<id>/` for `<id>` in `<c>`, `<c>-directory` | provider listed, application answers 200 |
| Authentik | `GET /sources/ldap/azblink-ldap/` | `group_object_filter` contains `(cn=<c>-*)` |
| SIP | building's token: `POST <AUTHENTIK_URL>/application/o/token/` form `grant_type=client_credentials`, `client_id=<c>-directory`, `client_secret=directoryClient.clientSecret`, `scope=openid profile` | 200 with `access_token` |
| SIP | with that token: `POST /api/users/create {uid: <c>r1, displayName: "Journey Resident", orgDn: ou=<c>,ou=org,<base>, password: Journey-Pass-2026!}`, retried while 401 for up to 20 s (another worker trusts a new principal within 10 s, ARD-022 §2) | 201 |
| SIP | `PUT /api/users/<c>r1/sip {password: Journey-Sip-2026}` | 200; `sip.rangeStart <= extension <= sip.rangeEnd` |
| SIP | `POST /api/groups/<c>-resident/members {uid: <c>r1}` | 200 |
| SIP | point `pbx-sim` at the client (`res_ldap.conf` `user = pbx.bindDn`, `pass = pbx.secret`; `extconfig.conf` base `ou=<c>,ou=people,<base>`; `asterisk -rx "core reload"`), then `relayctl.py sip-register <ext> Journey-Sip-2026 --pbx=<pbx-sim relay IP>` | 200 within 60 s; with `Wrong-Sip-Secret-1`, 401 |
| XMPP | point `xmpp-sim` at the client (`ldap_rootdn = ejabberd.bindDn`, `ldap_password = ejabberd.secret`, `ldap_base = ou=<c>,ou=people,<base>`; `ejabberdctl reload_config`), then `relayctl.py xmpp-login <uid>@xmpp.relay.test <password> --server=<xmpp-sim relay IP>` | bridge (`xmppBridge.uid`, `xmppBridge.password`) `ok: true` within 90 s; `<c>r1` with `Journey-Pass-2026!` `ok: true`; with `Wrong-Pass-1!` `ok: false` |
| UI | `/directory/users/<c>r1` | heading `Journey Resident` and the text `<c>-resident` are visible |
| Relay | `relay` in the A4 response | `null` (no `relayIp` sent); see A7 |

### A6. A repeat is a no-op, not an error

Tool call `onboard_client` with the fixture arguments again.

Expected: success; nothing is created and no secret is returned.
Assert: `isError` falsy; `created == []`; all five secrets `null`; `sip` equal to A4's.

Agent rule: a repeat answers success with `null` secrets. The agent reports "already onboarded;
the secrets were issued by the first call" and never treats `null` as a failure or retries to get them.

### A7. The relay address

1. Tool call `onboard_client` with the fixture arguments and `relayIp: "127.0.0.1"`.
   Expected: a tool error from the server's own check; the API is not called.
   Assert: `isError === true`.
2. Tool call `onboard_client` with the fixture arguments and
   `relayIp: <relay-sim relay-path IP>`.
   Expected: success, `created == []`.
   Assert: `relay.ip` equals the address; `relay.operatorStep` names `authentik_onboarded_clients`
   and `authentik_relay_ips`.
3. Tool call `onboard_client` with the fixture arguments (no `relayIp`).
   Assert: `relay.ip` is still that address.
4. (#411) Tool call `onboard_client` with a second fresh client id `<c2>` (`e2eai` + 6 hex), the
   fixture's other arguments, and the same `relayIp`.
   Expected: tool error `HTTP 409: relay IP <ip> is already used by client '<c>'; each relay box
   needs its own`, before any change.
   Assert: `isError === true`; the text names `<c>`; `ldapDns(ou=<c2>,ou=org,<base>)` is empty.
   Agent rule: stop and ask the operator for that building's own relay address. Never retry.
5. (#411, API only) `POST /api/clients/onboard` with the fixture arguments plus `"relayIp": null`,
   operator's token. The tool cannot send this (it drops `null`).
   Expected: 200, `relay == {ip: null, operatorStep: …}`.
   Assert: `relay.operatorStep` names `authentik_onboarded_clients` and `authentik_relay_ips`. A
   repeat that omits `relayIp` (tool call, fixture arguments) returns `relay: null`.
   Agent rule: the agent cannot clear a relay IP. Asked to, it hands the operator this API call.

Agent rule: `operatorStep` is a converge, not an API call. The agent hands it to the operator
verbatim and does not claim the relay works or stopped working: `X-Forwarded-For` trust is
deploy-time (ARD-021). Until that converge, Authentik does not trust a new relay and still trusts
a cleared one.

### A8. Failure cases the agent must handle

Every API error reaches the agent as a tool error whose text starts `HTTP <status>: <API detail>`.
Run them after A4–A7 in this order: F1–F7, then F10, then F8 and F9 last, inside one stop of
Authentik.

| # | Trigger (tool call unless noted) | Expected text contains | Agent must | Changes state |
|---|---|---|---|---|
| F1 | 409 nested id: fixture arguments, `clientId: "<c>-x"`, `adminToken: <token>` | `HTTP 409`, `nests with` | stop; report; ask the operator for another id. Never retry | no (audit `refused` row) |
| F2 | 409 changed block on a repeat: fixture arguments, `sipBlockSize: 20` | `HTTP 409`, `SIP range is already` | stop; a range change goes through the profile, not this call | no |
| F3 | 409 Authentik takeover: `clientId: "azblink"` (its `azblink-directory` is the admin UI's provider) | `HTTP 409`, `already exist in Authentik` | stop; choose another id | no |
| F4 | 409 env client: `clientId: "safenest-dev"` | `HTTP 409`, `AUTHENTIK_FIRST_PARTY_CLIENTS` | stop; the seed manages it | no |
| F5 | 422 only the API can judge: fresh id, `sipBlockSize: 100000` | `HTTP 422`, `sipBlockSize is at most 1000` | fix the argument from the message; retry once | no |
| F6 | 403 not an admin: fixture arguments, `adminToken: <access_token of <c>-directory from A5>` | `HTTP 403`, `Insufficient permissions` (a scoped service client is refused by the auth dependency, `auth.py`, before the admin check; a signed-in person outside the admin group gets `Admin group required` instead) | stop; ask for an `IT-Admins` member's token. Never retry with the same token | no |
| F7 | 401 stale token: fixture arguments, `adminToken: "not-a-live-admin-token"` | `HTTP 401`, `Supply a fresh one` | ask the operator for a fresh token; repeat the same call with it as `adminToken` | no |
| F8 | 502 upstream: `docker stop` the project's `authentik-server`, then the fixture arguments with `adminToken: "dev-test-token"` (a repeat, so the pre-check that would answer 503 is skipped) | `HTTP 502`, `step 'authentik'`, `repeat the call to resume` | wait for the upstream; repeat the same call. After `docker start` and Authentik answering again: success, `created == []` | steps before `authentik` stay done |
| F9 | 503 upstream before any change: a fresh id, `adminToken: "dev-test-token"`, with `authentik-server` still stopped (between F8's stop and start) | `HTTP 503`, `Authentik admin API is temporarily unavailable` | retry later; nothing was changed | no |
| F10 | 429: empty the limiter, make F1's call ten times (each a counted 409), then an eleventh | `HTTP 429` on the eleventh | wait 60 s, then repeat | no |

F8 and F9 use the dev bypass token (`DEV_AUTH_TOKEN`, dev and CI stacks only, never production)
because the API verifies a real admin token against Authentik's JWKS, cached 300 s: with Authentik
stopped and the cache expired, the call would fail at authentication, not at the step under test.

**Secrets after a 502.** A 502 body carries no secrets. If a *new* client's call stops at step
`authentik`, the PBX, ejabberd and bridge secrets that call created are lost, and the resume returns
them as `null` (it creates nothing that exists). If it stops between the two Authentik providers, the
first provider's secret is lost too (ARD-022 amendment 1, item 2). The agent must:

1. Compare the resume's response with what it has received: a `null` secret it never received is
   lost, not "already issued".
2. Tell the operator which ones, and how they are rotated:
   `POST /api/settings/ldap/clients/provisioned/<c>/rotate` (PBX) and `…/<c>-ejabberd/rotate`
   (`system_configuration`), `POST /api/users/<c>.xmpp-bridge/reset_password {newPassword}`
   (`user_management`), an Authentik provider's secret by an Authentik superuser
   (`docs/runbooks/client-lifecycle.md`).

The MCP server has no tool for these, so recovery is the operator's.

### A9. Cleanup

1. Close the MCP server (kill the child process).
2. If F8 or F9 ran: `docker start` the project's `authentik-server` and wait until
   `<AUTHENTIK_URL>/application/o/azblink-directory/.well-known/openid-configuration` answers 200.
3. Put the simulators back (`restoreSims`): `cp /sim/asterisk/*.conf /etc/asterisk/` and
   `core reload` in `pbx-sim`; `/sim/ejabberd.yml` back over the live config and
   `ejabberdctl reload_config` in `xmpp-sim`. `tests/test_relay_path.py` expects the shipped configs.
4. Tear the stack down: `docker compose … down -v --rmi local --remove-orphans` with the same
   files and project.

There is no deregistration call (ARD-022: deregistration stays manual). On any stack that is not
thrown away, remove a client the way `tests/test_client_onboard.py` `_purge` does: the Authentik
applications, providers, the two expression policies and `<c>-*` groups, the `(cn=<c>-*)` filter
term, the client's users in Authentik and LDAP, its LDAP groups, clients, org and people OUs, then
the rows in `first_party_clients`, `ldap_provisioned_clients`, `config_templates` (`name = <c>`) and
`org_profiles`.

## Coverage map

Tests named here: **J1** is journey test 1 (`admin adds a client that lands in LDAP, Authentik, SIP
and XMPP`, merged #406), **J2** is journey test 2 (`an AI agent adds a client through the MCP server,
and it lands the same way`, #410), **B** is `tests/test_client_onboard.py` (backend, API
direct), **M** is `tools/directory-mcp/tests/test_server.py` (#410, fake API).

| Step | Covered by |
|---|---|
| H1 sign-in, token | J1 and J2 step `the admin signs in through Authentik` |
| H2 admin onboard | J1 `the admin adds the client on the Add client screen`, `adding it again shows no secrets` |
| A1 start server | J2 (`startMcpServer`); M (one real stdio run) |
| A2 tool list | J2 `the agent finds the onboard_client tool` |
| A3 local refusal | J2 `invalid arguments never reach the API`; M (no request reaches the fake API; parity with `ClientOnboardReq`) |
| A4 onboard | J2 `the agent adds the client` (success only); five secrets non-empty and none in stderr: J2 `the MCP server logged none of the returned secrets`. The response fields: see U2 |
| A5 LDAP, Authentik, SIP, XMPP, UI | J1 and J2 (`landsEverywhere`); B for the deeper shapes |
| A6 repeat | B `test_repeat_is_a_no_op` (API); J1 `adding it again shows no secrets` (screen) |
| A7 steps 1–3 relay | B `test_relay_ip_is_stored_and_names_the_operator_step` (API); M `test_relay_ip_is_sent_when_given`, `test_invalid_arguments_never_reach_the_api` and `test_validates_like_the_api` for `relayIp` (fake API); for the screen only, the unit tests `onboard.test.ts` (refused and accepted relay IPs, left out when empty) and `onboard-result.test.ts` (the operator step shown) |
| A7 step 4 shared relay 409 | B `test_relay_ip_another_client_uses_is_refused` (#411) |
| A7 step 5 clear | B `test_clearing_relay_ip_is_audited_apart_from_omitting_it` (#411) |
| F1 nested 409 | J2 `the API's refusals come back as tool errors`; B `test_refusals` |
| F2 changed block 409 | B `test_repeat_is_a_no_op` |
| F3 Authentik takeover 409 | B `test_an_existing_authentik_provider_is_never_taken_over` |
| F4 env client 409 | B `test_env_client_is_never_onboarded` |
| F5 API 422 | B `test_refusals`; M `test_api_errors_are_tool_errors_with_their_message` |
| F6 403 | B `test_refusals` (scoped principal, status only); M `test_api_errors_are_tool_errors_with_their_message` (a faked 403) |
| F7 401 | J2 `the API's refusals come back as tool errors`; M `test_expired_token_says_to_supply_a_fresh_one` |
| F8, F9 | M `test_api_errors_are_tool_errors_with_their_message` (a faked 502 and 503 only); see U7 |
| F10 429 | B `test_onboard_is_rate_limited`; M `test_api_errors_are_tool_errors_with_their_message` (a faked 429) |
| Audit rows | B `test_every_onboard_and_change_is_audited` |

### Steps no test covers yet

| # | Gap | Where it would go |
|---|---|---|
| U1 | A5 DN shapes in the E2E. B checks `pbx.bindDn` and `xmppBridge.dn` exactly and `created` ⊇ {`org`, `pbx`, `ejabberd`, `xmpp_bridge`, `ldap_source_group_filter`}. No test checks the shape of `ejabberd.bindDn` or the `group:…`, `login_client` and `service_client` entries of `created` | J1/J2 `it lands in LDAP`; B |
| U2 | A4 response fields. No test checks `loginClient.issuerPath` or `orgDn`. Only B checks `groups`, `sip` size and context, and that the Authentik secrets match Authentik's; J2 checks none of them, nor `clientId`, `directoryClient.clientId` or `relay: null` | J2 `the agent adds the client`; B for `issuerPath`, `orgDn` |
| U3 | A6 repeat through the MCP tool (`null` secrets as success) | J2 |
| U4 | A7 relay through the MCP tool on the real stack, steps 1–4 (B covers the API, M a fake API) | J2 |
| U5 | F2–F5 and F10 through the MCP tool on the real stack (B covers the API, M a fake API) | J2 `the API's refusals come back as tool errors` |
| U6 | F6 on the real stack through the MCP tool, and its message anywhere (B asserts the status only); a non-admin *person's* token anywhere (B uses the scoped principal only) | J2; B |
| U7 | F8 and F9 on the real stack: no test makes the API answer 502 at a step or 503 with Authentik down, nor resumes after a 502 (M fakes both answers) | J2 last step, or B with Authentik stopped |
| U8 | Secrets lost on a new client's 502 at step `authentik`: no test, no fault hook to stop between steps, no MCP recovery tool | needs a decision (below) |
| U9 | A member of `<c>-resident` signing in through the login client `<c>` in the E2E (B `test_member_signs_in_through_the_login_client` only) | J1/J2 |
| U10 | The `onboard_client` audit rows of the agent's calls (`started`, `finished`, `refused`) seen from the E2E | J2, via `/api/audit/events` |
| U11 | Cleanup of an onboarded client: there is no deregistration API, so nothing to test | out of scope (ARD-022) |
| U12 | A7 step 5 through the agent: the MCP tool drops `relayIp: null`, so an agent cannot clear a relay IP (nor can the Add client screen, which leaves an empty field out) | needs a decision (below) |

Open decisions, each a behaviour change that this document does not assert:

- **U8:** either the 502 response returns the secrets its call created before it stopped, or the MCP
  server gains rotate tools. Either needs an ARD-022 amendment.
- **U12:** either the MCP tool forwards an explicit `relayIp: null`, or a clear stays an operator's
  API call. Changing the tool is a change to `tools/directory-mcp/server.py`; no amendment, since the API already accepts the clear.
