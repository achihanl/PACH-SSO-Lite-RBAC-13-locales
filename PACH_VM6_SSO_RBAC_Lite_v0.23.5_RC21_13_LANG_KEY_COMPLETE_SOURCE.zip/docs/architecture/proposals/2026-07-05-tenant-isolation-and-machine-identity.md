---
status: proposal
authored_at: 2026-07-05
author: security-audit (Fable arbiter)
spec_sections_affected: ["02-component-architecture", "04-security-authz", "05-provisioning"]
related_findings: ["C1", "M1", "H3", "H4"]
---

# Proposal: Tenant Isolation, Machine Identity, and Auth-Availability Hardening

Design contract for the P0/P1 items that change the **security model** (not just code)
and therefore require architectural sign-off before implementation. Produced by the
production-readiness audit (`docs/../plans/` audit report). The mechanical/localized
hardening (M2 issuer-required, L5 require-exp, H2/H6 prod-config fail-fast, H5
trusted-proxy XFF, M5 `escape_rdn`, M6 error hygiene, M4 random token key, L1 delete
breakglass) has already landed with unit coverage; this document governs the parts
that need product decisions and the live stack to validate.

## Update 2026-07-05 — D1 resolved (Model A); first drafts landed

**D1 decision: Model A (one deployment per tenant).** C1 is therefore an
*authorization*-tightening problem, not a shared-instance isolation build. Under
Model A the org-profile *mutations* are already permission-gated
(`require_permission("device_provisioning")`), so the critical cross-customer
IDOR dissolves; the residual is over-exposed **reads** available to any
authenticated user — including self-service users who authenticate only for
`/api/me*`.

Landed as **UNVERIFIED DRAFTS** (need live-stack + admin-UI validation before merge):

- **H4** — removed the per-username auto-lock driven by the unverified-token
  username in `_claims_from_auth_header`; kept IP-based blocking + audit trail.
  Account lock is now admin-action-only and still enforced post-verification.
  *Must be re-validated against `tests/test_account_lock.py`, which asserts the
  old auto-lock behavior and will need updating.*
- **C1 (Model A), first tranche** — new `require_directory_read` dependency
  (any management permission or admin group) applied to the most sensitive
  arbitrary-target reads: `GET /api/users/{uid}/devices`, `/stats`,
  `GET /api/orgprofiles`, `GET /api/orgprofiles/{id}`. `/api/me*` untouched.

**Still open (product UX decision before converting):** the aggregate directory
*browse* endpoints — `GET /api/users`, `/api/users/{uid}`, `/api/users/search`,
`/api/groups*`, `/api/org/tree`, `/api/orgs/*` — remain on `require_user`. Gating
these turns off "any authenticated employee can browse the company directory."
If that address-book behavior is intended, they stay; if not, extend
`require_directory_read` to them during stack validation. **Confirm with the
product owner.** M1 (machine identity) is unstarted — it needs the Authentik
provider seed and the live stack.

## Context

The platform is marketed (goal statement) as a **multi-tenant** unified SSO/OAuth control
plane fronting the Ved/Ped VMs (XMPP/SIP LDAP clients), with **API-client integration** and
**bi-directional AI/agent** support. Two of those pillars are not real in the code today:

1. **No tenant isolation boundary (C1, CRITICAL).** Identity is raw OIDC claims with no
   tenant binding (`main.py` `require_user`). Every directory read is global; org-profile
   reads/writes are IDOR-able by predictable id (`orgdb.get_profile` keyed on `id` only);
   the `tenant` filter on `/api/orgprofiles` is caller-supplied; user-lifecycle writes gate
   only on a global permission with no target-in-tenant check. Any tenant's user can read
   and mutate every other tenant's data.
2. **No machine identity (M1).** The HTTP API accepts only a human Authentik JWT or the dev
   bypass. There is no scoped, revocable, per-agent credential — so "agent support" has no
   secure front door.
3. **Auth-availability DoS (H4).** Account-lock counters key on a username taken from an
   *unverified* JWT, letting an attacker lock arbitrary victims.

A prerequisite product decision blocks C1 and must be settled first (see Open Decisions).

## Open Decisions (must be resolved before implementation)

**D1 — What is a "tenant" in this deployment?** The config carries a single `LDAP_TENANT`
and single `LDAP_BASE_DN`; the DB `org_profiles.tenant` column is the only multi-tenant
artifact. Two coherent models:

- **(A) One deployment per tenant** (single-tenant instances). Then C1 reduces to an
  *authorization* problem: a normal user must not read the whole directory or other orgs;
  `tenant` scoping is intra-directory (org subtree) rather than cross-customer. Lower blast
  radius; the `tenant` column becomes org-grouping, not an isolation boundary.
- **(B) Many tenants in one LDAP/DB** (true multi-tenant SaaS). Then C1 requires a tenant
  claim in the token, per-tenant LDAP subtrees (`ou=<tenant>` under base DN), and a tenant
  predicate on every `orgdb` query. Highest correctness bar.

**Fable's recommendation:** default to **(A)** unless the product explicitly sells shared-
instance multi-tenancy, because (B) multiplies the LDAP schema, provisioning, and Authentik
seeding work and is easy to get subtly wrong. Ship (A)'s authorization fixes now; treat (B)
as its own ARD if/when shared instances are a real requirement. **This decision is the
gate — it should be confirmed with the product owner before C1 code is written.**

## Design contract — C1 (tenant/authorization enforcement)

Regardless of A/B, the enforcement mechanics are the same shape:

1. **Derive a scope from the verified token, once.** Add a `Principal` object built in the
   auth dependency: `{uid, groups, is_admin, tenant, scope_dns}` where `tenant`/`scope_dns`
   come from an Authentik group→tenant mapping (model B) or the caller's own org subtree
   (model A). `require_user` returns the `Principal`, not raw claims. Single chokepoint.
2. **Thread the scope into data access, not into each handler.** Every `orgdb` read/write
   that today takes a bare `id`/`tenant`/`uid`/`org_dn` gains a `principal`/`scope` argument
   and enforces it in the query `WHERE` (DB) or the search base + post-filter (LDAP). Make
   the *unsafe* signatures private (`_get_profile_unscoped`) so a scoped wrapper is the only
   public path — a forgotten scope becomes a type/callsite error, not a silent leak.
3. **Ownership checks on every `{id}`/`{uid}` route.** `get_profile`, `update_org_profile`,
   `delete_profile`, all `/api/users/{uid}/*` lifecycle routes, `/api/org/users?orgDn=`,
   and the provisioned-client registry (add a `tenant` column, migration) must assert the
   target is within `principal.scope` before acting; else 404 (not 403 — don't confirm
   existence cross-tenant).
4. **Admin is scoped too (model B).** `OIDC_ADMIN_GROUP` today is a global superuser. Under
   (B) it must be per-tenant or split into `global_admin` vs `tenant_admin`.

Non-negotiables: fail-closed (missing/unmappable tenant → deny), and no data-access helper
may be reachable without a scope on the public path.

## Design contract — M1 (machine identity for API-client / agent integration)

Introduce a first-class **service principal** distinct from human OIDC users:

- **Issuance:** a dedicated Authentik OAuth2 provider per tenant using the
  `client_credentials` grant (NOT the shared human app provider — the shared one is slated
  for removal, `TODOS.md`). Each agent/service gets its own `client_id`/`client_secret`,
  bound to a tenant and a scope set.
- **Verification:** `verify_bearer_token` already validates aud/iss/sig; extend the
  `Principal` builder to recognize a service token (no `preferred_username`; carries a
  `client_id` and scoped `groups`/roles) and map it to a *machine* RBAC role — never the
  human `IT-Admins` fallback.
- **Authorization:** reuse `require_permission` with a machine-scoped permission set. Agent
  actions (inbound/outbound) are explicit permissions (`agent_read`, `agent_provision`,
  `agent_message`), not the human admin bundle.
- **Revocation:** per-client secret rotation + Authentik token revocation
  (`DELETE /api/v3/oauth2/access_tokens/{id}/`, per `.claude/rules/authentik.md`).

Do **not** advertise agent support until this exists; the only current M2M paths (shared-
provider `client_credentials`, `ou=clients` LDAP binds, dev token) are not fit for it.

## Design contract — H4 (verified-subject lockout)

The account-lock feature must never trust an unverified token. In this architecture a
"failed login" does not occur at this API (Authentik does password auth); the API only sees
already-issued tokens, so a signature-invalid token is not evidence of a password-guessing
attempt against the named user. Therefore:

- **Remove per-username auto-lock driven by invalid-token contents.** Keep IP-based blocking
  (now XFF-spoof-resistant via H5) as the abuse control for bad-token floods.
- **Account lock stays an explicit admin action** (the `account_locks` endpoints already
  exist) and/or is driven by Authentik's own brute-force flow.
- If a per-user signal is still wanted, count only failures where the token **signature is
  valid** but authorization fails (a real, attributable subject) — never an unverified name.

This is a behavior change to DS-1 and **must be validated against `tests/test_account_lock.py`
on the live Docker stack** (unavailable in the audit environment), which is why it is
specified here rather than shipped blind.

## Implementation routing (per approved plan)

| Item | Design/arbitration | Implementation | Validation |
|------|--------------------|----------------|-----------|
| D1 decision | **Fable + product owner** | — | — |
| C1 | Fable (this contract) | Sonnet, per-route | Live stack + new cross-tenant tests beside `test_rbac.py` |
| M1 | Fable (this contract) | Sonnet (provider seed + verify) | Live stack + Authentik seed |
| H4 | Fable (this contract) | Sonnet | Live stack: `test_account_lock.py` |

## Verification (when the stack is available)

- **C1:** two non-admin principals in different tenants; assert cross-tenant
  `GET/PATCH/DELETE /api/orgprofiles/{id}`, `GET /api/orgprofiles` (no `tenant`), `GET
  /api/users`, `GET /api/org/users?orgDn=` all return 404/empty.
- **M1:** a service token reaches only its scoped permissions and never the `IT-Admins`
  fallback; revocation takes effect.
- **H4:** forged invalid tokens naming a victim no longer lock that victim.
- Re-run `just test-security` and the full suite after each change.
