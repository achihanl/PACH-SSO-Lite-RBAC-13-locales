<!--
Proposal: Data & Content i18n (Phase 2)
- Status: DRAFT proposal (pre-ARD) — graduates to ARD-010 on acceptance
- Author: session 2026-07-07, branch feat/i18n-multilanguage (PR #203)
- Supersedes/extends: PR #203 UI-chrome i18n (react-i18next, en/zh-Hant/zh-Hans)
- Build: DEFERRED — this document commits a target architecture, not code
-->

# Proposal: Data & Content Internationalization (Phase 2)

**Status:** Draft proposal (pre-ARD). Graduates to **ARD-010** on acceptance.
**Date:** 2026-07-07 · **Branch:** `feat/i18n-multilanguage` (PR #203)

## Context

PR #203 internationalized the admin UI **chrome** — every user-visible string
that originates in the frontend source — via `react-i18next` across 12
namespaces (`en` + `zh-Hant` + `zh-Hans`), guarded by an `i18next/no-literal-string`
(`jsx-text-only`) ESLint rule.

Phase 2 is the harder half: the **data itself**. A code-audit of the running
system splits the remaining strings into two categories with fundamentally
different treatments.

**Category A — user-entered directory data** (authored once, in the org's
working language):
- LDAP: org unit names (`ou`), group `cn` + `description`, user identity
  attrs (`displayName`, `sn`, `givenName`, `title`).
- PostgreSQL: `config_templates.name` / `.description` (admin-authored profiles),
  `profile_services` config.

**Category B — system-generated strings emitted as data** (produced by the
backend, rendered as if they were data):
- `orgdb.py` builds audit/compliance `description` fields as **English literals
  in SQL/Python** — e.g. `'All sessions revoked, LDAP disabled'`,
  `'Reason: ' || af.failure_reason`, `'Token expired without being consumed'`,
  `f"User has {r['cnt']} active tokens simultaneously"`,
  `f"Device consumed tokens for {r['user_count']} different users"`.
- Frontend `audit-event-config.ts` maps event types → English labels/icons.

The insight that scopes the whole effort: **Category B is not "data to translate"
— it is presentation that leaked into the data layer.** The fix is to stop
server-rendering English, not to store translations of it.

## Core principles

1. **Presentation leaves the data layer.** The server emits `{code, params}`;
   human text is a client concern resolved through the existing i18n bundles.
2. **Canonical-as-entered is the fallback.** User data is stored once in its
   authored language. Localized values are *optional overrides* layered on top —
   never a hard requirement, never a blank field.
3. **Identity ≠ copy.** Personal names, usernames, org unit names, DNs, and
   secrets are identity. They are never translated, machine or otherwise —
   mistranslating them is actively harmful.

## Target architecture — three independent, ordered layers

Each layer is independently valuable and independently shippable. Ship L1 first;
L2 and L3 are opt-in and may never be built if L1 proves sufficient.

### Layer 1 — System strings → codes + params (Category B)

- Backend stops writing English into `description`. Audit/compliance rows carry
  an `event_code` (stable dotted key, e.g. `audit.sessionsRevoked`,
  `compliance.rapidConsumption`) plus a `params` JSON blob (`{count, userCount, …}`).
- Frontend resolves `event_code` → existing `audit` / `provisioning` i18n
  namespaces and interpolates `params`. `audit-event-config.ts` becomes the
  `code → { key, icon, severity }` map (single source, already the natural home).
- **Historical rows** (pre-migration, English `description`, no `event_code`)
  keep their literal string as a display fallback. No retro-translation, no
  back-fill — the resolver renders `event_code` when present, else the stored
  `description`.
- Storage: add nullable `event_code TEXT` + `params JSONB` to the audit-source
  tables (or the unified audit view's producers); no data migration of history.
- **Reuses existing i18n infra. No translation storage. Highest value / lowest cost.**

### Layer 2 — `content_translations` override table (Category A, opt-in)

- One side table, not per-column sprawl:
  `content_translations(entity_type, entity_id, field, locale, value, updated_by, updated_at)`,
  unique on `(entity_type, entity_id, field, locale)`.
- Read path: canonical value from the entity's own row; if an override exists for
  the active locale, it wins. Missing override → canonical (never blank).
- **Curated field set only:** profile `name` / `description`, group `description`.
  Deliberately **excludes** personal names, usernames, `ou`, DNs (see boundaries).
- Admin UX: an unobtrusive "＋ translation" affordance per eligible field, hidden
  behind the current locale. Zero burden unless an admin chooses to localize.
- **True per-record localization without schema explosion or forcing admins to
  translate everything.**

### Layer 3 — Machine translation as human-in-the-loop assist (optional, last)

- MT **suggests** Layer-2 override values; an admin reviews/edits before save.
- Explicitly **not** live read-time translation. This sidesteps the three MT
  failure modes for a directory: privacy (no live egress of directory data to a
  third party), latency/cost on every read, and silent mistranslation of
  proper nouns.
- MT feeds the override store; the store remains the source of truth.

## Scope boundaries

| Data | Category | Treatment |
|------|----------|-----------|
| Audit / compliance / status descriptions | B | **Layer 1** — codes+params → client i18n |
| Frontend audit event labels | B | **Layer 1** — `audit-event-config.ts` = code→key map |
| Seed/default profile description | B | **Layer 1** — system string, emit code |
| Profile `name` / `description` (admin-authored) | A | **Layer 2** — optional override |
| Group `description` | A | **Layer 2** — optional override |
| User `displayName` / `sn` / `givenName` / `title` | A | **Never** — identity |
| Username, `uid`, DNs, org `ou` | A | **Never** — identity / structural |
| `AstAuthPassword`, secrets, tokens | — | **Never** |

## Decisions already made (flag if wrong)

- **No historical back-fill.** Pre-Layer-1 audit rows keep their English
  `description` as fallback; only new rows carry `event_code`/`params`.
- **This is a proposal, not an ARD.** The build is deferred, so no accepted
  decision yet. It graduates to **ARD-010** when a layer is scheduled for build.
- **Layers are ordered and optional.** L1 is the only near-certain build; L2/L3
  are gated on real demand.

## Open decisions (product input before building)

- **O1 — Curated Layer-2 field set.** Is `{profile.name, profile.description,
  group.description}` the right minimal set, or is any of it also out of scope?
- **O2 — Is Layer 2 ever wanted?** For many directory deployments, canonical
  as-entered user content is acceptable and L1 alone satisfies "multi-language."
- **O3 — Locale source for Layer 1 rendering.** Reuse the viewer's UI locale
  (recommended) vs a per-record authored locale.

## Phasing & effort

| Layer | Effort | Surfaces touched | Gate artifact |
|-------|--------|------------------|---------------|
| L1 | Medium | `orgdb.py` description producers, audit schema, `audit-event-config.ts`, audit/provisioning namespaces | ARD-010 + migration (add cols) |
| L2 | Larger | new table + resolver, entity read paths, admin UX per field | ARD amendment + migration |
| L3 | Add-on | MT client, suggest-in-admin-UI | ARD amendment |

Each layer is its own PR with its own spec → plan → implement cycle, per the
repo SOP. This proposal is the shared design they descend from.

## Verification approach (per layer)

- **L1:** trigger each audit/compliance event; assert the API returns
  `event_code`+`params` (not English) and the UI renders the correct localized
  string in all three locales; assert a legacy row (no code) still renders its
  fallback.
- **L2:** create a profile, add a `zh-Hant` override for `description`; assert the
  override shows under `zh-Hant` and canonical shows under `en`; delete override →
  canonical returns.
- **L3:** MT suggestion populates the L2 editor but does not persist until admin save.

## Alternatives considered

- **Per-locale columns** (`description_en`, `description_zh_hant`, …) — rejected:
  schema sprawl, N columns per translatable field per locale, painful to add a
  locale, and still forces the Category-B/Category-A conflation. The
  `content_translations` side table is the normalized equivalent.
- **Live read-time MT** — rejected: privacy (directory data egress), per-read
  latency/cost, and mistranslated proper nouns with no human gate. Retained only
  as an opt-in *suggestion* source feeding Layer 2.
- **Do nothing (L1 only, forever)** — a legitimate outcome, not an alternative to
  reject. If O2 resolves "no," L1 is the whole of Phase 2.
