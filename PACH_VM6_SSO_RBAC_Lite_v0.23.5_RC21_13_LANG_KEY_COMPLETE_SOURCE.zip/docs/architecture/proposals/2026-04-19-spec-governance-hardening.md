<!-- proposal-meta: { version: "0.1.0", status: "proposed", date: "2026-04-19" } -->
# Spec Governance Hardening — Design Proposal

| Field | Value |
|-------|-------|
| **Status** | `proposed` — not yet accepted |
| **Date** | 2026-04-19 |
| **Target ARD on acceptance** | ARD-005 |
| **Amends** | `docs/architecture/SOP.md` (amended, not replaced) |
| **Scope** | Governance of `docs/architecture/*` + deprecation of `docs/prd/*`, `specs/v2.0/*`, `docs/plans/*` |

## 1. Problem Statement

The AZBlink Directory spec architecture drifted. ARD-001 through ARD-004 were authored between Mar 2 and Mar 17, 2026. Between Mar 17 and Apr 19, 2026 — 33 days — **12+ architectural PRs shipped with zero ARDs and zero spec-section updates**:

| PR | Date | Decision / change — no record |
|----|------|-------------------------------|
| #51 / #58 | Mar 10 | WebSocket + SSE real-time activity bus |
| #60 / #61 | Mar 11 | Sealed-box credential delivery (new crypto primitive) |
| #76 / #77 | Mar 13 | **QR subsystem removed** — reverses entire PRD surface |
| #85 | Mar 26 | QA / Playwright CI gate architecture |
| #88 / #89 / #91 | Apr 13–15 | Account-lock model + OIDC-infra carve-out + Redis same-token dedup |
| #93 | Apr 17 | `AsteriskAccount` schema primary key |
| #95 | Apr 18 | Dead-code pipeline + fast PR-gate split |
| #97 | Apr 18 | App-tile auto-start OIDC redirect flow |
| #98 | Apr 19 | Orphan filter + stats/list contract alignment |

`docs/architecture/README.md`'s `<!-- spec-meta: { last_updated: "2026-03-17" } -->` is 33 days stale.

`docs/prd/PHASE1_UC_CORE_QR_PRD.md` and `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md` describe a QR-centric provisioning flow deleted in PR #76 / #77. They specify a system that does not exist.

`specs/v2.0/Directory_Portal_Specification_v4.1.md` predates Authentik OIDC (ARD-002), single-LDAP (ARD-001), and profile-services (ARD-004). Triple stale.

### Why the existing SOP did not prevent drift

1. **No enforcement.** Rules existed; nothing blocked a merge that violated them.
2. **Heuristic trigger.** "When to create an ARD" was phrased as *"significant"*, *"lasting consequences"* — subjective, and under deadline pressure the subjective call is always *"this is small"*.
3. **Competing truth sources.** `README.md` listed PRDs and `specs/v2.0/` as authoritative "Related Documents", giving contributors three sources for any question.
4. **Manual CHANGELOG edits were conflict-prone.** The SOP required in-place CHANGELOG edits per PR; under concurrent development these merge-conflict, so they were silently skipped.
5. **Changelog was mistaken for a guard.** A changelog entry records what shipped — by then, drift already exists. The real guard must fire before merge, not at release.

## 2. Goals

- **Prevent drift at the PR gate.** No architectural change merges without a matching ARD reference or spec-section update.
- **Preserve ARD decision integrity.** Accepted ARDs are immutable except via append-only amendments.
- **Eliminate competing truth sources.** PRDs and `specs/v2.0/` archived. `docs/architecture/` is the single authoritative tree.
- **Make the policy executable.** CI + pre-commit + weekly cron audit. No rule depending on a contributor remembering.
- **Preserve velocity.** Hybrid workflow — two-PR only for decisions, single-PR for state updates. Emergency lane for hotfixes.
- **Dogfood.** On acceptance, ARD-005 is the first ARD written under the new rules and governs this document.

## 3. Non-Goals

- **Not replacing product CHANGELOG tooling.** `git-cliff` stays. One `CHANGELOG.md` at repo root. Architecture commits group by scope inside it; no second file.
- **Not introducing fragment-file tooling** (changie, towncrier, scriv). Commit trailers + git-cliff are sufficient for reporting; they are not the drift guard.
- **Not unifying product and architecture version tracks.** Product `v0.4.0` (package.json + git tag) and architecture `spec-meta.version` (`1.1.0`, in README.md only) remain independent.
- **Not retroactively writing ARDs for every historical decision.** Only load-bearing ones (§7.2).
- **Not introducing a formal proposal-review board.** The PR is the review.

## 4. Design Principles

1. **Git is source of truth; documents reflect it.** Commit trailers carry structured metadata; ARDs record decisions; spec sections record current state. Everything else is derivable.
2. **ARDs are decisions; spec sections are state.** Different lifecycles, different mutability rules, different workflow ceremonies.
3. **Drift prevention is a pre-merge check, not a release artifact.** The changelog is downstream reporting. The guard is the surface-path gate + ARD immutability check + consistency check.
4. **Policy is code.** `tools/arch_guard.py` is the single source of rules, called by both pre-commit and CI.
5. **Archive ≠ erase.** Old PRDs and specs stay in git history; they just move out of glob/grep paths so agents and humans stop treating them as current.

## 5. Three-Document Model

```text
docs/architecture/
├── README.md              — index + version badge + ARD table
├── SOP.md                 — governance rules (amended to reflect this doc)
├── CHANGELOG.md           — REMOVED (rolled into repo-root CHANGELOG, scope-grouped)
├── surfaces.yaml          — NEW: architectural-surface path list
├── spec/                  — state (mutable, versioned)
│   ├── 01-system-overview.md
│   ├── …
│   └── 08-integration-points.md
├── decisions/             — ARDs (append-only body, mutable metadata)
│   ├── _TEMPLATE.md
│   ├── ARD-001..004-*.md                           — existing
│   ├── ARD-005-spec-governance-hardening.md        — NEW on acceptance
│   ├── ARD-006-websocket-sse-activity-bus.md       — retro
│   ├── ARD-007-sealed-box-credential-delivery.md   — retro
│   ├── ARD-008-qr-subsystem-removal.md             — retro
│   └── ARD-009-account-lock-model.md               — retro
└── proposals/             — NEW: forward-facing pre-ARD designs
    └── 2026-04-19-spec-governance-hardening.md    — THIS DOC

docs/archive/              — NEW: historical, read-only
├── README.md              — manifest: what, why, when, superseded-by
├── CLAUDE.md              — "Historical only. Do not treat as current."
├── prd/                   — was docs/prd/
├── specs-v2.0/            — was specs/v2.0/
└── plans/                 — was docs/plans/
```

### 5.1 ARDs — Decisions

- **Append-only body.** Once `Status=accepted`, the Context / Decision / Alternatives / Consequences / References sections are frozen. Corrections or clarifications go in an `## Amendments` section at the bottom, each with a date and PR link.
- **Mutable metadata.** Header fields (`Status`, `Superseded by`, `PR`) can change. Status transitions tracked.
- **Monotonic numbering.** Never reused, even for deprecated ARDs.
- **Substantive change = new superseding ARD**, not an amendment.
- **Metadata format: YAML frontmatter — authoritative, no dual-write** (CEO review Issue 1.3; refined outside-voice Finding #12). The markdown-table metadata on ARD-001..004 is **replaced, not duplicated**, during Phase 0. A human-readable rendering of the frontmatter is auto-generated between `<!-- summary:begin --> <!-- summary:end -->` markers via pre-commit hook; no manual sync required.

`_TEMPLATE.md` gains:
- YAML frontmatter block at the top: `status`, `accepted_at`, `decision_effective_date`, `supersedes`, `superseded_by`, `pr`, `spec_sections_affected` (the dual timestamps preserve audit integrity for retro-ARDs per outside-voice Finding #9 — see §7.2)
- Auto-rendered summary block between `<!-- summary:begin/end -->` markers (regenerated by pre-commit from frontmatter)
- `## Amendments` section at the bottom (empty at creation)

### 5.2 Spec Sections — State

- **Freely editable.** Spec sections describe the system as it currently is.
- **Markers** (replacing the `[TARGET v2.0]` scheme):
  - `[AS-BUILT]` — currently shipped
  - `[PROPOSED: ARD-XXX]` — not yet shipped but authorized by a proposed or accepted ARD
  - Unauthorized `[PLANNED]` text is forbidden — either it is authorized (has an ARD link) or it should not be in the spec
- **Metadata:** each section carries `<!-- spec-meta: { section, version, last_updated } -->`; `last_updated` bumps on every content change.
- **Overall spec version** on `README.md` bumps per SemVer rules in `SOP.md`.

### 5.3 Archive — History

- Physical move, not deletion — git history preserved, paths changed.
- `docs/archive/README.md` is the manifest (what / why / when / superseded-by table).
- `docs/archive/CLAUDE.md` contains one line: *"Historical only. Do not treat as current. Do not update."* This nested CLAUDE.md is honored by agents that load the tree.
- `arch_guard.py` ignores `docs/archive/**` — zero gate pressure on historical content.

## 6. Workflow — Hybrid

### 6.1 Decision changes (new / superseding ARD) — Two-PR

1. **PR-1: ARD-only.** Author writes a new ARD file with `Status=proposed`, or updates an existing ARD's `Superseded by` / status. No code changes. Reviewed on decision merit.
2. On merge, status flips to `accepted` (by a second commit in the same PR, or by merge-time automation).
3. **PR-2: Implementation.** Code + spec-section edits + commit trailer `ARD: ARD-00N`. `arch_guard.py` verifies the ARD exists and is `accepted`.
4. Spec-section edits for affected sections ship in PR-2 (single-PR state rule, §6.2).

### 6.2 State updates (spec sections) — Single-PR

Code change and spec-section edit ship together. Commit message requires one of:

- `ARD: ARD-00N` — points at an accepted ARD whose `Spec sections affected` list includes the section(s) being edited, OR
- `Spec-Patch: NN[,MM,…]` — for non-decisional clarifications (renames, corrections, descriptive adds, diagram updates). Patch-level only.

`Spec-Patch` must not be used to assert new behavior. A new behavioral claim requires `ARD:`.

### 6.3 Emergency lane — Post-merge ARD

Security hotfixes and outage remediation may merge with trailer `ARD-POST: placeholder`. This:

- Creates a tracking issue titled *"ARD required for PR #NNN within 7 days"*, auto-labeled `arch-post-followup`.
- Bypasses the surface check but is logged.
- Blocks the next architecture version bump (§12) until resolved.

Use sparingly. Misuse will be visible in the `arch-post-followup` issue list.

## 7. Migration Plan

### 7.1 Archive (Phase 0)

Move, don't delete:

- `docs/prd/` → `docs/archive/prd/`
- `specs/v2.0/` → `docs/archive/specs-v2.0/`
- `docs/plans/` → `docs/archive/plans/`

Create:

- `docs/archive/README.md` (manifest table)
- `docs/archive/CLAUDE.md` (one-line rule)
- `docs/architecture/proposals/` (forward-facing pre-ARD dir; this doc resides here)

Update references:

- Root `CLAUDE.md` — remove PRD/v2.0 citations in the spec-driven-development section; replace with a pointer to `docs/architecture/`
- `docs/architecture/README.md` Related Documents table — update or remove old entries
- `grep -r` for `docs/prd/`, `specs/v2.0/`, `docs/plans/` across code, docstrings, tests, skills — update or remove

### 7.2 Retro-ARDs

Retro-ARDs describe decisions already shipped. They are single-PR (the ARD file on its own; no code follows because code is already merged), and created at `status: accepted` with two timestamps (outside-voice Finding #9):
- `accepted_at: 2026-04-26` — real date the retro-ARD file was merged
- `decision_effective_date: 2026-03-10` — date the original decision shipped to production

Preserves audit integrity without backdating process history. The two-PR rule of §6.1 applies only to *forward-looking* decisions.

Thin (~1-page) ARDs:

- **ARD-006 WebSocket/SSE activity bus** — refs PR #51, #58. New cross-process boundary.
- **ARD-007 Sealed-box credential delivery** — refs PR #60, #61. New crypto primitive.
- **ARD-008 QR subsystem removal** — refs PR #76, #77. Explicitly supersedes the QR-era PRDs (now in `docs/archive/prd/`).
- **ARD-009 Account-lock model** — refs PR #88, #89, #91. OIDC-infra carve-out, Redis same-token dedup, structured 403.

ARD-005 is *this* governance doc.

**Skipped (downgraded to spec patches, not decisions):**

- AsteriskAccount schema (PR #93) → §03 Data Architecture patch
- App-tile auto-start OIDC (PR #97) → §04 Authentication patch
- Orphan filter + stats alignment (PR #98) → §05 Provisioning + §07 Security patch
- Dead-code pipeline + PR-gate split (PR #95) → §06 Deployment patch (or §09 CI gates when created)
- Playwright QA CI (PR #85) → §06 Deployment patch

### 7.3 Spec-section sync

Patch `docs/architecture/spec/01..08-*.md` to match current reality:

- **§02 Component Architecture** — add WebSocket/SSE activity bus, sealed-box crypto module
- **§03 Data Architecture** — rename `provision_tokens → device_provisions`, add `AsteriskAccount` schema, remove QR tables, document dual-source dashboard stats
- **§04 Authentication** — add account-lock state, OIDC infra-failure carve-out, app-tile auto-start flow
- **§05 Provisioning** — remove QR flow; device-provisioning is token-only
- **§06 Deployment** — add Playwright QA container, dead-code pipeline split
- **§07 Security** — add account lock, Redis-backed same-token dedup
- **§08 Integration Points** — remove QR delivery endpoints

Bump `spec-meta.version` `1.1.0 → 2.0.0` (MAJOR — QR removal is structurally breaking relative to the prior spec).

### 7.4 Marker replacement

Find-and-replace `[TARGET v2.0]` across `spec/*.md` with:

- `[AS-BUILT]` — if now shipped
- `[PROPOSED: ARD-XXX]` — if authorized by an ARD but not yet shipped
- (Remove) — if no longer relevant

## 8. Enforcement

All logic in `tools/arch_guard.py`. One source of rules, called by both pre-commit (staged diff) and CI (PR diff).

### 8.1 `arch_guard.py` checks

Inputs: changed-files list, commit message(s).

1. **Surface-path coverage check** (CEO review Issue 4.1 B; upgraded to full-coverage per outside-voice Tension B). If changed paths intersect any glob in `docs/architecture/surfaces.yaml`, **every touched surface** must be covered by at least one commit trailer on the PR:
   - Trailer `ARD: ARD-NNN` covers a surface IFF referenced ARD exists, is `accepted` (or `proposed` for the PR-1 of §6.1), and its `spec_sections_affected` includes a section that maps to that surface, OR
   - Trailer `Spec-Patch: NN[,MM,…]` covers a surface IFF the listed section file exists, is edited in this PR, and maps to that surface, OR
   - Trailer `ARD-POST: placeholder` covers everything; allows merge (subject to rule 6 back-pressure); creates a followup issue.

   Trailers can **distribute coverage** — `ARD: ARD-007` covering `auth_plane` + `Spec-Patch: 03` covering `data_contracts` may coexist on the same PR. Each contributes its coverage set. **Every touched surface must be covered by the union of trailer coverage. Partial coverage fails** — this closes the "throwaway trailer on unrelated commit" gaming vector.

   **Trailer scanning scope:** the guard scans trailers across all commits in `base..HEAD` via `git interpret-trailers --parse`. Permissive across commits (ergonomics for multi-commit PRs), **strict across surfaces**. A separate `arch-guard-post-merge.yml` workflow re-runs the coverage check on the actual merge commit and creates an `arch-post-merge-drift` tracking issue if coverage was lost in the squash (rare but possible if the author rewrites the squash message).
2. **ARD immutability.** For any modified file under `decisions/`:
   - If incoming `status: accepted`: diff must be confined to (a) YAML frontmatter fields (`pr`, `superseded_by`, etc.), or (b) the auto-rendered `<!-- summary:begin/end -->` block, or (c) additions below the `## Amendments` heading. Content above Amendments (Context / Decision / Alternatives / Consequences / References) must be byte-identical.
3. **ARD ↔ spec consistency.** For any new or modified ARD:
   - `Spec sections affected` references only real files in `spec/`
   - `Supersedes` / `Superseded by` bidirectional with the referenced ARD
4. **Marker consistency.** For any spec section containing `[PROPOSED: ARD-XXX]`: ARD-XXX file exists.
5. **CLAUDE.md facts.** If the diff intersects CLAUDE.md's `## Architecture (Quick Reference)` anchor → same rule as surface-path check applies.
6. **ARD-POST back-pressure** (outside-voice Finding #6). Before evaluating rules 1-5, check for open `arch-post-followup` issues older than 7 days:
   - PRs touching any architectural surface → **fail with rule ID `ard-post-backlog`** ("Clear pending ARD-POST followups before new architectural changes").
   - PRs touching `spec-meta.version` or any version-bump path → fail regardless.
   - Unrelated PRs → allow (no back-pressure on non-architectural work).

   Gives real teeth to the emergency-lane promise.
7. **Archive immunity.** `docs/archive/**` is unconditionally exempt.

Failure messages cite the specific rule + the SOP.md section that defines it. No generic "validation failed" errors.

### 8.2 Pre-commit hook (`.pre-commit-config.yaml`)

```yaml
- repo: local
  hooks:
    - id: arch-guard
      name: architecture governance guard
      entry: python tools/arch_guard.py --staged
      language: python
      stages: [pre-commit]
      pass_filenames: false
      always_run: true
```

Runs on staged diff; fast-fail with actionable error.

### 8.3 CI workflow (`.github/workflows/arch-guard.yml`)

```yaml
name: arch-guard
on:
  pull_request:
    paths:
      - "src/**"
      - "migrations/**"
      - "deploy/**"
      - "docs/architecture/**"
      - "CLAUDE.md"
      - ".github/workflows/**"
      - ".pre-commit-config.yaml"
      - "Justfile"
jobs:
  guard:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - uses: actions/setup-python@v5
        with: { python-version: "3.11" }
      - run: |
          python tools/arch_guard.py \
            --base origin/${{ github.event.pull_request.base.ref }} \
            --head ${{ github.event.pull_request.head.sha }}
```

Required status check on `main`. Mirrors pre-commit; defeats `--no-verify`.

### 8.4 Weekly drift audit (`.github/workflows/arch-drift-audit.yml`)

```yaml
on:
  schedule:
    - cron: "0 6 * * 1"   # Monday 06:00 UTC
  workflow_dispatch:
jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: python tools/arch_drift_audit.py --report audit-report.md
      - if: failure()
        run: gh issue create --title "Arch drift detected $(date +%F)" --body-file audit-report.md --label arch-drift
        env:
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

`arch_drift_audit.py`:

- Reads each spec section, extracts concrete claims (table names, endpoint paths, config vars, flow steps).
- Greps the codebase for each claim.
- Reports claims that no longer match code (removed table, renamed endpoint, removed config var).
- Initial version may wrap the project's `fira-reconcile` skill invocation; later version can be standalone.

Pre-merge guard catches path-based drift; this catches subtle drift where paths didn't change but behavior did.

## 9. Surface List

`docs/architecture/surfaces.yaml` — single source of truth for the guard.

```yaml
# v1 draft — refine via Spec-Patch edits as real PRs reveal gaps.
# Paths are repo-root-relative globs. Any match triggers the surface check.
surfaces:
  auth_plane:
    - "src/backend/oidc_verify.py"
    - "src/backend/authentik_client.py"
    - "src/frontend/src/lib/oidc.ts"
    - "src/frontend/src/stores/auth-store.ts"
  ldap_schema:
    - "src/backend/ldap_client.py"
    - "deploy/dev/openldap-schema/**"
  data_contracts:
    - "migrations/**"
    - "src/backend/orgdb.py"
    - "src/backend/settingsdb.py"
    - "docs/api/openapi*.yaml"
  api_contracts:
    - "src/backend/main.py"
    - "docs/api/**"
  cross_process_boundaries:
    - "src/backend/activity_bus.py"
    - "src/backend/uc_client.py"
  crypto_primitives:
    - "**/sealed_box*"
    - "**/crypto*"
  deploy_topology:
    - "deploy/dev/docker-compose.yml"
    - "deploy/dev/Dockerfile.*"
  security_state_model:
    - "src/backend/rate_limit.py"
    - "src/backend/**/*lock*"
  ci_release_gates:
    - ".github/workflows/**"
    - ".pre-commit-config.yaml"
    - "Justfile"
```

### Concept triggers (PR-template checkbox, not auto-detected)

PR template asks:

- [ ] This PR introduces a new authentication mechanism or identity provider
- [ ] This PR introduces a new protocol (messaging / voice / video / federation)
- [ ] This PR introduces a new persistent store (database / cache / queue / LDAP branch)
- [ ] This PR changes a user-facing trust boundary (public endpoint, anonymous access)
- [ ] This PR changes deployment topology (new/removed service, new network)

If any box is checked → require `ARD:` trailer regardless of paths touched.

**Honesty gap:** concept triggers rely on author self-disclosure. An author who checks none of the boxes despite the PR matching a trigger bypasses this half of the gate. Reviewers are expected to audit. The path-based surface check (§8.1.1) is the automated floor; concept triggers catch what paths can't.

### Expansion rule

`surfaces.yaml` is itself a surface. Edits require `Spec-Patch: SOP` (for corrections / additions of paths that are clearly architectural) or `ARD:` (for decisional expansions, e.g., "we now treat analytics writes as a surface"). Prevents the guard being silently shrunk.

## 10. CHANGELOG — Single git-cliff with scope grouping

The existing `just release` flow is unchanged. `git-cliff.toml` gains grouping rules so architecture commits surface in their own CHANGELOG section:

```toml
[git]
commit_parsers = [
  { message = "^(feat|fix|refactor|perf)\\(arch\\)", group = "Architecture" },
  { message = "^(feat|fix|refactor|perf)\\(auth\\)", group = "Authentication" },
  { message = "^(feat|fix|refactor|perf)\\(ldap\\)", group = "LDAP / Directory" },
  { message = "^(feat|fix|refactor|perf)\\(ci\\)",   group = "CI / Release" },
  { message = "^feat",      group = "Features" },
  { message = "^fix",       group = "Bug Fixes" },
  { message = "^refactor",  group = "Refactor" },
  { message = "^chore",     skip = true },
]
```

Commit trailers (`ARD:`, `Spec-Sections:`, `Supersedes-ARD:`) are preserved in the commit body. git-cliff's `body` template renders the `ARD:` line as a link into the CHANGELOG entry.

**Architecture commit format** (documented in root `CLAUDE.md` § Git Hooks):

```text
feat(arch): add account-lock model to auth plane

Introduces `account_locked_until` column on users. OIDC infra failures
no longer count toward the lock threshold. Same-token failures are
deduplicated via Redis.

ARD: ARD-009
Spec-Sections: 04-authentication, 07-security
Supersedes-ARD:
```

`git interpret-trailers` handles this natively; no new parser.

## 11. CLAUDE.md Relationship

- CLAUDE.md remains operational quick-reference: dev commands, hot-reload rules, env vars, MCP tool rules, skill guidance.
- CLAUDE.md's `## Architecture (Quick Reference)` section is a **summary view** derived from `spec/01..08`.
- **Rule:** architectural facts may exist (a) only in `spec/`, or (b) in both `spec/` and CLAUDE.md as a summary. **Never only in CLAUDE.md.**
- **Guard:** `arch_guard.py` treats edits inside CLAUDE.md's `## Architecture (Quick Reference)` anchor (detected by heading boundaries) as surface changes — same ARD-or-Spec-Patch trailer requirement. Edits outside that anchor (dev commands, hot-reload table, env vars) are free.
- On acceptance, append to root `CLAUDE.md`: *"Architectural facts are owned by `docs/architecture/spec/`. This section is a summary; edits require a matching spec edit (see `docs/architecture/SOP.md`)."*

## 12. Architecture Version Track

Two independent version tracks, one release cadence:

| Track | Format | Where | How bumped | Tagged? |
|-------|--------|-------|-----------|---------|
| Product | `vX.Y.Z` | `package.json`, `_version.py`, git tag | `cz bump` via `just release` | Yes — `vX.Y.Z` |
| Architecture spec | `X.Y.Z` | `<!-- spec-meta -->` in `docs/architecture/README.md` | Manual edit in the same PR that edits `spec/*` | No |

Rationale: an architecture version bump is a documentation event, not a code release. Tagging it would proliferate branches and confuse deploy targets.

`spec-meta.version` on individual `spec/NN-*.md` files tracks "overall spec version at which this section was last modified" — no independent per-section versioning.

## 13. Rollout Phases

### Phase 0 — Foundations (PR-1)

- Create `docs/archive/` with manifest + nested CLAUDE.md
- Move `docs/prd/`, `specs/v2.0/`, `docs/plans/` into archive
- Update references in root `CLAUDE.md` and `docs/architecture/README.md`
- Create `docs/architecture/proposals/` (this doc lives here)
- Create `docs/architecture/surfaces.yaml` (v1 from §9)
- Write `tools/arch_guard.py` v1 — stdlib + `pathspec` + `PyYAML`, ~160 LOC (reduced from ~200 via Approach D's fira delegation)
- Create `tools/arch_guard_requirements.txt` with pinned deps (`pathspec==X.Y.Z`, `PyYAML==X.Y.Z`) — outside-voice Finding #2
- **Migrate ARD-001..004 to YAML frontmatter only** (Issue 1.3 + outside-voice Finding #12). Metadata fields become: `status`, `accepted_at`, `decision_effective_date`, `supersedes`, `superseded_by`, `pr`, `spec_sections_affected`. No duplicate markdown summary — auto-rendered between `<!-- summary:begin/end -->` markers via pre-commit.
- Update `_TEMPLATE.md` to use YAML frontmatter + auto-summary markers + `## Amendments` section at bottom
- Create `.github/CODEOWNERS` with governance-path ownership (outside-voice Tension A1):
  ```text
  /docs/architecture/decisions/**    @<maintainer>
  /docs/architecture/surfaces.yaml   @<maintainer>
  /docs/architecture/SOP.md          @<maintainer>
  /.github/workflows/arch-*          @<maintainer>
  /tools/arch_*                      @<maintainer>
  /tools/_lib/                       @<maintainer>
  ```
  Phase 0 checklist item (manual repo setting): enable "Require review from Code Owners" in `main` branch protection.
- Amend `docs/architecture/SOP.md` to cite this design and its rules
- Remove `docs/architecture/CHANGELOG.md` (rolled into root CHANGELOG via scope)
- Open PR → on merge, author ARD-005 referencing this proposal as its design record

### Phase 1 — Enforcement (SPLIT INTO 1a / 1b per outside-voice Tension C2)

**Phase 1a — Enforcement core (PR-2a)**

- Add `arch-guard` pre-commit hook (local, warn-only by default)
- Add `.github/workflows/arch-guard.yml` (PR-triggered). It does NOT execute the guard from PR HEAD. Instead, it uses **sparse-checkout from `main`** (eng-review E1.1 → B) to materialize the trusted guard sources before invocation:
  ```yaml
  - uses: actions/checkout@v4              # PR HEAD for the diff being checked
  - uses: actions/checkout@v4              # main's copy of the guard (trusted)
    with:
      ref: main
      path: _trusted
      sparse-checkout: |
        tools/arch_guard.py
        tools/arch_guard_requirements.txt
        tools/_lib/
        docs/architecture/surfaces.yaml
        docs/architecture/decisions/
  - run: pip install -r _trusted/tools/arch_guard_requirements.txt
  - run: |
      python _trusted/tools/arch_guard.py \
        --base origin/${{ github.event.pull_request.base.ref }} \
        --head ${{ github.event.pull_request.head.sha }}
  ```
  Closes the "PR neuters its own guard" attack (outside-voice Tension A1) without depending on cross-repo reusable-workflow syntax. Sparse-checkout ~200 ms; preserves PR HEAD as the diff target.
- Add `.github/workflows/arch-guard-post-merge.yml` — re-runs coverage check on merge commit; creates `arch-post-merge-drift` tracking issue if coverage lost in squash (Tension B2)
- CI workflow explicitly `pip install -r tools/arch_guard_requirements.txt` before invoking the guard (outside-voice Finding #2)
- Configure arch-guard + arch-guard-post-merge as required status checks on `main` branch protection
- Run in `--warn-only` mode; flip to `--fail` per Issue 9.3 criterion (2 consecutive weeks zero-false-positives OR 60 days elapsed, whichever first)
- Document commit-trailer conventions in root `CLAUDE.md` § Git Hooks

Phase 1a ships the gate — no friction-reduction features yet. Proves the rule set in warn-only before adding surface area.

**Phase 1b — Friction-reduction + scope grouping (PR-2b, lands ~2 weeks after 1a)**

Prerequisites: Phase 1a has been live ≥2 weeks AND ≥1 architectural PR has exercised the gate.

- Add `tools/arch_new_ard.py` (~50 LOC, stdlib) + `Justfile` recipe `new-ard <slug>` — ARD scaffolder (CEO review Candidate 2). Prefills from git state; opens in `$EDITOR`.
- Update `git-cliff.toml` with scope-grouping rules (§10)
- Update PR template with surface-list checkbox + concept triggers
- Add `tools/check_links.py` + `.github/workflows/check-links.yml` — scans code / docs for stale `docs/prd/`, `specs/v2.0/`, `docs/plans/` references (outside-voice Finding #10)

### Phase 2 — Retro-ARDs + spec sync (PR-3, possibly batched as 3a/3b)

- Write ARD-006 through ARD-009 (thin, 1 page each)
- Patch `spec/01..08-*.md` to match current reality (§7.3)
- Replace `[TARGET v2.0]` markers (§7.4)
- Bump `spec-meta.version` `1.1.0 → 2.0.0`
- Add `tools/render_ard_graph.py` — reads every ARD's YAML frontmatter, renders the supersession graph (mermaid with ASCII fallback) between `<!-- ard-graph:begin --> <!-- ard-graph:end -->` markers in `docs/architecture/README.md`. Pre-commit hook scoped to `docs/architecture/decisions/**` + `docs/architecture/README.md` only (not every commit) to keep runtime negligible. **Failure posture: fail-soft** (decided in CEO review 2026-04-19, Issue 1.4). All rendering errors (mermaid template bugs, malformed metadata, missing markers) log a warning and exit 0 — never blocks a commit. CI has a separate check that warns (not fails) if the committed graph is stale vs freshly rendered. Graph is derived-data, not decision-integrity. Deterministic output asserted via golden-file test in CI to prevent spurious diffs. Accepted in CEO review 2026-04-19 (Candidate 4).

### Phase 3 — Drift audit (PR-4)

- Write `tools/arch_drift_audit.py` (wraps `fira-reconcile` or stands alone)
- Add `.github/workflows/arch-drift-audit.yml` weekly cron
- First run likely fires; treat initial issues as baseline calibration

### Phase 4 — Future

- PR-template checkbox → GitHub action that enforces checkbox completion
- JSON Schema validation on `surfaces.yaml` in CI
- Architecture-only git tag namespace if demand emerges
- Contributor-facing guidance doc (`docs/architecture/CONTRIBUTING.md`) if team grows

**Deferred from CEO review 2026-04-19** (see CEO plan for full rationale):

- **Code-derived spec sections** — generators that render `§03 Data Architecture` from migrations and `§08 Integration Points` from FastAPI routes between `<!-- arch-gen:begin --> <!-- arch-gen:end -->` markers. CI fails if committed spec diverges from generated. **Trigger: after baseline gate has 2 release cycles of operational data** (proves baseline works before adding generator-bug failure modes).
- **CodeRabbit rule as second gate** — LLM-aware semantic policy check that catches drift `arch_guard.py` misses (e.g., column renamed in migration but spec still names old column). **Trigger: after `surfaces.yaml` stabilizes** (~Phase 2 + 1 release cycle), to avoid duplicate-noise overlap with the Python gate during calibration.
- **`# @arch-surface: <name>` code annotations** — surface membership becomes a property of the code; `surfaces.yaml` becomes generated from annotations via AST scan. Closes the "silently shrinks" risk. **Trigger: after 2 release cycles**, if silent-shrinkage incidents occur (if reviewers catch shrinkage reliably, the convention burden isn't justified).

## 14. Open Risks

- **Surface list starts wrong.** First revision of `surfaces.yaml` will miss things and catch things that are not really architectural. Mitigation: treat early false positives and negatives as signal; refine via `Spec-Patch` edits. Do not silently shrink.
- **Emergency-lane abuse.** `ARD-POST:` becomes a merge-anyway escape hatch. Mitigation: auto-issue creation, visible `arch-post-followup` label, blocked arch-version bump until cleared. If abuse persists, require human approval on the label.
- **`arch_guard.py` false positives kill velocity.** Likely in the first two weeks. Mitigation: ship in `--warn-only` mode; flip to `--fail` when EITHER (a) ≥2 consecutive weeks of zero new false-positive warnings (reviewer-tagged `arch-guard-false-positive` label), OR (b) 60 days elapsed post-Phase-1a merge — whichever comes first (Issue 9.3 C + outside-voice Finding #5). Prevents indefinite warn-only drift.
- **`git-cliff` scope-grouping is fragile.** Commits not using the scope convention are silently lost from the Architecture group. Mitigation: commitizen already enforces conventional commits; add a warning when `(arch)` is used without an `ARD:` trailer.
- **Spec drifts silently when no PR touches the relevant code.** A stale claim (e.g., "Redis is used for rate-limiting" after Redis is replaced) will not trigger the pre-merge guard. Mitigation: weekly drift audit (§8.4). Accept a latency of ≤7 days.
- **CLAUDE.md enforcement annoys contributors editing non-architectural sections.** Mitigation: guard only fires on diffs within the § Architecture anchor, detected by heading boundaries, not on the whole file.
- **Retro-ARDs become a make-work project.** Mitigation: strictly limited to the four decisions in §7.2; everything else is a spec patch. One-page ARDs are acceptable.

## 15. Acceptance Criteria

On acceptance of this proposal:

- [ ] ARD-005 merged citing this proposal as its design record
- [ ] Phase 0 PR merged (archive + surfaces.yaml v1 + `arch_guard.py` v1 + SOP amended)
- [ ] Phase 1 PR merged (pre-commit hook + CI workflow + git-cliff scopes + PR template + commit-trailer docs)
- [ ] Phase 2 PR(s) merged (retro-ARDs 006–009 + spec sync + version bump)
- [ ] Phase 3 PR merged (drift audit cron)
- [ ] First weekly drift audit runs successfully
- [ ] Two subsequent architectural PRs successfully pass the guard (proof of life)

## 16. References

- Current SOP (to be amended): `docs/architecture/SOP.md`
- ARD template: `docs/architecture/decisions/_TEMPLATE.md`
- Existing release flow: `Justfile` (`just release` uses `cz bump` + `git-cliff`)
- Sources deprecated by this proposal: `docs/prd/*`, `specs/v2.0/*`
- Prior architecture-governance design (pre-drift): `docs/plans/2026-03-07-architecture-specification-design.md` (to be archived as part of §7.1)
- Drift map (ground truth): PRs #50, #51, #58, #60, #61, #76, #77, #85, #88, #89, #91, #93, #95, #97, #98
- CEO review decision record (scope expansion outcomes): summarised inline in §Reviews above; full transcript lives in the repo owner's gstack workspace and is quoted into `HANDOFF.md` where relevant — intentionally not committed to the shared repo.

## 17. Amendments

*(None yet. First amendment will be added post-acceptance if corrections surface before ARD-005 is cut.)*

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|--------|---------|-----|------|--------|----------|
| CEO Review | `/plan-ceo-review` | Scope & strategy | 1 | CLEAR (SELECTIVE EXPANSION) | 5 proposals / 2 accepted / 3 deferred; 0 unresolved decisions; 0 critical gaps |
| Outside Voice (Codex) | cursor-agent + gpt-5.3-codex-high | Cross-model challenge | 1 | ISSUES FOUND | 12 findings (2 CRIT / 5 HIGH / 4 MED / 1 LOW); 4 tensions resolved; 6 obvious fixes applied |
| Eng Review | `/plan-eng-review` | Architecture & tests (required) | 1 | CLEAR (PLAN, 2026-04-20) | 5 issues; 2 decisions resolved (E1.1=B sparse-checkout, E2.1=A PyYAML+shim); 13 test gaps added; 0 critical gaps |
| Design Review | `/plan-design-review` | UI/UX gaps | 0 | — | Skipped (no UI scope) |
| DX Review | `/plan-devex-review` | Developer experience gaps | 0 | — | Skipped (meta-plan) |

**CODEX:** 12 findings; 6 applied as obvious fixes (CI deps, warn-only reconciliation, ARD-POST back-pressure, retro-ARD dual timestamps, link-check workflow, metadata dual-write removal); 4 cross-model tensions resolved via user decision (A1 B2 C2 D1).

**CROSS-MODEL:** Codex and Claude CEO review substantially agreed on the 6 obvious fixes (independent surfacing from both angles). The 4 tensions reflect genuine design-tradeoff points where user judgment was required — not errors in either review.

**UNRESOLVED:** 0 decisions. All 12 STOP points through Sections 1–10 resolved in conversation.

**VERDICT:** CEO + Outside Voice + Eng Review all CLEARED. Design/DX not applicable. **Plan is implementation-ready.**

**Implementation approach:** D — full proposal + `--warn-only` rollout + fira delegation + 1a/1b Phase 1 split + trusted-workflow execution + CODEOWNERS + full-coverage trailer gate + dual-timestamp retro-ARDs + frontmatter-only metadata.

**Phase count:** 6 PRs total (0, 1a, 1a→fail flip, 1b, 2, 3) — sequential, each ≤8 files.
