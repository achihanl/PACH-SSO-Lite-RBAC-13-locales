<!-- spec-meta: { section: "08", version: "1.53.0", last_updated: "2026-10-24" } -->

# 08 — Integration Points

## 1. Authentik Admin API v3 `[AS-BUILT]`

The `AuthentikClient` class provides stateless access to Authentik's Admin API for session and token lifecycle management. It is used during user termination -- not for authentication.

**Connection:**
- Base URL: `AUTHENTIK_API_URL` (Docker-internal network, e.g. `http://authentik-server:9000`)
- Auth: `Bearer {AUTHENTIK_API_TOKEN}` header on every request
- Timeout: 10 seconds per request
- HTTP client: Python stdlib `urllib.request` (no external HTTP library)

### API Operations

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/v3/core/users/?username={username}` | Find user PK by username: quoted, exact match only. Unquoted, a `#` cut the query, so `keith#1` resolved to `keith` and suspending it revoked keith's tokens |
| GET | `/api/v3/core/authenticated_sessions/?user__username={username}&page=N` | List active sessions for a user, every page (2026.5 ignores `?user=<pk>` on this endpoint and lists everyone's) |
| DELETE | `/api/v3/core/authenticated_sessions/{uuid}/` | Revoke a specific session (2026.5 keys sessions on `uuid`) |
| GET | `/api/v3/oauth2/access_tokens/?user={pk}` | List OAuth2 access tokens for a user |
| DELETE | `/api/v3/oauth2/access_tokens/{pk}/` | Revoke a specific OAuth2 access token |
| GET | `/api/v3/oauth2/refresh_tokens/?user={pk}` | List OAuth2 refresh tokens for a user |
| DELETE | `/api/v3/oauth2/refresh_tokens/{pk}/` | Revoke a specific refresh token |
| GET | `/api/v3/core/users/?username={username}` (`groups_obj`) | `in_group`: is the user in `OIDC_ADMIN_GROUP` (ARD-019 containment) |
| PATCH | `/api/v3/core/users/{pk}/` `{is_active}` | `set_active`: deactivate on suspend/terminate, reactivate on unsuspend |
| GET, DELETE | `/api/v3/core/tokens/?user__username={username}&intent=app_password`, `/api/v3/core/tokens/{identifier}/` | `revoke_app_passwords`: terminate only |
| GET, DELETE | `/api/v3/policies/reputation/scores/?identifier={id}`, `/api/v3/policies/reputation/scores/{pk}/` | `clear_reputation`: unlock, for the username and `ldap-bind-budget:<uid>` |

### Termination Flow

`terminate_user_access(username)` orchestrates full revocation:
1. Find user PK by username, once for both steps below
2. List and DELETE the user's authenticated sessions (never another user's)
3. List OAuth2 access and refresh tokens at once, then DELETE every access token, then every refresh token (a surviving refresh token keeps minting access tokens)

Steps 2 and 3 run side by side. A session DELETE cascades to its access tokens, so a token DELETE that answers 404 counts as revoked, not as a failure.
4. Return summary: `{user_found, sessions_revoked, tokens_revoked}`

Called from the user termination endpoint and, since ARD-019 §7, from suspend for every caller.

**Cut-off (ARD-019 amendment 2026-10-21).** After `terminate_user_access`, suspend and terminate
deactivate the Authentik user (`is_active=false`): on 2026.5 that refuses sign-in, the refresh grant
and the app-password grant, and deletes the user's tokens, so a token minted mid-revocation dies too.
Terminate also deletes the user's app passwords (before deactivating) and queues the LDAP source sync
that drops the groups `disable_user` removed. Unsuspend reactivates the user. `POST
/api/users/{uid}/unlock` runs step 1 of the unblock runbook below.

**Terminated stays terminated.** Suspend, unsuspend, `reset_password`, `POST /api/me/password` and
`move_org` refuse a terminated user with 409 before any write, so neither LDAP, Authentik nor the PBX
ACL sees them again. The check sits in the shared LDAP writers (`_set_user_passwords`,
`suspend_user`, `unsuspend_user`, `move_user_to_org`), not in one route: either marker counts,
`description=TERMINATED` or `pwdAccountLockedTime=000001010000Z`. Both matter because any
`userPassword` write, the admin's included, makes ppolicy delete the lock sentinel (measured on the
stack), and the PBX ACL hides `AstAuthPassword` only while `description` says SUSPENDED or
TERMINATED. A scoped caller's refusal is audited as `scoped_denied`. Each of those writes also
carries the LDAP assertion control (RFC 4528) on "neither marker", so slapd refuses it (409) when a
terminate lands between the check and the write. Terminate writes the sentinel in its own modify,
after the `userPassword` one, so a repeated terminate keeps it.

Each step runs even if an earlier one failed. A failure does not block the LDAP-side change: it is
logged at ERROR, lands in the audit row as `authentik_error`, and the response still answers 200 with
`partial: true` and a warning naming the step. Repeating the call retries; every step is idempotent.
Each ERROR line starts `revocation incomplete:`, which the critical Loki rule **Revocation
incomplete** pages on (ARD-008 amendment 2026-10-24). A suspend or unsuspend whose lifecycle,
suspension or admin audit row fails to write logs `audit not recorded` at ERROR and adds an `audit`
warning (it was a bare `pass`). The admin UI's termination dialog shows a partial result as
"Termination incomplete" with each warning, and so does its downloaded report.

### Authentik API Gotchas (2025.8+)

| Gotcha | Detail |
|--------|--------|
| `redirect_uris` format | Must be `[{matching_mode: "strict", url: "..."}]` dicts, NOT plain strings |
| `invalidation_flow` | REQUIRED field when creating an OAuth2 provider |
| `signing_key` | Must be set on OAuth2 provider -- without it, JWKS returns empty keys |
| `property_mappings` | Must set openid/profile/email scope mappings on provider |
| End-session endpoint | Does NOT revoke tokens -- must explicitly `DELETE /api/v3/oauth2/access_tokens/{id}/` |
| First startup | ~60s for DB migrations before API is reachable (seed script polls 30x5s) |
| `iss` claim variance | Authentik stamps `iss` based on access URL -- Docker-internal and tunnel URLs differ |

**Source:** `src/backend/authentik_client.py`

---

## 2. LDAP Bind Contract `[AS-BUILT]`

### Connection Parameters

| Parameter | Config Variable | Default |
|-----------|----------------|---------|
| Server URI | `LDAP_URI` | `ldap://127.0.0.1:389` |
| Bind DN | `LDAP_BIND_DN` | `cn=admin,dc=example,dc=com` |
| Bind Password | `LDAP_BIND_PW` | (env-configured) |
| TLS | `LDAP_USE_SSL` | `false` |
| Protocol | LDAP v3 | (ldap3 library default) |

`get_conn()` creates a `Server` with `get_info=ALL` and `use_ssl=LDAP_USE_SSL`, then binds with `auto_bind=True`. All CRUD operations use this admin bind connection. Errors are caught by `safe_ldap()` which wraps `LDAPException` into `RuntimeError`.

### Bind Planes

| Plane | Bind DN | Password Attribute | Purpose |
|-------|---------|-------------------|---------|
| Admin (API) | `cn=admin,dc=azblink,dc=com` | `LDAP_BIND_PW` | All directory-api CRUD operations |
| User auth (Plane A) | `uid={username},ou=people,{base}` | `userPassword` (SSHA) | XMPP bind auth, login verification |
| SIP auth | PBX: `cn=<c>,ou=pbx,ou=clients,{base}` (ARD-020), searches `ou=<c>,ou=people` | `AstAuthPassword` | SIP digest auth (plaintext, separate from login); the PBX reads it for that client's active owned users only (§07 PBX Read Access) |

### LDAP Library

Uses **ldap3** (Python). Operations: `MODIFY_ADD`, `MODIFY_DELETE`, `MODIFY_REPLACE`, `SUBTREE`, `LEVEL` search scopes. DN escaping via `escape_filter_chars()`.

**Source:** `src/backend/ldap_client.py`, `src/backend/config.py`

### Directory Consumer Contract `[AS-BUILT]`

What a relying party that reads this directory over LDAP must be configured with. Two entries below are not the consumer's default, and each one silently drops users rather than erroring — a consumer keyed on the wrong attribute is indistinguishable from an empty directory.

| Concern | Read from | Consumer default is often | Note |
|---|---|---|---|
| Account identifier | `uid` | `uid` / `sAMAccountName` | The application-visible identity. Equals the OIDC `preferred_username`. |
| **Display name** | **`cn`** | **`displayName`** ⚠️ | **azb-AD writes no LDAP `displayName` on any path.** See below. |
| Email | `mail` | `mail` | Optional — only written when supplied. |
| Group membership | `member` on `cn=<group>,ou=groups,{base}` | `memberOf` on the user | `memberOf` is also available, via the overlay recorded in **03 §2.4** — but it computes only on write, so entries predating the overlay carry none. `member` is the durable read. |
| **Account is dead** | **`(pwdAccountLockedTime=*)`** | *(nothing)* ⚠️ | Terminated users stay in the tree. A consumer that does not exclude this keeps a terminated account enabled and addressable indefinitely (see **02 Termination Flow**). |
| User search base / filter | `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=*)))` under `ou=people,{base}` | — | The canonical active-user filter. |

**`cn` is the display-name attribute.** There is no LDAP `displayName` to map to: `create_user()` writes `cn` (falling back to the `uid` when no display name is given), `update_user()` maps the *API* field `displayName` onto `cn`, and every read reconstructs that API field from `cn`. A second attribute was considered and rejected — it would duplicate `cn`, need write-sync on every path forever, and need a migration, all to satisfy a default this product has never held. Consumers map to `cn` explicitly (for Nextcloud's `user_ldap`, `ldapUserDisplayName=cn`).

Because `cn` is load-bearing for consumers it is kept readable at the API edge rather than trusted to the schema. OpenLDAP rejects an absent or empty-string `cn` on its own, but accepts a **whitespace-only** one verbatim — which would leave an entry nameless in every consumer while returning 200. A blank `displayName` on `PATCH /api/users/{uid}` or `PATCH /api/me` is therefore refused with 422, and values are stripped before being written; on create, blank remains legal and falls back to the `uid`. Pinned by `tests/test_users.py::TestDisplayNameIsCarriedByCn`.

**Consumers bind as a provisioned client** under `ou=clients` (§6 *Client Provisioning*), never as `cn=admin`. Under [ARD-001](../decisions/ARD-001-single-ldap-architecture.md) identity and UC service attributes share one entry, so an admin bind hands a consumer that needs `uid`/`cn`/`mail`/`member` read access to `AstAuthPassword` and the rest of the UC secrets. The `ou=clients` ACL grants exactly the attributes in the table above and hides every secret. The one exception is a client's PBX identity under `ou=pbx,ou=clients`, which also reads `AstAuthPassword` of that client's active owned users ([ARD-020](../decisions/ARD-020-client-sip-provisioning-and-pbx-read.md), §07).

**Source:** `src/backend/ldap_client.py`, `src/backend/schemas/users.py`, `deploy/dev/ldap/ldap-clients-acl.ldif`

---

## 3. External Service Integration `[AS-BUILT]`

UC services consume the single LDAP directory for authentication and configuration. Both use the same LDAP entry (single DN) but different password attributes.

### XMPP Server

- **Auth method:** LDAP simple bind using `userPassword` (SSHA hash)
- **DN pattern:** `uid={username},ou=people,{LDAP_BASE_DN}`
- **Purpose:** Real-time messaging authentication
- **Endpoint config:** `xmpp_domain`, `xmpp_ws_url` (stored on profile)
- **Over the relay path (ARD-021 §3):** LDAPS to `<azblink_public_host>:636` (a hosts entry to
  the private IP), the certificate checked against the relay CA; a search bind as a provisioned
  client under `ou=clients`, never `cn=admin`; base `ou=people,<base>` with `uid` as the user
  attribute and the active-user filter from §2. In ejabberd: `ldap_encrypt: tls`,
  `ldap_port: 636`, `ldap_tls_verify: hard`, `ldap_tls_cacertfile`, `ldap_rootdn`,
  `ldap_uids: {uid: "%u"}`, `ldap_filter`. Suspend replaces `userPassword`, so the next login
  fails; keep `auth_cache_life_time` short (SafeNest: 300 s), since a cached check outlives it.
  Reference config and test: `deploy/dev/relay-sim/ejabberd.yml`, `tests/test_relay_path.py`.

### Asterisk / SIP

- **Auth method:** LDAP attribute lookup for `AstAuthPassword` + `AstAuthRealm`, `AstAuthType=userpass`
- **Endpoint name:** the extension, in `AstAccountName`, `AstAuthUsername` and the `*Id` attributes; the `uid` stays separate (ARD-020 §1, §03 §2.3). Phones register with the extension as username.
- **Password:** 24-character random string generated at enable, or a 12+ character secret set through `PUT /api/users/{uid}/sip` -- separate from `userPassword`
- **Context:** `AstEndpointContext` is the resolved SIP context, user > group > org > `default` (§03 §2.3); `from-internal` routes nothing on UED
- **Realm:** `SIP_AUTH_REALM` (default: `"asterisk"`)
- **LDAP objectClasses:** `AsteriskAccount`, `AsteriskPjsipEndpoint`, `AsteriskPjsipAuth`, `AsteriskPjsipAor`
- **Endpoint config:** `sip_domain`, `sip_wss_url` (stored on profile)
- **UED SIP-in-LDAP, per box (ARD-020 §4):** bind DN `cn=<c>,ou=pbx,ou=clients,<base>` and its secret, basedn `ou=<c>,ou=people,<base>`, the default `sfilter` `(AstAccountName=*)`, realm `asterisk` (not UED's default `azblink2`). UED reads PJSIP live from LDAP; changes apply in about 1 s. The box-to-LDAP path carries the secret in clear and must be private.
- **Asterisk realtime equivalent (tested):** `res_config_ldap` with the same bind DN, basedn and
  `additionalFilter=(AstAccountName=*)` on the `ps_endpoints`, `ps_auths` and `ps_aors` tables;
  `sorcery.conf` maps endpoint, auth and AoR to realtime with no cache, so each REGISTER reads
  LDAP. Field mapping: endpoint `id`/`context`/`allow`/`disallow`/`aors`/`auth`/`transport` from
  `AstEndpoint*`, auth `id`/`auth_type`/`password`/`username`/`realm` from `AstAuth*`, AoR
  `id`/`max_contacts`/`remove_existing`/`qualify_frequency` from `AstAor*`. The dialplan needs the
  contexts the API writes (`default`, `all`). Reference config: `deploy/dev/relay-sim/asterisk/`;
  `tests/test_relay_path.py` registers, calls, suspends and checks another org's user against it.

### Dual Password Design

| Attribute | Generated By | Used By | Format |
|-----------|-------------|---------|--------|
| `userPassword` | Admin-set or provisioning | XMPP bind, web login (via Authentik LDAP source) | SSHA hash |
| `AstAuthPassword` | `provisioning.py` (24-char random) or `PUT /api/users/{uid}/sip` | SIP digest auth only; read by the client's PBX | Plaintext (for digest) |

Service endpoints are stored on the profile (`config_templates` table) and included in QR provisioning payloads so client apps know where to connect.

---

## 4. API Contract Summary `[AS-BUILT]`

The REST API surface is organized by domain. All endpoints return JSON with an `ok` boolean field.

### Where Routes Live

The 102 route handlers live in `src/backend/routers/`, one module per domain. `main.py` registers them and holds no handlers of its own.

The wire contract did not change when they moved: the generated OpenAPI document is byte-identical to the pre-decomposition one, pinned by `tests/contract/test_openapi_snapshot.py` against `openapi.baseline.json`. Response shapes are pinned separately by `test_response_shapes.py`.

**Registration order is load-bearing.** Starlette matches routes in registration order, so `/api/users/search` must be registered before `/api/users/{uid}` or the literal path is swallowed by the parameterised one. Two things preserve that: definition order within each router module, and `ROUTER_ORDER` in `routers/__init__.py` — a list reproducing the order the routes appeared in the pre-decomposition `main.py`, which `main.py` iterates. Reordering either changes which handler answers a request, so both are part of the API contract rather than implementation detail.

### Endpoint Domains

Routes are grouped by the router module that owns them, in `ROUTER_ORDER`.

| Router module | Routes | Endpoints | Authorization |
|---|---:|---|---|
| `system.py` | 7 | `/api/health`, `/api/health/deep`, `/api/version`, `/metrics`, `/api/tenant`, `/api/bootstrap`, `/api/system/versions` | Public (health), `require_user`, `require_admin`, `system_configuration` |
| `orgs.py` | 9 | `/api/org/tree`, `/api/org/users`, `/api/org/create`, `/api/org/rename`, `/api/org/sip_context`, `DELETE /api/org/{dn}`, `/api/orgs/tree`, `/api/orgs/detail`, `/api/orgs/users` | `require_directory_read` (read), `org_management` (write) |
| `groups.py` | 10 | `/api/groups`, `/api/groups/{cn}`, `/api/groups/create`, member add/remove/role/list, group patch/delete, `/api/groups/{cn}/permissions` | `require_directory_read` (read), `user_management` (write; grants contained — §07) |
| `users.py` | 18 | `/api/users`, `/api/users/search`, `/api/users/export`, `/api/users/{uid}` (+ patch, groups, devices, stats), `/api/users/create`, `reset_password`, `PUT /api/users/{uid}/sip`, `move_org`, `terminate`, `suspend`, `unsuspend`, `import_csv`, `lock-status`, `unlock` | `require_directory_read` (read), `user_management` (write); writes act on the uid LDAP found, not the path spelling |
| `selfservice.py` | 4 | `/api/me`, `PATCH /api/me`, `/api/me/password`, `/api/me/devices` | `require_user` |
| `provisioning.py` | 10 | `/api/provision/validate`, `/api/provision/consume`, `/api/provision/device` (+ delete), token `bulk-revoke` / `extend`, `/api/provisioning/devices` (+ history), `/api/provisioning/compliance`, `/api/provisions/pending` | `require_user`, `require_admin`, `device_provisioning` |
| `orgprofiles.py` | 5 | `/api/orgprofiles` (+ per-id get/patch/delete) | `require_directory_read` (read), `device_provisioning` (write) |
| `dashboard.py` | 3 | `/api/dashboard/stats`, `/api/dashboard/chart`, `/api/dashboard/health` | `require_admin` |
| `realtime.py` | 2 | `/api/activity/recent`, `WS /api/activity/ws` (the SSE feed `/api/activity/stream` is gone: it never re-checked `exp`, lock or group, and no UI read it) | `require_admin`; the WebSocket applies it in `verify_ws_token` (admin group, account lock) and closes at the token's `exp` |
| `audit.py` | 5 | `/api/audit/terminations`, `auth_failures`, `user_lifecycle`, `events`, `export` | `audit_log_access` |
| `templates.py` | 12 | `/api/config-templates` CRUD, `clone`, `assign`, assignment delete, `validate-endpoints`, profile-service create/update/delete | `require_admin`, `system_configuration` |
| `settings.py` | 13 | `/api/settings` (+ security, patch, reset), LDAP client inventory (list/patch/delete), provisioned clients (create/list/rotate/revoke), `ldap/test`, `email/test` | `system_configuration` |
| `admin.py` | 3 | `/api/security/blocked-ips` (list/create/delete) | `system_configuration` |

**Group and RBAC writes are audited.** Every write route in `groups.py` (create, delete, patch, member add / remove / role, `/permissions`) records an `admin_action_audit` row, `resource_type` `group`, `resource_id` the group cn, through `routers/_shared.audit_admin_action`. A permissions change records `granted`, `revoked` and the resulting `permissions`; a delete records the permissions the group conferred. The audit write is best-effort: it runs after the change commits, so a failure is logged and the response is unchanged. A rejected request (404, 403, 422) writes nothing, and `PATCH /api/groups/{cn}` validates `group_type` before any write.

**Org delete answers 409 while the org is not empty.** `DELETE /api/org/{dn}` refuses while
`ou=<org>` under `ou=org`, `ou=people` or `ou=groups` holds any entry: a user (terminated ones
included), a group or a sub-org. Nothing is deleted, the org's profile included. Before the fix it
ignored LDAP's results, answered `ok`, left the non-empty OUs behind and deleted the profile.

**Policy: an org that ever held users is never deleted.** Its OUs stay as the termination records
of those users. While a terminated user remains in the org, the 409 above enforces this.

**Profile range changes answer 409 or 422.** `PUT /api/config-templates/{id}` with `uidRangeStart`/`uidRangeEnd`, and `PUT /api/config-templates/{id}/services/{sid}` with `counterStart`/`counterEnd`, return 409 when the new end falls below values already issued and 422 when the start is after the end; nothing is written. Otherwise the response's `nextUidNumber` / `nextCounter` is the counter after it moved up to the new start (§05 Counter Mechanics). A SIP service's range, on `POST /api/config-templates/{id}/services` or when a `PUT` changes it, also answers 409 when it overlaps another profile's SIP range (the `detail` names that profile) and 422 when it is wider than `SIP_RANGE_MAX_SIZE` (§05 § SIP ranges are disjoint).

Authorization names refer to the ladder in `auth.py` (see **02 § Key Design Decisions**). `require_permission("<name>")` falls back to the OIDC admin group; behaviour when the RBAC store is unreachable is decided in [ARD-012](../decisions/ARD-012-auth-degraded-store-posture.md).

> **Removed since the last spec sync.** The QR-code endpoints (`/api/users/{uid}/qrcode*`), the public QR preview (`/api/qr/preview/{token}`), and the API-key endpoints (`/api/keys*`) no longer exist in the backend. QR provisioning is now carried by the device-provisioning endpoints in `provisioning.py`; the `api_keys` table was dropped by `migrations/018_drop_api_keys.sql`.

**Full specification:** the generated OpenAPI document at `/api/openapi.json` (Swagger `/api/docs`, ReDoc `/api/redoc`), pinned by `tests/contract/openapi.baseline.json`. It declares an `HTTPBearer` security scheme. `DOCS_ENABLED` serves all three in dev environments and none elsewhere unless set to `1` — production exposure belongs behind an Authentik ForwardAuth. [AS-BUILT: ARD-017] (`docs/archive/specs-v2.0/Directory_Portal_OpenAPI_v4.2.yaml` is archived and no longer current.)

### API-to-API Integration `[AS-BUILT]` (ARD-017)

How another backend service calls this API — one confidential Authentik
provider per service, `client_credentials` only:

| Step | Where | Value |
|---|---|---|
| Register | `AUTHENTIK_SERVICE_CLIENTS` (seed) | `client_id` (provider name == `client_id`) |
| Accept | `OIDC_ACCEPTED_AUDIENCES`, `OIDC_ACCEPTED_ISSUERS` | `client_id`; `…/application/o/<client_id>/` |
| Authorize | `OIDC_SERVICE_PERMISSIONS` | `client_id:perm|perm` (§07 Service Principals) |
| Credential | Authentik Admin API, once → caller's vault | provider `client_secret` (never rotated by the seed) |
| Call | `POST /application/o/token/` `grant_type=client_credentials&client_id&client_secret` | 15-minute access token; re-request, no refresh |

The seeded dev demo is `azblink-svc-demo` with `audit_log_access`.

**Client-scoped principal `[AS-BUILT]` (ARD-019).** Instead of RBAC permissions, a
service client may be bound to one first-party client: same Register, Accept and
Credential steps, an empty `OIDC_SERVICE_PERMISSIONS` entry (or none), and
`OIDC_SERVICE_CLIENT_SCOPES="<svc>:<client_id>:<role>|<role>"`. It may then run
nine user and group calls on that client's roles and users, plus ARD-020's two SIP calls,
and nothing else (§07 Client-Scoped Service Principals). Scoped writes share one 600/minute
bucket per principal; a 429 is retryable. The dev principal is
`safenest-dev-directory:safenest-dev:admin|staff|resident|visitor`; prod renders
the key from the inventory var `authentik_service_client_scopes` (§06).

### First-Party Headless Login `[AS-BUILT]`

How a first-party app keeps its own login form and still signs users in through
Authentik (sequence: §04 §2.1). One confidential provider per client,
`authorization_code` + `refresh_token`:

| Step | Where | Value |
|---|---|---|
| Register | `AUTHENTIK_FIRST_PARTY_CLIENTS` (seed, one JSON value), or `POST /api/clients/onboard` (ARD-022, table `first_party_clients`) | `{"<client_id>": ["<redirect_uri>", …]}`. `/authorize` checks the URI even though the relay never follows it |
| Flow | `headless-first-party-auth` (seed), the provider's authentication flow | own stages: identification (email or username, no captcha) → password (Inbuilt + LDAP backends) → deny (lockout guard, below) → authenticator-validate (every device class; skipped when the user has none) → user-login. Edits to the brand's default flow do not reach it |
| Allow | Application group policy binding (seed) | the `<client_id>-*` groups; anyone else is refused at `/authorize` |
| Roles | `/api/groups/*` (azb-AD admins) | `<client_id>-<role>`, lowercase, top of `ou=groups`, `uidObject` + `uid=<cn>`; synced by the `azblink-ldap` source |
| Relay source | `AUTHENTIK_TRUSTED_PROXY_CIDRS` (compose → `AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS`; ansible `authentik_relay_ips`, one static IPv4 per client, rendered as /32s) | the relay box's address on the routed private path (ARD-021). Default loopback only; never a shared docker network or its gateway |
| Lockout | headless flow and brand flow (seed) | 3 failed passwords for a username, at most 2 of them from any one client IP, refuse it with `ak-stage-access-denied`, `error_message` "Too many failed sign-in attempts…" (below) |
| Credential | Authentik Admin API, once → client's vault | provider `client_secret` (never rotated by the seed) |
| Verify (client side) | issuer `<host>/application/o/<client_id>/`, JWKS `<issuer>jwks/` | RS256, `aud=<client_id>`, `exp` required |

Not registered in `OIDC_ACCEPTED_AUDIENCES`: this API rejects first-party tokens.

Role changes reach Authentik through the `azblink-ldap` source, which syncs only
the registered `<client_id>-*` groups. After a group create or a membership
change on such a group (including user create and CSV import), the API queues a
source sync in the background (`AuthentikClient.trigger_ldap_sync`, waiting out
any sync already running), so a removed role is gone at the client's next
refresh. Deleting such a group also deletes the Authentik group, because the
source never deletes groups. Authentik being down never fails the directory write.

Rules every client meets (ARD-018): confidential client with PKCE S256; the shared
`headless-first-party-auth` flow only; access 15 min, refresh 7 d; the relay never
logs passwords or raw flow responses and sets `X-Forwarded-For` to the client IP it observed (never
appends an incoming one); MFA fails
closed; logout = refresh-token revoke, no Authentik session delete; tokens accepted
only with the client's `aud`, an allowed issuer and `exp`.

**Lockout.** Two flows bind LDAP in their password stage: the shared headless flow and the brand
flow `default-authentication-flow` behind web sign-in, admin sign-in included (G22). The seed gives
both the same lockout, each with its own `<flow>-*` objects. A reputation policy (username rows only,
`check_ip` off, passes at a sum of −3 or less) is bound negated on the password stage's binding, so
it is re-checked on every request before the LDAP bind. That binding's policy engine mode is `all`:
the brand flow's own "password needed" policy sits on the same binding and under `any` would
outvote the check. When it trips, the password stage is skipped and a deny stage after it ends the
flow (it runs unless a stage authenticated the user, and fails closed on a policy error). The same
guard, negated, sits on the user-login binding, so a flow plan stored in a session before the deny
stage existed still never logs a user in without a password. A passkey accepted at identification
counts as authenticated, as the brand flow already assumes. The tenant's `reputation_upper_limit`
is 0, so successful sign-ins never buy extra failures. A fresh session is refused at the
identification POST; a session identified earlier is refused at its password POST. Both flows count
the same username rows. The relay shows a lockout message and points to web sign-in; web sign-in
says to ask an administrator.

The reputation check races: every POST in a parallel burst passes it before any failure is recorded.
A **bind budget** on the same password binding closes that (G23). On each password POST, an expression
policy reserves one of the username's 3 binds with one atomic Postgres upsert. If no reservation is
left, the password stage is skipped and the deny stage ends the flow. Both flows share the counter.
Its key is the username, NFKC-normalised, whitespace-collapsed and lowercased. Once a stage
authenticates the user, the guard gives back that session's reservation, once. So successes do not
use up the budget, and failures stay counted. A refused attempt reserves nothing. The counter resets
when 3900 s pass with no reservation, which is longer than `pwdFailureCountInterval` plus a running bind.
The reservation statement does that reset itself; it does not wait for Authentik's cleanup task. The
counter is a reputation row: identifier `ldap-bind-budget:<username>`, IP `::`. The reputation check
never matches it. The budget binding fails closed (`failure_result` false). At most 3 password
sign-ins per username can be in flight at once; the rest are refused and can retry.

A **source throttle** in front of both (audit blocker B5, ARD-018 amendment 2026-10-21) keeps one
source from blocking a username. The source is the client IP Authentik records: `X-Forwarded-For`
counts only from the trusted relay CIDRs above, otherwise it is the socket peer. The same policy, before
it reserves the username's bind, refuses a source whose reputation row for the username sums to −2 or
less, then reserves one of that source's 2 binds (row `ldap-bind-budget:<username>`, IP = the source,
same upsert and window). If the username's bind is then refused it gives the source's back; a success
gives back both. So one source spends at most 2 of the username's 3 failures, parallel or not, and is
then refused even with the right password, while the user signs in from anywhere else. Failures from
two sources still block the username. Everyone behind one address (a NAT, a relay or proxy not on the
trusted list, the dev tunnel's `cloudflared`) is one source. In production each browser is its own source:
the edge takes `CF-Connecting-IP` from cloudflared only and hands that one address down (§06 Transport,
browser source). At most 2 sign-ins per username per source can be in flight at once.

This keeps ppolicy's `pwdMaxFailure` of 5 out of reach, for parallel traffic too: at most 3 stored LDAP
failures, so XMPP and SIP keep working. ppolicy's `pwdFailureCountInterval` is 3600 (G24): LDAP
forgets a failure after an hour, 23 h before the reputation row that counted it expires, so one
lockout's failures do not carry into the next, nor past an admin unblock. It is longer than
`pwdLockoutDuration` (300), so an account whose lock ends re-locks at its next failure instead of
getting 5 fresh tries.

Not covered (ARD-018 amendment): LDAP binds outside Authentik (XMPP, SIP). The budget leaves them a
margin of 1 below `pwdMaxFailure` and does not count them. Measured on dev before and after the budget
(the ARD-018 G23 amendment has the full table): of 96 parallel wrong passwords after 2 failures, 90 reached
the bind and locked LDAP before; 1 reached it after, and LDAP stayed unlocked.

Successful sign-ins do not heal a score either: a blocked username stays blocked until its rows
expire or an admin deletes them. This now includes admins on web sign-in: anyone who can reach
Authentik from two sources can block a username, `akadmin` included, for 24 h with 3 attempts. From one
source, 2 attempts block only that source. The runbook below clears both kinds of row.

**Unblock (runbook).**

1. Authentik: delete every reputation row whose identifier is the username, and its bind-budget row
   `ldap-bind-budget:<uid>` (lowercase). Admin UI: Customization → Policies → Reputation scores. API:
   `GET /api/v3/policies/reputation/scores/?identifier=<id>` for each of the two identifiers,
   then `DELETE /api/v3/policies/reputation/scores/<pk>/` per row.
2. When no admin can sign in (`akadmin` blocked), use the server container, which needs no login:
   `docker exec azblink-authentik-server ak shell -c "from authentik.policies.reputation.models import Reputation; print(Reputation.objects.including_expired().filter(identifier__in=['<uid>', 'ldap-bind-budget:<uid>']).delete())"`.
   An admin API token (the bootstrap token) with the API calls in step 1 works too.
3. LDAP, only if the entry is locked: read `pwdAccountLockedTime` first. `000001010000Z` is the
   termination sentinel (`disable_user`): leave it, and restore the user through the API instead.
   Any other value is a ppolicy lock; clear it with the relax control:
   `docker exec -i azblink-openldap ldapmodify -Y EXTERNAL -H ldapi:/// -e relax`, input
   `dn: uid=<uid>,ou=people,dc=azblink,dc=com` / `changetype: modify` / `replace: pwdAccountLockedTime`
   / `-` / `replace: pwdFailureTime` / `-`. Left alone, a ppolicy lock ends after 300 s.

**Client registry**

| client_id | App | Roles | Redirect URIs | Relay path |
|---|---|---|---|---|
| `safenest-dev` | SafeNest (dev building) | `safenest-dev-{admin,staff,resident,visitor}` | `http://localhost:5173/auth/callback` | docker network `http://authentik-server:9000` |

SafeNest registers one client per building box, `safenest-<building>`, with the
building id matching `^[a-z0-9]{2,16}$`. A building is a client, not a tenant.

**Onboarding a building in one call (ARD-022).** Per building `<b>`, with `<c>` = `safenest-<b>`, an
admin (admin group) calls:

```text
POST /api/clients/onboard
{clientId: "<c>", redirectUris: ["<relay callback>"], roles?: [admin, staff, resident, visitor],
 sipRangeStart?: int, sipBlockSize?: 100, sipContext?: "default" | "all"}
→ {ok, clientId, created: [...], orgDn, groups: [dn, ...],
   loginClient: {clientId, clientSecret, issuerPath}, directoryClient: {clientId, clientSecret, roles},
   sip: {profileId, rangeStart, rangeEnd, context}, pbx: {bindDn, secret}, ejabberd: {bindDn, secret},
   xmppBridge: {uid, dn, password}}
```

It registers the client (table `first_party_clients`, no deploy, live on every worker within 10 s),
and converges the org and role groups, the login client `<c>` and service client `<c>-directory`
in Authentik, the LDAP source's `(cn=<c>-*)` term, a profile with the building's own SIP and UID
blocks assigned to the org, the org's SIP context, the PBX client `cn=<c>,ou=pbx,ou=clients`, the
XMPP search client `cn=<c>-ejabberd,ou=clients` and the owned bridge user
`uid=<c>.xmpp-bridge,ou=<c>,ou=people`. A failed step answers 502 naming it; repeating the call
resumes. Every secret, the two Authentik client secrets included, comes back only from the call
that creates it (`null` after): directory admins are not Authentik superusers. Rotate LDAP ones with
`…/provisioned/{id}/rotate` and the principal's `reset_password`, Authentik ones as in
docs/runbooks/client-lifecycle.md. The Authentik step runs last, so no later step can fail and lose
a new provider's secret. 409 when `<c>` is an env client (`AUTHENTIK_FIRST_PARTY_CLIENTS`: the seed
manages it), nests with a registered id, has `<c>-*` groups carrying RBAC permissions (ARD-019
invariant 1), or prefixes the admin group (`OIDC_ADMIN_GROUP`, case-insensitive: `(cn=it-*)` matches
`IT-Admins`), or, for a `<c>` with no registry row yet, when `<c>` or `<c>-directory` already exists
in Authentik, `ou=<c>,ou=people` already holds users, or any `<c>-*` group already exists (onboarding
did not create it); also when a repeat asks for another SIP block, or adds a role whose `<c>-<role>`
group already exists. slapd does the group matching (`(cn=<c>-*)` under `ou=groups`), so case
folding, spacing and a second `cn` value count as they do for the LDAP source's term. A repeat that omits `roles` or
`sipContext` keeps the client's stored roles and the org's context; the defaults apply to a new
client only. Guards in place of the deploy review (ARD-022 §5 and its 2026-10-22 amendment): admin group
only; an `onboard_client` audit row before any change (no row, no change: 503) and after; redirect
URIs exact, `https` outside dev, no wildcard, fragment or user info, at most 512 characters (422); 10 calls a minute (429);
advisory locks on the UID block choice and the LDAP source filter write. Env registration
(`AUTHENTIK_FIRST_PARTY_CLIENTS`, `authentik_service_client_scopes`) still works; an env client is
never onboarded. An optional `relayIp` is stored on the row and the response's `relay.operatorStep`
names the converge that trusts it (`authentik_onboarded_clients`, `authentik_relay_ips`; ARD-022 relay
amendment): `X-Forwarded-For` trust stays deploy-time (ARD-021). A `relayIp` another registry row
already has is refused (409) before any change. `relayIp: null` clears it, and `relay` is then
`{ip: null, operatorStep}` naming both inventory entries to remove. The audit row's
`requested.relayIp` is present only when the call sent it, so a clear is told from an omission.
The box's own private IP and the browser edge are not API settings: preflight alone refuses those.

**On screen.** The admin UI's Add client page (`/configuration/clients/new`, Configuration → Add
Client) makes this call for an admin: client id, 1-10 redirect URIs, and optionally the relay IP
and the SIP block size, first extension and context (roles are never sent, and the context only
when the admin picks one, so a repeat keeps both; an empty relay IP is not sent either). It checks the request model's rules
before sending; `https` outside dev and the SIP block cap stay the API's to refuse, and any refusal
shows as `<status>: <detail>`. The returned secrets are shown once, each with a copy button, and
are kept only in the page's memory: never in browser storage, the URL or a log, and gone on Done or
navigation. While the call is pending, and while its secrets are on screen until Done, the page
blocks in-app navigation and asks before a reload or close: the response is the only copy of the
secrets. A 502 shows as "partly added, repeat to resume". A `null` secret shows as not returned
(it existed before this call, perhaps never shown after a 502), with how to rotate it. A stored relay IP shows with the response's `relay.operatorStep`, the
converge that makes Authentik trust it. A non-admin sees no form and no sidebar link.

**From an AI agent (MCP).** `tools/directory-mcp/server.py` is a stdio MCP server with one tool,
`onboard_client`, which makes this same call with the same arguments and returns its response as
the tool result. It is a client of the API, not a second write path: it authenticates with an
admin's bearer token that the operator puts in its environment (`DIRECTORY_API_URL`,
`DIRECTORY_ADMIN_TOKEN`) or that the caller passes per call (`adminToken`, header only), so every
guard above still applies to it. It never mints, refreshes or stores a credential, and there is no
long-lived or admin-scoped service credential for it. An admin access token lasts 15 minutes (§04),
so a 401 comes back as "the admin token has expired, supply a fresh one". It rejects arguments the request model would reject before it sends anything, except
`http` redirect URIs and the `SIP_RANGE_MAX_SIZE` cap, which only the API can judge. It sends only
the optional arguments it was given. Every API error (401/403/409/422/429/502/503) comes back as a
tool error, `HTTP <status>: <detail>`. It does not follow redirects, and it logs neither the token
nor the response, whose secrets go only to the caller. It strips whitespace around the token and
refuses one outside the RFC 6750 bearer characters with a fixed message. Transport failures are
fixed messages too, never the error's text, which can quote the `Authorization` header. Registration with an MCP client:
`tools/directory-mcp/README.md`.
The same call made by an AI agent, with what it must do on each refusal, is specified as an E2E
run in [scenarios/agent-onboard-client.md](../scenarios/agent-onboard-client.md).

The building's users are then created by the principal under `ou=<c>,ou=people` (owned). Existing
people stay where they are and are only added to the building's groups (adopted).

Two consequences of containment for whoever places users and groups:

- **A person in two buildings must be adopted, never owned.** They live in `ou=people` and are
  members of both buildings' groups. An owned user who holds any group, RBAC permission or Authentik
  admin seat outside that building's `<c>-<role>` groups is not contained, and the building gets 403
  on every identity write (`PATCH`, `reset_password`, `suspend`, `unsuspend`) for them. The
  containment rule does not apply to adopted users: a building may add or remove any existing user
  in its own groups, whatever else they hold, but never writes an adopted user's identity (404).
- **Do not create groups under the org's own `ou=<c>,ou=groups`.** Only the top-level
  `cn=<c>-<role>,ou=groups,<base>` is in scope, so membership in any group below the org OU makes
  that building's owned users non-contained (403).

**A building's phones (ARD-020).** The onboard call does steps 1–3; they remain the way to change
one later.

1. An admin assigns the building's org a profile with an enabled SIP service
   (`POST /api/config-templates/{id}/assign {org_dn: "ou=<c>,ou=org,<base>"}`). Its SIP counter range
   is the building's extension namespace, disjoint from every other profile's (ARD-020, 2026-10-21).
2. An `org_management` holder sets the org default context:
   `POST /api/org/sip_context {dn: "ou=<c>,ou=org,<base>", sipContext: "default" | "all"}`
   (`null` clears it). Without one, users fall back to `default`.
3. A `system_configuration` holder provisions the PBX identity:
   `POST /api/settings/ldap/clients/provisioned {client_id: "<c>", kind: "pbx"}` → `bind_dn`
   `cn=<c>,ou=pbx,ou=clients,<base>` and a secret shown once. `rotate` and `DELETE` work by the same
   `client_id`; registry rows list a `kind` (`ldap` or `pbx`). 422 when `<c>` is not a registered
   first-party client or its org is missing; 409 when the id is already used, by a PBX or a generic
   client (they share the registry's id namespace, never a DN). The UED box is configured as in §3.
4. The principal enables each resident: `PUT /api/users/{uid}/sip {password?, extension?, context?}`
   → `{ok, uid, enabledNow, extension, context, sipPassword?}` (§05 §5.4). A SafeNest migration
   passes the resident's existing `extension` and `password` (12+ characters), so phones keep both.
   The same call with the same extension is safe to retry; a different one is 409.
5. Group-level context, if any: `PATCH /api/groups/{cn} {sipContext}` on the building's role groups
   (the only field the principal may send there). A role group's context reaches only owned users.

Reads gain the levels: `GET /api/groups/{cn}` returns `sipContext`, `GET /api/orgs/detail` returns
`ucConfig.sipContext` (the value set on that entry, not resolved). Users of the device payload note
that `sipUsername` is now the extension (§05 §5.5).

---

## 5. OIDC Discovery `[AS-BUILT]`

### Discovery Flow

1. If `OIDC_DISCOVERY_URL` is set, fetch that URL directly
2. Otherwise, construct from `OIDC_ISSUER`: `{issuer}/.well-known/openid-configuration`
3. Extract `jwks_uri` from discovery response
4. Create `PyJWKClient` with the JWKS URI

### Caching

- Discovery response and `PyJWKClient` are cached in a module-level `_Cache` dataclass
- **TTL: 600 seconds** (10 minutes) -- after expiry, discovery is re-fetched
- Cache key: timestamp-based (`_CACHE.fetched_at`)

### Token Verification (`verify_bearer_token`)

1. Fetch signing key from JWKS via `jwk_client.get_signing_key_from_jwt(token)`
2. Decode with `jwt.decode()` verifying:
   - **Signature** -- algorithms: RS256, RS384, RS512, ES256, ES384, ES512
   - **Audience** -- `OIDC_ACCEPTED_AUDIENCES` (default: `["azblink-directory"]` from `OIDC_AUDIENCE`)
   - **Issuer** -- multi-issuer list from `OIDC_ACCEPTED_ISSUERS`
3. Return decoded claims dict

### Multi-Issuer Support

Authentik stamps the `iss` claim based on the URL used to access it (Docker-internal vs Cloudflare tunnel produce different values). To handle this:

- `OIDC_ACCEPTED_ISSUERS` is a comma-separated env var listing all valid issuer URLs
- `config.py` expands each entry to both with and without trailing slash (Authentik includes trailing slash in JWT `iss`)
- PyJWT's `issuer=` parameter accepts a list, matching against any entry
- `OIDC_ISSUER` is used only for JWKS/discovery fetching (Docker-internal URL, reliable)

**Source:** `src/backend/oidc_verify.py`, `src/backend/config.py`

### Account-Lock Mirror Re-Sync (ARD-012) `[AS-BUILT]`

A lifespan-managed background task keeps a Redis mirror of active account locks so
that lock enforcement survives a PostgreSQL outage. Registered in `main.py`'s
lifespan alongside the activity-bus listener, the LDAP activity collector and the
service-health probe.

| Property | Value |
|---|---|
| Task | `account_lock_mirror.run_resync_loop(ORGDB)` |
| Interval | 60 s (`RESYNC_INTERVAL_SECONDS`) |
| Source of truth | `OrgDB.list_active_locks()` — PostgreSQL |
| Mirror keys | `azblink:account_lock:<uid>`, TTL = remaining lock duration |
| Completeness sentinel | `azblink:account_lock_mirror:synced`, TTL = 120 s (2 × interval) |
| Redis client | the shared `deps.ip_block_redis` (per ARD-011 — no second connection) |

The sentinel is what makes the mirror safe to read: a positive-only cache may be
treated as authoritative only while every lock is known to have reached it.
`check_account_locked` reads through to the mirror when PostgreSQL raises, and
denies with `503` when the sentinel is absent rather than reading a miss as
"not locked".

The sentinel carries a TTL rather than being set once at startup because
`lock_account()` has no production caller today — ARD-009/H4 removed the auto-lock
path and no admin lock endpoint replaced it, so rows enter `account_locks`
out-of-band where dual-write cannot observe them. A TTL bounds staleness to one
re-sync interval; if the task dies, the sentinel lapses and the lock check fails
closed. Recorded as an amendment on ARD-012.

**Source:** `src/backend/account_lock_mirror.py`, `src/backend/main.py`,
`src/backend/auth.py`, `src/backend/db/security.py`

### Audit Retention Purge `[AS-BUILT]`

A lifespan-managed task enforces Settings > Audit > `retentionPolicy`, which until
1.21.0 was stored but never applied.

| Property | Value |
|---|---|
| Task | `db.retention.run_retention_loop(ORGDB, settings_db)` |
| Interval | 3600 s (`PURGE_INTERVAL_SECONDS`); first pass at startup |
| Policy | `"90"` or `"365"`: delete rows older than that many days. `"forever"`, or any value that is not a positive whole number: delete nothing |
| Tables | `termination_events`, `auth_failure_audit`, `user_lifecycle_audit`, `admin_action_audit`, `provisioning_audit` (by `timestamp`); `suspension_events` (by `created_at`) |
| Self-audit | A pass that deletes rows records `purge_audit` (actor `system`, `resource_id` `retention:<days>d`, detail = cutoff and per-table counts) |
| Workers | Every uvicorn worker runs the loop. The DELETE is idempotent, so a second worker's pass finds nothing and records nothing |

A failed pass is logged and retried at the next interval; it never stops the app.

**Source:** `src/backend/db/retention.py`, `src/backend/db/audit.py` (`purge_audit_before`),
`src/backend/main.py`

## 6. LDAP Client Inventory `[AS-BUILT]`

Detects and classifies clients that bind **directly** to the platform OpenLDAP (UED/XMPP, Asterisk, the Directory API itself), surfaced as a dedicated operator page at `/configuration/ldap-clients` (search, status/service filters, column sort, inline labelling, bulk acknowledge/block, CSV export).

### Capture

- OpenLDAP `olcLogFile` (bootstrap ldif `deploy/dev/ldap/logfile-config.ldif`) mirrors slapd stats output (`-d 256`) to `/var/lib/ldap/slapd-stats.log` on the `azblink_ldap_data` volume.
- The Directory API mounts that volume read-only; `ldap_activity.py` runs a lifespan-managed asyncio collector that tails the file, correlates `conn=N` (`ACCEPT` → `BIND` → `closed`) into `(bind_dn, source_ip)` sessions, and upserts them.
- Sessions are recorded at **bind completion** (not close) so long-lived connections appear immediately. Admin-set `status`/`label`/`acknowledged_*` are preserved across re-observation.

### Classification (`classify()`)

Ordered rules → `service`: `healthcheck` (localhost + `cn=admin`) · operator CIDR overrides (`LDAP_KNOWN_SERVICE_CIDRS`) · `api` (bind DN == `LDAP_BIND_DN`, off-localhost) · `provisioned_client` (bind DN under `ou=clients` — see Client Provisioning below) · `xmpp` (`uid=` bind) · else `unknown` (the flag target).

### Endpoints (admin-only, `require_permission("system_configuration")`)

- `GET /api/settings/ldap/clients` — inventory + counts + `connected_now` (best-effort; never 500)
- `PATCH /api/settings/ldap/clients/{id}` — acknowledge / block / label
- `DELETE /api/settings/ldap/clients/{id}` — forget a stale row

**Source:** `src/backend/ldap_activity.py`, `src/backend/db/ldap_inventory.py` + `db/tables.py` (`ldap_clients`), `src/backend/routers/settings.py`, `migrations/028_ldap_clients.sql`, `deploy/dev/ldap/logfile-config.ldif`

### Client Provisioning `[AS-BUILT]`

> **Decision record:** [ARD-006 — LDAP Client Provisioning & Reconciliation](../decisions/ARD-006-ldap-client-provisioning-reconciliation.md) (covers both the inventory above and provisioning here).

The platform can hand out dedicated per-client LDAP credentials so every external client binds with its own identity that the inventory recognises as known (rather than being NAT-masked / bind-DN-collapsed into the API's own `cn=admin` row). Provisioning records intent; the passive detector above reconciles on first bind.

- **Subtree:** clients live under `ou=clients,dc=azblink,dc=com` (config `LDAP_CLIENTS_OU`). Each is `cn=<client_id>,ou=clients,…` (`organizationalRole` + `simpleSecurityObject`, holding an SSHA `userPassword`); a PBX (`kind: "pbx"`, ARD-020) is `cn=<client_id>,ou=pbx,ou=clients,…`, only for a registered first-party client whose org exists. `client_id` is a constrained slug (`^[a-z0-9][a-z0-9-]{1,30}$`). The OU is created idempotently at startup by `ensure_clients_ou()` (bound as `cn=admin`, the data plane).
- **Static ACL:** a single bootstrap ldif (`deploy/dev/ldap/ldap-clients-acl.ldif`) grants read-minus-secrets to `dn.children="ou=clients,…"` (`olcAccess` rule `{4}`). Secret attrs stay hidden from provisioned clients: login/bind secrets (`userPassword`, `shadowLastChange`) by rule `{1}`, and UC secrets (`azbXmppBindPassword` plaintext XMPP, `AstAuthPassword` SIP digest, `AstAuthMd5Cred` SIP MD5) by rule `{3}` — both ordered before the `ou=clients` read grant so a client never reaches them. Rule `{2}` is the one exception: a PBX reads `AstAuthPassword` of its own client's active owned users (§07 PBX Read Access); every other bind breaks through it to `{3}`. It ships as a top-level bootstrap ldif applied by osixia via EXTERNAL at init because the app's `cn=admin` data bind cannot write `cn=config`. No per-client `cn=config` edits.
- **Registry:** `ldap_provisioned_clients` (`migrations/029`) stores only intent — `client_id`, `bind_dn`, `label`, `created_by`, timestamps, `revoked_at`. **No secret column;** the SSHA hash lives only in LDAP. Secrets are strong-generated (or operator-supplied + strength-validated), shown once, never persisted.
- **Endpoints** (admin-only, `require_permission("system_configuration")`): `POST /api/settings/ldap/clients/provisioned` (create → secret once), `GET …/provisioned` (registry joined with observed rows), `POST …/provisioned/{client_id}/rotate` (→ new secret), `DELETE …/provisioned/{client_id}` (revoke). CLI parity via `directoryctl ldap-client provision|list|rotate|revoke` (thin API client over the same endpoints).
- **Reconciliation:** `classify()` gains an ordered rule before the `uid=` fallback — a bind DN under `ou=clients` → service `provisioned_client`; `upsert_ldap_session` inserts such rows with `status="acknowledged"` (auto-acknowledged). Non-provisioned binds stay `unknown`.

**Source:** `src/backend/ldap_provisioning.py`, `src/backend/ldap_activity.py` (`classify`), `src/backend/db/ldap_inventory.py` + `db/tables.py` (`ldap_provisioned_clients`), `src/backend/routers/settings.py`, `src/cli/directoryctl.py`, `migrations/029_ldap_provisioned_clients.sql`, `deploy/dev/ldap/ldap-clients-acl.ldif`
