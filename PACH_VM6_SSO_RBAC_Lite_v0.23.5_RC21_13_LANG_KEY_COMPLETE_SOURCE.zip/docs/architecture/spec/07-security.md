<!-- spec-meta: { section: "07", version: "1.41.0", last_updated: "2026-10-22" } -->

# 07 — Security

## 1. Rate Limiting `[AS-BUILT]`

Rate limiting is Redis-backed via **slowapi** using a **fixed-window** strategy. The `limiter` instance is created with `storage_uri=REDIS_URL` and a default limit of `100/minute` applied to all endpoints.

**Client IP extraction:** `get_client_ip()` (`resolve_client_ip`, H5) reads `X-Forwarded-For` only when the socket peer is in `TRUSTED_PROXIES`, and then returns the rightmost entry that is not itself a trusted proxy; otherwise it is the socket peer. Every per-IP limit below and the IP auto-block (§3) key on it. In production (`docker-compose.tls.yml`) Traefik reaches the API over the edge network (§06 Transport), and the API trusts exactly the edge `.3` and Traefik `.4`: each browser (by `CF-Connecting-IP`) and each relay (Traefik's `websecure` trusts no forwarded header) is its own source. Unset (dev, CI) = the socket peer, Traefik, for everyone.

### Rate Constants

| Constant | Endpoint Pattern | Limit |
|----------|------------------|-------|
| `LIMIT_BOOTSTRAP` | `POST /api/bootstrap` | 5/hour |
| `LIMIT_USER_CREATE` | `POST /api/users/create`, `POST /api/users/{uid}/terminate` | 20/minute |
| `LIMIT_DEVICE_PROVISION` | `POST /api/provisioning/create`, `POST /api/provisioning/consume` | 5/minute |
| `LIMIT_SCOPED_WRITE` | The nine writes a client-scoped principal may make (§3: ARD-019's seven, `PUT /api/users/{uid}/sip` and `PATCH /api/groups/{cn}`), one bucket per verified `azp`; unscoped callers are exempt and keep the per-IP limits (ARD-019 §6, ARD-020 §2) | 600/minute |
| *(inline decorator)* | `GET /api/compliance` (`?refresh=1` bypasses the 60s cache) | 30/minute |
| `LIMIT_DEFAULT` | All other endpoints | 100/minute |

**Custom 429 handler:** `rate_limit_exceeded_handler` returns a JSON body with `{"ok": false, "error": "rate_limit_exceeded", "detail": "..."}` and a `Retry-After: 60` header.

**Source:** `src/backend/rate_limit.py`

---

## 2. Device Provisioning Security `[AS-BUILT]`

Device provisioning uses token-based authorization with SHA-256 hashed tokens stored in `device_provisions`. QR code HMAC signing (`qr_signing.py`) was removed in ARD-004.

### Token Security

- Tokens are generated via `secrets.token_urlsafe(32)` and stored as SHA-256 hashes
- Token lifecycle is tracked: `active` -> `consumed` or `active` -> `revoked_terminated`
- TTL enforcement: `DEVICE_PROVISION_TTL_SEC` (default 30 days), extension capped at `DEVICE_PROVISION_MAX_EXTEND_SEC` (default 86400s)
- Device cap per user: `max_devices_per_user` on profile (default 5)

---

## 3. Authorization Model `[AS-BUILT]`

Authentication is Authentik OIDC exclusively. Three dependency functions gate access:

### `require_user()`

Any valid OIDC Bearer token. Extracts token from `Authorization` header, verifies via `verify_bearer_token()`. On failure, records an `auth_failure_audit` entry and returns HTTP 401. 20 failures from one client IP in 15 minutes block that IP for 1 hour (`blocked_ips`). A token that fails only on expiry passed signature verification, so the IdP minted it (a tab waking with a stale token): it is recorded as `expired_token` and never counts toward the block.

### `require_admin()`

Depends on `require_user()`. Checks the OIDC `groups` claim (claim name configurable via `OIDC_GROUPS_CLAIM`, default `"groups"`) for membership in `OIDC_ADMIN_GROUP` (default `"IT-Admins"`). Returns HTTP 403 if not present.

### `require_directory_read()` (ARD-009)

Authorizes **directory reads** — both sensitive per-target reads and aggregate
directory *browse*. Admits a caller holding **any** management permission in
`_MANAGEMENT_PERMISSIONS` (`user_management`, `org_management`,
`device_provisioning`, `audit_log_access`, `system_configuration`) **or**
membership in `OIDC_ADMIN_GROUP`; otherwise HTTP 403 `"Directory read requires
an operator role"`. **Fail-closed:** an RBAC-lookup error does not grant access.

Gated reads:

- **Per-target (ARD-009 original):** `GET /api/users/{uid}/devices`, `/stats`,
  `GET /api/orgprofiles`, `GET /api/orgprofiles/{profile_id}`.
- **Aggregate browse (ARD-009 amendment, 2026-07-08 — address-book visibility
  resolved to operator-only):** `GET /api/users`, `/api/users/search`,
  `/api/users/{uid}`, `/api/users/{uid}/groups`, `/api/org/tree`,
  `/api/org/users`, `/api/orgs/tree`, `/api/orgs/detail`, `/api/orgs/users`,
  `/api/groups`, `/api/groups/{cn}`, `/api/groups/{cn}/members`.

Self-service endpoints (`/api/me*`, `/api/provision/device*`) and config
metadata (`/api/tenant`) stay on `require_user()` — scoped to the caller, not a
directory-wide enumeration. Regression-guarded by
`tests/test_rbac.py::TestC1DirectoryReadAuthz`.

### `require_permission(permission)`

Fine-grained RBAC. Checks in order:
1. Look up user permissions from group RBAC via `ORGDB.get_user_permissions(uid)` -- if the requested permission is present, allow
2. Fall back to admin group membership check (admins can do everything)
3. Deny with HTTP 403 if neither check passes

Permissions are stored locally: `group_profiles.permissions` (JSON) joined through `group_member_roles` rows keyed on `preferred_username`. Any row confers the group's whole permission set — the row's `role` (`owner`/`admin`/`member`) is not consulted. Only admin status comes from the OIDC `groups` claim.

### Grant Containment `[AS-BUILT]` (ARD-017)

`assert_can_confer(claims, perms)` guards every write that confers RBAC
permissions: `PATCH /api/groups/{cn}/permissions` (newly added permissions
only), `POST /api/groups/{cn}/members` and `PATCH /api/groups/{cn}/members/{uid}/role`
(the group's permissions). A caller outside `OIDC_ADMIN_GROUP` may confer only
permissions it already holds, else HTTP 403 `"Cannot grant permissions you do
not hold: …"`. It fails **closed** (503) if the RBAC store is unreachable.
Removing permissions is always allowed. Pinned by
`tests/test_rbac.py::TestRBACNoEscalation`.

**Takeover containment** (review finding 5). A password reset, an unsuspend
(which sets a new password) and a mail change hand the caller the target's
account, so they are a grant of everything that account holds.
`assert_can_take_over(claims, uid)` runs on the unscoped path of
`POST /api/users/{uid}/reset_password`, `POST /api/users/{uid}/unsuspend` and
`PATCH /api/users/{uid}`. A caller outside `OIDC_ADMIN_GROUP` gets HTTP 403 when
the target is in `OIDC_ADMIN_GROUP` (Authentik) or holds an RBAC permission the
caller does not. It fails **closed** (503) when the RBAC store or the Authentik
Admin API cannot answer. It checks the uid LDAP found, not the path spelling:
LDAP matches uid without regard to case or spaces, while RBAC rows and Authentik
compare exactly, so `IT-BOSS` would otherwise pass for `it-boss`. Every user
write route and group member add/remove act on that canonical uid. A scoped
principal keeps ARD-019's own containment
(`_client_scope.write_target`). Pinned by
`tests/test_rbac.py::TestRBACNoEscalation::test_user_manager_cannot_take_over_a_stronger_account`
and `tests/unit/test_takeover_containment.py`.

### Service Principals (API-to-API) `[AS-BUILT]` (ARD-017)

A backend service calls this API with an Authentik `client_credentials` token
from its own confidential provider (§08 API-to-API Integration). Its RBAC grants
are static, from `OIDC_SERVICE_PERMISSIONS="client_id:perm|perm,…"`, applied by
`require_permission`, `require_directory_read` and `assert_can_confer` only when
`azp == client_id` **and** `preferred_username == "ak-<client_id>-client_credentials"`
(Authentik's generated account). Grants need no store, so service callers are
unaffected by a PostgreSQL outage. The `ak-` uid prefix is reserved at user
create (422). Pinned by `tests/test_rbac.py::TestServiceClientRBAC`.

No token for anyone else comes from a service client (audit B2). Authentik's
`client_credentials` grant also takes a username and app password, and minted a
token as that person. The seed binds an access policy on each service application
that admits only `ak-<client_id>-client_credentials`, so that grant answers
`invalid_grant`; the dev/CI-only `azblink-directory-test` client is exempt (§06).
The application's `policy_engine_mode` is `all`, so a binding added to it later
cannot outvote the check.
The API refuses such a token anyway: `_claims_from_auth_header` answers 401, and
`verify_ws_token` refuses it, when `azp` is a client listed in
`OIDC_SERVICE_PERMISSIONS` or `OIDC_SERVICE_CLIENT_SCOPES` and
`preferred_username` is not that client's generated account.

### Client-Scoped Service Principals `[AS-BUILT]` (ARD-019)

A third grant kind beside the admin group and RBAC permissions. A service
client listed in `OIDC_SERVICE_CLIENT_SCOPES="svc:first_party_client:role|role,…"`
(for SafeNest `safenest-b2-directory:safenest-b2:admin|staff|resident|visitor`)
is bound to one first-party client `<c>` and holds no RBAC permission. The
identity check is ARD-017's: `azp` and `ak-<azp>-client_credentials` must both
match. Startup refuses an unregistered `<c>`, a principal that also has a
non-empty `OIDC_SERVICE_PERMISSIONS` entry, an entry without roles, and nested
first-party ids (`safenest` beside `safenest-a1`).

A principal can also be bound at runtime by `POST /api/clients/onboard` (ARD-022,
`OIDC_ADMIN_GROUP` only), which writes the registry table `first_party_clients`. The
onboard call applies the same refusals (409), and refuses a client whose
`ou=<c>,ou=people` already holds users, since they would become owned. Every check
in this section reads env plus registry from an in-process snapshot (10 s reload,
last snapshot kept while PostgreSQL is down); an env entry wins over a row. The
onboarded service client's Authentik application admits only
`ak-<c>-directory-client_credentials`, so a person's app password gets `invalid_grant`.
The onboard call refuses env clients and never converges an Authentik provider or application
it did not create (409: only a client with a registry row is converged), refuses `<c>-*` groups
carrying RBAC permissions (invariant 1 below, 409), returns each secret only from the call that
creates it, writes an `onboard_client` audit row before any change or changes nothing, accepts
only exact `https` redirect URIs outside dev, and is limited to 10 calls a minute (ARD-022 §5
and its 2026-10-22 amendment).

Every guard in this section answers the principal 403: `_claims_from_auth_header`
refuses it unless the route's dependency is `require_scope_or_permission` or
`require_scope_or_directory_read`, which only the eleven routes below use
(ARD-019's nine and ARD-020's two). The target checks live in
`src/backend/routers/_client_scope.py`.

| Term | Rule |
|---|---|
| In-scope group | exactly `cn=<c>-<role>,ou=groups,<base>` for a configured role (case matters; a same-named group under an org OU is not in scope) |
| Owned user | exactly `uid=<uid>,ou=<c>,ou=people,<base>` |
| Contained | owned, every LDAP group in scope, no RBAC permission, not in Authentik's `OIDC_ADMIN_GROUP` |
| Adopted | a member of an in-scope group who is not owned |

| Call | Admitted when | Refusal |
|---|---|---|
| `GET /api/users/{uid}` | owned (full user) or adopted (`uid`, `dn`, `displayName`, `accountStatus`) | 404 |
| `GET /api/users/{uid}/groups` | owned or adopted; in-scope groups only | 404 |
| `POST /api/users/create` | `orgDn` is `ou=<c>,ou=org,<base>`; body only `uid`, `displayName`, `mail`, `mobile`, `orgDn`, `password` | 403 other org, 422 other fields, 409 uid or mail taken |
| `PATCH /api/users/{uid}`, `reset_password`, `suspend`, `unsuspend` | owned and contained | 404 not owned, 403 not contained, 409 mail taken / unsuspend of a terminated user |
| `POST /api/groups/{cn}/members` | `cn` in scope; any existing user under `ou=people` | 404 group, 403 group nested in another group |
| `DELETE /api/groups/{cn}/members/{uid}` | `cn` in scope | as above |
| `PUT /api/users/{uid}/sip` (ARD-020) | owned and contained; the profile is the one assigned to `ou=<c>,ou=org` | 404 not owned, 403 not contained or user carries another profile, 409 user suspended or terminated / no SIP profile on the org / extension taken, outside the range or changed after enable, 422 password under 12 characters |
| `PATCH /api/groups/{cn}` (ARD-020) | `cn` in scope, even when nested in another group; body only `sipContext` | 404 group, 422 other fields |

The scoped principal cannot set the org level of the SIP context (`POST /api/org/sip_context`
is `org_management` only, 403), nor provision a PBX client.

A 404 carries the same body as a missing target. The containment check reads
PostgreSQL and the Authentik Admin API; if either cannot answer, the write is
refused with 503. Pinned by `tests/test_client_scope.py` and
`tests/unit/test_client_scope_unit.py`.

**Invariants for every caller (ARD-019 §4):** `PATCH /api/groups/{cn}/permissions`
with a non-empty list on a `<client>-*` group answers 422 (startup logs CRITICAL
for any such group written earlier); user uids starting with a registered
`<client>-` are reserved (422); a uid already used elsewhere under `ou=people`
answers 409 (and the LDAP `unique` overlay rejects it); membership writes answer
200 `changed: false` when nothing changed; org create or rename to a registered
client id needs `OIDC_ADMIN_GROUP` (422). Suspend revokes the user's Authentik
sessions, access tokens and refresh tokens, best-effort (ARD-019 §7).

### PBX Read Access `[AS-BUILT]` (ARD-020 §4)

A first-party client's PBX binds as `cn=<c>,ou=pbx,ou=clients,<base>` (provisioned with
`kind: "pbx"`, §08 §6) and must read the SIP secret of that client's phones. One static rule,
placed before the UC-secret rule, grants it:

```text
olcAccess: {2}to dn.regex="^uid=[^,]+,ou=([^,]+),ou=people,dc=azblink,dc=com$"
   filter=(!(|(description=SUSPENDED)(description=TERMINATED)))
   attrs=AstAuthPassword
   by dn.exact,expand="cn=$1,ou=pbx,ou=clients,dc=azblink,dc=com" read
   by * break
```

- **Reach:** `AstAuthPassword` of entries exactly `uid=<uid>,ou=<c>,ou=people` (owned users),
  and only for the PBX whose `cn` equals that `<c>`: `expand` binds `$1` to the entry's own org.
  Another client's PBX, a generic provisioned client, a normal user and an adopted user's entry
  get nothing from it.
- **Widens nothing else:** every other bind reaches `by * break` and falls through to rule `{3}`
  (`azbXmppBindPassword`, `AstAuthPassword`, `AstAuthMd5Cred`: self read, `cn=admin` write,
  `* none`), exactly as before. The PBX reads the non-secret attributes through rule `{4}`
  (read for `dn.children` of `ou=clients`).
- **Suspend and terminate:** the filter keys on `description`, so the secret is hidden while a
  user is `SUSPENDED` or `TERMINATED`; unsuspend restores it without a new secret. Unsuspend
  refuses a terminated user with 409, so `TERMINATED` is never cleared and stays hidden. A ppolicy
  lockout (`pwdAccountLockedTime`) does not hide it. On UED the change applies in about 1 s; an
  existing registration lasts until the phone's registration expiry.
- **Plaintext, option B:** UED answered `md5` auth with 500, so `AstAuthType` stays `userpass`
  and the PBX reads `AstAuthPassword` (ARD-020 amendment 1). `AstAuthMd5Cred` is not written.
  UED has no TLS field: the box-to-LDAP path must be private. Production publishes LDAP only as
  LDAPS (ARD-021), so UED needs a private tunnel to loopback, or the `azblink_allow_plaintext_ldap`
  exception firewalled to the PBX's /32.
- Pinned by `tests/test_client_scope.py` (`test_20_05_*`). End to end, with a PBX that reads
  PJSIP from LDAP as its PBX identity (register, a call, suspend and unsuspend, another org's
  user): `tests/test_relay_path.py` against the relay-path simulator (§06 Transport).

### Public Endpoints (No Auth)

| Endpoint | Purpose |
|----------|---------|
| `GET /api/health` | Liveness check |
| `GET /api/health/deep` | Deep health (LDAP + PostgreSQL + Redis connectivity) |
| `POST /api/provisioning/consume` | Token consumption (device-facing) |

### Dev/Test Bypass

When `DEV_AUTH_TOKEN` is set, a Bearer token matching that value bypasses OIDC verification and returns synthetic admin claims (`sub: "dev-admin"`, groups include `OIDC_ADMIN_GROUP`). Never set in production.

**Source:** `src/backend/main.py` (lines 175--249)

---

## 4. Audit Trail `[AS-BUILT]`

All audit tables are append-only -- records are inserted but never updated or deleted.

### Audit Tables

| Table | Events Tracked | Key Fields |
|-------|---------------|------------|
| `user_lifecycle_audit` | User create, suspend, unsuspend, terminate | `user_uid`, `action`, `performed_by`, `detail`, `timestamp` |
| `termination_events` | Detailed termination records with revocation counts | `user_uid`, `user_dn`, `org_dn`, `terminated_by`, `reason`, `actions_taken` (JSON), `tokens_revoked`, `authentik_sessions_revoked` |
| `device_provisions` | Token lifecycle: issuance, consumption, revocation, expiry | `token_hash`, `uid`, `profile_id`, `status`, `consumed_by_device_id`, `consumed_from_ip`, `client_platform` |
| `auth_failure_audit` | Failed authentication attempts | `username`, `failure_reason`, `client_ip`, `user_agent`, `endpoint` |
| `admin_action_audit` | Admin CRUD (incl. `set_sip`, `set_org_sip_context`, `provision_ldap_client` with its `kind`); a client-scoped principal's writes (`scoped_create_user`, `scoped_update_user`, `scoped_reset_password`, `scoped_suspend`, `scoped_unsuspend`, `scoped_member_add`, `scoped_adopt`, `scoped_member_remove`, `scoped_set_sip`, `scoped_set_group_sip_context`) and every target refusal (`scoped_denied`) | `actor`, `action`, `resource_type`, `resource_id`, `detail` (JSON: `client`, `target` owned/adopted, field names, refusal `route` and `reason`; SIP rows: `fields`, `enabledNow`, `extension`, `context`, never the password) |

### Recording Methods

| Method | Table | Called From |
|--------|-------|-------------|
| `record_lifecycle_event()` | `user_lifecycle_audit` | User create/suspend/unsuspend/terminate |
| `record_termination()` | `termination_events` | User termination endpoint |
| `record_auth_failure()` | `auth_failure_audit` | OIDC token verification failure |

### Actor Tracking

All audit records capture the acting administrator:
- `issued_by` / `performed_by` / `terminated_by` -- extracted from OIDC claims of the authenticated admin
- A client-scoped principal is recorded as `ak-<azp>-client_credentials`, never its hashed `sub` (ARD-019); no password value reaches an audit row
- `client_ip` / `user_agent` -- captured from request headers where applicable

**Source:** `src/backend/orgdb.py`

---

## 5. Security Boundaries

### Implemented `[AS-BUILT]`

- **Rate limiting:** Redis-backed fixed-window on all endpoints with per-category limits
- **Device provisioning tokens:** SHA-256 hashed, TTL-enforced, device cap per user
- **Audit logging:** Append-only tables for user lifecycle, terminations, auth failures
- **OIDC authentication:** Authentik-only with multi-issuer support, JWKS signature verification
- **LDAP bind auth (Plane A):** XMPP/SIP authenticate via LDAP bind -- no IdP dependency
- **Session/token revocation:** Authentik Admin API v3 deletes sessions, access tokens and refresh tokens on termination and on suspend (ARD-019 §7)
- **Transport (ARD-021):** production carries no plaintext credential off the box. Browsers use one public HTTPS host through a Cloudflare tunnel (nothing listens publicly). Relays use the same name over TLS on a routed private path: Authentik `:443`, API `:8443`, LDAPS `:636`, one certificate whose CA relays pin. Plaintext Traefik, Authentik and LDAP bind loopback. `preflight.yml` refuses any other production shape. The only opt-in exception is plaintext LDAP for a PBX without TLS (§3 PBX Read Access), which must be firewalled to its /32. Only single hosts may set `X-Forwarded-For` at Authentik: each relay box's static IP (`authentik_relay_ips`, one per first-party client) and loopback; preflight refuses a missing, shared, non-canonical or wider entry, judged per address family (IPv4 `/32`, IPv6 `/128`; ARD-021 amendment 2026-10-22). On the browser path each hop trusts one fixed peer, so a browser's source is the `CF-Connecting-IP` that cloudflared delivers and nothing a client sends (§06 Transport, browser source)

### Deferred `[TARGET v2.0]`

| Area | Gap | Reference |
|------|-----|-----------|
| LDAP federation hardening | 30% gap -- custom schema, status tracking in LDAP | V1_TO_V2_GAP_ANALYSIS.md S1 |
| Auth failure soft-lock | Spec requires 5/5min + account soft-lock, only recording implemented | V1_TO_V2_GAP_ANALYSIS.md S1.3 |
| Encrypted audit storage | Audit records stored in plaintext PostgreSQL | v2.0 spec |
| RBAC beyond admin/user | `require_permission()` exists but group-permission mapping is minimal | v2.0 spec |
| Advanced compliance controls | 50% gap -- retention policies, export, regulatory tagging | V1_TO_V2_GAP_ANALYSIS.md |
