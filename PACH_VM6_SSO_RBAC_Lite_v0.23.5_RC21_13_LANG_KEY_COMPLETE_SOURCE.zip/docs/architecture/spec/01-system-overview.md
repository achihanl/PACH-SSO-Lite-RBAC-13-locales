<!-- spec-meta: { section: "01", version: "1.0.0", last_updated: "2026-03-07" } -->

# 01 — System Overview

> `[AS-BUILT]` This section describes the system as currently implemented.

## 1. Mission

AZBlink Directory is an LDAP-backed identity directory with QR-based provisioning and optional Authentik SSO integration. It enables IT administrators to manage users, organizations, groups, and provisioning profiles through a web-based admin UI, while end users receive fully configured UC (Unified Communications) credentials -- XMPP and SIP -- via a single QR code scan. The platform is designed so that UC services remain operational regardless of whether Authentik SSO is installed or running, ensuring zero-downtime communications even when the identity provider is unavailable.

## 2. Product Scope

**The platform does:**

- User lifecycle management (create, update, suspend, unsuspend, terminate) with LDAP as the directory backend
- Organization tree management (hierarchical OUs in LDAP, mirrored to PostgreSQL profiles)
- Group management with RBAC-style member roles and permissions
- Provisioning profiles (config templates) that define UC service parameters, QR settings, and SSO policy per organization
- UC provisioning: atomic LDAP writes of XMPP and SIP attributes (posixAccount + AsteriskPjsip*) at user creation time
- QR code generation with HMAC-SHA256 signed payloads containing UC credentials and service endpoints
- One-time token enforcement to prevent credential sharing
- Shareable QR preview links with expiry and access counting
- Comprehensive audit trail (QR issuance, user lifecycle, terminations, auth failures)
- Rate limiting (Redis-backed) for abuse prevention
- CSV bulk user import
- SSO integration via Authentik OIDC (optional, graceful degradation)

**The platform does NOT:**

- Act as an Identity Provider -- Authentik is the external IdP; the platform is an IdP consumer
- Run UC servers -- XMPP (Prosody/ejabberd) and SIP (Asterisk/Kamailio) are external services that bind against LDAP
- Serve as an end-user application -- the web UI is for IT administrators only; end users interact via QR codes and UC client apps
- Manage DNS, certificates, or network infrastructure
- Provide multi-tenancy across separate LDAP domains (single-tenant by design)

## 3. Actor Model

| Actor | Role | Interface | Auth Plane |
|-------|------|-----------|------------|
| **IT Admin** | Manages users, orgs, groups, profiles, QR codes, audit via web UI | React admin UI (`/`) + REST API (`/api`) | Plane B (Authentik OIDC) |
| **End User** | Receives QR codes; uses XMPP/SIP services through UC client apps | QR code scan, UC client app | Plane A (LDAP bind) |
| **UC Client App** | Authenticates users via LDAP bind for XMPP/SIP services | LDAP bind (port 389/636) | Plane A (LDAP bind) |
| **AI Agent (Claude Code)** | Reads architecture spec and codebase; modifies code per instructions | CLI, file system, MCP tools | N/A (development tool) |

## 4. Design Invariants

1. **UC must work without Authentik installed.** The XMPP/SIP authentication path (Plane A) uses direct LDAP bind and has zero dependency on Authentik or any OIDC provider. A deployment can run UC-only with no SSO.

2. **UC must work when Authentik is down.** Authentik outages affect admin UI login (Plane B) only. UC client apps continue to authenticate via LDAP bind. The two planes are fully independent.

3. **Single LDAP holds identity + UC attrs on the same DN.** Each user entry carries `inetOrgPerson` (identity), `posixAccount` (POSIX), and `AsteriskPjsip{Endpoint,Auth,Aor}` (SIP) objectClasses on a single DN. There is no separate UC LDAP.

4. **Provisioning is synchronous.** UC attributes are written atomically via LDAP MODIFY_ADD during user creation. There is no async event queue, no sync worker, and no eventual consistency -- the API response confirms provisioning is complete.

5. **Two authentication planes.** Plane A (UC/LDAP bind) handles XMPP and SIP client authentication directly against OpenLDAP. Plane B (web UI/OIDC) handles admin UI authentication via Authentik. The planes share no tokens or sessions.

6. **Graceful degradation: SSO failure does not equal UC failure.** If Authentik is unreachable, the admin UI shows a login error, but all UC services continue operating. The `authentik_client.py` module uses fire-and-forget patterns for non-critical Authentik API calls (e.g., session revocation during termination).

## 5. Technology Stack

| Layer | Technology | Version | Role |
|-------|-----------|---------|------|
| **Backend runtime** | Python | 3.12 | Application language |
| **Web framework** | FastAPI | latest | REST API (82 endpoints) |
| **ORM / SQL** | SQLAlchemy Core | >= 2.0 | PostgreSQL query builder (no ORM models) |
| **LDAP client** | ldap3 | latest | LDAP CRUD operations |
| **JWT verification** | PyJWT | latest | OIDC token validation |
| **HTTP client** | httpx | >= 0.27 | Authentik Admin API calls |
| **QR generation** | qrcode + Pillow | latest | QR PNG rendering |
| **Rate limiting** | slowapi + Redis | >= 0.1.9 / >= 5.0 | Request throttling |
| **Frontend language** | TypeScript | >= 5.7 | Type-safe UI code |
| **UI framework** | React | 19 | Component rendering |
| **Build tool** | Vite | 6 | Dev server + production bundler |
| **Routing** | TanStack Router | >= 1.114 | File-based routing |
| **Data fetching** | TanStack Query | >= 5.60 | Server state management |
| **State management** | Zustand | >= 5.0 | Client state (auth, UI) |
| **Design system** | @azblink/ui | 2.0.0 | 30 primitives (Base UI + CSS Modules) |
| **Utility CSS** | Tailwind CSS | 4 | Feature component styling |
| **LDAP server** | OpenLDAP (osixia) | 1.5.0 | Identity + UC directory |
| **Database** | PostgreSQL | 16 | Profiles, audit, tokens, config |
| **Cache / rate limit** | Redis | 8-alpine | Rate limiting backend |
| **Identity provider** | Authentik | 2026.5 | OIDC SSO (optional) |
| **Reverse proxy** | Traefik | 3.7 | Path-based routing (API + UI) |
| **Orchestration** | Docker Compose | v2 | Service orchestration |

## 6. Spec Document Map

| Document | Path | Purpose |
|----------|------|---------|
| **Architecture Spec** (this series) | `docs/architecture/spec/` | As-built system architecture |
| **Historical specs/PRDs** | `docs/archive/` | Archived v2.0 specs, PRDs, and prior plans (read-only) |
| **Knowledge Base** | `CLAUDE.md` | Agent instructions and project context |
