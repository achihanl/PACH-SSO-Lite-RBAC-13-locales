<!-- spec-meta: { section: "02", version: "1.33.0", last_updated: "2026-10-22" } -->

# 02 — Component Architecture

> `[AS-BUILT]` This section describes the system components as currently implemented.

## 1. Component Inventory

### Backend Modules

`[AS-BUILT]` All backend source lives in `src/backend/`. Routes, PostgreSQL access, and request models each live in their own package; `main.py` is a composition root and holds no business logic.

**Packages**

| Package | Files | Lines | Responsibility |
|---------|------:|------:|----------------|
| `routers/` | 15 | 3922 | The 100 route handlers, one module per domain. `__init__.py` holds `ROUTER_ORDER`; `_shared.py` holds helpers used by more than one domain |
| `db/` | 11 | 2842 | PostgreSQL access, one mixin per bounded context. `tables.py` holds all 19 `Table` objects and the single `MetaData`; `_base.py` declares the typing contract the mixins rely on |
| `schemas/` | 7 | 433 | The 39 Pydantic request/response models, split by domain and flat-re-exported from `__init__.py` |

**Modules**

| Module | Lines | Responsibility |
|--------|------:|----------------|
| `ldap_client.py` | 1226 | LDAP CRUD -- user/org/group lifecycle, UC attribute builder (`build_uc_attrs`), UC attr writer (`add_uc_attrs_to_user`), SSHA password hashing |
| `config.py` | 384 | Environment loading -- LDAP, OIDC, Authentik, Redis, UC endpoints, signing secrets; also `setup_logging()` and the production-safety assertions |
| `auth.py` | 305 | The Authentik OIDC auth ladder: `require_user` -> `require_admin` -> `require_permission(p)` -> `require_directory_read`, plus WebSocket token verification |
| `ldap_activity.py` | 288 | Lifespan-managed collector tailing the slapd stats log into the LDAP client inventory |
| `rate_limit.py` | 259 | slowapi rate limiting plus `IPBlockingMiddleware` and `RequestAuditMiddleware` |
| `observability.py` | 383 | ARD-008 -- Prometheus metrics, `MetricsMiddleware`, `RequestIDMiddleware`, service-reachability probe; identity alert signals (locked identities: usernames refused everywhere, not per-source throttles; TLS expiry; amendment 2026-10-21); relay-path probe `azblink_relay_path_up{listener}` (TLS for the public name against the relay CA, the public issuer, API health; ARD-021 amendment 2026-10-22) |
| `activity_bus.py` | 192 | Activity event bus with Redis pub/sub fan-out across uvicorn workers (ARD-011) |
| `settingsdb.py` | 185 | Application settings persistence (key-value store with typed serialization) |
| `ldap_provisioning.py` | 166 | Per-client LDAP credential provisioning under `ou=clients` (ARD-006) |
| `oidc_verify.py` | 156 | OIDC JWT verification -- discovery caching, JWKS client, multi-issuer validation |
| `main.py` | 157 | Application composition: lifespan, middleware order, exception handlers, router registration |
| `authentik_client.py` | 150 | Authentik Admin API v3 client -- session/token revocation for user termination (fire-and-forget) |
| `orgdb.py` | 136 | `OrgDB` -- engine lifecycle and startup seeding; every query method is inherited from a `db/` mixin |
| `uc_validation.py` | 124 | UC input validation (extension ranges, domains, service config) |
| `deps.py` | 88 | Process-wide singletons (`ORGDB`, `settings_db`, Redis, outbound clients), constructed without I/O |
| `provisioning.py` | 70 | UC resource allocation -- UID number and SIP extension allocation from profile counters |
| `uc_client.py` | 66 | UC server API client |
| `version_cache.py` | 44 | Cached platform version lookup |
| `response_utils.py` | 34 | Response shaping and exception-to-HTTP mappings |
| `activity_types.py` | 26 | Activity event type constants |

### Frontend Layers

`[AS-BUILT]` All frontend source lives in `src/frontend/`.

| Layer | Location | Count | Responsibility |
|-------|----------|------:|----------------|
| **Primitives** | `packages/azblink-ui/primitives/` | 30 | Domain-agnostic UI atoms (Button, Badge, Card, DataTable, Dialog, Input, Tabs, Select, Menu, etc.) -- CSS Modules + design tokens, built on @base-ui/react |
| **Feature components** | `src/components/features/` | 9 dirs | Domain-specific composites organized by domain: user-management, group-management, org-management, org-profiles, qr-management, qr-preview, provisioning-ops, audit-management, settings |
| **Query hooks** | `src/lib/queries/` | 24 files | TanStack Query hooks by domain (users, groups, orgs, QR, audit, settings, health, provisioning-ops, etc.) |
| **Zustand stores** | `src/stores/` | 2 | `auth-store.ts` (OIDC tokens, user claims, login/logout), `ui-store.ts` (modals, notifications, UI state) |
| **Type definitions** | `src/types/` | 11 files | TypeScript types derived from API contracts (user, org, group, QR, audit, settings, provisioning-ops, org-profiles) |
| **Routes** | `src/routes/` | 5 dirs | File-based TanStack Router routes: directory (users/groups/orgs), provisioning, configuration (profiles/templates), auth (callback), qr (public preview) |
| **Design tokens** | `packages/azblink-ui/tokens/` | -- | CSS custom properties (dark-first): colors, typography, spacing, radius, shadows |

### Infrastructure Services

`[AS-BUILT]` All infrastructure is defined in `deploy/dev/docker-compose.yml`.

| Service | Image | Role | Persistence |
|---------|-------|------|-------------|
| `postgres` | `postgres:16` | Application database (profiles, audit, tokens, config, settings) | `azblink_pg_data` volume |
| `redis` | `redis:8-alpine` | Rate limiting backend, Authentik cache | `azblink_redis_data` volume |
| `openldap` | `osixia/openldap:1.5.0` | Identity + UC directory (users, orgs, groups, SIP/XMPP attrs) | `azblink_ldap_data` + `azblink_ldap_config` volumes |
| `directory-api` | Custom (Dockerfile.api) | FastAPI backend with uvicorn hot reload | Stateless (mounts `src/backend/` read-only) |
| `directory-ui` | Custom (Dockerfile.ui-dev) | Vite dev server with HMR | Stateless (mounts `src/frontend/src/` read-only) |
| `traefik` | `traefik:v3.7` | Reverse proxy -- path-based routing (`/api` -> backend, `/` -> UI) | Stateless |
| `seed` | Custom (Dockerfile.seed) | One-shot LDAP bootstrap (demo org tree, sample users) | Writes to `avatar_cache` volume |
| `authentik-postgres` | `postgres:16-alpine` | Authentik-dedicated database (separate from app DB) | `authentik_pg_data` volume |
| `authentik-server` | `ghcr.io/goauthentik/server:2026.5` | OIDC provider, admin UI (port 9000) | Stateless (DB-backed) |
| `authentik-worker` | `ghcr.io/goauthentik/server:2026.5` | Background tasks (token cleanup, email, etc.) | Stateless |
| `authentik-seed` | `python:3.13-slim` | One-shot Authentik OIDC app setup (OAuth2 provider, groups, test users) | Stateless |

## 2. Backend Architecture

`[AS-BUILT]` The backend is a composition root over three packages. `main.py` builds the FastAPI app -- lifespan, middleware order, exception handlers, router registration -- and nothing else. Route handlers live in `routers/`, PostgreSQL access in `db/`, request models in `schemas/`. `config.py` provides environment-based configuration to every module, and `deps.py` holds the process-wide singletons they share.

### Composition Root

`main.py` performs four jobs, in this order:

1. **Lifespan** -- `init_database()` (schema creation + profile-service seeding), activity-bus init, `ensure_clients_ou()`, the production demo-identity tripwire, and three background tasks (LDAP activity collector, service health probe, activity-bus listener). Each task body catches its own errors so a failure cannot block startup.
2. **Middleware** -- see the ordering invariant below.
3. **Exception handlers** -- `RateLimitExceeded` and `LdapUnavailableError`.
4. **Router registration** -- `for name in routers.ROUTER_ORDER: app.include_router(...)`.

`ROUTER_ORDER` is load-bearing, not cosmetic. Starlette matches routes in registration order, so a literal path registered after a parameterised one that also matches is unreachable — `/api/users/search` must come before `/api/users/{uid}`. Two things preserve that: definition order within each router module (which is where those two particular routes sit), and `ROUTER_ORDER` across modules. The list reproduces the order the routes appeared in the pre-decomposition `main.py`. See **08 § 4** for the per-module breakdown.

### Middleware Ordering Invariant

> **Decision record:** [ARD-011 — Redis Cross-Worker Event Fan-Out & Middleware Ordering Invariant](../decisions/ARD-011-redis-fanout-and-middleware-order.md)

`add_middleware()` inserts at position 0, so the **last** middleware added is the **outermost**. The runtime nesting is:

```
CORS -> RequestID -> Metrics -> RequestAudit -> IPBlocking -> routes
```

CORS is outermost so that rejections from inner middleware still pass back through it and carry `Access-Control-Allow-Origin`. Pinned by `tests/contract/test_middleware_order.py`.

### Cross-Worker Event Delivery

> **Decision record:** [ARD-011](../decisions/ARD-011-redis-fanout-and-middleware-order.md)

`Dockerfile.api` runs uvicorn with `--workers ${UVICORN_WORKERS:-2}` on the non-reload path, so in-process-only event delivery reached subscribers on the publishing worker alone. `activity_bus.py` publishes through Redis pub/sub and each worker runs a listener task that relays received events into its own subscriber queues. Redis is optional: without it the bus falls back to local delivery.

### LDAP Connection Lifecycle

> **Decision record:** [ARD-013 — LDAP Connection Lifecycle](../decisions/ARD-013-ldap-connection-lifecycle.md)

`[AS-BUILT]` `ldap_client.get_conn()` opens a fresh TCP connection and performs a bind on **every**
call — there is no pooling. Release is guaranteed at the operation boundary rather than at each call
site: `get_conn()` registers each connection it opens on a `ContextVar`-scoped bucket, and
`safe_ldap()` releases everything in that bucket in a `finally` — on success, on the `LDAPException`
it converts to `LdapUnavailableError`, and on any other exception. `ContextVar` rather than a module
global because 98 of the 100 handlers are sync `def` and run in FastAPI's threadpool, where a shared
global would let concurrent requests release each other's connections.

The invariant this creates:

> Every `get_conn()` call must execute inside either a `safe_ldap()` operation or an `ldap_conn()`
> block.

`safe_ldap()` covers operations defined inside `ldap_client.py`; `ldap_conn()` is the
context-manager entry point for every caller outside it. A `get_conn()` call in neither leaks a
socket and a file descriptor on every exception path, and **nothing enforces this** — see ARD-013
§ Consequences and TD-9. Pinned by `tests/unit/test_ldap_conn_lifecycle.py` (8 tests, no directory
required).

No call-site census is kept here. ARD-013 § 5 records the callers as they stood on 2026-08-01,
which is a dated claim in a dated record; repeating it in an as-built section would just create a
list nothing updates.

### Module Dependency Diagram

```mermaid
graph TD
    main["main.py<br/>composition root"] --> routers["routers/<br/>100 routes, 13 domains"]
    main --> obs["observability.py<br/>metrics + request-id"]
    main --> rate["rate_limit.py<br/>rate limit + IP block + audit"]
    main --> bus["activity_bus.py<br/>Redis fan-out"]
    routers --> schemas["schemas/<br/>39 request models"]
    routers --> auth["auth.py<br/>OIDC auth ladder"]
    routers --> deps["deps.py<br/>singletons"]
    routers --> ldap["ldap_client.py<br/>LDAP CRUD"]
    routers --> prov["provisioning.py<br/>resource allocation"]
    auth --> oidc["oidc_verify.py<br/>JWT verification"]
    auth --> deps
    deps --> orgdb["orgdb.py<br/>OrgDB"]
    deps --> authentik["authentik_client.py<br/>Admin API client"]
    deps --> settings["settingsdb.py<br/>app settings"]
    orgdb --> db["db/<br/>8 mixins + tables.py"]
    ldap --> config["config.py<br/>environment"]
    db --> config
    oidc --> config
    authentik --> config
```

### Key Design Decisions

- **No ORM models.** The `db/` package uses SQLAlchemy Core (table objects + raw SQL expressions), not the ORM. Tables are `sqlalchemy.Table` instances in `db/tables.py`, auto-created via `metadata.create_all()`. See **03 -- Data Architecture § 3** for why they stayed in one module.
- **Routes by domain.** All 100 endpoints live in `routers/`, one module per domain. Route handlers are thin -- they validate input (`schemas/` models), call into modules, and format responses.
- **Composition, not delegation.** `OrgDB` inherits from eight per-context mixins rather than forwarding to eight repositories, so the ~150 `ORGDB.<method>()` call sites resolve exactly as before and there is no forwarding layer to keep in sync.
- **Import-time purity.** Importing `deps.py` performs no I/O -- `create_engine` and `Redis.from_url` are both lazy, and `metadata.create_all()` moved into `init_database()`, called from the lifespan. That is what makes the backend importable with no database running, which is what lets the auth ladder and the contract gates be tested without standing up Docker.
- **Auth ladder as dependencies.** `require_user()`, `require_admin()`, `require_permission(p)`, and `require_directory_read` are dependency-injection functions called via `Depends()`. They delegate to `oidc_verify.verify_bearer_token()` or fall through to the `DEV_AUTH_TOKEN` bypass in dev/test. Their behaviour when the authorization stores are unreachable is decided in [ARD-012](../decisions/ARD-012-auth-degraded-store-posture.md); see **04 -- Authentication**.
- **Fire-and-forget Authentik calls.** `authentik_client.terminate_user_access()` catches all exceptions internally so that Authentik failures never block user termination.

## 3. Frontend Architecture

`[AS-BUILT]` The frontend uses a two-layer component architecture with clear separation between reusable primitives and domain-specific features.

### Layer 1 -- Primitives (`@azblink/ui`)

Source: `src/frontend/packages/azblink-ui/primitives/` (30 components)

Domain-agnostic UI atoms built on `@base-ui/react` (headless). Each primitive is a folder containing `Component.tsx`, `Component.module.css`, `Component.types.ts`, and `index.ts`. Styling uses CSS Modules exclusively, with all values referencing design tokens from `tokens.css` (`var(--text-sm)`, `var(--color-text-muted)`, etc.).

Components include: AlertDialog, Badge, Button, Card, Checkbox, CodeBlock, CollapsibleSection, ContentArea, DataTable, DetailGrid, Dialog, FieldCard, InfoField, Input, Label, ListPanel, Menu, Pagination, RadioGroup, Select, Skeleton, Stepper, Table, Tabs, Textarea, Toggle, ToggleCard, ToggleChipGroup, ToggleRow, Tooltip.

All primitives are barrel-exported through `packages/azblink-ui/index.ts`. Consumers import from `@azblink/ui`.

### Layer 2 -- Feature Components

Source: `src/frontend/src/components/features/` (9 domain directories + shared files)

Domain-specific composites that compose primitives with business logic. Styled with Tailwind utility classes. Organized by domain:

| Directory | Domain |
|-----------|--------|
| `user-management/` | User detail panel, user cards, user forms, password reset |
| `group-management/` | Group detail, member management, permissions |
| `org-management/` | Org tree, org detail, org forms |
| `org-profiles/` | Profile editor, profile list, UC config forms |
| `qr-management/` | QR code list, revocation, extension, stats |
| `qr-preview/` | Public shareable QR preview page |
| `provisioning-ops/` | Provisioning wizard, device list |
| `audit-management/` | Audit log tables, filters |
| `settings/` | Application settings, API keys, integrations |

Shared feature files at the root level: `empty-state.tsx`, `stat-card.tsx`, `health-status.tsx`, `search-input.tsx`, `qr-display.tsx`, `user-table.tsx`, `profile-dropdown.tsx`, `session-expired-modal.tsx`.

### State Management

- **`auth-store.ts`** (Zustand): OIDC access/ID tokens, user claims, admin group membership, login/logout actions, token refresh.
- **`ui-store.ts`** (Zustand): Modal visibility, notification queue, sidebar state, selected items.
- **TanStack Query**: All server state. 24 query hook files handle fetching, caching, and invalidation by domain. Mutations are co-located with their queries.

### Routing

TanStack Router with file-based route generation. Route tree in `src/routes/`:

| Route Group | Path Prefix | Purpose |
|-------------|-------------|---------|
| `directory/` | `/directory/users`, `/directory/groups`, `/directory/orgs` | Core directory management |
| `provisioning/` | `/provisioning` | Provisioning operations |
| `configuration/` | `/configuration/profiles`, `/configuration/templates` | Profile and template management |
| `audit-log/` | `/audit-log` | Audit trail viewing |
| `auth/` | `/auth/callback` | OIDC callback handler |
| `qr/` | `/qr/:token` | Public QR preview (unauthenticated) |
| `login.tsx` | `/login` | Login page |
| `settings.tsx` | `/settings` | Application settings |
| `my-profile.tsx` | `/my-profile` | Admin's own profile |

## 4. Infrastructure Services

`[AS-BUILT]` The platform runs as a Docker Compose stack with 11 services across two networks.

### Network Topology

```
azblink-net (bridge):
  postgres, redis, openldap, directory-api, directory-ui, traefik,
  seed, authentik-postgres, authentik-server, authentik-worker, authentik-seed

cloudflare-tunnel (external):
  traefik, authentik-server
```

Traefik listens on port 8081 and routes by path prefix:
- `PathPrefix(/api)` (priority 10) -> `directory-api:8000`
- `PathPrefix(/)` (priority 1) -> `directory-ui:5173`

### Data Persistence

| Volume | Service | Content |
|--------|---------|---------|
| `azblink_pg_data` | postgres | Application tables (profiles, tokens, audit, config, settings) |
| `azblink_redis_data` | redis | Rate limit counters (ephemeral) |
| `azblink_ldap_data` | openldap | LDAP directory data (users, orgs, groups) |
| `azblink_ldap_config` | openldap | slapd configuration (schemas, ACLs) |
| `avatar_cache` | seed | Generated user avatars |
| `authentik_pg_data` | authentik-postgres | Authentik internal state (users, providers, flows) |

### Seed Scripts

Two one-shot seed services bootstrap the dev environment:

1. **`seed`** (`deploy/dev/seed/`): Populates OpenLDAP with demo org tree and sample users. Runs after LDAP is healthy.
2. **`authentik-seed`** (`deploy/dev/authentik-seed/seed_authentik.py`): Creates OAuth2 provider, application, IT-Admins group, and test users in Authentik. Polls Authentik API up to 30 times (5s intervals) waiting for startup.

## 5. Key Architectural Flows

`[AS-BUILT]` Three primary flows drive the system. Each is detailed in its own architecture spec section.

### Authentication Flow

IT Admin opens the web UI -> redirected to Authentik OIDC (PKCE S256) -> receives access token -> frontend stores in `auth-store` -> all API calls include `Bearer` token -> backend validates via `oidc_verify.py` (JWKS, multi-issuer) -> claims extracted for RBAC.

Dev/test bypass: `DEV_AUTH_TOKEN` env var skips OIDC and returns synthetic admin claims.

> Full details: see **04 -- Authentication and Authorization**

### Provisioning Flow

Admin creates user via API (`POST /api/users`) with `profileId` -> `routers/users.py` creates LDAP entry (`inetOrgPerson`) -> if profile has `xmpp_enabled`/`sip_enabled`, allocates UID number + SIP extension from profile counters (`provisioning.py`) -> builds UC LDAP attributes (`ldap_client.build_uc_attrs`) -> adds UC objectClasses to same DN via MODIFY_ADD (`ldap_client.add_uc_attrs_to_user`) -> records provisioning token in PostgreSQL -> generates signed QR code -> returns credentials in response (shown once).

> Full details: see **05 -- Provisioning and QR Codes**

### Termination Flow

`[AS-BUILT]` Termination disables the user across all systems in a single synchronous API call:

`api_user_terminate()` in `routers/users.py` receives the request with a reason, then runs five steps in order, accumulating per-step outcomes into an `actions` dict:

1. `ldap_client.disable_user()` -- three writes: sets `pwdAccountLockedTime` to `000001010000Z`, removes the user from every group they belong to, and sets `userPassword` to `{DISABLED}` plus `description` to `TERMINATED`. The ppolicy lock is the part an **external** consumer can act on — the overlay refuses the bind, and the attribute is the one filterable signal that the account is dead. Without it the entry still satisfies an ordinary user filter, so an LDAP-backed relying party keeps a terminated account enabled and addressable indefinitely (2026-08-07 VM7 integration report, **G5**). Group removal uses `LDAP_BIND_DN` as a placeholder member where the terminated user is a group's only member, since `groupOfNames` requires one. Pinned by `tests/test_users.py::TestTerminationReachesConsumers`.
2. `ORGDB.revoke_tokens_for_user()` -- marks all active provisioning tokens as revoked
3. `authentik_client.terminate_user_access()` -- revokes all Authentik sessions and OAuth2 tokens (fire-and-forget; failures logged but do not block termination)
4. `uc_client.terminate_user_sessions()` -- **stub, see below**
5. `ORGDB.record_termination()` -- writes the accumulated `actions` to the termination audit table, followed by `record_admin_action()`

Each step catches its own failures and records an `*_error` key rather than aborting; `summarize_termination()` turns any such key into `partial: true` plus a warning, which `TerminationSuccessModal` shows as "Termination incomplete".

The LDAP disable is the critical step -- it immediately prevents both UC authentication (Plane A) and any future OIDC login (Plane B, since Authentik federates against this LDAP).

#### Accepted risk -- UC session teardown is not implemented `[AS-BUILT]`

Step 4 is a stub. `UCClient.terminate_user_sessions()` performs no teardown: real SIP termination needs Asterisk ARI and real XMPP termination needs an ejabberd/Prosody admin API, and both are blocked on a UC Server API specification.

**Consequence.** Disabling the LDAP entry stops *new* binds, but per ARD-001 `userPassword` is the XMPP bind credential and `AstAuthPassword` is the SIP digest — neither is consulted again by an *already-established* session. A terminated user's live SIP registration and XMPP session therefore survive until natural expiry. Plane A is by design always available and does not depend on Authentik, so the Plane B revocation in step 3 provides no cover here.

**Why the audit record does not hide this.** The stub returns `None` counts behind an explicit `implemented: False` flag, and `response_utils.uc_termination_actions()` records `uc_sessions: "not_implemented"` instead of writing counts through. It previously returned `0`, which the route wrote into the audit event — asserting that zero UC sessions were terminated, indistinguishable from a genuine "no live sessions found". An operator reading the trail can now tell the two apart.

Tracked as **TD-8** in `docs/reports/tech-debt.md` and issue #233.
