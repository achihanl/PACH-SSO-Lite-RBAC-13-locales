<!-- spec-meta: { section: "06", version: "1.57.0", last_updated: "2026-10-26" } -->

# 06 — Deployment

## 6.1 Service Topology `[AS-BUILT]`

The stack is defined by a **base + override compose set** in `deploy/dev/`
(ARD-010): the base `docker-compose.yml` is a prod-safe skeleton, and profile /
override files differentiate dev from prod (see §6.7). The tables below describe
the **dev profile** (base `+ docker-compose.dev.yml`, `COMPOSE_PROFILES=dev`);
production selection is covered in §6.7. It comprises two service groups.

### AZBlink Core Services

| Service | Image | Host Port | Role | depends_on |
|---------|-------|-----------|------|------------|
| `postgres` | `postgres:16` | 5433 | Application database (SQLAlchemy Core) | -- |
| `redis` | `redis:8-alpine` | 6380 | Rate limiting and caching | -- |
| `openldap` | `osixia/openldap:1.5.0` | 1390 | LDAP directory (identity + UC) | -- |
| `directory-api` | Custom (`Dockerfile.api`) | -- (8000 internal) | FastAPI application server | postgres, openldap, redis (all healthy) |
| `directory-ui` | Custom (`Dockerfile.ui-dev`) | -- (5173 internal) | Vite dev server with HMR | directory-api |
| `traefik` | `traefik:v3.7` | 8081 | Reverse proxy (path-based routing) | -- |
| `seed` | Custom (`Dockerfile.seed`) | -- | One-shot LDAP bootstrap (org tree, demo users) | openldap, postgres (healthy) |

### Authentik IdP Services

| Service | Image | Host Port | Role | depends_on |
|---------|-------|-----------|------|------------|
| `authentik-postgres` | `postgres:16-alpine` | -- (internal) | Separate Authentik database | -- |
| `authentik-server` | `ghcr.io/goauthentik/server:2026.5` | 9000 | OIDC provider + admin UI | authentik-postgres, redis (healthy) |
| `authentik-worker` | `ghcr.io/goauthentik/server:2026.5` | -- | Background task processing | authentik-postgres, redis (healthy) |
| `authentik-seed` | `python:3.13-slim` | -- | One-shot OAuth2 app + LDAP source bootstrap | authentik-server (started), directory-api (healthy) |

---

## 6.2 Network Topology `[AS-BUILT]`

Two Docker networks isolate internal services from external access.

| Network | Type | Purpose |
|---------|------|---------|
| `azblink-net` | bridge (internal) | All services communicate here |
| `cloudflare-tunnel` | external | Dev and LAN layout: exposes traefik + authentik-server to the dev box's shared Cloudflare tunnel. The prod TLS overlay takes both off it and ansible does not create it there |

```mermaid
graph LR
    subgraph "azblink-net (bridge)"
        PG[postgres]
        Redis[redis]
        LDAP[openldap]
        API[directory-api]
        UI[directory-ui]
        Traefik[traefik]
        Seed[seed]
        APG[authentik-postgres]
        AS[authentik-server]
        AW[authentik-worker]
        ASeed[authentik-seed]
    end

    subgraph "cloudflare-tunnel (external)"
        Traefik
        AS
    end

    Traefik -->|"/ → :5173"| UI
    Traefik -->|"/api → :8000"| API
    API --> PG
    API --> LDAP
    API --> Redis
    AS --> APG
    AS --> Redis
    AW --> APG
    AW --> Redis
```

Only `traefik` and `authentik-server` are attached to the `cloudflare-tunnel` network, which connects to a centralized Cloudflare tunnel for external access (e.g., `azblink-ad.keithmoc.dev`, `authentik.keithmoc.dev`).

**Cloudflare Access on `authentik.keithmoc.dev` (dev, since 2026-10-08).** A Zero Trust Access application admits only the owner's email to the whole hostname. Two path-scoped applications bypass it (Bypass, Everyone), because the admin UI fetches them cross-origin and without credentials (`src/frontend/src/lib/oidc.ts`), so an Access cookie never reaches them:

| Path | Why it is open |
|---|---|
| `/application/o/azblink-directory/.well-known/` | OIDC discovery |
| `/application/o/token/` | Code exchange and refresh |

Everything else on the hostname redirects to the Access login: `/if/admin/`, `/api/v3/` (the flow executor included), the flows, `/application/o/authorize/`, end-session, JWKS, and other providers' discovery. Browser navigation therefore crosses Access once per session. Access sits at Cloudflare's edge, so the docker-internal `http://authentik-server:9000` is unaffected; headless relays use only that address (ARD-018). The Access applications live in the Cloudflare dashboard, and the tunnel ingress lives outside this repo (`~/_WORKSPACES_/cloudflare-tunnel/ingress.d/azblink.yml`).

---

## 6.3 Port Mappings `[AS-BUILT]`

| Host Port | Service | Protocol | Purpose |
|-----------|---------|----------|---------|
| 8081 | traefik | HTTP | Reverse proxy: UI (`/`) + API (`/api`) |
| 8083 | traefik | HTTP | Traefik dashboard (debug) |
| 5433 | postgres | TCP | Application database (PostgreSQL) |
| 1390 | openldap | TCP | LDAP directory (LDAP protocol) |
| 1637 | openldap | TCP | LDAPS (TLS disabled in dev) |
| 6380 | redis | TCP | Rate limiting store |
| 9000 | authentik-server | HTTP | OIDC IdP + Authentik admin UI |
| 9443 | authentik-server | HTTPS | Authentik HTTPS (dev) |

Non-standard host ports (5433, 6380, 1390) are used to avoid conflicts with other local instances.

---

## 6.4 Volume Mounts `[AS-BUILT]`

### Named Volumes (Persistence)

| Volume | Service | Mount Point | Content |
|--------|---------|-------------|---------|
| `azblink_pg_data` | postgres | `/var/lib/postgresql/data` | Application database |
| `azblink_redis_data` | redis | `/data` | Rate limit state |
| `azblink_ldap_data` | openldap | `/var/lib/ldap` | LDAP database |
| `azblink_ldap_data` | directory-api | `/var/lib/ldap` (ro) | Read `slapd-stats.log` for LDAP client inventory collector |
| `azblink_ldap_config` | openldap | `/etc/ldap/slapd.d` | LDAP configuration |
| `authentik_pg_data` | authentik-postgres | `/var/lib/postgresql/data` | Authentik database |
| `avatar_cache` | seed | `/avatars` | Generated user avatars |

### Bind Mounts (Hot Reload)

| Source | Container | Purpose |
|--------|-----------|---------|
| `src/backend/` | directory-api (`/app:ro`) | Python source for uvicorn auto-reload |
| `src/frontend/src/` | directory-ui (`/app/src/frontend/src`) | React source for Vite HMR |
| `src/frontend/packages/azblink-ui/` | directory-ui | Design system primitives for Vite HMR |
| `src/frontend/index.html` | directory-ui | Entry HTML |
| `src/frontend/vite.config.ts` | directory-ui | Vite configuration |
| `deploy/dev/ldap/*.schema` | openldap | Asterisk PJSIP LDAP schema (read-only) |
| `deploy/dev/ldap/bootstrap.ldif` | openldap | LDAP seed data (read-only) |
| `deploy/dev/ldap/logfile-config.ldif` | openldap | `olcLogFile` bootstrap → slapd stats log (read-only) |
| `deploy/dev/ldap/memberof-refint-config.ldif` | openldap | Overrides osixia's built-in `memberof` overlay onto `groupOfNames`/`member` (read-only). Must sort **after** the image's `04-refint.ldif`, which creates the overlay — see spec §03 §2.4 |
| `deploy/dev/authentik-seed/` | authentik-seed (`/seed:ro`) | Seed script (read-only) |

---

## 6.5 Authentik Bootstrap `[AS-BUILT]`

The Authentik IdP is bootstrapped automatically via `deploy/dev/authentik-seed/seed_authentik.py`.

### Bootstrap Sequence

1. `AUTHENTIK_BOOTSTRAP_TOKEN=dev-authentik-api-token` is set as an environment variable. Authentik creates this API token on first startup only.
2. The seed script polls `GET /api/v3/root/config/` every 5 seconds for up to `AUTHENTIK_WAIT_SEC` (default 600 s). First startup takes 2.5-4 minutes of Authentik database migrations, longer under load.
3. Once reachable, the script creates:
   - **Authorization + invalidation flows** -- looks up default flows by slug
   - **Property mappings** -- resolves `openid`, `profile`, `email` scope mappings.
     Authentik's worker creates these flows and mappings (and the LDAP source mappings,
     sync schedule and discovered TLS keypair) after the API answers, so the seed polls
     for them on the same `AUTHENTIK_WAIT_SEC` budget. A fixed 12 polls (60 s) gave up on
     a loaded fresh box and left the web provider without `profile`.
   - **Signing key** -- finds or creates a certificate/keypair (required for JWKS)
   - **OAuth2 provider** -- public client, PKCE S256, client ID `azblink-directory`, redirect URIs as `[{matching_mode: "strict", url: "..."}]` dicts, grants `authorization_code` + `refresh_token` only, access token 15 min, refresh token 12 h (review finding 9, owner decision 2026-10-24: the browser keeps it in `localStorage`; first-party relay providers stay 7 d). It refuses `client_credentials`, so an app password cannot mint an API token outside the browser flow. On a re-run the seed patches an existing provider's flows, redirect URIs, grants, scope mappings and token validity back to these values (every provider it owns), so an older install converges
   - **The API's Admin API token** (ARD-010 amendment 2026-10-22) -- when `AUTHENTIK_API_TOKEN` differs
     from the bootstrap token (prod vault), a non-expiring `api` token `azblink-directory-api` for `akadmin`,
     its key set to that value and reset if it drifts. Equal or empty (dev, CI) = nothing to create. [AS-BUILT]
   - **Application** -- `azblink-directory` linked to the OAuth2 provider
   - **Service clients** (ARD-017) -- one confidential `client_credentials` provider + application per `AUTHENTIK_SERVICE_CLIENTS` entry, with an expression policy that admits only the generated `ak-<client_id>-client_credentials` account (audit B2, §07), under application `policy_engine_mode: all` so no other binding can outvote it. Dev and CI also register `azblink-directory-test`, through which `tests/conftest.py` mints user tokens from app passwords; it alone has no such policy and is never registered elsewhere
   - **First-party headless clients** -- per `AUTHENTIK_FIRST_PARTY_CLIENTS` entry (JSON `{client_id: [redirect_uri, ...]}`): a confidential `authorization_code` + `refresh_token` provider (15 min / 7 d), an application with slug = `client_id` under `policy_engine_mode: all`, and an expression policy that admits only `<client_id>-*` group members; the shared `headless-first-party-auth` flow with its lockout (tenant `reputation_upper_limit` 0). Dev registers `safenest-dev`. [AS-BUILT]
   - **IT-Admins group** -- with `akadmin` user assigned
   - **Test users** -- none seeded locally (`SEED_USERS` is empty); web identities federate from the LDAP source below. `akadmin` remains the local break-glass admin.
   - **LDAP source** (ARD-007) -- provisions the `authentik-sync` client via the
     directory API (dev; prod supplies the secret from vault), resolves the
     OpenLDAP property mappings, creates the `azblink-ldap` source
     (`object_uniqueness_field=uid`, bind-based login, `sync_users_password=false`),
     and triggers an initial sync. The legacy local `alanl` seed user (not present in LDAP) is removed *before* the sync; the LDAP demo user (`mei`) is then added to `IT-Admins` for the SSO demo.
   - **Web sign-in lockout** (ARD-018 amendment, G22) -- the headless flow's username lockout on the brand
     flow `default-authentication-flow` too, admin sign-in included, whether or not first-party clients
     exist (§08 *First-Party Headless Login*). [AS-BUILT]
   - **LDAP bind budget** (ARD-018 amendment, G23) -- on both flows' password bindings, an expression
     policy that atomically reserves one of a username's 3 LDAP binds per password POST; the deny/login
     guard gives a success's reservation back. The seed also enforces `re_evaluate_policies` there.
     The same policy first throttles the source (B5): a client IP with 2 failures for the username is
     refused, and each IP reserves one of its own 2 binds before the username's. [AS-BUILT]
   - **Clients onboarded at runtime** (ARD-022) -- `POST /api/clients/onboard` builds a client's
     providers, applications and policies through the Authentik Admin API (`authentik_client.py`,
     the seed's twin) and adds its `(cn=<c>-*)` term to the LDAP source. So the seed creates the
     headless flow even with no env client, and its group filter keeps every term already on the
     source: a reseed never drops an onboarded client. Nothing to configure per client; the
     registry table `first_party_clients` is created at startup (migration `030` for upgrades).
     [AS-BUILT]

The default password policy (`cn=default,ou=policies`) is LDAP data, so `bootstrap.ldif` sets it only on a
fresh volume. `deploy/dev/ldap/ppolicy-lockout.ldif` carries its lockout settings
(`pwdFailureCountInterval: 3600`, G24) to an initialized volume: ansible `ldap_source.yml` applies it with
`ldapmodify -Y EXTERNAL` on every converge, like the `ou=clients` ACL; on dev, apply it by hand (the file
header has the commands). [AS-BUILT]

ARD-020 changes LDAP config twice, and both reach an initialized volume the same way
`[AS-BUILT]`:

- **Schema:** `azbSipContext` (§03 §2.3) is in `azblink.schema`, which osixia loads only on a
  fresh volume. `deploy/dev/ldap/azblink-schema-ard020.ldif` adds it to a running directory: it
  adds the attribute type and replaces the three azblink objectClasses on
  `cn={N}azblink,cn=schema,cn=config`, whose index differs per install. `ldap_source.yml` reads
  the index and applies the file when `azbSipContext` is absent; on dev, apply it by hand (the
  file header has the commands). Re-applying is harmless (checked on OpenLDAP 2.4.57).
- **ACL:** `ldap-clients-acl.ldif` gains rule `{2}`, the PBX read (§07 §3). The file replaces
  `olcAccess` whole, so the converge that re-applies it every run picks the rule up.
- **Order does not matter.** ldap3 refuses an attribute name the server schema lacks, so the API
  asks for `azbSipContext` only when the schema defines it (`ldap_client._sip_context_attr`). On a
  directory without it, every level reads as unset (new endpoints get `default`) and group, member
  and org calls work as before; a write of a context (`PUT /sip` with `context`, group
  `sipContext`, `POST /api/org/sip_context`) answers 503 `sip_context_unavailable`. Each LDAP
  connection re-reads the schema, so applying the file takes effect without an API restart. Dev's
  API runs merged code at once; this is what keeps it working until the owner applies the file.

### Idempotency

The seed script is safe to re-run. It checks for existing resources by slug/name before creating, and updates in place where possible.

### API Gotchas (Authentik 2025.8+)

- `redirect_uris` must be dicts with `matching_mode` and `url`, not plain strings
- `invalidation_flow` is required when creating an OAuth2 provider
- OAuth2 provider needs `property_mappings` AND `signing_key` -- without `signing_key`, JWKS returns empty and OIDC token verification fails
- LDAP source `object_uniqueness_field` defaults to `objectSid` (AD) — must be set
  to `uid` for OpenLDAP or the sync imports zero users silently
- The sync client secret is minted show-once by the provision API. Prod reads
  `AUTHENTIK_LDAP_SYNC_PASSWORD` from vault. Dev/CI self-provision it, and a re-run
  keeps it while the source still binds; only a source that cannot bind gets a
  rotated secret. The check is a live bind: `GET /sources/ldap/<slug>/debug/` builds
  each synchronizer with the stored credentials and answers 500 when LDAP refuses.
  The source's `connectivity` field is a cache (2 h TTL, refreshed hourly and on
  save) and still reads "ok" after an LDAP-side rotate, restore or reset

---

## 6.6 Hot Reload Rules `[AS-BUILT]`

| Change Type | Action Required | Command |
|-------------|-----------------|---------|
| `src/backend/*.py` | None -- uvicorn auto-reload | wait ~1s |
| `src/frontend/src/**/*` | None -- Vite HMR | wait ~1s |
| `src/frontend/packages/azblink-ui/**/*` | None -- Vite HMR (source alias) | wait ~1s |
| `src/frontend/package.json` or deps | Rebuild UI container | `just ui` |
| `src/backend/requirements.txt` | Regenerate the lockfile, then rebuild the API container | `just lock-backend && just api-rebuild` |
| `deploy/dev/Dockerfile.*` | Full rebuild | `just up` |
| `deploy/dev/docker-compose.yml` | Restart stack | `just down && just up` |
| Route file added/deleted/renamed | Regenerate route tree | `just ui-routes` |
| Backend request model (`src/backend/schemas/*.py`) | Refresh the contract baseline, then regenerate frontend types | `just openapi-accept && just ui-types` |

### Generated Frontend API Types

`src/frontend/src/types/api.gen.ts` is generated from
`tests/contract/openapi.baseline.json` by `openapi-typescript`, and is
**gitignored** -- the same convention as `src/routeTree.gen.ts` (§6.4). It is
produced automatically by the `postinstall` and `prebuild` npm lifecycle hooks
in `src/frontend/package.json`, so for host installs and builds a plain
`npm ci` or `npm run build` is sufficient; `just ui-types` is the manual escape
hatch for editing the baseline in place.

Docker image builds need one more step: `deploy/dev/Dockerfile.ui-dev` and
`Dockerfile.ui-react` `COPY tests/contract/openapi.baseline.json` into the
build context before their `npm ci`, since the hooks can't generate from a
file that was never sent to the daemon. `.dockerignore` excludes `tests/` but
carries a narrow unignore for that one path.

The generator is a devDependency of the **repo-root** `package.json`, not the
frontend workspace's. It peer-requires `typescript@^5.x` while the frontend pins
`^7.0.2` (the native port, whose API has no `ts.factory`); declaring it in the
workspace fails `npm install` with ERESOLVE. At the root -- which declares no
other dependencies -- npm resolves `typescript@5.9.3` for the generator while
`src/frontend/node_modules/typescript` stays at `7.0.2`.

That placement makes the install location load-bearing: every `npm ci` must run
at the **repo root**, never with `working-directory: src/frontend`. A
workspace-scoped install omits the root devDependency, so the frontend's
`postinstall` hook then fails with `openapi-typescript: not found` and exits
127. CI workflows that install the frontend follow this (`pr-checks.yml`
frontend, `dead-code.yml` pr-scan and full-scan).

Only request bodies and path/query parameters are generated. No handler declares
a `response_model`, so every success response types as `unknown`; response
shapes remain hand-written.

### Backend Lockfile Regeneration

`src/backend/requirements.lock` is compiled from `requirements.txt` by
`pip-compile` inside a throwaway `python:3.14-slim` container (`just
lock-backend`); `deploy/dev/Dockerfile.api` and the backend CI jobs install the
**lock**, not the floors, so a `requirements.txt` edit changes nothing at
runtime until the lock is regenerated.

Two properties of that recipe are load-bearing:

- **pip is pinned to `25.3`.** `python:3.14-slim` now ships pip 26.x, and
  pip-tools 7.6.0 -- the current release -- calls the pre-26
  `make_requirement_preparer()` signature, so an unpinned
  `pip install pip-tools` resolves and then dies with `TypeError: ... missing 1
  required keyword-only argument: 'allow_editables'`. The pin is the only
  reason the recipe completes; drop it when pip-tools ships a pip-26-compatible
  release.
- **The container runs as the invoking uid**, via `--user` plus a venv under
  `/tmp` (a non-root user cannot install into the image's system
  `site-packages`). A root-owned lockfile is not merely inconvenient: it stalls
  the Mutagen sync described under *Remote-Synced Working Trees* below, which
  cannot apply the file back to the alpha side.

### Decision Flow for Developers

1. Edited Python in `src/backend/`? Do nothing -- uvicorn watches for changes.
2. Edited React/CSS/TS in `src/frontend/src/` or `packages/azblink-ui/`? Do nothing -- Vite HMR propagates.
3. Changed `package.json` or dependency files? Run `just ui` (frontend) or `just lock-backend && just api-rebuild` (backend).
4. Changed Docker configuration? Run `just down && just up`.
5. Added or deleted a route file? Run `just ui-routes` (uses `@tanstack/router-cli generate`). Do **not** use `npx tsr generate` -- that resolves to `ts-remove-unused`, a different package.
6. Changed a backend request model? Run `just openapi-accept` to refresh the contract baseline, then `just ui-types`. A stale `api.gen.ts` surfaces as a `tsc` failure at the affected call site, not a runtime surprise.

### Remote-Synced Working Trees

When the stack runs on a separate host and the working tree is mirrored to it by
a file synchronizer (`just sync-start`, Mutagen), the rules above hold for the
**directory** bind mounts in §6.4 but not for the **single-file** ones
(`index.html`, `vite.config.ts`, and the tsconfig/postcss entries). Synchronizers
write via temp-file-plus-rename, which replaces the host inode; the container's
mount still points at the old inode, so it serves the previous content
indefinitely while the host file reads as correct. Changes to those files require
a service restart (`just r "recover-service directory-ui"`), not a reload.

Reaching the dev server by a hostname other than `localhost` also requires that
hostname in the Vite `server.allowedHosts` allowlist, or Vite 6+ answers with a
403 that resembles a network failure (§6.2).

---

## 6.7 Production Deployment Topology `[AS-BUILT]` (ARD-010, ARD-021)

Production is deployed **exclusively via Ansible** (`deploy/ansible/`); the
`deploy/install.sh` `curl|bash` quick-path was removed. Production runs the
**ARD-021 transport**: one public HTTPS host through a Cloudflare tunnel for
browsers, the same name over TLS on a routed private path for relays, and
plaintext listeners on loopback only (see Transport below). ARD-010's
LAN-plaintext posture no longer applies.

### Compose topology (base + override)

`deploy_subdir` stays `deploy/dev` for both environments (relative build
contexts `../..` and `./ldap`/`./obs` mounts must resolve). Differentiation is
by compose file set + profiles, selected from the inventory:

| File | Role | Loaded in |
|------|------|-----------|
| `docker-compose.yml` | Prod-safe **skeleton** (no demo LDAP data, no `seed` service) | dev + prod |
| `docker-compose.dev.yml` | Demo LDAP mount (`bootstrap.demo.ldif`) + one-shot `seed` service | dev only |
| `docker-compose.prod.yml` | **Additive only**: per-service resource limits + vault-rendered `bootstrap.admin.ldif` mount | prod only |
| `docker-compose.tls.yml` | Production transport (ARD-021): cloudflared, the browser edge (nginx), Traefik `websecure` + Authentik router, Authentik worker cert mount, LDAPS | prod only |

Selection vars: dev = `azblink_compose_files: ["docker-compose.yml"]` +
`azblink_compose_profiles: ["dev"]`; prod = `["docker-compose.yml",
"docker-compose.prod.yml", "docker-compose.tls.yml"]` + `["prod"]`, threaded into
the `docker_compose_v2` deploy task.

### Transport (ARD-021)

| Who | Reaches | Listener | TLS by |
|-----|---------|----------|--------|
| Browsers | `https://<azblink_public_host>/` (UI, `/api`, Authentik paths) | cloudflared → edge (nginx) → Traefik `web` (loopback `:8081`) | Cloudflare edge |
| Relays | `https://<azblink_public_host>/` resolved to `azblink_private_ip` | Authentik `:9443` published on `<private ip>:443` | Authentik (brand web certificate) |
| Relays | `https://<azblink_public_host>:8443/api/…` | Traefik `websecure` on `<private ip>:8443` | Traefik (`deploy/dev/traefik/tls.yml`) |
| Relays, PBXs, ARD-006 clients | `ldaps://<azblink_public_host>:636` | OpenLDAP `:636` on `<private ip>` | slapd (`LDAP_TLS=true`, client certs not requested) |

- **Issuer:** `https://<azblink_public_host>/application/o/<client>/` on both paths (§04 §3).
  Traefik's Authentik router (priority 20, above `/api`) sets `X-Forwarded-Proto: https`.
- **Certificate:** one chain for `azblink_public_host`. `azblink_tls_fullchain` and
  `azblink_tls_ca` are in group_vars, and `azblink_tls_privkey` is in vault. `config.yml`
  renders them to `deploy/dev/tls/` (git-ignored; key 0600, owned by uid 1000 for
  authentik-worker). The worker discovers `/certs/<host>/`, and `authentik-seed`
  (`AUTHENTIK_WEB_CERT_NAME`) sets it as the brand's web certificate. `AZBLINK_TLS_SHA`
  in each reader's environment makes a new certificate recreate the readers.
- **Publishing:** `traefik_web_publish`, `authentik_http_publish` and `ldap_publish` bind
  `127.0.0.1`. `authentik_https_publish` (`:443`), `traefik_relay_publish` and
  `ldap_publish_tls` bind `azblink_private_ip`. Dev defaults (`8081`, `9000`, all
  interfaces) are unchanged.
- **Cloudflare (outside the repo):** a dedicated tunnel for the production box. Its token
  is `cf_tunnel_token` in vault, and its public hostname maps to `http://edge:80`.
  The dev box's shared tunnel (`~/_WORKSPACES_/cloudflare-tunnel/`) is not used for
  production.
- **Browser source (ARD-021 amendment 2026-10-22, browser source):** each browser is its own
  source at the sign-in throttle. Authentik records the first `X-Forwarded-For` entry from a
  trusted peer, and Cloudflare forwards the visitor's own `X-Forwarded-For` in front of the real
  address, so each hop trusts exactly one peer at a fixed address. `azblink_edge_net` (a /24
  prefix, default `10.255.250`) is split in two networks (ARD-021 amendment 2026-10-24).
  `tunnel` (`.128/25`) holds only cloudflared `.130` and the edge `.131`, so a tunnel target
  naming any other container is unreachable and fails with a 502 instead of making every browser
  one source. Not covered: ports the box publishes on its private IP stay reachable, because `tunnel` cannot be `internal` (cloudflared dials out): above all Authentik's own TLS listener (`authentik_https_publish`, `:443`); a target there still makes every browser one source. `edge` (`.0/25`) holds the edge, nginx
  (`deploy/dev/edge/default.conf.template`) `.3`, which takes `CF-Connecting-IP` only from `.130`
  and replaces `X-Forwarded-For` (and the other forwarding headers) with that one address;
  Traefik `.4`, whose `web` entrypoint trusts forwarded headers only from `.3`; Authentik `.5`,
  which Traefik reaches over this network and which trusts `.4` (`env.j2`); and the directory API
  `.6`, reached the same way, whose `TRUSTED_PROXIES` is exactly `.3` and `.4` (Traefik appends the
  edge behind the browser's address), so its per-IP limits and auto-block see each browser and relay
  (§07 §1). A request that does
  not come from cloudflared is its own peer's source. Docker assigns dynamic addresses only from
  `.64/26` (edge) and `.192/26` (tunnel), and every member is pinned below them, so nothing that
  joins either network can take a trusted `.3`-`.6` or `.130`
  (`tests/unit/test_browser_edge_config.py`, which also checks that only the edge shares
  cloudflared's network in every compose file). `preflight.yml` refuses an edge
  prefix that is not three octets or holds `azblink_private_ip`, and a relay IP inside it.
- **Relay boxes (ARD-021 amendment 2026-10-22):** `authentik_relay_ips`
  (`{client_id: <static IPv4>}`) names each first-party client's relay box. `env.j2`
  trusts each as a `/32` for `X-Forwarded-For` (`AUTHENTIK_TRUSTED_PROXY_CIDRS`, with
  loopback and any `authentik_trusted_proxy_cidrs`). `preflight.yml` refuses a client
  without a relay IP, a relay IP for an id that is not a first-party client or listed in
  `authentik_onboarded_clients` (API-onboarded clients that relay, ARD-022; each needs a relay IP,
  and an onboarded client that does not relay is in neither list), an id in both
  `authentik_first_party_clients` and `authentik_onboarded_clients`, a value that is
  not one canonical IPv4, an unspecified, loopback or multicast address, the box's own
  `azblink_private_ip`, two clients on one address, and any trusted entry that is not a valid
  single host of its family (IPv4 `/32`, IPv6 `/128`). The checks are
  `filter_plugins/relay_checks.py`; `tests/unit/test_preflight_relay.py` runs the real task. Who may reach the private IP at all is the routed network's ACL, outside the box.
- **Browser-path probes (ARD-008 amendment 2026-10-24):** the service probe follows the
  compose set. The base file points `UI_PROBE_URL` at `directory-ui:5173`,
  `docker-compose.prod.yml` at `directory-ui-prod:8001/health`, and
  `docker-compose.tls.yml` adds `EDGE_PROBE_TARGETS`: cloudflared's `/ready` (served by
  `--metrics 0.0.0.0:2000`, 200 only while the connector holds a connection to
  Cloudflare, read through the edge's `edge:2000/ready`, since the API shares no network with
  cloudflared) and `edge:80` (through Traefik to the UI). Both land in
  `azblink_service_up`, so a dead tunnel pages through **Platform service down**.
  `tests/unit/test_probe_targets.py` merges each compose set and fails on a probe of a
  service that set does not run.
- **Relay-path probe:** `directory-api` checks each listener the way a relay reaches it,
  every 20 s, into `azblink_relay_path_up{listener}`: TLS verified for the public name
  against `tls/ca.pem`, Authentik's discovery `issuer` equal to
  `https://<host>/application/o/azblink-directory/`, and the API's `/api/health`.
  `env.j2` renders the targets (`RELAY_PATH_TARGETS`, `authentik|api|ldaps=<ip>:<port>`);
  `docker-compose.tls.yml` sets the host and mounts the CA. The **Relay path down** alert
  fires after 3 minutes at 0 (§02). It complements `verify.yml`, which checks the same
  path once at converge.
- **Simulator (test stacks only):** `docker-compose.relay-sim.yml` loads after the TLS
  overlay with a throwaway CA for `id.relay.test` and puts the path's clients on their own
  network at static addresses: a trusted relay, an untrusted box, an Asterisk PBX reading
  PJSIP from LDAP as the client's PBX identity (plaintext `:389`, like UED), and ejabberd
  binding users over LDAPS. It also stands a box at cloudflared's tunnel address and another
  on the edge network, to test the browser source and that cloudflared's place reaches only the
  edge. Its subnets, `RELAY_SIM_NET` and
  `AZBLINK_EDGE_NET`, have no default there: every stack names
  its own (CI uses `10.231.44` and `10.231.43`), and Docker refuses an overlapping one at `up`. CI's backend
  stack loads it, and `tests/test_relay_path.py` drives it. It never ships to production.
  ejabberd starts from a copy of `relay-sim/ejabberd.yml`, so a test can point it at another
  client's search identity and `ejabberdctl reload_config`.
- **E2E journey (test stacks only):** `src/frontend/e2e/journey/` (Playwright project `journey`)
  runs on a fresh stack with the simulator (`.github/workflows/e2e.yml`: nightly, release tags,
  by hand, and PRs touching the journey, the Add client page or the simulator). The seeded web
  admin signs in through Authentik in the browser and onboards a throwaway client on the Add
  client page (ARD-022, §08), which shows each secret once and keeps none in browser storage or
  the URL; adding it again shows no secrets. The test checks the client's LDAP
  entries and Authentik objects, then acts as the building: its service client creates a
  resident with SIP, `pbx-sim` reconfigured with the returned PBX identity registers the
  resident's extension, and `xmpp-sim` with the returned ejabberd identity logs in the bridge
  and the resident. A second test adds another client the way an AI agent would: a plain
  JSON-RPC client (`journey/mcp.ts`) starts the MCP server `tools/directory-mcp` over stdio
  with the admin's token, calls `onboard_client`, checks that invalid arguments and an API 409
  come back as tool errors and that the server's stderr holds none of the returned secrets,
  then runs the same LDAP, Authentik, SIP and XMPP checks. The job installs that server's
  pinned SDK in its own venv and runs its unit tests before the stack starts; PRs touching
  `tools/directory-mcp/` or `src/backend/schemas/clients.py` trigger it too. Each UI step saves
  a numbered screenshot (`E2E_SHOTS_DIR`, artifact `e2e-screenshots`). It leaves the clients
  behind, so it never runs against dev.
  The run an AI agent makes, step by step with fixtures, assertions, failure cases and the steps no
  test covers yet, is [scenarios/agent-onboard-client.md](../scenarios/agent-onboard-client.md).

### Dev↔prod deltas

- **Admin UI:** `directory-ui` (profile `dev`, Vite/HMR) vs `directory-ui-prod`
  (profile `prod`, static `Dockerfile.ui-react` → nginx). `VITE_OIDC_*` are baked
  as build-args at deploy time. The prod nginx sends a CSP and security headers
  on every response (`deploy/dev/nginx-security-headers.conf`, review finding 9):
  `script-src 'self'`, `frame-ancestors 'none'`, `connect-src 'self'` plus the
  issuer's origin (baked from `VITE_OIDC_ISSUER`), `X-Frame-Options: DENY`,
  `nosniff`, `Referrer-Policy: same-origin`, HSTS and
  `Cross-Origin-Opener-Policy: same-origin`. They cover the UI only: Authentik's
  paths on the same host (`/if/`, `/api/v3/`, `/media/`) are served by Authentik
  and do not get them.
- **Port exposure:** operational ports (postgres, redis, grafana, traefik
  dashboard) and every plaintext listener (traefik `:8081`, authentik `:9000`,
  LDAP `:389`) bind loopback in prod via `${*_PUBLISH}` knobs. Only the ARD-021
  TLS listeners bind the private IP (Transport above). Every knob defaults to
  today's open dev value.
- **Secrets:** Grafana admin credentials, Redis `requirepass` (propagated to the
  backend and both Authentik services), and Traefik `--api.insecure` are
  templated from `env.j2`/ansible-vault. See §07 for the hardening guards.
- **API docs:** `DOCS_ENABLED` defaults on for dev environments and off for
  `ENVIRONMENT=production`, so `/api/docs`, `/api/redoc` and `/api/openapi.json`
  are absent in prod unless deliberately enabled. [AS-BUILT: ARD-017]
- **Service clients:** `AUTHENTIK_SERVICE_CLIENTS`, `OIDC_ACCEPTED_AUDIENCES`
  and `OIDC_SERVICE_PERMISSIONS` default empty — prod has no API-to-API caller
  until one is declared (§08 API-to-API Integration). On the prod path they come
  from one inventory var, `authentik_service_clients` (`{client_id: [permission, …]}`,
  default empty, then none of the keys is rendered). `env.j2` derives all three plus
  each client's `/application/o/<client_id>/` issuer on the internal, localhost and
  browser hosts (`https://<azblink_public_host>` in prod, `server_host:9000` otherwise);
  any further issuer goes in `oidc_extra_issuers`. `config.yml`
  refuses an id that is malformed or already a provider name, and `verify.yml` waits
  for each client's `client_credentials`-only provider. [AS-BUILT]
- **Client-scoped principals (ARD-019):** `OIDC_SERVICE_CLIENT_SCOPES` defaults
  empty. The inventory var `authentik_service_client_scopes`
  (`{service_client_id: {client: <first-party id>, roles: [role, …]}}`) renders it;
  each such client is also in `authentik_service_clients` with an empty list. Dev
  and CI carry `safenest-dev-directory:safenest-dev:admin|staff|resident|visitor`.
  The API refuses to start on an unregistered client, a scoped principal with
  permissions, or nested first-party ids. [AS-BUILT]
- **LDAP `unique` overlay (ARD-019):** `uid` is unique over `ou=people`. A fresh
  volume gets it from the bootstrap `unique-config.ldif`; `ldap_source.yml` adds it
  to a running directory after asserting no duplicate uid exists, and is a no-op
  once present. [AS-BUILT]
- **SIP provisioning (ARD-020):** the same `ldap_source.yml` adds `azbSipContext` to
  the schema and the PBX rule arrives with the ACL (§6.5). Existing SIP endpoints are
  renamed by a one-off `tools/migrate_ard020_sip.py` run (§05 §5.4), not by the
  converge; devices of renamed users re-provision. A PBX per building is a provisioned
  client of `kind: "pbx"` (§08). [AS-BUILT]
- **First-party clients:** `authentik-seed` has no compose profile, so it runs on
  the prod path as well (only the demo `seed` service is dev-only). The inventory
  var `authentik_first_party_clients` (`{client_id: [redirect_uri, …]}`, default
  empty) renders `AUTHENTIK_FIRST_PARTY_CLIENTS` into `.env`; a changed value
  recreates and reruns the seed on the next converge, and `verify.yml` waits for
  each client's provider. Each `client_secret` is read once from the Authentik
  Admin API into that client's vault. [AS-BUILT]
- **Trusted proxies:** `authentik-server` trusts `X-Forwarded-For` only from loopback by default
  (`AUTHENTIK_TRUSTED_PROXY_CIDRS`); prod adds each headless relay's /32 through
  `authentik_trusted_proxy_cidrs`. Authentik's own default trusts every private range. [AS-BUILT]
- **Alert routing (ARD-008 amendment 2026-10-21):** `config.yml` renders
  `obs/grafana/provisioning/alerting/notifications.yml` (gitignored) when
  `alert_webhook_url` is set: contact point `azb-oncall` posts every alert to that
  push-service webhook, and emails `alert_email_to` too when `alert_smtp_host` is
  set (`GF_SMTP_*` come from `.env`). Unset, the file is removed and Grafana stays
  UI-only, which is the dev and CI posture. `alert_tls_targets` renders
  `TLS_EXPIRY_TARGETS` for the certificate-expiry rule. The backup job's
  `.prom` file goes in `/var/lib/azblink/metrics` on the host. [AS-BUILT]
- **Alerting that outlives its host (ARD-008 amendment 2026-10-24):** with
  `alert_heartbeat_url` set, the same file adds contact point `azb-heartbeat` (webhook to
  `$ALERT_HEARTBEAT_URL`, resolve messages off) and an always-firing rule
  `azb-heartbeat` (`count(up) > 0`, no-data and error resolve it) routed only there,
  re-sent every 5 minutes. An external dead-man's switch pages when the posts stop: host,
  Grafana, Prometheus or the notifier dead. The file also carries **Alert delivery
  failing** (`grafana_alerting_notifications_failed_total`, which Alloy now scrapes from
  `grafana:3000`). Both rules exist only with routing, so dev and CI carry neither.
  `verify.yml` sends a test notification through every integration with Grafana's
  receivers-test API and fails the converge on any status but `ok` (Grafana redacts the
  URL in the error it prints). [AS-BUILT]
- **Image builds:** every compose-built image (`directory-api`, `directory-ui`,
  `directory-ui-prod`, the dev `seed`) builds on the default build network, in dev, CI
  and prod alike. Compose v5 (what a fresh host installs) builds only through bake,
  which refuses `network: host` without an `--allow=network.host` entitlement compose
  cannot pass, and it ignores `COMPOSE_BAKE=false`. [AS-BUILT]
- **Identities:** no demo users on the prod path; the first real admin and the
  `cn=authentik-sync` bind account are rendered from vault
  (`ldap_bootstrap.ldif.j2` → `bootstrap.admin.ldif`).

### Guards (defense-in-depth)

- **Ansible `preflight.yml`** (prod-gated, imported first) fails the converge if
  any shipped-default secret remains (LDAP/Authentik/Redis/Grafana/QR-signing/
  `DEV_AUTH_TOKEN`), or `alert_webhook_url` is empty, or `ldap_bind_pw` differs
  from `ldap_admin_password` while `ldap_bind_dn` is `cn=admin` (the API could not
  bind, and the converge would only find out at deep health). A suffix assert refuses
  `ldap_domain` other than `azblink.com`, `ldap_base_dn` other than `dc=azblink,dc=com`
  (any case), and an `ldap_bind_dn` that is not directly under it: `bootstrap.ldif`, the
  client ACL and the `openldap` healthcheck hard-code that suffix, while osixia builds the
  suffix from `LDAP_DOMAIN` alone, so another domain broke the first converge (review-2
  finding 21). Mail defaults that use `ldap_domain` can be overridden. An alerting assert refuses
  a prod converge without `alert_heartbeat_url` (or with it equal to the on-call webhook),
  and with one channel unless `alert_single_channel_accepted` records who accepted that
  risk, when and why. A second channel is email (`alert_smtp_host` + `alert_email_to`).
  A backup assert refuses a prod converge without `backup_offhost_target`,
  `backup_offhost_ssh_key` and an armored `backup_encryption_public_key`, unless
  `backup_local_only_accepted` records who accepted backups on the host alone, when and
  why (ARD-010 amendment 2026-10-26). The fresh-host test sets it.
  Another assert refuses a prod converge without the ARD-021
  transport: the public host, private IP, tunnel token, certificate, CA and key
  must be set, `docker-compose.tls.yml` must be loaded, and every publish knob
  must have the shape in Transport above. `verify.yml` then checks the relay
  path as a relay does (`curl --resolve` + `--cacert`): the discovery `issuer`,
  the API `/api/health`, and an LDAPS handshake. It also runs
  `files/authentik_api_token_check.py` inside `azblink-directory-api`, so the API's
  own `AUTHENTIK_API_TOKEN` must reach `/api/v3/core/users/me/` as an Authentik admin.
  When the vault's `authentik_api_token` differs from the bootstrap token (prod), it must
  also be the key of the seeded `azblink-directory-api` token: the bootstrap token is
  akadmin's too, so `users/me` alone would pass an API left on it (review-2 L12). The
  fresh-host test converges with the two tokens separate, as prod does.
- **Runtime `assert_production_config_safe`** (`config.py`, at import) refuses to
  start a non-dev API on shipped default secrets, or on plaintext LDAP to any host
  but loopback and the compose `openldap` service. Plaintext `:389` on the docker
  network is ARD-021 §3's design; any other LDAP host needs `ldaps://`.
- **Runtime `assert_no_demo_identities`** (backend lifespan, prod-only) is
  **non-bricking**: it logs CRITICAL and raises a health flag rather than
  crash-looping. The `ldap_admin.yml` purge is opt-in
  (`azblink_purge_demo_identities`, default false) and deletes only entries
  marked `businessCategory: azblink-demo`, which `bootstrap.demo.ldif` and
  `seed_demo_data.py` set on every demo person and group (not on IT-Admins). It
  never deletes the real admin or the OIDC admin group, and prints the DNs it
  deletes. Demo entries from before the marker are not purged; the runtime
  guard still reports them (ARD-010 amendment 2026-10-22).

### Backup `[AS-BUILT]`

The `azblink_backup` role (in `site.yml`, tag `backup`) installs
`/usr/local/sbin/azblink-backup` and a nightly systemd timer. Each run writes one
archive: `slapcat` of `cn=config` and the directory, `pg_dump -Fc` of the directory
and Authentik databases, and a Redis RDB snapshot. The host can neither read nor
delete what leaves it (ARD-010 amendment 2026-10-24):
- Archives are encrypted to `backup_encryption_public_key` (`gpg --recipient-file`); the
  private half lives off-host and comes back only for a restore
  (`restore FILE --yes --key KEY`, imported into a throwaway keyring). The role refuses a
  private key, an off-host target without the public key, and the old
  `backup_encryption_passphrase`, and deletes `/etc/azblink/backup.passphrase`.
- Each run pushes only its new archive (`rsync --ignore-existing`, no delete option) to
  `backup_offhost_target`, which must be `user@host:` with no path: the key's `rrsync` names
  the directory, and `seal` reads only that one, so a run refuses a target with a path
  (review-2 M9). Before sending, a dry-run `--delete` probe must be refused:
  the target's key is restricted to `rrsync -wo -no-del`, and a target that accepts
  deletes fails the run. The target keeps its own history; a wiped or compromised host,
  or a DR host's first run, adds to it and never removes from it.
- Retention: every archive under `backup_retention_days` (14), then the newest of each
  ISO week under `backup_retention_weeks` (12). On the host (`prune`) the age is the UTC
  date in the file name, which the host writes itself; other names are skipped. On the
  target, `seal` moves uploads into `sealed/<UTC date>/` and `prune-sealed` applies the
  tiers to those day directories, so names the host chooses never decide what the target
  keeps. A day directory exists only once an upload is sealed into it, and only directories
  that hold an archive count, so a missed night never displaces a week's real archives.
  `check-fresh SEALED URL` (hourly target cron) pings a second dead-man check only while an
  archive was sealed within 26 hours, by the target-set ctime (verifier t-0075).
- `backup_timer_enabled: false` installs the role with the timer stopped, for a DR
  converge before the restore.

Only after the off-host copy succeeds does a run write
`azblink_backup_last_success_timestamp_seconds` to `/var/lib/azblink/metrics/azblink_backup.prom`
(temp file + rename) for Alloy's textfile collector and the "Backup too old" alert; a run
without a target writes none, and prod preflight refuses a target-less converge unless
`backup_local_only_accepted` is set (Guards above). Containers are found by compose labels in `backup_compose_project`.
`azblink-backup restore FILE --yes` restores all four stores. Runbook and drill
record: [`docs/runbooks/backup-restore.md`](../../runbooks/backup-restore.md).
The stack is single-node: no store has a replica (ARD-010 amendment 2026-10-22).

### One-command converge and the fresh-host test `[AS-BUILT]`

`just deploy <inventory> [ansible args]` installs the collections in
`requirements.yml` and runs `site.yml` against `deploy/ansible/inventories/<inventory>`;
production is `just deploy prod --ask-vault-pass -K`. The target needs only SSH, a sudo
user and Python 3 (the §6.8 handoff contract): `host_prep`, `azblink_app` and
`azblink_backup` take it from there to a verified stack, so a fresh host and an
existing one use the same command. A host that cannot reach the repo is cloned
from a bare repo copied from the control node (`azblink_repo_mirror`) instead.

`deploy/ansible/fresh-host/run.py` (`just deploy-fresh-test`, workflow `fresh-host.yml`)
proves it from nothing. It boots a throwaway Ubuntu 24.04 cloud-image VM under
qemu/KVM with user-mode networking and its own Docker, so no host network, daemon or
volume is shared. It then converges with `site.yml` and the `inventories/prod` example
files. The REPLACE fields get test values, the vault keys get random secrets, and a
throwaway CA signs the relay certificate. So preflight, the ARD-021 relay checks,
`ldap_admin.yml` and the backup role all run. Both alert channels post to Alloy's
`/-/reload` (it answers any POST with 200), so `verify.yml`'s test notification
must reach a live endpoint through Grafana. After `verify.yml` it checks Grafana's
`azb-oncall` and `azb-heartbeat` contact points, runs one backup, and fails on any restarting container
(cloudflared excepted: the test has no tunnel). The VM gets 3.5 GB of memory plus 6 GB
of swap on its own disk: the guest's page cache counts against the CI runner unit's
`MemoryHigh=5G`. A SIGTERM (CI cancel) destroys the VM before the run exits.

### Schema migration `[AS-BUILT]` (ARD-010 amendment 2026-10-26)

`migrate.yml` runs between `config.yml` and `deploy.yml`, so the new release's schema is
in place before its API starts and a refusal leaves the running stack on the old release.
It starts `postgres` alone, then runs the runner (§03 §4) in a one-off `directory-api`
container (`docker compose run --no-deps`, `migrations/` mounted at `/migrations`): a dry
run first, a `pg_dump -Fc` to `/var/backups/azblink/pre-migrate-<UTC>.dump` when an
existing install has files to run, then the real run. Any non-zero exit fails the converge.
LDAP needs no step of its own: `ldap_source.yml` already applies the client ACL,
`azbSipContext`, the ppolicy lockout and the `unique` overlay to an initialized volume,
refusing duplicate uids or uidNumbers first. The Authentik seed converges on every `up`.
`tools/upgrade_drill.py` (workflow `upgrade.yml`) starts a private stack at v0.19.0,
writes data through its API, migrates with the PR's tree and checks every old table is
byte-identical, the new schema is in place, a rerun changes nothing and the new API reads
the old data. Operator steps: `deploy/ansible/README.md`, "Upgrading an install".

### Control-node reachability

The dev target sits behind a VPN, so a converge has one precondition beyond
credentials: the inventory's `ansible_host` must route over the tunnel.

Two things about that address are **not** stable and must not be treated as
constants. The tunnel's interface name is assigned per connection (`utunN` on
macOS, and it does change across reconnects), and the interface may carry only an
IPv6 address while still routing the IPv4 subnet — so presence of an `inet` line
on a named interface is not a reachability test. The target address itself moves
when the VM is rebuilt.

The `azb-autodeploy` preflight therefore reads `ansible_host` from the inventory
and asks the routing table which interface serves it, treating `utun*`/`tun*`/
`ipsec*` as reachable. `deploy/lan-to-vpn-gateway.sh` resolves its tunnel the
same way. Both derive; neither pins a name.

---

## 6.8 Host Bootstrap `[PROPOSED: ARD-015]`

§6.7 begins with a host that exists, answers SSH, and has a known address.
`deploy/bootstrap-iso/` is how a host reaches that state.

### Why an ISO carries it

The hypervisor exposes one input channel — upload an ISO, attach as CD/DVD, boot
UEFI, watch VNC. No cloud-init drive, no disk import, no API. The control node
reaches it over a VPN tunnel that a freshly-booted VM has no route back across.
Every per-VM fact must therefore be **inside the ISO before upload**; it cannot
be fetched at boot.

### Build mechanism

`build.py` renders a host config (`hosts/<name>.env`) and produces the ISO by
**copying** the source with `xorriso -boot_image any replay`, overlaying three
paths:

| Path in ISO | Source |
|---|---|
| `/autoinstall.yaml` | rendered from `templates/autoinstall.yaml.tmpl` |
| `/boot/grub/grub.cfg` | Canonical's file verbatim + `templates/grub.cfg.tmpl` appended |
| `/azb/` | `files/` — copied into the installed system by `late-commands` |

`replay` reproduces the source's El Torito records exactly, so the signed shim,
GRUB and kernel stay byte-identical and Secure Boot is unaffected. Autoinstall is
delivered **root-of-medium** (`/autoinstall.yaml` + `autoinstall` on the kernel
command line), not via a `ds=nocloud` datasource — the two are distinct
mechanisms and mixing them yields a half-automated install.

The appended GRUB block sets `default` by `--id`, which is load-bearing: the
stock menu can come up with the highlight on *UEFI Firmware Settings*, where an
unattended boot that times out will sit indefinitely.

`default` governs only what the **timeout** selects, so it is not sufficient on
its own. Stock entry #1 (*Try or Install Ubuntu Server*) boots the installer
interactively, and a keystroke on the VNC console during the menu selects it —
yielding a hand-installed host whose end state (no sshd, no `azb-netinfo`,
unmodified `/etc/issue`) is indistinguishable from the ISO never having been
read. `build.py` therefore appends `autoinstall` to **every** stock casper entry,
so no menu selection can produce an interactive install.

### Addressing

Default is DHCP with a netplan `en*` match, so the virtual NIC name — which
varies by hypervisor and is not determinable from the control node — never has
to be known. Where the address must be known in advance it is pinned by a **DHCP
reservation against the vNIC MAC** (readable in the hypervisor's VM settings
before first boot), not by static config in the ISO. Static config remains
available for segments with no DHCP.

The assigned address is read back on the VNC console two ways: `/etc/issue`
carries it pre-login via agetty's `\4` escape, and `azb-netinfo`
(`/usr/local/bin`, shipped in the ISO) prints interfaces, routing, DNS, SSH
state, host-key fingerprints, and a ready-made `hosts.ini` line.

### Scope boundary

The ISO installs the OS, one user, one authorized key, an address and
`qemu-guest-agent`. Docker, `just`, git and the application stay with
`host_prep` + `azblink_app` (§6.7). The handoff contract is exactly *"SSH-reachable
at a known address with a known key"*.

This boundary is deliberate: a fatter ISO — a package manifest, or a golden disk
image — would become a second definition of what is on a host, and it would
drift from the Ansible roles that are the first.

One install-time repair is in scope, because it blocks §6.7 rather than adding
software: the installer leaves `deb cdrom:` in the target's `sources.list`, and
once the CD is detached apt resolves every package to a `file:/cdrom` path that
no longer exists and fails there without consulting the network mirror. A
late-command comments the line out, so the delivered host can install packages.

### Commands

| Command | Purpose |
|---------|---------|
| `just bootstrap-iso-preview <host>` | Render and print the autoinstall YAML + GRUB block; builds nothing |
| `just bootstrap-iso <host>` | Build `deploy/bootstrap-iso/out/<host>.iso` |
| `just bootstrap-iso-test <host>` | Boot the built ISO under qemu/OVMF, watched on VNC `127.0.0.1:5901` |

Host configs (`hosts/*.env`) are gitignored — they carry a sha512crypt console
password. That password is a VNC-console and `become` credential only; SSH is
key-only (`allow-pw: false`).

### Build host

Builds run on the **workstation** (`brew install xorriso`), not the LAN dev box
of §6.6's remote-synced topology. The ISO is uploaded through the hypervisor's
web panel, so it has to be produced where that browser is; building remotely
would mean shipping 3 GB to the dev box and pulling it straight back.

`deploy/bootstrap-iso/{src,out}` are therefore gitignored **and** listed in the
Mutagen ignore set (`Justfile`, `sync-start`). Mutagen does not read
`.gitignore`, so without those entries the source ISO and every ISO built from
it would sync to the dev box and exhaust its disk.

Every build is verified before upload: the output's El Torito boot configuration
must match the source's, the volume ID must be unchanged, the payload must read
back byte-identical, `grub.cfg` must carry both the `autoinstall` kernel argument
and the `azb-autoinstall` default, **no installer entry may remain interactive**,
and the rendered `autoinstall.yaml` must parse. That covers ISO-surgery faults but
not a semantically invalid autoinstall, which only a real boot
(`just bootstrap-iso-test`, requires qemu) will reject.

The YAML parse requires PyYAML on the build host. It is a hard build failure when
absent (override: `--skip-yaml-check`) rather than a skipped step, because a
check that degrades to a printed note is off by default on the only machine that
builds ISOs — which is what happened, unnoticed, for every ISO built before this.

### Confirming an install applied

`late-commands` write `/etc/azb-bootstrap`, recording that autoinstall ran and
the state of `systemctl is-enabled ssh` at install time. Absence of that file
means the host was **not** provisioned by its ISO, whatever else it resembles,
and its configuration should be treated as unknown. Without it the same
conclusion is reachable only by inferring from absent artifacts, which is slow
and presupposes the suspicion.
