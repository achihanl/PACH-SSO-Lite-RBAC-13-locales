<!-- spec-meta: { section: "04", version: "1.53.0", last_updated: "2026-10-24" } -->

# 04 — Authentication

## 1. Dual Auth Planes

`[AS-BUILT]` -- Core architectural pattern (ARD-002). UC services must never depend on SSO infrastructure.

| Plane | Purpose | Protocol | Store | Availability |
|---|---|---|---|---|
| **Plane A -- UC/LDAP** | XMPP and SIP service authentication | LDAP bind | OpenLDAP `userPassword` (SSHA) | Always available |
| **Plane B -- SSO/Authentik** | Admin web UI authentication | OIDC (PKCE S256) | Authentik (LDAP-backed via source — ARD-007) | Optional, graceful degradation |

**Plane A** authenticates UC clients (XMPP servers, SIP/Asterisk) directly against the single LDAP via bind operations. The `userPassword` attribute (SSHA hash) serves as the credential. This plane has zero dependency on Authentik or any IdP -- if Authentik is completely offline, XMPP and SIP services continue to authenticate normally.

**Plane B** authenticates admin UI users via Authentik OIDC. The FastAPI backend validates Bearer tokens using JWKS signatures. This plane is optional by design -- the system can operate with UC-only functionality when Authentik is not deployed.

Registered **first-party headless clients** (SafeNest first) enter Plane B without the browser redirect: the client's backend relays its own login form to Authentik and receives Authentik tokens (§2.1). Their tokens carry `aud=<client_id>` and are not accepted by this API. [AS-BUILT]

Since ARD-007, Plane B's user store is federated from the platform OpenLDAP via
an Authentik **LDAP source** (`azblink-ldap`). Authentik binds as the provisioned
`cn=authentik-sync,ou=clients` client (read-minus-secrets, ARD-006) to sync
`uid→username / cn→name / mail→email` from `ou=people`; at login Authentik's
`LDAPBackend` binds AS the user to validate the same `userPassword` the PED uses —
no password is copied into Authentik (`sync_users_password=false`). One identity
serves UC (Plane A) and web SSO (Plane B). Authorization is unchanged: sync grants
no admin rights; `require_permission` still gates on ORGDB RBAC (by
`preferred_username`) then `OIDC_ADMIN_GROUP`. [AS-BUILT: ARD-007]

A service token whose `azp` is listed in `OIDC_SERVICE_CLIENT_SCOPES` or the client
registry (`first_party_clients`, ARD-022) (and whose
`preferred_username` is `ak-<azp>-client_credentials`) is a **client-scoped
principal**: token verification answers it 403 on every route except the nine
that admit it, and those hand the route its scope (§07 Client-Scoped Service
Principals). A human's app-password token minted through the same provider is
not scoped. Suspend and terminate revoke the user's Authentik sessions, access
tokens and refresh tokens (§08 §1). [AS-BUILT: ARD-019]

```mermaid
graph LR
    subgraph "Plane A -- UC/LDAP (always available)"
        XMPPServer["XMPP Server"] -->|LDAP bind<br/>userPassword SSHA| LDAP[("OpenLDAP")]
        SIPServer["SIP / Asterisk"] -->|LDAP bind<br/>AstAuthPassword| LDAP
    end

    subgraph "Plane B -- SSO/Authentik (optional)"
        Browser["Admin UI<br/>(React)"] -->|OIDC PKCE S256| Authentik["Authentik IdP"]
        API["FastAPI Backend"] -->|JWKS verify| Authentik
        Browser -->|Bearer token| API
    end

    LDAP -.->|"No dependency"| Authentik
```

**Design rationale (ARD-002):** UC communications are critical infrastructure. A failure in the SSO layer (Authentik maintenance, certificate expiry, network partition) must not disrupt active voice/messaging services. The dual-plane design ensures that Plane A operates independently with no shared state or dependency on Plane B.

## 2. OIDC Flow

`[AS-BUILT]` -- End-to-end Authentik OIDC with PKCE S256. Implementation: `src/frontend/src/lib/oidc.ts` (frontend), `src/backend/oidc_verify.py` (backend).

```mermaid
sequenceDiagram
    participant B as Browser (React)
    participant A as Authentik IdP
    participant F as FastAPI Backend
    participant J as JWKS Endpoint

    B->>B: Generate PKCE verifier (32 bytes)<br/>Compute S256 challenge
    B->>B: Store verifier in sessionStorage
    B->>A: GET /authorize?<br/>client_id, response_type=code,<br/>redirect_uri, scope=openid profile email offline_access,<br/>code_challenge, code_challenge_method=S256
    A->>B: User authenticates (Authentik login form)
    A->>B: Redirect to /auth/callback?code=...
    B->>A: POST /token<br/>grant_type=authorization_code,<br/>client_id, code, redirect_uri,<br/>code_verifier
    A->>B: { access_token (15 min), refresh_token (7 d), id_token, expires_in }
    B->>B: Clear PKCE verifier from sessionStorage
    B->>B: Store tokens in auth-store (Zustand)
    B->>F: API request with Bearer access_token
    F->>J: Fetch JWKS (cached 600s)
    F->>F: Verify signature, audience, issuer
    F->>B: API response
```

The login page's `redirect` parameter is kept only when it resolves, through the URL parser, to a
path on the UI's own origin whose resolved path does not start with `//` (`/\t/evil.example` and
`/.//evil.example` both resolve to `//evil.example` and fall back to `/`).
On a 401 the UI refreshes once and retries: the retry's own error is the answer, and the session
counts as lost only when the refresh fails or the retry is a 401 too.

### 2.1 Headless first-party login `[AS-BUILT]`

A registered client's backend relay runs the Authentik flow executor in place of the browser, then the same PKCE code exchange. azb-AD adds no endpoint. Admission rules, registration and the client registry: §08 *First-Party Headless Login*.

```mermaid
sequenceDiagram
    participant U as User
    participant C as Client app (own login form)
    participant R as Client backend relay
    participant A as Authentik (headless-first-party-auth flow)
    participant L as OpenLDAP

    U->>C: username + password
    C->>R: credentials (never logged)
    R->>A: GET /api/v3/flows/executor/headless-first-party-auth/<br/>X-Forwarded-For: user IP
    A->>R: ak-stage-identification
    R->>A: POST uid_field
    A->>R: ak-stage-password
    R->>A: POST password
    A->>L: LDAPBackend bind as user
    L->>A: bind OK
    A->>R: redirect (flow done) or ak-stage-authenticator-validate
    Note over R: authenticator-validate and no second step built:<br/>refuse, send user to web sign-in (fails closed)
    R->>A: GET /application/o/authorize/<br/>client_id, redirect_uri, PKCE S256 challenge
    A->>R: 302 redirect_uri?code=... (not followed)
    R->>A: POST /application/o/token/<br/>code, code_verifier, client_secret
    A->>R: access (15 min), refresh (7 d), id_token<br/>aud = client_id, groups = [client_id-role, ...]
    R->>C: client session
```

Logout: the relay revokes the refresh token at `POST /application/o/revoke/`, drops the client session and discards its flow cookies. The Authentik session is not deleted (ARD-018 rule 6).

Lockout: after 3 failed passwords for a username, Authentik answers `ak-stage-access-denied` instead of the next challenge (at identification in a fresh session, at the password POST in one identified earlier), before any LDAP bind. The brand flow behind web sign-in (`default-authentication-flow`, admin included) has the same lockout and counts the same failures (G22). Parallel POSTs cannot exceed it: each one first reserves one of the username's 3 LDAP binds, atomically, shared by both flows (G23). One client IP (the relay's `X-Forwarded-For` when the relay is trusted) may spend only 2 of the 3, so a spray from one source is refused at that source and the user still signs in elsewhere (source throttle, B5). §08 *First-Party Headless Login* has the limits and the unblock runbook.

### Frontend (`src/frontend/src/lib/oidc.ts`)

- **PKCE generation:** 32-byte random verifier via `crypto.getRandomValues()`, S256 challenge via Web Crypto API (`crypto.subtle.digest`). Includes a fallback pure-JS SHA-256 implementation for insecure contexts (HTTP over LAN where `crypto.subtle` is unavailable).
- **Discovery:** Fetches `/.well-known/openid-configuration` from `VITE_OIDC_ISSUER`, cached in memory for session lifetime.
- **Authorization:** Redirects to `authorization_endpoint` with PKCE parameters and `scope=openid profile email offline_access`.
- **Groups claim source:** The `groups` claim (consumed by `require_admin`, see §07) rides on the **`profile`** scope — Authentik's built-in `profile` property mapping emits `groups: [group.name for group in request.user.groups.all()]`. There is deliberately no separate `groups` scope: Authentik merges the output of every granted scope mapping with deepmerge's `always_merger`, which **appends** list-valued claims rather than overwriting them, so a second mapping emitting `groups` duplicates every entry (#279). One emitter, always.
- **Token exchange:** POST to `token_endpoint` with `code_verifier`. PKCE verifier is cleared from `sessionStorage` after exchange.
- **Token storage:** Access token, refresh token and id_token in the Zustand auth-store, persisted to `localStorage` (`azblink-auth`). PKCE verifier temporarily in `sessionStorage`. Any script running on the UI's origin can read the refresh token. The prod UI's CSP and headers (§06) narrow what can run there, and the 12-hour refresh lifetime caps an unused stolen token (owner decision on review finding 9; the origin split was declined, and Authentik's admin plane goes behind Cloudflare Access, finding 8).
- **Activity WebSocket:** `/api/activity/ws?token=` admits what `require_admin` admits on REST: `verify_ws_token` refuses a token without `OIDC_ADMIN_GROUP` and a locked account, and the server closes the socket (1008) at the token's `exp`; the client reconnects with its refreshed token (review finding 6).
- **Open tabs share one session:** Authentik rotates the refresh token on every refresh and revokes the old one, so each tab listens for the `storage` event on `azblink-auth` and rehydrates the store from it. A refresh, login or logout in one tab reaches every tab, and no tab refreshes with a revoked token.
- **Token lifetime and refresh:** the `azblink-directory` provider issues a 15-minute access token and a 12-hour refresh token (§06 seed; review finding 9). Each refresh rotates the refresh token, so an active session slides and an unused token dies after 12 h. `__root.tsx` checks every minute and refreshes within 5 minutes of expiry; `api-client.ts` refreshes once on a 401. A tab that slept past expiry and makes a request first refreshes on the 401 and recovers; past the refresh token's 12 h that refresh is refused, and the session-expired modal sends the user back through Authentik (`src/lib/__tests__/api-client.test.ts`). One that only re-renders goes back through `/login`.
- **Logout:** Builds end-session URL with `post_logout_redirect_uri` pointing to `/login`.

### Backend (`src/backend/oidc_verify.py`)

- **JWKS caching:** `PyJWKClient` instance cached for 600 seconds (`_CACHE_TTL_SEC`). Discovery document also cached.
- **Signature verification:** Signing key resolved from JWT `kid` header via JWKS. Supported algorithms: `RS256`, `RS384`, `RS512`, `ES256`, `ES384`, `ES512`.
- **Audience verification:** Validated against `OIDC_ACCEPTED_AUDIENCES` (CSV; defaults to `OIDC_AUDIENCE` = `azblink-directory`), with `verify_aud: True`. Each API-to-API service client's `client_id` is added here (§07 Service Principals). [AS-BUILT: ARD-017]
- **Issuer verification:** Validated against `OIDC_ACCEPTED_ISSUERS` list (see section 3). PyJWT's `issuer=` parameter accepts a list of valid issuers.

## 3. Multi-Issuer Handling

`[AS-BUILT]` -- Implemented in `src/backend/config.py`.

**Problem:** Authentik stamps the `iss` claim based on the URL used to access it. When the same Authentik instance is reachable via multiple URLs (Docker-internal network vs Cloudflare tunnel), tokens may carry different `iss` values:

- Docker-internal: `http://authentik-server:9000/application/o/azblink-directory/`
- Cloudflare tunnel: `https://authentik.keithmoc.dev/application/o/azblink-directory/`

**Solution:** `OIDC_ACCEPTED_ISSUERS` environment variable accepts a comma-separated list of issuer URLs. Each URL is automatically expanded to both with and without trailing slash (since Authentik includes a trailing slash but configuration may omit it):

```python
# config.py -- issuer expansion logic
_raw_issuers = [s.strip() for s in os.getenv("OIDC_ACCEPTED_ISSUERS", "").split(",") if s.strip()]
OIDC_ACCEPTED_ISSUERS: list[str] = []
for _iss in _raw_issuers:
    _stripped = _iss.rstrip("/")
    OIDC_ACCEPTED_ISSUERS.append(_stripped)        # without trailing slash
    OIDC_ACCEPTED_ISSUERS.append(_stripped + "/")   # with trailing slash
```

**URL roles:**

| Variable | Used For | Example |
|---|---|---|
| `OIDC_ISSUER` | JWKS / discovery fetching (Docker-internal, reliable) | `http://authentik-server:9000/application/o/azblink-directory/` |
| `OIDC_ACCEPTED_ISSUERS` | Token `iss` claim validation (both URLs accepted) | Both Docker-internal and Cloudflare tunnel URLs |
| `VITE_OIDC_ISSUER` | Frontend login redirect (browser-accessible) | `https://authentik.keithmoc.dev/application/o/azblink-directory/` |

If `OIDC_ACCEPTED_ISSUERS` is not set, the backend falls back to `OIDC_ISSUER` with both trailing-slash variants.

**Production (ARD-021).** Production has one public host, `azblink_public_host`. Browsers reach it through the Cloudflare tunnel; relays reach the same name over TLS on the private path, with Authentik terminating TLS itself. Both get `iss = https://<azblink_public_host>/application/o/<client>/`. Traefik sets `X-Forwarded-Proto: https` on the tunnel path, and Authentik takes the scheme from that header and the host from `Host`. `env.j2` renders `VITE_OIDC_ISSUER` and the public entry of `OIDC_ACCEPTED_ISSUERS` (one per service client too) from that one variable, beside the docker-internal and `localhost:9000` issuers. With `azblink_public_host` unset (dev inventory), the browser issuer stays `http://<server_host>:9000`. [AS-BUILT]

**Per-provider issuers.** Authentik stamps `iss` per provider (`/application/o/<slug>/`), so every API-to-API service provider adds its own issuer URL(s) to `OIDC_ACCEPTED_ISSUERS`. JWKS still comes from `OIDC_ISSUER`'s discovery: all providers share the seeded signing key, so the `kid` resolves. [AS-BUILT: ARD-017]

**Registry principals (ARD-022).** A scoped principal registered by `POST /api/clients/onboard` needs no
configuration here. `verify_bearer_token` adds its `aud`, and for each accepted issuer
`<prefix>/application/o/<app>/` it accepts `<prefix>/application/o/<service_client_id>/`, from the
in-process registry snapshot (reloaded every 10 s; the last one kept while PostgreSQL is down). A
first-party login client is never added, so this API keeps refusing its tokens. [AS-BUILT]

## 4. Dev Bypass

`[AS-BUILT]` -- Implemented in `src/backend/main.py`, function `_claims_from_auth_header()`.

When the `DEV_AUTH_TOKEN` environment variable is set and a request presents `Bearer <that-token>`, OIDC verification is bypassed entirely. The function returns synthetic admin claims:

```python
{
    "sub": "dev-admin",
    "uid": "dev-admin",
    "preferred_username": "dev-admin",
    "email": "admin@dev.local",
    "groups": [OIDC_ADMIN_GROUP],  # e.g., "IT-Admins"
}
```

**Safeguards:**

- `DEV_AUTH_TOKEN` defaults to empty string (bypass disabled)
- Must never be set in production deployments
- The bypass only activates when both the env var is set AND the Bearer token matches exactly
- Auth failures (invalid OIDC tokens) are logged to `auth_failure_audit` table with client IP and user-agent; an expired but correctly signed token is logged as `expired_token` and does not count toward the per-IP auto-block (§07)

**Test fixtures** (in `tests/conftest.py`):

| Fixture | Auth | Purpose |
|---|---|---|
| `client` | Includes `Authorization: Bearer dev-test-token` | Authenticated API tests |
| `anon_client` | No auth headers | Unauthenticated access tests |

## 5. Session Lifecycle

`[AS-BUILT]` -- Implemented in `src/backend/authentik_client.py`, class `AuthentikClient`.

The `AuthentikClient` uses the Authentik Admin API v3 to cut a user out of SSO on suspend and terminate, and to clear the lockout on unlock. It is stateless and uses Bearer token authentication (`AUTHENTIK_API_TOKEN`).

| Method | Admin API Endpoint | Action |
|---|---|---|
| `_find_user_pk(username)` | `GET /api/v3/core/users/?username=...` | Resolve username to Authentik PK |
| `revoke_user_sessions(username)` | `GET /api/v3/core/authenticated_sessions/?user__username={username}&page=N` (every page) then `DELETE .../authenticated_sessions/{uuid}/` | List and delete the user's AuthenticatedSession objects only: rows whose `user` is not the user's PK are skipped (2026.5 ignores `?user=<pk>` here and lists everyone's) |
| `revoke_user_tokens(username)` | `GET /api/v3/oauth2/access_tokens/?user={pk}` and `.../refresh_tokens/?user={pk}` side by side, then `DELETE .../<kind>/{pk}/` | Delete every OAuth2 access token, then every refresh token (a surviving refresh token keeps minting access tokens) |
| `terminate_user_access(username)` | One `_find_user_pk`, then both above side by side | Full access termination (sessions + tokens); a DELETE answering 404 counts as revoked (a session DELETE cascades to its access tokens) |

**Cut-off (ARD-019 amendment 2026-10-21).** Three more calls take the user out of SSO entirely:

| Method | Admin API Endpoint | Action |
|---|---|---|
| `set_active(username, active)` | `PATCH /api/v3/core/users/{pk}/ {is_active}` | Deactivate on suspend and terminate, reactivate on unsuspend. An inactive user cannot sign in, refresh, or use an app password, and 2026.5 deletes its tokens on deactivation |
| `revoke_app_passwords(username)` | `GET /api/v3/core/tokens/?user__username=...&intent=app_password` then `DELETE .../tokens/{identifier}/` | Terminate only |
| `clear_reputation(username)` | `GET /api/v3/policies/reputation/scores/?identifier=...` then `DELETE .../scores/{pk}/` | `POST /api/users/{uid}/unlock`: the username's rows and its `ldap-bind-budget:<uid>` row |

**Invocation pattern:** `routers/users.py` calls these from suspend, unsuspend, terminate and unlock. Suspend and terminate revoke sessions and tokens first, then deactivate; terminate also deletes app passwords and queues the LDAP source sync. Each step runs even if an earlier one failed. A failure never blocks the LDAP-side change. Any transport failure counts (HTTP error, unreachable, read timeout or reset, non-JSON body: all `AuthentikError`). It is logged at ERROR (`revocation incomplete: ...`, which pages through the **Revocation incomplete** alert), lands in the audit row as `authentik_error`, and the response (still 200) carries `partial: true` and a warning. The `AuthentikClient` is initialized only if both `AUTHENTIK_API_URL` and `AUTHENTIK_API_TOKEN` are configured; otherwise these steps are skipped and the audit row says `not_configured`.

**Gotcha:** Authentik's end-session endpoint (used by the frontend logout flow) does NOT revoke tokens. Active access tokens continue to be valid until expiry (15 minutes for the admin UI). For true revocation on termination, the backend must explicitly `DELETE` each token via the Admin API.

## 6. Graceful Degradation

`[AS-BUILT]` -- Design consequence of dual auth planes (ARD-002).

| Failure Scenario | Plane A (UC/LDAP) | Plane B (SSO/Authentik) |
|---|---|---|
| Authentik down | **Unaffected** -- XMPP/SIP continue via LDAP bind | Login and refresh unavailable. Existing access tokens work until they expire (15 min) while the JWKS cache (600 s) holds, so admin sessions end within 15 min. |
| Authentik DB failure | **Unaffected** | Login and token refresh unavailable. Cached JWKS may sustain validation briefly. |
| LDAP down | XMPP/SIP auth fails | New sign-in fails for directory users, admins included: Authentik checks their password with an LDAP bind (the `azblink-ldap` source keeps no password copy). Only Authentik-local accounts such as `akadmin` still sign in. Sessions already signed in keep their tokens until they expire. User CRUD fails. |
| Redis down | **Unaffected** | Rate limiting fails open (requests proceed without limits). |

**No fallback auth:** There is no breakglass, local login, or alternative auth path for the admin UI. Breakglass was removed as part of the Authentik-only migration (ARD-002). If Authentik is unavailable, admin operations must wait until it recovers. This is an intentional tradeoff -- maintaining a fallback auth path increases attack surface and code complexity for a scenario that should be addressed operationally (Authentik high availability) rather than architecturally.
