<!-- spec-meta: { section: "03", version: "1.57.0", last_updated: "2026-10-26" } -->

# 03 — Data Architecture

## 1. Data Ownership Matrix

`[AS-BUILT]`

PostgreSQL owners are named as the `db/` mixin module that holds the methods. All are reached through the single `ORGDB` object — the mixins are slices of one object, not independently instantiable repositories (§ 3.3).

| Data Domain | Storage | Owner Component | Access Pattern |
|---|---|---|---|
| Identity (users, orgs, groups) | OpenLDAP | `ldap_client.py` | CRUD via ldap3 binds — one connect-and-bind per operation, no pooling; release guaranteed per ARD-013 |
| UC attributes (posixAccount, SIP, XMPP) | OpenLDAP (same entry as identity) | `ldap_client.py` | MODIFY_ADD at creation time |
| Profiles / templates | PostgreSQL (`config_templates`) | `db/templates.py` | CRUD (SQLAlchemy Core) |
| Profile services | PostgreSQL (`profile_services`) | `db/templates.py` | CRUD (child of `config_templates`, CASCADE) |
| Profile assignments | PostgreSQL (`config_template_assignments`) | `db/templates.py` | CRUD |
| Profile change history | PostgreSQL (`config_template_history`) | `db/templates.py` | Append-only |
| Org profiles (legacy) | PostgreSQL (`org_profiles`) | `db/profiles.py` | CRUD |
| Device provisions | PostgreSQL (`device_provisions`) | `db/devices.py` | Issue / consume / revoke |
| User lifecycle audit | PostgreSQL (`user_lifecycle_audit`) | `db/audit.py` | Append-only; retention purge (§ 5) |
| Termination events | PostgreSQL (`termination_events`) | `db/audit.py` | Append-only; retention purge (§ 5) |
| Suspension events | PostgreSQL (`suspension_events`) | `db/audit.py` | Append-only; retention purge (§ 5) |
| Auth failure audit | PostgreSQL (`auth_failure_audit`) | `db/audit.py` | Append-only; retention purge (§ 5) |
| Admin action audit | PostgreSQL (`admin_action_audit`) | `db/audit.py` | Append-only; retention purge (§ 5) |
| Provisioning audit | PostgreSQL (`provisioning_audit`) | `db/audit.py` | Append-only; retention purge (§ 5) |
| Account locks | PostgreSQL (`account_locks`) | `db/security.py` | Lock / unlock / query — degraded-store posture per ARD-012 |
| Blocked IPs | PostgreSQL (`blocked_ips`) + Redis cache | `db/security.py` + `rate_limit.py` | Block / unblock; 60s Redis fast path in `IPBlockingMiddleware` |
| Group profiles / roles (RBAC) | PostgreSQL (`group_profiles`, `group_member_roles`) | `db/rbac.py` | CRUD |
| App settings | PostgreSQL (`app_settings`) | `settingsdb.py` | CRUD (section + key) |
| LDAP client inventory | PostgreSQL (`ldap_clients`) | `db/ldap_inventory.py` + `ldap_activity.py` | Upsert from slapd stats-log collector; admin acknowledge/block |
| Provisioned LDAP clients | PostgreSQL (`ldap_provisioned_clients`) | `db/ldap_inventory.py` + `ldap_provisioning.py` | Intent registry (no secret); create / rotate / revoke — hash lives only in LDAP |
| First-party clients onboarded at runtime (ARD-022) | PostgreSQL (`first_party_clients`) | `db/first_party.py` + `routers/clients.py` | Upsert by `POST /api/clients/onboard`; read through a 10 s in-process snapshot merged with the env registry |
| Dashboard aggregates | PostgreSQL (reads across the above) | `db/dashboard.py` | Aggregate queries only; owns no table |
| Rate limit state | Redis | `rate_limit.py` (slowapi) | TTL-based fixed-window counters |
| OIDC sessions / tokens | Authentik internal DB | `authentik_client.py` | Revocation via Admin API v3 |

## 2. LDAP Entry Structure

`[AS-BUILT]` -- Single-LDAP architecture (ARD-002). One LDAP holds identity and UC attributes on the same DN.

### 2.1 Directory Tree

```
dc=azblink,dc=com                          (base DN)
  +-- ou=org                                (organizational hierarchy -- metadata only)
  |     +-- ou=Engineering
  |     +-- ou=Sales
  +-- ou=people                             (user entries -- inetOrgPerson)
  |     +-- ou=Engineering                  (mirrored from ou=org)
  |     |     +-- uid=alice
  |     +-- ou=Sales
  |           +-- uid=bob
  +-- ou=groups                             (groupOfNames entries)
  |     +-- ou=Engineering                  (mirrored from ou=org)
  |     |     +-- cn=DevOps
  |     +-- ou=Sales
  |           +-- cn=Managers
  +-- ou=clients                            (provisioned LDAP clients, ARD-006)
        +-- cn=<client_id>                  (generic read-minus-secrets client)
        +-- ou=pbx
              +-- cn=<client_id>            (a first-party client's PBX, ARD-020 §4)
```

The three base OUs (`ou=org`, `ou=people`, `ou=groups`) are created at startup by `bootstrap_base_ous()`. Org sub-OUs are mirrored across all three trees by `create_org_ou()`.

**`uid` is unique across the whole `ou=people` subtree `[AS-BUILT]` (ARD-019).** `create_user()`
answers `status: "exists"` for its own exact DN and refuses a uid that lives anywhere else under
`ou=people` (`POST /api/users/create` → 409). The `unique` overlay
(`olcUniqueURI: ldap:///ou=people,<base>?uid?sub`, `deploy/dev/ldap/unique-config.ldif`; ansible
`ldap_source.yml` on running directories, after refusing existing duplicates) enforces the same
in LDAP. Uids starting with `ak-` or a registered `<client_id>-` are reserved.

**`uidNumber` is unique across the whole directory `[AS-BUILT]` (ARD-019, 2026-10-21 amendment).**
The same overlay carries a second URI, `ldap:///<base>?uidNumber?sub`, so no two entries anywhere
under the base share one. Profile uid ranges may overlap, so allocation skips a number another
entry holds (§05 §5.3); the overlay refuses whatever a race lets through.

**A first-party client's people `[AS-BUILT]` (ARD-019).** Users in `ou=<client_id>,ou=people`
(mirrored from the org `ou=<client_id>,ou=org`) are that client's *owned* users; its scoped
principal creates them there. Org names equal to a registered client id are reserved for the
admin group.

### 2.2 User Entry -- Base Identity

ObjectClasses: `top`, `person`, `organizationalPerson`, `inetOrgPerson`

| Attribute | Source | Purpose |
|---|---|---|
| `uid` | Required at creation | Login identifier |
| `cn` | Display name | Common name |
| `sn` | Derived from display name | Surname (required by person) |
| `givenName` | Derived from display name | First name |
| `mail` | Optional | Email address |
| `mobile` | Optional | Phone number |
| `title` | Optional | Job title |
| `employeeNumber` | Optional | Employee ID |
| `manager` | Optional (DN) | Manager reference |
| `userPassword` | SSHA hash | Login + XMPP bind auth (dual purpose) |
| `description` | Status marker | `SUSPENDED` or `TERMINATED` (empty = active) |

### 2.3 UC ObjectClasses (added via MODIFY_ADD)

When a profile has `xmpp_enabled` or `sip_enabled`, `build_uc_attrs()` constructs the UC attributes and `add_uc_attrs_to_user()` adds them to the existing LDAP entry in one modify: only the objectClasses the entry lacks, then a replace of each attribute. The same write enables SIP later on an entry that may already carry `posixAccount` (`PUT /api/users/{uid}/sip`, §05).

**posixAccount** (auxiliary -- NOT `account` which is structural and conflicts with inetOrgPerson):

| Attribute | Default Value | Purpose |
|---|---|---|
| `uidNumber` | Allocated from profile counter, skipping held numbers | POSIX UID, unique across the directory |
| `gidNumber` | `1000` | POSIX GID (fixed) |
| `homeDirectory` | `/home/{username}` | Required by schema |
| `loginShell` | `/bin/bash` | Required by schema |

**The SIP endpoint name is the extension `[AS-BUILT]` (ARD-020 §1).** When SIP is enabled,
the allocated extension goes into all seven naming attributes: `AstAccountName`,
`AstAuthUsername`, `AstAorId`, `AstAuthId`, `AstEndpointId`, `AstEndpointAors` and
`AstEndpointAuth` (`ldap_client.SIP_NAME_ATTRS`). The `uid` stays separate (`uid=humi6830`,
`AstAccountName: 6830`, the vendor model). UED keys the endpoint on `AstEndpointId`, uses
`AstAorId` and `AstAuthUsername` for the AoR and the digest username, and its default `sfilter`
`(AstAccountName=*)` selects entries on `AstAccountName`. No other attribute stores the
extension, and it is fixed once SIP is enabled.

An extension is unique per profile: no two entries with the same `azblinkProfileId` share one.
Allocation and an explicitly requested value both run under a PostgreSQL advisory lock keyed on
the profile (`OrgDB.sip_extension_lock`), check LDAP for the value, and skip or refuse a taken
one. The `unique` overlay cannot scope per profile.

**AsteriskAccount** (added when `sip_enabled`; the class UED enumerates):

| Attribute | Default Value | Purpose |
|---|---|---|
| `AstAccountName` | `{extension}` | Selected by UED's default `sfilter` |

**AsteriskPjsipEndpoint** (added when `sip_enabled`):

| Attribute | Default Value | Purpose |
|---|---|---|
| `AstEndpointId` | `{extension}` | Endpoint name (UED keys on it) |
| `AstEndpointContext` | resolved SIP context (below) | Dialplan context |
| `AstEndpointAllow` | `!all,ulaw,alaw,opus` | Allowed codecs |
| `AstEndpointDisallow` | `all` | Disallow baseline |
| `AstEndpointTransport` | `transport-udp` | SIP transport |
| `AstEndpointAors` | `{extension}` | AoR reference |
| `AstEndpointAuth` | `{extension}` | Auth section reference |

**AsteriskPjsipAuth** (added when `sip_enabled`):

| Attribute | Default Value | Purpose |
|---|---|---|
| `AstAuthId` | `{extension}` | Auth section name |
| `AstAuthType` | `userpass` | Auth mechanism; UED answers `md5` with 500 (ARD-020 amendment 1) |
| `AstAuthUsername` | `{extension}` | SIP digest username |
| `AstAuthPassword` | 24-char random, or set by `PUT /sip` (12+ chars) | SIP digest auth (separate from `userPassword`) |
| `AstAuthRealm` | `SIP_AUTH_REALM` env (default: `asterisk`) | SIP realm |

`AstAuthMd5Cred` is not written: HA1 is deferred until UED is shown to map `md5_cred`.

**AsteriskPjsipAor** (added when `sip_enabled`):

| Attribute | Default Value | Purpose |
|---|---|---|
| `AstAorId` | `{extension}` | AoR name |
| `AstAorMaxContacts` | `1` | Max simultaneous registrations |
| `AstAorRemoveExisting` | `yes` | Replace existing registration |
| `AstAorQualifyFrequency` | `60` | OPTIONS keep-alive interval (seconds) |

**Important:** `userPassword` (SSHA) serves dual purpose -- AD login + XMPP bind auth. `AstAuthPassword` is a separate plaintext secret used for SIP digest auth only.

**Layered SIP context `[AS-BUILT]` (ARD-020 §3).** `azbSipContext` (`AZBlinkAttr:8`, single-valued
`caseIgnoreMatch` string) is MAY on `azblinkUser`, `azblinkGroup` and `azblinkOrganization`; the
API admits only `default` and `all`, and adds the auxiliary class when it first sets the value.
A user's context resolves, most specific first:

1. the user's own `azbSipContext`;
2. else the groups under `ou=groups` that list the user and carry one. A client role group
   `<c>-*` counts only for users exactly under `ou=<c>,ou=people` (owned users). Groups that
   disagree give `default`;
3. else the org entry of the user's own DN (`_infer_org_dn_from_user_dn`), with no walk up to
   ancestor orgs;
4. else `default`. (`from-internal`, the old fixed value, routes nothing on UED.)

The PBX reads one attribute, so the API writes the resolved value into `AstEndpointContext` of
every SIP entry it affects: on a context write at any level, a member add or remove, a group
delete, `move_org`, and SIP enable. A failed fan-out is repaired by repeating the call.

### 2.4 Group Entries

ObjectClasses: `top`, `groupOfNames`

| Attribute | Purpose |
|---|---|
| `cn` | Group common name |
| `member` | DN list of members (minimum one -- service DN used as placeholder) |
| `description` | Optional group description |

**First-party client role groups.** A group named `<client_id>-*` for a client in
`AUTHENTIK_FIRST_PARTY_CLIENTS` also carries `uidObject` with `uid` = `cn`, so the
Authentik LDAP source (keyed on `uid`) syncs it. `create_group()` refuses such a
name unless it is lowercase and the group sits directly under `ou=groups`, never
under an org sub-OU. [AS-BUILT]

These groups never carry RBAC permissions: `PATCH /api/groups/{cn}/permissions`
with a non-empty list answers 422 for every caller (ARD-019 invariant 1). A
client's scoped principal writes only the groups of its configured roles,
exactly `cn=<client_id>-<role>,ou=groups,<base>` (§07). [AS-BUILT]

**`memberOf` on user entries `[AS-BUILT]`.** The `memberof` overlay maintains a
reverse `memberOf` attribute on each user entry as memberships are written. It
must be configured for **`groupOfNames` / `member`** to match the group entries
above:

| Overlay attribute | Required value |
|---|---|
| `olcMemberOfGroupOC` | `groupOfNames` |
| `olcMemberOfMemberAD` | `member` |
| `olcMemberOfMemberOfAD` | `memberOf` |

`osixia/openldap:1.5.0`'s built-in `04-refint.ldif` creates the overlay with
OpenLDAP's defaults — `groupOfUniqueNames` / `uniqueMember` — which this
directory never writes. Left uncorrected, the overlay populates `memberOf` on
**no entry at all**, for any membership past or future, and a consumer filtering
on `memberOf` receives an empty result rather than an error.
`deploy/dev/ldap/memberof-refint-config.ldif` overrides the two attributes;
`tests/test_org_groups.py::TestMemberOfOverlay` asserts the result through the
real API write path.

The overlay computes only on write. Changing its configuration does not
recompute existing entries — memberships written before a correction must be
rewritten to populate.

## 3. PostgreSQL Schema

`[AS-BUILT]` — All 19 tables are defined in `src/backend/db/tables.py` via SQLAlchemy Core `Table()` declarations, registered on one `MetaData`, and auto-created on startup by `metadata.create_all()` inside `OrgDB.init()`.

**Why the definitions stayed in one module.** They are the one part of `orgdb.py` that did *not* move out to the per-context mixins. `create_all()` operates on the whole `MetaData`, so a table defined in a mixin module that no code path happens to import before startup would silently not be created. `settingsdb.py` also reaches in for `app_settings` directly. Splitting them per mixin would buy nothing and risk a missing table on a fresh deploy.

**Two schema authorities.** `metadata.create_all()` only ever *adds* tables; it never alters an existing one. A column change must therefore also land in `migrations/`, or a fresh deploy and an upgraded deploy silently diverge (§ 4).

### 3.1 Table Definitions

**`config_templates`** -- Profile containers with UID allocation counters and device policy. UC services are stored in `profile_services` child table.

| Column | Type | Purpose |
|---|---|---|
| `id` | String(128) PK | UUID identifier |
| `name` | String(255) UNIQUE | Human-readable name |
| `description` | Text | Profile description |
| `template_type` | String(20) | `default` or `custom` |
| `status` | String(20) | `draft` or `active` |
| `max_devices_per_user` | Integer | Device cap per user (default: 5) |
| `next_uid_number` | Integer | UID allocation counter (default: 5000); kept in `uid_range_start`..`uid_range_end + 1` on range changes (§05) |
| `uid_range_start`, `uid_range_end` | Integer | UID range bounds (5000--65533) |
| `created_at`, `updated_at` | DateTime(tz) | Audit timestamps |
| `created_by`, `updated_by` | String(255) | Actor tracking |

**`profile_services`** -- UC services attached to profiles. Each service owns its config and optional allocation counters.

| Column | Type | Purpose |
|---|---|---|
| `id` | String(128) PK | UUID identifier |
| `profile_id` | FK -> `config_templates.id` (CASCADE) | Parent profile |
| `service_type` | String(50) | Discriminator: `xmpp`, `sip`, or future types |
| `enabled` | Boolean | Whether service is active (default: true) |
| `config` | JSON | Service-specific configuration |
| `next_counter` | Integer nullable | Service-specific allocation counter; kept in `counter_start`..`counter_end + 1` on range changes (§05) |
| `counter_start`, `counter_end` | Integer nullable | Counter range bounds |
| `created_at`, `updated_at` | DateTime(tz) | Audit timestamps |
| UNIQUE(`profile_id`, `service_type`) | | One service per type per profile |

**`config_template_assignments`** -- Links profiles to org DNs.

| Column | Type | Purpose |
|---|---|---|
| `id` | String(128) PK | UUID |
| `template_id` | FK -> `config_templates.id` | Profile reference (CASCADE delete) |
| `org_dn` | String(512) UNIQUE | LDAP org DN; also covers its sub-orgs that have none (§05) |
| `assigned_at` | DateTime(tz) | When assigned |
| `assigned_by` | String(255) | Actor |

**`config_template_history`** -- Audit trail for profile changes.

| Column | Type | Purpose |
|---|---|---|
| `id` | String(128) PK | UUID |
| `template_id` | FK -> `config_templates.id` | Profile reference (SET NULL on delete) |
| `timestamp` | DateTime(tz) | When changed |
| `actor` | String(255) | Who made the change |
| `description` | Text | Change description |
| `field`, `old_value`, `new_value` | Text | Field-level diff |

**`device_provisions`** -- Device provisioning token lifecycle tracking.

| Column | Type | Purpose |
|---|---|---|
| `token_hash` | String(128) PK | SHA hash of token |
| `uid` | String(128) | User identifier |
| `profile_id` | String(128) | Profile used for provisioning |
| `issued_at`, `expires_at` | DateTime(tz) | Token validity window |
| `used_at` | DateTime(tz) nullable | Consumption timestamp |
| `status` | String(32) | `active`, `consumed`, `revoked_terminated`, etc. |
| `consumed_by_device_id` | String(128) nullable | Device that consumed the token |
| `consumed_from_ip` | String(45) nullable | Client IP at consumption |
| `client_platform`, `client_version` | String(32) nullable | Device metadata |

**`user_lifecycle_audit`** -- User lifecycle event log.

| Column | Type | Purpose |
|---|---|---|
| `id` | Integer PK auto | Sequence ID |
| `user_uid` | String(255) | Target user |
| `action` | String(50) | `created`, `suspended`, `unsuspended`, `terminated` |
| `performed_by` | String(255) nullable | Actor |
| `detail` | Text nullable | Additional context |
| `timestamp` | DateTime(tz) | Event time |

**`termination_events`** -- Detailed termination records.

| Column | Type | Purpose |
|---|---|---|
| `id` | Integer PK auto | Sequence ID |
| `user_uid` | String(255) | Terminated user |
| `user_dn` | Text nullable | User LDAP DN |
| `org_dn` | Text nullable | Organization DN |
| `terminated_by` | String(255) | Actor |
| `reason` | String(100) | Termination reason |
| `timestamp` | DateTime(tz) | When terminated |
| `actions_taken` | Text | JSON array of actions performed |
| `ldap_disabled` | Boolean nullable | Whether LDAP was disabled |
| `tokens_revoked` | Integer nullable | Count of revoked tokens |
| `authentik_sessions_revoked` | Integer nullable | Count of revoked Authentik sessions |
| `uc_sessions_terminated` | Integer nullable | Count of terminated UC sessions |

**`auth_failure_audit`** -- Authentication failure log.

| Column | Type | Purpose |
|---|---|---|
| `id` | Integer PK auto | Sequence ID |
| `username` | String(255) nullable | Attempted username |
| `failure_reason` | String(100) | Why auth failed: `invalid_token`, or `expired_token` (signature valid, expired; not counted by `count_failures_by_ip`) |
| `timestamp` | DateTime(tz) | When it happened |
| `client_ip` | String(45) | Client IP |
| `user_agent` | Text nullable | Browser/client info |
| `endpoint` | String(255) nullable | Target endpoint |

**`group_profiles`** -- Group metadata (PostgreSQL extension of LDAP groups).

| Column | Type | Purpose |
|---|---|---|
| `cn` | String(255) PK | Group common name |
| `group_type` | String(50) | `distribution`, `security`, etc. |
| `permissions` | JSON | Permission list |
| `created_at`, `updated_at` | DateTime(tz) | Audit timestamps |

**`group_member_roles`** -- Per-member role assignments within groups.

| Column | Type | Purpose |
|---|---|---|
| `group_cn` | FK -> `group_profiles.cn` (CASCADE) | Group reference |
| `member_uid` | String(255) | User identifier |
| `role` | String(20) | `member`, `admin`, etc. |
| `assigned_at` | DateTime(tz) | When assigned |

**`app_settings`** -- Application configuration key-value store.

| Column | Type | Purpose |
|---|---|---|
| `id` | Integer PK auto | Sequence ID |
| `section` | String(50) | Settings group |
| `key` | String(100) | Setting name |
| `value` | Text | Setting value |
| `updated_at` | DateTime(tz) | Last modified |
| UNIQUE constraint on (`section`, `key`) | | Prevents duplicates |

> **Not exhaustive.** The definitions above predate the decomposition and cover 11 of the 20 tables. `org_profiles`, `suspension_events`, `account_locks`, `blocked_ips`, `admin_action_audit`, `provisioning_audit`, `ldap_clients`, `ldap_provisioned_clients` and `first_party_clients` are listed in the ownership matrix (§ 1) and defined in `db/tables.py`, but have no column table here. Tracked separately; `tests/contract/test_db_surface.py` pins the real schema against `db_surface.baseline.json` in the meantime.

### 3.2 Entity Relationships

```mermaid
erDiagram
    config_templates ||--o{ config_template_assignments : "assigned to orgs"
    config_templates ||--o{ config_template_history : "change history"
    config_templates ||--o{ profile_services : "has services"
    config_templates ||--o{ device_provisions : "profile_id"
    group_profiles ||--o{ group_member_roles : "has members"

    config_templates {
        string id PK
        string name UK
        integer max_devices_per_user
        integer next_uid_number
        integer uid_range_start
        integer uid_range_end
    }

    profile_services {
        string id PK
        string profile_id FK
        string service_type
        boolean enabled
        json config
        integer next_counter
    }

    config_template_assignments {
        string id PK
        string template_id FK
        string org_dn UK
    }

    config_template_history {
        string id PK
        string template_id FK
        string actor
        string field
    }

    device_provisions {
        string token_hash PK
        string uid
        string profile_id
        string status
    }

    user_lifecycle_audit {
        integer id PK
        string user_uid
        string action
    }

    termination_events {
        integer id PK
        string user_uid
        integer tokens_revoked
    }

    group_profiles {
        string cn PK
        string group_type
    }

    group_member_roles {
        string group_cn FK
        string member_uid
        string role
    }

    auth_failure_audit {
        integer id PK
        string client_ip
        string failure_reason
    }
```

### 3.3 OrgDB Composition

`[AS-BUILT]` — `OrgDB` was one 2,723-line class holding ~90 methods across all 19 tables. It is now a 136-line class that owns only engine lifecycle (`connect()`, `init()`) and startup seeding; every query method is inherited from a mixin in `db/`, one per bounded context:

| Mixin | Module | Bounded context |
|---|---|---|
| `ProfilesMixin` | `db/profiles.py` | Legacy org profiles |
| `DevicesMixin` | `db/devices.py` | Device provisioning tokens |
| `AuditMixin` | `db/audit.py` | All five audit trails + lifecycle events |
| `SecurityMixin` | `db/security.py` | Account locks, IP blocking |
| `RbacMixin` | `db/rbac.py` | Group profiles, member roles, permissions |
| `TemplatesMixin` | `db/templates.py` | Config templates, profile services, allocation counters |
| `LdapInventoryMixin` | `db/ldap_inventory.py` | Observed and provisioned LDAP clients |
| `DashboardMixin` | `db/dashboard.py` | Cross-context aggregate reads |
| `ClientRegistryMixin` | `db/first_party.py` | First-party clients onboarded at runtime, plus the merged registry snapshot (ARD-022) |

**Composition, not a delegating facade.** The mixins are inherited into one object rather than held as eight repositories behind forwarding methods. The consequence that decided it: the ~150 existing `ORGDB.<method>()` call sites resolve exactly as before, there is no forwarding layer to keep in sync, and there is no second way to reach the same table.

**The mixins are not independently instantiable, by design.** They are slices of one object; `OrgDB` owns the engine. `db/_base.py` declares the contract they may assume (`connect() -> Engine`) under `TYPE_CHECKING` only, so mypy can check each mixin in isolation without adding a runtime base class or changing the MRO.

## 4. Schema Versioning

`[AS-BUILT]` -- Migration files in `migrations/` directory, numbered sequentially.

| Migration | Purpose |
|---|---|
| `004_phase1_uc_qr.sql` | Phase 1 UC core + QR provisioning tables |
| `005_groups_management.sql` | Group profiles and member roles |
| `006_org_management.sql` | Org profile management |
| `007_provisioning_ops_indexes.sql` | Performance indexes for provisioning queries |
| `008_config_templates.sql` | Profile template system |
| `009_settings.sql` | App settings + API keys |
| `010_ued_sync.sql` | UED sync (superseded by single-LDAP) |
| `011_ued_schema_name.sql` | UED schema name |
| `012_ued_self_discovery.sql` | UED self-discovery |
| `013_profile_ued_link.sql` | Profile-UED linking |
| `014_profile_ued_merge.sql` | Profile-UED merge |
| `015_ued_service_endpoints.sql` | UED service endpoints |
| `016_qr_preview_links.sql` | QR preview shareable links |
| `017_single_ldap.sql` | Single-LDAP architecture (drops sync_events, adds UC fields, removes UED columns) |
| `018_drop_api_keys.sql` | Drop API keys table |
| `019_suspension_events.sql` | Suspension events |
| `020_account_locks.sql` | Account lock tracking |
| `020b_admin_action_audit.sql` | Admin action audit |
| `021_blocked_ips.sql` | IP blocking |
| `022_device_provisioning.sql` | Rename provision_tokens to device_provisions, add device fields |
| `023_drop_ued_sync_tables.sql` | Drop UED sync tables |
| `024_remove_sso_qr.sql` | Drop SSO/QR columns from config_templates |
| `025_profile_services.sql` | Create profile_services table, migrate XMPP/SIP data from config_templates |
| `026`-`029` | Provisioning audit, device app name, LDAP client inventory (029 is the runner's `BASELINE`) |
| `030_first_party_clients.sql` | First-party client registry (ARD-022) |
| `031_first_party_clients_relay_ip.sql` | **Current latest** -- `first_party_clients.relay_ip` |

**Fresh deployments** do not need migrations -- `metadata.create_all()` in `OrgDB.init()` creates all tables at startup. A default "Standard Profile" config template is seeded if `config_templates` is empty.

**Existing deployments** are migrated by the converge (ARD-010 amendment 2026-10-26): `migrate.yml` runs `python -m db.migrate /migrations` (`src/backend/db/migrate.py`) in a one-off `directory-api` container before the new API starts. The ledger table `schema_migrations` names each file once applied (`ran` = executed or only recorded). An empty database gets `create_all` and every file recorded. A database with tables but no ledger gets the files up to `029` recorded without running, then the later ones run: every release from v0.5.0 to v0.19.0 has identical columns, types, defaults, indexes and unique constraints, and only added tables. Then `create_all`, then a check that the live schema matches this release exactly: the reference is `create_all` into a scratch schema in the same transaction, compared column by column (type, nullability, default), index by index, with no unknown column and no table a file up to `029` dropped. All of it is one transaction under an advisory lock: a failing file (exit 1) or a refusal (exit 2: any schema older than v0.5.0, whose SIP/XMPP columns and `provision_tokens` would be stranded by a baseline, a hand-changed one, or a ledger naming files this release lacks) changes nothing. Files after `029` must be idempotent (`IF NOT EXISTS`), since dev's API `create_all` may have made their tables first, and must not `BEGIN`/`COMMIT` themselves.

## 5. Data Consistency Rules

`[AS-BUILT]`

| Rule | Detail |
|---|---|
| **User existence** | LDAP is the source of truth. If a user entry exists in LDAP under `ou=people`, the user exists. PostgreSQL tables reference users by `uid` string, not by LDAP DN. |
| **User metadata split** | Identity attributes (name, email, password, status) live in LDAP. Audit trails, lifecycle events, and device provisioning records live in PostgreSQL. |
| **Profile config** | PostgreSQL `config_templates` is the source of truth for provisioning configuration. UC attributes written to LDAP are derived from profile state at creation time. |
| **No cross-store FK** | No foreign keys between LDAP and PostgreSQL. Consistency is maintained by application logic in `routers/users.py` (user creation writes to both stores in sequence). |
| **Org tree mirroring** | `ou=org`, `ou=people`, and `ou=groups` trees are kept in sync by `create_org_ou()`, `rename_org_ou()`, and `delete_org_ou()` which mirror operations across all three trees. `delete_org_ou()` raises `OrgNotEmpty` before deleting anything while the org OU or either mirror holds an entry (user, group, sub-org), and raises when LDAP refuses a delete. |
| **Termination atomicity** | User termination disables LDAP entry (`{DISABLED}` password + `TERMINATED` description), revokes tokens in PostgreSQL, and revokes Authentik sessions -- performed sequentially, not transactionally. Partial failure is logged but not rolled back. |
| **Token lifecycle** | Device provision tokens transition: `active` -> `consumed` or `active` -> `revoked_terminated`. Reverse transitions are not supported. |
| **Audit immutability** | The six audit tables (`user_lifecycle_audit`, `termination_events`, `suspension_events`, `auth_failure_audit`, `admin_action_audit`, `provisioning_audit`) are append-only: no UPDATE. The only DELETE is the retention purge (§ 08 Audit Retention Purge), which removes rows older than `audit.retentionPolicy` days and records its own `purge_audit` admin action. |
