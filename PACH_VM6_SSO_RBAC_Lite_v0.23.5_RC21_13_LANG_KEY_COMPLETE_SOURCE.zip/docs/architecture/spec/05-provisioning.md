<!-- spec-meta: { section: "05", version: "1.26.1", last_updated: "2026-10-21" } -->

# 05 — Provisioning

## 5.1 Profile + Services Model `[AS-BUILT]`

A **profile** (`config_templates` row in PostgreSQL) is a named configuration container that groups organizational policy for UC services. Profiles decouple organizational policy from individual user creation -- an admin configures a profile once, and every user created under that profile inherits the same UC service configuration and device provisioning policy.

**Services** (`profile_services` child table) are independent records attached to a profile. Each service has its own type discriminator, JSON config, enabled flag, and optional allocation counters. This model allows new service types (e.g., Matrix, WebRTC) to be added without schema migrations (ARD-004).

### Profile Fields (`config_templates`)

| Group | Fields | Purpose |
|-------|--------|---------|
| **Identity** | `name`, `description`, `template_type`, `status` | Profile metadata and lifecycle (`draft` / `active`) |
| **Device Policy** | `max_devices_per_user` | Maximum provisioned devices per user (default: 5) |
| **UID Allocation** | `next_uid_number`, `uid_range_start`, `uid_range_end` | POSIX UID counter, shared across all services on this profile |
| **Audit** | `created_at`, `updated_at`, `created_by`, `updated_by` | Timestamps and actor tracking |

### Service Fields (`profile_services`)

| Field | Type | Purpose |
|-------|------|---------|
| `id` | String(128) PK | UUID identifier |
| `profile_id` | FK -> `config_templates.id` | Parent profile (CASCADE delete) |
| `service_type` | String(50) | Discriminator: `xmpp`, `sip`, or any future type |
| `enabled` | Boolean | Whether this service is active |
| `config` | JSON | Service-specific configuration (Pydantic-validated per type) |
| `next_counter` | Integer nullable | Service-specific allocation counter (e.g., SIP extensions) |
| `counter_start`, `counter_end` | Integer nullable | Counter range bounds |
| UNIQUE(`profile_id`, `service_type`) | | One service per type per profile |

### Service Config Schemas

XMPP config: `{ "domain": "xmpp.example.com", "ws_url": "wss://xmpp.example.com/ws" }`

SIP config: `{ "domain": "sip.example.com", "wss_url": "wss://sip.example.com" }`

Unknown service types are accepted with freeform JSON config (extensibility by design).

### Behavior by Service Configuration

- **No services attached:** Users exist in LDAP as plain `inetOrgPerson` entries. Profile provides organizational grouping and device provisioning policy only.
- **With XMPP/SIP services** (either service enabled): During user creation, UC attributes (`posixAccount` + `AsteriskPjsip*` objectClasses) are added to the user's LDAP entry via MODIFY_ADD on the same DN.

### Profile-Org Assignment

Profiles are linked to orgs via the `config_template_assignments` table (`template_id` + `org_dn`). The `resolve_template_for_org()` method walks the org hierarchy to find the applicable profile: the org's own assignment, else its parent's, and so on; the nearest one wins. The walk stops below the org root, so a profile assigned to `ou=org` itself applies to that DN alone and a client org `ou=<c>,ou=org` never inherits one from outside its subtree. DNs compare case-insensitively, ignoring spaces around separators. Service endpoints fall back to `UCCHAT_*` environment variables when no profile is assigned or no services are configured.

### Default-Profile Service Seeding `[AS-BUILT]`

On every backend startup, `OrgDB.init()` ensures the default profile
(`template_type="default"`, else name "Standard Profile") exists and carries its
`xmpp` and `sip` service rows. Seeding is **idempotent and insert-if-missing** — it
never updates or clobbers an existing row, preserving operator/GUI edits and
allocation counters. This self-heals both fresh deployments (which would otherwise
have a profile with no services) and existing deployments upgraded in place.

- `UCCHAT_*` is **mandatory** — `config._validate_uc_config()` raises at backend
  startup if any of the four vars (`UCCHAT_XMPP_DOMAIN`, `UCCHAT_XMPP_WS_URL`,
  `UCCHAT_SIP_DOMAIN`, `UCCHAT_SIP_WSS_URL`) is empty. Both service rows are
  therefore always seeded **enabled**, from real domain/URL config. SIP is seeded
  with extension range 1000–1999; XMPP has no counter.
- The `UCCHAT_*` env is a **bootstrap default only** — the DB service row is the
  source of truth. Provisioning reads service config from the DB first (env is a
  fallback), and the config is **editable at runtime from the admin GUI**
  (profile → Configuration → edit service), so UC servers can be repointed without a
  redeploy. An operator may disable a service from the GUI post-seed.
- Deploy verification: `GET /api/health/deep` reports `default_profile_services_ok`,
  which asserts the `xmpp`/`sip` rows **exist** on the default profile (not that
  they remain enabled — a GUI-disabled service must not fail the gate); the
  Ansible verify gate asserts it.

---

## 5.2 User Creation Flow `[AS-BUILT]`

When the API receives a `POST /api/users/create` request, provisioning proceeds through these steps:

1. **LDAP ADD** -- `ldap_client.create_user()` creates an `inetOrgPerson` entry under the mirrored `ou=people` branch. ObjectClasses: `top`, `person`, `organizationalPerson`, `inetOrgPerson`. Password is stored as SSHA hash.
2. **Group Assignment** (optional) -- If `groups` are specified, each group CN is resolved via `find_group_dn()` and the user DN is added as a member (best-effort, failures silently ignored).
3. **Lifecycle Audit** -- Records a `created` event in `user_lifecycle_audit`.
4. **Profile-Linked UC Provisioning** -- If `profileId` is provided and the profile has enabled services (`profile_services` with `enabled=true`):
   - a. Under `OrgDB.sip_extension_lock(profileId)`, `provisioning.allocate_uc_resources()` reads the profile's services and atomically allocates the next POSIX `uidNumber` from the profile's UID counter that no entry in the directory holds and (if a SIP service exists) the next extension from the SIP service's counter that no entry on the profile already uses (§5.3). The lock is held until the LDAP write in step d.
   - b. `provisioning.generate_sip_password()` generates a 24-character cryptographically random password (alphanumeric + symbols, no ambiguous characters).
   - c. `ldap_client.build_uc_attrs()` constructs the UC objectClasses list (`posixAccount`, `AsteriskAccount`, `AsteriskPjsipEndpoint`, `AsteriskPjsipAuth`, `AsteriskPjsipAor`) and attribute dict. The extension names the endpoint in all seven naming attributes, and `AstEndpointContext` is the user's resolved SIP context (§03 §2.3).
   - d. `ldap_client.add_uc_attrs_to_user()` performs one LDAP MODIFY on the same DN: the missing objectClasses, then each attribute. If the `unique` overlay refuses the uidNumber (another profile took it between check and write), the user stays without UC services and the response warns `uc provisioning failed: uidNumber N is already in use`.
5. **API Response** -- Returns the user DN, status, and (if UC was provisioned) a `provisioning` object containing `uidNumber`, `extension`, `sipPassword`, `xmppDomain`, and `sipDomain`. This information is shown once in the admin wizard.

```mermaid
sequenceDiagram
    participant Client as Admin UI
    participant API as FastAPI
    participant PG as PostgreSQL
    participant LDAP as OpenLDAP

    Client->>API: POST /api/users/create {uid, profileId, ...}
    API->>LDAP: create_user() -- LDAP ADD inetOrgPerson
    LDAP-->>API: {dn, uid, status: "created"}

    alt profileId provided with UC enabled
        API->>PG: get_config_template(profileId)
        PG-->>API: profile {xmpp_enabled, sip_enabled, ...}
        API->>PG: allocate_uid_number(profileId) -- UPDATE RETURNING
        PG-->>API: uid_number
        opt sip_enabled
            API->>PG: sip_extension_lock(profileId) -- advisory lock
            loop until free on the profile
                API->>PG: allocate_extension(profileId) -- UPDATE RETURNING
                PG-->>API: extension
                API->>LDAP: (azblinkProfileId=p)(AstAccountName=ext)?
            end
        end
        API->>API: build_uc_attrs() -- construct objectClasses + attrs
        API->>LDAP: add_uc_attrs_to_user(dn) -- MODIFY_ADD
        LDAP-->>API: success
    end

    API->>PG: record_lifecycle_event("created")
    API-->>Client: {ok, dn, provisioning: {uidNumber, extension, sipPassword, ...}}
```

---

## 5.3 UC Resource Allocation `[AS-BUILT]`

Resource allocation is implemented in `src/backend/provisioning.py`.

### Counter Mechanics

Allocation uses two levels of counters:

- **UID range** (on `config_templates`): `uid_range_start` (default 5000) through `uid_range_end` (default 65533), tracked by `next_uid_number`. Shared across all services on the profile. Ranges of different profiles may overlap, so `provisioning.allocate_uid_number()` takes counter values until one is held by no entry in the directory (`ldap_client.uid_number_taken`); the skipped values are spent.
- **Service-specific counters** (on `profile_services`): e.g., SIP extension range `counter_start` through `counter_end`, tracked by `next_counter`. Each service row owns its own counter independently.

### Atomic Allocation

UID allocation uses PostgreSQL `UPDATE ... RETURNING` on `config_templates`:

```sql
UPDATE config_templates
SET next_uid_number = next_uid_number + 1
WHERE id = :profile_id AND next_uid_number BETWEEN uid_range_start AND uid_range_end
RETURNING next_uid_number - 1
```

Extension allocation uses the same pattern on `profile_services`:

```sql
UPDATE profile_services
SET next_counter = next_counter + 1
WHERE profile_id = :profile_id AND service_type = 'sip' AND next_counter BETWEEN counter_start AND counter_end
RETURNING next_counter - 1
```

If a counter is past its range end, or below its start, the WHERE clause fails to match and a `RuntimeError` ("range exhausted"; `ExtensionRangeExhausted` for SIP) is raised.

**Range changes keep the counter in range `[AS-BUILT]`.** `PUT /api/config-templates/{id}`
(`uidRangeStart`/`uidRangeEnd`) and `PUT /api/config-templates/{id}/services/{sid}`
(`counterStart`/`counterEnd`) set the counter to `max(counter, new start)` in the same `UPDATE`.
The counter never moves back: values below it may already be in LDAP, and nothing there
enforces `uidNumber` uniqueness. A new end below values already issued (`counter > end + 1`)
is refused with 409 and nothing changes; `counter = end + 1` is the exhausted state and is
allowed. A start after the end is refused with 422. A UID counter that moves is recorded in
the profile history as `next_uid_number`.

**Extensions are unique per profile `[AS-BUILT]` (ARD-020 §1).** The SIP counter never reads
LDAP, so a hand-set or migrated extension would be handed out again. `provisioning.allocate_extension()`
takes counter values until one is free (`ldap_client.sip_extension_taken`: no entry with this
`azblinkProfileId` has it as `AstAccountName`). Every allocation and every explicit value runs
under `OrgDB.sip_extension_lock(profile_id)`, a transaction-scoped `pg_advisory_xact_lock` keyed
on the profile, held until the LDAP write, so two concurrent callers cannot pick the same value.
Since SIP ranges are disjoint (below), two profiles no longer share a number inside their ranges;
ranges that predate the rule may still overlap until they are changed.

**SIP ranges are disjoint across profiles and capped in width `[AS-BUILT]` (ARD-020 amendment
2026-10-21).** azb-AD owns the SIP number space for every system it serves; each PBX gets its own
block, sized to its capacity. Creating a SIP service, or changing its `counterStart`/`counterEnd`,
is checked in the write's transaction (`db/templates._claim_sip_range`):

- A width (`end - start + 1`) above `SIP_RANGE_MAX_SIZE` (default 1000), or a start after the
  end, answers 422.
- A range that shares any extension with another profile's SIP range answers 409, naming that
  profile, its id and its range. Every profile counts, drafts and disabled services included;
  adjacent ranges (`end + 1 = start`) are allowed.
- The check takes a transaction-scoped advisory lock (`sip-ranges`) before reading, so two
  concurrent writes cannot both pass it.
- A SIP range is not checked when it does not change: a `PUT` that sends only `config` or
  `enabled`, or the same bounds, succeeds even for a range that breaks a rule from before it
  existed (dev's safenest-dev, 6000-9999). Its next change must satisfy both rules.
- Cloning a profile copies its SIP service without a range; the admin gives the clone its own.
- Default-profile seeding (§5.1) skips the SIP row, with a warning, if 1000-1999 is taken or too
  wide, instead of failing startup.

### ProvisioningResult

`allocate_uc_resources()` returns a `ProvisioningResult` dataclass:

| Field | Type | Condition |
|-------|------|-----------|
| `uid_number` | `int` | Always (required for posixAccount) |
| `extension` | `int | None` | Only when `sip_enabled` |
| `sip_password` | `str | None` | Only when `sip_enabled` (24-char random) |

### SIP Password Generation

`generate_sip_password()` uses `secrets.choice()` over an alphabet of `ascii_letters + digits + !@#%^&*-_=+` (no ambiguous characters like `0/O`, `1/l`). Length: 24 characters. This password is stored in the LDAP `AstAuthPassword` attribute and is separate from the user's login password (`userPassword`).

---

## 5.4 Enabling SIP on an Existing User `[AS-BUILT]` (ARD-020 §2)

`PUT /api/users/{uid}/sip` with `{password?, extension?, context?}`, for `user_management`
holders and for a client-scoped principal on its owned and contained users (§07). Every field is
optional.

- **A suspended or terminated user answers 409** on every call, before anything is written.
- **The first call enables SIP** with the profile resolved for the org (5.1): for a scoped caller its
  client's org `ou=<c>,ou=org`, for an admin the org of the user's own DN. No assignment, or a
  profile without an enabled SIP service, answers 409; a user already carrying another
  `azblinkProfileId` answers 403. The call adds `posixAccount` and `uidNumber` when missing, the
  SIP classes, `azblinkProfileId`, and the §03 §2.3 attributes, in one modify under the profile's
  extension lock. A uidNumber the `unique` overlay refuses (a concurrent allocation took it)
  answers 409; retrying allocates the next free one.
- **`extension`**: enable only. Omitted, it is allocated (§5.3). Supplied, it must lie in the SIP
  service's `counter_start`–`counter_end` and be free on the profile, else 409. After enable the
  same value answers 200 (a retried call is safe) and a different one 409: the extension names
  the endpoint and every phone's username, so it is fixed.
- **`password`**: at least 12 characters (422 otherwise). Omitted on enable, a 24-character one is
  generated and returned once as `sipPassword`. Later calls replace `AstAuthPassword` only;
  `userPassword` is untouched.
- **`context`**: the user level of the SIP context (`default` or `all`); an explicit `null`
  clears it. The resolved value is rewritten into `AstEndpointContext`.

Response: `{ok, uid, enabledNow, extension, context, sipPassword?}`, where `context` is the
resolved `AstEndpointContext`.

### Migrating Pre-ARD-020 Endpoints

Before ARD-020 every SIP entry used the uid in the seven naming attributes and `from-internal`
as its context, which UED answers with 404. `tools/migrate_ard020_sip.py` rewrites them. It runs
inside the API container, which has the backend modules and the LDAP and PostgreSQL settings:

```bash
docker exec -i azblink-directory-api python - --dry-run < tools/migrate_ard020_sip.py
docker exec -i azblink-directory-api python - < tools/migrate_ard020_sip.py
```

- **Naming.** An entry whose seven attributes already hold one numeric value is left alone.
  Otherwise an extension is allocated from its profile (`azblinkProfileId`, else the profile
  assigned to its org, which is then recorded on the entry), skipping used values, and written to
  all seven. The uid and `AstAuthPassword` are kept; `AstAuthMd5Cred` is not written.
- **Context.** The resolved context is written where `AstEndpointContext` differs.
- `--dry-run` prints the plan and writes nothing; it names the profile and range rather than the
  extension, since naming it would move the counter.
- Idempotent: a second run changes nothing. An entry with no SIP profile on itself or its org is
  skipped and listed, and the script exits 1.
- **Devices must re-provision.** The sealed payload's `sipUsername` is the extension now (§5.5),
  so a device provisioned before the migration registers with the old name and fails. The script
  prints how many provisioned devices the renamed users hold.

On 2026-10-20 the dev directory held no SIP entries (read-only count), so the migration changes
nothing there.

---

## 5.5 Device Provisioning `[AS-BUILT]`

Device provisioning uses token-based authorization tracked in the `device_provisions` table. QR code signing (HMAC-SHA256) and QR preview links were removed as part of the profile services restructuring (ARD-004). Device provisioning tokens are created via `POST /api/provisioning/create` and consumed by devices via `POST /api/provisioning/consume`.

### Token Lifecycle

Provision tokens transition: `active` -> `consumed` or `active` -> `revoked_terminated`. Reverse transitions are not supported.

### TTL Enforcement

- Default TTL: `DEVICE_PROVISION_TTL_SEC` (default: 30 days)
- Extension cap: `DEVICE_PROVISION_MAX_EXTEND_SEC` (default: 86400s)
- Device cap per user: `max_devices_per_user` on profile (default: 5, overridden by `DEVICE_PROVISION_MAX_DEFAULT`)

### Sealed Credential Payload

`POST /api/provision/device` seals `{xmppPassword?, sipPassword?, sipUsername?}` to the device's
public key. `sipUsername` is the entry's `AstAuthUsername`, which is the extension since ARD-020
§1, not the uid; clients that need the uid (an XMPP JID) take it from the response's `uid`.
