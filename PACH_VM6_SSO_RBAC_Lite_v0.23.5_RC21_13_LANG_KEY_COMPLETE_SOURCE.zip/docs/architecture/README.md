<!-- spec-meta: { version: "1.57.0", last_updated: "2026-10-26" } -->
# AZBlink Directory — Architecture Specification

**Version:** 1.57.0 | **Last Updated:** 2026-10-26 | **Status:** Current

<!--
  1.56.0 (MINOR) makes verify prove the directory API holds its own Authentik token (§06,
  review-2 L12): when the vault's API token differs from the bootstrap token, the API's token
  must be the key of the seeded azblink-directory-api token, not merely any admin token. The
  fresh-host test now converges with the two tokens separate, as prod does. Numbered in the
  next free slot (1.55.0 is #427's).

  1.55.0 (MINOR) makes a prod converge refuse backups that stay on the host (§06, ARD-010
  amendment 2026-10-26): preflight needs the off-host target, its SSH key and the encryption
  public key, or a written backup_local_only_accepted. An empty target used to warn only
  (audit t-0092). Numbered in the next free slot.

  1.54.0 (MINOR) fixes four deploy and runbook findings of the second production-readiness
  review (§06, ARD-021 amendment 2026-10-24): cloudflared gets a network shared only with the
  edge (and Traefik and Authentik leave the shared cloudflare-tunnel network), so a tunnel
  target naming another container fails with a 502 instead of making every browser one source
  (a port published on the private IP, above all Authentik's :443, is still reachable); the off-host backup target is user@host: with no path, and a run refuses one with
  a path; preflight refuses a directory suffix other than dc=azblink,dc=com; the deregistration
  runbook revokes an onboarded client's ejabberd identity, deletes its registry row and drops
  its group-sync term. Numbered in its assigned slot (1.53.0 is the "Review-2 fixes A" PR's).

  1.53.0 closes review 2's M1, M2 (UI part), M4-M7, L2 and finding 26 (§04, §08).
  The SSE activity feed is gone (it outlived the token). A repeated terminate keeps
  the lock sentinel, and the guarded LDAP writes carry an assertion control, so a
  write racing a terminate is refused. A repeat onboarding keeps omitted roles and
  context; ids prefixing the admin group or meeting a foreign `<c>-*` group are
  refused. The Add client page holds the admin until Done and words a 502 as
  partly added; the UI keeps a retry's own error and same-origin redirects only.
  Fixes; numbered in the assigned slot.

  1.52.0 adds the agent simulation spec, scenarios/agent-onboard-client.md:
  the run an AI agent makes to onboard a building client through the MCP tool
  `onboard_client` (#410), with fixtures, the call and assertion per system,
  the failure cases the agent must handle, cleanup, and which steps the E2E
  journey covers. Docs only, no new behavior; numbered in its assigned slot.

  1.51.0 closes the four non-blocking follow-ups of #405's review (§06, §08): the onboard
  call refuses a relayIp another client already has (409), an explicit `relayIp: null` is
  audited apart from an omission and names the inventory entries to remove, and §06 names
  preflight's "id in both lists" refusal. A fix; numbered in its assigned slot.

  1.50.0 (MINOR) adds the admin UI's Add client page (§08) for ARD-022's
  POST /api/clients/onboard: it shows the returned secrets once, keeps them only in
  page memory, and shows a repeat call's null secrets as already issued. The E2E
  journey (1.48.0) now adds its client through this page. A new screen for an
  existing call, nothing removed; numbered in its assigned slot.

  1.49.0 documents the AI-agent path to onboarding (§08): the stdio MCP server
  tools/directory-mcp, one tool `onboard_client` over POST /api/clients/onboard
  with an operator-supplied admin token. A client of the API, no new API
  behavior. §06: the E2E journey's second test adds a client through it.
  Fixed (§08): a redirect URI over 512 characters is a 422, not a 500.
  Numbered in its assigned slot.

  1.48.0 adds the E2E journey (§06): on a fresh stack with the relay-path
  simulator, the seeded admin signs in through Authentik, onboards a client with
  that session's token, and the client lands in LDAP, Authentik, SIP (simulated
  Asterisk) and XMPP (simulated ejabberd). New workflow `e2e.yml`; screenshots per
  step for the tutorial. Test coverage, no new behavior; numbered in its assigned slot.

  1.47.0 closes the ops highs of the 2026-10-22 review (§06, §08, §04, §02):
  probes follow the compose set and watch cloudflared; off-host backups are
  push-only and encrypted to an off-host key; a dead-man heartbeat, a delivery
  alert and a converge-time test notification; a failed revocation pages and
  shows in the UI. ARD-008 and ARD-010 amendments 2026-10-24. Numbered in its
  assigned slot.

  1.46.0 closes review findings 5, 6 and 9 (§04, §06, §07, §08). A delegated
  `user_management` holder can no longer reset, unsuspend or re-mail an account
  that holds more than it does. The activity WebSocket admits only what REST and
  SSE admit, and closes at the token's `exp`. The prod UI sends a CSP and security
  headers, and its refresh token lives 12 h instead of 7 days (owner decision).
  Fixes; numbered in the assigned slot.

  1.45.0 (MINOR) lets an onboarded client carry its relay IP (§06, §08; ARD-022
  amendment): the onboard call stores an optional `relayIp` and names the converge
  step, and preflight accepts the relay IPs of clients listed in
  `authentik_onboarded_clients`. X-Forwarded-For trust stays deploy-time (ARD-021).
  Numbered in its assigned slot.

  1.44.0 builds every compose-built image on the default build network
  (§06): compose v5 refuses `network: host` under bake, which `just up` and CI
  would hit on their next Docker upgrade. CI drops `COMPOSE_BAKE=false`. A build
  fix, no new capability; numbered in its assigned slot.

  1.43.0 makes the Authentik seed converge on a slow fresh box and on a re-run
  (§06 §6.5): it waits for worker-created flows, mappings and keypairs on the
  AUTHENTIK_WAIT_SEC budget, and keeps authentik-sync's secret while the LDAP
  source still binds (a live bind). Bug fixes, no new capability; numbered in its
  assigned slot.

  1.42.0 closes review findings 3 and 14 (§08): suspend, unsuspend, password resets and
  move_org refuse a terminated user with 409 from the shared LDAP writers, and the Authentik
  user lookup is quoted and exact, so a uid with `#` cannot reach another user's tokens. A
  fix; numbered in its assigned slot.

  1.41.0 (a fix; the number is #401's fixed slot) closes review blocker 1 (§03, §04,
  §06, §07): the API's client IP was Traefik for everyone, so 20 junk tokens from
  anyone auto-blocked the whole API for an hour. On the prod transport the API now sits on the edge network and trusts exactly
  the edge and Traefik, and an expired but genuine token never counts toward the block.
  Config and a counting rule, no new capability. Fixed slots stop parallel PRs
  colliding (#396=1.36.0 … #393=1.40.0).

  1.40.0 (MINOR) adds and accepts ARD-022: POST /api/clients/onboard provisions a
  first-party client (a SafeNest building) end to end in one admin call, and the
  client registry becomes env plus the PostgreSQL table first_party_clients, read
  through a 10 s in-process snapshot. Token trust follows the registry. A new
  capability, nothing removed, so MINOR.

  1.39.0 sets policy_engine_mode `all` on each service and first-party application
  (§06, §07), so a binding added later cannot outvote its access policy (1.33.1's
  account check, the `<client_id>-*` group check). PATCH-sized hardening of existing
  refusals; numbered 1.39.0 by the batch's fixed spec slots (1.36.0-1.41.0) so
  parallel PRs stop colliding.

  1.38.0 fixes `DELETE /api/org/{dn}` (§03, §08): it now answers 409 and deletes
  nothing while the org or a mirror OU holds an entry, instead of ignoring LDAP's results,
  answering ok and deleting the profile. §04 §6 corrects the LDAP-down row: new sign-in
  fails, because Authentik checks passwords with an LDAP bind. A fix; numbered in its
  assigned slot (1.36.0 and 1.37.0 belong to #396 and #400).

  1.37.0 (MINOR) closes review blocker 2 and finding 7 (§06, ARD-010 amendment
  2026-10-22): the seed creates the API's AUTHENTIK_API_TOKEN in Authentik when it
  differs from the bootstrap token, and verify.yml checks it from the API container;
  the demo purge is opt-in (new inventory var) and deletes only entries the demo
  seed marked. New inventory var and seed capability, so MINOR.

  1.36.0 (MINOR) closes the browser-source known issue (ARD-021 amendment 2026-10-22,
  browser source): an nginx edge between cloudflared and Traefik takes CF-Connecting-IP
  only from cloudflared, and each hop on a fixed-address edge network trusts only the one
  before it. Each browser is now its own source at the sign-in throttle. A new component
  and an owner action (tunnel target edge:80), so MINOR.

  1.35.0 (MINOR) adds the one-command converge (`just deploy <inventory>`) and the
  fresh-host test: the production playbook converges a throwaway VM from nothing,
  in CI on deploy PRs and nightly. That run found four bugs that stopped a fresh
  prod converge, now fixed (§06 §6.7). A new deployment capability and CI gate, so
  MINOR.

  1.33.1 (PATCH) closes audit B2 (§06, §07): a service client's provider no longer
  mints a token from a person's app password (seeded access policy), and the API
  refuses such a token with 401. ARD-017 always meant only the generated account
  to act through a service client; a refusal, no new capability, so PATCH.

  1.33.0 (MINOR) hardens the ARD-021 relay path (amendment 2026-10-22): one static
  address per relay box, checked by preflight and trusted as a /32; a relay-path probe
  and a "Relay path down" alert; and a simulator on which CI registers and calls through
  an Asterisk PBX and logs in through ejabberd over the path. New inventory var, metric
  and alert, so MINOR.

  1.32.1 (PATCH) fixes the admin UI across open tabs: each tab adopts another's
  refreshed token (or logout) from the `storage` event, so a second tab no longer
  refreshes with a revoked refresh token. A bug fix, no new capability, so PATCH.

  1.32.0 (MINOR) cuts the admin UI's access token from 8 hours to 15 minutes and
  makes the seed converge token validity on existing installs (ARD-003 amendment
  2026-10-22). It also resolves the ARD-007 and ARD-017 [PROPOSED] markers, both
  shipped. A changed security posture on every install, so MINOR.

  1.31.0 (MINOR) adds and accepts ARD-021: production transport. One public HTTPS
  host through a Cloudflare tunnel for browsers, the same name over TLS on a routed
  private path for relays (Authentik :443, API :8443, LDAPS :636), and plaintext
  listeners on loopback only, enforced by preflight. It replaces ARD-010's
  LAN-plaintext posture. A new deployment capability and invariant, so MINOR.

  1.30.0 (MINOR) adds the backup lane (§06): a nightly backup of LDAP, both
  Postgres databases and Redis with 14-day retention, an off-host copy, a
  success metric for the "Backup too old" alert, and a restore command. New
  operational capability, nothing breaks, so MINOR.

  1.29.0 (MINOR) puts a source throttle in front of the username lockout (ARD-018
  amendment 2026-10-21, audit blocker B5): one client IP may spend only 2 of a
  username's 3 failures, so one source can no longer block a user. A new check on
  both sign-in flows, so MINOR.

  1.28.0 (MINOR) routes Grafana alerts to a push-service webhook (email too when
  SMTP is set) and adds five identity alerts (ARD-008 amendment 2026-10-21). A new
  outbound integration and new metrics, so MINOR.

  1.27.1 (PATCH) closes a gap in the 1.27.0 cut-off: POST /api/users/{uid}/unsuspend
  refuses a terminated user with 409. Unsuspend cleared description=TERMINATED, which
  handed the PBX ACL the SIP secret back, and reactivated the Authentik user. A
  refusal on an existing route, no new capability, so PATCH.

  1.27.0 (MINOR) makes suspend and terminate cut a user off from SSO (ARD-019
  amendment 2026-10-21): Authentik deactivation, app-password deletion and an
  LDAP sync on terminate, reputation clearing on unlock, and Authentik failures
  surfaced as partial responses. New behaviour at two integration points, so MINOR.

  1.26.3 (PATCH) runs terminate_user_access's session and token revocation side by
  side from one user lookup (§08). Same calls and outcome, less latency, so PATCH.

  1.26.2 (PATCH) makes suspend/terminate revoke only the target user's Authentik
  sessions, as §04 and §08 already said they did: the list query's `?user=<pk>` is
  ignored by Authentik 2026.5. Code catching up with the spec, so PATCH.

  1.26.1 (PATCH) makes resolve_template_for_org walk up the org tree as §05
  already said it did: a sub-org without its own profile gets its nearest
  assigned ancestor's. Code catching up with the spec, so PATCH.

  1.26.0 (MINOR) makes SIP extension ranges disjoint across profiles and caps
  their width at SIP_RANGE_MAX_SIZE (ARD-020 amendment 2026-10-21): a new
  invariant over the shared SIP number space and a new config knob, so MINOR.

  1.25.0 (MINOR) makes uidNumber unique across the whole directory (ARD-019
  amendment 2026-10-21): a second unique-overlay URI, allocation that skips a
  held number, and a rollout step for running directories. A new directory
  invariant and deployment step, so MINOR.

  1.24.2 (PATCH) fixes the allocation counters: a profile range change moves
  the counter up to the new start and refuses an end below issued values. A
  bug fix on existing routes, no new capability, so PATCH.

  1.24.1 (PATCH) closes a gap ARD-020 left open: PUT /api/users/{uid}/sip
  refuses a suspended or terminated user with 409 (owner amendment). A
  refusal on an existing route, no new capability, so PATCH.

  1.24.0 (MINOR) implements ARD-020: the SIP endpoint name is the extension
  (unique per profile), PUT /api/users/{uid}/sip enables SIP for admins and for
  a client-scoped principal on its contained users, azbSipContext on user, group
  and org resolves into AstEndpointContext (fallback default), and a per-client
  PBX bind DN under ou=pbx,ou=clients reads AstAuthPassword of that client's
  active owned users. Existing endpoints are renamed by a migration and devices
  re-provision. New routes, schema, ACL rule and caller-visible behaviour, so
  MINOR.

  1.23.1 (PATCH) records ARD-020's PED80 verification results as an amendment:
  the PBX reads plaintext AstAuthPassword (md5 auth failed on UED; HA1 deferred
  until res_ldap.conf maps md5_cred), option D confirmed with UED keying on
  AstEndpointId, the context fallback becomes default (from-internal routes
  nothing on UED), LDAP changes apply in about 1 s. Resolves a gate the owner
  already accepted; still decision-only, so PATCH.

  1.23.0 (MINOR) adds and accepts ARD-020 (owner, 2026-10-20): client SIP
  provisioning for SafeNest phase 4. The SIP endpoint name becomes the
  extension, a scoped principal may enable SIP on its contained users, the SIP
  context is layered user > group > org, and a per-client PBX bind DN reads one
  SIP secret, HA1 or plaintext depending on a PED80 REGISTER test. Decision-only:
  spec sections change with the implementation. Takes the MINOR as ARD-019's
  decision PR did (1.18.0).

  1.22.0 (MINOR) accepts and implements ARD-019: client-scoped service
  principals. A service client bound to one first-party client may write that
  client's fixed role groups and its contained users through nine routes, and
  nothing else. Adds invariants for every caller (no permissions on client role
  groups, reserved client uids and org names, uid unique across ou=people,
  idempotent membership), and suspend now revokes Authentik tokens. New grant
  and caller-visible behaviour, so MINOR.

  1.21.0 (MINOR) audits every group and RBAC write (§08 §4) and enforces the
  audit retentionPolicy setting with an hourly purge (§08, §03 §5). No ARD: both
  implement contracts that already existed (DS-7 admin audit, the stored setting).

  1.20.0 (MINOR) closes G23 under an ARD-018 amendment: an LDAP bind budget
  reserves one of a username's 3 binds atomically before the password stage,
  on both flows, so a parallel burst no longer reaches the bind ~90 times and
  an expired reputation row no longer leaves an unthrottled window. New
  mechanism (§04, §06, §08), so MINOR.

  1.19.0 (MINOR) closes the ARD-017 follow-up: the web provider azblink-directory
  no longer grants client_credentials, so an app-password holder cannot mint an
  API-valid token without the browser flow. The test suite mints user tokens
  through the dev/CI-only azblink-directory-test service client (§06 §6.5).
  Removes a grant, so MINOR.

  1.18.0 (MINOR) adds ARD-019 (proposed): client-scoped service principals
  (G18). A service client bound to one first-party client may write that
  client's role groups and its own users through nine existing routes, and
  nothing else. Decision-only: no spec section changes until the owner accepts
  it and the implementation lands with [PROPOSED: ARD-019] markers. Takes the
  MINOR as ARD-018's decision PR did (1.15.0).

  1.17.2 (PATCH) documents the prod config path for ARD-017 service clients
  (06 is in its spec_sections_affected): §06 Dev↔prod deltas records the
  inventory var authentik_service_clients, from which env.j2 renders the three
  service-client keys and issuers. Defaults stay empty.

  1.17.1 (PATCH) records in §06 §6.2 the Cloudflare Access gate the owner put
  on the dev tunnel hostname authentik.keithmoc.dev (dashboard config, outside
  this repo), with the two OIDC paths it bypasses. No code or compose change.

  1.17.0 (MINOR) closes the lockout follow-ups G22–G24 under an ARD-018
  amendment. Web sign-in (the brand flow, admin included) now has the headless
  lockout, and ppolicy forgets failures after an hour. G23 was measured rather
  than closed: parallel requests are bounded by connections, not by worker
  threads, so pwdMaxFailure stays 5 and §08 records the bound. Asserts new
  behaviour (§04, §06, §08), so MINOR.

  1.16.0 (MINOR) ships E5, the last ARD-018 item: the headless flow's lockout
  (reputation check on the password binding, fail-closed deny guard, tenant
  reputation_upper_limit 0) and loopback-only trusted proxies. Asserts new
  behaviour (§04, §06, §08), so MINOR. Every [PROPOSED: ARD-018] marker in
  §03/04/06/08 becomes [AS-BUILT]. ARD-018 gains an amendment on where the
  check sits and what it does not cover.

  1.15.5 (PATCH) documents G20 under ARD-018 (06 is in its spec_sections_affected):
  §06 Dev↔prod deltas corrects "the seed does not run on the prod path" (only the
  demo seed is dev-only) and records the prod registration path for first-party
  clients. Markers stay: E5 has not shipped.

  1.15.4 (PATCH) documents E3 under ARD-018: §08 First-Party Headless Login gains
  the as-built composition of the shared headless-first-party-auth flow, which
  ARD-018 rule 2 already names. Markers stay: E5 and G20 have not shipped.

  1.15.3 (PATCH) flips ARD-018 to accepted. Its acceptance gate (E2 #332, E2b
  #333, E4 #334 merged) closed on 2026-10-02; `pr:` records the decision PR
  #330. The [PROPOSED: ARD-018] markers in §03/04/06/08 stay: E3, E5 and the
  prod path (G20) have not shipped, the same reading ARD-017 and ARD-007 keep.
  Asserts no new behaviour, so PATCH.

  1.15.2 (PATCH) documents E2b under ARD-018: §03 says first-party client role
  groups carry uidObject + uid=<cn> and must be lowercase at the top of
  ou=groups; §08 says how a role change reaches Authentik (background source
  sync, Authentik group deleted with the LDAP group). ARD-018 lists 03.

  1.15.1 (PATCH) documents the ARD-018 seed knob in §06: the dev seed creates
  first-party clients from AUTHENTIK_FIRST_PARTY_CLIENTS (E2), and prod has no
  path for them yet (G20). ARD-018 (still proposed) now lists 06-deployment.

  1.15.0 (MINOR) adds ARD-018 (proposed): registered first-party headless
  clients, SafeNest first. A client's backend relays its own login form to
  Authentik and gets Authentik tokens; azb-AD adds no login endpoint. Amends
  ARD-002 (Plane B gains the class) and ARD-007 (registered clients' role
  groups sync). New §04 §2.1 sequence and §08 First-Party Headless Login with
  the client registry, all marked [PROPOSED: ARD-018]. Takes 1.15.0, which the
  1.14.2 note had held for the VM6⇄VM7 §08 consumer-contract edit; that edit
  takes the next MINOR when it lands. ARD-016 stays reserved for it, so this
  record is ARD-018.

  1.14.3 (PATCH) gives Dependabot a lane through arch-guard (SOP.md § Commit
  trailers). SOP.md already rules out ARDs for dependency bumps, but a bump to a
  governed file demanded a trailer Dependabot cannot write, freezing #300. The
  guard now matches the SOP it enforces; no spec section changes, so PATCH.

  1.14.2 (PATCH) backfills the ARD status ledger. ARD-007 (#184), ARD-008 (#186)
  and ARD-010 (#206) all shipped between July 3 and July 15 and none was ever
  flipped, so three implemented decisions read `proposed` for two months —
  ARD-008 while the README table beside it already said `accepted`. ARD-015 is
  deliberately NOT flipped: its own summary block sets the gate (a real host
  bootstrapped unattended *and* converged) and its Amendments record that the one
  attempt on real hardware fell back to a hand-install. Records what already
  shipped and changes no spec section, so PATCH. 1.15.0 stays reserved for the
  VM6⇄VM7 §08 consumer-contract edit the 1.14.0 note queues.

  1.14.1 (PATCH) flips ARD-017 to accepted. #304 merged its implementation on
  2026-09-11 while the record still read `proposed`, so the decision was live in
  code and unaccepted on paper — SOP.md § Update Triggers item 3 outstanding
  since that merge. `accepted_at` is the date of this flip; the behaviour has
  been in effect since #304 merged, which is what `decision_effective_date`
  records (the ARD-013 split). Also backfills the PR reference in the frontmatter,
  the mirrored summary block and § References. Asserts no new behaviour — 1.14.0
  already describes everything that shipped — so PATCH.

  1.14.0 (MINOR) adds ARD-017. RBAC grants are now contained — a caller outside
  the admin group may confer only permissions it holds, closing a delegated
  user_management → system_configuration escalation (§07). API-to-API callers
  get service principals: one confidential client_credentials provider per
  service, admitted by OIDC_ACCEPTED_AUDIENCES and authorized statically by
  OIDC_SERVICE_PERMISSIONS (§04, §07, §08). API docs move under /api and are
  off outside dev (§06, §08). New behaviour, so MINOR. The VM6⇄VM7 plan's §08
  consumer-contract edit, drafted as 1.14.0, now lands as 1.15.0.

  1.13.0 (MINOR) publishes §8's directory consumer contract — the attribute map
  a relying party reading this directory over LDAP must be configured with, and
  the canonical active-user filter 1.12.0 queued there. The load-bearing row is
  that the display name is `cn`: azb-AD writes an LDAP `displayName` on no path,
  so a consumer keyed on that default (Nextcloud's `user_ldap`) sees no
  product-created user at all, and fails by dropping them silently rather than
  erroring (VM7 report G9). Also pairs with a behaviour change — a blank
  `displayName` on PATCH is now refused with 422 instead of writing a
  whitespace-only `cn` OpenLDAP happily accepts, which left an entry nameless in
  every consumer. New behaviour, so MINOR.

  1.12.0 (MINOR) makes termination reach relying parties. disable_user() now
  sets ppolicy's pwdAccountLockedTime and removes the user from every group,
  not just userPassword + description. Termination previously left no state an
  external LDAP consumer could filter on, so a relying party kept a terminated
  account enabled and addressable indefinitely (VM7 report G5) — and the group
  removal §2 had claimed as-built was never implemented. New behaviour, so
  MINOR. Consumers should exclude (pwdAccountLockedTime=*).

  1.11.4 (PATCH) records the `memberof` overlay's required attribute pair in §3
  and remounts its override in §6. osixia's built-in creates the overlay for
  groupOfUniqueNames/uniqueMember; AZBlink groups are groupOfNames with
  `member`, so memberOf was populated on nothing at all and a consumer keyed on
  it got an empty result rather than an error (VM7 report G4). The mount had
  been removed on the belief that the built-in was sufficient. Restores the
  overlay to the pair the group entries already use, so no new behaviour: PATCH.

  1.11.3 (PATCH) corrects §2's termination flow, which claimed as-built that
  `disable_user()` "removes from all groups". It never has — it replaces
  `userPassword` and `description` and stops there. The consequence is the part
  worth recording: termination leaves no state an external LDAP consumer can
  filter on, so a relying party keeps a terminated account enabled and
  addressable indefinitely. Found while reviewing the VM7 Nextcloud SSO
  integration (report G5). Describes what the code does, so PATCH; the
  behavioural fix is separate work.

  1.11.2 (PATCH) records where §4's `groups` claim actually comes from. The seed
  created a custom `groups` scope mapping on the assumption Authentik has no
  built-in one; the built-in `profile` mapping has always emitted `groups`, and
  Authentik merges scope-mapping output with deepmerge's always_merger, which
  appends list claims instead of overwriting. Every group therefore appeared
  twice in every token (#279). Membership tests are duplicate-insensitive, so
  nothing broke — which is why it survived. Corrects the recorded scope string
  and names the single emitter; asserts no new behaviour, so PATCH.

  1.11.1 (PATCH) records §6.6's backend lockfile lane as-built. `just
  lock-backend` had been broken for some time: python:3.14-slim ships pip 26.x
  and pip-tools 7.6.0 calls the pre-26 make_requirement_preparer() signature, so
  the unpinned recipe resolved and then died mid-compile — and it emitted the
  lock as root, stalling the Mutagen sync of a remote-synced tree. The recipe now
  pins pip and runs as the invoking uid. Documents existing tooling behaviour and
  corrects a §6.6 table row that omitted the regeneration step; asserts no new
  behaviour, so PATCH.

  1.11.0 (MINOR) adds ARD-015 and §6.8: the host bootstrap lane. §6.7 began with
  a host that already existed and answered SSH; nothing recorded how one got
  there, so it was a VNC procedure in somebody's memory. The hypervisor offers
  one input channel — upload an ISO — and an installing VM has no route back
  across the VPN, so per-VM identity must ride inside the ISO rather than be
  fetched at boot. deploy/bootstrap-iso/ builds that ISO per VM. New deployment
  capability per SOP.md's MINOR trigger table. Scope is bounded to
  SSH-reachability; what gets installed stays with the Ansible roles in §6.7.

  1.10.0 (MINOR) adds ARD-014: backend module governance. surfaces.yaml governs
  src/backend/*.py by enumeration, so a module named in no glob was ungoverned
  and undetectable — the shape of #249, #252, #255 and #259, each found by eye.
  New guard rule 8 fails a PR touching a top-level backend module that matches
  no surface and is not on a new `exempt:` list; the nine long-standing
  ambiguities are classified in ARD-014 § 4. New enforcement capability per
  SOP.md's MINOR trigger table. Depends on 1.9.2, which restored the `ARD:` lane
  this record needed in order to be filed at all.

  1.9.2 (PATCH) fixes guard rule 3 to accept "SOP" as a spec section. It built
  its valid-section set from spec/*.md, and SOP.md lives one level up, so an ARD
  declaring "SOP" failed rule 3 — meaning `ARD: ARD-NNN` could never cover
  governance_metadata or ci_release_gates, and `Spec-Patch: SOP` (which may not
  assert new behaviour) was their only lane. A decisional change to the guard's
  own machinery had no valid lane at all. #247's defect in its third location.
  Defect fix restoring the documented design, so PATCH; unknown sections are
  still rejected.

  1.9.1 (PATCH) drops the `ldap_conn()` call-site enumeration 1.9.0 put in §02's
  LDAP Connection Lifecycle subsection. A named list of caller modules in a
  living as-built section drifts the moment anyone adds or removes one, and
  nothing updates it — the same coverage-by-enumeration shape as #249/#252/
  #255/#259. The invariant stays; the census stays in ARD-013 § 5, where it is
  a dated claim in a dated record. Clarification only, no architectural change.

  1.9.0 (MINOR) records ARD-013 (LDAP connection lifecycle), the last known
  decisional change sitting on main with no decision record. The guaranteed
  release shipped in PR #226's commit 2fa9226 under `Spec-Patch: 02` — a lane
  that may not assert new behaviour — and ARD-011's 2026-07-29 errata carried
  the question forward rather than closing it by silence. §02 gains an "LDAP
  Connection Lifecycle" subsection stating the unpooled-connection posture and
  the invariant that every get_conn() call runs inside safe_ldap() or
  ldap_conn(); §03's ownership matrix names the same posture on the identity
  row. MINOR per SOP.md § Creating a New ARD step 6 — no code changes here, the
  behaviour has been live since 2026-07-29.

  1.8.0 (MINOR) adds the build-time frontend API type-generation pipeline: a new
  integration point between the committed OpenAPI contract (tests/contract/
  openapi.baseline.json) and the frontend build. `api.gen.ts` is generated by
  `openapi-typescript`, gitignored like `routeTree.gen.ts`, produced automatically
  by the npm postinstall/prebuild hooks, with `just ui-types` as the manual
  escape hatch. §06 gains §6.6 (hot reload rules + the as-built record). New
  integration point per SOP.md's MINOR trigger table, so MINOR rather than PATCH.

  1.7.0 (MINOR) brings §02, §03 and §08 up to as-built after the backend
  decomposition (PR #226) and records the two decisions it contained: ARD-011
  (Redis cross-worker event fan-out + the middleware ordering invariant) and
  ARD-012 (authorization posture when the auth stores are unreachable). The
  wire contract is unchanged — the decomposition is a structural change only,
  with the OpenAPI document pinned byte-identical — so this is MINOR rather
  than MAJOR. Cross-worker event delivery is the new capability.

  1.6.0 (MINOR) adds the production deployment artifact (ARD-010): base + override
  compose topology, prod-safe skeleton, static-nginx prod UI, loopback port +
  secret hardening, and LDAP demo-user removal. §06 gains §6.7 (prod topology).
  install.sh removed; Ansible is the sole prod path. See ARD-010.

  1.5.0 (MINOR) resolves the ARD-009 open follow-up — the aggregate directory
  browse endpoints (address-book visibility) move behind require_directory_read
  (operator-only). §07 also gains the require_directory_read documentation it
  had been missing since ARD-009. See ARD-009 amendment (2026-07-08).

  1.3.0 (MINOR) adds the Authentik LDAP source — LDAP-backed web SSO (ARD-007).

  1.2.1 is a PATCH bump: formalized the already-shipped LDAP client
  provisioning + reconciliation capability (v1.2.0) as ARD-006 — a decision
  record, not new behavior. Also corrected the stale classify() rule list in
  section 08 (missing the provisioned_client rule). No spec-behavior change.

  1.2.0 was a MINOR bump: new capability — LDAP client provisioning
  (ou=clients subtree + static read-minus-secrets ACL + ldap_provisioned_clients
  registry + /api/settings/ldap/clients/provisioned endpoints + inventory
  reconciliation) documented in spec section 08. Additive, non-breaking.
  (The prior visible badge lagged the machine spec-meta at 1.1.2 → 1.1.1;
  reconciled there.)
  Bump to 2.0.0 lands in Phase 2 alongside the spec-section sync
  (proposal §7.3, §12).
-->


## Audience

This specification serves two audiences:
- **Human engineers** — structured prose with diagrams for understanding system design, trade-offs, and evolution
- **AI agents (Claude Code, etc.)** — machine-parseable `<!-- spec-meta -->` headers, self-contained sections (~2-4K tokens each), cross-references via relative paths

## How to Read This Spec

- **Quick orientation:** Read [01 — System Overview](spec/01-system-overview.md) for mission, invariants, and tech stack
- **Specific topic:** Jump to any section via the table of contents below — each is self-contained
- **Decision history:** Browse [Architecture Decisions](#architecture-decisions-ards) for the "why" behind major changes
- **Operational reference:** See [CLAUDE.md](../../CLAUDE.md) for dev commands, hot reload rules, and environment setup
- **Historical docs:** See [`docs/archive/`](../../docs/archive/) for archived PRDs, v2.0 specs, and prior plans (read-only)

## Table of Contents

| # | Section | Scope | ~Tokens |
|---|---------|-------|---------|
| 01 | [System Overview](spec/01-system-overview.md) | Mission, actors, design invariants, tech stack | 2K |
| 02 | [Component Architecture](spec/02-component-architecture.md) | Backend, frontend, infrastructure, dependency graph | 3K |
| 03 | [Data Architecture](spec/03-data-architecture.md) | LDAP schema, PostgreSQL tables, data ownership, ER diagram | 3K |
| 04 | [Authentication](spec/04-authentication.md) | Dual auth planes, OIDC flow, multi-issuer, dev bypass | 2.5K |
| 05 | [Provisioning](spec/05-provisioning.md) | Profile + services model, user creation flow, device provisioning | 2.5K |
| 06 | [Deployment](spec/06-deployment.md) | Docker topology, networking, Authentik + host bootstrap, hot reload | 2.5K |
| 07 | [Security](spec/07-security.md) | Rate limiting, audit trails, authorization | 2K |
| 08 | [Integration Points](spec/08-integration-points.md) | Authentik API, LDAP bind, external services, API summary | 2K |

## Architecture Decisions (ARDs)

Decisions are tracked as individual records in [`decisions/`](decisions/). See [`SOP.md`](SOP.md) for the versioning process and ARD lifecycle.

| ARD | Title | Status | Date | PR |
|-----|-------|--------|------|----|
| [ARD-001](decisions/ARD-001-single-ldap-architecture.md) | Single-LDAP Architecture | `accepted` | 2026-03-02 | #12 |
| [ARD-002](decisions/ARD-002-authentik-only-auth.md) | Authentik-Only OIDC Authentication | `accepted` | 2026-03-04 | #13 |
| [ARD-003](decisions/ARD-003-authentik-dev-stack.md) | Authentik Dev Stack | `accepted` | 2026-03-04 | #14 |
| [ARD-004](decisions/ARD-004-profile-services.md) | Profile Services Restructuring | `accepted` | 2026-03-17 | #78, #79 |
| [ARD-005](decisions/ARD-005-spec-governance-hardening.md) | Spec Governance Hardening | `accepted` | 2026-04-20 | #99 (Phase 0) |
| [ARD-006](decisions/ARD-006-ldap-client-provisioning-reconciliation.md) | LDAP Client Provisioning & Reconciliation | `accepted` | 2026-07-03 | #179, #181 |
| [ARD-007](decisions/ARD-007-authentik-ldap-source.md) | Authentik LDAP Source (LDAP-backed Web SSO) | `accepted` | 2026-09-18 | #184 |
| [ARD-008](decisions/ARD-008-observability-stack.md) | Observability Stack | `accepted` | 2026-07-04 | #186 |
| [ARD-009](decisions/ARD-009-directory-read-authorization.md) | Directory-Read Authorization & Lock-DoS Hardening | `accepted` | 2026-07-06 | #187, #196 |
| [ARD-010](decisions/ARD-010-production-deployment-artifact.md) | Production Deployment Artifact (compose topology + hardening + demo-user removal) | `accepted` | 2026-09-18 | #206 |
| [ARD-011](decisions/ARD-011-redis-fanout-and-middleware-order.md) | Redis Cross-Worker Event Fan-Out & Middleware Ordering Invariant | `accepted` | 2026-07-29 | #226, #241 |
| [ARD-012](decisions/ARD-012-auth-degraded-store-posture.md) | Authorization Posture When the Authorization Stores Are Unreachable | `accepted` | 2026-07-29 | (decision-only; #243 records, #257 implements) |
| [ARD-013](decisions/ARD-013-ldap-connection-lifecycle.md) | LDAP Connection Lifecycle — No Pooling, Release Guaranteed at the Operation Boundary | `accepted` | 2026-08-01 | #226 (retro-record; #264) |
| [ARD-014](decisions/ARD-014-backend-module-governance.md) | Backend Module Governance — Explicit Exemption Over Silent Ungovernedness | `accepted` | 2026-08-01 | #268 (issue #265) |
| [ARD-015](decisions/ARD-015-vm-host-bootstrap-iso.md) | Per-VM Autoinstall ISO as the Host Bootstrap Lane | `proposed` | 2026-08-05 | (this PR) |
| [ARD-017](decisions/ARD-017-rbac-grant-containment-and-service-principals.md) | RBAC Grant Containment and API-to-API Service Principals | `accepted` | 2026-09-18 | #304 |
| [ARD-018](decisions/ARD-018-headless-first-party-client-login.md) | Headless First-Party Client Login | `accepted` | 2026-10-02 | #330 (implemented by #332, #333, #334, #336, #337, #338; amended by #345) |
| [ARD-019](decisions/ARD-019-client-scoped-service-principals.md) | Client-Scoped Service Principals | `accepted` | 2026-10-20 | #353 (decision), #367 (accepted + implemented) |
| [ARD-020](decisions/ARD-020-client-sip-provisioning-and-pbx-read.md) | Client SIP Provisioning, Layered SIP Context and PBX Read Access | `accepted` | 2026-10-20 | #369 (decision), #370 (implemented) |
| [ARD-021](decisions/ARD-021-prod-issuer-tls-and-relay-path.md) | Production Issuer, TLS and Relay Path | `accepted` | 2026-10-22 | #388 (decision + implementation) |
| [ARD-022](decisions/ARD-022-first-party-client-onboarding.md) | First-Party Client Onboarding in One Call | `accepted` | 2026-10-22 | this PR (decision + implementation) |

To create a new ARD, copy [`decisions/_TEMPLATE.md`](decisions/_TEMPLATE.md) and follow the process in [`SOP.md`](SOP.md).

## Related Documents

| Document | Location | Scope |
|----------|----------|-------|
| CLAUDE.md | [`../../CLAUDE.md`](../../CLAUDE.md) | Agent operational quick-reference (dev commands, hot reload, env vars) |
| Proposals | [`proposals/`](proposals/) | Forward-facing pre-ARD design proposals |
| Scenarios | [`scenarios/`](scenarios/) | End-to-end runs the E2E suite executes: [agent onboards a client](scenarios/agent-onboard-client.md) |
| Archive | [`../../docs/archive/`](../../docs/archive/) | Historical documentation (read-only, not current) |

## Versioning

This specification follows Semantic Versioning. See [`SOP.md`](SOP.md) for rules and [`CHANGELOG.md`](CHANGELOG.md) for history.
