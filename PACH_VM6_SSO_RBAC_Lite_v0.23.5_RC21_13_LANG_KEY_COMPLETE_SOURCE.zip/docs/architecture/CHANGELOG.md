# Architecture Specification Changelog

All notable changes to the architecture specification are documented here.
Format follows `SOP.md`. The spec as a whole uses SemVer (`README.md` spec-meta).

## [1.57.0] - 2026-10-26

### Added
- §06 Schema migration: the converge migrates an existing install's PostgreSQL before the new
  API starts (`migrate.yml`, no longer a placeholder). It runs `python -m db.migrate` in a one-off
  `directory-api` container: a dry run, a `pg_dump` when an existing install has files to run,
  then the real run; a refusal fails the converge and leaves the old stack serving. Proven by
  `tools/upgrade_drill.py` (workflow `upgrade.yml`): v0.19.0 with data, then this tree.
- §03 §4: the runner's ledger `schema_migrations`, its baseline (files up to `029` are recorded
  without running on an install without a ledger, since v0.5.0 to v0.19.0 share one schema), the
  full live-schema check (columns with type, nullability and default, indexes, retired tables) against this release's `create_all` in a scratch schema, and the one-transaction refusal. Installs older than v0.5.0 are refused, not baselined (verifier t-0104). Migrations
  table lists `026`-`031`.

### Removed
- §06 "Deferred (Bucket B)": the migration runner is built.

### References
- ARD-010 amendment 2026-10-26; production-readiness audit t-0092 (upgrade lane a no-op)

## [1.56.0] - 2026-10-26

### Changed
- §06 Guards: when the vault's `authentik_api_token` differs from the bootstrap token, `verify.yml`
  also requires the API container's token to be the key of the seeded `azblink-directory-api`
  token (`authentik_api_token_check.py own`). The bootstrap token belongs to akadmin too, so the
  `users/me` admin check alone passed an API left on it (review-2 L12, verifier t-0102). The
  fresh-host test no longer sets the API token to the bootstrap token, so CI runs the seed's
  token-creation path and this check as prod does.

## [1.55.0] - 2026-10-26

### Changed
- §06 Guards: preflight refuses a prod converge without `backup_offhost_target`,
  `backup_offhost_ssh_key` and an armored `backup_encryption_public_key`, unless
  `backup_local_only_accepted` records who accepted backups on the host alone, when and why. An
  empty target used to warn only, while the docs said preflight refused a converge without the
  ops values (audit t-0092). The fresh-host test sets the acceptance.

### References
- ARD-010 amendment 2026-10-26; release-readiness audit t-0092

## [1.54.0] - 2026-10-24

### Changed
- §06 Browser source: `azblink_edge_net` is split in two networks. `tunnel` (`.128/25`) holds only
  cloudflared `.130` and the edge `.131`; `edge` (`.0/25`, dynamic addresses from `.64/26`) holds the
  edge `.3`, Traefik `.4`, Authentik `.5` and the API `.6`. A tunnel target naming any other
  container is unreachable and answers 502, where it used to work and make every browser one
  source (review-2 M8). Not covered: ports the box publishes on its private IP stay reachable, because `tunnel` cannot be `internal` (cloudflared dials out): above all Authentik's own TLS listener (`authentik_https_publish`, `:443`). The edge trusts `CF-Connecting-IP` only from `.130`,
  and the API's `cloudflared` probe reads `/ready` through the edge (`edge:2000/ready`).
- §06 Network topology: in the prod set (TLS overlay) Traefik and Authentik leave the external
  `cloudflare-tunnel` network, and ansible no longer creates it there, so no other cloudflared on
  the box reaches them (verifier t-0090).

### Fixed
- §06 Backups: `backup_offhost_target` is `user@host:` with no path. The documented
  `backup@nas.example:incoming` put uploads in `incoming/incoming/` under rrsync, where `seal` never
  looks, so they were never sealed. A run now refuses a target with a path (review-2 M9).
- §06 Guards: preflight refuses an `ldap_domain` other than `azblink.com`, an `ldap_base_dn` other
  than `dc=azblink,dc=com` and an `ldap_bind_dn` not directly under it. The bootstrap LDIF, client
  ACL and healthcheck hard-code that suffix, so another domain broke the first converge (finding 21).
- Client-lifecycle runbook (no spec section): deregistering an onboarded client revokes
  `cn=<c>-ejabberd,ou=clients`, deletes its `first_party_clients` row (exact SQL), and drops its
  `(cn=<c>-*)` group-sync term, which the seed keeps on a converge (review-2 M10, runbook part).
  Step 4 deletes every `<c>-*` role group, listed by query, not four fixed names: an onboarded
  client can have its own roles (verifier t-0090).

### References
- ARD-021 amendment 2026-10-24; production-readiness review 2 (M8, M9, M10, finding 21)

## [1.53.0] - 2026-10-24

### Fixed
- §08: `GET /api/activity/stream` (SSE) is removed. It checked `require_admin` once and then
  streamed the cross-tenant feed with a 30 s keepalive, never re-checking `exp`, the account lock
  or the group; no UI read it. The activity WebSocket is the only live feed (review 2, M1).
- §08: terminate writes `pwdAccountLockedTime` in its own modify after the `userPassword` one, so
  a repeated terminate (which the revocation alert asks for) keeps the sentinel; measured on the
  stack, the old single modify left it empty (review 2, M6; first review, finding 18).
- §08: the guarded writes (`_set_user_passwords`, suspend, unsuspend, move) carry the LDAP
  assertion control (RFC 4528) on "not terminated", so a write racing a terminate is refused
  with 409 instead of handing back a known password (review 2, M7).
- §08: a repeat `POST /api/clients/onboard` that omits `roles` or `sipContext` keeps the stored
  roles and the org's context; the defaults apply to a new client only (review 2, M5). The Add
  client page never sends roles, and sends the context only when the admin picks one.
- §08: onboarding refuses (409) an id that prefixes `OIDC_ADMIN_GROUP` (case-insensitive), for
  a new client any existing `<c>-*` group it did not create, and on a repeat any existing
  `<c>-<role>` group of a role it adds. slapd matches the groups, as the LDAP source does
  (review 2, L2).
- §08: the Add client page holds the admin on the page while the secrets are on screen, until
  Done; a 502 reads "partly added, repeat to resume"; a `null` secret reads "not returned" with
  how to rotate it, not "issued by an earlier call" (review 2, M2, UI part; the 502 body is
  unchanged, spec U8 stays the owner's decision).
- §04: the login `redirect` parameter must resolve to a same-origin path that does not start
  with `//`, so dot segments cannot collapse into a protocol-relative URL (finding 26). After a
  refresh and retry the UI shows the retry's own error; only a failed refresh or a second 401
  ends the session (review 2, M4).

### References
- ARD-001, ARD-022; review 2 (2026-10-24, t-0086) M1, M2, M4-M7, L2; first review findings 18, 26

## [1.52.0] - 2026-10-24

### Added
- `scenarios/agent-onboard-client.md`: the agent simulation spec. The run an AI agent makes to
  onboard a building client through the MCP tool `onboard_client` (#410): actors and
  preconditions (stack, seed state, the operator's admin token), fixtures, each step's tool call or
  API request with its expected result and assertion for LDAP, Authentik, SIP, XMPP and the relay,
  the failure cases the agent must handle (409, 422, 403, 401, 429, 502, 503, and #411's
  shared relay IP), the relay clear the tool cannot send, cleanup, and a map
  from each step to the journey test or backend test that covers it. Lists the steps no test covers,
  among them a 502 and its resume, and the LDAP secrets a new client's 502 at step `authentik` loses.
- §06 E2E journey and §08 onboarding point to it. Docs only, no new behavior.

### References
- ARD-022; #405, #406, #409, #410, #411

## [1.51.0] - 2026-10-24

### Fixed
- §08: `POST /api/clients/onboard` refuses a `relayIp` that another registry row already has
  (409, audited as refused, nothing changed), the check preflight already made at converge. The
  box's own private IP and the browser edge stay preflight-only: the API has neither setting.
- §08: `relayIp: null` clears the stored relay IP and the response's `relay` is
  `{ip: null, operatorStep}`, naming the `authentik_onboarded_clients` and `authentik_relay_ips`
  entries to remove. The audit row's `requested.relayIp` is present only when the call sent it,
  so a clear is no longer recorded like an omission.
- §06: the preflight refusal list names an id in both `authentik_first_party_clients` and
  `authentik_onboarded_clients`. The client-lifecycle runbook's deregistration removes an
  onboarded client from both inventory lists.

### References
- ARD-022 amendment 2026-10-22 (relay addresses of onboarded clients); #405 review (t-0072)

## [1.50.0] - 2026-10-24

### Added
- §08 Onboarding a building: the admin UI's Add client page (`/configuration/clients/new`)
  makes `POST /api/clients/onboard` for an admin. Client-side checks mirror the request model;
  API refusals show as `<status>: <detail>`. The returned secrets are shown once with copy
  buttons and kept only in page memory (never browser storage, the URL or a log); leaving
  while the call is pending is blocked (router blocker, and a `beforeunload` prompt), since the
  response is the secrets' only copy; a repeat call's `null` secrets show as already issued.
  The optional relay IP (1.45.0) is checked like the request model and sent only when set; a
  stored one shows with the response's converge step. Non-admins see no form and no sidebar link.
- §06 E2E journey: the admin adds the client through this page, adds it again to show the
  no-secrets state, and checks no secret reaches browser storage or the URL (screenshots
  `add-client-form`, `add-client-secrets`, `add-client-repeat`).

### References
- ARD-022

## [1.49.0] - 2026-10-24

### Added
- §08 Onboarding: the AI-agent (MCP) path. `tools/directory-mcp/server.py` is a stdio MCP server
  with one tool, `onboard_client`, that calls `POST /api/clients/onboard` with the same arguments
  and an admin's bearer token from its environment (`DIRECTORY_API_URL`, `DIRECTORY_ADMIN_TOKEN`)
  or from the per-call `adminToken` argument. It never mints or stores credentials. Admin tokens
  last 15 minutes, so a 401 says the token has expired and to supply a fresh one. It takes
  1.45.0's `relayIp` too. It checks arguments as the request model does, sends only
  the arguments given, returns API errors as tool errors with their message, refuses redirects,
  and logs neither the token nor the response's secrets. It strips whitespace around a token and
  refuses a malformed one, and maps transport failures to fixed messages, so a token is never
  echoed (http.client's header error quotes it whole). Registration: `tools/directory-mcp/README.md`.
- §06 E2E journey: a second test drives that server from a plain JSON-RPC client, adds a second
  client, and runs the same LDAP, Authentik, SIP and XMPP checks. Its UI checks wait for the API
  reply each page renders from (`/api/orgs/tree` scans every LDAP user and can outlast expect's
  5 s right after an onboard), and its failure messages never print a successful onboard's body. `e2e.yml` runs the server's
  unit tests (fake API, parity with `ClientOnboardReq`, one stdio run) and also triggers on
  `tools/directory-mcp/**` and `src/backend/schemas/clients.py`.

### Fixed
- §08 Onboarding: a redirect URI over 512 characters is a 422 like every other refused URI. The
  request model's validator raised `UnboundLocalError` on it, so the API answered 500.

### References
- ARD-022

## [1.48.0] - 2026-10-24

### Added
- §06 Transport: the E2E journey, `src/frontend/e2e/journey/` (Playwright project `journey`,
  workflow `.github/workflows/e2e.yml`, nightly, tags, dispatch and PRs touching it), on a
  fresh disposable stack with the relay-path simulator. The seeded web admin signs in through
  Authentik, onboards a client with that session's own token (ARD-022), and the test checks
  the client's LDAP entries and Authentik objects, a resident's SIP REGISTER through `pbx-sim`
  configured with the returned PBX identity, and XMPP logins for the bridge and the resident
  through `xmpp-sim` with the returned ejabberd identity. Numbered screenshots per UI step
  (artifact `e2e-screenshots`) for the tutorial.
- §06: `xmpp-sim` starts from a copy of `relay-sim/ejabberd.yml` instead of a bind mount, so a
  test can re-point it and `ejabberdctl reload_config`.

### References
- ARD-021, ARD-022

## [1.47.0] - 2026-10-24

### Fixed
- §06 Transport: prod probed the dev-only `directory-ui`, so "Platform service down" fired from
  go-live, and nothing probed cloudflared, so a dead tunnel was silent (review finding 10). The UI
  probe follows the compose set (`UI_PROBE_URL`, prod: `directory-ui-prod:8001/health`), and the TLS
  overlay probes cloudflared's `/ready` (`--metrics 0.0.0.0:2000`) and the `edge` hop.
- §06 Backup: the off-host copy was a `--delete-after` mirror, and the host held both the symmetric
  passphrase and a delete-capable key (finding 11). Archives are now encrypted to a public key whose
  private half lives off-host (`restore ... --key`), each run pushes only its new archive to a target
  that must refuse deletes (`rrsync -wo -no-del`, probed before every push), retention keeps 14
  dailies plus 12 weeklies, and `backup_timer_enabled: false` keeps a DR host's timer off until the
  restore. The target seals uploads into `sealed/<UTC date>/` (`seal`) and prunes whole seal-date
  directories (`prune-sealed`), so upload names, which the host chooses, never decide retention.
  Only day directories holding an archive count, and `seal` creates one only when it moves
  something, so a missed night or Sunday never displaces a week's archives. `check-fresh` pings a
  target-side dead-man check (healthchecks.io) only while an archive was sealed within 26 h.
  Host `prune` skips names it does not write instead of exiting 1.
- §06 Dev↔prod deltas, Guards: alerting had one channel, ran on the host it watched, and had no
  dead-man's switch (finding 12). An always-firing heartbeat goes only to `alert_heartbeat_url`, an
  external dead-man service; **Alert delivery failing** watches Grafana's own failed notifications
  (Alloy scrapes Grafana), including the first failure per integration, whose counter Grafana
  creates at 1; `verify.yml` sends a test notification through every integration; prod
  preflight requires the heartbeat URL and a second channel or `alert_single_channel_accepted`.
- §08, §04, §02: a partly failed suspend or terminate was invisible (finding 13). Each failed
  Authentik step logs `revocation incomplete:` and the critical Loki rule **Revocation incomplete**
  pages. `AuthentikClient` maps a read timeout, reset or non-JSON body to `AuthentikError`, which
  used to escape as a 500 after the LDAP lock with no marker line. Suspend and unsuspend audit-row failures are logged and returned as an `audit` warning
  instead of a bare `pass`; the termination dialog and its report show "Termination incomplete" with
  each warning.

### References
- ARD-008 amendment 2026-10-24, ARD-010 amendment 2026-10-24; 2026-10-22 production-readiness
  review findings 10-13

## [1.46.0] - 2026-10-24

### Fixed
- §07 (review finding 5): a delegated `user_management` holder could reset an `IT-Admins`
  member's password and sign in as them. `assert_can_take_over` now refuses a reset, an
  unsuspend or a mail change by a caller outside the admin group when the target is in
  `OIDC_ADMIN_GROUP` or holds an RBAC permission the caller lacks (403). It fails closed
  (503). `tests/test_rbac.py::TestRBACNoEscalation`, `tests/unit/test_takeover_containment.py`.
- §07, §08 (verifier on #407): LDAP matches uid without regard to case or surrounding spaces,
  while RBAC rows, Authentik lookups and audit rows compare exactly. `IT-BOSS` passed the
  takeover check and reset `it-boss`; a case-variant suspend or terminate revoked nothing in
  Authentik; removing `JSMITH` from a group left `jsmith`'s RBAC row. User write routes and
  group member add/remove now act on the uid LDAP found. `tests/unit/test_uid_canonical_routes.py`.
- §04, §08 (review finding 6): the activity WebSocket checked only the token's signature, so
  any signed-in resident could read the live, cross-tenant audit feed, even after the token
  expired. `verify_ws_token` now requires `OIDC_ADMIN_GROUP` and an unlocked account, and the
  socket closes at the token's `exp`. `tests/test_activity_realtime.py`,
  `tests/unit/test_activity_ws_auth.py`.
- §06 (review finding 9): the prod UI sent no CSP or security headers, so it could be
  framed and any injected script could run. nginx now sends a CSP (`script-src 'self'`,
  `frame-ancestors 'none'`, `connect-src` limited to the UI and the issuer), XFO, nosniff,
  Referrer-Policy, HSTS and COOP on every location. `tests/unit/test_ui_security_headers.py`.

- §04, §06 (review finding 9, owner decision): the admin UI's refresh token lived 7 days in
  `localStorage`, so a stolen one minted admin tokens for a week. The `azblink-directory`
  provider now issues a 12-hour refresh token; a reseed patches only that field on an existing
  provider. First-party relay providers stay at 7 days. Past 12 h the UI's refresh is refused
  and the session-expired modal sends the user back through Authentik.
  `tests/unit/test_authentik_seed_first_party.py`, `src/lib/__tests__/api-client.test.ts`.

### Known gaps (not closed here)
- §04: the refresh token stays in `localStorage`, and the UI shares its origin with Authentik.
  The owner declined the origin split; finding 8 goes to Cloudflare Access (owner-run).

## [1.45.0] - 2026-10-24

### Added
- §08: `POST /api/clients/onboard` takes an optional `relayIp` (one canonical IPv4 host, not
  unspecified, loopback or multicast), stores it on the registry row
  (`first_party_clients.relay_ip`, migration `031`, also applied at startup) and keeps it on a
  repeat without `relayIp`. When one is stored the response carries
  `relay: {ip, operatorStep}`. The call does not trust the address: X-Forwarded-For trust
  stays deploy-time (ARD-021).
- §06: preflight takes `authentik_onboarded_clients` (API-onboarded clients whose relay box
  uses the relay path). Each listed id needs a relay IP like an env client, its relay IP is
  accepted, and no id may be in both client lists. An onboarded client that does not relay
  is in neither list, and nothing is asked of it. The browser-edge check (#401) applies to
  these relay IPs too.

### References
- ARD-022 amendment 2026-10-22 (relay addresses of onboarded clients); ARD-021; #393, #401

## [1.44.0] - 2026-10-24

### Fixed
- §06 Dev↔prod deltas: dev and CI image builds failed on compose v5, which builds only
  through bake and refuses `network: host` (`pass "--allow=network.host"`), and which
  ignores the `COMPOSE_BAKE=false` CI set in #349. `directory-api`, `directory-ui`,
  `directory-ui-prod` and the dev `seed` now build on the default build network;
  `docker-compose.prod.yml` no longer needs its reset, and `pr-checks.yml` and `qa.yml`
  drop `COMPOSE_BAKE`. Checked with compose v5.6.1 + buildx 0.38.1 (dev and prod) and
  compose v2.40.3 (dev), all through bake.

### References
- ARD-010; #349, #395

## [1.43.0] - 2026-10-24

### Fixed
- §06 §6.5: the Authentik seed waited 12 polls (60 s) for what Authentik's worker creates
  after the API answers, then went on with a short list. On a loaded fresh box the web
  provider got no `profile` scope mapping, so tokens carried no `groups` (CI run
  39803379493). On a TLS deploy the seed exited before the brand certificate was
  discovered. Flows, scope and LDAP source mappings, the sync schedule and the keypair now
  wait on the `AUTHENTIK_WAIT_SEC` budget (default 600 s).
- §06 §6.5: every dev/CI seed run rotated `authentik-sync`'s bind secret. A re-run now
  keeps it while the LDAP source still binds and leaves `bind_password` untouched; a
  source that cannot bind is rotated as before. "Binds" is a live bind through the
  source's `debug/` endpoint, not its `connectivity` field: that is a cache (2 h TTL,
  refreshed hourly and on save) that misses an LDAP-side rotate, restore or reset.
  Prod already used the vault secret.

### References
- t-0042 notes; ARD-007, ARD-021

## [1.42.0] - 2026-10-22

### Fixed
- §08 (review finding 3): suspend then unsuspend undid a termination, and `reset_password`
  alone was enough: any `userPassword` write makes ppolicy delete the
  `pwdAccountLockedTime=000001010000Z` sentinel (measured). Suspend, unsuspend,
  `reset_password`, `POST /api/me/password` and `move_org` now refuse a terminated user with
  409 before any write. The check sits in the shared LDAP writers.
  `tests/test_suspend.py::TestTerminatedStaysTerminated`.
- §08 (review finding 14): the Authentik user lookup put the username unquoted in the URL,
  so `keith#1` resolved to `keith`, and suspending it revoked keith's sessions and tokens. It
  is now quoted and takes only an exact match.

### Changed
- §08: records the org-retention policy next to the org-delete 409. An org that ever held users
  is never deleted; its OUs stay as termination records.

### References
- ARD-020

## [1.41.0] - 2026-10-22

### Fixed
- §07 Rate Limiting, §06 Transport (review 2026-10-22, blocker 1): nothing set `TRUSTED_PROXIES`, so
  the API's client IP was Traefik for every browser and relay; per-IP limits were site-wide and 20 junk
  bearer tokens from anyone blocked the whole API for an hour. `docker-compose.tls.yml` puts the API on
  the edge network at `.6`, routes Traefik to it there, and sets `TRUSTED_PROXIES` to the edge `.3` and
  Traefik `.4`. §07 also corrects the stale description of `get_client_ip()`.
- §03, §04, §07: a token that fails only on expiry (signature valid) is recorded as `expired_token` and
  never counts toward the per-IP auto-block, so tabs waking with stale 15-minute tokens cannot trip it.

### References
- Tests: `tests/test_relay_path.py::test_one_browser_cannot_block_another`,
  `tests/unit/test_browser_edge_config.py`, `tests/unit/test_auth_ip_block_unit.py`
- Version 1.41.0 is #401's fixed spec slot (1.36.0-1.40.0 belong to other PRs).

## [1.40.0] - 2026-10-22

### Added
- ARD-022 (accepted): `POST /api/clients/onboard` (admin group) provisions a first-party client
  `<c>` end to end and is safe to repeat: registry row, org and role groups, Authentik login and
  service clients with their application policies, the LDAP source term, a profile with the
  client's own SIP and UID blocks and the org SIP context, the PBX and ejabberd LDAP clients, and
  the owned XMPP bridge user. LDAP secrets come back once (§08).
- Its guards (ARD-022 §5): admin group only; an `onboard_client` audit row before any change
  (or no change) and after; exact `https` redirect URIs outside dev with no wildcard, fragment
  or user info; refusal to touch Authentik objects it did not create; 10 calls a minute.
- Independent verification fixes (ARD-022 amendment 2026-10-22): env clients are refused (409);
  only a client with a registry row is converged; each Authentik secret is returned once; `<c>-*`
  groups carrying RBAC permissions are refused (ARD-019 invariant 1); the UID block choice and the
  LDAP source filter write hold advisory locks.
- The B2 refusal (#390) covers onboarded scoped principals (registry); onboarded applications use
  `policy_engine_mode: all`, as the seed's (#397).
- Table `first_party_clients` (§03), migration `030_first_party_clients.sql`.

### Changed
- The client registry is env plus `first_party_clients`, read through an in-process snapshot
  (10 s reload, last snapshot kept while PostgreSQL is down). Scope binding, role-group
  ownership, reserved uid prefixes and org names, and the PBX check read it (§07, ARD-019 and
  ARD-018 amendments).
- Token verification accepts each registry principal's `aud` and its issuer at every accepted
  host (§04 §3).
- The seed keeps every `(cn=<id>-*)` term already on the LDAP source and creates the headless
  flow even with no env client (§06 §6.5).
- A provisioned LDAP client id may be 48 characters (was 31), so `<c>-ejabberd` fits.

### References
- ARD-022, ARD-019, ARD-018, ARD-020; herdr t-0046

## [1.39.0] - 2026-10-22

### Changed
- §06, §07 Service Principals: the seed creates each service and first-party application with
  `policy_engine_mode: all` and patches an existing one, so a binding added to it later cannot
  outvote its access policy (the 1.33.1 account check; the `<client_id>-*` group check). A reseed
  writes nothing once set. `azblink-directory-test` is unchanged.

### References
- ARD-017, ARD-018; verifier t-0047 hardening note on #390

## [1.38.0] - 2026-10-22

### Fixed
- §03, §08: `DELETE /api/org/{dn}` checked none of its LDAP results. On an org whose people
  OU still held users it answered `ok`, left the non-empty OUs behind and deleted the org's
  profile. `delete_org_ou()` now refuses (`OrgNotEmpty`, 409) before deleting anything while
  the org OU or either mirror holds an entry, and raises when LDAP refuses a delete.
  `tests/test_org_groups.py::TestOrgDeleteNotEmpty`.
- §04 §6: with LDAP down, new sign-in fails for directory users, admins included. Authentik
  checks their password with an LDAP bind; the row said admin sign-in still worked.

### References
- ARD-001

## [1.37.0] - 2026-10-22

### Added
- §06 Authentik Bootstrap: when `AUTHENTIK_API_TOKEN` differs from the bootstrap token, the seed
  creates the `api` token `azblink-directory-api` for `akadmin` with that key and resets a drifted
  key. Before, prod's vault `authentik_api_token` existed nowhere in Authentik, so every suspend
  and terminate got 403 from the Admin API and revoked nothing (`partial=true`).
- §06 Guards: `verify.yml` runs `authentik_api_token_check.py` inside `azblink-directory-api`; the
  converge fails unless the API's own token reaches `/api/v3/core/users/me/` as an Authentik admin.

### Changed
- §06 Guards: the `ldap_admin.yml` demo purge no longer deletes by name (it removed any real
  `jchen`, `Finance`, ... on every non-dev converge). It runs only with
  `azblink_purge_demo_identities: true` and deletes only entries marked
  `businessCategory: azblink-demo`, which the demo LDIF and `seed_demo_data.py` now set. The real
  admin and the OIDC admin group are never deleted; the converge prints what it deletes.

### References
- ARD-010 (amendment 2026-10-22: API token and demo purge)

## [1.36.0] - 2026-10-22

### Fixed
- Known issue from 1.31.0: every browser on the tunnel path was one source at the sign-in throttle
  (Authentik's peer was Traefik). ARD-021 amendment 2026-10-22 (browser source), §06 Transport:
  an nginx edge between cloudflared and Traefik takes `CF-Connecting-IP` only from cloudflared's
  fixed address and replaces `X-Forwarded-For` with that one address; Traefik's `web` entrypoint
  trusts only the edge, and Authentik only Traefik, all on a fixed-address `edge` network
  (`azblink_edge_net`; dynamic addresses only from `.128/25`). Preflight refuses an edge prefix
  that holds the box's private IP or a relay IP. §07, §08 updated.

### Changed
- Owner action: the Cloudflare tunnel's public hostname maps to `http://edge:80` (was
  `http://traefik:80`).

### References
- ARD-021; tests: `tests/test_relay_path.py` (browser source, issuer through the edge),
  `tests/unit/test_browser_edge_config.py`, `tests/unit/test_preflight_relay.py`

## [1.35.0] - 2026-10-22

### Added
- §06 §6.7 One-command converge: `just deploy <inventory> [ansible args]` takes a host
  with SSH, a sudo user and Python 3 to a verified stack; production is
  `just deploy prod --ask-vault-pass -K`. `azblink_repo_mirror` clones from a bare repo
  copied from the control node, for a host that cannot reach the repo.
- §06 §6.7 Fresh-host test: `deploy/ansible/fresh-host/run.py` (`just deploy-fresh-test`,
  workflow `fresh-host.yml`) converges a throwaway Ubuntu 24.04 VM under qemu/KVM with
  `site.yml` and the `inventories/prod` example files, then checks the alert contact
  point, one backup and container health, and destroys the VM.

### Fixed
Each stopped a converge on a fresh production host:
- The API refused to start: its production guard rejected plaintext LDAP to any
  non-loopback host, including the compose `openldap` service ARD-021 §3 keeps on `:389`.
- Image builds failed on compose v5 (bake only), which refuses `network: host`;
  `docker-compose.prod.yml` resets it for the two prod images.
- Preflight now refuses an `ldap_bind_pw` that differs from `ldap_admin_password` while
  the API binds as `cn=admin`; the vault example listed them as separate secrets, and the
  API then failed deep health with `invalidCredentials`.
- `main.yml.example` said to copy it to `all.yml`; group_vars loads `main.yml`.

### References
- ARD-010, ARD-015 (the SSH handoff contract), ARD-021

## [1.33.1] - 2026-10-22

### Fixed
- §06, §07 Service Principals (audit B2): a service client's `client_credentials` grant
  accepted any user's username + app password and minted a token as that person. The seed
  now binds an access policy on each service application admitting only
  `ak-<client_id>-client_credentials` (converges on existing installs; the dev/CI-only
  `azblink-directory-test` is exempt). The API answers 401 to a token whose `azp` is a
  listed service client but whose `preferred_username` is not its generated account.

### References
- ARD-017

## [1.33.0] - 2026-10-22

### Added
- ARD-021 amendment 2026-10-22, §06 Transport: `authentik_relay_ips` (`{client_id: <IPv4>}`), one
  static address per first-party client's relay box, trusted as a `/32` for `X-Forwarded-For`.
  `preflight.yml` refuses a client without one, a relay IP for a non-client, a value that is not
  one canonical IPv4, an unspecified, loopback, multicast or own-box value, a shared address, and
  any trusted entry that is not one valid host of its family (IPv4 `/32`, IPv6 `/128`) (§07).
  `tests/unit/test_preflight_relay.py` runs the real task in CI.
- §02, §06: `azblink_relay_path_up{listener}`, the relay path probed as a relay sees it (TLS for
  the public name against the relay CA, the public issuer, API health), and the **Relay path
  down** alert (critical, 3 minutes).
- §06, §08: the relay-path simulator (`docker-compose.relay-sim.yml`, test stacks and CI only)
  and `tests/test_relay_path.py`: issuer and trusted `X-Forwarded-For` over Authentik's TLS
  listener; SIP register, call, suspend and cross-org refusal through an Asterisk PBX reading LDAP
  as its PBX identity; XMPP login, suspend and terminate through ejabberd over LDAPS. §08 §3
  records the ejabberd and Asterisk settings that pass.

### References
- ARD-021, ARD-020 §4, ARD-018

## [1.32.1] - 2026-10-22

### Fixed
- §04 §2: open admin UI tabs share one session. Each tab rehydrates the auth store on the
  `storage` event, so a second tab no longer refreshes with the refresh token another tab
  already rotated (Authentik revokes it) and lands on `/login` every 10-15 minutes under
  the 15-minute token. The sleeping-tab sentence no longer overstates the `/login` bounce.

### References
- ARD-002; verifier t-0049 findings on #391

## [1.32.0] - 2026-10-22

### Changed
- §04 §2, §06: the admin UI's `azblink-directory` provider issues a 15-minute access token
  (was 8 hours); the refresh token stays 7 days and the UI refreshes within 5 minutes of
  expiry (ARD-003 amendment 2026-10-22).
- §06: on every run the seed patches token validity onto an existing provider, so an
  install seeded before this change converges. It was create-time only.

### Fixed
- Spec drift. `[PROPOSED: ARD-007]` (§04 §1) and every `[PROPOSED: ARD-017]` (§04 §2/§3,
  §06, §07 Grant Containment and Service Principals, §08) become as-built: both ARDs are
  accepted and shipped. §04 §5 named termination only and access tokens only; it now
  covers suspend and unlock and the refresh-token revocation. §04 §6 gives the real
  outage window. §06 gives the seed's real wait (`AUTHENTIK_WAIT_SEC`, 600 s).

### References
- ARD-003, ARD-007, ARD-017; 2026-10-21 re-audit rows "spec drift" and "8 h admin-UI token"

## [1.31.0] - 2026-10-22

### Added
- ARD-021 (accepted): production issuer, TLS and relay path. One public HTTPS host
  (`azblink_public_host`) through a Cloudflare tunnel for browsers. Relays use the same
  name over TLS on a routed private path: Authentik `:443`, API `:8443`, LDAPS `:636`.
  The issuer is `https://<host>/application/o/<client>/` on both paths.
- §06 §6.7 Transport: the listener table, certificate handling, publish knobs and
  Cloudflare boundary. §04 §3: the production issuer. §07 §5: the transport boundary.

### Changed
- §06 §6.7: production loads `docker-compose.tls.yml`, every plaintext listener binds
  loopback, and `preflight.yml` refuses any other production shape. ARD-010's
  LAN-plaintext posture is replaced (ARD-010 amendment). ARD-018's relay path is made
  concrete (ARD-018 amendment).
- §07 §3 PBX Read Access: a PBX without TLS needs a private tunnel or the
  `azblink_allow_plaintext_ldap` exception.

### Fixed
- The OpenLDAP healthcheck binds with the container's own admin password. On a vault
  password it never passed, so `directory-api` never started on a production converge.

### Known issue
- Under the 1.29.0 source throttle, every browser on the tunnel path is one source
  (Authentik's peer is Traefik), so 2 failures through the public host refuse that
  username's browser sign-in. Relays and LDAP are unaffected. The fix (deliver
  `CF-Connecting-IP` as the client IP through a trusted edge) is a follow-up (ARD-021
  amendment 2026-10-22).
- `alert_tls_targets` in the prod example now lists the three relay-path TLS listeners.

### References
- ARD-021, ARD-010, ARD-018; 2026-10-08 audit G7 / decision 14; 2026-10-21 re-audit B3

## [1.30.0] - 2026-10-22

### Added
- §06 Backup: the `azblink_backup` Ansible role installs `azblink-backup` and a nightly systemd
  timer. One archive per night: `slapcat` of `cn=config` and the directory, `pg_dump -Fc` of the
  directory and Authentik databases, a Redis RDB snapshot. 14-day retention on the host and the
  target; `gpg` AES-256 when a passphrase is set; an rsync-over-SSH mirror to
  `backup_offhost_target` (vault, needs the passphrase). After the off-host copy succeeds it writes
  `azblink_backup_last_success_timestamp_seconds` to `/var/lib/azblink/metrics/azblink_backup.prom`
  for Alloy's textfile collector. `azblink-backup restore FILE --yes` restores all four stores.
  Runbook and drill: `docs/runbooks/backup-restore.md`. Replaces the `backup.yml` Bucket B
  placeholder (ARD-010 amendment 2026-10-22).

## [1.29.0] - 2026-10-22

### Added
- §08 Lockout, §04 §2.1, §06 §6.5 (ARD-018 amendment 2026-10-21, audit blocker B5): a source throttle
  on both flows' password bindings. The client IP Authentik records (trusted relays' `X-Forwarded-For`
  only) is refused once its reputation row for the username reaches −2, and reserves one of its own 2
  binds before the username's 3. One source can no longer block a username; failures from two sources
  still do. At most 2 sign-ins per username per source in flight.

### Changed
- §02 `observability.py`: `azblink_locked_identities{source="authentik"}` counts only a username's own
  bind-budget row (IP `::`), so per-source throttle rows never make an unblocked username read as locked.

## [1.28.0] - 2026-10-22

### Added
- §06 Dev↔prod deltas, §02, ARD-008 amendment 2026-10-21 (decision D-d): Grafana alerts leave the box.
  Ansible renders a contact point `azb-oncall` (webhook to `alert_webhook_url`, plus email when
  `alert_smtp_host` and `alert_email_to` are set); preflight refuses a prod converge without the
  webhook. New `azblink-identity` rules: Authentik down (server and worker on `/-/health/ready/`),
  lockout spike (`azblink_locked_identities{source}`), LDAP bind failures (Loki, `err=49`), TLS
  certificate expiry (`azblink_tls_cert_not_after_seconds`, `TLS_EXPIRY_TARGETS`), backup age
  (`azblink_backup_last_success_timestamp_seconds` via Alloy's textfile collector).

## [1.27.1] - 2026-10-22

### Changed
- §07 §3, §08 §1: `POST /api/users/{uid}/unsuspend` refuses a terminated user with 409 before any
  write. It used to clear `description=TERMINATED` (re-exposing `AstAuthPassword` to the PBX ACL)
  and reactivate the Authentik user. A scoped caller's refusal is audited as `scoped_denied`.

## [1.27.0] - 2026-10-21

### Added
- §04 §5, §08 §1 (ARD-019 amendment 2026-10-21): suspend and terminate set Authentik `is_active=false`
  after revoking sessions and tokens; unsuspend sets it back. On 2026.5 an inactive user's refresh and
  app-password grants answer `invalid_grant` and its tokens are deleted. Terminate also deletes the
  user's app passwords and queues the LDAP source sync. `POST /api/users/{uid}/unlock` deletes the
  username's reputation rows and bind budget.

### Changed
- §04 §5, §08 §1: an Authentik failure during suspend, unsuspend, terminate or unlock is logged at
  ERROR and returned as `partial: true` with a warning; the response stays 200 because the LDAP write
  has landed, and repeating the call retries.

## [1.26.3] - 2026-10-21

### Changed
- §04 §AuthentikClient, §08 Termination Flow: `terminate_user_access()` looks the Authentik user up once (was once per
  revocation), revokes sessions and tokens side by side, and lists access and refresh tokens at
  once; deletes keep their order. A DELETE answering 404 counts as already revoked: a session
  DELETE cascades to its access tokens. Revocation p50 722 → 463 ms in an interleaved A/B (t-0031).

## [1.26.2] - 2026-10-21

### Fixed
- §04 §AuthentikClient, §08: `revoke_user_sessions()` lists sessions with `?user__username=` across
  every page and deletes only rows owned by the user's PK. Authentik 2026.5 ignores `?user=<pk>` on
  `/core/authenticated_sessions/`, so each suspend or terminate deleted the first page (20) of every
  user's sessions, and missed the target's own when it was not on that page.

## [1.26.1] - 2026-10-21

### Fixed
- §05 Profile-Org Assignment, §03: `resolve_template_for_org()` now walks up the org tree as §05
  described: the org's own assignment, else the nearest assigned ancestor, stopping below `ou=org`.
  It matched only the exact DN, so `PUT /api/users/{uid}/sip` on a user in a sub-org (a building
  under a client) answered 409. DNs compare case-insensitively.

## [1.26.0] - 2026-10-21

### Changed
- §05 §5.3, §08 §4: SIP extension ranges are disjoint across profiles and at most
  `SIP_RANGE_MAX_SIZE` wide (default 1000), per the ARD-020 amendment of 2026-10-21. Adding a SIP
  service or changing its range answers 409 on overlap with another profile (drafts included) and
  422 over the width limit, checked under a transaction-scoped advisory lock. Unchanged ranges are
  not checked, so existing ones stay valid until changed. A cloned profile's SIP service has no
  range. Default-profile seeding skips the SIP row with a warning instead of failing startup.

## [1.25.0] - 2026-10-21

### Added
- §03 §2.1: `uidNumber` is unique across the whole directory (ARD-019 amendment 2026-10-21). The
  `unique` overlay gains `olcUniqueURI: ldap:///<base>?uidNumber?sub`; fresh volumes get it from
  `unique-config.ldif`, running directories from ansible (after refusing existing duplicates) or
  `unique-uidnumber.ldif`.

### Changed
- §05 §5.1, §5.3, §5.4: uidNumber allocation skips a number any entry holds, since profile uid
  ranges may overlap. A lost race answers 409 on `PUT /api/users/{uid}/sip` and a named warning on
  `POST /api/users/create`.

## [1.24.2] - 2026-10-21

### Fixed
- §05 Counter Mechanics, §03, §08: changing a profile's UID range or a service's counter range
  moves the counter up to the new start (never back), so `uidNumber`s and extensions are no longer
  issued below the new range. A new end below values already issued is refused with 409, a start
  after the end with 422. Both allocators also refuse a counter below its range start.

## [1.24.1] - 2026-10-20

### Changed
- §05 §5.4, §07 §3: `PUT /api/users/{uid}/sip` refuses a suspended or terminated user with 409
  (ARD-020 amendment "inactive users"). A scoped caller's refusal is audited as `scoped_denied`.

## [1.24.0] - 2026-10-20

### Added
- ARD-020 implemented. §03 §2.3: the SIP endpoint name is the allocated extension in all seven
  naming attributes (`AstAccountName`, `AstAuthUsername`, `AstAorId`, `AstAuthId`, `AstEndpointId`,
  `AstEndpointAors`, `AstEndpointAuth`); `uid` stays separate. Extensions are unique per profile:
  allocation skips used values under a per-profile advisory lock (§05 §5.3).
- §05 §5.4, §07 §3: `PUT /api/users/{uid}/sip {password?, extension?, context?}` enables SIP with
  the org's assigned profile, or changes the secret (12+ characters) or user-level context. Admitted
  for `user_management` and for a client-scoped principal on owned, contained users; counts in
  `LIMIT_SCOPED_WRITE`, audited as `scoped_set_sip` / `set_sip` without the password.
- §03 §2.3: `azbSipContext` (`AZBlinkAttr:8`) on `azblinkUser`, `azblinkGroup`,
  `azblinkOrganization`, values `default` or `all`. Resolution user > groups (disagreement →
  `default`; a client role group reaches only owned users) > the user's own org > `default`,
  written into `AstEndpointContext`. Set through `PUT /sip`, `PATCH /api/groups/{cn} {sipContext}`
  (also admitted for the scoped principal on in-scope groups) and `POST /api/org/sip_context`
  (`org_management`).
- §07 PBX Read Access, §08: `POST /api/settings/ldap/clients/provisioned {kind: "pbx"}` creates
  `cn=<c>,ou=pbx,ou=clients`; ACL rule `{2}` lets it read `AstAuthPassword` of that client's owned
  users while they are not suspended or terminated. Plaintext, option B; `AstAuthMd5Cred` is not
  written.
- §06: `deploy/dev/ldap/azblink-schema-ard020.ldif` and an ansible `ldap_source.yml` task add the
  attribute to running directories; the ACL file carries the new rule. The API tolerates a
  directory without the attribute (reads it as unset, refuses context writes with 503), so the
  code may merge before the schema is applied.

### Changed
- **Existing SIP endpoints are renamed from uid to extension** by `tools/migrate_ard020_sip.py`
  (§05, run inside the API container; `--dry-run`; idempotent). **The sealed device payload's
  `sipUsername` becomes the extension, so installed devices must re-provision.**
- **`from-internal` is replaced by the resolved context** (fallback `default`) on new endpoints and,
  through the same migration, on existing ones: UED answers an INVITE from `from-internal` with 404.
- `AstAuthType` stays `userpass` (ARD-020 amendment 1). Group detail returns `sipContext`, org
  detail `ucConfig.sipContext`; provisioned-client rows return `kind`.
- ARD-020: implementation amendment with the deviations from the body.

### References
- ARD-020, PRs #369 and #370; dev LDAP held no SIP entries on 2026-10-20

## [1.23.1] - 2026-10-20

### Changed
- ARD-020 amendment (verification results, 2026-10-20), decision-only:
  - §4 resolves to option B: the PBX reads plaintext `AstAuthPassword` behind the PBX ACL rule,
    because md5 auth answered 500 on UED. HA1 is deferred until Azblink maps `md5_cred`; re-test
    steps 1–3 then.
  - Option D is confirmed: UED keys endpoints on `AstEndpointId`; `AstAccountName` stays required
    for the default `sfilter`.
  - The §3 fallback context becomes `default`: `from-internal` gets 404 on INVITE.
  - LDAP changes reach UED in about 1 s with no VoIP restart; the revocation bound is the phone's
    registration expiry.

### References
- ARD-020, PR #369; PED80 run 2026-10-20 (herdr thread t-0021)

## [1.23.0] - 2026-10-20

### Added
- ARD-020 accepted (owner, 2026-10-20), decision-only: client SIP provisioning for SafeNest
  phase 4. The SIP endpoint name (`AstAccountName`, `AstAuthUsername`, the `*Id` attributes) is
  the allocated extension, unique per profile. `PUT /api/users/{uid}/sip` lets an ARD-019 principal
  enable SIP on its owned, contained users with the org's profile. `azbSipContext` on user, group
  and org resolves user > group > org > `from-internal` into `AstEndpointContext`. A PBX bind DN
  `cn=<c>,ou=pbx,ou=clients` reads one SIP secret of that org's active owned users: `AstAuthMd5Cred`
  if a PED80 REGISTER test passes, else `AstAuthPassword`. No spec section changes yet.

### References
- ARD-020, PR #369; `docs/reports/2026-04-17-sip-sso-e2e-report.md`; SafeNest phase-3 PLAN § Phase 4

## [1.22.0] - 2026-10-20

### Added
- ARD-019 accepted (2026-10-20) and implemented: client-scoped service principals. A service client
  in `OIDC_SERVICE_CLIENT_SCOPES="svc:first_party_client:role|role"` may run nine user and group
  calls on that client's fixed role groups and on its contained users under `ou=<c>,ou=people`;
  every other route answers it 403, an out-of-scope target 404, an owned user that is not contained
  403, a collision 409. §07 Client-Scoped Service Principals, §04 §1, §08 API-to-API.
- §07 §1: `LIMIT_SCOPED_WRITE`, 600/minute per verified `azp` across the seven scoped writes.
- §07 §4: `scoped_*` and `scoped_denied` rows in `admin_action_audit`, actor `ak-<azp>-client_credentials`.
- §03 §2.1, §06 Dev↔prod deltas: `uid` unique across `ou=people` (API 409 plus the LDAP `unique`
  overlay; ansible adds it to running directories after refusing duplicates).
- §06 Dev↔prod deltas: inventory var `authentik_service_client_scopes`; dev and CI carry
  `safenest-dev-directory:safenest-dev:admin|staff|resident|visitor`.
- §08 First-Party Headless Login: onboarding a building's roster writer, and why a person in two
  buildings is adopted rather than owned.

### Changed
- For every caller (ARD-019 §4): client role groups carry no RBAC permissions (422); `<client>-`
  uids and client-id org names are reserved (422, org names open to the admin group); membership
  writes answer 200 `changed: false` when nothing changed instead of 500; startup refuses nested
  first-party ids.
- §08 §1: suspend revokes Authentik sessions, access tokens and refresh tokens (ARD-019 §7), and
  terminate now revokes refresh tokens too. Session revocation used `pk`, which Authentik 2026.5
  does not return, so it had never revoked a session; it uses `uuid`.
- ARD-017, ARD-018: amendments pointing to ARD-019. ARD-019 gains 04 and 06 in
  `spec_sections_affected`.

### References
- ARD-019; gap report G18, decision 17; SafeNest G18-ASK A1–A4

## [1.21.0] - 2026-10-20

### Added
- §08 §4: every write route in `groups.py` (create, delete, patch, member add/remove/role,
  `/permissions`) records an `admin_action_audit` row; permission changes record `granted` and
  `revoked`.
- §08 Audit Retention Purge: an hourly lifespan task deletes audit rows older than
  `audit.retentionPolicy` days (`forever` keeps all) and records its own `purge_audit` action.

### Changed
- §03 §1, §5: audit tables are append-only except for the retention purge.
- §08 §4: `PATCH /api/groups/{cn}` validates `group_type` before writing the description.

### References
- Readiness audit 2026-10-08, plan PR #10

## [1.20.0] - 2026-10-19

### Added
- §08 Lockout, §04 §2.1, §06 §6.5: an LDAP bind budget on both flows' password bindings (G23). Each
  password POST atomically reserves one of the username's 3 binds, and a success gives its reservation
  back. Parallel bursts and expired reputation rows can no longer reach ppolicy's `pwdMaxFailure`.

### Changed
- §08 runbook: unblocking also deletes the `ldap-bind-budget:<uid>` row.
- §08 limits: the parallel-request and expired-row limits are closed; LDAP binds outside Authentik remain.
- ARD-018: amendment (G23).

### References
- ARD-018; gap report G23

## [1.19.0] - 2026-10-19

### Changed
- §06 §6.5: the web provider `azblink-directory` grants `authorization_code` + `refresh_token`
  only. It no longer grants `client_credentials`, which let any app-password holder mint an
  API-valid token without the browser flow (ARD-017 follow-up, readiness audit blocker).
- §06 §6.5: dev and CI register the test-only service client `azblink-directory-test`; the test
  suite's token factory uses it.

## [1.18.0] - 2026-10-19

### Added
- ARD-019 (proposed): client-scoped service principals (G18). One
  `client_credentials` service client per first-party client, bound by
  `OIDC_SERVICE_CLIENT_SCOPES`, may run nine existing user and group calls on
  that client's `<c>-<role>` groups and on contained users under
  `ou=<c>,ou=people`, and holds no RBAC permission. Records invariants for every
  caller (client role groups carry no permissions, reserved `<client>-` uids and
  org names, uid unique across `ou=people`, idempotent membership), 409 on a
  scoped create collision, per-`azp` rate limiting, and the recommendation that
  suspend revokes Authentik tokens. No spec section changes yet.

### References
- ARD-019, PR #353; gap report G18 and decision 17; SafeNest G18-ASK A1–A4

## [1.17.2] - 2026-10-08

### Added
- §06 Dev↔prod deltas: the prod path for API-to-API service clients. The inventory var
  `authentik_service_clients` (`{client_id: [permission, …]}`, default empty) renders
  `AUTHENTIK_SERVICE_CLIENTS`, `OIDC_ACCEPTED_AUDIENCES`, `OIDC_SERVICE_PERMISSIONS` and each
  client's issuers into `.env`; `verify.yml` waits for each provider.

### References
- ARD-017; readiness audit 2026-10-08 (G18 prerequisite)

## [1.17.1] - 2026-10-08

### Changed
- §06 §6.2: records Cloudflare Access on the dev hostname `authentik.keithmoc.dev` (owner email
  only), with Bypass on OIDC discovery and `/application/o/token/` for the admin UI's cross-origin
  fetches. Docker-internal access and the headless relays are unaffected. This is dashboard
  config, not a repo change.

## [1.17.0] - 2026-10-07

### Added
- §08 Lockout, §04 §2.1, §06 §6.5: the brand flow `default-authentication-flow` (web sign-in, admin
  included) carries the headless lockout. Its password binding runs its policies in mode `all`.
- §06 §6.5: `ppolicy-lockout.ldif` brings the default password policy's lockout settings to an
  initialized volume; ansible applies it on every converge.
- §08 runbook: unblocking when no admin can sign in (`ak shell`), and an LDAP unlock that leaves the
  termination sentinel alone.

### Changed
- §08: ppolicy `pwdFailureCountInterval` 0 → 3600 (G24).
- §08 limits: parallel requests are bounded by database connections (measured), not worker threads.
  `pwdMaxFailure` stays 5 (G23). The brand-flow and row-expiry limits are restated.
- ARD-018: amendment (G22–G24).

### References
- ARD-018; gap report G22, G23, G24

## [1.16.0] - 2026-10-02

### Added
- §08 First-Party Headless Login: Lockout row and paragraph, limits, unblock runbook. A
  username reputation policy (`check_ip` off, −3) is bound negated on the headless flow's
  password binding, with a fail-closed deny stage after it; tenant `reputation_upper_limit` 0.
- §06: `authentik-server` trusts `X-Forwarded-For` only from loopback unless relays are listed
  (`AUTHENTIK_TRUSTED_PROXY_CIDRS` / `authentik_trusted_proxy_cidrs`).
- §04 §2.1: where the lockout answers in the relay sequence.

### Changed
- §08 relay rule: the relay sets `X-Forwarded-For` to the client IP it observed, never appends.
- `[PROPOSED: ARD-018]` → `[AS-BUILT]` in §03, §04, §06, §08: E2, E2b, E3, E4, E5 and G20 shipped.
- ARD-018: amendment (E5 as built; guarantee is for sequential traffic).

### References
- E5, ARD-018; gap report G1, G2, G22–G24; PR #338

## [1.15.5] - 2026-10-02

### Changed
- §06 Dev↔prod deltas, "First-party clients": the old text said the seed does not
  run on the prod path. It does: `authentik-seed` has no compose profile; only the
  demo `seed` service is dev-only. Prod registers headless first-party clients
  through the inventory var `authentik_first_party_clients`, which `env.j2`
  renders into `AUTHENTIK_FIRST_PARTY_CLIENTS`; `verify.yml` waits for each
  client's provider. `[PROPOSED: ARD-018]` stays: E5 has not shipped.

### References
- G20, ARD-018 (06 in `spec_sections_affected`)

## [1.15.4] - 2026-10-02

### Changed
- §08 First-Party Headless Login: new "Flow" row. The seed builds the shared
  `headless-first-party-auth` flow from its own stages (identification →
  password with Inbuilt + LDAP backends → authenticator-validate with every
  device class → user-login) and sets it as each first-party provider's
  authentication flow. ARD-018 rule 2 already names the flow; this records its
  as-built shape. `[PROPOSED: ARD-018]` stays: E5 and G20 have not shipped.

### References
- E3, ARD-018; gap report G3 (TOTP challenge through the executor verified live)

## [1.15.3] - 2026-10-02

### Changed
- **ARD-018** status `proposed` → `accepted`. Its gate closed when E4 (#334)
  merged after E2 (#332) and E2b (#333). `pr:` is the decision PR #330; the
  summary block, § References and the README ARD table row list the
  implementing PRs.
- The `[PROPOSED: ARD-018]` markers stay: E3, E5 and the prod registration
  path (G20) have not shipped. No spec section changed, so PATCH.

### References
- PRs #330, #332, #333, #334; ARD-018

## [1.15.2] - 2026-10-02

### Changed
- §03.2.4: first-party client role groups (`<client_id>-*`) carry `uidObject` +
  `uid=<cn>`, are lowercase and live only at the top of `ou=groups`.
- §08 First-Party Headless Login: role changes trigger a background LDAP source
  sync; deleting a role group deletes its Authentik group. Both
  `[PROPOSED: ARD-018]`. ARD-018's `spec_sections_affected` gains
  `03-data-architecture`.

### References
- E2b (LDAP role-group sync), ARD-018; gap report G14–G17

## [1.15.1] - 2026-10-02

### Changed
- §06 bootstrap sequence lists service clients and first-party headless
  clients (`AUTHENTIK_FIRST_PARTY_CLIENTS`, dev registers `safenest-dev`); the
  prod notes say prod has no first-party client path yet (G20). Both
  `[PROPOSED: ARD-018]`. ARD-018's `spec_sections_affected` gains
  `06-deployment`.

### References
- E2 (seed first-party clients), ARD-018

## [1.15.0] - 2026-10-02

### Added
- **ARD-018** (proposed): headless first-party client login. A registered
  client's backend relays its own login form to the Authentik flow executor and
  gets Authentik tokens, under seven fixed admission rules (confidential + PKCE,
  shared flow, 15 min / 7 d, no password logging, MFA fails closed, logout by
  refresh-token revoke, `aud=<client_id>`). Clients register in one JSON
  `AUTHENTIK_FIRST_PARTY_CLIENTS`; role groups are `<client_id>-<role>`, created
  by azb-AD with `uidObject` + `uid=<cn>`. SafeNest is the first client, one per
  building box.
- §04 §2.1 headless sequence and §08 *First-Party Headless Login* with the
  client registry (`safenest-dev`), both `[PROPOSED: ARD-018]`.

### Changed
- **ARD-002** amendment: Plane B gains the first-party headless client class.
  "No fallback, no breakglass" stands.
- **ARD-007** amendment: the no-group-sync non-goal is narrowed. Registered
  clients' `<client_id>-*` groups sync; `IT-Admins` and other groups do not.

### References
- ARD-018; `docs/reports/2026-09-25-safenest-headless-login-gap-report.md`
  (decisions 1–20)

## [1.14.3] - 2026-09-25

### Fixed
- **arch-guard Dependabot lane.** A range in which every commit carries
  `Signed-off-by: dependabot[bot] <support@github.com>` is covered on all
  surfaces. SOP.md § When to Create an ARD already excludes dependency bumps,
  but a bump to a governed file (`release.yml`, `Dockerfile.*`,
  `arch_guard_requirements.txt`) needed a trailer Dependabot cannot write, so
  #300 could only merge red. One commit without the sign-off switches the lane
  off for the whole range.

### References
- PR #300, `tools/arch_guard.py`, SOP.md § Commit trailers

## [1.14.2] - 2026-09-18

### Changed
- **ARD-007** `proposed` → `accepted`, effective 2026-07-03 (#184). The Authentik
  LDAP source is seeded (`sources/ldap` in `seed_authentik.py`) and
  `AUTHENTIK_LDAP_SYNC_PASSWORD` is wired through compose; spec 1.3.0 already
  documented it.
- **ARD-008** `proposed` → `accepted`, effective 2026-07-04 (#186). Prometheus,
  Loki, Alloy and Grafana are all in the dev compose and `observability.py` is on
  the `cross_process_boundaries` surface. The README ARD table has said
  `accepted` since it landed — only the record itself was stale, so this is a
  drift fix between the two, not a new decision.
- **ARD-010** `proposed` → `accepted`, effective 2026-07-15 (#206).
  `deploy/ansible/`, `docker-compose.prod.yml` and the absence of `install.sh`
  are the artifact the decision describes.
- `accepted_at` on all three is 2026-09-18, the date of this backfill;
  `decision_effective_date` is the merge date, per the ARD-013 split.
- **ARD-005** and **ARD-014** gain an `## Amendments` entry naming the PR that
  landed each (#99 and #268). Their `pr:` frontmatter fields stay empty: guard
  rule 2 compares the whole file above `## Amendments`, frontmatter included,
  against the base-ref blob, so editing `pr:` on an `accepted` ARD fails
  `ard-immutability`. ARD-005 § References had promised exactly that post-merge
  patch — an instruction the rule it installed makes unexecutable.

### Fixed
- Three README ARD-table PR cells cited **issue** numbers in a column that reads
  as PRs: ARD-014 `#265` → `#268 (issue #265)`, ARD-012 `#242 implements` →
  `#243 records, #257 implements`. ARD-005's `(Phase 0)` gains its number, `#99`.
  ARD-014's own § References was already correct — it says "Issues: #265", and
  only the table turned that into a PR claim.

### Unchanged (deliberately)
- **ARD-015** stays `proposed`. Its summary block states the acceptance gate — a
  real host bootstrapped unattended **and** converged — and its Amendments record
  that the sole real-hardware attempt (2026-08-05) fell back to a hand-install
  with the cause unproven. #280 and #294 shipped the mechanism, not the lane.
- **ARD-012**'s empty `pr:` is deliberate and documented in its § References as a
  decision-only record (PR-1 of SOP § 6.1), not an omission.
- ARD-016 does not exist; SOP permits the gap and no record was invented for it.

### References
- PR #184, #186, #206, #99, #268; ARD-005, ARD-007, ARD-008, ARD-010, ARD-014

## [1.14.1] - 2026-09-18

### Changed
- **ARD-017** status `proposed` → `accepted`. Its implementation merged as #304
  on 2026-09-11 and the record was never flipped, leaving the decision live in
  code and unaccepted on paper (SOP.md § Update Triggers item 3).
  `decision_effective_date` is the merge date, `accepted_at` this flip — the
  same split ARD-013 used for a record filed after its behaviour shipped. The
  `pr:` field, the mirrored summary block and § References are backfilled to
  #304, and the README ARD table row matches.
- No spec section changed and no behaviour is asserted that 1.14.0 did not
  already describe, so PATCH rather than MINOR.

### References
- PR #304, ARD-017

## [1.14.0] - 2026-09-11

### Added
- **ARD-017 (proposed)** — RBAC grant containment and API-to-API service principals.
- **§07 Grant Containment** — `assert_can_confer` guards every RBAC-granting
  write (group permissions PATCH, member add, member-role PATCH): outside the
  admin group a caller may confer only permissions it holds; fails closed (503).
- **§07 Service Principals / §08 API-to-API Integration** — one confidential
  `client_credentials`-only Authentik provider per service
  (`AUTHENTIK_SERVICE_CLIENTS`), admitted via `OIDC_ACCEPTED_AUDIENCES` and the
  per-provider issuer, authorized by `OIDC_SERVICE_PERMISSIONS` keyed on `azp`
  plus the generated `ak-<client_id>-client_credentials` account. `ak-` uids are
  reserved at user create. Dev demo: `azblink-svc-demo` (`audit_log_access`).

### Changed
- **§04** audience verification reads `OIDC_ACCEPTED_AUDIENCES` (defaults to
  `OIDC_AUDIENCE`, so existing deployments are unchanged).
- **§06 / §08** API docs are served at `/api/docs`, `/api/redoc`,
  `/api/openapi.json` (previously at the app root, unreachable through Traefik)
  and gated by `DOCS_ENABLED`, default off outside dev. OpenAPI declares an
  `HTTPBearer` scheme on 92 of 98 operations.

### Fixed
- **§07** corrected "no roles are stored locally": permissions live in
  `group_profiles` + `group_member_roles`, and any member row confers the
  group's whole permission set.

### Security
- Closed a privilege escalation: a delegated `user_management` holder could
  grant its own group `system_configuration` (HTTP 200) or join a group already
  carrying it. `tests/test_rbac.py::TestRBACNoEscalation` reproduces it against
  the previous implementation.

## [1.13.0] - 2026-08-07

### Added
- **§8 §2 Directory Consumer Contract** — the attribute map an LDAP-backed
  relying party has to be configured with, plus the canonical active-user filter
  `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=*)))` that 1.12.0 queued
  here. Two rows are deliberately *not* the consumer's default, and both fail by
  dropping users silently rather than erroring:

  - **Display name is `cn`, not `displayName`.** azb-AD writes an LDAP
    `displayName` on no path — `create_user()` writes `cn`, `update_user()` maps
    the API field onto `cn`, and every read reconstructs it from `cn`. A consumer
    keyed on the default therefore sees no product-created user at all; the 54 it
    did see on the dev stack were the demo seed's, which is the only writer of the
    attribute anywhere (2026-08-07 VM7 integration report, **G9**).
  - **Terminated users stay in the tree** and are excluded by
    `(pwdAccountLockedTime=*)`, per 1.12.0.

  Also records that consumers bind as a provisioned `ou=clients` client rather
  than `cn=admin`, since ARD-001 puts the UC secrets on the same entry (**G3**).

### Changed
- A blank `displayName` on `PATCH /api/users/{uid}` or `PATCH /api/me` is now
  refused with 422, and values are stripped before being written. `cn` is
  load-bearing for consumers and OpenLDAP defends it only partly: it rejects an
  absent or empty-string `cn`, but accepts a **whitespace-only** one verbatim.
  `PATCH` with `"   "` returned 200 and left the entry nameless in every
  consumer, and `PATCH` with `""` tried to delete a MUST attribute and surfaced
  the objectClassViolation as a 500. Create is unchanged — blank there is legal
  and falls back to the `uid`.

  MINOR rather than PATCH: this asserts new behaviour at the API edge. Pinned by
  `tests/test_users.py::TestDisplayNameIsCarriedByCn`, verified to fail against
  the previous implementation.

## [1.12.0] - 2026-08-07

### Changed
- **§2 Termination Flow** — `disable_user()` now performs three writes instead
  of one. It sets ppolicy's `pwdAccountLockedTime` (the overlay then refuses the
  bind) and removes the user from every group, in addition to the existing
  `userPassword`/`description` markers.

  The lock attribute is the behavioural point: termination previously left
  **no state an external LDAP consumer could filter on**, so a relying party
  backed by this directory kept a terminated account enabled and addressable
  indefinitely — outliving the OIDC session concern by an unbounded margin
  (2026-08-07 VM7 integration report, **G5**). Group removal makes real the
  behaviour §2 had claimed as-built since it was written.

  Group removal inserts `LDAP_BIND_DN` as a placeholder member where the
  terminated user is a group's only member, since `groupOfNames` requires one —
  the same convention `create_group()` already uses.

  MINOR rather than PATCH: this asserts new behaviour. Pinned by
  `tests/test_users.py::TestTerminationReachesConsumers`, which is verified to
  fail against the previous implementation.

**Consumer note:** relying parties should treat `(pwdAccountLockedTime=*)` as
"account is dead" and exclude it from their user filter. Publishing a canonical
active-user filter in §8 is queued with the remaining VM7 follow-ups.

## [1.11.4] - 2026-08-07

### Added
- **§3 §2.4 Group Entries** — records the `memberof` overlay's required
  configuration (`groupOfNames` / `member` / `memberOf`) and why it needs
  stating: `osixia/openldap:1.5.0`'s built-in `04-refint.ldif` creates the
  overlay with OpenLDAP's `groupOfUniqueNames`/`uniqueMember` defaults, which
  this directory never writes, so `memberOf` populated on no entry at all — for
  any membership past or future — and a consumer filtering on it received an
  empty result rather than an error. Also records that the overlay computes only
  on write, so a configuration fix does not recompute existing entries.
- **§6 §6.4 Volume Mounts** — `deploy/dev/ldap/memberof-refint-config.ldif` is
  mounted again, as an override that must sort after the image's built-in.

Describes the LDAP schema and dev bind mounts as-built; no new behaviour is
asserted beyond restoring the overlay to the pair the group entries already use.
Pinned by `tests/test_org_groups.py::TestMemberOfOverlay`.

## [1.11.3] - 2026-08-07

### Fixed
- **§2 Termination Flow** — step 1 was recorded as-built as
  "`ldap_client.disable_user()` -- sets `userPassword` to a locked value, removes
  from all groups". The second clause has never been implemented:
  `disable_user()` replaces `userPassword` with `{DISABLED}` and `description`
  with `TERMINATED`, and does nothing further. Corrected to match the code, and
  extended to record the consequence — because the entry keeps satisfying an
  ordinary user filter, termination is invisible to an external LDAP consumer,
  which keeps the account enabled and addressable indefinitely. Surfaced by the
  2026-08-07 VM7 Nextcloud SSO integration report (**G5**).

No behavioural assertion — this corrects the record to describe the code as it
stands. Making termination propagate (a filterable disabled state, and removing
group memberships as the spec had claimed) is queued as separate work.

## [1.11.2] - 2026-08-07

### Fixed
- **§4.2 OIDC Flow** — the recorded authorization scope string (`openid profile
  email`) matched neither the code nor its intent. The frontend requested
  `openid profile email groups offline_access`, and the seeded provider carried a
  custom `groups` scope mapping on top of Authentik's built-in `profile` mapping,
  which already emits `groups`. Authentik merges each granted mapping's output
  with deepmerge's `always_merger` — which appends list-valued claims rather than
  overwriting — so both emitters fired and every group name appeared twice in the
  `groups` claim (#279). `require_admin` tests membership, which is insensitive
  to duplication, so authorization never broke and the defect went unseen.
  Corrected to `openid profile email offline_access`.

### Added
- **§4.2 Groups claim source** — names `profile` as the single `groups` emitter
  and records the append-on-merge semantics that make a second emitter a
  duplication bug rather than a redundancy. Pinned by `tests/test_oidc_claims.py`.

No behavioural assertion — both entries describe the auth plane as-built.

## [1.11.1] - 2026-08-06

### Fixed
- **§6.6 Hot Reload Rules** — the `src/backend/requirements.txt` row named only
  `just api-rebuild`, omitting the lockfile regeneration that has to precede it.
  `Dockerfile.api` and the backend CI jobs install `requirements.lock`, not the
  floors declared in `requirements.txt`, so the documented flow rebuilt the image
  from an unchanged lock and reported success while changing nothing. Corrected
  to `just lock-backend && just api-rebuild`, matching `CLAUDE.md`.

### Added
- **§6.6 Backend Lockfile Regeneration** — records two load-bearing properties of
  the `lock-backend` recipe that were previously implicit. pip is pinned to
  `25.3` because `python:3.14-slim` now ships pip 26.x while pip-tools 7.6.0
  still calls the pre-26 `make_requirement_preparer()` signature; unpinned, the
  recipe resolves and then dies with `TypeError: ... 'allow_editables'`. And the
  container runs as the invoking uid via a `/tmp` venv, because a root-owned
  lockfile stalls the Mutagen sync of a remote-synced working tree (§6.6,
  *Remote-Synced Working Trees*).

No behavioural assertion — both entries describe tooling as-built.

## [1.11.0] - 2026-08-05

### Added
- ARD-015: Per-VM Autoinstall ISO as the Host Bootstrap Lane (`proposed`). §6.7
  described converging a host that already existed, answered SSH, and had a
  known address. Nothing recorded how a host reached that state — it was a VNC
  console procedure held in somebody's memory, on the critical path of every new
  host.
- **§6.8 Host Bootstrap** — `deploy/bootstrap-iso/` builds a per-VM unattended
  Ubuntu 24.04 autoinstall ISO. The hypervisor's only input channel is "upload an
  ISO, attach as CD/DVD, boot UEFI, watch VNC", and an installing VM has no route
  back across the VPN to the control node, so per-VM identity must ride inside
  the ISO rather than be fetched at boot. That constraint rules out the usual
  `ds=nocloud;s=http://provisioner/` recommendation outright.
- ISOs are produced by *copying* the source with `xorriso -boot_image any replay`
  and overlaying `/autoinstall.yaml`, `/boot/grub/grub.cfg` and `/azb/`, rather
  than extract-and-repack. Boot records are reproduced verbatim, so the signed
  shim/GRUB/kernel stay byte-identical and Secure Boot is unaffected. (24.04
  live-server ships no `isolinux/`, so the widely-published repack recipe fails
  on it regardless.)
- Networking defaults to DHCP with a netplan `en*` match, so the virtual NIC
  name — hypervisor-dependent and not determinable from the control node — never
  has to be known. Predictability comes from a DHCP reservation against the vNIC
  MAC, not from static config in the ISO.
- `azb-netinfo` ships in the ISO and installs to `/usr/local/bin`; `/etc/issue`
  carries the assigned address pre-login via agetty's `\4`. Both exist so the
  DHCP address can be read off the VNC console, which is the only channel to a
  host that has not yet been added to the inventory.
- `just bootstrap-iso-preview` / `bootstrap-iso` / `bootstrap-iso-test`.
- **Every** stock casper GRUB entry carries `autoinstall`, not only the appended
  `azb-autoinstall` one. `set default` governs only the timeout path, so stock
  entry #1 (*Try or Install Ubuntu Server*) remained a one-keystroke route to an
  interactive install — and the host that produces is indistinguishable from one
  where the ISO was never read. Builds now fail if any installer entry is
  interactive.
- `late-commands` write `/etc/azb-bootstrap` (autoinstall applied + `ssh`
  enablement state), so "was this host provisioned by its ISO?" is answerable
  directly rather than inferred from missing artifacts.
- `late-commands` comment out `deb cdrom:` in the target's `sources.list`. With
  the CD detached, apt otherwise resolves packages to `file:/cdrom` paths that no
  longer exist and fails without consulting the network mirror, leaving a host
  that cannot install `openssh-server` — i.e. cannot meet the §6.8 handoff
  contract.
- The rendered-YAML check is now a hard build failure when PyYAML is absent
  (override `--skip-yaml-check`) instead of a printed note. As a silent skip it
  had never run on the workstation that builds every ISO.

### Scope boundary (deliberate)
- The ISO installs the OS, one user, one key, an address and `qemu-guest-agent`
  — nothing else. Docker, `just`, git and the application remain `host_prep` +
  `azblink_app`'s responsibility. A package manifest or golden image in the ISO
  would become a second definition of what is on a host and drift from the roles
  that are the first.

### Known gaps (not closed here)
- ARD-015 is `proposed`, not `accepted`. The first real boot (`azb-ad`,
  2026-08-05) did **not** produce an unattended install: the host came up
  hand-installed, with no sshd, no `azb-netinfo` and an unmodified `/etc/issue`.
  The hardening above closes every failure mode the evidence supports, but the
  specific cause was not isolated — `/var/log/installer/autoinstall-user-data`
  on the host is the outstanding evidence. Flip to `accepted` with `accepted_at`
  + `pr` only once a host has been bootstrapped **unattended** and converged.
- Verification still cannot reject a semantically invalid autoinstall; subiquity
  falls back to an interactive install when it cannot use the config, which
  presents exactly as the failure above. `just bootstrap-iso-test` (qemu) is the
  only check that would catch it and was not run for `azb-ad`.

### References
- ARD-015, ARD-010 (the converge this hands off to), `spec/06-deployment.md` §6.8

## [1.10.0] - 2026-08-01

### Added
- ARD-014: Backend Module Governance — Explicit Exemption Over Silent
  Ungovernedness. `surfaces.yaml` governs `src/backend/*.py` by enumeration, so
  a module named in no glob is ungoverned and no trailer can ever be required
  for it — with nothing to detect it. That is the shape of #249 (`auth.py`),
  #252/#259 (coverage by filename coincidence) and #255 (a glob for a directory
  that never existed), each found by a human reading the config. 9 of 56 backend
  modules matched no glob when this landed.
- **Guard rule 8** — a PR touching a top-level `src/backend/*.py` that matches no
  surface and is not listed under the new `exempt:` key fails. Scope is
  top-level only (`routers/`, `db/`, `schemas/` are covered by `**` globs);
  deleted paths are skipped.
- `exempt:` key in `surfaces.yaml` — explicitly ungoverned by decision, with a
  written reason per entry. Deliberately distinct from "matches no surface":
  #255 established that coverage by coincidence is worse than none, so the key
  records a judgement rather than widening coverage.
- ARD-014 § 4 classifies the nine modules: `ldap_provisioning.py` and
  `ldap_activity.py` → `ldap_schema`; `provisioning.py` and `uc_validation.py` →
  `data_contracts`; `response_utils.py` → `api_contracts`; `activity_types.py` →
  `cross_process_boundaries`; `config.py` → `deploy_topology`; `version_cache.py`
  and `_version.py` → exempt.

### Known gaps (not closed here)
- Rule 8 is per-PR and cannot see the backlog. The compensating control is a
  whole-tree assertion in `tests/arch_guard/test_real_surfaces.py`, which runs in
  CI rather than in the guard.
- Only the top level is protected. A new *subpackage* under `src/backend/`
  matching no `**` glob would still be ungoverned.
- `config.py` on `deploy_topology` is the classification most likely to be
  revisited — adding one env var now needs `Spec-Patch: 06` plus a
  `spec/06-deployment.md` edit. Accepted for the production-safety assertions it
  holds; see ARD-014 § Consequences.

### References
- #265, #259, #249, #252, #255, #247. Depends on 1.9.2, which restored the
  `ARD:` lane this record needed in order to be filed at all.

## [1.9.2] - 2026-08-01

### Fixed
- **Guard rule 3 now accepts `"SOP"` as a spec section.** It built its set of
  valid `spec_sections_affected` values from `docs/architecture/spec/*.md`, and
  `SOP.md` lives one level up — so an ARD declaring `"SOP"` failed rule 3.
  `ARD: ARD-NNN` could therefore never cover `governance_metadata` or
  `ci_release_gates`, leaving `Spec-Patch: SOP` — a lane that may not assert new
  behaviour — as their only option. A **decisional** change to the guard's own
  machinery had no valid lane at all: mislabel it, or declare an emergency. That
  is #247's defect in its third location, and the one place it matters most,
  since it is the surface that governs governance.
- The allowance is one name, not a relaxation: unknown sections are still
  rejected, and `"SOP"` is only accepted when `docs/architecture/SOP.md` actually
  exists — mirroring how numbered sections are validated. Asserted by
  `tests/arch_guard/test_sop_section_lane.py` (4 tests).

### Notes
- Landed on its own, ahead of #265's rule-8 work, for a bootstrap reason worth
  recording: `arch-guard` CI overlays `tools/` from **`main`** (`ref: main`), so
  a PR that both fixes rule 3 *and* adds an ARD declaring `"SOP"` is judged by
  the guard that predates the fix and fails on its own record. Stacking does not
  avoid it, because the overlay ref is `main` rather than the PR base. Splitting
  the fix out is the only way to land both changes with a green guard.

### References
- #247 (first two locations), #234, #265 (the work this unblocks)

## [1.9.1] - 2026-08-01

### Changed
- §02 Component Architecture — the "LDAP Connection Lifecycle" subsection added
  in 1.9.0 no longer enumerates the `ldap_conn()` callers by module name. A
  named list in a living as-built section drifts the moment a caller is added or
  removed and nothing updates it, which is the same coverage-by-enumeration
  defect as #249/#252/#255/#259. The invariant and the "nothing enforces this"
  warning stay, now pointing at TD-9 as well as ARD-013 § Consequences; the
  point-in-time census stays in ARD-013 § 5, where it is scoped to 2026-08-01.
  (§02 bumped 1.9.0 → 1.9.1.)

### References
- #266 (which introduced the list), TD-9

## [1.9.0] - 2026-08-01

### Added
- ARD-013: LDAP Connection Lifecycle — No Pooling, Release Guaranteed at the
  Operation Boundary. Records the decision that shipped in PR #226's commit
  `2fa9226` under a `Spec-Patch: 02` trailer, a lane that covers non-decisional
  edits only. `ldap_client.get_conn()` opens a fresh TCP connection and bind per
  call with no pooling; release is centralised in `safe_ldap()`, which registers
  every connection opened during an operation on a `ContextVar`-scoped bucket and
  releases it in a `finally` — including on the `LDAPException` →
  `LdapUnavailableError` conversion, the path that previously leaked one file
  descriptor per request against a failing directory. `ContextVar` rather than a
  module global because 98 of 100 handlers are sync `def` running in FastAPI's
  threadpool. `ldap_conn()` is the context-manager entry point for callers
  outside the module. Pinned by `tests/unit/test_ldap_conn_lifecycle.py`.
- §02 Component Architecture — new "LDAP Connection Lifecycle" subsection under
  § 2 Backend Architecture, stating the unpooled posture and the invariant that
  every `get_conn()` call must run inside `safe_ldap()` or `ldap_conn()`.
  (§02 bumped 1.7.0 → 1.9.0.)

### Changed
- §03 Data Architecture — the identity row of the ownership matrix (§ 1) now
  names the access pattern precisely: one connect-and-bind per operation, no
  pooling, release guaranteed per ARD-013. (§03 bumped 1.7.0 → 1.9.0.)

### Known gaps (not closed here)
- The ARD-013 § 5 invariant is unenforced. A new `get_conn()` caller written
  outside both wrappers leaks exactly as the pre-#226 code did, and no lint rule,
  test, or guard detects it. It holds today because it was checked by hand — the
  same posture #265 raises about surface coverage.
- No code changes accompany this record. The behaviour has been live on `main`
  since 2026-07-29; only the decision record was missing.

### References
- #264, #232 (closed as unactionable on its metadata half), #226, ARD-011
  (2026-07-29 errata amendment, which carried this question forward)

## [1.8.0] - 2026-07-30

### Added
- §06 Deployment — new §6.6 "Hot Reload Rules" as-built record for the
  build-time frontend API type-generation pipeline: `api.gen.ts` is generated
  from `tests/contract/openapi.baseline.json` by `openapi-typescript`,
  gitignored like `routeTree.gen.ts` (§6.4), and produced automatically by the
  `postinstall`/`prebuild` npm lifecycle hooks in `src/frontend/package.json`.
  `just ui-types` is documented as the manual escape hatch for regenerating
  after an in-place baseline edit. The generator is a devDependency of the
  repo-root `package.json` rather than the frontend workspace's — it
  peer-requires `typescript@^5.x` while the frontend pins `^7.0.2` (the native
  port, whose API has no `ts.factory`), and declaring it in the workspace
  fails `npm install` with ERESOLVE. New integration point, so MINOR rather
  than PATCH. (§06 bumped 1.2.1 → 1.8.0.)

### Known gaps (not closed here)
- Generation covers request bodies and query params only. No backend handler
  declares a `response_model` (or `responses={200: {"model": ...}}`), so
  success-response shapes stay hand-written in `src/frontend/src/types/`.

### References
- #230

## [1.7.0] - 2026-07-29

### Added
- ARD-011: Redis Cross-Worker Event Fan-Out & Middleware Ordering Invariant.
  Records the two decisions that shipped inside PR #226 without a spec update —
  Redis pub/sub as the activity-event transport (uvicorn runs `--workers 2`, so
  in-process delivery reached only the publishing worker), and middleware
  ordering as a load-bearing invariant with CORS outermost so inner rejections
  still carry `Access-Control-Allow-Origin`. Pinned by
  `tests/contract/test_middleware_order.py`.
- ARD-012: Authorization Posture When the Authorization Stores Are Unreachable.
  Decision-only (PR-1 of SOP §6.1) — account-lock state mirrors to Redis, reads
  through on PostgreSQL failure with a completeness sentinel, and fails closed
  only when both stores are unreachable. RBAC, audit, and IP-blocking stay
  fail-open by decision. Implementation tracked in #242.
- §03 Data Architecture — new §3.3 "OrgDB Composition": the eight `db/` mixins,
  why composition was chosen over a delegating facade, and why the mixins are
  deliberately not independently instantiable.
- §08 Integration Points — new "Where Routes Live" subsection: the `routers/`
  layout, the byte-identical OpenAPI gate, and `ROUTER_ORDER` as part of the API
  contract rather than an implementation detail.

### Changed
- §02 Component Architecture — replaced the single-file-orchestrator description
  with the as-built composition root. `main.py` is 157 lines (was 3,150) and
  holds no handlers; the module inventory now lists `routers/` (100 routes),
  `db/` (8 mixins + `tables.py`), `schemas/` (39 models), `auth.py`, `deps.py`,
  and `observability.py`. Dependency diagram redrawn. Middleware ordering and
  Redis fan-out reference ARD-011 rather than restating the decisions.
  (§02 bumped 1.0.0 → 1.7.0.)
- §03 Data Architecture — ownership matrix now names the owning `db/` mixin
  instead of `orgdb.py`; §3 preamble points at `db/tables.py` and records why
  the 19 `Table` definitions stayed in one module (`create_all()` operates on
  the whole `MetaData`, so a table defined in an unimported mixin module would
  silently not be created). (§03 bumped 1.2.0 → 1.7.0.)
- §08 Integration Points — the endpoint-domain table is now keyed by router
  module with verified route counts and authorization levels.
  (§08 bumped 1.2.1 → 1.7.0.)

### Removed
- §03 — the `api_keys` table definition and its ownership-matrix row. Dropped by
  `migrations/018_drop_api_keys.sql` and absent from `db/tables.py`; the spec had
  carried it since.
- §08 — the QR-code, QR-preview, and API-key endpoint rows. None of those routes
  exist in the backend. Noted inline in §4 so the removal is not silent.

### Known gaps (not closed here)
- §03 §3.1 documents column tables for 11 of the 19 tables. The other eight are
  named in the ownership matrix but have no column table; flagged inline.
  `tests/contract/test_db_surface.py` pins the real schema in the meantime.
- §03 §4 migration list stops at `025`; `028` and `029` are referenced from §08.

### References
- ARD-011, ARD-012, PR #226, issues #227, #228, #231

## [1.6.1] - 2026-07-27

### Changed
- §06 Deployment — new §6.6 subsection "Remote-Synced Working Trees" documenting
  as-built behaviour when the working tree is mirrored to the Docker host by a
  file synchronizer: single-file bind mounts (§6.4) serve stale content after a
  sync because temp-file-plus-rename replaces the host inode, so they need a
  service restart rather than a reload; and a non-`localhost` hostname must be
  present in Vite's `server.allowedHosts` or the dev server 403s. Clarification
  only — no architectural change. (§06 bumped to 1.2.1.)

### References
- Spec-Patch: 06

## [1.6.0] - 2026-07-10

### Added
- ARD-010: Production Deployment Artifact. Ansible becomes the sole production
  deploy path (`deploy/install.sh` removed). Base + override compose topology
  (prod-safe skeleton + `docker-compose.{dev,prod,tls}.yml`, selected by
  `azblink_compose_files`/`azblink_compose_profiles`); static-nginx prod UI
  (`directory-ui-prod` / `Dockerfile.ui-react`); loopback port binding + Grafana/
  Redis/Traefik secret hardening via `env.j2`/vault; LDAP demo-user removal with a
  vault-rendered real-admin bootstrap, an Ansible `preflight.yml` secret-default
  gate, and a non-bricking runtime `assert_no_demo_identities` + idempotent purge.
- §06 Deployment — new §6.7 Production Deployment Topology (bumped to 1.2.0).

### Changed
- §07 Security — `assert_production_config_safe` gains an `ORG_QR_SIGNING_SECRET`
  default check; the Ansible `preflight.yml` gate enforces the Authentik / Redis /
  Grafana / LDAP-admin secret defaults the API process cannot see (container-only).

### Deferred
- Backup + tracked migration runner (Bucket B) — commented `backup.yml`/
  `migrate.yml` hooks only.

### References
- ARD-010

## [1.5.0] - 2026-07-08

### Changed
- §07 Security — the aggregate directory-browse endpoints (address-book
  visibility) move behind `require_directory_read` (operator-only), resolving the
  ARD-009 open follow-up; §07 gains the `require_directory_read` documentation it
  had lacked since ARD-009. (§07 bumped accordingly.)

### References
- ARD-009 (amendment, 2026-07-08), PR #204

## [1.4.0] - 2026-07-05

### Added
- §05 Provisioning — Default-profile UC service seeding: `OrgDB.init()` idempotently
  ensures the default profile carries its xmpp+sip services on every startup
  (insert-if-missing, never clobbering operator/GUI edits), seeded from `UCCHAT_*`
  env as a bootstrap default. Service config (domain/URL) is now editable at runtime
  from the admin GUI, with the DB row as source of truth. Deploy-verify signal
  `default_profile_services_ok` added to `/api/health/deep` and asserted by the
  Ansible gate. (§05 bumped to 1.4.0)

### References
- Spec-Patch: 05

## [1.3.0] - 2026-07-03

### Added
- ARD-007: Authentik LDAP Source (LDAP-backed Web SSO). Authentik federates
  identity from the platform OpenLDAP via an LDAP source; bind-based login,
  no password copy; dogfooded `cn=authentik-sync` provisioned client.

### Changed
- §04 Authentication — Plane B user store is now LDAP-backed (bumped to 1.1.0).
- §06 Deployment — §6.5 bootstrap adds the LDAP-source step; authentik-seed now
  depends on directory-api (bumped to 1.1.0).

### References
- ARD-007

## [1.2.1] - 2026-07-03

### Changed
- Formalized the shipped LDAP client provisioning capability as ARD-006 (PATCH).

### References
- ARD-006, PR #179, #181

## [1.2.0] - 2026-07-03

### Added
- LDAP client provisioning & reconciliation capability (ARD-006).
