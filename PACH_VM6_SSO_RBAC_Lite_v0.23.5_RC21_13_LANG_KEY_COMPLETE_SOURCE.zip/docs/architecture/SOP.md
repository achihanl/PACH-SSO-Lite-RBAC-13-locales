# Architecture Specification — Standard Operating Procedure

This document governs how the architecture specification and ARDs (Architecture Records of Decision) are versioned, updated, and maintained.

## Versioning Scheme

The architecture specification as a whole uses [Semantic Versioning](https://semver.org/).

| Component | Trigger | Example |
|-----------|---------|---------|
| **MAJOR** (X.0.0) | Breaking architectural change — new auth model, LDAP restructure, component added/removed | 1.0.0 → 2.0.0 |
| **MINOR** (0.X.0) | New capability without breaking existing architecture — new integration point, new provisioning mode | 1.0.0 → 1.1.0 |
| **PATCH** (0.0.X) | Clarification, typo fix, diagram update, no architectural change | 1.1.0 → 1.1.1 |

The version is tracked in two places:
- `README.md` header (`<!-- spec-meta -->` comment and version badge)
- `CHANGELOG.md` (latest entry)

Both must be updated together on every version bump.

## Update Triggers

The spec **MUST** be updated when:

1. **Any PR changes system architecture** — new service, removed component, changed data flow, new integration point
2. **Any new ARD is created** — add to README.md ARD table and CHANGELOG.md
3. **Any ARD status changes** — e.g., `accepted` → `superseded`; update both the ARD file and README.md table
4. **CLAUDE.md architecture section changes** — spec and CLAUDE.md must stay in sync (CLAUDE.md has summary, spec has detail)

## CHANGELOG Format

Follows [Keep a Changelog](https://keepachangelog.com/):

```markdown
## [X.Y.Z] - YYYY-MM-DD

### Added
- New sections, ARDs, or capabilities

### Changed
- Modified sections with summary of what changed

### Removed
- Deprecated or removed content

### References
- PR #NN, ARD-NNN
```

## ARD Process

### When to Create an ARD

Create an ARD when:
- A significant architectural decision is made (new component, changed data flow, technology choice)
- An existing architectural pattern is replaced or deprecated
- A design trade-off with lasting consequences is chosen

Do **not** create an ARD for:
- Bug fixes or minor code changes
- UI/UX changes that don't affect architecture
- Dependency version bumps (unless they force architectural changes)

### ARD Lifecycle

```
proposed → accepted → (optionally) superseded or deprecated
```

- **proposed** — Decision is under consideration; not yet committed
- **accepted** — Decision has been implemented or approved for implementation
- **superseded** — Replaced by a newer ARD (link via `Superseded by` field)
- **deprecated** — No longer relevant but not replaced by anything specific

### Creating a New ARD

1. Copy `decisions/_TEMPLATE.md` to `decisions/ARD-NNN-descriptive-slug.md`
   - NNN = next available number (monotonically increasing, never reused)
   - Check the README.md ARD table for the highest existing number
2. Fill in all template fields (Context, Decision, Alternatives, Consequences, References)
3. Set status to `proposed` or `accepted` (if already implemented)
4. Update `README.md` ARD table
5. Update `CHANGELOG.md` with the new ARD
6. Bump spec version (MINOR for new capability, MAJOR for breaking change)
7. Commit all changes together

### Naming Convention

```
ARD-NNN-descriptive-slug.md

Examples:
  ARD-001-single-ldap-architecture.md
  ARD-002-authentik-only-auth.md
  ARD-015-redis-session-cache.md
```

- Numbers are zero-padded to 3 digits
- Slug is lowercase, hyphen-separated, describes the decision topic
- Numbers are never reused, even if an ARD is deprecated

## Maintenance Checklist (for AI Agents)

After any architectural PR, verify:

- [ ] Affected spec section(s) updated with `[AS-BUILT]` / `[TARGET v2.0]` markers
- [ ] `<!-- spec-meta: { last_updated: "..." } -->` bumped in affected sections
- [ ] ARD created if decision warrants it
- [ ] `README.md` version badge and ARD table current
- [ ] `CHANGELOG.md` has entry for this version
- [ ] `CLAUDE.md` architecture summary consistent with spec (no conflicts)

## Section Metadata Format

Each spec section begins with an HTML comment for machine parsing:

```markdown
<!-- spec-meta: { section: "01", version: "1.0.0", last_updated: "2026-03-07" } -->
# 01 — System Overview
```

Update `last_updated` whenever the section content changes. The `version` tracks the overall spec version at which this section was last modified.

## AS-BUILT vs TARGET Markers

Sections use inline markers to distinguish current implementation from v2.0 target:

- `[AS-BUILT]` — Currently implemented and in production/dev
- `[TARGET v2.0]` — Planned in the v2.0 specification but not yet implemented

This helps both humans and AI agents understand what exists in code vs. what's aspirational.

> **Marker update (2026-04-20, per design proposal 2026-04-19-spec-governance-hardening):**
> `[TARGET v2.0]` is deprecated. New markers: `[AS-BUILT]` (unchanged) and `[PROPOSED: ARD-XXX]`
> (requires an accepted or proposed ARD). Unauthorised `[PLANNED]` text is forbidden.
> Migration of existing markers lands in Phase 2 of the governance-hardening rollout.

## Enforcement (amended 2026-04-20 — design proposal 2026-04-19-spec-governance-hardening)

**Mode: fail (since 2026-07-31, Phase 1a-flip, #234).** The guard exits non-zero on a
violation in CI (`arch-guard.yml`) and in the local `commit-msg` hook. The calibration
window opened when Phase 1a merged 2026-04-21 and closed on its 60-day arm 2026-06-20;
the `--warn-only` flag and the workflow's `continue-on-error` were removed together, as
the workflow comment had said they must be. `arch-guard-post-merge.yml` is unchanged —
it never carried `--warn-only`, because it needs a truthful exit code to decide whether
to file a drift issue.

The `arch-guard` check is **not** a required status check; see § Known enforcement gap.
A failing run is visible on the PR but does not block the merge button server-side.

The rules above are enforced by `tools/arch_guard.py`:

1. **Surface-path coverage** — PRs touching paths in `docs/architecture/surfaces.yaml` must carry `ARD:` or `Spec-Patch:` trailer covering every touched surface.
2. **ARD immutability** — accepted ARDs are append-only via `## Amendments`.
3. **ARD↔spec consistency** — (a) `spec_sections_affected` names real files; (b) `supersedes`/`superseded_by` are bidirectional.
4. **Marker consistency** — `[PROPOSED: ARD-XXX]` resolves to a real ARD.
5. **CLAUDE.md Architecture anchor** — edits inside `## Architecture (Quick Reference)` are surface changes.
6. **ARD-POST back-pressure** — open `arch-post-followup` issues ≥7d block new architectural PRs.
7. **Archive immunity** — `docs/archive/**` is exempt.
8. **Backend module governance** — a top-level `src/backend/*.py` must match a surface glob or be listed under `exempt:` in `surfaces.yaml` (ARD-014).

#### Rule 8 — why enumeration needed a completeness check

`surfaces.yaml` governs `src/backend/*.py` by enumeration, so a module named in no glob is
ungoverned and no trailer can ever be required for it. Nothing detected that: #249 (`auth.py`),
#252/#259 (coverage by filename coincidence) and #255 (a glob for a directory that never existed)
were each found by a human reading the config, never by a check. Rule 8 is that check.

`exempt:` is the escape hatch and is deliberately **not** the same as "matches no surface" — it
records that someone decided a file carries no architectural content, with a comment saying why.
Editing it is a `governance_metadata` change and needs the same coverage as adding a surface.

Scope is top-level only: `routers/`, `db/` and `schemas/` are governed by `**` globs, so new files
there inherit coverage. Deleted paths are skipped. ARD-014 § 4 records the nine classifications made
when the rule landed.

Rule 8 is per-PR and cannot see the backlog. `tests/arch_guard/test_real_surfaces.py` carries the
compensating whole-tree assertion that every top-level module is governed or exempt.

See proposal §8 for full rationale. Trailer conventions summarised in **§ Commit trailers** below; the same table is mirrored into root `CLAUDE.md` in Phase 1a.

#### Trusted inputs in CI

ARD-005 decided that "CI uses sparse-checkout from `main` so a PR cannot neuter its own
guard". Two inputs decide a guard run's verdict, and until now only one of them was
sourced that way:

| Input | Sourced from | Why |
|-------|--------------|-----|
| `tools/arch_guard.py`, `tools/_lib/**` | `main`, overlaid onto the PR checkout | The rules themselves. |
| `docs/architecture/surfaces.yaml` | `main`, overlaid onto the PR checkout | Decides *which paths* the rules run over. Trusted code over a PR-authored surface list still lets a PR drop its own files out of governance. |
| `docs/architecture/decisions/**` | the **PR** — deliberately | The `ARD:` lane requires the guard to see an ARD the PR adds. Trust comes from rule 2 instead, which reads the base-ref blob via `git show <base>:<path>` — so editing an accepted ARD's `spec_sections_affected` to self-grant coverage fails whatever the PR's copy says. |

Overlaying `surfaces.yaml` does not hide a PR's own edit to it: `changed_paths` comes
from `git diff --name-only base..head`, so the edit is still in the diff, still trips
`governance_metadata`, and still needs `Spec-Patch: SOP`. Only the list the guard
*evaluates against* changes.

Consequence to know about: a PR that **adds** a surface or widens a glob is judged
against `main`'s list, so the new coverage takes effect on the run *after* merge — the
same one-run lag the guard's own code has always had.

The local pre-commit/`commit-msg` path has no trusted checkout and reads everything from
the working tree; it is a convenience check, and CI is the enforcement point. It locates
the commit message with `git rev-parse --git-path COMMIT_EDITMSG`, so it also works in
linked worktrees, where `.git` is a file.

The overlay is asserted by `tests/arch_guard/test_ci_trusted_sources.py` — the defect
lived entirely in the workflow's shell step, so every rule-level test passed while the
hole was open.

### Commit trailers

Architectural changes carry one of:

- `ARD: ARD-NNN` — references an accepted (or proposed during PR-1 of §6.1) ARD whose `spec_sections_affected` covers every touched surface.
- `Spec-Patch: NN[,MM,…]` — non-decisional edits to listed spec section(s). May not assert new behavior. Covers a surface only when the named section file is **actually edited** in the same diff (rule R2-2).
- `Spec-Patch: SOP` — the same lane for surfaces mapped to the literal section `SOP` rather than a numbered spec file: `governance_metadata` (the guard's own config, tooling and workflows) and `ci_release_gates`. Covers them only when `docs/architecture/SOP.md` is actually edited, mirroring R2-2. **`ci_release_gates` only acquired this lane in #234** — this paragraph described it from the start, but the surface's `section_map` entry listed `06-deployment` alone, and the guard credits `Spec-Patch: SOP` by looking for the literal `SOP` in that mapping. Until then its only real lane was `Spec-Patch: 06` plus an edit to `spec/06-deployment.md`, a section about deployment topology with nothing to say about a pre-commit hook stage.
- `ARD-POST: placeholder` — emergency lane. CI creates an `arch-post-followup` tracking issue; resolve within 7 days.
- **Dependabot lane** — no trailer to write. A range in which **every** commit carries `Signed-off-by: dependabot[bot] <support@github.com>` is covered on all surfaces. § When to Create an ARD already rules out ARDs for dependency bumps, yet a bump to a governed file (`release.yml`, `Dockerfile.*`, `arch_guard_requirements.txt`) demanded a trailer Dependabot cannot write — a merge freeze on `chore(deps)` (#300). One commit without the sign-off, such as a human fix pushed onto the Dependabot branch, switches the lane off for the whole range. GitHub squash-merge keeps the sign-off, so the post-merge check agrees. The sign-off is self-asserted like every other trailer here; forging it is deliberate, not a mistake the guard exists to catch. Asserted by `tests/arch_guard/test_guard_rules.py`.

Trailers are read from **every** all-trailer paragraph in the commit message, not
only the final one. `git interpret-trailers` recognises the last paragraph alone,
which silently orphaned coverage behind a trailing `Co-authored-by:` line and
behind GitHub's squash-merge concatenation — both shapes shipped on `main` and
filed spurious drift issues (#245, #254). A paragraph containing any non-trailer
line is prose and is ignored whole, so a commit that *discusses* a trailer is not
credited with *using* it.

> **`ci_release_gates` lists `Justfile` whole-file.** Surfaces match paths, not
> intent, so a recipe that has nothing to do with CI or releases — a local
> convenience wrapper around a script — sits on the surface exactly as
> `release.yml` does, and needs the same `Spec-Patch: SOP` plus an edit to this
> file. Anchor-level scoping does not exist; the whole file is the surface.
> Adding the `bootstrap-iso-run` / `bootstrap-iso-clean` wrappers is the change
> that surfaced it. `Spec-Patch: 06` is not the alternative — see the note in
> `surfaces.yaml` on why `spec/06-deployment.md` is the wrong place to describe
> a Justfile recipe.

> **CI builder settings are on this surface too.** The `Start Docker stack` steps
> in `pr-checks.yml` and `qa.yml` set `COMPOSE_BAKE=false` from #349 until
> 2026-10-22: compose's bake builder rejected the Dockerfiles' `network: host`
> without an `--allow=network.host` entitlement, which `docker compose` cannot
> pass. Compose v5 builds only through bake and ignores `COMPOSE_BAKE`, so the
> builds dropped `network: host` instead and both steps lost the setting. This
> changes no gate and no service set, but the workflow files are listed
> whole-file, so it travels with `Spec-Patch: SOP`.

> **So is where CI runs.** Since 2026-10-20 every job runs on a self-hosted
> runner labelled `azb-ad-ci` (GitHub-hosted jobs are refused while the
> account's payments fail). The stack-starting jobs bring up the dev compose
> files plus `.github/ci/compose.ci.yml`, a separate `azblink-ci` project on
> 2xxxx ports, so they cannot touch a dev stack on the same box. Same gates,
> same service set; `docs/ci/self-hosted-runner.md` covers install and sharing.

> **And how long CI waits for Authentik.** A fresh Authentik spends 2.5-4 min
> on migrations, longer when the shared box is busy. Since 2026-10-21
> `authentik-seed` waits up to `AUTHENTIK_WAIT_SEC` (default 600 s), and both
> `Start Docker stack` steps poll the OIDC discovery URL for 12 min. They stop
> early and print the seed's logs when it exits non-zero. Job timeouts rose to
> fit (backend-tests 35 min, playwright 25 min). Same gates, longer budget.

> **And how CI finds a PR's changed files.** Until 2026-10-27, three `pr-checks.yml`
> jobs re-fetched the base branch with `--depth=1` after a full checkout. When `main`
> moved while a job was queued, that shallow fetch cut the new `origin/main` off from
> its history, and `git diff origin/main...HEAD` failed with "no merge base".
> `backend-tests` went red, and `frontend` and `python-lint` passed because their
> pipes swallowed the error, so they linted nothing. The re-fetch is now a full one.
> Same gates, now actually run.

> **The `Justfile` `release` recipe is here too.** It deletes the fresh tag so
> the amended commit can be re-tagged, which left git-cliff seeing no tag: v0.19.0
> shipped with `## [Unreleased]` as its heading. Since 2026-10-21 the recipe
> passes `--tag "v$(cz version --project)"` to git-cliff. Same release steps.

> **`fresh-host.yml` joined on 2026-10-22.** It converges a throwaway VM with the
> production playbook and health-checks it (spec §06 §6.7). It runs on PRs that
> touch a deploy input, nightly and by hand, so it is listed like `qa.yml`. The
> `Justfile` `deploy` and `deploy-fresh-test` recipes arrived with it.

> **And where `qa.yml`'s browser runs.** Since 2026-10-26 the Playwright job
> starts a `playwright run-server` container (image and version from the
> installed `@playwright/test`) and the tests connect to it through
> `PW_BROWSER_WS`. Host Chromium aborted in-flight requests with
> `ERR_NETWORK_CHANGED` whenever Docker on the shared box added or removed an
> interface, which blanked pages at random. The suite, its specs and its
> `BASE_URL` are unchanged.

> **`governance_metadata` had no non-emergency lane before 2026-07-31.** It maps
> to `SOP`, which no numeric `Spec-Patch: NN` token can match, and `Spec-Patch:
> SOP` credited `ci_release_gates` only — so every SOP-mandated version bump had
> to declare an emergency (#247). `docs/architecture/CHANGELOG.md` was also on
> that surface and is no longer: it is a record of decisions, not a decision
> surface, and it never travels without the spec-section edits that carry their
> own coverage.

> **…and it had no `ARD:` lane at all until 2026-08-01.** Rule 3 built its set
> of valid `spec_sections_affected` values from `docs/architecture/spec/*.md`,
> and `SOP.md` lives one level up — so an ARD declaring `"SOP"` failed rule 3,
> and `ARD: ARD-NNN` could never cover `governance_metadata` or
> `ci_release_gates`. Their only lane was `Spec-Patch: SOP`, which may not
> assert new behaviour. A **decisional** change to the guard's own machinery
> therefore had no valid lane: mislabel it, or declare an emergency. That is
> #247's defect in its third location, and the one place it matters most, since
> it is the surface that governs governance. Rule 3 now resolves `"SOP"` to
> `docs/architecture/SOP.md`; unknown sections are still rejected, and the
> allowance is anchored to that file actually existing. Asserted by
> `tests/arch_guard/test_sop_section_lane.py`.

### Emergency lane

Hotfixes may carry `ARD-POST: placeholder`. CI creates an `arch-post-followup` tracking issue labeled accordingly. Resolve within 7 days. Rule 6 back-pressure blocks new architectural PRs while an issue is ≥7 days old.

### Known enforcement gap — platform limitation (noted 2026-06-10)

The repository is **private on the GitHub Free plan**, which disables branch protection
rules, rulesets, and CODEOWNERS review enforcement. Consequences until the repo moves
to GitHub Pro or becomes public:

- All CI checks (arch-guard, pr-checks, dead-code) are **advisory** — nothing blocks merge server-side.
- `.github/CODEOWNERS` is **not enforced** — the "PR can't neuter its own guard"
  defense (sparse-checkout of guard sources from `main` + CODEOWNERS on `arch-*` paths)
  relies on reviewer discipline, not platform enforcement.
- Direct pushes to `main` are possible server-side; the local `protect-main`
  pre-commit hook is the only barrier and exists only on configured clones.

Interim mitigations: default workflow token is read-only, Actions cannot approve PRs,
and `arch-guard-post-merge` files drift-tracking issues after the fact. Revisit this
section when the plan/visibility changes; flipping arch-guard to `--fail` mode does
not close this gap on its own.

The flip landed anyway (#234, 2026-07-31). Registering `arch-guard` as a required check
was the one acceptance item it could not satisfy, and it stays open against this section
rather than against the guard: fail mode is what makes the check *say* something true,
and required-status is what would make it *bind*. Those are separable, and only the
second needs a billing decision.
