---
title: Authentik Custom CSS Theming
description: Reference notes on theming Authentik's PatternFly and Lit Shadow DOM UI via Brand custom CSS
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: Authentik Custom CSS Theming
libraries: ["authentik", "patternfly"]
validated: 2026-03-11
source: https://docs.goauthentik.io/brands/custom-css/
supersedes: null
---

## Summary
Authentik uses PatternFly 4 (`pf-c-*` classes) + Lit web components with Shadow DOM. Custom CSS injected via Brand settings propagates into Shadow DOMs. Key customization via CSS variable overrides and `:host()` selectors.

## CSS Variables
- `--ak-accent` — primary accent color
- `--ak-dark-background` / `--ak-dark-background-light` — dark mode backgrounds
- `--pf-global--primary-color--100` — PatternFly primary (buttons, links, focus)
- `--pf-global--BackgroundColor--dark-100` — dark mode page bg
- `--pf-c-login__main--BackgroundColor` — login card bg
- `--pf-c-button--m-primary--BackgroundColor` — primary button bg

## Key Selectors
- `.pf-c-login__main` — login card
- `.pf-c-background-image` — login page background
- `.pf-c-button.pf-m-primary` — primary buttons
- `.pf-c-form-control` — text/password inputs
- `.pf-c-page__sidebar` — sidebar (admin/user)
- `ak-flow-executor::part(locale-select)` — hide locale dropdown
- `:host(ak-stage-identification)` — username stage (inside Shadow DOM)
- `:host(ak-stage-password)` — password stage
- `:host(ak-interface-user)` — user interface
- `[data-ak-interface-root="ak-interface-admin"]` — scope to admin

## Dark Mode
- Brand `attributes`: `{"settings": {"theme": {"base": "dark"}}}`
- Override dark palette with `--pf-global--BackgroundColor--dark-*` and `--ak-dark-background`

## Gotchas
- Shadow DOM boundaries: `:host()` selectors work inside Brand CSS, not from external stylesheets
- `!important` frequently needed due to PatternFly specificity
- PF4→PF5 migration underway (2025.12+): `pf-c-*` → `pf-v5-c-*` eventually
- `::part()` only works for elements with explicit `part` attribute
- No per-flow CSS scoping — CSS applies to ALL flows
- Page reload required after CSS changes
- On 2025.8: Brand CSS may not propagate into deeply nested Shadow DOMs (fixed in 2025.12)
