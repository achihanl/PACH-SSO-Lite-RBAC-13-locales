---
title: osixia OpenLDAP stats-log capture (olcLogFile)
description: Reference notes on enabling and parsing olcLogFile stats-log output from osixia/openldap for LDAP client inventory
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: osixia OpenLDAP stats-log capture (olcLogFile)
libraries: ["osixia/openldap:1.5.0", "openldap-2.4"]
validated: 2026-07-01
source: empirical (live container probe) + deploy/dev/ldap/ppolicy-config.ldif pattern
supersedes: null
---

## Summary
`osixia/openldap:1.5.0` runs `slapd -d ${LDAP_LOG_LEVEL:-256}` (stats), so connection/bind lines always stream to stderr regardless of the `olcLogLevel` config value (which defaults to `none`). Setting `olcLogFile` on `cn=config` **also** mirrors that output to a file. Point it at a path on the `azblink_ldap_data` volume (`/var/lib/ldap`) and a second container can mount the volume read-only and tail it — no docker socket needed.

## API Reference
Stats log line grammar (correlate by `conn=N`):
- `<hex> conn=N fd=X ACCEPT from IP=<ip>:<port> (IP=0.0.0.0:389)` → source IP
- `<hex> conn=N op=0 BIND dn="<dn>" method=128` then `... BIND dn="<dn>" mech=SIMPLE ssf=0` → bind DN + mech (SASL shows `mech=DIGEST-MD5|PLAIN`)
- `<hex> conn=N fd=X closed` → session end
- Anonymous bind → `dn=""`.

Enable via bootstrap ldif (applied first boot, survives `just reset` volume wipe):
```ldif
# deploy/dev/ldap/logfile-config.ldif
dn: cn=config
changetype: modify
replace: olcLogFile
olcLogFile: /var/lib/ldap/slapd-stats.log
```
Mount into osixia bootstrap dir (compose openldap volumes):
`./ldap/logfile-config.ldif:/container/service/slapd/assets/config/bootstrap/ldif/logfile-config.ldif:ro`

Live apply (dev, no restart): bind DN is `cn=admin,cn=config` (NOT `cn=config`):
```
docker exec -i azblink-openldap ldapmodify -x -D "cn=admin,cn=config" -w adminpassword <<'EOF'
dn: cn=config
changetype: modify
replace: olcLogFile
olcLogFile: /var/lib/ldap/slapd-stats.log
EOF
```

## Patterns
- Reader (API) container: mount `azblink_ldap_data` read-only (e.g. `/var/ldap-data:ro`), tail `/var/ldap-data/slapd-stats.log` with byte-offset tracking; reset offset if file shrinks (truncation/rotation).
- Both containers can mount the same named volume simultaneously (openldap rw, reader ro).
- Log file created as `openldap:openldap`, `/var/lib/ldap` is writable by that uid.

## Gotchas
- `cn=config` bind FAILS with `Invalid credentials (49)` — must bind `cn=admin,cn=config` (config-admin) with `LDAP_CONFIG_PASSWORD`.
- `olcLogLevel` config = `none` is a red herring; runtime `-d 256` wins → logs still flow.
- osixia "can be finicky about config LDIFs" on first boot (see ppolicy-config.ldif note) — provide a manual `ldapmodify -Y EXTERNAL -H ldapi:///` fallback in docs.
- `back_monitor.so` is present in the image but the monitor DB is NOT configured; only `back_mdb/memberof/refint/ppolicy` modules load by default.
- `olcLogFile` does NOT rotate — unbounded growth; needs logrotate/periodic-truncate as a follow-up.
- Prod parity: dev compose ≠ prod; the same `olcLogFile` must be applied in `deploy/ansible/` OpenLDAP config.
