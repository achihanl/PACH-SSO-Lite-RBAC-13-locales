---
title: "Pattern: Dual Auth Plane with SSO Overlay"
description: Using LDAP as the authoritative identity store with Authentik SSO as an optional overlay, so UC services keep working when SSO is down
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
---

# Pattern: Dual Auth Plane with SSO Overlay

**Context:** AZBlink Directory integrating Authentik SSO while preserving UC independence

## The Pattern

When a platform has both:
- **UC services** (XMPP/SIP) that authenticate via LDAP bind (Plane A)
- **Web admin UI** that benefits from SSO/OIDC (Plane B)

...and the design invariant is "UC must work without SSO":

**Use LDAP as authoritative identity store, with SSO as an optional overlay layer.**

## Data Flow

```
User Creation ──► AD LDAP (authoritative) ──► UED Sync ──► UED LDAP (XMPP/SIP)
                       │
                       │ LDAP Source import (periodic, ~5min)
                       ▼
                   Authentik ──► OIDC tokens ──► Admin UI
```

## Key Properties

1. **LDAP owns user lifecycle** — create, update, disable, delete all happen in LDAP first
2. **Authentik is a consumer** — it reads from LDAP, doesn't write to it (except optional password writeback)
3. **UC auth is SSO-independent** — XMPP/SIP bind against UED's LDAP, never touch Authentik
4. **Admin UI has dual login** — LDAP bind (fallback) + OIDC (preferred when Authentik available)
5. **Break-glass works** — When Authentik is down, LDAP login + break-glass bypass keep admin access
6. **Termination is multi-step** — Disable LDAP → Revoke Authentik sessions (API) → Terminate UC sessions

## When This Pattern Applies

- UC services that only understand LDAP bind auth (no OIDC/SAML support)
- SSO provider that can import from LDAP but not export to it
- Requirement for SSO-independent operation of critical services
- Break-glass/emergency access requirements

## Anti-Pattern: SSO-Authoritative with LDAP Bridge

Making the SSO provider authoritative and bridging to LDAP (via SCIM→LDAP bridge or custom sync) is fragile because:
- Bridge is an additional failure point
- Schema translation is lossy (SSO user model ≠ LDAP objectClasses)
- Breaks UC independence if bridge fails
- Password sync becomes bidirectional (complex, race conditions)
