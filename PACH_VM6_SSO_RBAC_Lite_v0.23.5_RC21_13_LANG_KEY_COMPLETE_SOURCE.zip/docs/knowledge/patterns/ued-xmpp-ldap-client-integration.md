---
title: "Pattern: UED XMPP ↔ Platform LDAP Client Integration"
description: Dev-reference pattern for UED's ejabberd XMPP server authenticating against the platform's OpenLDAP via SASL-PLAIN and X-OAUTH2
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
---

# Pattern: UED XMPP ↔ Platform LDAP Client Integration

**Context:** AZBlink PED80 UC Server (UED) XMPP authentication against the platform's single OpenLDAP — dev reference.
**Validated:** 2026-04-15 — fresh-user provisioning → SASL-PLAIN auth verified end-to-end.
**XMPP server implementation:** **ejabberd** (confirmed 2026-04-16). PLAIN handled by `mod_auth_ldap`; X-OAUTH2 handled by `ejabberd_oauth` (internal token store).

## Topology

```
┌──────────────────────────┐        ┌──────────────────────────────┐
│  XMPP client (slixmpp,   │        │  UED PED80 VM                │
│  mobile app, browser,    │        │   - XMPP server :5222/5269   │
│  etc.)                   │        │   - HTTPS admin :8082        │
└────────────┬─────────────┘        │   - LDAP client module       │
             │ TCP :5222             │                              │
             │ SASL-PLAIN            │   realm: private.z           │
             │ or X-OAUTH2           └───────────┬──────────────────┘
             ▼                                    │ LDAP bind
┌──────────────────────────────────────────────┐  │ as bind DN
│  192.168.122.220 (libvirt NAT)               │  │
└──────────────────────────────────────────────┘  ▼
                                        ┌──────────────────────────┐
                                        │  platform OpenLDAP       │
                                        │  (azblink-openldap)      │
                                        │   exposed 0.0.0.0:1390   │
                                        │   base: dc=azblink,…     │
                                        └────────┬─────────────────┘
                                                 │ fetches inetOrgPerson
                                                 ▼
                                        SSHA userPassword verify
```

## The Pattern

UED XMPP's LDAP-client auth module delegates SASL-PLAIN / bind to the platform's OpenLDAP — the single authoritative identity store (ARD-001). No user sync required; UED reads live.

- **Single LDAP is authoritative** — create once on the platform, XMPP sees it immediately.
- **`userPassword` is dual-purpose** (AD login + XMPP bind). `AstAuthPassword` is separate (SIP only).
- **Realm namespacing differs from LDAP base DN** — LDAP base is `dc=azblink,dc=com` but XMPP JIDs use `{uid}@private.z` (the realm UED advertises). Map is `uid` → `localpart`.

## End-to-end user flow (Web SSO → provisioned credentials → XMPP message)

Validated 2026-04-15. Five phases, single source of truth = platform OpenLDAP.

```
PHASE A — SSO + token (OIDC PKCE)
    User → Debugger: open + click Login
    Debugger → Authentik: /authorize?code_challenge=…
    User ↔ Authentik: credential entry
    Authentik → Debugger: 302 /callback?code=…&state=…
    Debugger → Authentik: POST /token (code + verifier)
    Authentik → Debugger: access_token (JWT, preferred_username=alanl)

PHASE B — Provision (backend issues sealed creds)
    Debugger → Backend: POST /api/provision/device (Bearer JWT, Curve25519 pubkey, deviceId)
    Backend → JWKS:    verify JWT signature
    Backend → OpenLDAP: get_user(uid='alanl')
    OpenLDAP → Backend: inetOrgPerson + UC objectClasses + userPassword + AstAuthPassword
    Backend resolves profile_services (xmpp domain, ws_url; sip…)
    Backend builds kit { xmppPassword=userPassword, sipPassword=AstAuthPassword, services }
    Backend → Debugger: 200 { sealedCredentials, services }   (libsodium box_seal to client pubkey)

PHASE C — Unseal (client recovers plaintext)
    Debugger: box_seal_open(client privkey) → plaintext xmppPassword + sipPassword

PHASE D — XMPP SASL-PLAIN bind (mod_auth_ldap bridges)
    XMPP client → ejabberd: TCP :5222 + <stream:stream to='private.z'>
    ejabberd → client:      <stream:features> SASL: PLAIN, X-OAUTH2
    XMPP client → ejabberd: <auth mechanism='PLAIN'> base64(\0alanl\0xmppPassword)
    ejabberd (mod_auth_ldap) → OpenLDAP: bind uid=alanl,ou=people,dc=azblink,dc=com
    OpenLDAP: verifies SSHA hash → OK
    ejabberd → client: <success/> + restart stream + bind + session

PHASE E — Messaging (stanza routing)
    Sender → ejabberd: <message to='xmpptest01@private.z' type='chat'>ping</message>
    ejabberd routes by JID (recipient session must be authenticated via Phase D)
    ejabberd → Recipient: <message from='alanl@private.z'>ping</message>
```

| Phase | What gets validated |
|---|---|
| A. SSO + token | OIDC PKCE flow, Authentik issues JWT with `preferred_username` claim |
| B. Provision | Backend trusts JWT → LDAP lookup → sealed credentials |
| C. Unseal | Curve25519 box_seal_open recovers plaintext `xmppPassword` (= LDAP `userPassword`) |
| D. XMPP auth | `mod_auth_ldap` bridges SASL-PLAIN to LDAP bind; dual-purpose userPassword validates |
| E. Messaging | Stanza routing across two authenticated sessions on the same XMPP server |

**Key invariants proven:**
- Same `userPassword` hash unlocks Authentik web login AND XMPP SASL-PLAIN bind (ARD-001 single-LDAP).
- Provisioning is read-only for UC services — backend never writes to ejabberd; ejabberd re-reads LDAP each bind.
- No user sync required between platform and UED — both look at the same LDAP simultaneously.

## Network paths

From the UED VM to the platform LDAP there are two equivalent routes:

| From inside VM | Target | Notes |
|---|---|---|
| `ldap://192.168.4.111:1390` | Host LAN IP | Playbook default. Works because dev-compose binds OpenLDAP to `0.0.0.0`. |
| `ldap://192.168.122.1:1390` | libvirt NAT gateway | Alternative; equally valid. Use when host LAN IP changes. |

Configure UED's LDAP client via the playbook:

```bash
# See playbooks/web-configure/azblink-server-ldap-client.yml
SERVER_URL="http://192.168.122.220:8082"   # UED admin panel
LDAP_HOST="192.168.4.111:1390"
LDAP_BASE_DN="dc=azblink,dc=com"
LDAP_BIND_DN="cn=admin,dc=azblink,dc=com"
```

## Creating a test user end-to-end

```bash
UC_TEST_USER=xmpptest01 UC_TEST_PASSWORD='UEDprobe!23' \
  ./tools/dev-seed-uc-user.py
```

Creates the user in Authentik + platform LDAP with UC objectClasses and profile services attached. The new user is immediately bindable via UED XMPP.

## Verifying XMPP auth

The server advertises `PLAIN` + `X-OAUTH2` SASL mechanisms and no STARTTLS in dev. slixmpp SASL-PLAIN probe:

```python
import asyncio, ssl, slixmpp

class Probe(slixmpp.ClientXMPP):
    def __init__(self, jid, pw):
        super().__init__(jid, pw)
        self.ok = asyncio.Event(); self.fail = asyncio.Event()
        self.add_event_handler("session_start", lambda _: self.ok.set())
        self.add_event_handler("failed_auth", lambda _: self.fail.set())
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        self["feature_mechanisms"].unencrypted_plain = True

async def run(jid, pw, host="192.168.122.220", port=5222, timeout=10):
    c = Probe(jid, pw); c.connect(host=host, port=port)
    deadline = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < deadline:
        if c.fail.is_set(): c.disconnect(); return "FAIL"
        if c.ok.is_set():   c.disconnect(); return "OK"
        await asyncio.sleep(0.1)
    c.disconnect(); return "TIMEOUT"

print(asyncio.run(run("alanl@private.z", "alanl123!")))
```

## Gotchas

- **slixmpp v1.12 API** — `connect(host=..., port=...)`; NOT a tuple, NOT `disable_starttls`/`use_ssl`. Must set `feature_mechanisms.unencrypted_plain = True` when server lacks STARTTLS.
- **`tests/test_xmpp_e2e.py` LDAP-provisioning block is stale for UED** — it assumes an LDAP server running *on* the XMPP VM. On PED80 UED, 389/636 are refused; UED has no LDAP of its own. The auth-only pattern in this doc is the applicable test.
- **`make vm-ip` changes across VM rebuilds.** Hardcoded `192.168.122.89` in `tests/test_xmpp_e2e.py` is stale; override via `EXTERNAL_LDAP_HOST`.
- **Port-forwarding is off by default.** Connecting to `192.168.4.111:5222` (host) fails unless `sudo make vm-port-forward` ran. Connect directly to `192.168.122.220:5222` from the libvirt-host.
- **UED admin-panel CAPTCHA is cosmetic** — `authimage` field is accepted empty (playbook notes).

## Validated scenarios (2026-04-15)

| Scenario | Result | Notes |
|---|---|---|
| SASL-PLAIN as existing user (alanl) | ✅ PASS | userPassword dual-purpose confirmed |
| Fresh provisioning + SASL-PLAIN (xmpptest01) | ✅ PASS | Platform API → LDAP → immediate XMPP bind |
| Bidirectional chat messaging | ✅ PASS | alanl ↔ xmpptest01, stanzas delivered |
| SASL X-OAUTH2 with Authentik access_token | ❌ FAIL | Server returns `<not-authorized/><text>Invalid token</text>` across 4 payload variants — UED's OAuth2 config does not trust our dev Authentik (JWKS / issuer / audience not wired). Mechanism is advertised but non-functional for tokens from this identity provider. |

**Key learning:** SASL-PLAIN (LDAP-bridged via `mod_auth_ldap`) is the functioning auth path today. X-OAUTH2 routes to `ejabberd_oauth`, which validates against ejabberd's **internal token store** by default — Authentik-issued JWTs are unknown to it and rejected with `Invalid token`.

**To enable X-OAUTH2 against external Authentik on ejabberd**, the typical paths are:
- Configure an OAuth2 introspection endpoint on Authentik and use ejabberd's external auth backend (`extauth_program` script that calls Authentik `/application/o/userinfo/` or token-introspection); OR
- Use ejabberd's `mod_http_api` + a custom OAuth backend module that accepts JWTs and validates against Authentik JWKS; OR
- Install a community OAuth2/OIDC bridge module (e.g. `mod_auth_jwt`-style) and configure it with our JWKS URL + audience `azblink-directory` + accepted issuers (`http://authentik-server:9000/application/o/azblink-directory/`, `https://authentik.keithmoc.dev/application/o/azblink-directory/`).

In all cases the change lives in `/etc/ejabberd/ejabberd.yml` on the VM, not on the platform side. Out of scope for this session.

## Untested paths

- **SIP digest auth** via `AstAuthPassword` against whatever SIP service PED80 exposes.

## More gotchas (surfaced 2026-04-15)

- **Seed script does NOT create the Authentik user** for a custom `UC_TEST_USER`. It creates the LDAP entry + UC attrs + profile services only. The Authentik user is "assumed seeded separately" per the script's own docstring — by default only `alanl` exists in Authentik (from `deploy/dev/authentik-seed`). For any username other than `alanl`, seed Authentik separately or SSO login will fail; SASL-PLAIN against LDAP still works regardless.
- **Seed script prints `hasXmpp/hasSip: False`** even when UC attrs are correctly written to LDAP (cosmetic false negative — issue #92).
- **`X-OAUTH2` advertised ≠ `X-OAUTH2` configured** on the UED side. Don't assume the advertisement means it works for our tokens.

## Related

- `playbooks/web-configure/azblink-server-ldap-client.yml` — configures the UED LDAP-client module.
- `docs/archive/plans/sessions/2026-04-13-xmpp-provision-e2e-verification-session.md` — live session record.
- `tools/dev-seed-uc-user.py` — one-shot user seed.
- `tests/test_xmpp_e2e.py` — has a useful `XMPPTestClient` slixmpp wrapper; provisioning path inapplicable to this UED variant.
- ARD-001 — single-LDAP decision (dual-purpose userPassword).
- `docs/knowledge/patterns/dual-auth-plane-sso-overlay.md` — prior pattern doc; its diagram predates single-LDAP (still shows "UED Sync" / "UED LDAP" which were removed 2026-03-02).
