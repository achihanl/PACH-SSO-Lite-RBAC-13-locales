---
title: SQLAlchemy Core JOIN for Template Resolution
description: Reference notes on using SQLAlchemy Core's select().join().where().mappings().first() for single-row template resolution
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: SQLAlchemy Core JOIN for Template Resolution
libraries: ["sqlalchemy"]
validated: 2026-02-24
source: context7:/sqlalchemy/sqlalchemy
---

## Summary
SQLAlchemy Core `select().join().where()` with `.mappings().first()` returns a dict-like RowMapping for single-row joins. The UNIQUE constraint on org_dn guarantees at most one result.

## API Reference
```python
stmt = (
    select(config_templates)
    .join(
        config_template_assignments,
        config_templates.c.id == config_template_assignments.c.template_id
    )
    .where(config_template_assignments.c.org_dn == org_dn)
)
with engine.connect() as conn:
    result = conn.execute(stmt).mappings().first()
    return dict(result) if result else None
```

## Gotchas
- Always use explicit ON clause (don't rely on FK inference)
- `.mappings()` is needed to get dict-like results; without it you get Row tuples
- `.first()` is preferred over `.fetchone()` (doesn't consume full result set)
- Always check for None before calling `dict(result)`
