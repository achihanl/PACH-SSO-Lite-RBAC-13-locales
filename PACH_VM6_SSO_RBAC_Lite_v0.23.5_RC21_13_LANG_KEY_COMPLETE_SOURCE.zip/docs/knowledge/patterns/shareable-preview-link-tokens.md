---
title: Shareable Preview Link Token Design
description: Design pattern for opaque, hashed, server-side-expiring shareable preview link tokens
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: Shareable Preview Link Token Design
libraries: ["secrets", "hashlib"]
validated: 2026-03-01
source: https://auth0.com/docs/secure/tokens/token-best-practices
supersedes: null
---

## Summary
Secure shareable links use opaque, URL-safe tokens with server-side expiry validation.
The token is never the same as the underlying credential — it's a separate, short-lived
reference that maps to the protected resource.

## API Reference
- `secrets.token_urlsafe(32)` — generates 43-char URL-safe token (256 bits of entropy)
- `hashlib.sha256(token.encode()).hexdigest()` — hash for DB lookup (never store raw token)

## Patterns
1. **Separate token:** Preview token != provision token. Different table, different TTL.
2. **Hash storage:** Store SHA-256 hash of preview token in DB. Look up by hash on access.
3. **Short TTL:** Preview link TTL should be shorter than the QR token TTL (e.g., 1h default, max 24h).
4. **No auth required:** Public endpoint validates preview token + expiry, returns read-only QR data.
5. **Audit trail:** Log preview link creation and access attempts.
6. **Rate limit:** Apply rate limiting to prevent enumeration attacks.

## Gotchas
- Never expose the provision token or its hash in the preview URL
- Preview token must be different from the provision token (defense in depth)
- Preview link expiry is independent of QR token expiry — the QR may still be valid after preview link expires
- HTTPS is mandatory for production (dev can use HTTP)
