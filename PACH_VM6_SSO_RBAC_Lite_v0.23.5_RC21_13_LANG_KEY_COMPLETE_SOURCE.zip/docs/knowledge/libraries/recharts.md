---
title: Recharts AreaChart
description: Reference notes on Recharts' AreaChart component, gradient fills, and React 19 support
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: Recharts AreaChart
libraries: ["recharts"]
validated: 2026-03-10
source: context7:/recharts/recharts
supersedes: null
---

## Summary
Recharts is a React charting library built on D3. The AreaChart component supports gradient fills via SVG `<defs>/<linearGradient>`, multiple Area series, custom dots, and tooltips. v3.8.0 is current and supports React 19.

## API Reference

```tsx
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer
} from 'recharts';
```

- `ResponsiveContainer` — wraps chart for fluid sizing (width="100%" height={N})
- `AreaChart` — container, takes `data` array and `margin` object
- `Area` — series, props: `type`, `dataKey`, `stroke`, `fill`, `fillOpacity`, `dot`, `activeDot`
- `defs > linearGradient` — define gradient fills inline in the `<AreaChart>`
- `Tooltip` — hover tooltip, `content` prop for custom renderer
- `XAxis/YAxis` — axes, `dataKey`, `tick`, `stroke`, `hide`
- `CartesianGrid` — grid lines, `strokeDasharray`

## Patterns

### Two-series AreaChart with gradient fills
```tsx
<ResponsiveContainer width="100%" height={240}>
  <AreaChart data={data}>
    <defs>
      <linearGradient id="gradGen" x1="0" y1="0" x2="0" y2="1">
        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
      </linearGradient>
    </defs>
    <XAxis dataKey="day" />
    <YAxis />
    <Tooltip />
    <Area type="monotone" dataKey="generated"
      stroke="#3b82f6" fill="url(#gradGen)" fillOpacity={1} />
  </AreaChart>
</ResponsiveContainer>
```

### Custom dots
- `dot` prop: `false` | `true` | `{ r: 4, fill: '#3b82f6', stroke: '#fff' }`
- `activeDot` prop: same shape, shown on hover

## Gotchas
- `ResponsiveContainer` needs a parent with explicit height (not flex-grow alone)
- Each `linearGradient` needs a unique `id` — if two charts share a page, IDs collide
- v3 removes internal state props — `activeIndex` prop removed
- `type="monotone"` gives smooth curves; `type="linear"` for straight lines
