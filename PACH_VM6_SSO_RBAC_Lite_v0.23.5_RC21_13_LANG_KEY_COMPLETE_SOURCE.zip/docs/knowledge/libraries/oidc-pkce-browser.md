---
title: OIDC PKCE Flow — Browser Implementation
description: Reference notes on implementing the OIDC PKCE code verifier and challenge flow in the browser via the Web Crypto API
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
---

# OIDC PKCE Flow — Browser Implementation

**Library:** Web Crypto API (native) + standard OIDC
**Last verified:** 2026-03-04

## Code Verifier & Challenge (RFC 7636)

```typescript
// Generate 32-byte random verifier → base64url (43+ chars)
const array = crypto.getRandomValues(new Uint8Array(32));
const verifier = btoa(String.fromCharCode(...array))
  .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

// S256 challenge
const encoder = new TextEncoder();
const digest = await crypto.subtle.digest('SHA-256', encoder.encode(verifier));
const challenge = btoa(String.fromCharCode(...new Uint8Array(digest)))
  .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
```

## Authorization Redirect

```
GET /application/o/authorize/
  ?client_id=azblink-directory
  &response_type=code
  &redirect_uri=http://localhost:8081/auth/callback
  &scope=openid profile email
  &code_challenge_method=S256
  &code_challenge={challenge}
  &state={random_state}
```

- Store `code_verifier` + `state` in `sessionStorage` before redirect
- PKCE provides CSRF protection; `state` is recommended but optional with PKCE

## Token Exchange (Callback)

```
POST /application/o/token/
Content-Type: application/x-www-form-urlencoded

grant_type=authorization_code
&client_id=azblink-directory
&code={authorization_code}
&redirect_uri=http://localhost:8081/auth/callback
&code_verifier={stored_verifier}
```

Response: `{ access_token, id_token, refresh_token, expires_in, token_type }`

## Gotchas

- `crypto.subtle` requires HTTPS (localhost is exempt)
- Public client: NO `client_secret` — PKCE replaces it
- `sessionStorage` is cleared on tab close — verifier lost if user opens callback in new tab
- Token exchange is a **browser-to-IdP** request (not via backend proxy for public clients)
