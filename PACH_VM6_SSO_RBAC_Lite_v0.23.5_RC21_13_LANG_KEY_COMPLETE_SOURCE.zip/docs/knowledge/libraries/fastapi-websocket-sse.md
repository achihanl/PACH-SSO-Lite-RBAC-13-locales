---
title: FastAPI WebSocket and SSE Patterns
description: Reference notes on FastAPI's native WebSocket support and server-sent events via StreamingResponse
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: FastAPI WebSocket and SSE Patterns
libraries: ["fastapi", "websockets", "sse-starlette"]
validated: 2026-03-10
source: context7:/tiangolo/fastapi + web research
supersedes: null
---

## Summary
FastAPI supports WebSocket natively (via Starlette) and SSE via StreamingResponse with `text/event-stream`. WebSocket auth requires manual token extraction (no Depends() in WS handshake). SSE is simpler for one-way server-to-client.

## API Reference

### WebSocket Endpoint
```python
from fastapi import WebSocket, WebSocketDisconnect, Query, status

@app.websocket("/ws")
async def ws_endpoint(websocket: WebSocket, token: str = Query(None)):
    if not token or not verify_token(token):
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({"echo": data})
    except WebSocketDisconnect:
        pass  # cleanup here
```

### SSE Endpoint (built-in StreamingResponse)
```python
from fastapi.responses import StreamingResponse

async def event_generator():
    while True:
        event = await queue.get()
        yield f"data: {json.dumps(event)}\n\n"

@app.get("/sse")
async def sse(request: Request):
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )
```

### SSE Message Format (W3C)
```
event: activity\n
id: 12345\n
data: {"type": "user-created", "text": "..."}\n
\n
```
- MUST end with `\n\n` (two newlines)
- `data:` is required, others optional
- Multi-line data: repeat `data:` prefix per line

## Patterns

### Connection Manager
```python
class ConnectionManager:
    def __init__(self):
        self.active: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        self.active.remove(ws)

    async def broadcast(self, message: str):
        for ws in list(self.active):  # copy to avoid mutation during iteration
            try:
                await ws.send_text(message)
            except Exception:
                self.disconnect(ws)
```

### asyncio Queue Event Bus
```python
class EventBus:
    def __init__(self):
        self._subscribers: list[asyncio.Queue] = []

    def subscribe(self, maxsize: int = 100) -> asyncio.Queue:
        q = asyncio.Queue(maxsize=maxsize)
        self._subscribers.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue):
        self._subscribers.remove(q)

    async def publish(self, event: dict):
        for q in list(self._subscribers):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                pass  # drop for slow consumers
```

## Gotchas
- **WebSocket auth:** `Depends()` DOES NOT work for WS handshake auth. Use `Query(None)` for token.
- **SSE format:** `data: json\n` alone is NOT enough — MUST end with `\n\n`
- **Stale connections:** Wrap `send()` in try-except during broadcast, remove failed connections
- **Memory leaks:** Always unsubscribe in `finally` block when WS/SSE disconnects
- **Queue broadcast:** Use `put_nowait()` not `put()` — `put()` can deadlock in broadcast loop
- **Iterate copy:** `for q in list(subscribers):` — don't mutate list while iterating
- **Heartbeat:** No built-in WS ping/pong in FastAPI — use `asyncio.wait_for(recv(), timeout=30)` + heartbeat
- **SSE disconnect:** Check `await request.is_disconnected()` periodically
- **Testing WS:** httpx does NOT support WebSocket — use `websockets` library or FastAPI TestClient
- **Testing SSE:** Use `httpx` streaming with `response.aiter_lines()` or `httpx-sse` library
