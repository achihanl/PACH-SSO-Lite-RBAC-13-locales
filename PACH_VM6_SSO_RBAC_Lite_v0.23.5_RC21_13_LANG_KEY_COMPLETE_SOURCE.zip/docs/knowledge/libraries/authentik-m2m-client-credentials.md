---
title: Authentik M2M client_credentials Grant
description: Reference notes on Authentik's OAuth2 client_credentials grant for machine-to-machine authentication
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: Authentik M2M client_credentials Grant
libraries: ["authentik"]
validated: 2026-03-12
source: https://docs.goauthentik.io/add-secure-apps/providers/oauth2/client_credentials/
supersedes: null
---

## Summary
Authentik supports `grant_type=client_credentials` with user context via `username` + app password token key.
Works on both public and confidential providers. Token endpoint is global (`/application/o/token/`).

## API Reference

### Token Acquisition
```
POST /application/o/token/
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials
client_id=<provider-client-id>
username=<authentik-username>
password=<app-password-token-key>
scope=openid profile email
```

### App Password Creation (Admin API)
```
POST /api/v3/core/tokens/
{
  "identifier": "unique-id",
  "intent": "app_password",
  "user": <user_pk>
}
```
Response includes `key` field — use this as `password` in token request.

### View Token Key
```
GET /api/v3/core/tokens/<identifier>/view_key/
```

## Patterns

### Claims in Access Token
- `sub`: hashed user ID (when `sub_mode=hashed_user_id`)
- `preferred_username`: Authentik username (requires `scope-profile` mapping + `scope=profile`)
- `aud`: the `client_id` of the provider
- `iss`: the OIDC issuer URL (depends on which URL the token endpoint was hit from)

### Public vs Confidential
- Public providers: `client_id` + `username` + `password` (no client_secret needed)
- Confidential providers: additionally support `client_secret`-only flow (auto-service-account)

## Gotchas
- Token endpoint is **global** `/application/o/token/` — NOT slug-scoped
- `aud` claim = `client_id` of the provider used — if you create a separate test provider with a different client_id, aud will differ
- `grant_type=password` treated identically to `client_credentials` but historically buggy (issue #6139) — use `client_credentials`
- App password `key` is the password, NOT the user's login password
- Without `scope-profile` mapping on provider, `preferred_username` won't appear in JWT
- Authentik 2025.8 bug: multiple app passwords with identical keys can collide — use unique keys
