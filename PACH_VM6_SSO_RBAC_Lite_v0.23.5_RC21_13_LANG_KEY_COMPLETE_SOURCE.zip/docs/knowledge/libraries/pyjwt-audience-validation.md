---
title: PyJWT Audience Validation (list support)
description: Reference notes on PyJWT's any-match audience validation when a list is passed to jwt.decode
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: PyJWT Audience Validation (list support)
libraries: ["PyJWT"]
validated: 2026-03-12
source: context7:/jpadilla/pyjwt
supersedes: null
---

## Summary
PyJWT's `jwt.decode(audience=...)` accepts a list. When a list is passed, validation uses
"any match" semantics: the token's `aud` claim must contain at least one value from the list.

## API Reference

```python
# Single audience (string)
jwt.decode(token, key, algorithms=["RS256"], audience="my-app")

# Multiple audiences (list) — passes if token aud contains ANY of them
jwt.decode(token, key, algorithms=["RS256"], audience=["app1", "app2"])
```

## Patterns

### Validation Logic
1. Both `audience` param and token `aud` are normalized to lists
2. Check: if ANY value from `audience` param exists in token's `aud` list → pass
3. If NONE match → raise `InvalidAudienceError`

### Examples
- `audience=["aud1", "aud2"]` + token `aud="aud2"` → PASSES
- `audience=["aud1", "aud2"]` + token `aud=["aud2", "aud3"]` → PASSES
- `audience=["aud1"]` + token `aud="aud2"` → FAILS

## Gotchas
- `strict_aud` option (PyJWT 2.8.0+): when `options={"strict_aud": True}`, both sides must be single strings with exact match
- List audience support has been available since PyJWT 1.5.0 (2017)
- Project uses PyJWT 2.10.1 — all features available
