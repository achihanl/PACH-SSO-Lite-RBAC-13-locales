---
title: Authentik OIDC Provider — Integration Reference
description: Reference notes on configuring an Authentik OIDC provider for the admin UI SPA and the authorization-code-plus-PKCE flow
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
---

# Authentik OIDC Provider — Integration Reference

**Source:** Authentik docs 2024.12+, verified via web research 2026-03-01

## OIDC Provider Setup for SPA (Admin UI)

- **Provider type:** OAuth2/OpenID Connect Provider
- **Client type:** Public (no client_secret — frontend SPA)
- **Client ID:** `azblink-directory` (matches `OIDC_AUDIENCE` in config.py)
- **Redirect URIs:** `http://localhost:8081/auth/callback` (dev), plus production domain
- **Signing key:** RS256 (Authentik auto-generates, rotate via Admin UI)
- **Scopes required:** `openid`, `profile`, `email`, `entitlements` (for groups)
- **Subject mode:** Based on User's username (maps to LDAP uid)
- **Access token type:** JWT (not opaque) — allows backend to verify via JWKS without Authentik roundtrip

## Authorization Code + PKCE Flow (SPA)

1. Frontend generates `code_verifier` (43-128 chars, unreserved chars)
2. Frontend computes `code_challenge = BASE64URL(SHA256(code_verifier))`
3. Redirect to: `{OIDC_ISSUER}/application/o/authorize/?response_type=code&client_id=azblink-directory&redirect_uri={CALLBACK}&scope=openid+profile+email+offline_access&code_challenge={CHALLENGE}&code_challenge_method=S256&state={STATE}`
4. User authenticates at Authentik login
5. Authentik redirects to callback with `?code=...&state=...`
6. Frontend exchanges code at token endpoint: `POST {OIDC_ISSUER}/application/o/token/`
   - Body: `grant_type=authorization_code&code={CODE}&redirect_uri={CALLBACK}&client_id=azblink-directory&code_verifier={VERIFIER}`
7. Response: `{ access_token, id_token, refresh_token, expires_in, token_type }`

## Discovery Endpoint

`GET {OIDC_ISSUER}/.well-known/openid-configuration`

Returns: `authorization_endpoint`, `token_endpoint`, `userinfo_endpoint`, `jwks_uri`, `end_session_endpoint`

## Authentik Admin API v3 (Session/Token Management)

- **Base URL:** `https://{AUTHENTIK_HOST}/api/v3/`
- **Auth:** Bearer token (API token created in Authentik Admin > Tokens)
- **User lookup:** `GET /api/v3/core/users/?search={username}`
- **Access tokens:** `GET /api/v3/oauth2/access_tokens/?user__username={username}`
- **Refresh tokens:** `GET /api/v3/oauth2/refresh_tokens/?user__username={username}`
- **Delete token:** `DELETE /api/v3/oauth2/access_tokens/{id}/` or `.../refresh_tokens/{id}/`
- **User deactivate:** `PATCH /api/v3/core/users/{id}/` with `{"is_active": false}`

## Gotchas

- **PKCE enforcement:** Pre-2023.10.4 had a bug where PKCE wasn't enforced even when configured. Ensure Authentik >= 2024.x.
- **`openid` scope:** Since 2024.2.2, `openid` scope must be explicitly selected in Provider settings (not auto-included).
- **End-session endpoint:** Logs out of Authentik SSO session but does NOT revoke access/refresh tokens. Must revoke via Admin API separately.
- **Groups claim:** Carried by the built-in **`profile`** scope mapping, which returns `groups` (array of group names) alongside `name`/`preferred_username`/`nickname`. Configure `OIDC_GROUPS_CLAIM=groups` in backend. Do NOT add a custom `groups` scope mapping on top of it — see below.
- **Scope mappings MERGE by appending, not overwriting.** Authentik folds each granted mapping's output into the claim set with deepmerge's `always_merger`, whose list strategy is `append`. Two mappings both emitting `groups` therefore yield every group name twice, not once (#279). Verify with `POST /api/v3/propertymappings/all/{pk}/test/ {"user": <pk>}`, which returns a single mapping's output in isolation.
- **Token lifetime:** Configure in Provider settings. Recommend: access_token=5min, refresh_token=8h (matches JWT_EXPIRY_HOURS).
