---
title: Pydantic BaseSettings Optional Fields
description: Reference notes on handling optional fields and empty-string env vars in pydantic-settings v2
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: Pydantic BaseSettings Optional Fields
libraries: ["pydantic-settings"]
validated: 2026-02-24
source: context7:/pydantic/pydantic
---

## Summary
In pydantic-settings v2, optional fields use `str | None = Field(default=None)`. When env var is unset, the field defaults to None. Use `env_ignore_empty=True` in SettingsConfigDict to treat empty strings as "not set".

## API Reference
```python
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_ignore_empty=True)
    xmpp_domain: str | None = Field(default=None, description="XMPP domain")
```

## Gotchas
- `default=None` is REQUIRED — without it, field is treated as required
- Empty string "" is NOT None by default — use `env_ignore_empty=True`
- Put non-None type first in union: `str | None` not `None | str`
