---
title: Authentik LDAP & SCIM Sync Capabilities — Research Findings
description: What Authentik's LDAP source, LDAP provider, and SCIM sync each actually do, including the missing outbound LDAP sync capability
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
---

# Authentik LDAP & SCIM Sync Capabilities — Research Findings

**Source:** Authentik docs + GitHub issues, verified 2026-03-01

## Key Finding: Authentik Cannot Push Users TO External LDAP

Authentik has **no outbound LDAP sync** capability. This is a confirmed missing feature (GitHub Issue #3896, open since 2022).

## What Each Feature Actually Does

### LDAP Source (Inbound LDAP Import)
- **Direction:** External LDAP → Authentik (one-way inbound)
- **Purpose:** Import users/groups from an existing LDAP directory into Authentik
- **Sync frequency:** Configurable, default ~5 minutes
- **Password writeback:** The SOLE exception to "inbound only" — when users change passwords in Authentik, it can write back to the source LDAP
- **Property mappings:** Control which LDAP attributes map to Authentik user fields
- **Use case for AZBlink:** Import AD Directory's LDAP users into Authentik so they can SSO into the admin UI

### LDAP Provider + Outpost (Virtual LDAP Server)
- **Direction:** Authentik → Virtual LDAP (read-only exposure)
- **Purpose:** Present Authentik users AS an LDAP directory for legacy apps
- **NOT a sync tool** — it's a protocol translator
- **ObjectClass limitations:** Exposes users as `inetOrgPerson`, `organizationalPerson`, `goauthentik.io/ldap/user` — does NOT include `posixAccount`, custom SIP/XMPP objectClasses
- **Search base:** Only `ou=users,dc=ldap,dc=goauthentik,dc=io` (Authentik's virtual tree)
- **Use case for AZBlink:** NOT suitable — ejabberd/Asterisk need `posixAccount` + custom schemas in their own LDAP servers

### SCIM Provider (Outbound User Push)
- **Direction:** Authentik → SCIM 2.0 endpoint
- **Purpose:** Push user/group changes to SCIM-compatible apps (e.g., Slack, Azure AD, Google Workspace)
- **NOT for LDAP** — OpenLDAP has no native SCIM API
- **A SCIM-to-LDAP bridge exists** (e.g., `scim2-ldap-bridge`) but is fragile, unmaintained, and adds operational complexity
- **Use case for AZBlink:** NOT suitable without a bridge layer

## Viable Architecture for AZBlink

### Architecture A: LDAP-Authoritative + Authentik Import (RECOMMENDED)

```
AZBlink Directory ──owns──► AD LDAP (identity store, authoritative)
       │                        │
       │ sync events            │ LDAP Source (inbound import)
       ▼                        ▼
   UED Sync ──► UED LDAP    Authentik (SSO layer)
   (XMPP/SIP)                  │
                                │ OIDC tokens
                                ▼
                           Admin UI (SPA)
```

- **AD LDAP stays authoritative** for all user identity
- Authentik imports users via **LDAP Source** (periodic sync)
- Authentik provides **OIDC** for admin UI SSO
- UED LDAP (XMPP/SIP) is provisioned by UED Sync — **completely independent of Authentik**
- **Password flow:** User passwords set in AD LDAP (SSHA hash). Authentik LDAP Source can sync these. Authentik password writeback can optionally update AD LDAP when users change passwords via Authentik.

### Why NOT Architecture B (Authentik-Authoritative)

- Would require replacing AD LDAP with Authentik as identity store
- LDAP Provider outpost can't produce `posixAccount` + SIP/XMPP objectClasses
- Would break the "UC works without Authentik" design invariant
- Major refactor with high risk

## Implications for "Option 3"

The user's original Option 3 ("Authentik as identity provider, SCIM sync to LDAP") needs revision:
- Authentik **cannot** SCIM-sync to OpenLDAP natively
- The correct architecture is the **reverse**: LDAP is authoritative, Authentik consumes it
- The SSO value proposition is preserved: admin UI gets OIDC, XMPP/SIP keep LDAP bind
- Net result is the same from a user perspective — just the data flow direction is different
