---
title: Authentik Brand API v3
description: Reference notes on the Authentik Brand API for CRUD of brand and theming configuration
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
topic: Authentik Brand API v3
libraries: ["authentik"]
validated: 2026-03-11
source: https://docs.goauthentik.io/brands/
supersedes: null
---

## Summary
Authentik Brand API (`/api/v3/core/brands/`) provides CRUD for brand/theming configuration. Brands replaced "tenants" in 2024.2. A default brand (`domain=authentik-default`, `default=true`) is auto-created on first boot. Custom CSS support added in 2025.4.

## API Reference
- `GET /api/v3/core/brands/?default=true` — find default brand
- `PATCH /api/v3/core/brands/{brand_uuid}/` — partial update
- Key fields: `branding_title` (string), `branding_logo` (file path or URL), `branding_favicon` (file path or URL), `branding_custom_css` (inline CSS text), `branding_default_flow_background` (file path or URL)
- `attributes` field: JSON object for theme/locale (`{"settings": {"theme": {"base": "dark"}}}`)
- `brand_uuid` is random UUID4 — always look up, never hardcode
- FileFields accept string paths in JSON PATCH (no multipart needed)

## Patterns
- Find-and-patch: GET `?default=true` → extract `brand_uuid` → PATCH
- Idempotent check: compare `branding_title` before patching
- Logo via volume mount: mount SVG to `/web/dist/assets/icons/` in server container
- Logo path reference: `/static/dist/assets/icons/your-logo.svg`
- `%(theme)s` placeholder in logo path for dark/light switching

## Gotchas
- Only one default brand allowed — ValidationError if two `default=true`
- `branding_custom_css` is inline CSS text, NOT a URL
- Blueprint `state: created` means seed PATCH persists across restarts
- CSS changes require page reload (no live push)
- Flow FK fields expect UUID pks, not slugs
- 2025.12 changed file storage from `/media` to `/files` — we use 2025.8, so `/static/dist/assets/` is correct
