---
title: Authentik Admin API v3 — Session & Token Revocation
description: Reference notes on authenticating to and revoking sessions via the Authentik v3 admin API
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
---

# Authentik Admin API v3 — Session & Token Revocation

**Last verified:** 2026-03-04

## Authentication

```
Authorization: Bearer <api-token>
```

API token created in Authentik Admin → Directory → Tokens & App Passwords.

## User Lookup

```
GET /api/v3/core/users/?username={username}
→ { results: [{ pk, username, name, email, is_active, ... }] }
```

## Session Revocation

```
# List sessions (Django double-underscore filter)
GET /api/v3/core/authenticated_sessions/?user__username={username}
→ { results: [{ uuid, user, last_ip, last_user_agent, ... }] }

# Delete single session
DELETE /api/v3/core/authenticated_sessions/{uuid}/
→ 204 No Content
```

## Token Revocation

```
# List OAuth2 access tokens
GET /api/v3/oauth2/access_tokens/
→ { results: [{ id, provider, user, ... }] }

# Delete access token
DELETE /api/v3/oauth2/access_tokens/{id}/
→ 204 No Content

# Delete refresh token
DELETE /api/v3/oauth2/refresh_tokens/{id}/
→ 204 No Content
```

## Critical Gotcha

- **`end_session` does NOT revoke tokens** — it only clears the browser session cookie
- Must explicitly DELETE access_tokens and refresh_tokens for full revocation
- Deactivating a user (`PATCH /api/v3/core/users/{pk}/ {is_active: false}`) triggers back-channel logout to all providers

## Termination Strategy

For user termination in AZBlink:
1. Delete all authenticated sessions by username
2. Delete all OAuth2 access tokens for the user
3. Delete all OAuth2 refresh tokens for the user
4. (LDAP deletion handles Plane A / UC auth separately)
