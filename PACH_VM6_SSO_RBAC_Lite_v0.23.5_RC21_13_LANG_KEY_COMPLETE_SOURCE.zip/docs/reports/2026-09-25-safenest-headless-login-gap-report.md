---
title: Headless first-party login (B1) — azb-AD gap report and plan
description: What azb-AD must ship so any registered first-party app (SafeNest first) can relay its own login form to Authentik, and the decisions it needs
type: reference
product: azblink-directory
status: draft
updated: 2026-10-07
---

# Headless first-party login (B1) — azb-AD gap report and plan

- Date: 2026-09-25 UTC. Repo: azb-AD `main` at `2f16829`. Dev stack: Authentik `2026.5` (`deploy/dev/docker-compose.yml:389,429`).
- Scope: option **B1**. A client app's **own backend** relays its password form to the Authentik flow executor and gets real Authentik tokens. azb-AD adds **no** login endpoint. azb-AD's part is one ARD, plus seed and config.
- **Generic by design.** SafeNest is the first client. Each later client is onboarded by adding config, not by writing code. The pattern copies the one already used for machine clients (`AUTHENTIK_SERVICE_CLIENTS` → `ensure_service_client`, `seed_authentik.py:97,562`; spec `08-integration-points.md:170-183`).
- Evidence: `tools/safenest-headless-probe/`, deleted by E4 once `tests/test_headless_first_party_login.py` covered it (read it with `git log -- tools/safenest-headless-probe`): (`headless_probe.py`, `revoke_probe.py`; outputs `run1.txt` happy path, `run2.txt` bad password, `run3.txt` revocation). `ldap_probe.py` (2026-10-01): LDAP-sourced user and the ppolicy lockout (G1, G4, G11). `group_sync_probe.py` (2026-10-02): scoped LDAP group sync (G14; `run4.txt` plain `groupOfNames`, `run5.txt` with `--uid-aux`). `role_sync_probe.py` (2026-10-02): E2b role grant and removal through `/api/groups` (`run6.txt`).
- Aligned with the combined review brief (claude.ai artifact `Pkn7XYSwAeB2g3hC4Kzax5`). See the section "Alignment with the review brief".
- Legend: **[T]** tested live · **[R]** read in repo · **[N]** not checked.

> [!IMPORTANT]
> Correction to the first findings: `http://safenest.local:8081/auth/callback` is azb-AD's own admin-UI callback. `safenest` is the remote dev host that runs azb-AD (`Justfile:570-572`). Leave it on the `azblink-directory` provider.

## The pattern

A **first-party headless client** is an app that:

- keeps its own login form, and
- has a backend relay that runs the Authentik flow executor, then authorize (PKCE), then token.

What azb-AD provides, once, for every such client:

```mermaid
flowchart LR
  subgraph Client["Client app (e.g. SafeNest)"]
    F[Own login form] --> R[Backend relay]
  end
  subgraph AK["Authentik (azb-AD)"]
    HF["Shared flow: headless-first-party-auth (E3)"]
    P["Per-client provider: aud = client_id (E2)"]
    POL["Username reputation policy (E5)"]
    AP["Per-client access policy: allowed groups (E2)"]
  end
  R -- "flow executor + XFF" --> HF
  HF --- POL
  R -- "authorize (PKCE) + token" --> P
  P --- AP
  HF -- "LDAPBackend bind" --> L[(OpenLDAP)]
```

Onboarding one client means changes in exactly these places:

| Step | Where | Value |
|---|---|---|
| Register + redirect URIs | `AUTHENTIK_FIRST_PARTY_CLIENTS` (seed env, one JSON value, e.g. `{"safenest-a1":["http://…/auth/callback"]}`) | `client_id` → redirect URI list. URIs are validated by `/authorize` even though the relay never follows the redirect [T]. One variable because a per-client `AUTHENTIK_CLIENT_<ID>_*` name breaks on the hyphen in `safenest-a1` (G13) |
| Allowed groups | Derived: `<client_id>-*` | The access binding and the E2b sync filter both come from the client_id, so there is no per-client groups variable |
| Relay source | `AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS` (Authentik env) | Add the client relay's egress CIDR |
| Credential | Authentik Admin API, read once → client's vault | Provider `client_secret` (the seed never rotates it) |
| Contract | spec 08 | Client row added to the first-party client table |

Rules every client must meet. The ARD sets these; they are not negotiated per client:

1. Confidential client. Grants `authorization_code` + `refresh_token` only. PKCE S256.
2. Uses the shared headless flow only, never the brand default flow.
3. Access-token TTL 15 min (same as service clients, `seed_authentik.py:588`). Refresh 7 d.
4. The relay never logs a password or a raw flow response. It forwards `X-Forwarded-For`.
5. **MFA fails closed.** If the flow returns `ak-stage-authenticator-validate` and the client has not built the second step, the relay refuses the login and points the user to web sign-in. It never skips the stage.
6. Logout = `POST /application/o/revoke/` on the refresh token [T], then the client drops its own session and the relay discards its flow-executor cookies. No Authentik session delete: that needs an admin-API token the relay must not hold (decision 20).
7. Tokens are accepted only with `aud=<client_id>`, from the issuer allow-list, with `exp` present.

## 1. PRs

Phase labels refer to SafeNest's plan, the first client. For later clients, phases 1–2 shrink to the "Onboarding one client" config table above.

| # | PR title | Scope | Files touched | Acceptance check | Blocks |
|---|---|---|---|---|---|
| D0 | `docs(deploy): drop deleted POST /api/auth/login examples` | Remove the curl login examples. Point readers to the OIDC flow / `DEV_AUTH_TOKEN` instead | `deploy/dev/README.md:164-168`, `deploy/dev/DEPLOYMENT_SPEC.md:342-345` | `rg "api/auth/login" deploy/` returns nothing. Docs linter passes | Nothing (hygiene) |
| E1 | `docs(architecture): ARD-0NN headless first-party client login` | New ARD **amending** ARD-002 Plane B. Today `ARD-002:29` names SafeNest behind Authentik OIDC with no fallback. The amendment adds a **class** exception, "registered first-party headless clients", with the 7 rules above as admission criteria. Spec 04: headless sequence next to PKCE (`04:12`). Spec 08: new "First-party headless login" subsection with the onboarding table and a client registry (SafeNest as row 1), placed next to "API-to-API Integration". Bump `spec-meta.version`. Add an Amendments link on ARD-002 | `docs/architecture/decisions/ARD-0NN-*.md`, `ARD-002-*.md` (Amendments only), `spec/04-*.md`, `spec/08-integration-points.md`, `docs/architecture/README.md`, `CHANGELOG` | `just arch-guard` passes with `ARD: ARD-0NN`. ARD `accepted` | **Phase 1** |
| E2 | `feat(seed): env-registered first-party headless clients` | (a) Pull provider create/patch into one helper that `ensure_oauth2_provider` (`:491`), `ensure_service_client` (`:562`) and the new client type all call. Two copies exist today; a third must not be added. (b) `ensure_first_party_client(client_id)`: confidential, grants per rule 1, 15 min / 7 d, standard scope mappings, **no custom groups mapping** (#279), clients and redirect URIs from `AUTHENTIK_FIRST_PARTY_CLIENTS` (G13). (c) Application plus a group policy binding per client, to the `<client_id>-*` groups. (d) Register the dev building client `safenest-dev` with redirect URIs `["http://localhost:5173/auth/callback"]` (SafeNest, 2026-10-02; remote dev and prod come later), in dev `.env.example` and in the seed container's `environment:` list. (e) Unlike `ensure_service_client`, do **not** add the client_id to azb-AD's `OIDC_ACCEPTED_AUDIENCES`: azb-AD's API must keep rejecting `aud=safenest-*` tokens (`src/backend/config.py:79-81`, G19) | `deploy/dev/authentik-seed/seed_authentik.py`, `tests/unit/test_authentik_seed_*.py`, `deploy/dev/.env.example`, `deploy/dev/docker-compose.yml` (seed `environment:`, `:467-485`), `deploy/ansible/roles/azblink_app/templates/env.j2` | Unit test: two registered clients each get their own provider, correct grants and URIs. Probe with `CLIENT=safenest-dev`: `aud=safenest-dev`, no duplicate `groups`. A user outside the allowed groups is refused at `/authorize` | **Phase 1** |
| E2b | `feat(seed): sync LDAP group membership into Authentik` | SafeNest owner (2026-10-01): role membership lives in LDAP. Turn on `sync_groups` for `azblink-ldap`, **scoped to app role groups only** (owner decision 2026-10-01, option A): `group_object_filter` built from the registered clients, e.g. `(&(objectClass=groupOfNames)(\|(cn=safenest-a1-*)(cn=safenest-b2-*)))`, one term per registered building client (decisions 12–13), `group_membership_field: member`, a group name mapping (`openldap-cn`), and a sync schedule. **G14 [T] 2026-10-02:** a plain `groupOfNames` imports nothing under the shared `object_uniqueness_field: uid`. So `create_group` adds the `uidObject` aux class with `uid=<cn>` to every group under a registered client prefix; users are not re-keyed. Also covers stale roles after a membership change (G15) and deleted groups (G16). `IT-Admins` and every other group stay unsynced, so admin access is unchanged (G12). E1's ARD amends ARD-007's "no group sync" non-goal: app role groups sync, admin access does not | `seed_authentik.py`, `src/backend/ldap_client.py` (G14), `src/backend/routers/groups.py` (G15, G17), E4 extended | An LDAP user in `cn=safenest-a1-resident,ou=groups` gets `groups: ["safenest-a1-resident"]` in the token. A group `safenest-a1x-resident` is not matched by the `safenest-a1-*` term. Removing the user from the group drops the role by the next refresh, within the decided latency (decision 16). Azb-AD admin access is unchanged for every existing user | **Phase 1** (SafeNest roles) |
| E4 | `test(e2e): headless first-party login contract` | Port the four probes into `tests/`, **parametrized over registered first-party clients**. Real stack, throwaway user, fixture cleanup. Delete `tools/safenest-headless-probe/` | `tests/test_headless_first_party_login.py` (new), `tools/safenest-headless-probe/` (deleted) | Green in `just test-quick`, for each client: claims and `aud`, bad password → `invalid`, refresh keeps groups, revoke → `invalid_grant`, disallowed group refused | **Phase 1** |
| E3 | `feat(seed): shared headless-first-party-auth flow` | **One** flow for all headless clients: identification (no captcha) → password (LDAPBackend + Inbuilt) → authenticator-validate (kept; rule 5) → user-login. Isolated from brand-flow edits. Each client's provider points its authentication flow at it | `seed_authentik.py` (`ensure_headless_flow()`), E4 extended | E4 runs against this flow. A TOTP-enrolled user gets `ak-stage-authenticator-validate` and the relay contract fails closed | Phase 2. Dev can use `default-authentication-flow` until then [T] |
| E5 | `feat(authentik): lockout and throttling for headless clients` | (a) Username-keyed reputation policy bound to the **shared** flow, set to trip **below** ppolicy's 5 (for example at 3) so the LDAP account is never locked (G1). (b) `AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS` = union of registered relay CIDRs (G2) | `seed_authentik.py`, `deploy/dev/docker-compose.yml`, E4 extended | 3 bad attempts via a relay block that username in Authentik only. The LDAP account is not locked (XMPP still works). Other users are unaffected. XFF from a non-trusted source is ignored | **Before any real users** (pilot or production) |

E6 (an azb-AD password-login endpoint) is **not needed** under B1.

## 2. Effort and approvals

"Reviewer" means the repo owner plus the automated gates: CodeRabbit, CI, `arch-guard`, and the docs linter.

| # | Estimate | Approval |
|---|---|---|
| D0 | 0.5 h | Owner review |
| E1 | 4–6 h (class rules and registry add about 1 h over a SafeNest-only ARD) | **Owner accepts the ARD**. `arch-guard` green |
| E2 | 5–7 h (the provider-helper consolidation adds about 2 h) | Owner review. Seed is not in `surfaces.yaml` [R], so no enforced trailer. Cite `ARD: ARD-0NN` anyway |
| E2b | 4–7 h (G14 probed [T] 2026-10-02, fix is one aux class; G15–G17 add about 2 h) | Owner review **plus `/security-review`** (G12 trust assumption) |
| E4 | 3–4 h | Owner review. CI `backend-tests` green |
| E3 | 4–6 h. TOTP second-step test deferred with the SafeNest decision | Owner review |
| E5 | 6–10 h | Owner review **plus `/security-review`** |

- Total: about **27–41 h**, i.e. 3.5–5 working days.
- Phase 1 (D0, E1, E2, E2b, E4): about 17–25 h.
- Each later client: about **1–2 h** (config, a spec 08 row, the E4 parametrization picks it up), once the client provides its onboarding inputs.

## 3. Needed from each client (SafeNest first)

| Item | Why | For |
|---|---|---|
| Callback URL per environment (dev, remote dev, prod) | `/authorize` validates `redirect_uri` strictly [T] | E2 |
| Confirmation it can hold a client secret, and where | Rule 1 requires a confidential client | E2 |
| Role groups and who creates them | azb-AD has only `IT-Admins` (`seed_authentik.py:88`). See decision 7 | E1, E2 |
| Relay egress IP/CIDR per environment; relay sends `X-Forwarded-For` | Otherwise reputation keys on the relay IP [T] and every user is hit | E5 |
| Which Authentik host the relay calls (internal or tunnel) | `iss` follows the host [T] | E1 |
| User mix (LDAP-sourced vs Authentik-local; any MFA users) | Decides whether G3/G4 must be tested before phase 1 ends | E3, E4 |
| Logout implementation (rule 6) | Written into the spec 08 contract | E1 |

Access TTL is no longer a per-client input: rule 3 fixes it at 15 min.

SafeNest answers (2026-10-01):

- Dev callback: `http://localhost:5173/auth/callback`. Remote dev and prod are open.
- Secret: account-service env `AUTHENTIK_CLIENT_SECRET`.
- Relay hosts: azb-AD owner (2026-10-01) decided the **docker network is the default**: `http://authentik-server:9000`. The tunnel `https://authentik.keithmoc.dev` is not a supported relay path until E5 tests XFF through it (G2).
- Roles `admin|staff|resident|visitor`, as per-building groups `safenest-<building>-<role>` (decision 13). Membership lives in LDAP, which adds E2b.
- Logout per rule 6.
- Topology (2026-10-02): one shared azb-AD, one client per building. See decisions 8, 12–14.
- Open: production relay path and CIDR per box (decision 14), user mix. SafeNest phase 1 waits for D0/E1/E2/E2b/E4 and is not scheduled.

## 4. Gaps not in the first findings

| # | Gap | Status |
|---|---|---|
| G1 | **ppolicy lockout as a DoS path.** `pwdMaxFailure: 5`, `pwdLockoutDuration: 300` (`deploy/dev/ldap/bootstrap.ldif:60-62`). LDAPBackend binds as the user (spec 04:22-23), so 5 bad relay attempts lock the LDAP account, and with it XMPP (a `userPassword` bind). SIP is unaffected. E5(a) addresses it | **[T] 2026-10-01**: each bad password via the flow executor adds one `pwdFailureTime`; the 5th sets `pwdAccountLockedTime`. A direct bind with the correct password then returns 49, and the correct password via Authentik returns the same `Invalid password` as a wrong one. Fresh flow per attempt, so the password stage's `failed_attempts_before_cancel: 5` never trips. **Resolved for sequential relay traffic by E5 (2026-10-02)**: 3 failures refuse the username in Authentik, LDAP keeps 3 stored failures and still binds (E4 test). Limits: G22–G24 |
| G2 | Authentik trusted-proxy CIDRs unset in `deploy/dev/docker-compose.yml`. If the default trusts private ranges, any internal client can spoof XFF | Unset [R]. Default [N]. A relay calling through the tunnel reaches Authentik via Cloudflare and `cloudflared`, which rewrite or append XFF. Which IP the reputation policy keys on there is [N]. **[T] 2026-10-02 (E5)**: the 2026.5 default trusts all private ranges, and a spoofed XFF from the host was recorded. Now loopback only plus registered relay /32s; the same spoof is ignored, loopback XFF is honoured. The lockout keys on the username only (`check_ip` off), so the relay IP no longer matters for it |
| G3 | MFA through the executor (TOTP challenge/response) | **[T] 2026-10-02** (E3): on `headless-first-party-auth`, a TOTP-enrolled user gets `ak-stage-authenticator-validate` with `device_challenges: [totp]` after the password stage; POSTing `{"component": "ak-stage-authenticator-validate", "code": …}` to the same executor finishes the flow (no CSRF header needed before login). A code already used is refused, so a test needs the next 30 s step. E4 asserts the challenge and that the half-done session gets no code |
| G4 | Headless run with an LDAP-sourced user | **[T] 2026-10-01**: works (synced via `azblink-ldap`, no internal password, so LDAPBackend binds). `preferred_username` = LDAP `uid` (`openldap-uid` mapping). Differences from an Authentik-local user: `amr` is absent (local: `["pwd"]`), and `groups` is `[]` because LDAP group membership is not synced into Authentik groups |
| G5 | Authentik 2026.8 upgrade: challenge names and grant behaviour must be re-verified. Land E4 first | [N] |
| G6 | Duplicate `groups` claim if a custom groups mapping is added (#279) | [R]. In E2 scope |
| G7 | Production (tunnel) issuer for new providers | [N] |
| G8 | `ARD-016` has no file in `docs/architecture/decisions/`. Confirm the next free number before E1 | [R]. **Resolved 2026-10-02:** ARD-016 is reserved by the VM6⇄VM7 plan (`docs/superpowers/plans/2026-08-19-vm6-vm7-integration.md`), so E1 is **ARD-018** |
| G9 | ARD-017 (RBAC containment, service principals) may constrain how client roles map to azb-AD groups | [N] |
| G10 | **DRY:** provider create/patch logic is duplicated in `ensure_oauth2_provider` and `ensure_service_client`. Folded into E2(a) | [R] |
| G12 | **LDAP group sync is off, and turning it on changes azb-AD admin access.** `azblink-ldap` has `sync_groups: false` and the AD filter `(objectClass=group)`. LDAP has its own `cn=IT-Admins,ou=groups` (`alex`, `robert`), separate from the seed's Authentik `IT-Admins`, which grants azb-AD admin. Syncing would merge or clash with it | [T] 2026-10-01 (API + LDAP read). **Resolved by option A**: sync only `<client>-*` groups. Name-collision behaviour stays [N] but out of scope. Residual risk: anyone who can create an LDAP group named `safenest-*` grants a SafeNest role, so E2b still needs a `/security-review` |
| G11 | **Per-client authorization:** without an application policy binding, any Authentik user can get a token for any first-party client. Folded into E2(c) | [R] from seed (no bindings created). **[T] 2026-10-01**: a user in no group got tokens from `azblink-directory` |
| G13 | **Per-client env names break on the hyphen.** `AUTHENTIK_CLIENT_SAFENEST-A1_*` is not a valid name, and compose silently reads `${AUTHENTIK_CLIENT_SAFENEST-A1_X}` as `AUTHENTIK_CLIENT_SAFENEST` with default `A1_X`. The seed gets a fixed `environment:` list (`deploy/dev/docker-compose.yml:467-485`), not an `env_file`, so every new variable is a compose edit. Folded into E2: one JSON `AUTHENTIK_FIRST_PARTY_CLIENTS`, groups derived from the client_id | [R] 2026-10-02 |
| G14 | **A plain `groupOfNames` does not sync.** `object_uniqueness_field: "uid"` (`seed_authentik.py:394`) applies to groups too, and `groupOfNames` has no `uid`. Probe (`group_sync_probe.py`): with `sync_groups`, `additional_group_dn: ou=groups`, filter `(&(objectClass=groupOfNames)(cn=safenest-dev-*))`, `group_membership_field: member` and the managed `openldap-cn` group mapping, the sync reports `done` and imports **0** groups. Adding `objectClass: uidObject` + `uid=<cn>` to the same group imports it with `ldap_uniq=<cn>`, and its `member` DN matches the OpenLDAP user (`robert`) through the user's stored `distinguishedName`. `safenest-devx-resident` is not matched by the `safenest-dev-*` term. So E2b uses the aux class and does not move users to `entryUUID`. Groups created by `ldap_client.create_group` (`:560-563`) are plain `groupOfNames` with the bind DN as placeholder member, so E2b adds the aux class there | [T] 2026-10-02 |
| G15 | **Removed roles linger.** Removing a member (`routers/groups.py:239-257`) does not tell Authentik. Sessions are revoked only on termination (`authentik_client.py:78-139`). Refresh (7 d) keeps reissuing the stale `groups` until the next sync, and the default sync interval on 2026.5 is [N]. See decision 16 | [R]. **Resolved by E2b:** the API queues a source sync after each `<client>-*` change; live probe: removal reached Authentik in about 8 s and the next refresh dropped the role (`role_sync_probe.py`, `run6.txt`) |
| G16 | **Deleted groups never go away.** `delete_not_found_objects: False` (`:400`) covers groups too. Deleting `safenest-a1-resident`, or dropping a building from the filter, leaves the Authentik group and its members. It cannot simply be turned on: ARD-007 relies on it for users. E2b needs a scoped cleanup for `<client>-*` groups | [R]. **Resolved by E2b:** `DELETE /api/groups/{cn}` also deletes the Authentik group for `<client>-*` names |
| G17 | **Group name uniqueness and case.** `create_group` checks only the exact DN (`ldap_client.py:554-557`), so `cn=safenest-a1-admin` can exist under `ou=groups` and an org sub-OU at once; `find_group_dn` returns the first (`:626`). The cn rule (`schemas/groups.py:12`) allows upper case, the LDAP filter is case-insensitive, the token is not. Fix in E2b: names under a registered client prefix are lowercase and live only at the top of `ou=groups` | [R]. **Resolved by E2b:** `create_group()` refuses `<client>-*` names that are not lowercase or sit under an org (422) |
| G18 | **No building-scoped admin.** Group writes need `user_management` (`routers/groups.py:181,214`), which is directory-wide (ARD-017 has no resource scoping). A SafeNest service client holding it could edit `safenest-b2-*`, `IT-Admins`, any user, and reset passwords. Blocks SafeNest phase 3 (roster writes to azb-AD), not phase 1. See decision 17 | [R] |
| G19 | azb-AD's API must keep rejecting `aud=safenest-*` (`config.py:79-81`). Folded into E2(e) | [R] |
| G20 | **Prod has no client config path.** `deploy/ansible/roles/azblink_app/templates/env.j2` carries no `AUTHENTIK_*` client variables (spec 06:304-305). Production needs it before the first real building | [R]. **Resolved 2026-10-02 (G20 PR):** `authentik-seed` already runs on the prod compose path; `env.j2` renders `AUTHENTIK_FIRST_PARTY_CLIENTS` from the inventory var `authentik_first_party_clients` and `verify.yml` waits for each provider |
| G22 | **`default-authentication-flow` is an unthrottled LDAP-lockout path** (E5 review). Its password stage binds to LDAP with no reputation check; anyone reaching port 9000 or the tunnel can lock a user with 5 attempts. Throttling it means the admin web login inherits a no-heal 24 h block | **Resolved 2026-10-07** (owner: "do them securely"; ARD-018 amendment). The seed puts the headless lockout on the brand flow too, with the password binding in policy mode `all` (under `any`, the flow's "password needed" policy outvoted the check, [T]). [T] `tests/test_web_signin_lockout.py`: 3 failures block web sign-in, LDAP `(3, False)`; it fails when the mode is `any` or the check is unbound. Without the deny stage and the login guard a throttled user got a session with no password [T]. Admin unblock runbook in spec 08 (`ak shell` when no admin can sign in) [T] |
| G23 | **Parallel requests pass any Authentik-side check** (E5 review). K concurrent password POSTs are all checked before a failure is recorded (about 8 per server replica), so 2 earlier failures + parallel ones can reach ppolicy's 5. Only an LDAP margin closes it: `pwdMaxFailure` ≥ 3 + 8 × replicas + 1, which contradicts ARD-018's "below 5" wording | **Resolved 2026-10-08 (ARD-018 G23 amendment).** An LDAP bind budget reserves one of a username's 3 binds atomically before the password stage, shared by both flows. [T] 96 parallel after 2 failures: 1 reached the bind (90 before), LDAP unlocked. It also closes the expired-row window. Earlier, measured 2026-10-07: the "8 per replica" premise is wrong on 2026.5: ASGI workers run each request in its own thread. [T] 32/32 and 90/96 parallel POSTs reached the check; a 16-wide burst locked an LDAP account. No `pwdMaxFailure` margin closes a race bounded by DB connections, so it stays 5. Residual (spec 08): one LDAP lock (300 s) per username per reputation-row lifetime. A real fix is a pre-bind atomic reservation, a new mechanism (now built) |
| G24 | **Reputation row expiry vs `pwdFailureCountInterval 0`** (E5 review). A row expires 24 h after its first failure and keeps absorbing failures unseen for up to 5 min until cleanup; LDAP keeps failures until a successful bind. After expiry 2 more failures lock LDAP. Setting `pwdFailureCountInterval` (e.g. 3600) narrows it | **Resolved 2026-10-07** (owner; ARD-018 amendment): `pwdFailureCountInterval: 3600`, between `pwdLockoutDuration` (300) and the reputation expiry (86400), with `ppolicy-lockout.ldif` for initialized volumes (ansible). [T] Two 3-failure lockouts one interval apart leave LDAP unlocked; with 0 the second locks it. The ≤ 5 min unthrottled window after a row expires remains |
| G21 | **Possible conflict with the tenant proposal.** `proposals/2026-07-05-tenant-isolation-and-machine-identity.md` D1 picks one deployment per tenant. Decision 8 puts every building on one azb-AD. E1's ARD must say whether a building is a tenant | [R] |

## 5. Owner decisions before starting

| # | Decision | Recommended |
|---|---|---|
| 1 | B1 (relay in the client) vs B2 (azb-AD endpoint) | **B1**. Only the client sees passwords |
| 2 | Accept no browser SSO for headless clients (other apps prompt again [T]) | Accept, per client. Branded redirect is the alternative |
| 3 | MFA for headless clients | **Fail closed** (rule 5) now. The TOTP second step comes later, per client |
| 4 | Lockout model (G1) | **Authentik username policy trips first** (E5a) |
| 5 | Access-token TTL | **15 min** for every first-party client (rule 3) |
| 6 | Authentik 2026.8 upgrade order (G5) | **After E4** |
| 7 | Group naming across clients | **Client-prefixed** (`<client>-<role>`; for SafeNest the client is per building, so `safenest-<building>-admin`, decision 13): no collisions between clients, and it maps 1:1 to E2's access binding. The alternative is shared semantic groups reused across apps |
| 8 | azb-AD topology: one shared instance vs one per building (open since 18 Sep) | **Decided 2026-10-02 (SafeNest owner): one shared azb-AD, the only directory.** One first-party client per building box, `safenest-<building>`, own secret, access binding to that building's groups. `aud` = that client_id, issuer `<host>/application/o/safenest-<building>/`. SafeNest's own OpenLDAP retires after its phases 3–4 |
| 12 | Building id format | **Decided 2026-10-02 (azb-AD owner):** `^[a-z0-9]{2,16}$`, a stable opaque code, not a name or address. **No hyphen**: E2b filters on the prefix `safenest-<building>-`, so ids `a1` and `a1-annex` would make `safenest-a1-*` match `safenest-a1-annex-resident`. Used as-is in the client_id, the Authentik slug and the LDAP group `cn` |
| 13 | Role groups: per building or global | **Decided 2026-10-02 (azb-AD owner): per building**, `safenest-<building>-<role>`. With global groups a person who is admin in A and resident in B gets admin on B's box, and the access binding cannot fix that: it scopes who logs in, not which role they get. The standard groups scope still emits every group the user has, so a box must honour only its own `safenest-<building>-*` groups (no per-client groups mapping, #279) |
| 14 | Relay path for remote building boxes (revisits 11) | **Dev decided 2026-10-02 (SafeNest owner):** SafeNest runs on the azb-AD physical host. Either the same VM (relay on the docker network, `iss` = `http://authentik-server:9000/…`) or a sibling VM calling the published port (`deploy/dev/docker-compose.yml:409`, all interfaces), with `iss` = the exact host string the relay uses. **Production deferred**, gated by E5 before real users: a routed path where Authentik sees each box's own IP (site VPN, static IP per box), so E5(b) can trust one CIDR per box. Through the tunnel Authentik sees `cloudflared`, not the box (G2). Docker DNAT keeping the sibling VM's source IP is [N] |
| 9 | Generic pattern vs SafeNest-only | **Generic** (owner direction, 2026-09-25) |
| 10 | LDAP group sync vs the azb-AD admin group | **Decided 2026-10-01: A.** Sync app role groups only (`<client>-*` filter). `IT-Admins` is never synced. LDAP-driven admin access (option C) is a separate, later ARD |
| 11 | Relay → Authentik host | **Decided 2026-10-01: docker network** (`http://authentik-server:9000`). Tunnel unsupported until E5 covers it |
| 15 | First-party client config shape (G13) | **Decided 2026-10-02 (azb-AD owner):** one JSON `AUTHENTIK_FIRST_PARTY_CLIENTS` (client_id → redirect URIs), groups derived from `<client_id>-*` |
| 16 | Role-removal latency (G15) | **Decided 2026-10-02 (azb-AD owner):** the directory API triggers an LDAP source sync after any membership change to a registered `<client>-*` group, and E4 asserts the role is gone by the next refresh. Fallback: a fixed sync interval written into the ARD as the maximum latency |
| 17 | Who manages SafeNest role membership (G18) | **Decided 2026-10-02 (azb-AD owner):** azb-AD admins through the existing `/api/groups/*` for phases 1–2. A building-scoped admin grant is a separate ARD before SafeNest phase 3 |
| 18 | Building vs tenant (G21) | **Decided 2026-10-02 (azb-AD owner):** a building is not a tenant. One azb-AD per operator, and buildings are clients inside it. E1 records this |
| 19 | Who creates `<client>-<role>` groups (G14, G17) | **Decided 2026-10-02 (azb-AD owner):** azb-AD does, through `/api/groups/*`, which adds `uidObject` + `uid=<cn>` and enforces G17. Client apps create no LDAP groups. The E2b filter stays `groupOfNames` + one `cn=<client>-*` term per client: the `uid` uniqueness field already skips entries without `uid` |
| 20 | Logout rule 6 | **Decided 2026-10-02 (SafeNest owner):** option A, drop the Authentik session delete. Logout = refresh-token revoke + drop the client session. No azb-AD helper endpoint |

## Alignment with the review brief

Checked against artifact `Pkn7XYSwAeB2g3hC4Kzax5`. What already matches:

- E1–E5, D0, E6-not-needed.
- The phase mapping, including the corrections (E4 in phase 1, E5 before any real users).
- The 8 handover inputs.
- The evidence and the viability numbers.

Deltas the brief should pick up:

| # | Brief says | This plan says | Why |
|---|---|---|---|
| A1 | SafeNest-specific ARD, provider and flow (`safenest-headless-auth`) | Class ARD, env-registered clients, one shared flow `headless-first-party-auth` | Owner direction: one pattern for every later client |
| A2 | Phase 2 exit: "5 bad passwords lock one username and nobody else" | **3** bad passwords lock the username in Authentik; the LDAP account stays unlocked | 5 equals ppolicy's `pwdMaxFailure`, so it would also lock LDAP and XMPP, which is the exact failure E5 prevents |
| A3 | TOTP second step out of scope, with no behaviour stated | MFA fails closed (rule 5), and E3 keeps the validate stage | Dropping the stage would let enrolled users skip MFA |
| A4 | Access TTL 15 min recommended; "Access-token TTL" is still a handover input | 15 min fixed by rule; removed from the inputs | Same as service clients (`seed_authentik.py:588`) |
| A5 | Group names "to be named in Authentik" | Client-prefixed groups recommended (decision 7), plus a per-client access binding (G11) | Needed once a second client exists |
| A6 | Totals 20–30 h, phase 1 10–14 h | 23–34 h, phase 1 13–18 h; about 1–2 h per later client | Consolidating the provider helper and the class rules |
| A7 | "ARD-002 line 29 puts SafeNest behind Authentik OIDC **redirect**" | Line 29 says "behind Authentik OIDC. No fallback". The PKCE redirect is spec 04:12 | Citation accuracy |
| A8 | G8 "ARD number clash" | ARD-016 is **missing**, not clashing | Wording |

## Not reviewed (blind spots)

- SafeNest's relay code: none exists yet (audit 2026-10-02). Its plan, `azb-safenest/docs/plans/2026-09-25-safenest-sso-headless-login-plan.md`, was read. SafeNest-side gaps were sent to that session rather than tracked here.
- Authentik docs for default `trusted_proxy_cidrs`, application policy bindings on 2026.5, and the 2026.8 release notes.
- `docs/architecture/surfaces.yaml`, checked only by code search.
- The live stack was not re-probed. [T] marks come from the 2026-09-25 morning runs.
