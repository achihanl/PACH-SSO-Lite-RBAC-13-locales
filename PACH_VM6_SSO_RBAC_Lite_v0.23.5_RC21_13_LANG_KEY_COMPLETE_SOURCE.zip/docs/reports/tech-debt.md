---
title: Tech Debt Register
description: Living source of truth for deferred and known-debt items, reviewed weekly and closed with resolution notes
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
---

# Tech Debt Register

<!--
- Purpose: single source of truth for deferred/known-debt items, so debt is paid
  down on a cadence instead of silently accumulating.
- Cadence: reviewed WEEKLY by a scheduled Claude Code routine (see § Automation).
- Severity: P0 (breaks prod) · P1 (serious, fix soon) · P2 (should fix) · P3 (minor/cosmetic).
- Status: open · in-progress · blocked · done.
- An item is OVERDUE when today is past its Target date.
- On close: move the row to § Closed with the resolution + date.
- Mirrored by memory pointer `project_tech_debt_register.md` → MEMORY.md (per-session reminder).
-->

> **Source of truth.** Edit here. The agent-memory entry only mirrors the count for
> per-session reminders. Started 2026-07-02.

## Open

| ID | Area | Item | Sev | Added | Target | Status |
|----|------|------|-----|-------|--------|--------|
| TD-5 | deploy | Ansible full live `-K` converge on `azb-ad` (dev VM) — operator task, interactive sudo; azb-ad GitHub-air-gapped (`--skip-tags fetch`). | P2 | 2026-06-22 | TBD | open |
| TD-4 | arch | Phase 1b = **anchor-scoped enforcement**: rule 5 (`_claude_md_architecture_edit`) still treats *any* `CLAUDE.md` edit as an architecture-anchor edit rather than inspecting hunk lines against `## Architecture (Quick Reference)`, and the helper is seeded but not wired into `run_guard`. The calibration half of this row is resolved — the guard has run in **fail mode** since 2026-07-31 (#234, PR #260): `--warn-only` and the workflow's `continue-on-error` are both gone, and trailers are enforced. Note the check is not a *required* status check (platform limitation, tracked separately at SOP.md § Known enforcement gap / #234). See CLAUDE.md § Architecture Commit Trailers. | P3 | 2026-07-02 | TBD | open |
| TD-6 | ci | CodeRabbit Free rate-limited / no line-by-line → no reliable automated PR review; adversarial-review workflow is manual. Consider upgrade or a cheaper automated gate. | P3 | 2026-07-02 | TBD | open |
| TD-8 | security | UC session termination is a stub — `UCClient.terminate_user_sessions()` performs no teardown, so a terminated user's **already-established** SIP registration and XMPP session survive until natural expiry (LDAP disable stops new binds only; per ARD-001 neither credential is re-consulted mid-session). Real impl needs Asterisk ARI + an ejabberd/Prosody admin API — **blocked on a UC Server API specification**. The audit half is fixed (#233): the stub now returns `None` counts behind `implemented: False` and the event records `uc_sessions: "not_implemented"` instead of a `0` that read as a genuine "no live sessions found". Accepted risk documented in spec §02 § Termination Flow. | P1 | 2026-07-29 | 2026-10-31 | blocked |
| TD-9 | arch | ARD-013 § 5's invariant — every `ldap_client.get_conn()` call must run inside `safe_ldap()` or `ldap_conn()` — is **unenforced**. A new caller written outside both wrappers leaks a socket and a file descriptor on every exception path, exactly as the pre-#226 code did, and no lint rule, test, or guard detects it. It holds today only because every caller was checked by hand while writing ARD-013. Same shape as #265 (governance by enumeration with no mechanism). Cheapest plausible fix: an AST or import-graph check over `src/backend/**` asserting no `get_conn()` call site outside the two wrappers. | P3 | 2026-08-01 | TBD | open |
| TD-7 | security | Dependabot #27 — esbuild `>=0.27.3 <0.28.1` (GHSA-g7r4-m6w7-qqqr): **arbitrary file read via esbuild dev-server on Windows**, `scope: development`, LOW. Pulled transitively by `tsup ^0.27.0` (tsup@latest 8.5.1 still pins `^0.27.0`; no clean bump). npm 11 silently ignores an `overrides` to force `^0.28.1`; a full lockfile regen churns unrelated deps without fixing esbuild. **Near-zero real risk** (project is Linux; tsup *bundles*, never runs esbuild's serve). **Deferred** — revisit when tsup widens its range, or force via a dedicated dependency PR if policy requires a clean alert. | P3 | 2026-07-02 | TBD | open |

## Closed

| ID | Area | Item | Sev | Added | Resolved | Resolution |
|----|------|------|-----|-------|----------|------------|
| TD-1 | tests | `/api/system/versions` **failure-path** test — real-stack integration can't force a probe failure. (Non-admin-403 half done in v0.13.0.) | P3 | 2026-07-02 | 2026-07-08 | Extracted the freeze/retry/ttl logic from `main.py` into dep-free `src/backend/version_cache.py` (`cached_probe`; `main.py` imports it, call sites unchanged) so it is importable without a live DB (`main.py` runs `ORGDB.init()` at import). `tests/unit/test_version_cache_unit.py` (5 tests) mocks the probe to exercise fail→retry, self-heal, freeze-forever, ttl re-probe, and no-evict-on-failed-refresh. Live `/api/system/versions` re-verified 200 post-extraction. |
| TD-3 | deploy | `Dockerfile.api` CMD ran `uvicorn --reload` → dev-server flags reached prod (ansible deploys the same `deploy/dev` compose; `inventories/prod` sets `n: deploy/dev` — prod compose split is future work). | P1 | 2026-07-02 | 2026-07-08 | Env-driven CMD (v0.13.0): image CMD defaults **prod-safe** — multi-worker, no `--reload`; dev opts in via `UVICORN_RELOAD=1` (compose). Ansible `env.j2` renders `UVICORN_RELOAD=0` + `UVICORN_WORKERS` for prod. `--reload`/`--workers` branch since they are mutually exclusive. |
| TD-2 | tests | No non-admin test fixture — only admin `client` + `anon_client`; blocked authz-forbidden (403) tests and TD-1. | P2 | 2026-07-02 | 2026-07-06 | `non_admin_client` fixture (real non-admin Authentik user + client_credentials M2M token) added in `tests/conftest.py`; merged via PR #187 (`afccf1c`). Proves the C1 deny path (non-admin → 403) and unblocks TD-1. |

## Automation

- **Weekly routine:** a scheduled Claude Code cloud agent reviews this file every week —
  flags overdue items (today > Target), scans the repo for new debt signals
  (`TODO`/`FIXME`/`HACK`/`XXX`, dead-code/lint findings), and reports a summary.
- **Per-session reminder:** `MEMORY.md` carries the open count so every agent session
  opens with the current debt state.
