---
title: VM7 Nextcloud SSO Integration Report — findings and azb-AD gaps
description: Measured findings and gap analysis from VM7 (PACH Document Share Adapter)'s integration with azb-AD SSO and directory identity
type: reference
product: azblink-directory
status: current
updated: 2026-08-08
---

# VM7 Nextcloud SSO Integration Report — findings and azb-AD gaps

- Date: 2026-08-07 UTC
- Operator: Claude Opus 5 (1M context)
- Consumer under test: VM7 — PACH Document Share Adapter (`azb-document-share-adapter`, branch `feat/sso-and-self-containment`)
- azb-AD under test: 0.17.0 (`c0574ef`), Authentik 2026.5, OpenLDAP 1.5.0
- Host: `safenest` (192.168.4.111), dev stack, 13 containers, 0 unhealthy throughout
- Consumer-side design: `docs/superpowers/specs/2026-08-06-vm7-self-containment-and-sso-design.md` in the VM7 repo

**This report asserts nothing about azb-AD's behaviour that was not measured on the
running dev stack.** Where a claim is inherited rather than observed it says so.

A code review after publication overturned six of the nine gap entries. The
measurements held; the causes inferred from them did not. Sections 3, 5 and 6
carry the corrected findings, and **§10 records what each entry originally
claimed and what disproved it.**

## 1. Executive summary

VM7 is the second consumer of azb-AD SSO, and the first that needs directory
identity to be *the same identity* its application logic addresses. It shares
files to named Nextcloud user IDs over OCS, so "the Nextcloud user ID equals the
LDAP `uid`" is a correctness requirement, not a convenience.

| Area | Status | Verdict |
|---|---|---|
| OIDC login into a third-party RP (Nextcloud) | ✅ PASS | Full redirect chain, session established as the directory `uid` |
| No duplicate account created by OIDC | ✅ PASS | 55 accounts before and after; `oc_user_oidc` 0 rows |
| LDAP as sole account source | ✅ PASS | 54 LDAP-mapped + 1 local; test user absent from local table |
| Group resolution from LDAP | ✅ PASS | Resolved to `Executive`, `C-Suite` on first login |
| Addressing a share to a directory `uid` | ✅ PASS | Including a recipient who has never logged in |
| Unknown `uid` fails closed | ✅ PASS | OCS 404, no dangling share |
| azb-AD #279 fix (duplicate groups claim) | ✅ VERIFIED | Legacy mapping deleted |
| azb-AD #281 fix (application slug lookup) | ✅ VERIFIED | Re-seed with two applications left the second intact |

**Overall verdict: the SSO contract works.** Nothing in azb-AD had to change for
VM7 to integrate, and that stands. But the gap analysis was revised after
publication, and **three** of the nine entries are live defects in the current
stack rather than the two originally reported:

- **G4** — the `memberOf` overlay is bound to an attribute pair azb-AD never
  writes. It has never populated a single entry and never will, for any
  membership past or future.
- **G5** — termination leaves no directory-visible state, so a terminated user
  remains an enabled, addressable account in every LDAP-backed consumer
  indefinitely — not merely for the 8h token window.
- **G9** — azb-AD never writes LDAP `displayName` on any path. A consumer
  keying on it sees only the users a dev seed script created; a production
  deployment would present it with none.

## 2. Environment snapshot

| Item | Value |
|---|---|
| azb-AD | 0.17.0, `main` @ `c0574ef` |
| Authentik | 2026.5, `http://192.168.4.111:9000` |
| OpenLDAP | osixia 1.5.0, `dc=azblink,dc=com`, 389→1390, 636→1637 |
| Directory entries | 60 users under a flat `ou=people` (54 visible to a consumer keyed on `displayName`, all 54 written by the dev seed — see **G9**), 12 groups under `ou=groups` |
| Nextcloud | 34.0.2, `user_ldap` 1.25.0, `user_oidc` 8.10.1 |
| Euro-Office | documentserver 9.3.1.37 (an ONLYOFFICE version — confirms the rebrand) |
| Test subjects | `dchang` (Executive, C-Suite), `tchen`, `ywang` (never logged in) |

## 3. The contract VM7 consumes

Recorded so azb-AD knows what it is now load-bearing for. All four were
measured.

| # | Property VM7 depends on | Observed |
|---|---|---|
| C1 | `preferred_username` in the ID token equals the LDAP `uid` | Yes — this is the entire basis of the integration |
| C2 | The `profile` scope carries `preferred_username` | Yes; `claims_supported` also lists `groups` |
| C3 | A user's LDAP entry is readable by a bound client, including a display name, `mail` and group `member` | Yes — but the display name is carried by `cn`. LDAP `displayName` is written by nothing in azb-AD, so a consumer must map to `cn`. See **G9** |
| C4 | `ou=people` is searchable one-level and subtree with the same result | Yes — all 60 users are flat under `ou=people` |

C4 corrects an earlier draft of the VM7 design, which claimed users lived in a
nested tree and that a one-level search would return zero. Measured against the
running directory that is false; the nested tree is `ou=org`, which contains
organisational units and no people. A user's placement is carried by an `ou:`
*attribute* on the flat entry.

## 4. Test results

### 4.1 Identity plane

| Observation | Before | After OIDC login | After LDAP login |
|---|---|---|---|
| Total Nextcloud accounts | 55 | 55 | 55 |
| Accounts named `dchang` | 1 | 1 | 1 |
| `dchang` backend | LDAP | LDAP | LDAP |
| Rows in `oc_user_oidc` | 0 | 0 | 0 |
| `dchang` in the local users table | 0 | 0 | 0 |

The OIDC login drove the real redirect chain through Authentik's flow executor
and landed an authenticated session on the Nextcloud dashboard. `user_oidc`
created **no backend record at all** — it adopted the existing LDAP account.

The Authentik provider was deliberately left on `sub_mode: hashed_user_id` so
that an opaque `sub` could not mask a failure to map on `preferred_username`.
That is the strong form of the test, and it passed. See **G6**.

### 4.2 Sharing by directory `uid`

| Case | Result |
|---|---|
| directory user → directory user (`tchen` → `dchang`) | `share_with='dchang'`, recipient reads the bytes |
| local service account → directory user, previously logged in | `share_with='dchang'` → "David Chang" |
| local service account → directory user, **never logged in** (`ywang`) | `share_with='ywang'` → "Yuki Wang" |
| local service account → nonexistent `uid` | Refused, OCS 404 |

The never-logged-in case is the one that matters to azb-AD: `user_ldap` syncs
lazily, so "the user exists in the directory" and "a consumer can address that
`uid`" are separate claims. The second holds.

### 4.3 azb-AD fixes verified

**#279 — duplicated groups claim.** The legacy `AZBlink OAuth Mapping: groups`
object is gone from Authentik, and the Nextcloud provider carries exactly the
three built-in scope mappings it needs (`openid`, `profile`, `email`) with no
dangling references. The prune did not damage a provider created outside the
seed.

**#281 — application lookup by slug.** Verified in the strongest available form:
the seed re-ran with **two** applications present (`azblink-directory` and
`nextcloud`) and left the Nextcloud one intact. That is exactly the scenario the
old `?slug=` filter would have skipped, since the endpoint ignores the filter in
`results` and only zeroes `pagination.count`. Before this fix, a second
consumer's application could have been silently dropped on any re-seed.

## 5. Technical gaps in azb-AD

Listed by ID; §6 orders the work. Each states what was measured, why it matters
to a consumer, and a suggested direction. None of these blocked VM7.
**G4, G5 and G9 are live defects in the current stack**; G5 is the one with a
security consequence. Six entries here were rewritten after a post-publication
code review — see §10.

### G5 — Termination does not propagate to relying parties `[SECURITY]`

**Measured.** Termination has three legs and two of them never reach a relying
party.

*Directory state.* `disable_user()` (`src/backend/ldap_client.py:1160`) sets
`userPassword` to `{DISABLED}` and `description` to `TERMINATED`. It changes
nothing else. The entry still satisfies any ordinary user filter, so an
LDAP-backed consumer keeps the account **enabled and addressable indefinitely**.
A terminated employee stays a valid share recipient with no expiry at all.

*Group membership.* `disable_user()` removes the user from no groups.
`docs/architecture/spec/02-component-architecture.md:289` states, marked
`[AS-BUILT]`, that it "sets `userPassword` to a locked value, removes from all
groups". The second clause has never been implemented. A terminated user retains
every group membership — and once **G4** is repaired would begin carrying
`memberOf` for groups they were terminated out of.

*RP session.* `terminate_user_access(username)` (§08 of the architecture spec)
revokes Authentik sessions and OAuth2 access tokens. It has no effect on a
relying party that has already minted its own session: after an OIDC login
Nextcloud holds its own session cookie, and killing the Authentik session does
not log that browser out. The provider's `access_token_validity` is `hours=8`.
The discovery document **does** advertise
`end_session_endpoint: .../application/o/nextcloud/end-session/`, but the
relying party was not configured with it and no back-channel logout is wired.

**Why it matters.** The LDAP disable does stop new logins — Authentik federates
against this directory, so a `{DISABLED}` password fails the bind. What it does
not do is tell any consumer the account is dead. For a file-sharing consumer the
terminated user remains a live share target permanently, which outlasts the 8h
session window by an unbounded margin. The original entry named only the session
leg, which is the smaller of the two.

**Direction.** Do the directory leg first: give termination a state a consumer
can filter on, and make `disable_user()` remove group memberships so the code
matches the spec (or correct the spec, but the spec has the better behaviour).
That alone makes every LDAP-backed consumer disable the account on its next
sync, with no RP registry involved. The session leg — back-channel logout, or
fanning `terminate_user_access` out to registered RP logout endpoints — needs
the RP list to become first-class, which is **G1**.

### G9 — azb-AD does not write LDAP `displayName` on any path

**Measured.** `ou=people` holds 60 `inetOrgPerson` entries. Nextcloud lists 54.
The six missing are `alanl`, `audit-test-user`, `qa.smoke.5pahtp`,
`qa.smoke.5pdl1w`, `xmpptest1`, `xmpptest2`. All six have `uid`, `cn`, `sn` and
`mail`; none has `displayName`. Every visible user has it.

Confirmed as cause and effect, not correlation:

```
occ ldap:check-user alanl    -> "The given user is not a recognized LDAP user."
occ ldap:check-user dchang   -> "The user is still available on LDAP."

share to alanl   -> OCS 404 "Please specify a valid account to share with"
share to dchang  -> OCS 200 OK
```

The original reading of this — six bad rows from creation paths that disagree —
was wrong, and understated it. **azb-AD writes an LDAP `displayName` on no path
at all.** `create_user()` (`src/backend/ldap_client.py:1019`) writes `uid`,
`cn`, `sn`, `givenName`, `userPassword`, and optionally `mail`, `mobile`,
`title`, `employeeNumber` and `manager`. `update_user()` maps the API field
`displayName` onto LDAP `cn` (`:1069`), and every read reconstructs the API
field from `cn` (`:711`, `:762`, `:847`, `:885`, `:960`). In azb-AD's model
**`cn` is the display name**; `displayName` is not part of the schema the
product maintains.

The sole writer of a real LDAP `displayName` is
`deploy/dev/seed/seed_demo_data.py`, a dev-only demo fixture. The six are
therefore not the anomaly — the fifty-four are. Every user created through the
product lacks the attribute, and a production deployment carrying no demo seed
would present a consumer keyed on `displayName` with **zero** addressable users,
not 90%.

**Why it matters.** `alanl` is a real, active directory user, and a consumer
cannot address them **at all**. The failure is byte-identical to the response
for a `uid` that does not exist — so a consumer cannot distinguish "no such
user" from "user exists but is unreachable", and neither can its operator. VM7's
fail-closed behaviour, which §4.2 records as a feature, becomes indistinguishable
from data loss. That consumer-visible failure is exactly as bad as first
described; what changes is its scope and its fix.

**Direction.** The consumer maps its display-name attribute to `cn` — for VM7,
`ldapUserDisplayName=cn` in `configure.sh`. That is not a workaround but the
correct reading of azb-AD's data model, and it is a one-line change that fixes
all sixty users at once. azb-AD's side is to state the mapping in the consumer
contract and add a test asserting no entry under `ou=people` has an empty `cn`.

Introducing a real `displayName` attribute was considered and rejected: it
duplicates `cn`, must be kept in sync on every write path forever, and needs a
migration — all to satisfy a default the product has never held.

### G1 — No provisioning path for OIDC relying parties

**Measured.** `ou=clients` contains `cn=ped80` and `cn=authentik-sync`, both
provisioned through ARD-006's
`POST /api/settings/ldap/clients/provisioned`. There is no equivalent for OIDC.
To onboard Nextcloud we hand-rolled a script against Authentik's Admin API using
`AUTHENTIK_BOOTSTRAP_TOKEN`, duplicating the provider/application logic in
`deploy/dev/authentik-seed/seed_authentik.py`. That script was deliberately not
committed (§7), so consumer #3 starts from nothing.

**Why it matters.** LDAP clients self-provision; OIDC clients do not. Every
future SSO consumer re-implements provider creation, redirect-URI syncing, scope
mapping selection and the Authentik gotchas already catalogued in §08 — and
needs the bootstrap token to do it, which is a far broader credential than the
task requires. It is also why **G5**'s session leg has nowhere to record an RP's
logout endpoint.

**Direction.** Near-term, fold Nextcloud's provisioning into
`deploy/dev/authentik-seed/` as a second seeded application taking credentials
from the environment, and issue a scoped Authentik token in place of
`AUTHENTIK_BOOTSTRAP_TOKEN`. That captures what this integration learned and
closes the over-broad-credential problem without new architecture.

Mirroring ARD-006 with a declarative relying-party record (client id, redirect
URIs, scopes, logout endpoint, `sub_mode`) reconciled by the seed or an API
endpoint remains the right end state. Two consumers is thin evidence for the
abstraction, so build it when consumer #3 arrives or when the back-channel
logout leg of **G5** is scheduled — whichever comes first.

### G2 — Port 636 is bound but serves no TLS

**Measured.** `azblink-openldap` runs with `LDAP_TLS=false`. Port 636 is
listening and published to 1637, but the TLS handshake fails and no certificate
can be retrieved. `ldapsearch -H ldaps://…` returns
`Can't contact LDAP server (-1)`.

**Why it matters.** Less than this entry originally claimed. It first treated
the plaintext path as blocking the production-shaped configuration, because
VM7's configurator refuses to run in production against a plaintext `ldap://`
URI and exits non-zero by design.

But plaintext on the LAN is azb-AD's **ratified** posture, not an oversight.
`deploy/dev/docker-compose.tls.yml` records that "LAN deploys skip this entirely
(the ratified posture is plaintext HTTP on the LAN behind loopback-bound ops
ports)", with TLS an opt-in edge concern terminated at Traefik or Cloudflare.
Nothing in spec §07 requires LDAPS. VM7's guard is therefore stricter than any
rule azb-AD has adopted — the consumer is enforcing a policy the directory never
agreed to.

What survives is a papercut: a listening port that serves nothing reads as a
network fault rather than "TLS is switched off".

**Direction.** VM7 relaxes its guard to require TLS only when the LDAP host is
off-LAN, which makes the production-shaped path exercisable immediately. azb-AD
stops publishing 1637 (or unbinds 636) so the port's absence is honest. Serving
LDAPS would be a posture change beyond the current ratified decision — it would
need its own ARD, cert lifecycle in production, and it touches every existing
LDAP client.

### G3 — Nextcloud bound as admin, though a scoped client was already available

**Measured.** No `cn=nextcloud,ou=clients` entry exists. The integration bound
as `cn=admin,dc=azblink,dc=com`.

The machinery to avoid that already exists and is working. The read-minus-secrets
ACL is live on the running directory and matches
`deploy/dev/ldap/ldap-clients-acl.ldif` exactly: rule `{1}` protects
`userPassword` and `shadowLastChange`, rule `{2}` protects
`azbXmppBindPassword`, `AstAuthPassword` and `AstAuthMd5Cred`, and rule `{3}`
grants `dn.children="ou=clients,dc=azblink,dc=com"` read on everything else —
which covers the `member` reads on `ou=groups` this entry originally flagged as
needing confirmation.

**Why it matters.** ARD-001 puts identity and UC service attributes on the same
entry, so an admin bind hands a document-sharing consumer read access to
`AstAuthPassword` and the rest of the UC secrets. It needs `uid`, `cn`, `mail`
and group `member` — nothing else. But this is an operational omission rather
than a design gap: nobody called the provisioning endpoint.

**Direction.** Provision `cn=nextcloud,ou=clients` through ARD-006's
`POST /api/settings/ldap/clients/provisioned` and rebind VM7 to it. One API
call.

### G4 — The `memberOf` overlay is bound to the wrong attribute pair

**Measured.** **No** entry under `ou=people` carries `memberOf` — not one, and
not only the entries that predate the overlay, as this was first reported.

The overlay is loaded. `olcOverlay={0}memberof,olcDatabase={1}mdb,cn=config`
exists on the `dc=azblink,dc=com` database. Its live configuration is:

```
olcMemberOfGroupOC:  groupOfUniqueNames
olcMemberOfMemberAD: uniqueMember
```

Those are OpenLDAP's compiled-in defaults.
`deploy/dev/ldap/memberof-refint-config.ldif` specifies `groupOfNames` /
`member`, and the groups really are `objectClass: groupOfNames` carrying
`member:`. The LDIF's `changetype: add` collided with an already-present overlay
on first boot and its attribute values were never applied — precisely the
failure that file's own comment anticipates ("If this fails to load on first
boot, apply manually"). Nothing asserted the outcome, so it went unnoticed.

Confirmed as cause and effect, on a membership created through the product
seconds earlier:

```
POST /api/groups/Executive/members {"uid":"xmpptest1"}  -> {"ok":true}
ldapsearch cn=Executive ... member    -> member: uid=xmpptest1,ou=people,...
ldapsearch uid=xmpptest1 ... '*' '+'  -> no memberOf attribute
```

**Why it matters.** VM7 works only because `user_ldap` was deliberately
configured for member-based association. A consumer that filters on `memberOf` —
the more common default — gets an empty result and therefore *no groups*,
silently and with no error. That is a wrong-answer failure, not a loud one. And
because the overlay watches an attribute pair azb-AD never writes, this is not a
backlog of unpopulated entries: it will not populate the next membership either.

**Direction.** Change the LDIF to an attribute-level modify so it repairs an
already-present overlay instead of failing silently, apply the corrected values
to the running directory, and rewrite existing memberships so `memberOf`
populates. Then add a test that adds a member through
`POST /api/groups/{cn}/members` and asserts `memberOf` on the user entry. The
test is the load-bearing part — without it this regresses invisibly on the next
fresh boot, exactly as it did the first time. A backfill on its own fixes
nothing: the directory would go stale again on the very next group add.

### G6 — `sub_mode: hashed_user_id` is a trap for LDAP-correlating consumers

**Measured.** Both providers use `sub_mode: hashed_user_id`, so `sub` is an
opaque hash and is **not** the LDAP `uid`.

**Why it matters.** It is correct for azb-AD's own frontend and it is a
defensible default. But any RP that correlates the OIDC identity with a
directory account on `sub` will mint a second, differently-named account —
which for VM7 would have meant shares addressed to an account the user cannot
see. VM7 avoided it by mapping on `preferred_username` and disabling the RP's
own unique-ID hashing. Nothing in azb-AD's documentation warns about this.

**Direction.** Document it in the §08 gotchas table, where the other Authentik
traps already live, and consider making `sub_mode` a per-relying-party field of
the record proposed in **G1**.

### G7 — The federated identity path is untested end to end

**Measured indirectly.** `preferred_username == uid` held for every federated
user tested. No test in azb-AD pins it — and, more than that, **no test fixture
in azb-AD produces a federated user at all.** `authentik_user_factory`
(`tests/conftest.py:272`) creates users directly in Authentik through the Admin
API, and every auth-bearing test depends on it: `test_oidc_claims.py`,
`test_xmpp_e2e.py`, `non_admin_client`. Production identity is LDAP-federated
under ARD-007. The suite exercises the identity class production does not use
and never exercises the one it does.

**Why it matters.** It is C1 above — the single property the whole integration
rests on. A user created directly in Authentik rather than federated from LDAP
would have a `preferred_username` owing nothing to the directory, and would
resolve onto the wrong account or none. The failure surfaces in the consumer,
not here.

This also settles the open question the entry originally raised — whether
Authentik-local users are permitted at all. They are not merely permitted; the
test harness depends on them, so forbidding them is not an available option.

**Direction.** Lift the LDAP-source-sync-forcing pattern from
`tools/dev-seed-uc-user.py:379-393` into a `federated_user` conftest fixture,
then assert `preferred_username == uid` on a token minted for it. Document
Authentik-local users as an explicitly test-only identity class. The fixture
costs a sync round-trip, which is the price of exercising the path production
actually uses.

### G8 — `iss` varies by access URL, and a second consumer makes that operational

**Measured.** `issuer_mode: per_provider`; the discovery document stamps
`issuer: http://192.168.4.111:9000/application/o/nextcloud/` from the URL used
to fetch it. §08 already records this gotcha.

**Why it matters.** It stops being a curiosity once an RP is reached at a
different address than the browser uses — internal service name versus tunnel
hostname. The RP validates `iss` against what it discovered; a mismatch fails
the login with an error that points at the token, not at the URL. VM7 hit the
neighbouring version of this: Nextcloud's SSRF guard refused to fetch discovery
from a private address and reported it as "Could not reach the OpenID Connect
provider", which reads as a network fault rather than a policy refusal.

**Direction.** Pin a canonical public issuer URL for provider configuration and
state in the onboarding docs that RPs must use it for discovery even when they
reach Authentik internally for token exchange.

## 6. Suggested work items

In priority order, revised after the code review in §10.

| ID | Item | Rationale |
|---|---|---|
| 1 | Repair the `memberOf` overlay config; make the LDIF repair rather than silently fail; rewrite existing memberships; assert via an API-created membership | **G4** — populates nothing today, for any membership past or future |
| 2 | Give termination a directory-visible disabled state; make `disable_user()` remove group memberships; re-sync spec §02 | **G5** — a terminated user is a live share target with no expiry |
| 3 | Document `cn` as the display-name attribute in the consumer contract; assert `cn` non-empty; VM7 sets `ldapUserDisplayName=cn` | **G9** — no product-created user is addressable by `displayName` |
| 4 | Provision `cn=nextcloud,ou=clients` and rebind VM7 off the admin DN | **G3** — one API call against machinery that already works |
| 5 | Commit Nextcloud's provisioning into the Authentik seed; issue a scoped token | **G1** — consumer #3 currently starts from nothing |
| 6 | `federated_user` fixture + a `preferred_username == uid` test | **G7** — the identity path production uses is untested |
| 7 | Document `sub_mode` and pin a canonical issuer URL in §08 | **G6**, **G8** |
| 8 | Stop publishing 1637; VM7 relaxes its plaintext guard to off-LAN only | **G2** — downgraded to a papercut |

Items 1 and 2 are the confirmed defects and go first; both were verified on the
running stack. Items 3 and 4 are what actually unblocks a consumer and are
roughly a day between them. Items 5–8 are provisioning, test and documentation
debt that cost each new consumer a day of rediscovery.

The corrected list sharpens the pattern the first version of this report named.
**Every confirmed defect here is a missing or misconfigured attribute producing
a silent wrong answer in a consumer rather than an error in azb-AD** — a
`displayName` that is never written, a `memberOf` overlay bound to an attribute
pair nobody uses, a `preferred_username` invariant asserted only against the
identity class production does not use, and a termination that changes nothing a
consumer can see. In each case azb-AD reports success and the consumer is left
holding a wrong answer. A directory whose consumers key on attributes needs
assertions that those attributes are populated and reachable, not only that the
entries exist.

## 7. Reproduction

The consumer side is committed in the VM7 repo on
`feat/sso-and-self-containment`:

- `deployment/nextcloud-identity/configure.sh` — the one-shot configurator; the
  full `occ` sequence for `user_ldap` and `user_oidc` is readable there and is
  the concrete form of the contract in §3
- `deployment/docker-compose.yml` — the `nextcloud-identity` and `eurooffice`
  services
- `deployment/env.example` — every VM6-facing variable, with the fail-closed
  rules documented

Verification scripts used for this report are throwaway spike tooling and were
deliberately **not** committed: they carry dev credentials read from
`deploy/dev/.env` and `~/nextcloud-oidc-client.json` on `safenest`. They live in
the session scratchpad. The one worth re-creating if this is ever automated is
the editing-path test, for the reason in §8.

## 8. Two traps for whoever automates this

Recorded because both produce tests that pass while proving nothing.

**A reused document defeats the save check.** The Euro-Office connector keys an
editing session off the document. A save callback against a document used by a
previous run returns `{"error":0}` and saves nothing. Any regression test must
create a fresh document per run.

**Byte identity is the wrong assertion for a save.** Nextcloud re-encodes the
`.docx` container on save — 929 bytes in, 1250 out, zip entries reordered —
while the content round-trips exactly. Assert on content, with a marker unique
to the run. An earlier version of our test asserted on text that also existed in
another fixture, and reported a pass on a run that had saved nothing.

## 9. What is not covered

- **No browser has loaded the editor UI.** Both server-to-server legs (document
  fetch and save callback) were driven and pass; the JavaScript bundle and
  WebView behaviour are unobserved. Not an azb-AD concern, listed for honesty.
- **No production-shaped run.** Everything here ran over plaintext HTTP with
  `allow_insecure_http` and `allow_local_remote_servers` enabled on the RP.
  See **G2**.
- **Authentik-local (non-federated) users were not tested.** See **G7**.

## 10. Corrections after code review

The measurements in §4 stand unchanged, as do the pass verdicts in §1. What
follows are the *causes* inferred from those measurements in §3, §5 and §6 that
a subsequent code review overturned — recorded so the reasoning trail survives
rather than being quietly rewritten. Evidence for each is in the rewritten
entry.

| Entry | Originally claimed | What disproved it | Net effect |
|---|---|---|---|
| **G9** | Six users lack `displayName` because the UC and QA creation paths disagree with the seeded-user path; fix by making the attribute mandatory everywhere and backfilling six | `create_user()` writes no `displayName` on any path; `update_user()` maps the API field onto `cn`; every read reconstructs it from `cn`. The only writer is the dev demo seed | **Worse.** Not 6 of 60 but every product-created user — all of them, in a production deployment. The fix inverts to the consumer mapping to `cn`, which the original dismissed as "the weaker fix" |
| **G4** | The overlay is loaded but never backfilled the entries that predate it | The live overlay is bound to `groupOfUniqueNames`/`uniqueMember` while azb-AD writes `groupOfNames`/`member`. A membership created through the API seconds earlier produced no `memberOf` | **Worse.** It populates nothing, past or future, and the proposed backfill would have gone stale on the next group add |
| **G5** | Revocation does not reach an RP's own session; `access_token_validity` is 8h | `disable_user()` changes only `userPassword` and `description`, so the entry still matches any user filter and the account stays enabled in an LDAP-backed consumer indefinitely. Spec §02:289's `[AS-BUILT]` claim that it "removes from all groups" is not implemented | **Wider.** The 8h session was the smaller leg; the directory leg is unbounded and is also the cheaper fix |
| **G7** | The invariant is unasserted; the test shape already exists in `test_oidc_claims.py` | No fixture in the suite produces a federated user — `authentik_user_factory` creates Authentik-local users, and every auth-bearing test uses it | **Wider.** Not one missing assertion but an untested identity path; also settles the entry's own open question, since the harness depends on Authentik-local users |
| **G3** | No read-minus-secrets client exists, and the ACL needs confirming for `member` reads on `ou=groups` | The ACL is live on the running directory and rule `{3}` already grants exactly that to `ou=clients` children | **Downgraded.** The mechanism exists and works; the endpoint was simply never called |
| **G2** | `LDAP_TLS=false` makes the production-shaped configuration untestable anywhere | Plaintext on the LAN is the ratified posture (`docker-compose.tls.yml`), with TLS an opt-in edge concern; spec §07 requires no LDAPS. VM7's configurator enforces a rule azb-AD never adopted | **Downgraded** to a papercut, plus a consumer-side fix |

**G1** was rescoped rather than corrected: the finding stands, but the near-term
response is smaller than the ARD-006 mirror originally proposed. **G6** and
**G8** are unchanged.

The four errors that made a finding look *smaller* than it is share a shape
worth naming, because it is the same trap the report warns about in §8. Each
read a symptom off the running dev stack and inferred the cause without checking
what the code writes. The dev stack carries a demo seed and a first-boot
bootstrap sequence, and **both diverge from what the product does** — the seed
writes attributes no product path writes, and the bootstrap silently failed to
apply an overlay's configuration. So an observation of the dev directory is
evidence about the fixture at least as much as about azb-AD, and a gap report
that keys on directory state has to close the loop against the creation path
before it names a cause.
