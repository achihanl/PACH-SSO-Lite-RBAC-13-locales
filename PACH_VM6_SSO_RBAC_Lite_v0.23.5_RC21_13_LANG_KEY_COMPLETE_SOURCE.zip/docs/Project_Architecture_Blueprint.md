---
title: AZBlink Directory — Architecture Blueprint
description: Point-in-time architecture and platform-maturity snapshot (2026-03-17, v0.3.0), superseded by docs/architecture/ as source of truth
type: overview
product: azblink-directory
status: superseded
updated: 2026-08-08
---

# AZBlink Directory — Architecture Blueprint

**Generated:** 2026-03-17 | **Platform Version:** 0.3.0 | **Architecture Spec:** 1.0.0

---

## 1. Executive Summary — Where We Are

AZBlink Directory is an **LDAP-backed identity directory** with QR-based provisioning and optional Authentik SSO integration. It's a single-tenant IT admin platform for managing users, organizations, groups, and UC (Unified Communications) provisioning — designed so that XMPP/SIP services keep working even when Authentik is down.

### Platform Maturity Scorecard

| Dimension | Status | Maturity |
|-----------|--------|----------|
| **Core Identity CRUD** (users, orgs, groups) | Fully functional | Production-ready |
| **UC Provisioning** (XMPP/SIP via LDAP) | Fully functional | Production-ready |
| **QR Code System** (signing, tokens, preview) | Fully functional | Production-ready |
| **Authentication** (Authentik OIDC) | Fully functional | Production-ready |
| **Admin UI** (React SPA) | Fully functional | Production-ready |
| **Audit Trail** (lifecycle, QR, termination, auth) | Functional | Production-ready |
| **Design System** (@azblink/ui) | 33 primitives | Mature |
| **Test Suite** | 47 files, ~8,900 lines | Good coverage |
| **v2.0 Spec Compliance** | **~58% complete** | Mid-development |
| **Production Hardening** | Dev environment only | Pre-production |

### Key Numbers

| Metric | Value |
|--------|-------|
| Backend modules | 14 Python files (9,654 lines) |
| API endpoints | ~76 routes in `main.py` (14 categories) |
| Frontend files | 231 TypeScript/TSX files |
| UI primitives | 33 in `@azblink/ui` |
| Feature domains | 10 feature component directories (~140 files) |
| Query hooks | 24 TanStack Query files |
| Test files | 47 (8,878 lines, ~305 tests) |
| PostgreSQL tables | 17 (defined via SQLAlchemy Core) |
| Migrations | 004–023 (21 migration files) |
| Docker services | 11 (app stack + Authentik stack) |
| Git commits | 484 across 20 branches |
| Closed PRs | 77 |
| Open issues/PRs | 0 |

---

## 2. Architecture Overview

### 2.1 Design Invariants (Non-Negotiable)

1. **UC works without Authentik** — XMPP/SIP auth is LDAP bind (Plane A), completely independent of OIDC (Plane B)
2. **UC works when Authentik is down** — admin UI login breaks, but all UC services continue
3. **Single LDAP** — one LDAP holds identity (`inetOrgPerson`) + UC attrs (`posixAccount` + `AsteriskPjsip*`) on the same DN
4. **Synchronous provisioning** — UC attributes written atomically via LDAP MODIFY_ADD, no async queue
5. **Two authentication planes** — Plane A (LDAP bind for UC clients) + Plane B (Authentik OIDC for web admin)
6. **Graceful degradation** — SSO failure ≠ UC failure

### 2.2 Architectural Decisions (ARDs)

| ARD | Decision | Date | Impact |
|-----|----------|------|--------|
| ARD-001 | Single-LDAP architecture (replaces two-LDAP) | 2026-03-02 | Eliminated UED sync microservice, removed eventual consistency |
| ARD-002 | Authentik-only OIDC (replaces LDAP JWT + breakglass) | 2026-03-04 | Simplified auth, added dev bypass token |
| ARD-003 | Authentik dev stack integration | 2026-03-04 | Full SSO development environment with seeded IdP |

### 2.3 Component Dependency Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│                        Admin Browser                             │
│                   (React 19 + TanStack Router)                   │
└──────────────────┬───────────────────────────────────────────────┘
                   │ HTTPS (Traefik :8081)
                   ├─── PathPrefix(/api) ──────────────────┐
                   │                                       ▼
                   │                          ┌─────────────────────┐
                   │                          │    FastAPI Backend   │
                   │                          │   main.py (82 eps)  │
                   │                          │                     │
                   │                          │  ┌───────────────┐  │
                   │                          │  │ oidc_verify.py │──┼───► Authentik (JWKS)
                   │                          │  └───────────────┘  │
                   │                          │  ┌───────────────┐  │
                   │                          │  │ ldap_client.py │──┼───► OpenLDAP
                   │                          │  └───────────────┘  │
                   │                          │  ┌───────────────┐  │
                   │                          │  │   orgdb.py     │──┼───► PostgreSQL
                   │                          │  └───────────────┘  │
                   │                          │  ┌───────────────┐  │
                   │                          │  │ rate_limit.py  │──┼───► Redis
                   │                          │  └───────────────┘  │
                   │                          │  ┌───────────────┐  │
                   │                          │  │authentik_cli.py│──┼───► Authentik Admin API
                   │                          │  └───────────────┘  │
                   │                          └─────────────────────┘
                   │
                   └─── PathPrefix(/) ─► Vite Dev Server (React SPA)

┌─────────────────────────────────────────────────────────────────┐
│                     UC Client Apps                               │
│              (XMPP: Prosody/ejabberd, SIP: Asterisk)            │
└──────────────────┬──────────────────────────────────────────────┘
                   │ LDAP bind (port 389/636) — Plane A
                   ▼
              ┌──────────┐
              │ OpenLDAP │ (identity + UC attrs on same DN)
              └──────────┘
```

---

## 3. Backend Architecture

### 3.1 Module Map

| Module | Lines | Responsibility | Dependencies |
|--------|------:|----------------|--------------|
| `main.py` | 4,368 | 82 API routes, 38 Pydantic models, auth middleware, QR generation, CSV import | All modules |
| `orgdb.py` | 3,005 | 63 PostgreSQL methods (profiles, tokens, audit, config templates, settings, preview links) | config |
| `ldap_client.py` | 1,079 | LDAP CRUD (users, orgs, groups), UC attribute builder, SSHA password hashing | config |
| `rate_limit.py` | 189 | Redis-backed rate limiting via slowapi | config |
| `settingsdb.py` | 185 | Key-value settings store with typed serialization | config |
| `authentik_client.py` | 150 | Authentik Admin API v3 — session/token revocation (fire-and-forget) | config |
| `config.py` | 146 | Environment variable loading (33 constants) | — |
| `uc_validation.py` | 124 | UC input validation rules | — |
| `oidc_verify.py` | 108 | OIDC JWT verification, JWKS client, multi-issuer validation | config |
| `activity_bus.py` | 85 | WebSocket/SSE event bus | — |
| `qr_signing.py` | 82 | HMAC-SHA256 signing/verification for QR payloads | config |
| `uc_client.py` | 66 | UC service client stub | config |
| `provisioning.py` | 65 | UID number + SIP extension allocation, SIP password generation | orgdb |
| `_version.py` | 2 | Platform version (0.3.0) | — |

### 3.2 API Endpoint Categories

| Domain | Endpoint Count | Key Routes |
|--------|---------------:|------------|
| Users | ~15 | CRUD, terminate, suspend, password reset, move, import CSV |
| Organizations | ~6 | Tree, create, rename, delete, users list |
| Groups | ~7 | CRUD, member add/remove, roles |
| QR Codes | ~8 | Generate, revoke, preview, share, extend, history |
| Provisioning | ~5 | Consume token, device provisioning, config templates |
| Audit | ~5 | QR issuance, lifecycle, terminations, auth failures |
| Health | 3 | Shallow, deep (LDAP + PG + Redis), version |
| Settings | ~5 | CRUD by section |
| Config Templates | ~8 | CRUD, assign to org, history |
| Dashboard | ~5 | Stats, pending provisions, recent activity |
| Auth/Bootstrap | ~3 | Tenant info, bootstrap |
| WebSocket/SSE | 2 | Real-time event streams |
| **Total** | **~82** | |

### 3.3 Architectural Pattern

**Single-file orchestrator:** `main.py` is the sole FastAPI entry point. Route handlers are thin — they validate input (Pydantic), delegate to specialized modules, and format responses. No ORM models; SQLAlchemy Core only. Auth via dependency injection (`Depends(require_user)`).

**Key design choices:**
- No ORM models — `orgdb.py` uses `sqlalchemy.Table` + raw SQL expressions
- Fire-and-forget for non-critical operations (Authentik session revocation)
- LDAP as source of truth for user existence; PostgreSQL for audit/config/tokens
- No cross-store foreign keys — consistency via application logic

---

## 4. Frontend Architecture

### 4.1 Technology Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Build | Vite 6 | Dev server + production bundler |
| Framework | React 19 | Component rendering |
| Routing | TanStack Router (file-based) | URL routing |
| Data | TanStack Query (24 query files) | Server state management |
| Client State | Zustand (2 stores) | Auth + UI state |
| Design System | @azblink/ui (30 primitives) | Domain-agnostic atoms |
| Styling Layer 1 | CSS Modules + design tokens | Primitives |
| Styling Layer 2 | Tailwind CSS 4 | Feature components |

### 4.2 Two-Layer Component Architecture

**Layer 1 — Primitives (`@azblink/ui`)**
- 30 components: AlertDialog, Badge, Button, Card, Checkbox, CodeBlock, CollapsibleSection, ContentArea, DataTable, DetailGrid, Dialog, FieldCard, InfoField, Input, Label, ListPanel, Menu, Pagination, RadioGroup, Select, Skeleton, Stepper, Table, Tabs, Textarea, Toggle, ToggleCard, ToggleChipGroup, ToggleRow, Tooltip
- Built on @base-ui/react (headless), CSS Modules exclusively, design tokens from `tokens.css`
- `data-slot` attribute pattern, `cn()` merge utility, `ComponentProps<'div'>` typing

**Layer 2 — Feature Components (9 domains)**
- `user-management/` — detail panel, cards, forms, password reset
- `group-management/` — detail, member management, permissions
- `org-management/` — org tree, detail, forms
- `org-profiles/` — profile editor, UC config forms
- `qr-management/` — QR code list, revocation, extension, stats
- `qr-preview/` — public shareable QR preview page
- `provisioning-ops/` — provisioning wizard, device list
- `audit-management/` — audit log tables, filters
- `settings/` — application settings, API keys

### 4.3 Route Structure

| Route Group | Path | Purpose | Auth |
|-------------|------|---------|------|
| directory/ | `/directory/users`, `/groups`, `/orgs` | Core directory management | Required |
| provisioning/ | `/provisioning` | Provisioning operations | Required |
| configuration/ | `/configuration/profiles`, `/templates` | Profile management | Required |
| audit-log/ | `/audit-log` | Audit trail | Required |
| settings | `/settings` | Application settings | Required |
| my-profile | `/my-profile` | Admin's own profile | Required |
| auth/ | `/auth/callback` | OIDC callback handler | Public |
| qr/ | `/qr/:token` | Public QR preview | Public |
| login | `/login` | Login page | Public |

### 4.4 State Management

- **`auth-store.ts`** (Zustand) — OIDC tokens, user claims, admin group membership, login/logout, token refresh
- **`ui-store.ts`** (Zustand) — modal visibility, notification queue, sidebar state, selected items
- **TanStack Query** — all server state, 24 query hook files by domain

---

## 5. Data Architecture

### 5.1 Dual Storage Model

| Store | Owns | Access |
|-------|------|--------|
| **OpenLDAP** | Identity (users, orgs, groups), UC attributes (SIP/XMPP), passwords | `ldap_client.py` via ldap3 |
| **PostgreSQL** | Config templates, audit trails, provisioning tokens, QR preview links, settings, API keys, group profiles | `orgdb.py` via SQLAlchemy Core |
| **Redis** | Rate limit counters (ephemeral) | `rate_limit.py` via slowapi |
| **Authentik** | OIDC sessions/tokens (managed externally) | `authentik_client.py` via Admin API v3 |

### 5.2 PostgreSQL Tables (13 total)

| Table | Purpose | Access Pattern |
|-------|---------|----------------|
| `config_templates` | Profile templates with UC toggles and allocation counters | CRUD |
| `config_template_assignments` | Profile → org DN links | CRUD |
| `config_template_history` | Profile change audit trail | Append-only |
| `provision_tokens` | QR token lifecycle (active → consumed/revoked) | Issue/consume/revoke |
| `qr_issuance_audit` | QR code issuance log | Append-only |
| `qr_issues` | QR issue records | Issue/revoke |
| `qr_preview_links` | Shareable QR preview tokens | Create/access-count/expire |
| `user_lifecycle_audit` | User lifecycle events | Append-only |
| `termination_events` | Detailed termination records | Append-only |
| `auth_failure_audit` | Authentication failure log | Append-only |
| `group_profiles` | Group metadata (type, permissions) | CRUD |
| `group_member_roles` | Per-member role assignments | CRUD |
| `app_settings` | Application key-value config | CRUD |
| `api_keys` | API key management | Create/revoke |

### 5.3 LDAP Structure

```
dc=azblink,dc=com
  ├── ou=org          (org hierarchy metadata)
  │     ├── ou=Engineering
  │     └── ou=Sales
  ├── ou=people       (user entries: inetOrgPerson + posixAccount + AsteriskPjsip*)
  │     ├── ou=Engineering
  │     │     └── uid=alice
  │     └── ou=Sales
  │           └── uid=bob
  └── ou=groups       (groupOfNames entries)
        ├── ou=Engineering
        │     └── cn=DevOps
        └── ou=Sales
              └── cn=Managers
```

---

## 6. Authentication Architecture

### 6.1 Dual Auth Planes

| Plane | Purpose | Mechanism | Depends On |
|-------|---------|-----------|------------|
| **A — UC Auth** | XMPP/SIP client login | Direct LDAP bind | OpenLDAP only |
| **B — Web Admin** | Admin UI login | Authentik OIDC (PKCE S256) | Authentik + OpenLDAP |

**Critical:** Plane A has zero dependency on Authentik. UC works when Authentik is down.

### 6.2 OIDC Flow (Plane B)

1. Admin opens web UI → redirected to Authentik OIDC (PKCE S256)
2. Authentik authenticates against LDAP federation
3. Access token returned → stored in `auth-store` (Zustand)
4. All API calls include `Bearer` token
5. Backend validates via `oidc_verify.py` (JWKS, multi-issuer: Docker-internal + Cloudflare tunnel)
6. Claims extracted for RBAC

**Dev/test bypass:** `DEV_AUTH_TOKEN=dev-test-token` skips OIDC, returns synthetic admin claims.

---

## 7. Infrastructure

### 7.1 Docker Compose Services (11 total)

| Service | Image | Role |
|---------|-------|------|
| `postgres` | postgres:16 | Application database |
| `redis` | redis:8-alpine | Rate limiting, Authentik cache |
| `openldap` | osixia/openldap:1.5.0 | Identity + UC directory |
| `directory-api` | Custom (Dockerfile.api) | FastAPI backend (uvicorn, hot reload) |
| `directory-ui` | Custom (Dockerfile.ui-dev) | Vite dev server (HMR) |
| `traefik` | traefik:v3.7 | Reverse proxy (path-based routing) |
| `seed` | Custom (Dockerfile.seed) | LDAP bootstrap (demo data) |
| `authentik-postgres` | postgres:16-alpine | Authentik-dedicated database |
| `authentik-server` | ghcr.io/goauthentik/server:2026.5 | OIDC provider + admin UI |
| `authentik-worker` | ghcr.io/goauthentik/server:2026.5 | Background tasks |
| `authentik-seed` | python:3.13-slim | One-shot Authentik setup |

### 7.2 Network Topology

- `azblink-net` (bridge) — all 11 services
- `cloudflare-tunnel` (external) — Traefik + authentik-server
- Traefik:8081 → `/api` → directory-api:8000, `/` → directory-ui:5173

### 7.3 Tooling

- **`just`** (Justfile) — all dev commands (up, down, test, logs, health, release)
- **Commitizen** — conventional commits + version bumping
- **6 persistent Docker volumes** — pg_data, redis_data, ldap_data, ldap_config, avatar_cache, authentik_pg_data

---

## 8. Testing Architecture

### 8.1 Test Profile

| Metric | Value |
|--------|-------|
| Test files | 45 |
| Total test lines | ~8,878 |
| Test runner | pytest |
| Test target | Real Docker stack (no mocks) |
| Auth bypass | `DEV_AUTH_TOKEN` fixture |

### 8.2 Test Domains

| Domain | Files | Key Coverage |
|--------|------:|--------------|
| QR/Provisioning | 12 | QR signing, flow, format, preview, consume, revoke |
| Users | 3 | CRUD, lifecycle, device provisioning |
| Organizations | 2 | Org tree, profile CRUD |
| Groups | 2 | Group CRUD, member management |
| Config Templates | 2 | Template CRUD, assignments |
| Security | 2 | Rate limiting, auth failures |
| Dashboard | 1 | Dashboard API endpoints |
| E2E | 2 | XMPP e2e, SSO device provisioning |
| Settings | 1 | App settings |
| Admin | 1 | Admin operations |
| Other | 17+ | Various integration tests |

### 8.3 Test Quality Notes

- **Strength:** Integration tests run against real Docker stack — catches real bugs
- **Strength:** Good QR/provisioning coverage (12 test files)
- **Strength:** Security coverage: rate limiting, IP blocking, account locks, RBAC, LDAP injection tests
- **Available but unused:** Vitest 4.0.18 + Playwright 1.48.0 configured in package.json but no test files written yet
- **Gap:** No frontend test files written (tooling is ready, coverage is zero)
- **Gap:** Some test shadowing issues discovered during FIRA audit (duplicate function names)

---

## 9. Release History & Velocity

### 9.1 Releases

| Version | Date | Key Changes |
|---------|------|-------------|
| **v0.3.0** | 2026-03-13 | Authentik branding, SSO e2e tests, dead code cleanup (10 items), QR subsystem cleanup |
| **v0.2.0** | 2026-03-11 | Dashboard phases 1-4, FIRA audit remediation, settings UI, design system migration, single-LDAP migration, Authentik-only auth |

### 9.2 Recent Development Activity (Last 30 Commits)

- Dead code cleanup (L1-L5 audit, 10 items removed)
- QR subsystem cleanup (dead components, phantom endpoints, type consolidation)
- Authentik UI branding (glassmorphic login, custom CSS)
- SSO device provisioning e2e tests
- Dashboard phase 4 reconciliation
- FIRA audit remediation (10 findings)
- Runtime bug fixes
- Design system migration

---

## 10. Gap Analysis — v1.0 Implementation vs v2.0 Spec

The gap analysis (dated 2026-01-25, updated through development) shows **~58% overall v2.0 compliance**.

### 10.1 What's Done (Strong Areas)

| Area | Coverage | Key Items |
|------|----------|-----------|
| Health & Bootstrap API | 100% | All endpoints match spec |
| OrgProfile CRUD | 100% | Full profile management |
| Rate Limiting | ~85% | All standard limits in place |
| QR Signing (HMAC-SHA256) | 100% | Canonical JSON, constant-time verify |
| Token Lifecycle | ~80% | Issue/consume/revoke |
| User CRUD | ~80% | Create, update, suspend, terminate |
| Audit Trail | ~70% | 4 audit tables operational |
| Groups | ~75% | CRUD, members, roles |

### 10.2 What's Missing (Gap Summary — Updated from Agent Audit)

Several items from the original gap analysis (dated 2026-01-25) have since been **implemented**. Updated status:

| Gap Area | Original Gap | Current Gap | Newly Implemented Since Gap Analysis |
|----------|-------------|-------------|--------------------------------------|
| **Security** | 30% | **~10%** | Account soft-lock (`account_locks` table, migration 020), IP blocking (`blocked_ips` table, migration 021) |
| **API Endpoints** | 25% | **~10%** | `/me` self-service (5 endpoints), user search, user export, group detail/update |
| **Database Schema** | 65% | **~45%** | `suspension_events` (019), `account_locks` (020), `admin_action_audit` (020b), `blocked_ips` (021), `device_provisioning` (022) |
| **Audit & Compliance** | 50% | **~25%** | `admin_action_audit` table + middleware, suspension events tracking |
| **LDAP Custom Schema** | 80% | **80%** | Not started — still using standard objectClasses |
| **QR Provisioning Schema** | 40% | **~15%** | Upgraded to `azblink.provisioning.v2` schema, unified endpoint |
| **User Lifecycle** | 20% | **~10%** | Suspension events tracking, improved termination flow |

**Estimated overall v2.0 compliance: ~70%** (up from ~58% at gap analysis baseline)

### 10.3 Remaining Priority Items

**P0 — Critical (Must Have for Production):**
- `users` shadow table in PostgreSQL (enables fast queries, full-text search, FK relationships)
- LDAP replication for HA
- CI/CD pipeline

**P1 — Core Functionality:**
- Custom LDAP schema (`azblinkUser` objectClass, `azblinkStatus` attr)
- LDAP overlays (ppolicy, memberof, refint)
- Table partitioning for audit tables
- Frontend test infrastructure

**P2 — Operations & Polish:**
- Connection pooling config
- Extended CLI commands (`directoryctl`)
- Webhook support
- `main.py` route decomposition (4,368 lines → route modules)

---

## 11. Strengths Assessment

1. **Clean architectural foundations** — Single-LDAP, dual auth planes, synchronous provisioning are well-reasoned and documented via ARDs
2. **Comprehensive architecture spec** — 8 sections, versioned, with SOP for changes
3. **Strong QR/provisioning system** — HMAC-SHA256 signing, one-time tokens, preview links, audit trail
4. **Real integration tests** — 45 test files running against actual Docker stack
5. **Well-designed UI** — two-layer component system, 30 primitives, clear design tokens
6. **Good dev tooling** — `just` commands, hot reload, seed scripts, Commitizen releases
7. **Clean codebase** — recent dead code cleanup removed 10+ items
8. **Authentik integration** — full OIDC flow, dev stack with seeding, custom branding

---

## 12. Risks & Technical Debt

### 12.1 Architectural Risks

| Risk | Severity | Detail |
|------|----------|--------|
| **`main.py` is 4,368 lines** | Medium | Single-file orchestrator with 82 routes — increasingly hard to navigate. No urgent issue but approaching the threshold where refactoring into route modules would pay off. |
| **No frontend tests written** | Medium | Vitest + Playwright are configured but zero test files exist — all QA is backend integration tests. Frontend regressions caught manually only. |
| **No production deployment config** | High | Only dev Docker Compose exists. No Kubernetes, no Terraform, no CI/CD pipeline. |
| **No `users` shadow table** | Medium | All user queries hit LDAP — slow for large directories, can't do full-text search or complex SQL joins against user data. |
| **LDAP is single point of failure** | Medium | No replication configured in dev stack. Production needs LDAP replication for HA. |
| **`orgdb.py` is 3,005 lines** | Low-Medium | God class with 63 methods — covers profiles, tokens, audit, config, settings, preview links. Could benefit from decomposition. |

### 12.2 Technical Debt

| Item | Priority | Impact |
|------|----------|--------|
| `main.py` route extraction | P2 | Maintainability |
| `orgdb.py` decomposition | P3 | Maintainability |
| Frontend test files (Vitest + Playwright ready) | P1 | Quality |
| Production deployment (K8s/Terraform) | P0 | Operability |
| CI/CD pipeline | P1 | Reliability |
| LDAP replication | P1 | Availability |
| Database connection pooling | P2 | Performance |
| Table partitioning for audit | P3 | Performance at scale |

---

## 13. Forward Path — Where We Can Go

### 13.1 Option A: v2.0 Spec Completion (Close the Gap)

**Goal:** Reach ~95% v2.0 spec compliance
**Effort:** ~4-6 weeks
**Focus:** Complete the gap analysis items

| Wave | Items | Effort |
|------|-------|--------|
| Wave 1 | Account soft-lock, IP blocking, `users` shadow table | 1 week |
| Wave 2 | `/me` self-service endpoints, full-text search, user export | 1 week |
| Wave 3 | Custom LDAP schema, LDAP overlays (ppolicy, memberof) | 1 week |
| Wave 4 | Table partitioning, missing audit tables, ENUM types | 1 week |
| Wave 5 | CLI extension, webhook support, QR v2 schema finalization | 1-2 weeks |

**Trade-off:** Completes the spec but doesn't address production readiness.

### 13.2 Option B: Production Readiness (Ship It)

**Goal:** Make the platform deployable and reliable for real users
**Effort:** ~3-4 weeks
**Focus:** Infrastructure, testing, monitoring

| Wave | Items | Effort |
|------|-------|--------|
| Wave 1 | CI/CD pipeline (GitHub Actions), production Docker Compose / K8s | 1 week |
| Wave 2 | Frontend test infrastructure (Vitest + Playwright), critical path tests | 1 week |
| Wave 3 | LDAP replication, PostgreSQL backups, monitoring (health dashboard) | 1 week |
| Wave 4 | Production secrets management, TLS configuration, rate limiting tuning | 1 week |

**Trade-off:** Doesn't add features, but makes what exists reliable and shippable.

### 13.3 Option C: Hybrid (Prioritized Mix)

**Goal:** Balance between spec completion and production readiness
**Effort:** ~5-6 weeks
**Focus:** High-impact gaps + critical infrastructure

| Wave | Items | Category |
|------|-------|----------|
| Wave 1 | CI/CD pipeline, frontend test infrastructure | Production |
| Wave 2 | Account soft-lock, IP blocking, `users` shadow table | Security |
| Wave 3 | `/me` endpoints, full-text search | Feature |
| Wave 4 | Production deployment config, LDAP replication | Infrastructure |
| Wave 5 | Table partitioning, custom LDAP schema | Polish |

**Trade-off:** Slower on both fronts, but balances risk.

### 13.4 Option D: Refactor First (Technical Debt)

**Goal:** Clean up before building more
**Effort:** ~2-3 weeks
**Focus:** `main.py` decomposition, `orgdb.py` split, frontend tests

| Wave | Items | Effort |
|------|-------|--------|
| Wave 1 | Extract `main.py` into route modules (users, orgs, groups, qr, audit, etc.) | 1 week |
| Wave 2 | Split `orgdb.py` into domain-specific DB modules | 1 week |
| Wave 3 | Frontend test infrastructure + initial test coverage | 1 week |

**Trade-off:** No new features or production capability, but makes future work significantly faster.

---

## 14. Recommendation

Based on the current state:

**Start with Option C (Hybrid) but lead with CI/CD + security hardening.**

Rationale:
- The core platform works well — 82 endpoints, good test coverage, clean architecture
- The biggest risk is **no CI/CD and no production deployment** — one bad push could break everything
- **Security gaps** (account soft-lock, IP blocking) are the most spec-critical items for any production deployment
- **Frontend testing** is a growing risk as the UI complexity increases
- The `main.py` refactor (Option D) would help but isn't blocking anything yet

**Suggested first 3 moves:**
1. CI/CD pipeline with `just test` in GitHub Actions (1-2 days)
2. Account soft-lock + IP-based blocking (2-3 days)
3. Frontend test infrastructure with Vitest (2-3 days)

---

*This blueprint reflects the codebase as of v0.3.0 (2026-03-13). Architecture spec version 1.0.0. Gap analysis baseline at ~58% v2.0 compliance.*
