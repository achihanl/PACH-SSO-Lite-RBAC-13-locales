# Provisioning Device Management — Frontend Design Spec

**Date:** 2026-03-18
**Status:** Draft
**Scope:** Frontend page replacing deprecated QR provisioning UI with SSO-era device management

## Problem

The `/provisioning/tokens` route is a placeholder stub that says "Device provisioning is now handled through Authentik SSO." The backend endpoints for device listing, compliance alerts, bulk token operations, and device history are fully built. The frontend has query hooks and TypeScript types ready (`provisioning-ops.ts`). There is no admin UI to:

- View all provisioned devices across users
- Monitor compliance anomalies (expired-unused, cross-user-device, multi-issue)
- Revoke or extend device tokens
- Inspect per-device provisioning history

## Design Decisions

- **Route rename:** `/provisioning/tokens` → `/provisioning/devices` — clean break from QR-era "tokens" language
- **Two-tab layout (Devices | Compliance):** Drop `lifecycle` from `OpsTab` — redundant with audit log's provisioning category
- **Split-panel on Devices tab:** Follows User Management and Audit Log pattern — `ListPanel` left, detail panel right
- **No new primitives:** Uses existing `@azblink/ui` components exclusively — `ListPanel`, `Tabs`, `StatusBadge`, `DetailGrid`, `FieldCard`, `Pagination`, `Badge`, `CollapsibleSection`, `AlertDialog`, `CodeBlock`, `Select`, `Button`, `Skeleton`, `Tooltip`
- **URL-driven state:** All filter/selection state in search params — back button, deep-linking, share URLs all work
- **No hardcoded styles:** All colors via CSS custom properties (`--color-*`), all spacing via Tailwind scale, all typography via design tokens (`--text-*`)

## Route & Navigation

### Route File

**Delete:** `src/frontend/src/routes/provisioning/tokens.tsx`
**Create:** `src/frontend/src/routes/provisioning/devices.tsx`

```ts
// Search param validation
validateSearch: (search) => ({
  tab: (search.tab === 'compliance' ? 'compliance' : 'devices') as OpsTab,
  deviceId: typeof search.deviceId === 'string' ? search.deviceId : undefined,
  platform: typeof search.platform === 'string' ? search.platform : undefined,
  dateRange: ['7d', '30d', '90d', 'all'].includes(search.dateRange)
    ? search.dateRange : '30d',
  search: typeof search.search === 'string' ? search.search : undefined,
  page: Number(search.page) || 1,
  pageSize: [10, 25, 50].includes(Number(search.pageSize))
    ? Number(search.pageSize) : 25,
  alertType: typeof search.alertType === 'string' ? search.alertType : undefined,
})
```

### Sidebar Update

In `src/frontend/src/components/layout/sidebar.tsx`:
- `href: '/provisioning/tokens'` → `href: '/provisioning/devices'`
- `label: 'Provisioning Ops'` → `label: 'Device Management'`
- Compliance alert dot: update `item.href` check to `/provisioning/devices`

### Type Update

In `src/frontend/src/types/provisioning-ops.ts`:
- `OpsTab = 'devices' | 'compliance'` (remove `'lifecycle'`)
- Rename `ProvisioningOpsSearchParams` → `ProvisioningDevicesSearchParams`
- Remove `tokenHash` field (actions use device selection, not direct token hash)
- Add `platform?: string` field (new filter, not in original type)

## Component Architecture

### File Structure

```
src/frontend/src/components/features/provisioning-management/
├── ProvisioningDevicesPage.tsx    # Page orchestrator: URL state + tab switching
├── PageHeader.tsx                 # Icon + title + subtitle + search
├── DeviceFilterBar.tsx            # Platform chips + date range select
├── DeviceList.tsx                 # ListPanel with rows + pagination + bulk select
├── DeviceRow.tsx                  # Grid row: device, user, platform, status, date
├── DeviceDetailPanel.tsx          # Detail panel: Overview | History sub-tabs + actions
├── ComplianceTab.tsx              # Alert dashboard orchestrator
├── ComplianceSummaryCards.tsx     # Stat card row (one per alert type)
└── ComplianceAlertRow.tsx         # Alert row with severity badge + expandable evidence
```

### Component Tree

```
<ContentArea className="gap-4">
  <PageHeader />
  <Tabs value={tab} onValueChange={setTab}>
    <TabsList variant="pill">
      <TabsTrigger value="devices">Devices</TabsTrigger>
      <TabsTrigger value="compliance" count={alertCount} countVariant="warning">
        Compliance
      </TabsTrigger>
    </TabsList>
    <TabsContent value="devices">
      <DeviceFilterBar />
      <div className="flex gap-6 flex-1 min-h-0">
        <div className="flex-1 min-w-0">
          <Suspense fallback={<Skeleton />}>
            <DeviceList />
          </Suspense>
        </div>
        <div className="hidden lg:flex w-[380px]">
          <Suspense>
            <DeviceDetailPanel />
          </Suspense>
        </div>
      </div>
    </TabsContent>
    <TabsContent value="compliance">
      <ComplianceTab />
    </TabsContent>
  </Tabs>
</ContentArea>
```

## Devices Tab

### PageHeader

Follows Audit Log's `PageHeader` pattern:
- Left: rounded icon container with brand tint + "Device Management" title + "Manage provisioned devices and compliance alerts" subtitle
- Right: search input with `Cmd+K` shortcut + bulk actions dropdown (visible when rows selected)

Icon: `Smartphone` from lucide-react, tinted with `bg-[var(--color-primary)]/10` container and `text-[var(--color-primary)]`.

### DeviceFilterBar

Horizontal bar below page tabs, above the split panel:
- Platform filter: styled `<button>` pills with `aria-pressed` (single-select, matching Audit Log's `AuditFilterBar` pattern — NOT `ToggleChipGroup` which is multi-select Set-based): `All | iOS | Android | Desktop`
- `Select` for date range: `Last 7 days | Last 30 days | Last 90 days | All time` (default: 30d)
- Responsive: pills wrap on small screens

All filter changes update URL search params via `navigate({ search: ... })`.

### DeviceList

Uses `ListPanel` compound component:

```
ListPanel
├── ListPanelHeader
│     title="Devices"
│     count={total}
│     countLabel="devices"
│     children={bulkActionControls}   // "Revoke Selected" button when checkboxes active
├── ListPanelColumns
│     columns={[{ label: 'Device' }, { label: 'User' }, { label: 'Platform' }, { label: 'Status' }, { label: 'Provisioned' }]}
│     className="grid-cols-[1fr_1fr_100px_100px_120px] gap-4 px-5"
├── ListPanelBody
│     {devices.map(d => <DeviceRow key={d.device_id} ... />)}
└── ListPanelFooter
      <Pagination pageIndex={page - 1} pageSize={pageSize} totalCount={total}
        onPageChange={(idx) => updateSearch({ page: idx + 1 })}
        onPageSizeChange={(size) => updateSearch({ pageSize: size, page: 1 })} />
```

Row selection:
- Checkbox column prepended when "select mode" is active
- Selected token hashes tracked in local component state (not URL)
- "Revoke Selected" appears in `ListPanelHeader` children slot

### DeviceRow

Grid row matching `ListPanelColumns` template. Highlights on hover (`bg-[var(--color-bg-hover)]`), selected state indicated by `bg-[var(--color-primary-bg)]`.

| Column | Content | Notes |
|--------|---------|-------|
| Device | `device_id` first 8 chars + `…` in monospace | Full ID in `Tooltip` on hover, click-to-copy |
| User | `user_display_name` primary + `user_uid` muted below | Two-line cell |
| Platform | Lucide icon + label | `Smartphone` (ios/android), `Monitor` (desktop), `HelpCircle` (null) |
| Status | `StatusBadge` | See mapping below |
| Provisioned | Relative time ("3h ago") from `consumed_at` | Full ISO in `title` attribute. Shows "Pending" when `consumed_at` is null |

**Status → StatusBadge mapping** (note: `token_status` is a raw string from the API, must be mapped to valid `StatusBadgeStatus` values):

| `token_status` | StatusBadge `status` | Rationale |
|----------------|---------------------|-----------|
| `"active"` | `"healthy"` | Green dot — device actively provisioned |
| `"consumed"` | `"consumed"` | Blue dot — token consumed, normal lifecycle |
| `"revoked"` | `"error"` | Red dot — admin or user revoked (not a direct StatusBadge value) |
| `"expired"` | `"expired"` | Gray dot — TTL elapsed |
| fallback | `"pending"` | Yellow dot — unknown/new status values |

### DeviceDetailPanel

Right panel (380px, hidden below `lg` breakpoint). Structurally identical to the User Management detail panel pattern.

**Header section:**
- Device ID (full, monospace) + copy button
- Platform badge + client version
- Close button (×) that clears `?deviceId=`

**Sub-tabs** (underline variant):

#### Overview Tab

```
<DetailGrid>
  <FieldCard label="User" value={user_display_name} />
  <FieldCard label="UID" value={user_uid} mono />
  <FieldCard label="Device ID" value={device_id} mono />
  <FieldCard label="Platform" value={platform} />
  <FieldCard label="Client Version" value={client_version} />
  <FieldCard label="IP Address" value={ip_address} mono />
  <FieldCard label="Token Hash" value={token_hash_truncated} mono />
  <FieldCard label="Status" value={<StatusBadge />} />
  <FieldCard label="Provisioned At" value={consumed_at ? formatDate(consumed_at) : 'Pending'} />
</DetailGrid>
```

**Actions section** (below detail grid, separated by `border-t border-[var(--color-border-subtle)]`):

- **Extend Token** (`Button variant="outline" size="sm"`)
  - Opens `Dialog` with `Select` for duration: 1 hour | 6 hours | 12 hours | 1 day
  - Calls `useExtendToken({ tokenHash, extendSeconds })`
  - Disabled when status is not `"active"`
- **Revoke** (`Button variant="danger" size="sm"`)
  - Opens `AlertDialog` with confirmation text
  - Calls `useBulkRevokeTokens([tokenHash])` (reuses existing mutation)
  - Disabled when status is `"revoked"` or `"expired"`

#### History Tab

Uses `deviceHistoryQueryOptions(deviceId)`. Renders a vertical timeline:

Each entry:
- Token hash (truncated, monospace)
- Status badge
- Timestamp: use `consumed_at` when available (relative + full on hover), show "Not consumed" when null
- Platform + version if available

Displayed as a simple stacked list with left border accent (timeline feel), using existing spacing tokens. No new timeline primitive needed — `border-l-2 border-[var(--color-border-default)]` with `pl-4` per entry.

## Compliance Tab

### ComplianceSummaryCards

Horizontal row of stat cards, one per alert type. Uses `Card` wrapping a `FieldCard` (since `FieldCard` has no `onClick` prop — wrap in a clickable `Card` container):

```
<div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
  {alertTypes.map(type => (
    <button
      key={type}
      onClick={() => filterByType(type)}
      className={cn(
        "text-left rounded-lg border border-[var(--color-border-subtle)] p-4",
        "hover:bg-[var(--color-bg-hover)] transition-colors",
        activeFilter === type && "ring-2 ring-[var(--color-primary)]"
      )}
    >
      <FieldCard label={alertTypeLabel(type)} value={summary[type] || 0} />
    </button>
  ))}
</div>
```

**Alert type labels and severity colors (all 6 types from `ComplianceAlertType`):**

| Alert Type | Label | Severity Color |
|------------|-------|----------------|
| `expired-unused` | Expired Unused | `warning` (amber) |
| `rapid-consumption` | Rapid Consumption | `warning` (amber) |
| `multi-issue` | Multi-Issue Users | `warning` (amber) |
| `stale-active` | Stale Active | `info` (blue) |
| `cross-user-device` | Cross-User Device | `error` (red) |
| `high-failure-rate` | High Failure Rate | `error` (red) |

Cards are clickable — clicking one filters the alert list below and updates `?alertType=` in URL.

### Alert List

Below summary cards. Filtered by `alertType` when set, otherwise shows all alerts sorted by severity (critical → warning → low).

### ComplianceAlertRow

Each alert row:

```
<div className="flex items-start gap-4 p-4 border border-[var(--color-border-subtle)] rounded-lg">
  <Badge variant={severityToBadgeVariant(severity)}>{severity}</Badge>
  <div className="flex-1 min-w-0">
    <p className="text-sm font-medium text-[var(--color-text-primary)]">{description}</p>
    <p className="text-xs text-[var(--color-text-muted)] mt-1">
      {subject_uid && `User: ${subject_uid}`}
      {subject_device_id && ` · Device: ${subject_device_id}`}
      {` · ${relativeTime(detected_at)}`}
    </p>
  </div>
  <CollapsibleSection title="Evidence">
    <CodeBlock language="json" maxHeight="200px" code={JSON.stringify(evidence, null, 2)} />
    <p className="text-xs text-[var(--color-text-muted)] mt-2 italic">
      {recommended_action}
    </p>
  </CollapsibleSection>
</div>
```

**Severity → Badge variant mapping:**

| Severity | `Badge variant` |
|----------|----------------|
| `"critical"` | `"error"` |
| `"warning"` | `"warning"` |
| `"low"` | `"muted"` |

## Data Flow

### Queries Used

| Query | Tab | Component |
|-------|-----|-----------|
| `devicesQueryOptions({ limit, offset, search, date_range, platform })` | Devices | `DeviceList` |
| `deviceHistoryQueryOptions(deviceId)` | Devices | `DeviceDetailPanel` (History tab) |
| `complianceQueryOptions()` | Both | `ComplianceTab` + sidebar alert dot + Devices tab badge count |

### Mutations Used

| Mutation | Trigger | Component |
|----------|---------|-----------|
| `useBulkRevokeTokens` | Revoke button / Bulk revoke | `DeviceDetailPanel`, `DeviceList` |
| `useExtendToken` | Extend dialog submit | `DeviceDetailPanel` |

### Cache Invalidation

Both mutations already invalidate `queryKeys.provisioningOps.all` — no new invalidation logic needed. Toast notifications already wired in the mutation hooks.

## Error Handling

- **Empty states:** "No devices found" with muted text when device list is empty (filtered or unfiltered)
- **Query errors:** TanStack Query's `error` state renders inline error message with retry button
- **Mutation errors:** Toast notifications (already wired in `useBulkRevokeTokens` and `useExtendToken`)
- **Detail panel with no selection:** Shows a muted "Select a device to view details" placeholder
- **Compliance with no alerts:** "No compliance alerts" success state with checkmark icon

## Responsive Behavior

| Breakpoint | Layout Change |
|------------|--------------|
| `< lg` (1024px) | Detail panel hidden, device row click navigates or opens sheet |
| `< md` (768px) | Summary cards: 2 columns instead of 6 |
| `< sm` (640px) | PageHeader stacks vertically (title above, search below) |

## Keyboard Shortcuts

Following Audit Log's pattern:
- `Cmd+K` / `Ctrl+K` — focus search input
- `↑` / `↓` — navigate device list
- `Escape` — close detail panel (clear `?deviceId=`)

## Files Changed Summary

### Create
| File | Purpose |
|------|---------|
| `src/frontend/src/routes/provisioning/devices.tsx` | New route with search param validation |
| `src/frontend/src/components/features/provisioning-management/ProvisioningDevicesPage.tsx` | Page orchestrator |
| `src/frontend/src/components/features/provisioning-management/PageHeader.tsx` | Title + search |
| `src/frontend/src/components/features/provisioning-management/DeviceFilterBar.tsx` | Platform + date filters |
| `src/frontend/src/components/features/provisioning-management/DeviceList.tsx` | List panel + pagination |
| `src/frontend/src/components/features/provisioning-management/DeviceRow.tsx` | Device grid row |
| `src/frontend/src/components/features/provisioning-management/DeviceDetailPanel.tsx` | Detail panel + actions |
| `src/frontend/src/components/features/provisioning-management/ComplianceTab.tsx` | Compliance dashboard |
| `src/frontend/src/components/features/provisioning-management/ComplianceSummaryCards.tsx` | Alert type stat cards |
| `src/frontend/src/components/features/provisioning-management/ComplianceAlertRow.tsx` | Alert row + evidence |

### Modify
| File | Change |
|------|--------|
| `src/frontend/src/types/provisioning-ops.ts` | `OpsTab` drop `lifecycle`, rename search params type |
| `src/frontend/src/components/layout/sidebar.tsx` | Route href + label + alert dot href |
| `src/frontend/src/routeTree.gen.ts` | Auto-regenerated via `just ui-routes` |

### Delete
| File | Reason |
|------|--------|
| `src/frontend/src/routes/provisioning/tokens.tsx` | Replaced by `devices.tsx` |

### Explicitly NOT Changed
| File | Reason |
|------|--------|
| `src/frontend/src/lib/queries/provisioning-ops.ts` | Already complete — all queries and mutations ready |
| `src/frontend/packages/azblink-ui/**` | No new primitives needed |
| `src/backend/**` | All endpoints already built |
| `src/frontend/src/routes/provisioning/route.tsx` | Layout wrapper stays as-is |
