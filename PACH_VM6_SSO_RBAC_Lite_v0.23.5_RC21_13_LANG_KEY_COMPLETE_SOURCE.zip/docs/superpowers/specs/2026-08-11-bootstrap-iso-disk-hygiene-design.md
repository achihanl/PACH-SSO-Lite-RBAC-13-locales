# Bootstrap ISO Disk Hygiene — Design Spec

**Date:** 2026-08-11
**Status:** approved, ready for implementation
**Scope:** this repo **and** the VM7 docshare repo (`VM7_Documen_Nextcloud_EuroOffice_TLS_Hardening_Code_v0.12.1`). Both ship the same `deploy/bootstrap-iso/` tooling; this spec is authoritative for both. VM7 has no `docs/superpowers/` tree, so the spec lives here only.

## Problem

A 250 GB laptop reached **174 MB free**. Recovering 20.6 GB meant hand-deleting
`deploy/bootstrap-iso/` artifacts from two repos. Nothing in the tooling prevents
that state from returning, and nothing warned on the way down.

Measured, not assumed:

| Artifact | Size | Why it exists |
|---|---|---|
| `azblink/.../out/azb-ad.iso` | 3.2 GB | one built ISO per host, never pruned |
| `azblink/.../out/azb-isotest.iso` | 3.2 GB | same |
| `azblink/.../out/smoke-azb-isotest/disk.qcow2` | 4.4 GB | qemu scratch, survives every run |
| `VM7/.../out/azb-docshare.iso` | 3.2 GB | same as above |
| `azblink/.../src/ubuntu-24.04.4-live-server-amd64.iso` | 3.2 GB | source ISO |
| `VM7/.../src/ubuntu-24.04.4-live-server-amd64.iso` | 3.2 GB | **byte-identical duplicate** |

The two source ISOs share sha256 `e907d92eeec9df64163a7e454cbc8d7755e8ddc7ed42f99dbc80c40f1a138433`.
Both `out/` and `src/` are gitignored in both repos, so none of this was ever
tracked — it is pure local exhaust.

### Three independent causes

**1. Each repo downloads its own source ISO.** `find_source_iso()` resolves
`--source` → `AZB_SOURCE_ISO` → `glob(HERE/src/ubuntu-*-live-server-*.iso)`. The
glob is the path of least resistance, so every clone acquires its own 3.2 GB copy.
The config hooks already exist and were simply never used.

**2. Built ISOs accumulate per host.** `out/<host>.iso` is a deterministic path,
so a *rebuild* overwrites — the growth is one 3.2 GB file per host ever built, kept
forever.

**3. `smoke-test.sh` cannot clean up after itself.** The script ends in
`exec qemu-system-x86_64 ...`. `exec` replaces the shell process, so any
`trap ... EXIT` would never fire. It deletes `disk.qcow2` at the *start* of a run,
which means the 4.4 GB file is always present *between* runs — peak footprint is
held exactly when nobody is looking at it. This is the root cause of the single
largest artifact, and it cannot be fixed by adding a trap alone.

### Prior state of the tooling

- The two `build.py` have **diverged** (26,675 vs 25,318 bytes) but expose the
  identical function set, and `find_source_iso` is byte-identical in both.
- `smoke-test.sh` is **byte-identical** in both repos.
- This repo has a `Justfile` with `bootstrap-iso`, `bootstrap-iso-preview`,
  `bootstrap-iso-test`. VM7 has **no command runner** and documents raw script paths.

## Non-goal: automatic recurring cleanup

An earlier draft proposed age-based pruning of stale `out/*.iso` on every build.
**Rejected.** Building a bootstrap ISO is a rare, deliberate act — it happens once
when standing up a new VM and then effectively never again. Machinery that runs on
a schedule or silently deletes siblings during an unrelated build adds a failure
mode to a path that is exercised too rarely to be trusted, and buys nothing over an
explicit command. Cleanup is therefore a verb the operator types.

Likewise rejected: a background low-disk watchdog. It would catch leaks from
anywhere, but costs a resident process on a RAM-constrained machine to solve a
problem whose source is now known and bounded.

## Design

Two explicit verbs, plus one structural fix to each of the three causes.

### Component 1 — shared source-ISO cache in the resolution chain

`build.py`, both repos. New module constant beside `HERE` / `OUT`:

```python
ISO_CACHE = Path(os.environ.get("AZB_ISO_CACHE",
                                Path.home() / ".cache" / "azb" / "iso"))
```

`find_source_iso()`'s fallback branch consults `ISO_CACHE` **before** `src/`:

```
--source → AZB_SOURCE_ISO → ISO_CACHE/ubuntu-*.iso → src/ubuntu-*.iso → BuildError
```

Cache-first is deliberate. Were `src/` to win, a fresh clone that downloaded
locally would keep duplicating and the fix would hold only on machines already
tidied by hand. Cache-first makes the shared copy the default for every clone on
the machine, leaving `src/` as a legacy fallback that still works.

`sorted(...)[-1]` — highest point release wins — is preserved within each location.

**Accepted tradeoff:** an ISO deliberately placed in `src/` is now ignored when a
cache copy exists. `--source` and `AZB_SOURCE_ISO` both still override, so testing
a different point release remains a one-flag operation.

The fix belongs in the resolution chain rather than in `hosts/*.env` precisely
because those files are gitignored: a config-based fix evaporates on a fresh clone
and the duplication silently returns.

### Component 2 — `deploy/bootstrap-iso/run.sh` (new, identical in both repos)

The whole pipeline behind one command:

```
run.sh <host>
  1. source ISO in cache?  no → resolve current point release, download to
                                $ISO_CACHE, verify sha256
  2. build.py --host <host>       → out/<host>.iso   (self-verifying, unchanged)
  3. smoke-test.sh out/<host>.iso → qemu/OVMF on VNC :1, operator watches
  4. print upload steps, and name clean.sh as the follow-up
```

**Which release, and which checksum.** `README.md` explicitly warns against
hardcoding a point release ("24.04.4 supersedes .3"), so `run.sh` must not embed
one. It reads `AZB_UBUNTU_RELEASE` (default `24.04`), fetches
`https://releases.ubuntu.com/$AZB_UBUNTU_RELEASE/SHA256SUMS` **fresh at download
time**, picks the newest `*-live-server-amd64.iso` entry from it, and verifies the
downloaded file against that freshly-fetched digest.

The two 594-byte `SHA256SUMS` files retained in `src/` are *not* the verification
source — they are a record of what was previously used, and would reject a newer
point release. Verification uses the fetched copy; the retained files stay as
provenance only.

It stops with the ISO ready to upload. It cannot go further: attaching the ISO to
the hypervisor is manual and out-of-band, so the pipeline must not reclaim the
artifact it just produced.

### Component 3 — `deploy/bootstrap-iso/clean.sh` (new, identical in both repos)

Reclaims `out/` — built ISOs plus any leftover qemu scratch — and reports bytes
freed. `--cache` additionally drops the shared source ISO from `$ISO_CACHE`.

That flag is opt-in **because the cache is shared**: a repo-local clean silently
deleting it would force every other repo on the machine into a 3.2 GB re-download.

### Component 4 — `smoke-test.sh` cleans up after itself

Both repos, identical patch. Drop `exec` so qemu runs as a child and the shell
survives to clean up, then:

```bash
trap cleanup EXIT INT TERM
```

`cleanup` removes `$SCRATCH` — guarded against an empty variable — unless
`AZB_KEEP_SCRATCH=1`, which is set when an install fails and the disk image needs
inspecting.

This is the one automatic action in the design, and it is scoped to a command
removing a temp file it created seconds earlier, not recurring background work.
Ctrl-C out of a VNC session is the *normal* exit path here, so without the trap the
4.4 GB leak simply continues.

**Accepted tradeoff:** dropping `exec` leaves a wrapper shell alive alongside qemu
(one extra process), and signals now route through the trap rather than reaching
qemu directly. That is the price of the cleanup ever running.

### Command surface

The scripts are the implementation. This repo's `Justfile` gains two thin wrappers
beside the existing targets:

```
bootstrap-iso-run host      → deploy/bootstrap-iso/run.sh {{host}}
bootstrap-iso-clean *ARGS   → deploy/bootstrap-iso/clean.sh {{ARGS}}
```

VM7 has no runner and calls the scripts directly, exactly as it already does for
`smoke-test.sh`. One implementation, no new divergence.

## Failure modes

| Condition | Behaviour |
|---|---|
| Download interrupted / corrupt | verify against the freshly-fetched `SHA256SUMS`; on mismatch delete the partial and refuse to build |
| `releases.ubuntu.com` unreachable | fail with the manual download URL; never build against an unverified ISO |
| `$ISO_CACHE` unwritable | warn, fall through to `src/`, continue |
| qemu absent | `smoke-test.sh` already errors clearly; `run.sh` treats a failed smoke test as non-fatal — the ISO is still uploadable |
| `$SCRATCH` unset/empty | `cleanup` refuses to `rm -rf` |
| No source ISO anywhere | `BuildError` names `$ISO_CACHE` as the download target |

## Testing

- `--dry-run` requires no ISO and must still pass in both repos.
- Source resolution: cache present → cache used; only `src/` populated → legacy
  fallback used; neither → error names the cache directory.
- Scratch cleanup: start a smoke test, Ctrl-C, confirm `out/smoke-*` is gone; repeat
  with `AZB_KEEP_SCRATCH=1` and confirm it survives.
- `verify_iso()` already proves the built ISO's bytes and boot records are
  unchanged by any of the above — no new verification needed for build output.

## Migration

None. The offending artifacts were already deleted on 2026-08-10; only the two
594-byte `SHA256SUMS` files were kept so a re-download can be verified. The first
`run.sh` finds an empty cache, downloads once, and both repos share it thereafter.

## Outcome

Steady-state footprint falls from ~20 GB to a single 3.2 GB cached ISO, and only
while a VM is actively being provisioned.

## Files

**New (identical in both repos):**
- `deploy/bootstrap-iso/run.sh`
- `deploy/bootstrap-iso/clean.sh`

**Modified:**
- `deploy/bootstrap-iso/build.py` (both repos) — `ISO_CACHE` in the resolution chain
- `deploy/bootstrap-iso/smoke-test.sh` (both repos) — drop `exec`, add trap
- `Justfile` (this repo) — `bootstrap-iso-run`, `bootstrap-iso-clean`
- `deploy/bootstrap-iso/README.md` (both repos) — document the two verbs
