# SSO Device Provisioning — Design Spec

**Date:** 2026-03-11
**Status:** Approved
**Scope:** Authenticated, in-app device provisioning via SSO — no QR code required

## Problem

The current provisioning flow is QR-centric: an admin generates a QR code, the mobile client scans it, and consumes a one-time token to receive UC configuration. This works for initial device bootstrapping but requires admin involvement and physical proximity.

Users who are already authenticated via SSO (Authentik OIDC) in a UC client app (softphone, chat) should be able to self-provision their device directly — tap "Add device", get credentials, connect to XMPP/SIP.

## Design Decisions

- **End-user self-service** — the user (not an admin) provisions their own device from within an existing UC client app
- **E2E encryption via libsodium sealed box** — credentials encrypted to client's ephemeral public key, only the client can decrypt
- **Actual credentials returned** (not tokens) — XMPP bind password + SIP password, sealed in the encrypted payload
- **Configurable device cap per profile** — default 5, stored on config template
- **Reuse `provision_tokens` table** — add `auth_method` discriminator column, no new tables
- **New LDAP attribute `azbXmppBindPassword`** — stores plaintext XMPP password, initially synchronized with `userPassword` to avoid XMPP server config changes

## API Contract

### `POST /api/provision/device`

**Auth:** Bearer OIDC access token (required)

**Request:**
```json
{
  "publicKey": "<standard base64-encoded 32-byte Curve25519 public key>",
  "deviceId": "<client-generated UUID>",
  "clientInfo": {
    "platform": "iOS | Android | desktop",
    "version": "1.2.3",
    "appName": "MySoftphone"
  }
}
```

**Public key validation:**
- Decode standard base64 (RFC 4648, not URL-safe)
- Verify decoded length is exactly 32 bytes
- Validate via `nacl.public.PublicKey(decoded_bytes)` — rejects off-curve values
- 422 on any failure

**`clientInfo` mapping:** `platform` → `client_platform` column, `version` → `client_version` column. `appName` is not stored. Max 32 chars each, validated by Pydantic.

**Response (200):**
```json
{
  "ok": true,
  "uid": "jsmith",
  "sealedCredentials": "<base64-encoded libsodium sealed box>",
  "endpoints": {
    "xmpp": {
      "domain": "uchat.example.com",
      "wsUrl": "wss://xmpp.example.com/ws"
    },
    "sip": {
      "domain": "sip.example.com",
      "wssUrl": "wss://sip.example.com"
    }
  },
  "provisioned": {
    "xmppEnabled": true,
    "sipEnabled": true
  },
  "expiresAt": "2026-04-10T04:15:00Z"
}
```

**Sealed payload (decrypted by client):**
```json
{
  "xmppPassword": "<azbXmppBindPassword>",
  "sipPassword": "<AstAuthPassword>",
  "sipUsername": "jsmith"
}
```

**Errors:**
| Code | Error Key | Meaning |
|------|-----------|---------|
| 401 | `INVALID_TOKEN` | Invalid/expired OIDC token |
| 403 | `NOT_UC_PROVISIONED` | User not found in LDAP or no UC attributes |
| 409 | `DEVICE_CAP_REACHED` | Device limit reached (body includes `current` + `max`) |
| 422 | `INVALID_REQUEST` | Invalid public key or missing fields |

### `DELETE /api/provision/device/{device_id}`

**Auth:** Bearer OIDC access token (required)

Revokes a specific device provisioning record. User can only remove their own devices. Sets `status = 'revoked'` in `provision_tokens`, freeing a device cap slot.

**Response (200):**
```json
{ "ok": true, "deviceId": "...", "status": "revoked" }
```

**Errors:**
| Code | Error Key | Meaning |
|------|-----------|---------|
| 401 | `INVALID_TOKEN` | Invalid/expired OIDC token |
| 404 | `DEVICE_NOT_FOUND` | Device ID not found or belongs to another user |

## Backend Flow

1. **Validate OIDC token** — reuse `oidc_verify.py`. Extract `preferred_username` → LDAP `uid`.
2. **Resolve user in LDAP** — `ldap_client.get_user(uid)`. 403 if missing or no UC objectClasses.
3. **Resolve config template** — read `azblinkProfileId` from LDAP user entry, then `orgdb.get_config_template(profile_id)`. Read `max_devices_per_user`, service toggles, endpoints.
4. **Check device cap (with re-provision awareness):**
   - Count: `SELECT COUNT(*) FROM provision_tokens WHERE uid = ? AND auth_method = 'sso_token' AND status = 'active' AND consumed_by_device_id != ?` (excludes current deviceId)
   - If count >= cap → `409 DEVICE_CAP_REACHED`
   - This allows re-provisioning an existing device without hitting the cap
5. **Read credentials from LDAP** — `azbXmppBindPassword` (if `xmpp_enabled`), `AstAuthPassword` (if `sip_enabled`).
   - If `xmpp_enabled` but `azbXmppBindPassword` missing/empty → `500` (log error for admin investigation)
   - If `sip_enabled` but `AstAuthPassword` missing/empty → `500` (log error for admin investigation)
   - Empty string values treated as missing
6. **Build credential payload** — JSON with `xmppPassword`, `sipPassword`, `sipUsername`.
7. **Seal with libsodium** — `nacl.public.SealedBox(client_public_key).encrypt(payload_bytes)`.
8. **Upsert into `provision_tokens`:**
   - `token_hash` = SHA256(`deviceId + uid + str(int(time.time()))`)
   - Use UPSERT keyed on `(uid, consumed_by_device_id, auth_method)` — re-provisioning the same device updates the existing row instead of inserting a duplicate
   - Populate: `auth_method = 'sso_token'`, `sealed_payload` = encrypted blob, `public_key_hash` = SHA256(client public key), `consumed_by_device_id` = request `deviceId`, `client_platform` / `client_version` from `clientInfo`
9. **Return response** — sealed blob + unencrypted service endpoints + provisioning flags.

## LDAP Changes

### New Attribute: `azbXmppBindPassword`

- **Type:** Directory string, single-valued
- **Stored on:** Same DN as existing UC attributes (inetOrgPerson + posixAccount + AsteriskPjsip*)
- **Created during:** `add_uc_attrs_to_user()` when `xmpp_enabled=True`
- **Initial value:** Same plaintext as `userPassword` (before SSHA hashing)

**LDAP schema definition (LDIF):**
```ldif
attributetype ( 1.3.6.1.4.1.99999.1.1.1
    NAME 'azbXmppBindPassword'
    DESC 'Plaintext XMPP bind password for device provisioning'
    EQUALITY caseExactMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15
    SINGLE-VALUE )
```

Note: OID `1.3.6.1.4.1.99999.1.1.1` is a placeholder — replace with AZBlink's registered PEN arc if available. The attribute is added to the OpenLDAP server's custom schema file loaded at startup.

**Password synchronization:** When a user's password changes, both `userPassword` and `azbXmppBindPassword` must be updated. Implementation: add a `_set_user_passwords(dn, plaintext)` helper that updates both in a single LDAP MODIFY. All password-change paths (`reset_user_password()`, any future Authentik-triggered sync) call this helper. This coupling is temporary — once the XMPP server is reconfigured to check `azbXmppBindPassword` directly, the two can diverge.

**XMPP server:** No changes now. Continues using `userPassword` for LDAP BIND auth. Future: reconfigure to check `azbXmppBindPassword`.

### Impact on `build_uc_attrs()`

```python
def build_uc_attrs(xmpp_enabled, sip_enabled, uid_number, extension,
                   sip_password, username, xmpp_password) -> (dict, list):
    # ... existing logic ...
    if xmpp_enabled:
        attrs["azbXmppBindPassword"] = xmpp_password
    # ... rest unchanged ...
```

### New Helper: `get_uc_credentials(uid)`

```python
async def get_uc_credentials(uid: str) -> dict[str, str | None]:
    """Read UC bind passwords from LDAP for device provisioning.
    Returns {"xmpp_password": str|None, "sip_password": str|None}.
    """
```

Reads `azbXmppBindPassword` and `AstAuthPassword` from LDAP for a given user. Used by the provisioning endpoint.

### Password Sync Helper: `_set_user_passwords(dn, plaintext)`

```python
async def _set_user_passwords(dn: str, plaintext: str) -> None:
    """Update both userPassword (SSHA) and azbXmppBindPassword (plaintext) atomically."""
```

Single LDAP MODIFY updating both attributes. Called by `reset_user_password()` and any future password-change path.

## Database Changes

### Migration: `022_device_provisioning.sql`

```sql
-- Add discriminator and SSO-specific columns to provision_tokens
ALTER TABLE provision_tokens
  ADD COLUMN auth_method VARCHAR(32) NOT NULL DEFAULT 'qr',
  ADD COLUMN sealed_payload BYTEA,
  ADD COLUMN public_key_hash VARCHAR(128);

-- Index for device cap counting
CREATE INDEX idx_pt_uid_auth_method_status
  ON provision_tokens (uid, auth_method, status);

-- Unique constraint for SSO device upsert
CREATE UNIQUE INDEX idx_pt_sso_device_upsert
  ON provision_tokens (uid, consumed_by_device_id, auth_method)
  WHERE auth_method = 'sso_token';

-- Rollback:
-- DROP INDEX IF EXISTS idx_pt_sso_device_upsert;
-- DROP INDEX IF EXISTS idx_pt_uid_auth_method_status;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS public_key_hash;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS sealed_payload;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS auth_method;
```

### Config Template Extension

`maxDevicesPerUser` added to config template JSON schema (default: 5).

## Device Cap Enforcement

- **Default:** 5 devices per user
- **Configurable:** per config template via `maxDevicesPerUser`
- **Scope:** Only counts `auth_method = 'sso_token'` with `status = 'active'` (QR provisions are separate)
- **Device removal:** `DELETE /api/provision/device/{device_id}` sets status to `'revoked'`, frees a slot
- **Admin override:** existing `POST /api/users/{uid}/qrcode/revoke` revokes all tokens (both auth methods)

## Security Model

| Threat | Mitigation |
|--------|------------|
| Stolen OIDC token → rogue device | Device cap limits blast radius. Audit trail (IP, device info). Short-lived access tokens. |
| MITM intercepts credentials | libsodium sealed box (E2E). TLS as outer layer. |
| Replay of provisioning request | `public_key_hash` + `deviceId` recorded. Same deviceId re-provisions (updates, not new slot). |
| Credential leakage from LDAP | `azbXmppBindPassword` follows `AstAuthPassword` pattern — plaintext, access restricted to service bind DN. |
| Client private key compromised post-provisioning | Sealed payload in DB is audit-only — permanently unrecoverable after client discards ephemeral key. Re-provisioning generates a new sealed payload with a new client public key. |

**Rate limiting:** New constant `LIMIT_DEVICE_PROVISION = "5/minute"` in `rate_limit.py`, applied per-user via `_device_provision_key()` which extracts `preferred_username` from the Bearer token (unverified decode for key extraction; full verification in `require_user`). Falls back to client IP if token is unparseable.

**Device provision lifetime:** `DEVICE_PROVISION_TTL_SEC` (default 30 days). Expired provisions → client must re-provision.

**Out of scope:** Compromised client device (rooted/jailbroken) — credentials in app memory are exposed regardless.

## Files Modified

| File | Change |
|------|--------|
| `src/backend/main.py` | New routes: `POST /api/provision/device`, `DELETE /api/provision/device/{device_id}` |
| `src/backend/ldap_client.py` | `build_uc_attrs()` adds `azbXmppBindPassword`. New `get_uc_credentials(uid)` helper. |
| `src/backend/orgdb.py` | `count_active_device_provisions(uid, exclude_device_id)` query. Extend `record_provision_token(uid, profile_id, token_hash, expires_at, auth_method='qr', sealed_payload=None, public_key_hash=None)` with new columns. Add upsert method for SSO device provisions. |
| `src/backend/config.py` | Add `DEVICE_PROVISION_TTL_SEC` (default 2592000 = 30 days) |
| `src/backend/requirements.txt` | Add `PyNaCl` |
| `migrations/022_device_provisioning.sql` | Schema extension (3 columns + 1 index) |
| OpenLDAP schema | Add `azbXmppBindPassword` attribute definition |
| OpenLDAP seed/bootstrap | Update test user creation to include new attribute |

## Tests

- **New:** `tests/test_device_provisioning.py` — endpoint auth, device cap, sealed box roundtrip, revocation, error cases
- **Covered in:** `tests/test_device_provisioning.py` — `TestUserCreationXmppPassword` verifies `azbXmppBindPassword` set during user creation

## Future Work (Not in Scope)

- XMPP server reconfiguration to read `azbXmppBindPassword` directly (decouples from `userPassword`)
- Password rotation API for `azbXmppBindPassword`
- Admin UI for viewing/managing SSO-provisioned devices
- Per-device credential isolation (separate passwords per device rather than per user)
