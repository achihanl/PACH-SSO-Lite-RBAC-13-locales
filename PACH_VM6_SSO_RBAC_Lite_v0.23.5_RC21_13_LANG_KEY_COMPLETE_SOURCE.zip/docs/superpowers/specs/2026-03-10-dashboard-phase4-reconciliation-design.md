# Dashboard Phase 4 — Naming & Contract Reconciliation

**Date:** 2026-03-10
**Epic:** #42 (Dashboard Migration)
**Related:** #49 (Phase 4 wiring), #50 (backend endpoints), #51 (WebSocket)
**Scope:** Contract cleanup — types, paths, labels, issue text alignment

---

## Problem

PR #55 merged Phase 3 UI + Phase 4 query hooks, but several naming/contract mismatches exist between:
- GitHub issue specifications (#49, #50) vs actual implementation
- Hook response types vs what backend can realistically return
- Quick action labels vs available routes

These mismatches will cause 404s, type errors, or confusion when #50 (backend) and #49 (wiring) resume.

---

## Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Health endpoint | New `/api/dashboard/health` (separate from `/api/health/deep`) | Different auth, different shape, different purpose (startup check vs ops dashboard) |
| Stats API shape | Backend returns flat aggregate, frontend maps to `StatCardData[]` | Icons/variants are presentation concerns; API stays generic |
| Response wrappers | All endpoints return wrapped objects (`{ field: [...] }`) | Future-proof, matches audit endpoint pattern, hooks already expect this |
| Hook naming | Keep `*QueryOptions()` factory pattern | Matches codebase convention (health.ts, audit.ts); TQ v5 best practice |
| Quick action labels | Hybrid: keep "Add User"/"Audit Log", change "Bulk QR"→"Generate QR", "Export"→"Settings" | Link to existing routes, not future modals |

---

## Changes

### 1. Type Layer (`src/frontend/src/types/dashboard.ts`)

- **Add** `DashboardStatsApiResponse` — flat backend shape:
  ```typescript
  interface DashboardStatsApiResponse {
    total_users: number;
    active_sessions: number;
    pending_provisions: number;
    success_rate: number;
    trends?: {
      users?: { value: string; direction: TrendDirection };
      sessions?: { value: string; direction: TrendDirection };
      pending?: { value: string; direction: TrendDirection };
      success_rate?: { value: string; direction: TrendDirection };
    };
  }
  ```
- **Keep** `StatCardData` as component prop type (unchanged)

### 2. Hook Layer (`src/frontend/src/lib/queries/dashboard.ts`)

- **`dashboardStatsQueryOptions`**: Change response type from `DashboardStatsResponse { stats: StatCardData[] }` to `DashboardStatsApiResponse`
- **Delete** `DashboardStatsResponse` interface
- **`recentQRQueryOptions`**: Add `limit = 5` parameter, pass to API
- **`activityFeedQueryOptions`**: Add `limit = 20` parameter, pass to API
- **`dashboardHealthQueryOptions`**: No change (path `/dashboard/health` is correct)

### 3. Query Keys (`src/frontend/src/lib/queries/keys.ts`)

- **`recentQR`**: Change from static `['dashboard', 'recentQR']` to function `(limit = 5) => ['dashboard', 'recentQR', limit]`
- **`activity`**: Change from static `['dashboard', 'activity']` to function `(limit = 20) => ['dashboard', 'activity', limit]`

### 4. Component Layer (`src/frontend/src/components/features/dashboard/QuickActionsCard.tsx`)

- "Bulk QR" → "Generate QR" (route: `/provisioning/qr-generator`)
- "Export" → "Settings" (route: `/configuration`)
- "Add User" (route: `/directory/users/onboard`)
- "Audit Log" (route: `/audit-log`)
- Replace `() => {}` handlers with `useNavigate()` calls

### 5. GitHub Issues

- **#49**: Replace `use*()` names with `*QueryOptions()` in data wiring table; update quick action labels
- **#50**: Stats endpoint returns flat aggregate; health is `/api/dashboard/health`; add `limit` params to recent QR + activity
- **#42**: Add "Phase 4 Reconciliation Decisions" section

---

## Out of Scope

- Component wiring to hooks (replacing mock data) — blocked on #50
- WebSocket/SSE — #51
- Suspense/error boundaries — part of #49 wiring work
- PendingItem action handlers — needs backend mutation endpoints
- Toast integration — needs real events
- Backend endpoint implementation — #50

---

## Files Changed

| File | Change |
|------|--------|
| `src/frontend/src/types/dashboard.ts` | Add `DashboardStatsApiResponse` |
| `src/frontend/src/lib/queries/dashboard.ts` | Fix stats response type, add limit params, delete stale interface |
| `src/frontend/src/lib/queries/keys.ts` | Parameterize `recentQR` and `activity` keys |
| `src/frontend/src/components/features/dashboard/QuickActionsCard.tsx` | Fix labels, wire navigate handlers |
| GitHub #49 | Update hook names + quick action labels |
| GitHub #50 | Update stats shape, health path, add limit params |
| GitHub #42 | Add reconciliation decisions section |
