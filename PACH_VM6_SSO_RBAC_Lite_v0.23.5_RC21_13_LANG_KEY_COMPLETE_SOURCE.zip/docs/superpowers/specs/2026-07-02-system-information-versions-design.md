# System Information — Stack Versions — Design

- **Date:** 2026-07-02
- **Surface:** `/configuration/settings` → System Info section (frontend) + new backend endpoint `GET /api/system/versions`.
- **Goal:** Surface precise, per-service versions of the whole stack (platform + backing services) under System Information, so an operator can answer "what exact versions am I running?" from the UI.
- **Status:** design approved; pending spec review → implementation plan.

## Problem

The platform version is only shown at the bottom of the sidebar (frontend build `FULL_VERSION`). No version of any **backing service** (OpenLDAP, Redis, PostgreSQL, Authentik, Traefik) is captured or displayed anywhere. Health endpoints report only `healthy`/`unhealthy` status — never a version string.

Operators need version visibility on the configuration page for support, upgrade planning, and CVE triage. Declared docker image tags are not precise enough (`redis:8-alpine` actually runs `8.8.0`; `postgres:16` runs `16.14`), so versions must be queried live where possible.

## Verified findings (empirical, live dev stack 2026-07-02)

| Service | Live probe | Result | Precision vs. image tag |
|---|---|---|---|
| PostgreSQL | `SELECT version()` | `PostgreSQL 16.14 (Debian …)` → `16.14` | tag `16` → live adds patch |
| Redis | `INFO server` → `redis_version` | `8.8.0` | tag `8-alpine` → live adds minor+patch |
| Authentik | `GET /api/v3/admin/version/` → `version_current` | `2026.5.2` (also `version_latest` `2026.5.3`, `outdated:true`) | tag `2026.5` → live adds patch **+ update-available signal** |
| OpenLDAP | rootDSE `vendorName`/`vendorVersion` | **empty** (osixia does not populate) | no live path |
| OpenLDAP | `cn=Monitor` `monitoredInfo` | **unavailable** (`back_monitor` not loaded; cn=config bind refused) | no live path |
| Traefik | — | no clean version API without dashboard/api enabled | no live path |
| Platform | `_version.py` `__version__` | `0.7.0` | authoritative |

**Conclusion:** live query is both possible and strictly more precise for PostgreSQL, Redis, Authentik, and the platform. OpenLDAP and Traefik have no reliable runtime version path → declared image tag is the honest best source. This is exactly the **hybrid** strategy.

## Chosen approach — Hybrid (live probe, image-tag fallback)

Each service reports `{ name, version, source }` where `source ∈ {live, image, unknown}`:

- **live** — queried from the running service (most precise).
- **image** — declared docker image tag, injected via env (for services with no runtime version path).
- **unknown** — probe failed and no tag configured (service down / misconfigured); never blank.

Rejected alternatives:
- **Live-only:** OpenLDAP/Traefik have no runtime version → those rows would be permanently `unknown`. Less useful than showing the declared tag.
- **Tags-only:** `redis:8-alpine` / `postgres:16` tags omit the patch level → violates "as precise as possible."

The `source` badge is shown in the UI so the operator knows whether a value is the true running version or the declared tag.

## Architecture

```
Frontend (SystemInfoSection)                Backend (main.py)
  ├─ "Service Versions" card  ──GET──────►  GET /api/system/versions   [require_admin]
  │    version + source badge                 ├─ platform: _version.__version__ + git env
  │                                           └─ services[]: per-service probe (try/except)
  └─ "Build Information" card                       PostgreSQL  live  SELECT version()
       + Platform Version (from platform.version)   Redis       live  INFO server → redis_version
                                                     Authentik   live  GET /api/v3/admin/version/
                                                     OpenLDAP    image env LDAP_IMAGE_TAG
                                                     Traefik     image env TRAEFIK_IMAGE_TAG
```

## Backend — `GET /api/system/versions`

- **New endpoint in `src/backend/main.py`.** Admin-gated (`Depends(require_admin)`), mirroring the existing `/api/dashboard/health` pattern (per-service list, each probe wrapped in try/except so one failure never 500s the whole response).
- **Why a new endpoint, not extending `/api/version`:** `/api/version` is public/unauthenticated and lightweight. Live DB/Redis/Authentik probes must not run on a public route (perf + information disclosure). Admin gate matches `/api/dashboard/health` precedent.
- **Response shape:**

```json
{
  "platform": {
    "version": "0.7.0",
    "gitHash": "9132697",
    "gitBranch": "main",
    "buildTime": "2026-07-02T01:41:45Z"
  },
  "services": [
    { "name": "PostgreSQL", "version": "16.14",   "source": "live" },
    { "name": "Redis",      "version": "8.8.0",   "source": "live" },
    { "name": "Authentik",  "version": "2026.5.2","source": "live", "latest": "2026.5.3", "outdated": true },
    { "name": "OpenLDAP",   "version": "osixia/openldap:1.5.0", "source": "image", "note": "osixia wrapper tag, not slapd version" },
    { "name": "Traefik",    "version": "v3.7",    "source": "image" }
  ]
}
```

- **Probe implementations** (each isolated, failure → `{version: null, source: "unknown"}` for that row):
  - **PostgreSQL:** `SELECT version()` via existing `ORGDB` engine; parse leading `PostgreSQL X.Y`.
  - **Redis:** `redis.from_url(REDIS_URL).info("server")["redis_version"]`.
  - **Authentik:** `GET {AUTHENTIK_API_URL}/api/v3/admin/version/` with bearer `AUTHENTIK_API_TOKEN`; take `version_current`, optionally `version_latest`/`outdated`. Skip cleanly if Authentik not configured.
  - **OpenLDAP:** read `LDAP_IMAGE_TAG` env → `source: "image"`; if unset → `unknown`.
  - **Traefik:** read `TRAEFIK_IMAGE_TAG` env → `source: "image"`; if unset → `unknown`.
  - **Platform:** `_version.__version__` + `GIT_HASH`/`GIT_BRANCH`/`BUILD_TIME` env (same source as `/api/version`).
- **Config plumbing (compose):** add two env vars to the `api` service in `deploy/dev/docker-compose.yml`:
  - `LDAP_IMAGE_TAG=osixia/openldap:1.5.0`
  - `TRAEFIK_IMAGE_TAG=v3.7`
  (Kept in the `api` service because the backend container cannot see sibling image tags otherwise. Live-capable services need no tag env — they fall back to `unknown` only if actually down, which the health card already flags red.)

## Frontend — enhance existing `SystemInfoSection.tsx`

No new frontend file. No new page (enhancing the existing System Info section, per approved placement).

- **`src/frontend/src/lib/queries/health.ts`** — add `SystemVersionsResponse` type + `systemVersionsQueryOptions()` hitting `/system/versions`. Extending the existing health query file (no new query file).
- **New "Service Versions" card** inside `SystemInfoSection`, above or beside System Status: one row per service → name, version (mono), and a `source` badge (`live` → `success`, `image` → `muted`, `unknown` → `warning`). Reuse `@azblink/ui` `Card` + `Badge`. When Authentik `outdated` is true, show a small "update available → latest" hint.
- **Build Information card** — add a **Platform Version** row (from `platform.version`) next to the existing UI Version. This is the explicit "show the platform version on the config page" ask. UI Version (frontend build) and Platform Version (backend `_version.py`) are the same SemVer in this monorepo but are surfaced independently for traceability.

## Bundled polish fixes (approved, separable)

Same `SystemInfoSection` card carries stale data — fix as part of this pass:

1. **Authentication card is wrong.** Hardcodes "OIDC Required: No (UC-only mode)", "Break-glass Mode: Disabled" — contradicts **ARD-002 (Authentik-only OIDC)**. Correct to reflect OIDC-required web auth. `// TODO today:` fix stale auth card.
2. **Hardcoded connection strings** (`localhost:5433`, `localhost:6379`, `ldap://openldap:389`) are dev literals baked into the component — wrong in any non-dev deploy. Either drop the connection detail or source it (out of primary scope; at minimum stop asserting dev values as fact).

## Error handling

- Endpoint never 500s on a single probe failure — each row degrades to `unknown`.
- Frontend query uses standard TanStack Query (non-suspense) with skeleton; a total endpoint failure shows an inline error, not a crash.
- No secrets in the response: only version strings; Authentik token never echoed.

## Testing

- **One integration test** (real Docker stack, existing convention): `GET /api/system/versions` as admin →
  - asserts response shape (`platform.version` present; `services` is a non-empty list of `{name, version, source}`),
  - asserts PostgreSQL and Redis rows are `source: "live"` with non-null version (stack is up),
  - asserts unauthenticated request is rejected (admin gate).
- Follows `tests/` real-stack pattern (`client` = authed, `anon_client` = unauthed).

## Scope

- **In:** Platform, PostgreSQL, Redis, Authentik (live); OpenLDAP, Traefik (tag). The two bundled polish fixes.
- **Out:** XMPP/SIP UC servers (external, no reliable version discovery — omit rather than show noise). Per-service "latest available" checks beyond what Authentik already returns. Sourcing live connection strings (only stop asserting wrong dev literals).

## Architecture governance

- Adds one API route (`/api/system/versions`) — a governed surface. The implementation commit carries a **`Spec-Patch:`** trailer against the observability/health spec section (non-decisional: a read-only diagnostics endpoint that mirrors existing `/api/dashboard/health`; no new architectural decision). If review deems it decisional, escalate to a short ARD. `arch_guard.py` is warn-only during calibration.

## Files touched

- `src/backend/main.py` — new `/api/system/versions` endpoint + probe helpers.
- `deploy/dev/docker-compose.yml` — `LDAP_IMAGE_TAG`, `TRAEFIK_IMAGE_TAG` env on `api` service.
- `src/frontend/src/lib/queries/health.ts` — types + `systemVersionsQueryOptions()`.
- `src/frontend/src/components/features/settings/sections/SystemInfoSection.tsx` — Service Versions card, Platform Version row, 2 polish fixes.
- `tests/` — one integration test for the endpoint.
