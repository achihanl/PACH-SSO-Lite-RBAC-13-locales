# Design — Authentik LDAP Source (LDAP-backed web SSO)

> **Date:** 2026-07-03 · **Status:** approved (brainstorm) · **Branch:** `feat/authentik-ldap-source`
> **Governance:** ARD-007 (standalone; *references* ARD-002 — ARDs are append-only, not amended). Spec §04 (authentication) + §06 (deployment topology) updates.

## Problem / goal

Today the platform has two **disjoint** identity stores:

- **Platform OpenLDAP** — every UC user (`uid=…,ou=people`) with `userPassword` (login + XMPP bind), `AstAuthPassword` (SIP), and UC objectClasses. The PED and other UC clients authenticate users by binding here.
- **Authentik** — its own user store (`akadmin`, plus locally-seeded users). 0 LDAP sources → the two stores do not share identities.

Empirically confirmed: an LDAP-only user (`mei`, `alex`, …) cannot log into the web SSO, and an Authentik-only user can't authenticate on the PED.

**Goal:** unify identity so a directory user provisioned on the platform can **also** log into the web admin SSO with the *same* credential the PED uses (`userPassword`). One identity, created once → PED XMPP + SIP (already works via profile-driven UC provisioning) **and** web SSO (this work).

**Scope:** production-ready. Dev seed + ansible/prod config + ARD-007 + docs + integration test.

## Non-goals

- Directory-driven admin RBAC via LDAP group sync — **deferred** (design option ②). This spec syncs *users* only; web-admin rights stay assigned in Authentik's admin group.
- Changing UC provisioning (Flow 1) — already works; a user on a UC-enabled profile gets XMPP/SIP attrs atomically at creation (ARD-001/ARD-004).
- Reverse federation (Authentik LDAP outpost as the PED's directory) — rejected; it would break the single-LDAP UC model (UC attrs live only on the platform LDAP).

## Architecture / auth model

Authentik federates identity **from** the platform OpenLDAP — one-directional. LDAP stays the source of truth; Authentik reads it. ARD-002 ("Authentik-only web auth") is preserved: Authentik remains the sole web-auth path; its user store is now LDAP-backed. **UC still works with Authentik absent** (Authentik depends on LDAP, never the reverse) — the core invariant is intact.

```
  operator creates user (profile w/ XMPP+SIP)
        │  atomic LDAP write (ARD-001/004)
        ▼
  platform OpenLDAP  ── userPassword / azbXmppBindPassword / AstAuthPassword
        │  (Plane A: PED binds as user → XMPP/SIP)         [already works]
        │
        │  (Flow 2, this work) Authentik LDAP source:
        │    - sync: bind cn=authentik-sync → read ou=people users
        │    - login: LDAPBackend binds AS the user to validate password
        ▼
  Authentik ── web SSO identity (username=uid, email=mail)
        │  OIDC → AZBlink Directory web UI
        ▼
  backend authorizes: admin actions require OIDC_ADMIN_GROUP ∈ claims.groups
```

## Components

### Authentik LDAP source
Created idempotently by the seed (and ansible for prod):

| Field | Value |
|-------|-------|
| `name` / `slug` | `AZBlink Directory LDAP` / `azblink-ldap` |
| `server_uri` | `ldap://openldap:389` (dev, Docker-internal); prod: the platform LDAP URI |
| `bind_cn` | `cn=authentik-sync,ou=clients,dc=azblink,dc=com` |
| `bind_password` | provisioned-client secret (env `AUTHENTIK_LDAP_SYNC_PASSWORD` / vault) |
| `base_dn` | `dc=azblink,dc=com` |
| `additional_user_dn` | `ou=people` — scopes sync to people. Service accounts (`ou=clients`, `organizationalRole`) sit outside this subtree, so the filter needn't exclude them. **Everything in `ou=people` syncs**, incl. test users (`xmpptest01`) — accepted. |
| `user_object_filter` | `(&(objectClass=inetOrgPerson)(uid=*))` |
| `object_uniqueness_field` | `uid` — **CRITICAL.** Authentik model-defaults this to AD's `objectSid`, absent on OpenLDAP entries → sync silently imports **0 users**. `uid` matches the platform's immutable-uid convention. (`entryUUID` is the alternative.) |
| `user_property_mappings` | `openldap-uid`, `openldap-cn`, `default-mail` (managed defaults; PKs looked up by managed ID). Optionally add `default-dn-path` for tidy user paths. |
| `sync_users` | `true` |
| `sync_users_password` | `false` — read-minus-secrets can't read `userPassword`, and we don't want a hash copy |
| `password_login_update_internal_password` | `false` — pure bind-based; internal password stays unmanaged |
| `sync_groups` | `false` — model default is `true` with an AD `(objectClass=group)` filter (noise on OpenLDAP). Explicit `false` encodes non-goal ② (no LDAP group/RBAC sync). |
| `delete_not_found_objects` | `false` — LDAP-deleted users keep their Authentik account (no surprise session kills). Deactivation is handled by Plane A instead: terminate/suspend swaps `userPassword`→`{DISABLED}`/`{SUSPENDED}`, so the next bind fails. Revisit if orphan cleanup is needed. |

Managed property-mapping IDs: `goauthentik.io/sources/ldap/openldap-uid`, `…/openldap-cn`, `…/default-mail`.

### Bind/sync account — dogfooded provisioned client
`cn=authentik-sync,ou=clients,dc=azblink,dc=com`, provisioned via the existing `/api/settings/ldap/clients/provisioned` (client_id `authentik-sync`). Read-minus-secrets is **sufficient and preferable**: sync reads only non-secret user attrs (uid/cn/mail); login binds as the user, so the account never needs to read a password. Least privilege + dogfoods #181/ARD-006.

### Secret lifecycle (the provision API mints the password — plan around it)
The provision API (`main.py:3634`) **generates** the client secret server-side and returns it **show-once**; there is no way to supply a chosen password. This shapes every consumer:

- **Seed idempotency (dev).** Step 2 captures the secret only on the *first* run. Re-running the seed (documented recovery: `docker start -a azblink-authentik-seed`) gets 409 with no secret. Mechanism: on-exists → `POST /api/settings/ldap/clients/provisioned/{client_id}/rotate` (`main.py:3671`) → capture the fresh secret → `PATCH` the source's `bind_password`. A re-run is then self-healing, never stuck.
- **Prod.** "Secret in vault" is circular — vault can't pre-hold a password the API mints at provision time. Chosen flow: **ansible calls provision (or rotate) with an admin OIDC token, captures the show-once secret, writes it to `group_vars/all/vault.yml`, then configures the source with it.** (Rejected: direct `ldapadd` with a vault-chosen password — bypasses the `ldap_provisioned_clients` registry, making the client invisible in the UI and breaking ARD-006 reconciliation.)
- **ACL on existing volumes (prod upgrade).** The `ou=clients` read ACL ships via `deploy/dev/ldap/ldap-clients-acl.ldif`, applied **only at osixia fresh init**. Already-initialized LDAP volumes lack the `dn.children=ou=clients` read rule → sync reads return err-32/empty. Ansible needs an **idempotent `ldapmodify` step** (EXTERNAL bind) to apply/confirm the ACL on upgrade.

## Data flow

- **Sync:** Authentik binds as `cn=authentik-sync` → searches `ou=people` with the user filter → maps `uid→username`, `cn→name`, `mail→email` → creates/links Authentik users + a `UserSourceConnection`.
- **Login:** user submits LDAP password → Authentik `LDAPBackend` binds to LDAP as `uid=<user>,ou=people` with that password → success = authenticated. No password copied into Authentik. Identical `userPassword` the PED uses.

## Authorization (safety)

Synced users receive Authentik identities but **no admin rights by default**. Two gates in the backend:
- **Admin:** `require_admin` (`main.py:441-445`) grants full admin only when `OIDC_ADMIN_GROUP ∈ claims.groups`.
- **Fine-grained RBAC:** `require_permission` (`main.py:455-473`) checks **ORGDB permissions keyed by `preferred_username` first**, with admin-group as the fallback.

**Activation caveat (state in ARD-007):** synced usernames = `uid` = exactly the key `ORGDB.get_user_permissions()` uses. Any permission rows already assigned to directory users — inert until now because those users could not log in — **activate the day sync ships**. This is almost certainly intended (that's what the grants were for), but it *is* an authorization-activation event, not a no-op. The safe-by-default claim holds strictly for *admin* rights (sync creates no group membership); it does **not** mean zero authz change for users who already hold RBAC grants.

Demo: add the demo user to the Authentik admin group so end-to-end SSO lands in the admin UI (rather than "authenticated but denied"). Use an **LDAP-only** user for this — see Testing.

## Files / surfaces

- `deploy/dev/authentik-seed/seed_authentik.py` — new `ensure_ldap_source()`:
  1. look up the 3 property-mapping PKs by managed ID (mirror `get_scope_mapping_pks` pattern),
  2. ensure the sync client exists (call the directory-api `/api/settings/ldap/clients/provisioned` with `DEV_AUTH_TOKEN`; capture the show-once secret; **on 409 → rotate → capture** per Secret lifecycle) — dev only; prod supplies the secret via vault,
  3. idempotent GET-then-POST the LDAP source,
  4. **trigger the initial sync via the tasks system** — find the source's schedule, `POST /api/v3/tasks/schedules/{id}/send/`, then **poll** `GET /api/v3/sources/ldap/{slug}/sync/status/` to completion (there is **no** `.../sync/` trigger endpoint). Apply the worker-race retry pattern (`_get_flow_pk`-style) — the sync worker may still be importing blueprints (prior seed-race gotcha),
  5. **only after sync completes**, add the demo user to the admin group.
- `ensure_seed_users()` — stop creating local `alanl` **and delete/relink any pre-existing local `alanl`** on run (skip-if-exists means dropping it from the list fixes only fresh stacks; existing stacks keep the collision). Keep `akadmin` local as break-glass admin.
- `deploy/dev/docker-compose.yml` — **governed surface (§06).** `authentik-seed` currently `depends_on: authentik-server` only. Add: `depends_on` directory-api (healthy) + `DEV_AUTH_TOKEN` + the directory-api base URL in its env (step 2 needs all three).
- `deploy/dev/ldap/ldap-clients-acl.ldif` — ACL itself unchanged; document the upgrade-path apply (Secret lifecycle → idempotent `ldapmodify`).
- `deploy/ansible/` — role/vars for the prod LDAP source; provision/rotate → capture → `group_vars/all/vault.yml`; idempotent ACL apply.
- `docs/architecture/decisions/ARD-007-authentik-ldap-source.md` (**standalone, references ARD-002** — note ARD-002 already anticipated an LDAP source: its termination note cites "next LDAP Source sync ~5 min"); `docs/architecture/spec/04-authentication.md` **and `06-*` (deployment topology)** updates + spec-meta bump; README ARD table.
- Env: `AUTHENTIK_LDAP_SYNC_CLIENT_ID` (default `authentik-sync`), `AUTHENTIK_LDAP_SYNC_PASSWORD`, `LDAP_URI` (source server_uri).
- No platform DB migration (Authentik-side config only).

## Edge cases

- **Username collision** — the seed currently creates a *local* `alanl`. `ensure_seed_users` is skip-if-exists, so merely dropping `alanl` from the list leaves the account on every already-built stack → the local user shadows the LDAP one. Because both passwords are `alanl123!`, login silently falls through to `InbuiltBackend` and a "successful" SSO **proves nothing about the LDAP path**. Fix: actively delete/relink the pre-existing local `alanl`; validate with an LDAP-only user (see Testing). `akadmin` stays local. (In practice `alanl` is a legacy local-only seed user not present in the LDAP bootstrap directory, so the collision described above cannot occur today — the delete is defensive, guarding the case where `alanl` is later UC-provisioned into LDAP; the demo deliberately uses `mei`, a real LDAP user, instead.)
- **Sync latency / login needs prior sync** — `LDAPBackend` authenticates only users already imported (it needs the synced DN). A freshly provisioned user cannot web-SSO until the next scheduled sync. v1: document the sync interval; optionally shorten the source schedule. (A backend fire-and-forget "poke sync" after user-create is possible — precedent: `terminate_user_access` is already optional fire-and-forget Authentik coupling — but it's scope creep; deferred.)
- **Deletion lifecycle** — `delete_not_found_objects=false`, so LDAP-deleted users leave an active-looking Authentik account. Bind-based login still fails once Plane A swaps `userPassword`→`{DISABLED}`, but **live sessions / refresh tokens are not revoked by sync**. Terminate already revokes Authentik sessions (`main.py:1648`); confirm the **suspend** path does too (unverified).
- **LDAP down** — LDAP users can't SSO (bind fails); local `akadmin` still works. Acceptable degradation.
- **Authentik down** — UC/PED unaffected (invariant preserved).
- **Ordering (dev)** — `ensure_ldap_source` provisions the sync client before creating the source. Note: `ou=clients` is created **lazily inside `provision()`** (`ldap_provisioning.py:98`), *not* at directory-api startup; the ACL comes from the openldap **fresh-init bootstrap**, not directory-api. The real dependency is that directory-api is up + reachable (with `DEV_AUTH_TOKEN`) before the Authentik seed calls step 2 — enforced via the compose `depends_on` above.
- **Re-sync idempotency** — `UserSourceConnection` links prevent duplicate users on repeated syncs.

## Testing

- **Integration test** (real stack): provision the sync client → create an **LDAP-only** user via the directory API (one that never existed locally in Authentik) → trigger sync (`POST /tasks/schedules/{id}/send/`) → poll `/sources/ldap/{slug}/sync/status/` to completion → assert the user is imported with matching `username`/`email` **and a `UserSourceConnection` linking it to the source** (username presence alone is insufficient — a local user would also match). Ideally also assert the imported user has no usable internal password.
- **Live SSO demo** (gstack): log in as an **LDAP-only** user (e.g. `mei`) — *not* `alanl`, whose local duplicate would false-positive the demo. Screenshot the authenticated admin UI after adding the demo user to the admin group. Headless assertion of the full browser auth flow is brittle, so this stays a demo/manual verification. (`tools/web-sso-provision-ref/` is an existing browser-OIDC harness that can serve here.)

## Rollout

1. Dev: seed provisions the sync client (rotate-on-rerun), creates the source, triggers + polls the initial sync, then demos SSO with an **LDAP-only** user.
2. Prod: ansible provisions/rotates the sync client with an admin OIDC token → captures the show-once secret → writes `group_vars/all/vault.yml` → configures the source; **idempotent `ldapmodify`** applies the `ou=clients` ACL on already-initialized volumes.
3. ARD-007 accepted (standalone, references ARD-002); spec §04 + §06 updated + spec-meta bump; PR + release.
