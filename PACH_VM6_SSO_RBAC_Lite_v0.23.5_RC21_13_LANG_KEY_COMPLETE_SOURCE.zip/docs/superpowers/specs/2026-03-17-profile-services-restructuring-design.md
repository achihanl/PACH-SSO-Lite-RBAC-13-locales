# Profile Services Restructuring — Design Spec

**Date:** 2026-03-17
**Status:** Draft
**Scope:** Remove SSO + QR from profiles, restructure UC services into extensible profile_services model

## Summary

Three changes to the config template (profile) system:

1. **Remove SSO** — Authentik is platform-level SSO. No per-profile or per-org SSO config needed.
2. **Remove QR** — SSO device provisioning replaces QR-based provisioning entirely. Full removal of QR infrastructure.
3. **Restructure UC services** — XMPP and SIP become independent service records attached to a profile via a new `profile_services` table with a `service_type` discriminator and JSON `config` column. Extensible for future service types without schema migrations.

## Decisions

| # | Decision | Choice | Rationale |
|---|----------|--------|-----------|
| 1 | Profile model | Profile = container, services = typed child records | Profiles are named config bundles; services are independently managed |
| 2 | Service schema | `service_type` discriminator + JSON `config` column | Extensible for future services without migrations; Pydantic validates per type |
| 3 | Counter ownership | UID range on profile (shared), service-specific counters on service | UID is LDAP posixAccount (shared); extensions are SIP-specific |
| 4 | SSO removal scope | Full removal from profiles AND orgs | Authentik is the single SSO source of truth |
| 5 | QR removal scope | Full platform removal | SSO device provisioning has replaced QR provisioning |
| 6 | Device cap | Stays on profile | Policy decision independent of service type |
| 7 | Provision tokens | Rename to `device_provisions`, drop `auth_method` column | Only SSO provisions remain; cleaner schema |

## Approach: Phased — Removals First, Then Schema (Approach C)

Three sequential PRs, each independently reviewable and testable:

- **PR 1:** Remove SSO + QR (pure deletions)
- **PR 2:** Profile services restructuring (additive schema change)
- **PR 3:** Cleanup and documentation

---

## PR 1 — Remove SSO + QR (Pure Deletions)

### Migration: `024_remove_sso_qr.sql`

```sql
ALTER TABLE config_templates DROP COLUMN sso_config;
ALTER TABLE config_templates DROP COLUMN qr_settings;
DROP TABLE IF EXISTS qr_issuance_audit;
DROP TABLE IF EXISTS qr_issues;
DROP TABLE IF EXISTS qr_preview_links;
ALTER TABLE provision_tokens RENAME TO device_provisions;
ALTER TABLE device_provisions DROP COLUMN auth_method;
```

### Backend Deletions

**SSO config removal:**
- `orgdb.py`: Drop `sso_config` column from `config_templates` table definition
- `orgdb.py`: Remove from `create_config_template`, `update_config_template`, `clone_config_template`
- `orgdb.py`: Remove `toggle_config_template_section` entirely (only `sso` was toggleable)
- `main.py`: Remove `_resolve_sso_payload()` helper (~line 210-239)
- `main.py`: Remove `ssoConfig` from user detail response (~line 866-907)
- `main.py`: Remove SSO fields from `_format_template_list` / `_format_template_detail`
- `main.py`: Remove `PATCH /api/config-templates/{id}/toggle` endpoint
- `main.py`: Remove `ConfigTemplateSectionToggle` Pydantic model

**QR full removal:**
- Delete `src/backend/qr_signing.py` entirely
- `main.py`: Remove top-level imports: `import qrcode`, `from qr_signing import sign_provisioning_payload`
- `main.py`: Remove all QR-related endpoints:
  - `GET /api/qr/codes` — QR management list
  - `GET /api/qr/stats` — QR aggregate stats
  - `GET /api/qr-codes/recent` — Dashboard recent QR feed
  - `GET /api/qr/preview/{token}` — Public preview (no auth)
  - `POST /api/users/{uid}/qrcode/share` — Create preview link
  - `POST /api/provision/qr` — QR provisioning
  - Any other `/api/qrcode/*` or QR-related endpoints
- `main.py`: Remove QR-related Pydantic models
- `orgdb.py`: Remove `record_org_qr_issue`, `sso_profile_qrcode`, QR issuance methods
- `orgdb.py`: Drop `qr_issuance_audit`, `qr_issues`, `qr_preview_links` table definitions and all associated methods (`create_preview_link`, `get_preview_link`, `revoke_issues_by_profile`, etc.)
- `orgdb.py`: Update `compute_compliance_alerts()` — remove any JOINs against `qr_issuance_audit`; either rewrite to use only `device_provisions` or remove entirely if compliance logic is QR-only

**Provision tokens → device_provisions:**
- `orgdb.py`: Rename table reference `provision_tokens` → `device_provisions`
- `orgdb.py`: Drop `auth_method` from queries (always SSO now)
- `orgdb.py`: Rename methods (e.g., `count_active_sso_provisions` → `count_active_provisions`)

### Frontend Deletions

**SSO config UI (delete files):**
- `src/frontend/src/components/features/org-management/SSOConfigTab.tsx`
- `src/frontend/src/components/features/org-management/SSOStatusCard.tsx`
- `src/frontend/src/components/features/org-management/SSOBadge.tsx`
- `src/frontend/src/components/features/org-management/modals/EditSSOModal.tsx`

**SSO from profiles:**
- `ConfigTab.tsx`: Remove SSO section (lines 58-74)
- `profile-type-config.ts`: Remove `sso` from `sectionConfig`
- `org-profiles.ts`: Remove `SsoConfig`, `FeatureKey`, `ToggleSectionPayload`, `sso` from `ProfileDetail`, `ssoEnabled` from `ProfileListItem`, SSO fields from payloads

**SSO from org management:**
- Remove SSO references from `DetailTabs.tsx`, `OrgDetailPanel.tsx`, `OverviewTab.tsx`
- `org-mutations.ts`: Remove `useToggleSSO` and `useUpdateSSOConfig` hooks

**QR UI (delete files):**
- `src/frontend/src/components/features/user-management/modals/QRGenerationModal.tsx`
- `src/frontend/src/components/features/org-management/QRSettingItem.tsx`
- `src/frontend/src/components/features/org-management/ProvisioningTab.tsx` (if QR-only; otherwise remove QR content)
- `src/frontend/src/lib/queries/qr.ts`
- `src/frontend/src/lib/queries/qr-generation.ts`
- `src/frontend/src/lib/queries/qr-management.ts`
- `src/frontend/src/lib/queries/qr-share.ts`
- `src/frontend/src/lib/utils/qr-helpers.ts`
- `src/frontend/src/types/qr.ts`
- `src/frontend/src/types/qr-management.ts`

**QR management page (delete entire directory):**
- `src/frontend/src/components/features/qr-management/` — all 9 files (`QRManagementPage.tsx`, `QRDetailPanel.tsx`, `QRList.tsx`, `QRRow.tsx`, `QRStatusBadge.tsx`, `PageHeader.tsx`, `qr-status-config.ts`, `useModalState.ts`, `modals/GenerateQRModal.tsx`)

**QR preview page (delete):**
- `src/frontend/src/components/features/qr-preview/QRPreviewPage.tsx`

**QR routes (delete):**
- `src/frontend/src/routes/qr/preview.$token.tsx`
- `src/frontend/src/routes/provisioning/qr-codes.tsx`

**QR on dashboard:**
- Delete `src/frontend/src/components/features/dashboard/RecentQRCard.tsx`
- Delete `src/frontend/src/components/features/dashboard/QRTable.tsx`
- `DashboardMain.tsx`: Remove `RecentQRCard` import and render
- `src/frontend/src/lib/queries/dashboard.ts`: Remove `recentQRQueryOptions`

**QR in onboarding wizard:**
- Delete `src/frontend/src/components/features/user-management/onboarding/StepQRCode.tsx`
- `OnboardingWizard.tsx`: Remove Step 4 (QR code), renumber remaining steps

**QR from profiles:**
- `ConfigTab.tsx`: Remove QR Settings section (lines 76-93)
- `profile-type-config.ts`: Remove `qr` from `sectionConfig`
- `org-profiles.ts`: Remove `QrSettings`, `qr` from `ProfileDetail`, QR fields from payloads

**Tests to delete:**
- `tests/test_qr_signing_unit.py`
- `tests/test_qr_signing.py`
- `tests/test_qr_format.py`
- `tests/test_qrcode_v2.py`
- `tests/test_qr_revoke.py`
- `tests/test_qr_flow_integration.py`
- `tests/test_qr_management.py`

**Tests to update:**
- `test_config_templates.py`: Remove SSO/QR assertions
- `conftest.py`: Remove QR-related test helpers

---

## PR 2 — Profile Services Restructuring

### New Table: `profile_services`

```sql
-- 025_profile_services.sql

CREATE TABLE profile_services (
    id            VARCHAR(128) PRIMARY KEY,
    profile_id    VARCHAR(128) NOT NULL REFERENCES config_templates(id) ON DELETE CASCADE,
    service_type  VARCHAR(50) NOT NULL,    -- 'xmpp', 'sip', future types
    enabled       BOOLEAN NOT NULL DEFAULT true,
    config        JSON NOT NULL DEFAULT '{}',
    -- Service-specific allocation counters (NULL if not applicable)
    next_counter  INTEGER,
    counter_start INTEGER,
    counter_end   INTEGER,
    -- Audit
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- One service type per profile
    UNIQUE(profile_id, service_type)
);
```

### Data Migration (in same migration file)

```sql
-- Migrate XMPP services
INSERT INTO profile_services (id, profile_id, service_type, enabled, config)
SELECT
    gen_random_uuid()::text, id, 'xmpp', xmpp_enabled,
    json_build_object('domain', COALESCE(xmpp_domain, ''), 'ws_url', COALESCE(xmpp_ws_url, ''))
FROM config_templates
WHERE xmpp_enabled = true OR xmpp_domain IS NOT NULL;

-- Migrate SIP services with counters
INSERT INTO profile_services (id, profile_id, service_type, enabled, config, next_counter, counter_start, counter_end)
SELECT
    gen_random_uuid()::text, id, 'sip', sip_enabled,
    json_build_object('domain', COALESCE(sip_domain, ''), 'wss_url', COALESCE(sip_wss_url, '')),
    next_extension, ext_range_start, ext_range_end
FROM config_templates
WHERE sip_enabled = true OR sip_domain IS NOT NULL;

-- NOTE: Profiles with no UC configuration (both flags false, both domains NULL)
-- intentionally produce no profile_services rows and will have services: [] in the API response.

-- NOTE: gen_random_uuid() requires PostgreSQL 13+ (built-in) or pgcrypto extension on older versions.

-- Drop migrated columns from config_templates
ALTER TABLE config_templates DROP COLUMN xmpp_enabled;
ALTER TABLE config_templates DROP COLUMN sip_enabled;
ALTER TABLE config_templates DROP COLUMN xmpp_domain;
ALTER TABLE config_templates DROP COLUMN xmpp_ws_url;
ALTER TABLE config_templates DROP COLUMN sip_domain;
ALTER TABLE config_templates DROP COLUMN sip_wss_url;
ALTER TABLE config_templates DROP COLUMN next_extension;
ALTER TABLE config_templates DROP COLUMN ext_range_start;
ALTER TABLE config_templates DROP COLUMN ext_range_end;
```

### Columns Remaining on `config_templates`

After PR 1 + PR 2, the table retains:
- `id`, `name`, `description`, `template_type`, `status` (identity/metadata)
- `max_devices_per_user` (profile-level policy)
- `next_uid_number`, `uid_range_start`, `uid_range_end` (shared LDAP posixAccount)
- `created_at`, `updated_at`, `created_by`, `updated_by` (audit)

### Service Config JSON Shapes (Pydantic-validated)

```python
# XMPP
{"domain": "hkl.example.com", "ws_url": "wss://xmpp.hkl.example.com/ws"}

# SIP
{"domain": "sip.hkl.example.com", "wss_url": "wss://sip.hkl.example.com"}

# Future service (no migration needed)
{"domain": "matrix.example.com", "homeserver_url": "https://matrix.example.com"}
```

### Backend Changes

**New Pydantic models:**
```python
class XmppConfig(BaseModel):
    domain: str
    ws_url: str

class SipConfig(BaseModel):
    domain: str
    wss_url: str

class ServiceConfig(BaseModel):
    service_type: str
    enabled: bool = True
    config: dict

class XmppServiceConfig(ServiceConfig):
    service_type: Literal["xmpp"] = "xmpp"
    config: XmppConfig

class SipServiceConfig(ServiceConfig):
    service_type: Literal["sip"] = "sip"
    config: SipConfig
    counter_start: int | None = None
    counter_end: int | None = None
```

**`orgdb.py` changes:**
- Add `profile_services` SQLAlchemy Table definition
- New methods: `add_profile_service()`, `update_profile_service()`, `remove_profile_service()`, `get_profile_services(profile_id)`
- `allocate_extension()` rewritten: `UPDATE profile_services SET next_counter = next_counter + 1 WHERE profile_id = ... AND service_type = 'sip' AND next_counter <= counter_end RETURNING next_counter - 1`. Preserve existing overflow behavior: when no row is updated (counter exhausted), raise the same `ExtensionRangeExhausted` error type so existing tests and callers continue to work.
- `create_config_template()` and `update_config_template()` no longer accept XMPP/SIP flat fields
- `clone_config_template()` also clones associated service rows

**`provisioning.py` — `allocate_uc_resources()` changes:**
- Current signature: `allocate_uc_resources(orgdb, profile_id, xmpp_enabled, sip_enabled)`
- New signature: `allocate_uc_resources(orgdb, profile_id, services: list[dict])` — receives service records from `get_profile_services()`
- Derives `xmpp_enabled`/`sip_enabled` from service list instead of receiving as booleans
- Extension allocation calls rewritten `allocate_extension()` on `profile_services`

**`ldap_client.py` — `build_uc_attrs()` changes:**
- Receives a list of service configs instead of separate `xmpp_enabled`/`sip_enabled` booleans
- Iterates services to determine objectClasses and attrs
- `azblinkProfileId` still set (single profile reference unchanged)

**`main.py` changes:**
- `_format_template_list()` and `_format_template_detail()` include `services: [...]` array
- New sub-endpoints:
  - `POST /api/config-templates/{id}/services` — attach a service
  - `PUT /api/config-templates/{id}/services/{service_id}` — update a service
  - `DELETE /api/config-templates/{id}/services/{service_id}` — remove a service
- User creation endpoint: calls `get_profile_services(profile_id)` and passes result to both `allocate_uc_resources()` and `build_uc_attrs()` (replaces current flat `xmpp_on`/`sip_on` pattern at ~line 1515)
- Device provisioning endpoint resolves service configs for credential sealing

### Frontend Changes

**Types (`org-profiles.ts`):**
```typescript
export type ServiceType = 'xmpp' | 'sip' | string;

export interface ProfileService {
  id: string;
  serviceType: ServiceType;
  enabled: boolean;
  config: Record<string, unknown>;
  counterStart?: number;
  counterEnd?: number;
  nextCounter?: number;
}

// ProfileDetail changes:
export interface ProfileDetail extends ProfileBase {
  services: ProfileService[];
  maxDevicesPerUser: number;
  nextUidNumber: number;
  uidRangeStart: number;
  uidRangeEnd: number;
  // xmpp/sip flat fields REMOVED
}

// ProfileListItem changes:
export interface ProfileListItem extends ProfileBase {
  services: { serviceType: string; enabled: boolean }[];
  usageStats: ProfileUsageStats;
  // xmppEnabled/sipEnabled flat fields REMOVED
}
```

**`ConfigTab.tsx`:**
- Replace hardcoded XMPP/SIP + UC Services section with dynamic loop over `profile.services`
- Each service renders its config fields from the JSON shape
- Service-specific icons/colors resolved from `sectionConfig` map

**`profile-type-config.ts`:**
- Remove `uc` section (replaced by per-service entries)
- Keep `xmpp` and `sip` icon configs, make the map extensible via `Record<string, ...>`

**New components:**
- `ServiceCard.tsx` — renders a single service with config fields and enable/disable toggle
- `AddServiceModal.tsx` — attach a new service type to a profile

### What Stays Unchanged
- `config_template_assignments` — profile-to-org linkage
- `config_template_history` — audit trail
- `azblinkProfileId` in LDAP — one profile per user
- `device_provisions` table (from PR 1)

---

## PR 3 — Cleanup & Documentation

### Dead Code Removal
- Remove any orphaned imports referencing deleted SSO/QR types
- Clean up `types/index.ts` re-exports for removed types

### Test Updates
- `test_config_templates.py` — update assertions to use `services` array
- `test_device_provisioning.py` — update profile creation helpers for `add_profile_service()` pattern
- `test_device_provisioning.py` — update enrichment tests for new service model
- `conftest.py` — update profile fixtures
- Add `profile_services` CRUD tests
- Add extensibility test (mock "matrix" service type roundtrips correctly)

### Architecture Documentation
- Update `docs/architecture/README.md` — Profile = Connector section to reflect services model
- Update `CLAUDE.md` if needed (database tables, environment variables)
- Create ARD for profile services restructuring (significant schema change)

### Migration Sequence
- `024_remove_sso_qr.sql` (PR 1)
- `025_profile_services.sql` (PR 2)
- No migration in PR 3 (code-only)
