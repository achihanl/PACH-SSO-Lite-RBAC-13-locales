# Unified Platform Versioning — Design Spec

**Date:** 2026-03-11
**Status:** Approved
**Stack:** git-cliff + commitizen

## Problem

The platform has no unified version management:
- Frontend has `0.1.0` in `package.json` with build-time git hash injection
- Backend has no version at all — no `__version__`, no `/api/version` endpoint
- No git tags, no CHANGELOG, no release process
- Architecture spec is separately versioned at `1.0.0` (unrelated)

## Goals

1. **Deployment traceability** — know exactly what code is running (version + git hash + build time)
2. **Release management** — formal releases with changelogs, git tags, and version bumps
3. **Single version** — one version number for the whole platform (API + UI ship together)

## Tool Stack

| Tool | Role | Install |
|------|------|---------|
| commitizen | Commit validation, version bumps, version file sync | `pip install commitizen` |
| git-cliff | Changelog generation from git history | System binary (cargo/brew/snap) |
| pre-commit | Hook framework for commit-msg validation | `pip install pre-commit` |

**Why not semantic-release?** Pulls in 6 npm plugins, less customizable changelogs, no commit enforcement, CI-coupled. git-cliff + commitizen are composable Unix tools that fit the Python+TS monorepo naturally.

## Version Source of Truth

Root `package.json` holds the canonical version. Commitizen syncs to all locations atomically during `cz bump`.

| File | Field | Consumer |
|------|-------|----------|
| `package.json` (root) | `"version"` | Canonical source |
| `src/frontend/package.json` | `"version"` | npm workspace consistency |
| `src/backend/_version.py` | `__version__` | Backend runtime import |

**Starting version:** `0.2.0` — marks the unification as a minor release.
**Tag format:** `v0.2.0`

## Commitizen Configuration

File: `.cz.toml`

```toml
[tool.commitizen]
name = "cz_conventional_commits"
version = "0.2.0"
tag_format = "v$version"
version_files = [
    "package.json:version",
    "src/frontend/package.json:version",
    "src/backend/_version.py:__version__"
]
update_changelog_on_bump = false
```

- `update_changelog_on_bump = false` — git-cliff owns the changelog
- `version_files` — all three locations bumped atomically
- Conventional commit types: `feat`, `fix`, `docs`, `perf`, `refactor`, `style`, `test`, `chore`

## Pre-commit Hook

File: `.pre-commit-config.yaml`

```yaml
repos:
  - repo: https://github.com/commitizen-tools/commitizen
    rev: v4.2.2
    hooks:
      - id: commitizen
        stages: [commit-msg]
```

Validates every commit message (manual, Claude Code, CI) against conventional commit format.

## git-cliff Configuration

File: `cliff.toml`

```toml
[remote.github]
owner = "KeithMoc"
repo = "azb-azblink-directory-and-identity-stack"

[changelog]
header = """
# Changelog

All notable changes to AZBlink Directory are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/).

"""
body = """
{% if version %}\
    ## [{{ version | trim_start_matches(pat="v") }}] - {{ timestamp | date(format="%Y-%m-%d") }}
{% else %}\
    ## [Unreleased]
{% endif %}\
{% for group, commits in commits | group_by(attribute="group") %}
    ### {{ group | upper_first }}
    {% for commit in commits %}
        - {% if commit.scope %}**{{ commit.scope }}:** {% endif %}\
            {{ commit.message | split(pat="\n") | first | upper_first }}\
            {% if commit.github.pr_number %} \
                ([#{{ commit.github.pr_number }}](https://github.com/{{ remote.github.owner }}/{{ remote.github.repo }}/pull/{{ commit.github.pr_number }}))\
            {% endif %}\
    {% endfor %}
{% endfor %}
"""
footer = ""
trim = true

[git]
conventional_commits = true
filter_unconventional = true
commit_parsers = [
    { message = "^feat", group = "Features" },
    { message = "^fix", group = "Bug Fixes" },
    { message = "^doc", group = "Documentation" },
    { message = "^perf", group = "Performance" },
    { message = "^refactor", group = "Refactor" },
    { message = "^style", group = "Styling" },
    { message = "^test", group = "Testing" },
    { message = "^chore\\(release\\)", skip = true },
    { message = "^chore", group = "Miscellaneous" },
]
protect_breaking_commits = false
filter_commits = false
tag_pattern = "v[0-9].*"
sort_commits = "oldest"

[bump]
features_always_bump_minor = true
breaking_always_bump_major = true
initial_tag = "v0.2.0"
```

## Backend Integration

**New file:** `src/backend/_version.py`
```python
"""Platform version — updated by commitizen during `cz bump`."""
__version__ = "0.2.0"
```

**New endpoint:** `GET /api/version` (public, no auth)
```python
{
    "version": "0.2.0",
    "gitHash": "df905f3",
    "gitBranch": "main",
    "buildTime": "2026-03-11T10:30:00Z"
}
```

Git hash/branch/build time from env vars (already exported in Justfile, passed as Docker build args).

**Modified:** `/api/health` gains a `version` field.

## Frontend Integration

**One-line change** in `vite.config.ts`:
```diff
- import pkg from './package.json'
+ import pkg from '../../package.json'
```

Everything downstream (`version.ts`, sidebar, SystemInfoSection) is unchanged.

## Justfile Commands

```just
# Show current platform version
version:
    @node -p "require('./package.json').version"

# Guided conventional commit (interactive TUI)
cz-commit:
    cz commit

# Preview next version bump (dry run)
release-dry:
    cz bump --dry-run && git-cliff --bump --unreleased

# Bump version + generate changelog + tag
release:
    cz bump --yes && git-cliff -o CHANGELOG.md && git add CHANGELOG.md && git commit --amend --no-edit
```

## Release Workflow

```
1. Develop on feature branch with conventional commits
2. PR merges to main
3. When ready to release:
   just release-dry              # preview
   just release                  # bump + changelog + tag
   git push origin main --tags   # push tag
```

`just release` produces one commit (version bump + changelog) tagged `v0.3.0`.

## Optional CI: GitHub Release on Tag Push

File: `.github/workflows/release.yml`

```yaml
name: Release
on:
  push:
    tags: ['v*']

jobs:
  release:
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - uses: orhun/git-cliff-action@v4
        id: changelog
        with:
          config: cliff.toml
          args: --latest --strip header
      - uses: softprops/action-gh-release@v1
        with:
          body: ${{ steps.changelog.outputs.content }}
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

## Files Created

| File | Purpose |
|------|---------|
| `cliff.toml` | git-cliff config |
| `.cz.toml` | commitizen config |
| `.pre-commit-config.yaml` | commit-msg validation hook |
| `src/backend/_version.py` | Backend version (commitizen-managed) |
| `CHANGELOG.md` | Generated changelog |
| `.github/workflows/release.yml` | GitHub Release on tag push |

## Files Modified

| File | Change |
|------|--------|
| `package.json` (root) | Add `"version": "0.2.0"` |
| `src/frontend/package.json` | Sync version to `0.2.0` |
| `src/frontend/vite.config.ts` | Import from root `package.json` |
| `src/backend/main.py` | Add `/api/version`, add `version` to `/api/health` |
| `Justfile` | Add versioning commands |

## Dev Machine Setup

```bash
pip install commitizen pre-commit
cargo install git-cliff  # or: brew install git-cliff
pre-commit install --hook-type commit-msg
```
