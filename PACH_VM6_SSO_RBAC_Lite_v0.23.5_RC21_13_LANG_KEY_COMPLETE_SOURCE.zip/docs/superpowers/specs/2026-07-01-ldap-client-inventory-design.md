# LDAP Client Inventory & Acknowledgement — Design

- **Date:** 2026-07-01
- **Surface:** `/configuration/settings` page + backend collector
- **Goal (C — both):** operational inventory of clients using the platform's OpenLDAP **and** flag-and-acknowledge unknown ones.
- **Status:** design approved (Sections A + B); pending spec review → implementation plan.

## Problem

External LDAP clients bind **directly** to the platform's OpenLDAP, bypassing the Directory API:

- **UED / PED80** — XMPP SASL bind as `uid=…` (identity + XMPP SASL-PLAIN/DIGEST).
- **Asterisk** — SIP realtime reads (frequent, sub-millisecond binds).
- **Directory API** — binds as `cn=admin` for CRUD.
- **Compose healthcheck** — binds `cn=admin` from localhost every 5s.

The API cannot observe direct binds at the application layer. Only OpenLDAP itself sees them. Admins have no way to answer "which clients are connected to my LDAP, and is any of them unexpected?"

## Verified findings (empirical, `osixia/openldap:1.5.0`)

| Source | State | Yields | Sees external clients | API-accessible |
|---|---|---|---|---|
| slapd stats log | ✅ live (osixia runs `slapd -d 256`) | `conn=N ACCEPT from IP=…`, `BIND dn="…" mech=…`, `closed` — IP + DN + timestamps, **historical** | ✅ | ⚠️ needs docker socket for `docker logs` |
| `cn=Monitor` backend | ❌ not configured; `back_monitor.so` **present** → enable-able | live connections snapshot, **no history** | ✅ | ✅ LDAP query |
| API-side bind tracking | n/a | API-initiated binds only | ❌ | — |

**Key verified enabler:** `olcLogFile: /var/lib/ldap/slapd-stats.log` (set via `ldapmodify` on `cn=config`, bind `cn=admin,cn=config`) redirects stats to a **file on the `azblink_ldap_data` volume**. The API mounts that volume **read-only** and tails it — **no docker socket required**. Confirmed lines carry both source IP (ACCEPT) and bind DN (BIND), correlatable by `conn=N`.

Config facts: default `olcLogLevel` in `cn=config` = `none`, but runtime `-d 256` overrides it → stats always flow. Databases present: `{-1}frontend`, `{0}config`, `{1}mdb`. Modules loaded: `back_mdb`, `memberof`, `refint`, `ppolicy` (no `back_monitor`, but the `.so` exists).

## Chosen approach — Log-tailing collector (Approach 1)

Rejected alternatives:
- **`cn=Monitor` poller** — misses sub-poll binds (Asterisk realtime) → false "all clear" on exactly the clients worth flagging; no history.
- **Hybrid (log + Monitor)** — Monitor near-redundant: log ACCEPT/`closed` already yields "currently connected" (session seen, no close yet).

## Architecture

```
slapd (-d 256) --olcLogFile--> /var/lib/ldap/slapd-stats.log  (azblink_ldap_data volume)
                                          │  (RO mount into API container)
                                          ▼
  ldap_activity.py  ── tail+offset ──> parse conn=N (ACCEPT→BIND→closed) ──> classify (dn,ip)
                                          │
                                          ▼
                              Postgres  ldap_clients  (upsert by (bind_dn, source_ip))
                                          │
                     GET/PATCH/DELETE /api/settings/ldap/clients  (admin-only)
                                          │
                    Settings page "LDAP Clients" table (badges + Acknowledge)
```

### A1. Capture (slapd)
- Bootstrap `olcLogFile: /var/lib/ldap/slapd-stats.log` via a **dedicated config ldif** applied on first boot (osixia bootstrap), so it survives `just reset` (config-db wipe).
- Log level unchanged (`256` via runtime `-d`).
- **Prod parity task:** apply the same `olcLogFile` in `deploy/ansible/` OpenLDAP config (dev compose ≠ prod).

### A2. Storage — `ldap_clients` (migration `028`)

| col | type | note |
|---|---|---|
| `id` | BIGSERIAL PK | |
| `bind_dn` | TEXT | `""` = anonymous |
| `source_ip` | INET | from ACCEPT line |
| `service` | TEXT | auto: `api\|asterisk\|xmpp\|healthcheck\|unknown` |
| `status` | TEXT | admin: `unknown\|acknowledged\|blocked` |
| `label` | TEXT | admin-set name |
| `first_seen` / `last_seen` | TIMESTAMPTZ | |
| `session_count` | BIGINT | +1 per ACCEPT |
| `last_bind_mech` | TEXT | `SIMPLE\|PLAIN\|DIGEST-MD5` |
| `acknowledged_by` / `acknowledged_at` | TEXT / TIMESTAMPTZ | |
| | | `UNIQUE(bind_dn, source_ip)` |

"Currently connected" is **derived from collector in-memory open-conn map**, not stored.

### A3. Collector — `src/backend/ldap_activity.py` (new module)
- Background asyncio task (pattern precedent: `activity_bus.py`).
- Tails `slapd-stats.log`, tracks byte offset (resume across restart); truncation-safe (reset offset if file shrinks).
- In-memory `conn_id → {ip, dn, mech, connect_ts}`: `ACCEPT` seeds IP; `BIND` fills DN/mech; `closed` → upsert row (`last_seen`, `session_count += 1`) + drop from map.
- Rationale for new module: `ldap_client.py` is CRUD-focused; a log tailer + parser + classifier is a distinct concern.

### A4. Classification
- Ordered rule list `(service, dn_regex, optional ip/CIDR)`, seeded defaults, no match → `unknown` (the flag target).
- v1: constants in `ldap_activity.py` + env override for known service subnets (dynamic container IPs → match `DN + CIDR`, not exact IP).
- `localhost + cn=admin` → `healthcheck` (hidden by default).

### B1. API (in `main.py`, admin-only via existing auth dep)
- `GET /api/settings/ldap/clients` → rows + derived `connected_now` + summary counts; filters `?status=` / `?service=`.
- `PATCH /api/settings/ldap/clients/{id}` → `{status?, label?}`; acknowledge = `status:"acknowledged"`, sets `acknowledged_by` (OIDC claims) + `acknowledged_at`.
- `DELETE /api/settings/ldap/clients/{id}` → forget stale/rotated entry.

### B2. Frontend — fill placeholder `configuration/settings/index.tsx`
- New query hook `lib/queries/ldap-clients.ts` (`useLdapClients`, `useUpdateLdapClient`), `refetchInterval ~12s`.
- New feature component: table — Service badge · Label/Bind DN · Source IP · Last seen · Sessions · Status badge · `●` connected dot · **Acknowledge** action.
- Badge map: unknown→`warning`, acknowledged→`success`, blocked→`error`, healthcheck→`muted`.

## Error handling / edge cases
- **Healthcheck noise** → classify + hide by default.
- **SASL two-step (XMPP)** — `BIND … mech=DIGEST-MD5` then authzDN in follow-up; parser must capture final authenticated DN, not `dn=""`. Verify vs real UED bind during impl.
- **Dynamic container IP** — classify by `DN + CIDR`, env override.
- **Log absent / volume unmounted / perms** — collector warns + retries; endpoints return empty list, never 500; must not block API startup.
- **Rotation/growth** — offset-tracking + truncation-safe. Unbounded growth = **v1 follow-up** (logrotate/periodic truncate), flagged not silently dropped.
- **Anonymous bind** (`dn=""`) → shown, `unknown`.

## Testing
- **Unit (`tests/unit/`, Docker-free):** parser fed sample lines (ACCEPT / simple BIND / SASL / anonymous / `closed` / rotation) → assert session tuples + classification. Highest-value (parser = fragile part).
- **Integration (real stack):** bind as `cn=admin` / a `uid` user / anonymous → assert rows + classification + `connected_now` toggle; PATCH → status flips.
- Project rule: one test at a time, 100% green before the next.

## New files
- `migrations/028_ldap_clients.sql`
- `src/backend/ldap_activity.py`
- `deploy/dev/ldap/<olcLogFile-config>.ldif` (bootstrap)
- `src/frontend/src/lib/queries/ldap-clients.ts`
- 1 frontend feature component (LDAP clients table)
- `tests/unit/test_ldap_activity_parser.py`
- `tests/test_ldap_clients.py`
- (edits: `main.py`, `configuration/settings/index.tsx`, `docker-compose.yml` RO volume mount, `deploy/ansible/` prod parity)

## Follow-ups (out of v1 scope, flagged)
- Log rotation/truncation strategy (logrotate sidecar or collector-driven).
- Optional `cn=Monitor` live view (only if a true real-time panel is later wanted).
- Ansible prod-parity `olcLogFile`.

## Open items to verify during implementation
- Exact SASL bind log shape for a real UED/XMPP bind (authzDN capture).
- Whether osixia config bootstrap accepts an added `olcLogFile` ldif vs needing a `command:` step.
- Existing `/api/settings` route/response conventions in `main.py` to match.
