# UED SIP Configuration + Web-SSO SIP RING E2E — Design Spec

- Date: 2026-04-17
- Author: Claude (autopilot)
- Terminal artifact: `docs/reports/2026-04-17-sip-sso-e2e-report.md`
- Supersedes: —
- Related:
  - `playbooks/web-configure/azblink-server-ldap-client.yml` (sister playbook; AD/LDAP user auth)
  - `docs/knowledge/patterns/ued-xmpp-ldap-client-integration.md` (XMPP precedent — 2026-04-15 validated)
  - `tests/test_xmpp_e2e.py`, `tools/e2e_xmpp_notebook.py` (mirrors for SIP)

## 1. Goal

Configure UED PED80 (192.168.122.220:8082) to:
- Bind SIP account lookups to the platform OpenLDAP using the AsteriskPjsip* schema already on each user entry.
- Seed a minimal dial plan so extension-to-extension calls route inside UED.
- Start the VoIP process so SIP port 5060 is open.

Then validate end-to-end that a Web-SSO-provisioned client can:
- Acquire sealed SIP credentials via `POST /api/provision/device`.
- REGISTER against UED SIP (proving UED's LDAP-client auth path accepts platform-stored `AstAuthPassword`).
- INVITE peer and receive a `SIP/2.0 180 Ringing` (proving dial plan routes + SIP digest auth closes the loop).

The terminal deliverable is a single report documenting the full chain pass/fail with evidence.

## 2. Scope

Bundled into one autopilot execution per user instruction (2026-04-17 "one combined — these must go together"):

| Part | Output | Sister to |
|---|---|---|
| A. Patrol investigation | `qa/patrol/issues/2026-04-17-azblink-server-sip-config-navigation-route.yml` (single file covering SIP-in-LDAP + Dial Plan pages) | `2026-04-10-…-ldap-client-navigation-route.yml` |
| B. Combined web-configure playbook | `playbooks/web-configure/azblink-server-sip-config.yml` | `azblink-server-ldap-client.yml` |
| C. SIP RING e2e test | `tests/test_sip_ring_e2e.py` + optional `tools/e2e_sip_notebook.py` | `tests/test_xmpp_e2e.py` + `tools/e2e_xmpp_notebook.py` |
| D. Final report | `docs/reports/2026-04-17-sip-sso-e2e-report.md` | — |

Explicitly out of scope:
- No UI work in `src/frontend`.
- No backend route changes (SSO provisioning already returns sealed SIP creds per memory 4296 / 4390).
- No LDAP schema edits (AstAuthPassword/AstEndpointAors/AstAuthRealm already populated on both test users).
- No XMPP changes (separate validated track).

## 3. Architecture

```
┌──────────────────────────────┐                    ┌──────────────────────────────┐
│  SIP client A (alanl)        │                    │  SIP client B (xmpptest01)   │
│  pytest/asyncio, raw-UDP SIP │                    │  pytest/asyncio, raw-UDP SIP │
└────────────┬─────────────────┘                    └────────────┬─────────────────┘
             │ 1. REGISTER sip:alanl@<UED>                       │ 1. REGISTER
             │ 3. INVITE sip:xmpptest01@<UED>                    │ 4. receives INVITE
             │ 5. receives 180 Ringing  ◄───┐                    │ 5. responds 180
             ▼                              │                    ▼
     ┌──────────────────────────────────────┴─────────────────────────────┐
     │  UED PED80 VM  192.168.122.220                                     │
     │    :5060/UDP  SIP (enabled via Start-VoIP-Process toggle)           │
     │    :8082/HTTP admin panel (Phone » Basic » SIP in LDAP / Dial Plan) │
     └──────────────────────────────────┬─────────────────────────────────┘
                                        │ LDAP bind (configured via playbook)
                                        ▼
                             ┌──────────────────────────────┐
                             │  platform OpenLDAP :1390     │
                             │  base: dc=azblink,dc=com     │
                             │  entries: inetOrgPerson +    │
                             │    posixAccount +            │
                             │    AsteriskPjsipEndpoint/Auth/Aor │
                             └──────────────────────────────┘
```

Note: UED's LDAP reachability to the platform is already proven (AD/LDAP user-auth playbook ran clean 2026-04-10 against `192.168.4.111:1390`). This spec reuses the same bind DN / password; only the SIP-in-LDAP form's *schema mapping* differs.

## 4. Playbook design (combined, one YAML)

File: `playbooks/web-configure/azblink-server-sip-config.yml`

Phase layout:

| Phase | Purpose | Approach |
|---|---|---|
| `auth` | Log in to UED as admin | Copy from AD/LDAP playbook — same POST target, same CAPTCHA bypass |
| `navigate` | Reach Phone » Basic » SIP in LDAP, then Phone » Basic » Dial Plan | Two nav targets under one phase (chained) |
| `discover` | Fingerprint both forms | Two `forms:` entries; field IDs + AJAX endpoints + hidden `action=`/`active=` |
| `configure` | 3 operations: set SIP-in-LDAP, set dial plan, restart VoIP | See below |
| `verify` | Re-read forms + confirm SIP:5060 opens | curl re-GET + TCP probe + optional LDAP search via UED's search form |

Configure operations (ordered, idempotent):

1. **configureSipInLdap** — POST the SIP-in-LDAP form with:
   - LDAP host: `${LDAP_HOST}` (default `192.168.122.1:1390` — libvirt NAT gateway is more stable than host LAN IP)
   - Base DN: `${LDAP_BASE_DN}` (`dc=azblink,dc=com`)
   - Bind DN: `${LDAP_BIND_DN}` / bind password: `${LDAP_BIND_PW}`
   - Filter / attr mapping: placeholders until patrol-investigate reveals form fields. Expected schema mapping per AsteriskPjsip:
     - username attr → `AstAuthUsername` (falls back to `uid`)
     - password attr → `AstAuthPassword`
     - context attr → `AstEndpointContext`
     - objectClass filter → `(objectClass=AsteriskPjsipEndpoint)`
2. **configureDialPlan** — POST the dial-plan form with a single permissive internal pattern `_[2-9]XXX` (4-digit, not starting with 0/1 to avoid PSTN/emergency collisions). Context = `from-internal` (matches `AstEndpointContext` on both users).
3. **restartVoipProcess** — toggle "Start VoIP Process" OFF+Submit, then ON+Submit.

Variables (all in `.env` or prompted):

| Var | Secret | Default | Source |
|---|---|---|---|
| `SERVER_URL` | no | `http://192.168.122.220:8082` | from virsh dhcp lease |
| `ADMIN_USER` | no | `admin` | patrol issue 2026-04-10 |
| `ADMIN_PASS` | yes | — | `.env` (currently not present — will add as `UED_ADMIN_PASSWORD=admin123`) |
| `LDAP_HOST` | no | `192.168.122.1:1390` | libvirt NAT gateway |
| `LDAP_BASE_DN` | no | `dc=azblink,dc=com` | CLAUDE.md |
| `LDAP_BIND_DN` | no | `cn=admin,dc=azblink,dc=com` | CLAUDE.md |
| `LDAP_BIND_PW` | yes | — | `.env` `LDAP_BIND_PW=adminpassword` (already present) |
| `DIAL_PATTERN` | no | `_[2-9]XXX` | choice rationale §5 |
| `DIAL_CONTEXT` | no | `from-internal` | matches LDAP `AstEndpointContext` |

## 5. Dial-plan rule choice

Considered options (ranked):

| # | Pattern | + | − | Probability I'd pick |
|---|---|---|---|---|
| y | `_[2-9]XXX` | Avoids 0 (outbound prefix), 1 (emergency/PSTN), works for both `alanl` (length 5) and `xmpptest01` (length 10) — **wait, these usernames aren't numeric**. Need to reconsider: SIP usernames and dial patterns are separate concepts. The dial pattern only matters if the caller dials a *number*. INVITE target will be `sip:xmpptest01@<UED>` which routes by username match on registered AOR, not via dial plan pattern. | Dial plan may be unnecessary for username-based INVITE | 55% |
| y2 | `_.` (match anything) | Certainly permissive | Too broad for anything other than dev | 15% |
| x | no dial plan rule; rely on UED's default "match registered AOR" behavior | Minimal surface | May fail if UED's default context requires an explicit rule | 20% |
| z | full classes (emergency/PSTN/internal) | Realistic | Out of scope; creates more failure modes | 10% |

**Decision (autopilot):** Start with option **y2 (`_.`, match-any under `from-internal`)** to minimize dial-plan as a failure variable, since the test's failure mode we care about is *SIP LDAP auth*, not *dial-plan parsing*. If UED rejects `_.`, fall back to `_[2-9]XXXXXXXXXX` (broad 4–11 digit rule). Document the fallback in the plan.

## 6. SIP RING e2e test

File: `tests/test_sip_ring_e2e.py` (pytest, follows `test_xmpp_e2e.py` pattern).

**SIP client strategy — pure-Python raw UDP SIP**:

Considered alternatives (ranked):

| # | Approach | + | − | Prob. |
|---|---|---|---|---|
| α | Raw UDP SIP hand-crafted (stdlib) | Zero deps; full transparency; easy to trace in report; matches "raw" XMPP pattern (slixmpp for XMPP was the minimal choice there) | Must implement MD5 digest ourselves (~20 LoC) | **70%** |
| β | `aiosip` library | Higher-level | Not installed; async model adds complexity | 15% |
| γ | SIPp binary + pysipp wrapper | Industry standard | Needs `sudo apt install sip-tester`; XML scenarios add ceremony | 10% |
| δ | pjsua2 Python bindings | Production-grade | Heavy install, Asterisk-coupled | 5% |

**Decision (autopilot): α.** Implementation sketch:

1. Two helper functions, `register(user, pwd, ued)` and `invite(caller, peer, pwd, ued)`, both speaking UDP 5060.
2. REGISTER sends initial with no auth → expects 401 Unauthorized with `WWW-Authenticate: Digest realm="asterisk", nonce="…"`; computes `MD5(MD5(user:realm:pwd) + ":" + nonce + ":" + MD5(method:uri))`, retries → expects 200 OK.
3. INVITE follows identical challenge/response; success signal = receive `SIP/2.0 180 Ringing` within 10s timeout (don't need ACK or 200 OK for this test).
4. Both SIP clients run in the same pytest test but with different local UDP ports.

Test structure:

```python
def test_sip_ring_via_sso_provisioning(client):
    # 1. Two Web-SSO-ish provisions via DEV_AUTH_TOKEN path (skip OIDC UI — use backend fixture)
    kit_a = provision(client, user="alanl", device_id="test-ring-alanl")
    kit_b = provision(client, user="xmpptest01", device_id="test-ring-xmpptest01")
    # 2. REGISTER both
    reg_a = sip_register("alanl", kit_a["sipPassword"], UED_IP)
    reg_b = sip_register("xmpptest01", kit_b["sipPassword"], UED_IP)
    assert reg_a.status == 200 and reg_b.status == 200
    # 3. INVITE a -> b, expect 180
    ring = sip_invite_expect_180("alanl", "xmpptest01", kit_a["sipPassword"], UED_IP, timeout=10)
    assert ring.status == 180
```

Note: Spec 2 was originally proposed as a separate doc; autopilot folded it here because both specs share the same preconditions and the e2e is a no-op if the playbook hasn't run first.

## 7. Success criteria

- Playbook run writes SIP-in-LDAP config, dial-plan rule, and toggles VoIP process; re-read confirms persistence; final screenshot captured.
- `timeout 2 bash -c "</dev/udp/192.168.122.220/5060"` succeeds after playbook (or equivalent UDP probe).
- `tests/test_sip_ring_e2e.py::test_sip_ring_via_sso_provisioning` passes in CI-less local pytest run.
- Report documents every phase with commands, outputs, and pass/fail.

## 8. Alternatives / paths not taken (transparency)

- Did NOT patrol each page separately (β from my earlier Q) — combined single issue per user decision α.
- Did NOT implement SIP digest via `pysipp`/`sipp` binary — kept pure-Python to avoid `apt install` sudo prompt.
- Did NOT wire the e2e into the Playwright smoke suite (`web-sso-provision-ref.smoke.spec.ts`). Reason: SIP is UDP + digest — not a browser concern. Playwright smoke already validates SSO+provision; adding raw-UDP SIP to it would mix layers.
- Did NOT split into separate playbooks `sip-in-ldap.yml` + `dial-plan.yml` + `voip-restart.yml` per user's "one combined — these must go together" directive.
- Did NOT use the SSO OIDC flow interactively — provisioning fixture uses DEV_AUTH_TOKEN path. This is honest: the e2e validates *LDAP-backed SIP auth*, not *OIDC browser flow* (XMPP e2e did the same).

## 9. Blind spots / unknowns (to be resolved during patrol-investigate)

- Form field IDs on Phone » Basic » SIP in LDAP page — unknown until patrol runs.
- Form field IDs on Phone » Basic » Dial Plan page — unknown.
- Where exactly "Start VoIP Process" checkbox lives (Dial Plan page or sibling VoIP service page).
- Whether SIP-in-LDAP form exposes attribute-mapping fields, or expects a pre-wired AsteriskPjsip schema by convention.
- Whether UED SIP listens on 5060 UDP or also 5060 TCP.
- Whether SIP REGISTER against UED requires the LDAP-bind path to succeed on *first* REGISTER (cold cache) — may need a warm-up.

## 10. Risks

- **Admin password**: `admin123` inferred from patrol issue. If wrong, playbook fails in auth phase — report will flag and stop.
- **LDAP host from UED**: `192.168.122.1:1390` libvirt gateway. If UED iptables blocks, fall back to `192.168.4.111:1390`.
- **VoIP restart side effects**: flips may drop existing SIP sessions on UED (none expected in dev).
- **Pure-Python SIP digest**: MD5 on modern OpenSSL may warn; implement via `hashlib.md5(usedforsecurity=False)`.
- **Dial plan pattern rejected**: fallback path documented in §5.

## 11. Open questions explicitly deferred

- Whether to promote the playbook navigation flow into `qa/patrol/manifest.yml` — yes, as follow-up after verify succeeds (not blocking report).
- Whether to add an ARD documenting the UED-LDAP SIP integration (parallel to the XMPP pattern knowledge doc). Deferred.
