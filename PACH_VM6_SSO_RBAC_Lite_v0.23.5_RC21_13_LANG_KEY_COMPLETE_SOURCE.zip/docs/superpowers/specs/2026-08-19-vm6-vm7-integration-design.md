# AZBlink Directory (VM6) — VM6 ⇄ VM7 integration: derived specification and design

**Date:** 2026-08-19
**Status:** **approved 2026-08-19** — VM6's spec-of-record for this integration (master `REVIEW-2026-08-19.md`); pins re-derived to master 1.0.1 the same day (no contract literal changed; §3.3 409 guard, §3.10 sync value, §9.3 X-7). Implementation plan: `docs/superpowers/plans/2026-08-19-vm6-vm7-integration.md`.
**Scope:** this repository only (VM6 — the producer). A *derivation* of the cross-VM master in `azb-unified-ecosystem`: it restates only what binds this repo and designs how this repo meets it.
**Author:** derived by the estate PM session, 2026-08-19
**Companion:** `azb-document-share-adapter` carries the mirror document for VM7, same section skeleton.

## 0. Reading rule and provenance

Derives from: INTEGRATION-SPEC **1.0.1** (`azb-unified-ecosystem/integration/vm6-vm7/INTEGRATION-SPEC.md` · https://claude.ai/code/artifact/061108f7-9fed-4672-809c-2ad24c36f3f1), DEPLOYMENT-PLAN **1.0.1** (`…/DEPLOYMENT-PLAN.md` · https://claude.ai/code/artifact/b7ec1d20-c2c8-4892-8fd2-4294901508c4), decisions D1–D6 / D-withdraw / D-key (`…/decisions/`).

**Pin table** — update as one unit (§10):

| Bound | Pin |
|---|---|
| This repo | `azb-azblink-directory-and-identity-stack` @ `2a31343` (spec 1.13.0, §08 v1.9.0) |
| Peer | `azb-document-share-adapter` @ `ee26e7d` (0.12.1, contract 1.9) |
| Master | INTEGRATION-SPEC 1.0.1 · DEPLOYMENT-PLAN 1.0.1 (2026-08-19) |

**The master wins on conflict.** The fix is a change request against `azb-unified-ecosystem/integration/vm6-vm7/` — an issue naming the master § and the disputed value — never a local reinterpretation. Contract literals here are copied verbatim and MUST NOT be paraphrased.

**Claim markers:** `[V]` verified in this repo at the cited `file:line`; `[I]` inferred, with the settling check named; `[R]` reported by the master or another host document. **Words:** MUST / MUST NOT / SHOULD per RFC 2119.

## 1. This repository's role in the contract

VM6 is the **producer** — sole source of accounts and browser identity for VM7. Three existing surfaces carry it:

- **Directory Consumer Contract** — `docs/architecture/spec/08-integration-points.md` §2, the published statement of what an LDAP relying party must be configured with `[V] 08-integration-points.md:79-98`.
- **Provisioned clients (ARD-006)** — `cn=<id>,ou=clients,dc=azblink,dc=com`, read-minus-secrets `[V]`.
- **Authentik LDAP source (ARD-007)** — maps `openldap-uid` → username, which is what makes OIDC `preferred_username` equal the directory `uid` `[V] seed_authentik.py:376-419`.

**The invariant** (master §1, §3.1): *Nextcloud user ID == directory `uid` == conversation member identifier.* **Channels** (master §3, §6): **A — identity** (LDAP read + OIDC login), VM6 produces, VM7 consumes. **B — context assertion** (`RS256` JWT, `typ == ucchat_context`), VM7 owns, signed by its committed ucChat stand-in. **VM6 owns A end to end and has no part in B** — an OAuth2 provider cannot mint that assertion, and the 2026-08-10 decision pointing VM7's JWKS at this Authentik is withdrawn. VM6's residual obligation is to say so in its own spec (VM6-9).

## 2. Obligations derived from the master

### 2.1 Interfaces this repo publishes

| Concern | Value | Master § |
|---|---|---|
| People subtree | `ou=people,dc=azblink,dc=com`, flat, `objectClass: inetOrgPerson` | §3.1 |
| Account identifier | `uid`, equal to OIDC `preferred_username` | §3.1 |
| Display name | `cn` — VM6 writes no LDAP `displayName` on any path | §3.1 |
| Groups | `cn=<group>,ou=groups,…`, `groupOfNames`, association by `member` | §3.1 |
| Mapping key | `entryUUID`, readable by the bind client | §3.1, §3.11 |
| Account state | `pwdAccountLockedTime` — the sentinel only | §3.3 |
| Bind identity for VM7 | `cn=nextcloud,ou=clients,dc=azblink,dc=com` | §3.4 |
| LDAP endpoint | `ldap://<vm6_ip>`, port **1390**, plaintext | §3.5 |
| OIDC discovery | `http://<vm6_ip>:9000/application/o/nextcloud/.well-known/openid-configuration` | §3.5 |
| SSO latency bound | ≤ the Authentik LDAP source sync interval — **unpinned today** | §3.10 |

This repo consumes nothing from VM7. VM7 holds no credential on VM6 and gains none (plan Phase 1).

### 2.2 Values table — every literal this repo must carry (verbatim)

| Literal | Value | Master § |
|---|---|---|
| Account-state sentinel | `000001010000Z` | §3.3 |
| Consumer user filter | `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=000001010000Z)))` | §3.3 |
| Consumer login filter | `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=000001010000Z))(uid=%uid))` | §3.3 |
| **Superseded** presence filter | `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=*)))` | §3.3 ("was") |
| uid grammar | `^[a-z0-9][a-z0-9_.-]{0,63}$` | §3.2 |
| Reserved names / prefix | `pach_admin`, `pach_service` / `^pach_` | §3.2 |
| Bind DN | `cn=nextcloud,ou=clients,dc=azblink,dc=com` | §3.4 |
| Ports | LDAP `1390` · LDAPS `1637` · Authentik HTTP `9000` · HTTPS `9443` | §3.5 |
| OIDC slug / client id / type | `nextcloud` / `nextcloud` / **confidential** | §3.7 |
| Redirect URIs (strict) | `https://<pach_nextcloud_host>/apps/user_oidc/code` **and** `https://<pach_nextcloud_host>/index.php/apps/user_oidc/code` | §3.7 |
| Post-logout redirect (type *logout*, strict) | `https://<pach_nextcloud_host>/` | §3.7 |
| Launch URL | `https://<pach_nextcloud_host>/` | plan 1.2 |
| Subject / issuer mode | `sub_mode: hashed_user_id` · `issuer_mode: per_provider` | §3.7 |
| Scope mappings | built-in `openid`, `profile`, `email` **only** | §3.7 |
| Consumer cache bound | `ldapCacheTTL = 600` | §3.8, §3.10 |
| ppolicy | `pwdMaxFailure 5`, `pwdLockoutDuration 300` | §3.3 |

### 2.3 MUST / MUST NOT

1. Publish `000001010000Z` in spec §08 as *the* consumer-visible "treat as gone" value. [§3.3]
2. MUST NOT write any other value to `pwdAccountLockedTime` for that meaning. [§3.3]
3. Write the sentinel on **suspend** as well as terminate, and revoke Authentik sessions **and** tokens on suspend. [§3.3, D5]
4. **Delete** `pwdAccountLockedTime` on unsuspend — not overwrite it. [§3.3, D5]
5. Enforce `^[a-z0-9][a-z0-9_.-]{0,63}$` at create **and** import. [§3.2]
6. Refuse `pach_admin`, `pach_service`, and any uid matching `^pach_`. [§3.2]
7. Compare case **exactly**; MUST NOT fold case. [§3.2]
8. Keep `entryUUID` and `pwdAccountLockedTime` readable by `dn.children="ou=clients"`; if the ACL is rewritten as an `attrs=` enumeration both MUST be listed. [§3.4]
9. Pin and publish the Authentik LDAP source sync interval. [§3.10, N-11]
10. MUST NOT be presented as the Channel B assertion signer, and MUST say so in §08. [§6]
11. Treat `azblink_ldap_data` as **shared state**: a fresh init is a coordinated event with VM7. [§3.11]
12. The re-seed MUST NOT regenerate an existing client secret — VM7's vault is the only copy. [§4, D3]
13. VM6 changes **nothing** for the Option A transport. [§5.2, D1]

### 2.4 Estate posture this document is written against

| Decision | Consequence for VM6 |
|---|---|
| **D1** Option A, plaintext on the VPN-routed private subnet | VM6 code changes: **none**. VM6-11 optional. |
| **D2** Demonstration estate, expiry `<TBD — estate owner>` | The one open field; not this document's to invent. |
| **D3** Automate the Authentik registration in the same pass | VM6-2 by hand first, VM6-3 (+1 d) after. |
| **D4** Production posture before *production*, not before the demonstration | VM6-10 off the critical path. |
| **D5** One sentinel; consumers filter on the value | VM6-4 and VM6-5 required this round. |
| **D6** Direct LDAP login kept beside SSO | ppolicy lockout is the only brute-force control on that path; check 9 exercises it. |
| **D-key** Assertion signing key custody | **Open, unowned.** Not VM6's to close. |

**Production gate** (master §2.a — list only): Option B transport (Appendix C); VM6 converged from a filled prod inventory (VM6-10); stand-in stood down with a real signer (D-key); §3.2 grammar and §3.3 sentinel shipped both sides; the §11 acceptance set green on the real hosts.

## 3. Current state versus obligation (audit as of 2026-08-19)

| # | Obligation (master §) | Today | Verdict |
|---|---|---|---|
| 1 | Sentinel published in §08 (§3.3) | absent from §08; present at `spec/02-component-architecture.md:289` and `openwiki/backend/ldap_client.md:30` `[V]` | ❌ |
| 2 | Value filter published (§3.3) | ⚠ §08 publishes the **superseded presence filter** `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=*)))` at `08-integration-points.md:90`; the "Account is dead" row at `:89` reads `(pwdAccountLockedTime=*)` `[V]` | ⚠ **contradicts master** |
| 2b | …and nowhere else publishes it as current | also `docs/architecture/README.md:24`, `CHANGELOG.md:11,22,64` `[V]` — dated version notes; see §5.4 | ⚠ |
| 3 | Login filter published (§3.3) | §08 publishes none `[V]` | ❌ |
| 4 | Suspend writes the sentinel (§3.3) | `ldap_client.py:1230-1250` writes only `userPassword={SUSPENDED}` + `description=SUSPENDED`; `routers/users.py:556-583` calls no Authentik revocation `[V]` | ❌ |
| 5 | Unsuspend deletes the attribute (§3.3) | `ldap_client.py:1253-1270` resets the password, clears `description`, never touches the attribute `[V]` | ❌ |
| 6 | Terminate writes the sentinel (§3.3) | `ldap_client.py:1162,1165-1226` (`PWD_LOCKED_FOREVER`); `routers/users.py:486-498` calls `terminate_user_access`; pinned by `tests/test_users.py::TestTerminationReachesConsumers` `[V]` | ✅ |
| 7 | uid grammar at create (§3.2) | `schemas/users.py:36` — `min_length=1, max_length=64`, no `pattern` `[V]` | ❌ |
| 8 | uid grammar at import (§3.2) | `routers/users.py:622-625` — uid only stripped, empty rows skipped `[V]` | ❌ |
| 9 | Reserved namespace (§3.2) | `grep -rn "pach_" src/ tests/ docs/ deploy/` → zero `[V]` | ❌ |
| 10 | Existing entries conform (plan 1.3) | demo seed uids `alex james kevin laura mei robert sarah` all conform `[V] deploy/dev/ldap/bootstrap.demo.ldif`; live directory unaudited `[I]` — §5.3's audit settles it | ⚠ unproven on the host |
| 11 | ACL grants `entryUUID` + `pwdAccountLockedTime` (§3.4) | rule `{3}` is `to *` with no `attrs=`, `by dn.children="ou=clients,dc=azblink,dc=com" read` `[V] deploy/dev/ldap/ldap-clients-acl.ldif`; re-applied by `roles/azblink_app/tasks/ldap_source.yml` `[V]` | ✅ (check 8 proves it live) |
| 12 | `cn=nextcloud` provisioned (§3.4) | endpoint `routers/settings.py:189`, CLI `src/cli/directoryctl.py:61-74` both exist; never called `[R]` | ❌ operational |
| 13 | Nextcloud OIDC application (§3.7) | seed creates **one** application, `azblink-directory` `[V] seed_authentik.py:86,577-595`; no `NEXTCLOUD_OIDC_*` keys `[V]` | ❌ |
| 14 | Sync interval pinned and published (§3.10) | `trigger_ldap_sync` fires one-shot, leaves the schedule alone `[V] seed_authentik.py:421-473`. ⚠ two contradicting in-repo claims: `tools/dev-seed-uc-user.py:136` says **2 h**; `tests/test_ldap_source.py:61` names the live crontab `26 */2 * * *`; the master cites ARD-002 for ~5 min | ❌ + ⚠ |
| 15 | "Not an assertion signer" note (§6) | `grep -rni "assertion signer"` → zero `[V]` | ❌ |
| 16 | `federated_user` fixture (§7) | absent from `tests/conftest.py`; `tests/test_oidc_claims.py:33` uses `grouped_authentik_user`, Authentik-native not LDAP-federated `[V]`. Both halves exist separately: `tests/test_ldap_source.py::_trigger_sync_and_wait`, `conftest.authentik_user_factory` `[V]` | ❌ |
| 17 | 1637 honest (§3.5) | `deploy/dev/docker-compose.yml:78` publishes `"${LDAP_PUBLISH_TLS:-0.0.0.0:1637}:636"` with `LDAP_TLS: "false"` at `:72` `[V]` | ⚠ optional |
| 18 | ARD statuses (VM6-13) | ARD-007 `proposed` while the LDAP source **is** the SSO path; ARD-015 `proposed` `[V]` | ❌ / see §5.10 |
| 19 | Prod inventory filled (§2.a item 2) | `inventories/prod/{hosts.ini,group_vars/all/main.yml,vault.yml}.example` only `[V]` | ❌ production gate |

## 4. Work items — this repo's slice of the master gap register (§9.1)

| ID | What | Lands in | Proves | Bucket | Phase | Est | § |
|---|---|---|---|---|---|---|---|
| VM6-1 | Provision `cn=nextcloud,ou=clients` | API call; registry row | 6, 8 | this round | 1.1 | 5 min | 5.1 |
| VM6-2 | Nextcloud OIDC application by hand, §3.7 parameters | Authentik (no repo file) | 1, 4, 12 | this round | 1.2 | 2 h | 5.2 |
| VM6-3 | Fold VM6-2 into the seed as a second env-parameterised application; scoped token | `seed_authentik.py`, `deploy/dev/.env.example`, `tests/unit/test_authentik_seed_app_lookup.py` | re-seed leaves it intact | this round (D3) | Ph 1 +1 d | 1 d | 5.6 |
| VM6-4 | Publish sentinel + value filter in §08 §2 | `spec/08-integration-points.md`, `README.md`, `CHANGELOG.md` | 9 | **required** (D5) | 1.4 | 30 min | 5.4 |
| VM6-5 | Suspend semantics; unsuspend deletes the attribute | `ldap_client.py`, `routers/users.py`, `tests/test_suspend.py` | 11 | **required** (D5) | may follow Ph 5; gates "integrated" | 0.5 d | 5.7 |
| VM6-6 | uid grammar + reserved names at create/import; audit; publish in §08 | `schemas/users.py`, `routers/users.py`, `tools/audit_uid_grammar.py` (new), `tests/contract/openapi.baseline.json`, spec §08 | negative tests + audit report | this round | 1.3 | 0.5 d | 5.3 |
| VM6-7 | Pin the sync schedule in the seed; publish the interval in §08 | `seed_authentik.py`, spec §08 | doc + idempotent seed | hardening | 6.1 | 15 min | 5.8 |
| VM6-8 | `federated_user` fixture; assert `preferred_username == uid` | `tests/conftest.py`, `tests/test_oidc_claims.py` | test green | hardening | 6.1 | 0.5 d | 5.9 |
| VM6-9 | §08 note: Authentik is not an assertion signer | spec §08 §5 | doc | this round (rides VM6-4) | 1.4 | 15 min | 5.5 |
| VM6-10 | Fill `inventories/prod`, converge from it | `deploy/ansible/inventories/prod/**` | verify role green | **production gate** (D4) | — | 1 d | 5.13 |
| VM6-11 | Stop publishing 1637 (optional); TLS half | dev `.env`; (TLS) compose + a new ARD | 2 over TLS | **optional** / prod gate | Ph 2 | 0 / 0.5–1 d | 5.11 |
| VM6-12 | Backfill `memberOf` | one-off rewrite | next consumer's default works | **deferred** | — | 0.5 d | 5.13 |
| VM6-13 | ARD-007 / ARD-015 status → accept or amend | `decisions/`, `docs/architecture/README.md` | doc | hardening | 6.1 | 0.5 h | 5.10 |
| X-2 | Identifier-space contract, VM6 half | VM6-8 | 10 | this round / later | 6.1 | — | 5.9 |
| X-3 | `entryUUID` stability / re-init protocol | no VM6 code — operational | walkthrough | done (master §3.11) | day-two D2-3 | — | 6 |
| X-4 | Estate CA custody | cross-repo decision record | doc | production gate | — | 15 min | 5.13 |
| X-6 | Key custody for a real signer | not VM6's | — | open, unowned | — | — | 5.13 |

### 4.1 Repo hygiene found during derivation (facts only; not integration scope)

| ID | Finding | Evidence |
|---|---|---|
| H-1 | `pytest.ini:5` names a lab `<private range>` subnet in the `external_network` marker description — a cleartext network detail in a tracked file | `[V]` |
| H-2 | `ARD-015`'s second amendment (2026-08-05) records two host IP literals inline | `[V]` |
| H-3 | `SOP.md § Section Metadata Format` says a section's `version` is the overall spec version at its last edit; in practice they are independent counters (§01 `1.0.0`, §04 `1.1.1`, §06 `1.11.2`, §08 `1.9.0` against a whole-spec 1.13.0). One of the two is wrong | `head -1 docs/architecture/spec/*.md` `[V]` |
| H-4 | The seed bakes a brand hostname into `_DEFAULT_REDIRECT_URIS`, `_DEFAULT_POST_LOGOUT_REDIRECT_URIS` and `meta_launch_url`, and `.env.example` repeats it — the coupling CodeRabbit #1 removed for LAN callbacks | `seed_authentik.py:54-74,592`; `.env.example:108-113` `[V]` |
| H-5 | `GRANT_TYPES` includes `client_credentials` on the brand provider as a test affordance (already in `TODOS.md`). The Nextcloud provider MUST NOT inherit it | `seed_authentik.py:89-94` `[V]` |
| H-6 | Nothing in this repo references `azb-unified-ecosystem`. `docs/architecture/README.md` § Related Documents is the natural home for the pointer | `[V]` |

## 5. Design, per work item

Ordered by plan phase, then master ID. Governance for each is §10.1's table row.

### 5.1 VM6-1 — provision `cn=nextcloud,ou=clients` (§3.4, §4; plan 1.1)

**Obligation.** One provisioned client for VM7: show-once secret, registry row. Operational; no repo change.
- **Who/what.** VM6 admin, with a `system_configuration` token: `POST http://<vm6_host>:8081/api/settings/ldap/clients/provisioned` `{"client_id":"nextcloud","label":"VM7 document share"}` — or `directoryctl ldap-client provision nextcloud`, or `/configuration/ldap-clients` `[V] routers/settings.py:189-215`, `[V] src/cli/directoryctl.py:61-74`.
- **Where the secret goes.** The response carries `client.bind_dn` and `secret`, shown once, never stored on this side `[V] routers/settings.py:212-215`. Straight into VM7's `vault.yml` as `vm6_ldap_bind_password`. VM6 keeps the SSHA hash and the Postgres registry row.
- **What proves it.** Immediately (plan 1.1 = check 8): as `cn=nextcloud,ou=clients,dc=azblink,dc=com`, `ldapsearch` under `ou=people,dc=azblink,dc=com` returns `entryUUID`, `cn`, `mail`, and no `userPassword`/`AstAuth*`. Missing `entryUUID` ⇒ the ACL is not the shipped one: run the `ldap_source` tag and repeat.
- **Risk.** A live `nextcloud` row makes `POST` return 409 `[V] routers/settings.py:194-196`; use `…/rotate`, and carry the new secret to the vault in the same sitting — VM7 binds fail between rotate and converge (plan D2-1).

### 5.2 VM6-2 — the Nextcloud OIDC application, by hand (§3.7; plan 1.2)

**Obligation.** An Authentik application, slug `nextcloud`, §3.7 parameters, created before VM6-3 (D3). Operational; no repo change.
- **Who/what.** VM6 admin in Authentik: OAuth2/OpenID provider `Nextcloud OIDC`, **confidential**, client id `nextcloud`; **invalidation flow** and **signing key** both set — creation fails without the first, JWKS is empty without the second `[V] 08-integration-points.md:35-47`; property mappings = the three built-in `openid`/`profile`/`email` scope mappings **only**; `sub_mode: hashed_user_id`; `issuer_mode: per_provider`; two **strict** redirect URIs (`https://<pach_nextcloud_host>/apps/user_oidc/code`, `https://<pach_nextcloud_host>/index.php/apps/user_oidc/code`) plus one *logout*-type strict entry `https://<pach_nextcloud_host>/`. Application: name `Nextcloud`, slug **`nextcloud`**, launch URL `https://<pach_nextcloud_host>/`.
- **Where the secret goes.** Shown once → VM7 `vault.yml` as `vm6_oidc_client_secret`. **VM7's vault is the only copy** (§4).
- **What proves it.** `…/application/o/nextcloud/jwks/` returns a non-empty `keys` array and discovery resolves (plan Gate 1; checks 1, 4, 12).
- **Risk.** The ID-token audience is the client id `nextcloud`, **not** `pach_assertion_audience` — that is Channel B (§3.7, §6).

### 5.3 VM6-6 — uid grammar and reserved namespace (§3.2; plan 1.3)

**Obligation.** Enforce `^[a-z0-9][a-z0-9_.-]{0,63}$` at create and import; refuse `pach_admin`, `pach_service`, `^pach_`; audit existing entries first; publish in §08.
**Approach.** Three constants in **one** place, a pydantic `pattern=` plus one validator for the reserved set, the same function called from the CSV path, a standalone audit script importing the same constants. *Rejected:* a `validators.py` module — one caller pair does not earn one, and a second definition is the drift this closes. *Rejected:* folding the reserved names into the regex — unreadable, and it cannot give the two failure classes different messages.
**Files.** `src/backend/schemas/users.py`; `src/backend/routers/users.py`; `tools/audit_uid_grammar.py` (new); `tests/contract/openapi.baseline.json` (regenerated); spec §08 (rows in §5.4's sketch).

```python
# Directory consumer contract — the uid grammar and the reserved namespace VM7's
# Nextcloud local accounts occupy. Defined ONCE; the CSV import path, the audit
# tool and the pin test all read these. Master: INTEGRATION-SPEC 1.0.1 §3.2.
UID_PATTERN = r"^[a-z0-9][a-z0-9_.-]{0,63}$"
RESERVED_UIDS = frozenset({"pach_admin", "pach_service"})
RESERVED_UID_PREFIXES = ("pach_",)

def validate_uid(uid: str) -> None:
    """Raise ValueError if `uid` is outside the published grammar or reserved."""
    if not re.fullmatch(UID_PATTERN, uid):
        raise ValueError(f"uid {uid!r} is outside the directory grammar {UID_PATTERN} "
                         "(lowercase ASCII, no '@', 1-64 chars)")
    if uid in RESERVED_UIDS or uid.startswith(RESERVED_UID_PREFIXES):
        raise ValueError(f"uid {uid!r} is in the reserved consumer namespace")

class UserCreateReq(BaseModel):
    uid: str = Field(..., min_length=1, max_length=64, pattern=UID_PATTERN)
    @field_validator("uid")
    @classmethod
    def _uid_not_reserved(cls, v: str) -> str:
        validate_uid(v)          # pattern= already ran; this adds the reserved check
        return v
```


**CSV import — match today's per-row behaviour.** `api_users_import_csv` accumulates `errors.append({"line": idx, "error": str(e), "row": row})` inside a per-row `try` and returns `{"ok": True, "created", "updated", "errors"}` — it does **not** abort `[V] routers/users.py:621-669`. So the check goes **inside** that `try`, one line after the blank-uid skip, and a bad row lands in `errors` like any other:

```python
            uid = (row.get("uid") or "").strip()
            if not uid:
                continue
            validate_uid(uid)          # ➕ raises → caught by the existing row handler
```

Do **not** 422 the whole request: partial success with a per-row error list is the import path's contract.

**The one-time audit (plan 1.3, before Phase 4).** Vehicle: `tools/audit_uid_grammar.py`. *Rejected:* a `directoryctl` subcommand — permanent CLI surface for a one-time job, and `directoryctl` is a thin HTTP client with no import path to the constants, so it would duplicate the regex, which is the defect being closed. The script reads uids from `GET /api/users` with no `limit` (returns the whole directory `[V] routers/users.py:87-108`) using `directoryctl`'s own `API_BASE`/`DEV_AUTH_TOKEN` pair, and imports the three constants from `schemas.users` after setting the four UC env stubs — `config.py` validates them at import `[V] src/backend/config.py:350-368`; copy the four lines from `tests/unit/conftest.py:15-18` and cite it. Report — one line per offending uid, `uid · reason`, then a count; exit 1 if any:

```
$ python tools/audit_uid_grammar.py
uid-grammar audit — 54 entries under ou=people
  Alice.Wong    · outside grammar ^[a-z0-9][a-z0-9_.-]{0,63}$ (uppercase)
  pach_service  · reserved consumer namespace
2 of 54 entries fail. Each needs a named owner before plan Phase 4.
```

**The master's rule (plan 1.3):** ship the validators **only if the audit is clean**; otherwise fix the data first — a validator over dirty data makes those people un-editable through the create path while leaving them in the tree. **Tests.** `tests/unit/test_consumer_contract_pins.py` (§5.12) carries the vectors. `tests/test_users.py` adds one live-API negative per class (uppercase, `@`, reserved → 422) and one CSV import whose bad row lands in `errors` while good rows still create. `tests/test_ldap_injection.py:30-43` already tolerates any status for its injection uid `[V]`, so it passes unchanged under a new 422. **Sequencing.** Audit on the host before plan Phase 4; validators in the same PR only if clean. Independent of every VM7 item. **Risks.** (a) The OpenAPI snapshot gate fails until the baseline is regenerated — `tests/contract/test_openapi_snapshot.py:73-92` compares component schemas byte for byte and `pattern` is a new key; fix with `just openapi-accept` in the same commit, and `openapi.baseline.json` is on the same surface so it needs no extra trailer. (b) `PATCH /api/users/{uid}` cannot rename a uid `[V] schemas/users.py:64-72`, so there is no second create-shaped path to guard. (c) Every existing test uid conforms `[V]`.

### 5.4 VM6-4 — publish the sentinel and the value filter in §08 (§3.3, D5; plan 1.4)

**Obligation.** §08 §2 must publish `000001010000Z` as *the* "treat as gone" value, publish both value-based filters, and stop publishing the presence filter.
**Approach.** Replace two table rows, add four, add two prose blocks. VM6-6's grammar rows, VM6-7's interval and VM6-9's note ride the same edit, so §08 is touched once.
**Files.** `docs/architecture/spec/08-integration-points.md`; `docs/architecture/README.md`; `docs/architecture/CHANGELOG.md`.

**Change sketch** — the *Directory Consumer Contract* table at `:83-90`:

```diff
 | Account identifier | `uid` | `uid` / `sAMAccountName` | The application-visible identity. Equals the OIDC `preferred_username`. |
+| **Account identifier grammar** | **`^[a-z0-9][a-z0-9_.-]{0,63}$`** | *(anything)* ⚠️ | Enforced at create and import. Lowercase ASCII, no `@`, 1–64 chars, compared **byte for byte** — nobody folds case. Consumers that rewrite out-of-set usernames (Nextcloud `user_ldap` transliterates, maps space→`_`, hashes over 64) silently break the identity for that person. |
+| **Reserved namespace** | **`pach_admin`, `pach_service`, any `^pach_`** | *(none)* ⚠️ | Refused by this directory. It is the consumer-local account namespace on the document-share host; a directory entry inside it would collide with a local account. |
 | **Display name** | **`cn`** | **`displayName`** ⚠️ | **azb-AD writes no LDAP `displayName` on any path.** See below. |
-| **Account is dead** | **`(pwdAccountLockedTime=*)`** | *(nothing)* ⚠️ | Terminated users stay in the tree. A consumer that does not exclude this keeps a terminated account enabled and addressable indefinitely (see **02 Termination Flow**). |
-| User search base / filter | `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=*)))` under `ou=people,{base}` | — | The canonical active-user filter. |
+| **Account is dead** | **`pwdAccountLockedTime = 000001010000Z`** | *(nothing)* ⚠️ | The sentinel — and **only** the sentinel. Terminated and suspended entries stay in the tree carrying it. A consumer that does not exclude it keeps the account enabled and addressable indefinitely (see **02 Termination Flow**). |
+| **Account is temporarily locked** | `pwdAccountLockedTime = <a real timestamp>` | *(often conflated with the above)* ⚠️ | Written by the ppolicy overlay after `pwdMaxFailure 5`, cleared lazily on the next bind after `pwdLockoutDuration 300` s. **Not** a consumer signal. A consumer filtering on *presence* makes five wrong passwords erase a person from its user list for 300 s. |
+| User search base / filter | `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=000001010000Z)))` under `ou=people,{base}` | — | The canonical active-user filter. **Supersedes** the presence filter `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=*)))` published here through spec 1.13.0. |
+| Login filter | `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=000001010000Z))(uid=%uid))` | — | The same predicate with the username term, for consumers carrying a separate bind-time filter (Nextcloud `ldapLoginFilter`). Both filters MUST be set in *raw* mode where the consumer offers one, so a UI save cannot regenerate them. |
+| SSO latency for a new account | ≤ `<N>` min | — | See *Sync interval*, below. Direct LDAP bind is immediate; SSO waits for the Authentik LDAP source sync. |
```

Prose to add straight after that table:

```markdown
**`000001010000Z` is the account-state sentinel.** It is ppolicy's "locked
indefinitely" value, and in this directory it carries exactly one meaning: *treat
this account as gone*. Both `terminate` and `suspend` write it
(`ldap_client.disable_user()`, `suspend_user()`); `unsuspend` **deletes** the
attribute rather than writing a different value. **No other value written to
`pwdAccountLockedTime` carries that meaning** — the only other writer is the
ppolicy overlay's own transient lockout, and a consumer that treats that as death
removes a person for the lockout duration on five wrong passwords.
`description=TERMINATED`/`SUSPENDED` and `userPassword={DISABLED}`/`{SUSPENDED}`
are informational, not consumer signals.

**Sync interval.** Authentik's LDAP source (ARD-007) is what makes a directory
`uid` usable as an OIDC `preferred_username`, and it authenticates only users it has
already synced. A new account binds over LDAP immediately and gains **SSO for a new
account within ≤ `<N>` min**. The schedule is pinned by the seed.
```

**The presence filter must not survive where it reads as current.** After this edit the literal remains at `docs/architecture/README.md:24` and `CHANGELOG.md:11,22,64` `[V]`. Those are **dated records** of what 1.12.0 and 1.13.0 did, and under `SOP.md` the CHANGELOG is a record, not a decision surface — rewriting them would falsify it. Rule: the presence filter survives only inside a dated version note, and the new 1.14.0 entries in both files MUST say in as many words that it is superseded by the sentinel filter as of spec 1.14.0. The pin test (§5.12) enforces the live half — the literal must not appear in §08 at all. `openwiki/` is generated and carries the sentinel but not the presence filter `[V] openwiki/backend/ldap_client.md:30`; regenerate, do not hand-edit.

**Tests.** §5.12 greps §08 for the sentinel and the exact value filter, and asserts the presence filter is absent. Feeds check 9. **Sequencing.** Independent of VM7, but must land **before** VM7-6, so VM7 copies from a published source rather than a design document. **Risk.** VM7 transcribes the filter by hand; one character of drift and Nextcloud's user list silently loses or gains people. The two pin tests are the only mechanical guard, and they carry the same header comment.

### 5.5 VM6-9 — "Authentik is not an assertion signer" (§6, D-withdraw; rides VM6-4)

**Obligation.** A §08 note so the 2026-08-10 pointer is not reinstated by someone reading §08 alone.
**Section choice.** A new short subsection at the **end of §08 §5 *OIDC Discovery***, not §2 and not a new top-level section: §5 describes what this Authentik issues and how its tokens are verified `[V] 08-integration-points.md:172-206`, so a reader asking "can I point my JWKS consumer here?" lands there. §2 is the LDAP bind contract and has nothing to say about token shapes.

```markdown
### What This Provider Does Not Sign `[AS-BUILT]`

Authentik here is an OAuth2/OIDC provider: it mints ID and access tokens for a
registered client, carrying the claims its scope mappings emit. It **cannot** mint
an application context assertion — a JWT whose body is a conversation snapshot
(`typ`, `jti`, `sub == context.user.id`, `context` with members). Only the party
that knows the context can honestly assert it. A 2026-08-10 operator decision that
pointed a downstream verifier's `ASSERTION_JWKS_URL` / `ASSERTION_ISSUER` at this
Authentik is **withdrawn** (2026-08-18): publishing a JWKS is not the same as
being able to sign the document a verifier expects, and a context-assertion
verifier pointed here gets a token with the wrong shape and the wrong claims.
```

**Tests.** Doc-only; covered by the §08 grep in §5.12. **Sequencing.** Same §08 edit as VM6-4.

### 5.6 VM6-3 — a second application in the seed (§3.7, §4, D3; plan Phase 1 +1 d)

**Obligation.** Fold VM6-2 into `deploy/dev/authentik-seed/seed_authentik.py` as a second, environment-parameterised application, adopted idempotently, on a scoped API token; a re-seed leaves the by-hand application intact and **never regenerates its client secret**.
**Approach.** Generalise `ensure_oauth2_provider()` and `ensure_application()` to take an app spec instead of reading module globals, then call them twice. *Rejected:* a copy-pasted `ensure_nextcloud_provider()` — two divergent idempotency implementations is how the #281 defect went unnoticed once. *Rejected:* a blueprint/YAML rewrite — a large refactor for one extra app.
**Files.** `seed_authentik.py`; `deploy/dev/.env.example`; `tests/unit/test_authentik_seed_app_lookup.py`.

**Env keys** (new, beside the block at `seed_authentik.py:21-33`): `NEXTCLOUD_OIDC_ENABLED` (gate; dev default off), `NEXTCLOUD_OIDC_CLIENT_ID` = `nextcloud`, `NEXTCLOUD_OIDC_REDIRECT_URIS` = both strict URIs from `<pach_nextcloud_host>`, `NEXTCLOUD_OIDC_POST_LOGOUT_REDIRECT_URIS` = `https://<pach_nextcloud_host>/`, `NEXTCLOUD_OIDC_LAUNCH_URL`, `AUTHENTIK_SEED_TOKEN`. **No baked defaults** for the URIs — unlike `OAUTH2_REDIRECT_URIS`, which falls back to a literal set `[V]:54-85`; an empty key with the gate on is a loud failure, and a baked hostname is the coupling H-4 records.

```python
NEXTCLOUD_APP = {
    "enabled": os.getenv("NEXTCLOUD_OIDC_ENABLED", "").lower() in ("1", "true", "yes"),
    "client_id": os.getenv("NEXTCLOUD_OIDC_CLIENT_ID", "nextcloud"),
    "slug": "nextcloud", "name": "Nextcloud", "provider_name": "Nextcloud OIDC",
    "client_type": "confidential",                          # brand provider is public
    "grant_types": ["authorization_code", "refresh_token"], # NOT client_credentials (H-5)
    "scopes": {"goauthentik.io/providers/oauth2/scope-openid",   # the three built-ins
               "goauthentik.io/providers/oauth2/scope-profile",  # only — master §3.7
               "goauthentik.io/providers/oauth2/scope-email"},
    "sub_mode": "hashed_user_id",
    "issuer_mode": "per_provider",                          # unset on the brand provider
    "redirect_uris": _strict_uris(os.getenv("NEXTCLOUD_OIDC_REDIRECT_URIS", "")),
    "logout_uris": _logout_uris(os.getenv("NEXTCLOUD_OIDC_POST_LOGOUT_REDIRECT_URIS", "")),
    "launch_url": os.getenv("NEXTCLOUD_OIDC_LAUNCH_URL", ""),
}

def ensure_oauth2_provider(spec) -> int:
    if results:                       # ADOPT — never recreate, never re-secret
        pk, existing, patch = results[0]["pk"], results[0], {}
        # client_secret is DELIBERATELY absent from every branch below. VM7's vault
        # is the only copy (master §4); a re-seed that regenerates it breaks a
        # working consumer silently until the next converge.
        if not existing.get("signing_key") and signing_key_pk:
            patch["signing_key"] = signing_key_pk
        if existing.get("issuer_mode") != spec["issuer_mode"]:
            patch["issuer_mode"] = spec["issuer_mode"]
        ...
        return pk

def ensure_application(spec, provider_pk: int):
    if find_application(spec["slug"]) is not None:      # #281 retrieve-by-slug
        print(f"  Application '{spec['slug']}' already exists"); return
    api_request("POST", "/core/applications/", {
        "name": spec["name"], "slug": spec["slug"],
        "provider": provider_pk, "meta_launch_url": spec["launch_url"]})
```

Adoption is **by slug** through `find_application()`, which retrieves at `/core/applications/{slug}/` rather than filtering the list endpoint — that endpoint serves `results` from a per-user cache and applies the filter only to `pagination.count`, so a truthy `results` means "some application exists" `[V]:559-574`. That is the #281 pattern, and its own docstring already measures it against `nextcloud`. **Scope mappings.** `get_scope_mapping_pks()` resolves the module-level `WANTED_SCOPE_MAPPINGS` — four, including `offline_access` `[V]:44-49,283`. It takes the wanted set as an argument; the Nextcloud provider passes the three-element set and never acquires `offline_access`. `delete_legacy_groups_scope_mapping()` (#279) is estate-wide; leave it.

**The scoped API token — minimum viable.** `API_TOKEN` defaults to `AUTHENTIK_BOOTSTRAP_TOKEN` `[V]:22`, which is akadmin's and can do anything. The new block reads `AUTHENTIK_SEED_TOKEN` **with no fallback** — empty means the block does not run. How it comes to exist, once, by hand in the same sitting as VM6-2: (1) Directory → Users → **Create Service Account** `azb-seed`; (2) assign a role holding only add/change on OAuth2 providers and applications and view on certificate-key pairs, flows and property mappings; (3) Directory → Tokens → new token, `intent: api`, user `azb-seed`; view the key once → `.env`/vault. Whether 2026.5's object-level RBAC reaches `add_oauth2provider` at that granularity is `[I]` — the check is assigning the role and running the seed once with `AUTHENTIK_SEED_TOKEN` set: it either creates the provider or returns 403. If it does not, the recorded fallback is a **dedicated service account with a global role** — still strictly better than the bootstrap token, because it is independently revocable and appears in the audit log under its own name.

**Tests.** Extend `tests/unit/test_authentik_seed_app_lookup.py`, whose `FakeAuthentik` already models the cache-poisoned list endpoint and holds `{"slug": "nextcloud"}` as `_OTHER_APP` `[V]`. New cases: one run creates both applications when neither exists; a second run creates neither; the PATCH built for an existing confidential provider contains **no** `client_secret` key; the Nextcloud provider's `grant_types` excludes `client_credentials` and its scope set has exactly three members. This file runs in the stack-free `backend-unit` job `[V] .github/workflows/pr-checks.yml:141`. **Sequencing.** VM6-2 by hand first (plan 1.2), so the seed's first job is to *adopt* — also the only way to test adoption against a real object. Off the critical path (plan 6.1). **Risks.** (a) A re-seed regenerating the secret breaks VM7 silently until the next converge; the unit test above is the guard. (b) A seed-created confidential provider prints its secret once — acceptable in dev; in prod VM6-2 mints it. (c) Enabling the block against a prod Authentik needs `AUTHENTIK_SEED_TOKEN` provisioned out of band, exactly as ARD-007 already requires for `AUTHENTIK_LDAP_SYNC_PASSWORD` `[V] ARD-007 § Secret lifecycle`.

### 5.7 VM6-5 — suspend semantics (§3.3, D5; check 11)

**Obligation.** Suspend writes the sentinel and revokes Authentik sessions and tokens; unsuspend **deletes** `pwdAccountLockedTime`; neither touches termination's irreversible parts.
**What `terminate_user_access` actually does — the design's pivot.** It calls `revoke_user_sessions()` then `revoke_user_tokens()` and returns the counts. It does **not** deactivate the Authentik user, does not set `is_active=False`, and deletes nothing but sessions and access tokens `[V] src/backend/authentik_client.py:139-150`. Therefore: suspend calls **`terminate_user_access(uid)` unchanged** — no narrower helper is needed, and the existing `revoke_user_sessions()` alone `[V]:78` would revoke only half of what D5 requires; and unsuspend needs **no** re-activation, because nothing was deactivated. This also leaves `authentik_client.py` — an `auth_plane` surface — untouched, removing a governance lane (§10.1).

**Approach.** One attribute write in `suspend_user`, one attribute delete in `unsuspend_user`, one revocation call on the suspend route, one guard against resurrecting a terminated account. *Rejected:* routing suspend through `disable_user()` — that removes group memberships, termination's irreversible half, which unsuspend cannot restore.
**Files.** `src/backend/ldap_client.py`; `src/backend/routers/users.py`; `tests/test_suspend.py`; `openwiki/backend/ldap_client.md` (regenerated).

```python
def suspend_user(uid: str) -> Dict[str, Any]:
    """Suspend: reversible, but consumer-visible. Master §3.3 / D5.
    Group memberships are deliberately NOT touched — that is termination's
    irreversible half and unsuspend cannot restore it."""
        conn.modify(user_dn, {
            "userPassword": [(MODIFY_REPLACE, ["{SUSPENDED}"])],
            "description": [(MODIFY_REPLACE, ["SUSPENDED"])],
            "pwdAccountLockedTime": [(MODIFY_REPLACE, [PWD_LOCKED_FOREVER])],   # ➕
        })

def unsuspend_user(uid: str, new_password: str) -> Dict[str, Any]:
        conn.modify(user_dn, {"userPassword": [(MODIFY_REPLACE, [ssha_password(new_password)])],
                              "description": [(MODIFY_REPLACE, [])]})
        # ➕ Separate modify: MODIFY_DELETE with no values removes the whole attribute,
        # and OpenLDAP answers noSuchAttribute when it is absent — the normal case for
        # anyone suspended before this shipped. Batching it above fails the whole modify.
        conn.modify(user_dn, {"pwdAccountLockedTime": [(MODIFY_DELETE, [])]})
        if conn.result.get("description") not in ("success", "noSuchAttribute"):
            raise RuntimeError(f"LDAP unsuspend lock-clear failed: {conn.result}")

# routers/users.py::api_user_suspend — mirror the terminate route's fire-and-forget
# block [V]:486-498, so an Authentik outage does not block the LDAP-side suspend.
    suspend_user(uid)
    if _authentik_client:                                       # ➕ D5
        try:
            _authentik_client.terminate_user_access(uid)        # sessions + tokens only
        except AuthentikError as e:
            logger.warning("Authentik revocation failed for %s: %s", uid, e)
```

**A guard master 1.0.0 did not name; 1.0.1 §3.3 makes it a MUST.** `api_user_unsuspend` today only checks that the user exists `[V]:586-596`. Once unsuspend *deletes* `pwdAccountLockedTime`, calling it on a **terminated** user silently resurrects them: the sentinel disappears, the consumer filter stops excluding them, and they reappear in Nextcloud's list with a fresh password. Today the call is harmless because the attribute is never touched. So `api_user_unsuspend` **MUST** refuse with 409 unless the account state is `suspended` — `get_user(uid)` already carries `accountStatus`, the same field `routers/users.py:87-108` computes for the list endpoint.

**ppolicy — does the delete plus a password reset restore bind immediately?** `[I] — yes.` slapo-ppolicy consults `pwdAccountLockedTime` on bind; absent, there is no lock state to evaluate. The default policy sets `pwdMustChange: FALSE` and `pwdGraceAuthNLimit: 0`, so a fresh password is usable at once, and the API binds as the rootDN (`cn=admin,dc=azblink,dc=com`), which is not subject to `pwdInHistory: 3` / `pwdMinLength: 8` on the write `[V] deploy/dev/ldap/bootstrap.ldif:48-67`, `[V] deploy/dev/ldap/ppolicy-config.ldif`. **The check that settles it is already in CI:** `tests/test_suspend.py::TestUserSuspend::test_unsuspend_restores_access` binds as the user immediately after unsuspend `[V]` — residue turns it red. One residue is real, pre-existing and out of scope: `pwdFailureTime` values are not cleared and `pwdFailureCountInterval: 0` means they never age out, so a user who accumulated failures before suspension is closer to a new lockout after unsuspend. That is ppolicy configuration, not suspend semantics; do not fix it here.

**Tests** — extend `tests/test_suspend.py`, in its existing style (live API via `client`, LDAP read-back via `ldap_conn`):

| Case | Assertion |
|---|---|
| `test_suspend_sets_lock_sentinel` | after suspend, `pwdAccountLockedTime == "000001010000Z"` |
| `test_unsuspend_deletes_lock_attribute` | after unsuspend the attribute is **absent** — not empty, not another value |
| `test_suspend_revokes_authentik_sessions` | the route calls `terminate_user_access`; asserted against the Authentik API (session count 0) or a monkeypatched `_authentik_client`, matching `tests/test_authentik_client.py` |
| `test_suspend_leaves_group_memberships` | a group the user is in before suspend still lists their DN after — the explicit contrast with terminate |
| `test_unsuspend_refuses_terminated_user` | terminate then unsuspend → 409, sentinel still present |
| existing `test_unsuspend_restores_access` | unchanged — it is the ppolicy check above |

Feeds master **check 11**.

**Sequencing.** May land after plan Phase 5; check 11 then gates "integrated" (plan Gate 5). Depends on nothing from VM7, but check 11 cannot run until VM7-6 configures the sentinel filter. **Risks.** (a) Silent resurrection — closed by the 409 guard. (b) A pre-VM6-5 suspension has no attribute to delete — closed by tolerating `noSuchAttribute`. (c) A consumer sees a suspended person disappear only after `ldapCacheTTL` (600 s) — that is the contract (§3.10), not a defect. (d) `openwiki/backend/ldap_client.md:30` describes the old behaviour; regenerate in the same PR.

### 5.8 VM6-7 — pin and publish the sync interval (§3.10, N-11; plan 6.1)

**Obligation.** Pin the Authentik LDAP source sync schedule in the seed; publish the interval in §08 as an SSO latency bound.
**Does the schedule expose a settable `crontab`?** `[I] — readable for certain, writable very probably.* The seed already retrieves the schedule from `GET /tasks/schedules/?page_size=200` and matches by `rel_obj_id` `[V] seed_authentik.py:441-451`, and `tests/test_ldap_source.py:61` names the live value **`26 */2 * * *`** in a comment about racing the periodic sync `[V]` — someone read a `crontab` field off that object. **The check that settles writability:** on the dev stack, `GET /api/v3/tasks/schedules/{id}/` and confirm a `crontab` key, then `PATCH /api/v3/tasks/schedules/{id}/ {"crontab": "*/5 * * * *"}` and re-`GET`. If PATCH is refused, publish Authentik's default instead — the obligation is to *pin and publish*, and an unchanged-but-documented default satisfies it.

**Pinned value — decided 2026-08-19 (master 1.0.1 §3.10; review D-2): `*/5 * * * *`, five minutes.** ARD-002 already tells readers "~5 min" (cited by master §3.10), so five minutes is what this estate has effectively promised; the current `26 */2 * * *` means a new account can wait two hours for SSO, which reads as a broken integration. Five minutes costs one bind-and-search of a directory of tens of entries.

**Approach.** In `ensure_ldap_federation()`, between `ensure_ldap_source()` and `trigger_ldap_sync()`, PATCH the schedule's `crontab` to `LDAP_SYNC_CRONTAB` (env, default `*/5 * * * *`), tolerating a 4xx with a warning. Extract the schedule lookup out of `trigger_ldap_sync` into `_find_sync_schedule_id(source_pk)` so there is one lookup implementation.
**Files.** `seed_authentik.py`; `deploy/dev/.env.example`; spec §08 (§5.4's *Sync interval* block, `<N>` = 5).

**§08 wording:** *"SSO for a new account within ≤ 5 min."*

**Tests.** One unit case in the seed test file: the PATCH body is `{"crontab": …}` and a 4xx does not abort the run. Seed idempotency is plan check 7. `tests/test_ldap_source.py` triggers sync explicitly, so it does not depend on the interval. **Sequencing.** Hardening (plan 6.1); the seed change and the §08 number land in one PR. **Risk.** Publishing `5` while the schedule stays at `26 */2 * * *` is worse than publishing nothing — it turns a known unknown into a false promise.

### 5.9 VM6-8 — the `federated_user` fixture (§7, X-2; plan 6.1)

**Obligation.** A conftest fixture producing an LDAP-federated user, and an assertion that a token minted for them carries `preferred_username == uid`.
**Real Authentik or fake? Real.** `authentik_user_factory` creates users through Authentik's Admin API at `AUTHENTIK_API_URL` and mints app-password tokens `[V] tests/conftest.py:271-326`; `oidc_token_response_factory` performs an actual `client_credentials` grant against `/application/o/token/` `[V]:329-356`. Nothing is faked. So `federated_user` is a **stack-tier** fixture — directory-api + OpenLDAP + Authentik, i.e. the `backend-tests` job (`pytest tests/ --ignore=tests/unit -m "not external_network"` against the real stack `[V] .github/workflows/pr-checks.yml:237`). It needs **no** new marker: not `nostack`, not `external_network` (real lab devices), not `e2e` — the same unmarked tier as `tests/test_ldap_source.py`. **Approach.** Compose from what exists rather than writing a third sync trigger: `conftest.create_test_user()` `[V]:230-242` for the directory side, and the schedule-send-and-poll loop currently duplicated at `tests/test_ldap_source.py:18-44` and `tools/dev-seed-uc-user.py:132-170`. Move that loop into `tests/conftest.py` as `_trigger_ldap_sync_and_wait()` and have `test_ldap_source.py` import it — one implementation, three callers.

```python
@pytest.fixture                                          # tests/conftest.py
def federated_user(client, created_users):
    """An LDAP-created user synced into Authentik, plus an app-password key.
    Proves the identity invariant end to end: uid == preferred_username
    (master INTEGRATION-SPEC 1.0.1 §3.1, §7). Needs the real stack."""
    uid = f"fed-{uuid.uuid4().hex[:8]}"
    assert create_test_user(client, uid, created_users).status_code == 201
    _trigger_ldap_sync_and_wait()                        # extracted, shared
    users = _authentik_api("GET", f"/core/users/?username={uid}").get("results", [])
    assert users, f"{uid} did not import from the LDAP source"
    ak_pk, token_id = users[0]["pk"], f"fed-tok-{uuid.uuid4().hex[:8]}"
    _authentik_api("POST", "/core/tokens/",
                   {"identifier": token_id, "intent": "app_password", "user": ak_pk})
    yield uid, _authentik_api("GET", f"/core/tokens/{token_id}/view_key/")["key"]
    for path in (f"/core/tokens/{token_id}/", f"/core/users/{ak_pk}/"):
        try: _authentik_api("DELETE", path)
        except Exception: pass

def test_federated_user_preferred_username_is_the_directory_uid(   # test_oidc_claims.py
        federated_user, oidc_token_response_factory):
    uid, key = federated_user
    resp = oidc_token_response_factory(uid, key, scope="openid profile email")
    claims = jwt.decode(resp["id_token"], options={"verify_signature": False})
    assert claims["preferred_username"] == uid          # the invariant, byte for byte
```

That an app-password token can be minted for an **LDAP-sourced** Authentik user and used in the M2M grant is `[I]` — tokens attach by user pk and the source should not matter, and ARD-007 records `sync_users_password=false`, which is why the grant uses the app-password key and not the directory password. The check: run the fixture once against the dev stack.

**Sequencing.** Hardening (plan 6.1); independent of VM7. Feeds check 10's identifier-space half on VM6's side. **Risks.** (a) Cost — `_trigger_ldap_sync_and_wait` polls up to 120 s, and `tests/test_ldap_source.py:68-79` documents that one cycle can race the periodic schedule and needs up to three retries `[V]`, so the fixture can take minutes. Keep it function-scoped with exactly one consumer; promote to module scope only if a second appears. (b) VM6-7's five-minute schedule narrows that race, not widens it. (c) `created_users` teardown removes the LDAP entry but not the Authentik shadow — the fixture's own teardown does that, reverse order, best-effort, the same convention `authentik_user_factory` uses.

### 5.10 VM6-13 — ARD-007 and ARD-015 statuses (§9.1; plan 6.1)

**ARD-007 → `accepted` (decided 2026-08-19, review D-7).** It is load-bearing in the strictest sense: **the Authentik LDAP source *is* the SSO path this integration depends on.** Without it Authentik's store is disjoint from the directory and `preferred_username` cannot equal `uid` — the invariant the whole master exists to protect. It is shipped and exercised: the seed creates the source `[V] seed_authentik.py:376-419,476-485`, and `tests/test_ldap_source.py::test_ldap_source_exists` pins `object_uniqueness_field == "uid"`, `sync_users_password is False`, and a `cn=authentik-sync,ou=clients` bind `[V]`. A decision this load-bearing left at `proposed` reads as "not settled", which is the exact misreading that produced the 2026-08-10 assertion-signer decision. Flip: `status: accepted`, `accepted_at: <merge date>`, `decision_effective_date: 2026-07-03` (retro — it shipped then), `pr:`, and write the hand-maintained `<!-- summary:begin -->` block, empty today `[V]`.

**One correction must land *before* the flip.** `arch_guard` rule 2 freezes an ARD's body above `## Amendments` once `status: accepted` `[V] tools/arch_guard.py:143,292-322`. ARD-007's *Deactivation* bullet says termination and suspend swap `userPassword` to `{DISABLED}`/`{SUSPENDED}` "so bind-based login fails" — after VM6-5 that is incomplete: both also write `pwdAccountLockedTime = 000001010000Z`, the consumer-visible half. Correct that bullet in the same PR as the flip, or the accepted text is wrong, frozen, and costs an amendment to fix.

**ARD-015 → `amend`, not accept (decided 2026-08-19, review D-7).** Its own bar is explicit: *"Flip to `accepted` … once a real host has been bootstrapped unattended **and** converged"* `[V]`. Its three amendments record that this has never happened — two unattended installs under qemu, one real host that fell back to a hand-install with the cause never isolated. Accepting would assert something the record contradicts, and ARD-015 is not on the VM6 ⇄ VM7 path at all (host bootstrap, not the directory contract). Add a short dated amendment stating the bar is unchanged and unmet as of 2026-08-19, so a reader knows `proposed` is a live judgement, not an oversight.
**Files.** `decisions/ARD-007-authentik-ldap-source.md`; `decisions/ARD-015-vm-host-bootstrap-iso.md`; `docs/architecture/README.md` (ARD table `:189`, `:197`); `docs/architecture/CHANGELOG.md` — an ARD status change is an `SOP.md § Update Triggers` 3 event. **Tests.** `arch_guard` rules 2–4 in CI. Rule 3 requires every `spec_sections_affected` name to resolve under `docs/architecture/spec/` `[V]:324-344`; ARD-007's `["04-authentication", "06-deployment"]` both exist.

### 5.11 VM6-11 — stop publishing 1637 (optional; §3.5, §5.2, D1)

**Obligation (optional half).** Under Option A, 1637 is published and serves nothing (`LDAP_TLS: "false"`, handshake fails). Stopping the publication makes its absence honest.
**Approach — zero code.** `deploy/dev/docker-compose.yml:78` already reads the port from an env var (`"${LDAP_PUBLISH_TLS:-0.0.0.0:1637}:636"` `[V]`) and `deploy/dev/.env.example:53` documents the key `[V]`. Set `LDAP_PUBLISH_TLS=127.0.0.1:1637` in the deployment's `.env` (gitignored, per-host) and recreate the container. No tracked file changes ⇒ no spec bump, no trailer. *Rejected:* deleting the compose line — a tracked `deploy_topology` change for something the operator can already set, and it would be reverted under Appendix C. **Tests.** None. Confirmed by `docker compose ps` showing 1637 on loopback, 1637 unreachable from VM7, 1390 still bound. **Sequencing.** Any time from plan Phase 2. **Risk.** Nothing uses 1637 today because nothing can `[R]` §3.5 — but confirm no other LDAP client (UED/PED) was pointed at it in hope before making it loopback-only.

**TLS half:** production gate — **design deferred to the production-gate ARD/spec** (master Appendix C; X-4). It needs osixia `LDAP_TLS=true` with CA/cert/key mounted and Authentik's 9443 listener behind an estate-CA certificate: a ratified posture change touching every LDAP client, and therefore its own ARD in this repository.

### 5.12 Contract-pin test (the cross-repo alignment mechanism)

**Obligation.** One small test per repo asserting the shared literals, so drift breaks CI rather than the demonstration.
**File.** `tests/unit/test_consumer_contract_pins.py`. `tests/unit/` has its own conftest stubbing the four UC env vars, so backend modules import with no Docker `[V] tests/unit/conftest.py:13-18`, and it runs in the always-on, stack-free `backend-unit` job `[V] pr-checks.yml:141`. It needs **no** `nostack` marker — that marker exists to skip the autouse Redis/Postgres fixtures, which `tests/unit/conftest.py` already shadows with no-ops. **Header — identical in both repos, verbatim:**

```python
# Contract pins — azb-unified-ecosystem INTEGRATION-SPEC 1.0.1 §3.2, §3.3, §3.5, §3.8. Change only with a master bump.
```

Assertions: (1) `ldap_client.PWD_LOCKED_FOREVER == "000001010000Z"`; (2) the uid regex constant equals `^[a-z0-9][a-z0-9_.-]{0,63}$`; (3) the reserved set `== {"pach_admin", "pach_service"}` and the prefix tuple contains `pach_`; (4) `UserCreateReq` **rejects** `pach_admin`, `Pach_x`, `Alice`, `a@b`, `-x`, and a 65-character uid; (5) `UserCreateReq` **accepts** `alice`, `a.b-c_1`, `0abc`; (6) `docs/architecture/spec/08-integration-points.md` contains the literal `000001010000Z`; (7) …contains the exact string `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=000001010000Z)))`; (8) …does **not** contain `(!(pwdAccountLockedTime=*))`.

Grep-pinned tests are this repo's established style — `tests/test_api.py` pins `contract_version`, and `tests/contract/` is four files of static analysis over the source tree `[V]`. **VM7 carries the mirror** (`tests/test_identity_contract_pins.py`): both filter strings and the absence of the presence filter in `deployment/nextcloud-identity/configure.sh`; the six `occ` pins with their values (`ldapUserFilterMode 1`, `ldapLoginFilterMode 1`, `ldapGroupFilterMode 1`, `ldapExpertUUIDUserAttr entryuuid`, `ldapExpertUUIDGroupAttr entryuuid`, `ldapCacheTTL 600`); `UserRef.id` against **the same vectors, verbatim**; the `.example` refusal in `roles/pach_app/tasks/preflight.yml`.

**Sequencing.** Assertions 6–8 pass only after VM6-4, 2–5 only after VM6-6. Land the test in whichever PR comes second, or land it first marked `xfail` — never land a test that is green because the file it greps is missing. **Risk.** A pin test edited to match a change instead of blocking it is worse than none. The header comment is the whole control: it names the master version and says a change requires a master bump.

### 5.13 Production-gate and deferred items — requirements and trace only

| ID | Obligation | Disposition |
|---|---|---|
| **VM6-10** | VM6 converged from a filled `deploy/ansible/inventories/prod` — `server_host` set, ops ports on loopback, `dev_auth_token` empty, demo identities purged, with §3.11's re-init protocol observed on the VM7 side (§2.a item 2, D4) | **Design deferred to the production-gate ARD/spec.** Note only: `ldap_admin.yml` purges demo identities, so the dev→prod switch is a coordinated event with VM7 (plan D2-4), and plan 3.7 makes stand-in fixture members real directory uids — if those are demo identities, they are purged too. |
| **VM6-11 (TLS half)** | LDAPS on 1637 and Authentik TLS on 9443 under one estate CA (Appendix C) | **Design deferred to the production-gate ARD/spec** — needs its own ARD here; it changes the posture for every LDAP client, not just VM7. |
| **VM6-12** | Backfill `memberOf` for memberships predating the overlay repair | **Deferred, unscoped.** VM7 associates by `member` (§3.1). Overlay fix shipped in `967fd4b`; no backfill exists `[R]`. Design deferred until a `memberOf`-keyed consumer arrives. |
| **X-4** | Estate CA custody at the production gate | **Design deferred to the production-gate ARD/spec.** VM7's `playbooks/make-ca.yml` generates the CA; custody is a cross-repo decision record, not a VM6 file. |
| **X-5** | Telemetry contract | **Unscoped** by the master. Not designed here. |
| **X-6 / D-key** | Assertion signing key custody | **Open, unowned.** Not VM6's to close; VM6's only obligation is VM6-9 (§5.5). |

## 6. Dependencies on the peer and sequencing

Every VM6 item is independently implementable; what VM6 needs from VM7 is only proof.

| Direction · dependency | By | Blocks |
|---|---|---|
| **VM6 ← VM7** Both secrets in VM7's vault; a converged host | plan Ph 3–4 | checks 6, 8 (that `cn=nextcloud` binds from VM7's address) |
| **VM6 ← VM7** VM7-6 sentinel filter configured | plan 3.4 | checks 3, 9, 11 — VM6-5 is unprovable without a consumer applying the filter |
| **VM6 ← VM7** VM7-5 `ldapCacheTTL 600` pinned | plan 3.3 | checks 3b, 11 (the eviction bound) |
| **VM6 ← VM7** VM7-8 fixture members are real directory uids | plan 3.7 | check 10 |
| **VM6 → VM7** `cn=nextcloud` bind secret (VM6-1) | plan 1.1 | VM7-1 vault — preflight refuses half a pair |
| **VM6 → VM7** Nextcloud OIDC client secret + discovery URI (VM6-2) | plan 1.2 | VM7-1 vault; checks 1, 4, 12 |
| **VM6 → VM7** §08 publishing the sentinel and both filters (VM6-4) | plan 1.4 | VM7-6 — VM7 copies from a published source, not a design document |
| **VM6 → VM7** The uid grammar published (VM6-6) | plan 1.3 | VM7-8's `UserRef.id` validation and its pin test |
| **VM6 → VM7** A clean uid audit (VM6-6) | before plan Ph 4 | Phase 4 converge — a non-conforming uid needs a named owner first |
| **VM6 → VM7** The sync interval published (VM6-7) | plan 6.1 | nothing gating; it sets VM7's expectation for "does SSO work yet?" |

**Phase-ordered checklist for THIS repo:**

| Phase | VM6 does |
|---|---|
| **0** | Nothing to write — D1–D6 are on disk in the master. Note only: the D2 expiry date is the estate owner's; D-key is open and unowned. |
| **1.1** | VM6-1 — provision `cn=nextcloud`; secret straight to VM7's vault; `ldapsearch` proof (check 8) immediately. |
| **1.2** | VM6-2 — Authentik application by hand with the §3.7 parameters; client secret to VM7's vault; JWKS non-empty. |
| **1.3** | VM6-6 — run the uid audit against the live directory. Validators ship **only if it is clean**. |
| **1.4** | VM6-4 + VM6-6 (§08 rows) + VM6-9 — one §08 edit; spec → 1.14.0; §08 → 1.10.0; CHANGELOG entry. |
| **1 (+1 d)** | VM6-3 — seed adopts the by-hand application; scoped token; no secret regeneration. |
| **2** | Nothing (Option A needs no VM6 change). Optionally VM6-11's `.env` line. |
| **3–4** | Nothing. Stay available — checks 6 and 8 are read from VM6's side. |
| **5** | Co-run acceptance: checks 3, 6, 8, 9, 11 all read or write on VM6. |
| **6.1** | VM6-5 (if not already), VM6-7, VM6-8, VM6-13. Then check 11 → "integrated". |
| **6.2** | Nothing — stand-down is VM7's (VM7-12). |
| **day two** | Treat `azblink_ldap_data` as shared state: `just reset`, volume loss or a restore is a coordinated event with VM7 (§3.11; plan D2-3). The dev→prod switch purges demo identities (plan D2-4). |

## 7. Acceptance — checks this repository owns or co-owns (master §11)

| # | Check | VM6's part | Pass condition | Status |
|---|---|---|---|---|
| 2 | Directory fully visible | supply the reference count: `ldapsearch` as `cn=nextcloud` with the sentinel filter, `\| grep -c ^dn` | Nextcloud's `user:list` count = that **+ 2** (`pach_admin`, `pach_service`) | after VM6-1 |
| 3 | Terminated user leaves the list | `POST /api/users/{uid}/terminate` on a test user | gone from Nextcloud within `ldapCacheTTL` | runnable now |
| 3b | Established session evicted | the same terminate — VM6 supplies the trigger only | recorded either way (`[I]` in the master) | after VM7 Ph 4 |
| 6 | Bind identity from VM6's side | `GET /api/settings/ldap/clients` or `/configuration/ldap-clients` | a `provisioned_client` row for `cn=nextcloud` from VM7's address; **no** `cn=admin` bind from VM7 | needs VM6-1 |
| 8 | Operational attributes readable | `ldapsearch` as `cn=nextcloud` for `entryUUID pwdAccountLockedTime cn mail` | both returned; no `userPassword`/`AstAuth*` | needs VM6-1 |
| 9 | Lockout does not hide | 5 wrong passwords against a test user, then a correct one after 300 s | the user stays listed and shareable throughout; the lock clears | needs VM6-4 + VM7-6 |
| 10 | Real-uid member id | the uids VM7's fixtures name must exist and be active | the share lands on the directory account | needs VM7-8; VM6-8 is the unit-level half |
| 11 | Suspend semantics (D5) | `POST …/suspend` then `…/unsuspend` | evicted within the TTL; share refused; unsuspend restores | **needs VM6-5** — until then *pending*, not passed |
| 12 | Redirect URI | the registered strict URIs on the Authentik side | the authorise URL's `redirect_uri` matches one of them | needs VM6-2 |

Checks 1, 4, 5, 7, 13 are VM7's to run; VM6 has no part beyond the accounts.

## 8. Traceability matrix

**8.1 Master → this document.** §3.1 attributes → §2.1, §3 rows 6/11 (as-built; checks 2, 8) · §3.2 uid grammar → §5.3 (`schemas/users.py`, `routers/users.py`, `tools/audit_uid_grammar.py`, spec §08; pins 2–5 + the audit report) · §3.3 / D5 sentinel and filters → §5.4, §5.7 (spec §08, `ldap_client.py`, `routers/users.py`; pins 1, 6–8; checks 3, 9, 11) · §3.4 bind + ACL → §5.1, §3 rows 11–12 (no change; checks 6, 8) · §3.5 / §3.6 endpoints → §2.1, §5.11 (dev `.env` only; check 13, run by VM7) · §3.7 / D3 provider → §5.2, §5.6 (Authentik; `seed_authentik.py`; `.env.example`; checks 1, 4, 12) · §3.10 latency → §5.8 (`seed_authentik.py`, spec §08) · §3.11 entryUUID stability → §6 day-two (operational; plan D2-3) · §6 / D-withdraw → §5.5 (spec §08 §5) · §7 identifier space → §5.9 (`tests/conftest.py`, `tests/test_oidc_claims.py`; check 10) · VM6-10, VM6-12, Appendix C, X-4, X-5, X-6 → §5.13, deferred.

**8.2 This document → master** — §5.1 = VM6-1 (§3.4, §4, plan 1.1) · §5.2 = VM6-2 (§3.7, plan 1.2) · §5.3 = VM6-6 (§3.2, plan 1.3) · §5.4 = VM6-4 (§3.3, D5, plan 1.4) · §5.5 = VM6-9 (§6, D-withdraw) · §5.6 = VM6-3 (§3.7, §4, D3) · §5.7 = VM6-5 (§3.3, D5, check 11) · §5.8 = VM6-7 (§3.10, N-11) · §5.9 = VM6-8 (§7, X-2) · §5.10 = VM6-13 (§9.1) · §5.11 = VM6-11 (§3.5, §5.2, D1) · §5.12 = the pin set (§3.2, §3.3, §3.5, §3.8) · §5.13 = VM6-10/11(TLS)/12, X-4, X-5, X-6. **§4.1 H-1…H-6 have no master anchor by design** — repo hygiene found during derivation, out of scope, recorded so it is not rediscovered.

## 9. Out of scope / deferred

| Item | Why | Designed where |
|---|---|---|
| Appendix C (Option B transport); VM6-10 production posture | D1 chose Option A for the demonstration term; D4 puts VM6-10 before *production*, not before the demonstration | the production-gate ARD in this repo + master Appendix C |
| VM6-12 `memberOf` backfill | VM7 associates by `member` (§3.1); no consumer needs it | when a `memberOf`-keyed consumer arrives |
| X-5 telemetry contract; X-6 / D-key custody | unscoped by both audits and the master; D-key is open and unowned and needs an owner, not a design | a separate item; `D-key-custody.md` in the master |
| Back-channel logout; disabling direct LDAP login | §3.13 calls the first a latency improvement, not a gate; D6 keeps the second for the demonstration | after a relying-party registry exists (VM6-3 enables it); revisited at the production gate |
| H-1…H-6 (§4.1) | repo hygiene, not integration work | their own PRs; do not fold into an integration PR |

## 10. Change control

**When the master bumps, this document bumps.** Re-read the changed master sections; re-derive §2 and §4; re-run the §3 audit against the repo at its new HEAD; update the §0 pin table — master versions **and** the peer commit — in the same edit; update the pin test's header comment and literals. **The §0 pin table and the pin test move together or not at all**: a pin test naming an old master version is worse than no test.

**Owner.** Whoever holds VM6 administrative access; reviewed against the master by whoever owns `azb-unified-ecosystem/integration/vm6-vm7/`. **This document itself** lives under `docs/superpowers/specs/`, which `.docslintignore` excludes and `surfaces.yaml` does not govern `[V]` — no commit trailer, no spec bump. Everything it *designs* does.

### 10.1 Governance map — spec sections, trailers, `arch_guard`

`tools/arch_guard.py` rule 1 fails a PR touching a path that matches a surface glob unless a trailer covers that surface. Two lanes matter `[V] tools/arch_guard.py:210-278`:

- **`Spec-Patch: NN`** covers a surface only when `spec/NN-*.md` is **actually edited in the same PR** and `NN-*` is in that surface's `section_map`.
- **`ARD: ARD-NNN`** covers a surface when the ARD's `spec_sections_affected` intersects that surface's `section_map`. It does **not** require a spec-file edit, and it works at status `proposed`.

| Surface | Globs that matter here | `section_map` |
|---|---|---|
| `ldap_schema` | `src/backend/ldap_client.py`, `deploy/dev/ldap/**` | `02-component-architecture`, `03-data-architecture` |
| `api_contracts` | `src/backend/routers/**`, `src/backend/schemas/**`, `tests/contract/openapi.baseline.json` | `08-integration-points` |
| `auth_plane` | `src/backend/authentik_client.py` | `04-authentication` |
| `deploy_topology` | `deploy/dev/docker-compose*.yml`, `deploy/ansible/**` | `06-deployment` |

| Item | Files → surfaces | Spec sections to change | Trailer |
|---|---|---|---|
| VM6-1, VM6-2 | none (operational) | none | none |
| VM6-3 | `deploy/dev/authentik-seed/**`, `.env.example` → **no surface** `[V]` | none | none required |
| VM6-4 + VM6-9 | `docs/architecture/**` only → no surface (its own SOP governs it) | **§08** → `1.10.0`; whole spec → **`1.14.0`**; `CHANGELOG.md` entry; README badge + `spec-meta` + a 1.14.0 note | `Spec-Patch: 08` |
| VM6-5 | `ldap_client.py` → `ldap_schema`; `routers/users.py` → `api_contracts`. **`authentik_client.py` is NOT touched** (§5.7), so `auth_plane` stays clear | **§02** (a *Suspension Flow* sibling; `:289` already states the sentinel for terminate) **and §08** | `ARD: ARD-016` — §10.2 |
| VM6-6 | `schemas/users.py`, `routers/users.py`, `tests/contract/openapi.baseline.json` → `api_contracts` | **§08** (grammar rows) | `Spec-Patch: 08` **or** `ARD: ARD-016` |
| VM6-7 | seed + `.env.example` → no surface; §08 text | **§08** | `Spec-Patch: 08` |
| VM6-8, pin test | `tests/**` → no surface `[V]` | none | none required |
| VM6-11 (zero-code) | dev `.env` (gitignored) | none | none |
| VM6-13 | `decisions/**`, README, CHANGELOG → no surface | an ARD status change is `SOP.md § Update Triggers` 3 → CHANGELOG entry | none required (guard rules 2–4 still run) |

**Does §07 need touching?** No. §07 is rate limiting, provisioning-token security, the authorization ladder, audit tables and security boundaries `[V] 07-security.md` — no input-validation section, and the uid grammar is a *published consumer contract*, not a security boundary. Leave it. **Does §02 `:289` need touching?** Yes — for VM6-5, not VM6-4. `:289` already records that terminate writes `000001010000Z` `[V]`; VM6-5 makes suspend write it and unsuspend delete it, new behaviour the Termination Flow narrative does not cover. Add a short *Suspension Flow* sibling; do not rewrite the termination paragraph.

**Section version note.** §08 goes `1.9.0` → `1.10.0` while the whole spec goes `1.13.0` → `1.14.0`, following the eight section headers as they actually stand rather than `SOP.md § Section Metadata Format`, which says a section's `version` is the whole-spec version. That drift is H-3; do not fix it inside an integration PR.

### 10.2 Decision (2026-08-19, review D-1) — one new ARD-016

**Decided as recommended:** a single new ARD, **ARD-016 — "Directory consumer contract: account-state sentinel, uid grammar, reserved namespace"**, recording as *this repository's own immutable decision* what master D5 and INTEGRATION-SPEC §3.2/§3.3 require of VM6, naming the master's decision files as the origin.

**Alternative rejected — `Spec-Patch: 08` alone.** Three reasons, by weight:

1. **It does not cover VM6-5.** `Spec-Patch: 08` credits only surfaces whose `section_map` holds `08-integration-points` — `api_contracts` and `data_contracts`. VM6-5 touches `src/backend/ldap_client.py`, which is `ldap_schema` (`02`/`03`) `[V]`. Covering that with Spec-Patch means `Spec-Patch: 02,08` **and** edits to both spec files in the same PR. One `ARD: ARD-016` with `spec_sections_affected: ["02-component-architecture", "08-integration-points"]` covers `ldap_schema`, `api_contracts` and `data_contracts` in one trailer, in every PR of the set.
2. **Other consumers inherit this contract.** Plan D2-5 is explicit: a third SSO consumer becomes an application block in the seed and *"inherits §3.1–§3.3 … or silently sees an empty directory"*. A Spec-Patch records that a section changed; an ARD records *why the shape is what it is* — that the sentinel is one value and not a presence, that `pach_` is reserved for a consumer's local namespace, that case is compared byte for byte. The next integrator reads decisions, not diffs.
3. **The origin lives in another repository.** Nothing here references `azb-unified-ecosystem` (H-6). An ARD's References section is the one artifact type made for that pointer, and rule 2 then freezes the text once accepted, so nobody can quietly relax the grammar or reintroduce the presence filter without an amendment.

The ceremony is one file plus two table rows — worth it for a contract whose only symptom of failure is a silently short user list or a person whose uid was rewritten. **Frontmatter:**

```yaml
---
status: proposed
accepted_at:
decision_effective_date:
supersedes: []
superseded_by: []
pr:
spec_sections_affected: ["02-component-architecture", "08-integration-points"]
---
```

**Summary block** (hand-written; the repo has no generator `[V] _TEMPLATE.md`): *"Status **proposed**. Records the directory consumer contract this platform publishes to LDAP-backed relying parties: one account-state sentinel `000001010000Z`, a value-based active-user filter superseding the presence filter published through spec 1.13.0, and a uid grammar with a reserved consumer namespace. Origin: `azb-unified-ecosystem` `integration/vm6-vm7/decisions/D5-account-state-and-filter.md` and INTEGRATION-SPEC 1.0.1 §3.2/§3.3. Supersedes nothing; superseded by nothing. Affects `spec/02-component-architecture.md`, `spec/08-integration-points.md`."*

**Decision** (sketch):

- **One account-state sentinel.** `pwdAccountLockedTime = 000001010000Z` is the only value this platform writes to mean *treat this account as gone*. `disable_user()` (terminate) and `suspend_user()` both write it; `unsuspend_user()` **deletes the attribute** rather than writing a different value. No other value carries that meaning.
- **Consumers filter on the value, never on presence.** The published active-user filter is `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=000001010000Z)))`, and its login form appends `(uid=%uid)` inside the `&`. The presence filter `(&(objectClass=inetOrgPerson)(!(pwdAccountLockedTime=*)))`, published in §08 through spec 1.13.0, is **superseded**: under it a ppolicy lockout (`pwdMaxFailure 5`, `pwdLockoutDuration 300`) is indistinguishable from a termination, so five wrong passwords erase a person from every consumer for five minutes.
- **Suspension is consumer-visible and reversible.** Suspend additionally revokes Authentik sessions and tokens; it does **not** remove group memberships, which is termination's irreversible half. Unsuspend refuses a terminated account.
- **uid grammar.** `^[a-z0-9][a-z0-9_.-]{0,63}$`, enforced at create and at CSV import, compared byte for byte with no case folding. No `@`, so a JID can never be mistaken for a uid. Consumers that rewrite out-of-set usernames break the identity for that person silently.
- **Reserved namespace.** `pach_admin`, `pach_service`, and any uid matching `^pach_` are refused — the consumer-local account namespace on the document-share host; a directory entry inside it would collide.
- **The constants live in one place**, `src/backend/schemas/users.py`; every other reader (CSV import, the audit tool, the pin test) imports them.

**Alternatives Considered** (table): *amend ARD-006* — rejected; ARD-006 is about *who binds*, this is about *what they read*, and ARDs are append-only (the reasoning ARD-007 used against amending ARD-002). *`Spec-Patch: 08` alone* — rejected for the three reasons above. *Encode the reserved names in the regex* — rejected; unreadable, and it cannot give the two failure classes different messages.

**References:** the master spec and D5 by path; VM6-4, VM6-5, VM6-6 by ID; `decisions/D-withdraw-2026-08-10-assertion-signer.md` for the VM6-9 note; related ARDs 001 (single LDAP), 006 (provisioned clients), 007 (Authentik LDAP source), 012 (application locks stay VM6-internal).

**Flip to `accepted`** only once VM6-4, VM6-5 and VM6-6 have landed and master check 11 has passed. Rule 2 freezes the body at that moment `[V] tools/arch_guard.py:143`, and `ARD: ARD-016` already covers the surfaces at status `proposed` `[V]:225`, so there is no reason to flip early.
