# Ansible Deploy Baseline — AZBlink Directory (dev → prod)

- **Date:** 2026-06-21
- **Status:** Approved design (pre-implementation)
- **Author:** Keith + Claude
- **Scope:** A dedicated, idempotent Ansible process that deploys the AZBlink
  Directory stack to the dev VPN VM, structured as a reusable baseline for a
  later production deployment.

## 1. Goal & Motivation

Today the VM is provisioned by `deploy/install.sh` (`curl | sudo bash`). It
works but has gaps that a production baseline must close:

- **Not idempotent in a managed sense** — re-runs re-execute shell steps; no
  declarative converge/verify.
- **Silent seed failure** — the Authentik seed is a one-shot whose `Exited (1)`
  (the worker/blueprint race) does not fail the deploy. We hit exactly this on
  `azb-ad`: OIDC web login was dead for 7 days while every container read
  "healthy". (Seed script race itself is fixed under PR #147; this deploy must
  still *verify the outcome*.)
- **No dev/prod separation** — one script, one set of inline defaults.

This Ansible process is the managed, self-validating replacement, with dev fully
working now and prod as fill-in-later seams.

## 2. Decisions (locked)

| # | Decision | Choice |
|---|----------|--------|
| D1 | Implementation style | **Native Ansible tasks** (not a wrapper around `install.sh`). `install.sh` remains the `curl\|bash` quick-path. |
| D2 | Connection + privilege | **Local control node**, connect as `keith`, `become: true`, run with `--ask-become-pass` (`-K`). No VM changes. **Host connection vars are inline in the inventory** (`ansible_host=192.168.11.126`, `ansible_user=keith`, `ansible_ssh_private_key_file=~/.ssh/id_rsa`) — NOT `-F deploy/ssh_config` (relative `-F` resolves against CWD, and the VPN route is OS-level on `tun0`, independent of ssh_config). |
| D3 | Env/secrets scope | **Dev now, prod seams stubbed.** `inventories/{dev,prod}`; dev secrets plaintext (throwaway), prod via `ansible-vault` (stubbed `.example`, no values committed). |
| D4 | `.env` strategy | **C1 — full Jinja2 `env.j2` rendered from `group_vars`.** Single source of truth; prod differs by vars only. `env.j2` carries a header comment cross-linking `deploy/dev/.env.example` so schema drift is visible. |

## 3. Non-Goals (YAGNI)

- Separate `reset` / `reseed` / `down` playbooks — `just` already covers these;
  role **tags** let us run subsets of `site.yml`.
- Production TLS / reverse-proxy / Cloudflare tunnel wiring — prod *seams* only.
- Multi-host / clustering — single target host.
- CI integration of the playbook — manual `ansible-playbook` invocation for now.

## 4. Architecture

```
control node (this box)
   │  ansible-playbook -i inventories/dev site.yml -K
   │  (SSH via deploy/ssh_config → vpn-vm, become: keith→root)
   ▼
vpn-vm (azb-ad, 192.168.11.126)
   ├─ role: host_prep    → git/curl/jq, Docker Engine + Compose v2, just, docker group
   └─ role: azblink_app  → clone/update repo, render .env, ensure ext network,
                           compose up, deep-health wait, OIDC-seed VERIFY (hard gate)
```

Two roles with clean boundaries:

- **`host_prep`** — host-level prerequisites only. Reusable, app-agnostic. Inputs:
  package list, docker-group user. No app knowledge.
- **`azblink_app`** — owns the application stack lifecycle on the host. Inputs:
  repo URL/branch, install dir, the full `.env` variable set, host identity.

## 5. Repository Layout

```
deploy/ansible/
  ansible.cfg                      # inventory default, ssh_config reuse, become defaults, retries
  requirements.yml                 # collections: community.docker (only — nothing else is used)
  site.yml                         # play: hosts=azblink, roles host_prep→azblink_app (tagged)
  README.md                        # how to run (dev), how to add prod
  inventories/
    dev/
      hosts.ini                    # [azblink] host with inline ansible_host/user/private_key_file
      group_vars/
        all/                       # DIRECTORY — every file auto-loads for the `all` group
          main.yml                 # non-secret dev config (ports, repo, branch, server_host, .env values)
          vault.yml                # dev secrets PLAINTEXT (throwaway creds)
    prod/                          # STUBBED SEAMS — copy of dev shape, no live values
      hosts.ini.example
      group_vars/
        all/
          main.yml.example
          vault.yml.example        # `ansible-vault encrypt` target
  roles/
    host_prep/
      tasks/main.yml               # utils, docker (get.docker.com or distro), compose check, just, docker group
      defaults/main.yml
    azblink_app/
      tasks/main.yml               # orchestrates the steps below via include_tasks
      tasks/fetch.yml              # git clone/update (idempotent, ff-only)
      tasks/config.yml             # render .env from env.j2; ensure cloudflare-tunnel placeholder network
      tasks/deploy.yml             # docker_compose_v2 up
      tasks/verify.yml             # deep-health poll + Authentik provider/app assertion
      templates/env.j2             # full .env, values from group_vars
      defaults/main.yml
```

## 6. Component Detail

### 6.1 `host_prep`
- `ansible.builtin.package` (or `apt`) for `git`, `curl`, `jq`.
- Docker Engine + Compose v2: prefer the official convenience install
  (`get.docker.com`) via `ansible.builtin.shell` **guarded by a `creates`/`command -v docker` check** so it is idempotent; enable+start `docker` via `ansible.builtin.systemd`.
- `just`: install to `/usr/local/bin` guarded by a presence check.
- Add the connecting user to the `docker` group (`ansible.builtin.user`).
- Tag: `host`.

### 6.2 `azblink_app`
- **fetch.yml** — `ansible.builtin.git` to `install_dir` (default `/opt/azblink-directory`),
  `version: "{{ azblink_branch }}"`, `update: yes`, `force: no`. Idempotent.
- **config.yml** —
  - `ansible.builtin.template: src=env.j2 dest={{ install_dir }}/deploy/dev/.env`
    mode `0640`. Re-render is idempotent; changes notify a stack-restart handler.
  - `community.docker.docker_network: name=cloudflare-tunnel` to satisfy the
    compose `external` network reference on hosts without the author's central
    infra (mirrors the placeholder the VM's patched script creates).
- **deploy.yml** — `community.docker.docker_compose_v2: project_src={{ install_dir }}/deploy/dev, state: present, build: always`.
  `build: always` reproduces `just up-bg` (= `docker compose up -d **--build**`) — the
  stack has custom `Dockerfile.*` images that must be (re)built. Uses the
  `docker compose` CLI under the hood (already on the VM: Compose v5). Runs under
  the play's `become: true` (root) so it does not depend on the freshly-added
  docker-group membership taking effect mid-run.
- **verify.yml** (the hard gate) — all checks run **on the target host** (default
  `uri` behavior); `localhost` is the VM's own loopback, so no `delegate_to`.
  1. `ansible.builtin.uri` poll `http://localhost:8081/api/health/deep` until
     `json.ok == true`, `retries`/`delay` ≈ 10 min cap.
  2. `ansible.builtin.uri` against Authentik Admin API (Bearer
     `{{ authentik_bootstrap_token }}`), **with `retries`/`until`** (≈30×10s) because
     `compose up -d` detaches and the seed one-shot runs *asynchronously* after
     bring-up — a single check could fire before the seed completes. Poll
     `until` `providers/oauth2/` count == 1 **and** `core/applications/` count == 1;
     then assert discovery endpoint 200. `failed_when` on timeout → the deploy
     fails loudly instead of leaving a broken IdP. (Optional future enhancement:
     on timeout, `docker start -a azblink-authentik-seed` once and re-check.)
- Tags: `app`, plus `verify` on verify.yml so the gate can be run standalone.

### 6.3 `env.j2` (D4)
- Renders the **full active key set** of the deployed `.env`, values sourced from
  `group_vars` (`all.yml` non-secret, `vault.yml` secret). Note: several keys in
  `.env.example` ship **commented-out** as optional overrides
  (`CORS_ORIGINS`, `OAUTH2_REDIRECT_URIS`, `OAUTH2_POST_LOGOUT_REDIRECT_URIS`) —
  the template **emits them uncommented, host-derived** (a real remote deploy
  always needs them), reproducing `apply_host_config()`.
- Header comment: `# GENERATED by deploy/ansible — keep keys in sync with deploy/dev/.env.example`.
- The browser-facing keys (`VITE_OIDC_ISSUER`, `OIDC_ACCEPTED_ISSUERS`,
  `CORS_ORIGINS`, `OAUTH2_REDIRECT_URIS`, `OAUTH2_POST_LOGOUT_REDIRECT_URIS`) are
  derived from a single `server_host` var.
- **Prod-safety interaction (`ENVIRONMENT` × `DEV_AUTH_TOKEN`):** the API refuses
  to start when `ENVIRONMENT=production` while `DEV_AUTH_TOKEN` is set. The
  template emits `DEV_AUTH_TOKEN` **only when it is non-empty**; dev sets
  `ENVIRONMENT=development` + a token, the prod seam sets `ENVIRONMENT=production`
  + an empty token (key omitted). This makes a misconfigured prod fail fast at
  the API rather than silently enabling the dev bypass.

## 7. Variable Model

`group_vars/dev/all.yml` (non-secret), illustrative:
```yaml
azblink_repo: "git@github.com:KeithMoc/azb-azblink-directory-and-identity-stack.git"
azblink_branch: "main"
install_dir: "/opt/azblink-directory"
server_host: "192.168.11.126"      # drives all browser-facing OIDC/CORS keys
docker_user: "keith"
azblink_environment: "development" # → .env ENVIRONMENT; prod seam = "production"
# ...non-secret .env values: LDAP DNs/domain, OIDC_AUDIENCE/ADMIN_GROUP/GROUPS_CLAIM,
#    AUTHENTIK_API_URL, UCCHAT_* placeholders, ports, TTLs...
```
`group_vars/dev/vault.yml` (plaintext in dev; encrypted shape in prod) — the full
secret set: `postgres_password`, `ldap_admin_password`, `ldap_bind_pw`,
`org_qr_signing_secret`, `authentik_pg_pass`, `authentik_secret_key`,
`authentik_bootstrap_password`, `authentik_bootstrap_token`, `authentik_api_token`,
`dev_auth_token`.
```yaml
ldap_bind_pw: "adminpassword"
authentik_bootstrap_token: "dev-authentik-api-token"
dev_auth_token: "dev-test-token"        # prod seam: "" (empty → key omitted from .env)
# ...
```
Prod `.example` files mirror these keys with placeholder/redacted values, and set
`azblink_environment: production` + `dev_auth_token: ""` (see §6.3 prod-safety).

## 8. Idempotency & Re-run Semantics

- `git`, `template`, `docker_network`, `docker_compose_v2`, `user`, `package`
  are all natively idempotent → a no-op converge reports `changed=0`.
- Shell-guarded installs (docker, just) use presence checks → no re-install.
- A changed `.env` is picked up by the **same `docker_compose_v2` task**:
  `state: present` + `build: always` re-evaluates the effective config and
  recreates only the containers whose config changed — no separate handler needed
  (the prior draft's restart handler is dropped as redundant).
- `verify.yml` runs every converge → continuously asserts the IdP is wired.

## 9. Validation / Success Criteria

A run is successful iff:
1. `ansible-playbook ... -K` completes with no failed tasks.
2. `/api/health/deep` → `ok: true`.
3. Authentik `providers=1`, `apps=1`, discovery `200`.
4. A second immediate run reports `changed=0` for converge tasks (idempotency proof).
5. Browser login at `http://{{ server_host }}:8081/` reaches Authentik and back
   (manual e2e, optional).

## 10. Risks & Mitigations

| Risk | Mitigation |
|------|-----------|
| Flaky VPN drops mid-play | `ansible.cfg` SSH `ServerAliveInterval`, `retries`, `timeout`; idempotent re-run resumes safely. |
| `become` password prompt blocks automation later | Documented `-K`; prod can adopt a vaulted become pass or NOPASSWD sudoers (out of scope now). |
| `env.j2` drifts from `.env.example` schema | Header cross-link comment + a CI/lint follow-up (noted, not built). |
| Cold-boot Authentik slower than health cap | 10-min poll cap matches `install.sh`; tunable via var. |
| `docker_compose_v2` module version skew | Pin `community.docker` in `requirements.yml`. |
| `ansible.builtin.git` fails/discards on local edits in `/opt` (e.g. a hand-applied hotfix) | Default `force: no` → fail loudly on dirty tree (operators must not hand-edit `/opt`); a `force: yes` var is available for intentional reset. Document in role README. |
| Target lacks a Python 3 interpreter for Ansible modules | Ubuntu 24 ships `python3`; rely on interpreter auto-discovery, add `host_prep` assertion if missing. |

## 11. Open Questions

None blocking. Deferred: whether to later fold `install.sh` into a thin shim that
calls the playbook (keeps one source of truth) — revisit after prod lands.

## 12. Implementation & Validation (2026-06-22)

Implemented per `docs/superpowers/plans/2026-06-21-ansible-deploy-baseline.md`
(branch `feat/ansible-deploy-baseline`).

**Validated:**
- Full play authored, `--syntax-check` clean. Per-task spec+quality reviews and a
  final holistic review passed.
- **Verify gate validated LIVE** against `azb-ad` (192.168.11.126):
  `ansible-playbook site.yml --tags verify -e ansible_become=false` → `ok=6,
  failed=0` (deep-health ok, OAuth2 provider filtered `?client_id=azblink-directory`
  count==1, application filtered `?slug=azblink-directory` count==1, OIDC discovery
  200).
- Live run surfaced + fixed a structural bug: a standalone `group_vars/vault.yml`
  is **never auto-loaded** (Ansible loads `group_vars/all.yml`/`<group>.yml` only).
  Moved vars into a `group_vars/all/` directory; re-validated (secrets resolve).

**Pending operator action** (interactive `sudo` required — not runnable headless):
- Full `ansible-playbook site.yml -K` converge (`host_prep` + `config` + `deploy`)
  and the second-run idempotence proof (§9.4).

**Environment note — `azb-ad` is air-gapped from GitHub:** `origin` =
`/home/keith/azb-src` (local), GitHub SSH = `Permission denied (publickey)`. The
default `azblink_repo` (`git@github.com:…`) cannot fetch there. Run with
`--skip-tags fetch` (code already on `/opt`) or `-e azblink_repo=/home/keith/azb-src`.
For remote/prod targets, set `azblink_repo` to an HTTPS+PAT URL or provision an SSH
deploy key. A future "ship code from control node" (rsync) fetch mode would make
the baseline robust for air-gapped prod — deferred until the prod target is known.
