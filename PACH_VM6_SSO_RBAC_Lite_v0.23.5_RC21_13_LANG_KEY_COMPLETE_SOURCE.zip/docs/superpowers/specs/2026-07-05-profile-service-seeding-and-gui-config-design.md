# Design — Profile-service deploy seeding + GUI-dynamic UC config

- **Date:** 2026-07-05
- **Status:** Draft (awaiting user review)
- **Governed surfaces touched:** `src/backend/orgdb.py`, `src/backend/main.py` → `Spec-Patch: 05`
- **Spec section:** `docs/architecture/spec/05-provisioning.md` (`1.1.0 → 1.2.0`)

## 1. Problem

A fresh (prod) deployment ends up with a **Standard Profile that has no XMPP/SIP
services**, so user creation cannot provision UC. Two root causes:

1. **Wrong seed trigger.** `OrgDB.init()` seeds the default profile **only when
   `config_templates` is empty**, and it writes **no service rows** at all. A
   fresh prod deploy seeds the profile shell but no services; an existing dev VM
   (profile already present) never re-seeds. The dev VM only has services today
   because they were added by a one-time manual API call — that state lives in
   the VM's DB, not in code, and does not reproduce on the next VM.

2. **Config is not operator-editable.** XMPP and SIP are **VM-provided external
   servers** whose domains/URLs change over time. The operator must be able to
   repoint them from the GUI at runtime. Today the GUI can only **view** service
   config (`ServiceCard` is read-only); the mutation hooks
   (`useAddService` / `useUpdateService` / `useRemoveService`) exist but are
   **dead code** — wired to nothing. Changing config requires a raw API call.

## 2. Goals / Non-goals

**Goals**
- Every deploy (fresh prod + existing dev) ends with the Standard Profile
  carrying its `xmpp` and `sip` service rows — no manual step.
- Seeding is idempotent and **never clobbers** operator/GUI edits.
- The operator can edit UC service config (domain, WS/WSS URL, enabled, SIP
  extension range) **live from the GUI**, no redeploy.
- Deploy fails loudly if services are missing (verify gate).

**Non-goals**
- No Ansible migration runner (none exists; not introduced here).
- No new UC service *types* (xmpp/sip only; the model already supports more).
- No change to the provisioning read path (`main.py:466–476`) — it already
  reads DB-first with env fallback, which is exactly what we want.

## 3. Key architectural insight — two separate concerns

The original framing conflated "services exist" with "services are configured."
They are independent:

| Concern | When | Mechanism | Source of truth |
|---|---|---|---|
| Services **exist** on the profile | every deploy | idempotent `init()` seed | code |
| Service **config** (domain/URL) | anytime, live | **GUI edit** (PUT service) | the **DB row** |

**Env vars are a bootstrap default, not static config.** Provisioning reads the
DB service config first (`_parse_service_config`, `main.py:466–476`); `UCCHAT_*`
is only a fallback. So once a row exists, GUI edits take effect immediately and
survive every redeploy (seed is insert-if-missing). Env just supplies the
initial value so a fresh deploy isn't dead-on-arrival.

## 4. Design

### 4.1 Backend — idempotent per-service seed (`src/backend/orgdb.py`, `init()`)

Replace the seed-on-empty-table logic with:

1. **Resolve the default profile**: prefer `template_type == "default"`; fall
   back to `name == "Standard Profile"`; if neither exists (empty table), create
   it (unchanged behavior).
2. **Ensure `xmpp` and `sip` rows exist** on that profile. For each type:
   - If a row already exists for `(profile_id, service_type)` → **leave it
     untouched** (preserves GUI edits, dev VM's manual rows, counters).
   - Else insert via `add_profile_service(...)`:
     - `xmpp` → `config = {"domain": UCCHAT_XMPP_DOMAIN, "ws_url": UCCHAT_XMPP_WS_URL}`, no counter.
     - `sip`  → `config = {"domain": UCCHAT_SIP_DOMAIN, "wss_url": UCCHAT_SIP_WSS_URL}`, `counter_start=1000`, `counter_end=1999`.
     - `enabled = True`. `config._validate_uc_config()` requires all four
       `UCCHAT_*` vars non-empty at backend startup, so the domain-unset /
       "disabled shell" case below is unreachable in practice — both rows are
       always seeded enabled from real config.

**Blank-domain behavior:** the "no domain configured" case discussed during
design (rows created disabled as an empty GUI shell) does not occur — the
backend refuses to boot with any `UCCHAT_*` var empty, so seeding always has
real values to write. The rows are still always created (never skipped), so
GUI editing works the same either way. An operator can later **disable** a
seeded row from the GUI; that is a legitimate runtime state and must not fail
deploy verification (see §4.2).

Idempotency anchors on the existence check plus the existing
`UNIQUE(profile_id, service_type)` constraint. Runs on every backend startup,
i.e. every `docker compose up` deploy — self-heals fresh prod and existing dev.

Config keys (`domain`, `ws_url`, `wss_url`) match both the provisioning read
(`main.py:466–476`) and the GUI's `CONFIG_LABELS` (`ServiceCard.tsx:11–17`), so
seeded rows round-trip through the UI.

### 4.2 Backend — deploy-verify signal (`src/backend/main.py`, `/api/health/deep`)

Add an **unauthenticated** boolean to the existing deep-health payload, e.g.
`default_profile_services_ok`: true when the default profile's `xmpp`/`sip`
service rows **exist** (were seeded) — not when they are `enabled`. An operator
may legitimately disable a service via the GUI post-seed, and that must not
permanently fail the Ansible verify gate. Vacuously true when no `UCCHAT_*`
domain is configured (kept as a defensive fallback, though startup validation
makes this branch unreachable today). Prod-safe: no admin token required,
reuses the endpoint Ansible already polls.

### 4.3 Deploy — verify gate (`deploy/ansible/roles/azblink_app/tasks/verify.yml`)

Add an `until:` gate on `default_profile_services_ok`, mirroring the existing
Authentik/Grafana gates. A serviceless deploy fails loudly. Not a governed
surface.

### 4.4 Frontend — GUI service editing (`src/components/features/org-profiles/`)

Wire the **existing** dead mutation hooks into a real edit surface:
- Add an **edit affordance** on each `ServiceCard` (rendered in `ConfigTab.tsx`)
  opening a dialog.
- Dialog fields: `domain`, `ws_url` (xmpp) / `wss_url` (sip), `enabled` toggle,
  and SIP `counterStart`/`counterEnd`. Submit → `useUpdateService`.
- Also expose **Add service** (`useAddService`) and **Remove** (`useRemoveService`)
  so a profile with a missing service can be completed from the GUI.
- Follows the two-layer component rules: dialog uses `@azblink/ui` primitives
  (Dialog, Input, Button, etc.); feature component holds the domain logic.
- Not a governed surface (org-profiles components are not in `surfaces.yaml`).

New component files (e.g. `ServiceEditDialog.tsx`) require explicit user
approval before creation, per project rules.

**Deferred (follow-up):** this branch ships domain/URL/enabled repoint via the
edit dialog only. SIP extension-range (`counterStart`/`counterEnd`) editing and
the Add-service / Remove-service affordances were **not** wired in this pass —
`useAddService` and `useRemoveService` remain available but unused. Follow-up
work.

## 5. Data flow (fresh prod deploy)

```
group_vars ucchat_* → env.j2 → UCCHAT_* env
  → compose up → backend boot → init():
      ensure Standard Profile
      ensure xmpp row (enabled, {domain, ws_url})
      ensure sip  row (enabled, {domain, wss_url}, 1000–1999)
  → /api/health/deep: default_profile_services_ok=true
  → verify.yml gate passes
Operator later: GUI edit dialog → PUT service → DB row updated
  → next user create provisions against the NEW config (no redeploy)
```

## 6. Testing (full pyramid, real Docker stack)

- **Backend unit** (`OrgDB.init` seed logic): empty→creates 2 rows with correct
  counters/config/enabled; re-run→no dupes; pre-existing row→untouched;
  verifies idempotency. (No blank-domain case: `UCCHAT_*` is mandatory, so
  seeding always has real values.)
- **Backend integration** (real PG): fresh `init()` creates services; second
  `init()` is a no-op; a manually-edited row survives a re-`init()`.
- **Backend integration** (`/api/health/deep`): flag true after seed; PUT a new
  domain → provisioning read reflects it.
- **Frontend unit** (vitest): edit-dialog payload builder maps fields → PUT body;
  add/remove payloads correct.
- **e2e smoke**: from a clean profile, create a user → provisioning fires
  (uidNumber, extension 1000, SIP password, LDAP `posixAccount` +
  `AsteriskPjsip*` object classes); then edit the SIP domain in the GUI and
  confirm the next provision uses it.

## 7. Governance & delivery

- Spec §05 gains a "default-profile service seeding" subsection; bump
  `spec-meta.version 1.1.0 → 1.2.0`; top-level spec version + CHANGELOG per SOP.
- Commits touching `orgdb.py` / `main.py` carry `Spec-Patch: 05`. Ansible +
  frontend commits carry no trailer (not governed).
- **New GitHub issue** describing the deploy gap + GUI-config requirement →
  **new branch/PR** → CI green → merge → dev VM converge → prod VM converge.

## 8. Risks / open items

- **Prod `group_vars` domains are `example.com` placeholders.** `UCCHAT_*` is
  mandatory (backend refuses to boot if any var is empty), so a placeholder
  domain is non-empty and boots fine — it seeds `example.com` enabled but
  wrong, not a disabled shell (there is no disabled-shell path). Prod must set
  real UC domains in vault before converge; flagged as an operator
  precondition.
- **Deep-health semantics.** Adding a seeding assertion to `/api/health/deep`
  slightly broadens its meaning; acceptable and matches the existing "seed
  verify" intent. Alternative (a `docker exec psql` count in verify.yml) rejected
  as needing DB creds in Ansible.
- **Frontend scope.** The edit dialog is net-new UI; keep it minimal (one dialog,
  reuse primitives) to bound PR size.
