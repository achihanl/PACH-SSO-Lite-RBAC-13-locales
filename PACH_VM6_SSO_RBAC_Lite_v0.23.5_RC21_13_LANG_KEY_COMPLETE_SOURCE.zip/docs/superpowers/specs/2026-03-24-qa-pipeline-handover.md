# Handover: QA Pipeline Implementation

**Date:** 2026-03-24
**From:** Telegram brainstorming session (CLAUDE_STEWARD workspace)
**To:** Implementation agent (azb-azblink-directory-and-identity-stack workspace)

## Task

Implement the QA pipeline described in:
`docs/superpowers/specs/2026-03-24-qa-pipeline-design.md`

## Context

The user wants a three-layer QA-as-code pipeline that:
1. Uses gstack `/browse` for exploratory testing and app discovery
2. Exports browse sessions to deterministic Playwright tests
3. Runs Playwright locally and in CI — gstack never runs in CI

The design was brainstormed collaboratively and approved through 6 sections of interactive design review, then validated by an automated spec reviewer (passed on second iteration after fixing 2 critical + 4 major + 7 minor issues).

## What Exists Today

- **Backend tests:** 47 pytest files, solid coverage, run against real Docker stack
- **Frontend tests:** 4 Playwright E2E specs (dashboard, pagination, resizable-panel, settings), 1 Vitest unit test
- **Playwright config:** `src/frontend/playwright.config.ts` (baseURL: localhost:3000, webServer: npm run dev)
- **Justfile:** Has `test`, `test-quick`, `test-cov`, etc. — no QA pipeline commands yet
- **CI:** Only a `release.yml` workflow — no test pipeline
- **gstack:** Installed globally at `~/.claude/skills/gstack/`, `/browse` verified working against this app

## What Needs to Be Built

### Phase 1: Foundation
- [ ] Create `qa/manifest.yml` with all pages, flows, redirects, and auth config
- [ ] Create `.claude/skills/qa-azblink/SKILL.md` — the local orchestration skill
- [ ] Create `src/frontend/e2e/setup/auth.setup.ts` — Playwright auth setup project
- [ ] Create `src/frontend/e2e/fixtures/authenticated-page.ts` — dev bypass fixture
- [ ] Update `src/frontend/playwright.config.ts` with setup/smoke/full projects and conditional webServer
- [ ] Add `qa/.auth/` and `qa/sessions/` to `.gitignore`
- [ ] Migrate all 4 existing Playwright specs to `authenticatedPage` dev bypass fixture (they are currently broken)

### Phase 2: Explore & Export Engine
- [ ] Implement `/qa-azblink explore` subcommand in the skill
- [ ] Define session log JSON schema (example in spec)
- [ ] Implement `/qa-azblink export` subcommand — gstack command → Playwright code mapping
- [ ] Generate initial specs for all manifest pages via explore → export

### Phase 3: Smoke Tests
- [ ] Generate page-load smoke tests for all pages in manifest
- [ ] Verify all pages load correctly with auth
- [ ] Add sidebar navigation flow test
- [ ] Add SSO login flow test

### Phase 4: CI Integration
- [ ] Create `.github/workflows/qa.yml` — PR-triggered Playwright smoke suite
- [ ] Add Justfile commands: `qa-smoke`, `qa-full`, `qa-ui`, `qa-report`
- [ ] Verify CI workflow works with Docker stack

### Phase 5: Report & Promote
- [ ] Implement `/qa-azblink report` — manifest vs spec coverage
- [ ] Implement `/qa-azblink promote` — move generated specs to hand-owned
- [ ] Implement `/qa-azblink run` wrapper

## Key Design Decisions (already approved)

1. **Auth:** Dual strategy — dev bypass token (`Authorization: Bearer dev-test-token`) for speed, Playwright auth setup project for real SSO tests. Existing broken tests migrate to dev bypass in Phase 1.
2. **Environments:** `BASE_URL` env var (default: localhost:8081 Docker stack). `USE_DEV_SERVER=true` for Vite dev server on 3000.
3. **gstack stays local:** Explore/export are developer-driven, token-intensive operations. CI only runs deterministic Playwright output.
4. **Manifest is source of truth:** Pages, flows, assertions defined declaratively. Specs are generated from exploration sessions.
5. **Promotion lifecycle:** `e2e/generated/` → explore/export output. `e2e/` → promoted/hand-written, not overwritten.

## Important Caveats

1. **Auth bypass verified:** `Authorization: Bearer <DEV_AUTH_TOKEN>` in `src/backend/main.py` (`_claims_from_auth_header()`). Returns synthetic admin claims. The spec's `authenticatedPage` fixture uses this — NOT a custom `X-Dev-Auth` header.
2. **CI workflow should use `just up-bg`** (not `just up`) to avoid blocking — `just up` runs in foreground.
3. **Existing 4 Playwright specs are ALL broken.** Login page is now Authentik OIDC only — `#username`/`#password` form fields no longer exist. `dashboard.spec.ts` and `resizable-panel.spec.ts` have no auth at all. **Migrating all 4 to the `authenticatedPage` dev bypass fixture is a Phase 1 task**, not a future pass.
4. **SSO login flow** assumes Authentik's current 2-step password form. If Authentik config changes, the flow steps in manifest and auth.setup.ts need updating.
5. **Session log captures accessibility role + name** (not @e ref numbers) so exports map to `getByRole()` / `getByText()` — more resilient to DOM changes.

## How to Start

```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack

# Read the full spec first
cat docs/superpowers/specs/2026-03-24-qa-pipeline-design.md

# Read existing Playwright config
cat src/frontend/playwright.config.ts

# Read existing e2e tests for patterns
ls src/frontend/e2e/

# Check existing Justfile structure
cat Justfile

# Verify Docker stack is up
just health-check
```

## Credential Reference

| Service | User | Password | Port |
|---|---|---|---|
| Authentik SSO | akadmin | adminpassword | 9000 |
| PostgreSQL | azblink_directory | azblink_directory | 5433 |
| OpenLDAP | cn=admin,dc=azblink,dc=com | adminpassword | 1390 |
| Dev Auth Token | — | dev-test-token | — |

## Files to Read

| File | Why |
|---|---|
| `docs/superpowers/specs/2026-03-24-qa-pipeline-design.md` | The full approved spec |
| `CLAUDE.md` | Project conventions, commands, architecture rules |
| `src/frontend/playwright.config.ts` | Current Playwright setup to extend |
| `src/frontend/e2e/*.spec.ts` | Existing test patterns to maintain compatibility |
| `Justfile` | Where to add QA commands |
| `src/frontend/package.json` | Available scripts, dependencies |
