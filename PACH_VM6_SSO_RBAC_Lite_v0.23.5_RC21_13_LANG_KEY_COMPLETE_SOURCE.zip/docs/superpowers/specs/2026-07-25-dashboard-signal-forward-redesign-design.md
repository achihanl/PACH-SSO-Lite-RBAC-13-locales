# Dashboard — Signal-Forward Redesign

**Date:** 2026-07-25
**Status:** Design approved; corrections from source review folded in; pending final spec review → implementation plan
**Scope:** Signal-forward redesign (frontend + minimal additive backend, no schema changes)
**Companion:** `2026-07-25-dashboard-signal-forward-redesign-review.md` (spec ↔ source audit; evidence for every claim here)

## Problem

The current dashboard is a Phase-2/3 scaffold that got wired to real APIs in places but never had a signal-vs-noise pass. Three concrete failures:

1. **The most prominent real estate shows fabricated data.** Two of the four hero stat tiles are permanently zero:
   - `active_sessions` — hardcoded `0` (`orgdb.py:1159`, "no session tracking table").
   - `success_rate` — hardcoded `0` (`orgdb.py:1158`, "QR audit table removed").
2. **The health panel shows meaningless always-green rows.** `/api/dashboard/health` checks XMPP/SIP only for *is the domain configured* — and since `UCCHAT_*` is **mandatory at startup** (`config.py:368` `_validate_uc_config` raises if empty; spec `05-provisioning.md:59`), the domain is always set, so XMPP/SIP always report `healthy` with **no real reachability probe**. That is false assurance, not signal. *(An earlier draft framed this as "false-red on a directory-only deploy" — that was wrong: the backend cannot boot UC-unconfigured, so the red path is unreachable. Corrected after the Task 1 review.)*
3. **The platform's richest actionable signals are absent.** Backend endpoints already expose compliance/security alerts, users-by-status, live LDAP connections, and stack "update available" — none surface on the dashboard.

Plus accumulated dead code: stale "Phase 2/3 mock data" comments, an orphaned `recentQR` query key with a dead invalidation, a `trends` delta-badge path the backend never feeds, a dead "View All" button, and an activity icon map that renders user/provisioning/admin events as QR icons.

## Investigation findings (as-built)

### Current widgets and signal quality
Route `src/frontend/src/routes/index.tsx` → components in `src/frontend/src/components/features/dashboard/`, queries in `src/frontend/src/lib/queries/dashboard.ts`.

| Widget | Data reality | Verdict |
|---|---|---|
| Total Users tile | Real — `list_users()` LDAP count | Keep |
| Active Sessions tile | Hardcoded `0` (`orgdb.py:1159`) | **Kill** |
| Pending Provisions tile | Real | Keep |
| QR Success Rate tile | Hardcoded `0` (`orgdb.py:1158`) | **Kill** |
| Provisioning chart (generated/consumed) | Real — `device_provisions` buckets | Keep |
| System Health (6 svc) | XMPP/SIP are always-green non-probes (UC mandatory at startup) | Fix — drop XMPP/SIP |
| Pending Provisions list | Real, expiry-sorted | Keep; wire dead "View All" |
| Quick Actions | Static nav, empty 4th cell | Keep, trim |
| Activity Feed | Real live WebSocket feed | Keep; fix icon map |

### High-signal endpoints that already exist but are unused
- **Compliance/security alerts** — `GET /api/provisioning/compliance` (`main.py:2513`; `orgdb.py:2203`): 5 alert types incl. critical `cross-user-device`. Richest ops signal in the backend; 60s cached. **Permission-gated** (`device_provisioning`), not `require_admin`.
- **Users by account status** — `GET /api/users` returns `total`; each user carries `accountStatus ∈ {active, pending, suspended, terminated}` (`ldap_client._derive_account_status`, `ldap_client.py:659`).
- **Live LDAP client connections** — `connected_now` in `GET /api/settings/ldap/clients` (`main.py:3867`). *(Deferred; hook `useLdapClients()` already exists.)*
- **Stack update-available** — Authentik `outdated` flag in `GET /api/system/versions` (`main.py:2831`). *(Deferred; hook `systemVersionsQueryOptions()` already exists.)*

### Out-of-scope signals (would need new backend / schema — deferred)
Utilization ratios (UID range, SIP extension, device-cap "X of Y"), real active-sessions via Authentik API, system-wide entity totals, live UC session counts, real UC reachability probes. These belong to a later "full capacity dashboard" scope.

## Decisions

- **Scope:** signal-forward redesign — surface existing signals, reorganize attention-first, only additive backend changes (no new tables/columns).
- **UC health (D1 — revised after Task 1 review):** **remove XMPP/SIP from the health panel.** They are always-green non-probes — UC is mandatory at startup (`config.py:368`), so the domain is always configured, and there is no live reachability check, so the rows convey no signal. The health panel keeps only the services with real probes: PostgreSQL, LDAP, Redis, Authentik. A real UC reachability probe remains **out of scope** (deferred).
- **Users-by-status (option a — free):** add per-status counts to `GET /api/users`. `list_users()` already enumerates the whole directory in-memory, so a `Counter` over `accountStatus` costs **zero extra LDAP round-trips**. No new route, no schema. The option-(b) total+pending fallback is dropped as unnecessary.
- **Activity icons (D2 — minimal):** expand the frontend union + icon map to cover every type that actually flows from **both** feeds (REST `/activity/recent` and the live WS/SSE bus), and replace the REST `qr-generated` default with a neutral icon. Do **not** normalize the REST↔bus naming divergence (deferred).

## Design

**Principle:** attention-first. The top answers *"what needs me now?"*, fabricated data is deleted rather than faked, detail appears only when it matters, all data comes from existing (or additively extended) endpoints.

### 1. Hero row — 4 tiles (replaces `StatsGrid`)
Responsive `grid-cols-1 sm:grid-cols-2 lg:grid-cols-4`.

| Tile | Source | Behavior |
|---|---|---|
| **Alerts** | `/api/provisioning/compliance` | Count = sum of the `summary` per-type counts. Severity color derived **frontend-side** from `alerts[].severity` (`critical`/`warning`/`low`); critical (`cross-user-device`) → red. Click scrolls to the Compliance card. |
| **Health** | `/api/dashboard/health` (PG/LDAP/Redis/Authentik) | Rollup: "All systems OK" (green) or "N degraded" naming the failing service(s). Expands to per-service detail on click or automatically when degraded — steady-state green shows no service grid. Per-service field is `latency` (string, e.g. `"12ms"`); `status ∈ {healthy, error}`. |
| **Expiring** | `/api/provisions/pending` (+ additive `expires_at`) | Count expiring within 48h; urgency color. Requires the endpoint to expose a machine-readable `expires_at` (see §6). |
| **Users** | `/api/users` `total` + `statusCounts` | Real total with pending; drives the status breakdown below. |

Removed: Active Sessions tile, QR Success Rate tile, and the `trends` delta-badge path (`StatsGrid.tsx:34-56`).

### 2. Main column (left)
- **Provisioning throughput** chart — unchanged (real; 24h/7d/30d toggle).
- **Users by status** — compact segmented bar (active/pending/suspended/terminated) from `statusCounts`.

### 3. Sidebar (right) — a worklist, not vanity
- **Compliance alerts** (new) — top alerts, **sorted critical-first in the frontend** (the API returns type order, not severity order). Each row: type, severity badge, affected subject — handle `cross-user-device` where `subject_uid` is `null` (affected users are in `evidence.users`). Empty → small "No compliance issues." Reuse `complianceQueryOptions()` (`lib/queries/provisioning-ops.ts:65`) and the existing `ComplianceSummaryCards.tsx`.
- **Expiring provisions** — existing `PendingProvisionsCard`; wire the dead "View All" to `/provisioning/devices` (the fleet/ops page, which has a compliance tab — there is no dedicated `/provisions/pending` route) and show relative expiry.
- **Live activity feed** — kept; fix icons across **both feeds**: the REST `type_map` (`main.py:3019`) collapses `config-change`/`admin-action`/device events onto the QR icon and mis-maps `login`; the live bus (`orgdb._publish_activity_event`) emits still-different strings (`provisioning`, `user-suspended`, admin verbs). Expand the `ActivityEventType` union + `ACTIVITY_ICON_STYLES` to cover both, and replace the REST `qr-generated` default with a neutral icon.
- **Quick actions** — trimmed to the three real actions (Add User, Audit Log, Settings) in a responsive grid; the empty 4th cell is removed.
- The always-on standalone health grid is **removed** — its detail now lives in the expandable Health tile (redundant, and noise when green).

### 4. Layout / responsive
Replace fixed `380px` sidebar and hard `grid-cols-4` with `lg:grid-cols-[1fr_minmax(320px,380px)]`, stacking to a single column below `lg`. Hero and health-detail grids get breakpoints so nothing overflows on narrow viewports. Follow the in-repo pattern (`grid-cols-1 sm:grid-cols-2 lg:…`, e.g. `ComplianceSummaryCards.tsx:58`, `LdapClientsPage.tsx:399`).

### 5. Cleanup workstream (delete dead code)
- Stale comments: `dashboard.ts:3-8`, `DashboardMain.tsx:3`, `DashboardSidebar.tsx:4`, `PendingItem.tsx:3`, `QuickActionsCard`/`QuickActionButton` "2x2 grid".
- Orphaned `recentQR` query key (`keys.ts:73`) + dead invalidation (`index.tsx:56`) — leave the adjacent live `'chart'` invalidation intact.
- `DashboardStatsApiResponse.trends` type (`types/dashboard.ts:49-54`) and its consumer path (`StatsGrid.tsx:34-56`).
- Activity `type_map` and `ActivityEventType` fixes (above).

### 6. Backend changes (all additive, no schema)
1. `GET /api/dashboard/health` — remove the XMPP/SIP `_check` calls and their closures entirely from `api_dashboard_health` (`main.py`); the endpoint returns only PostgreSQL, LDAP, Redis, Authentik. (XMPP/SIP were always-green non-probes; UC is mandatory at startup so the old "error when unconfigured" branch was unreachable.)
2. `GET /api/dashboard/stats` — stop returning fabricated `active_sessions`/`success_rate` (`orgdb.py:1158-1159`; endpoint dict `main.py:2726-2731`); keep `total_users` and `pending_provisions`. **Coordinated with** `tests/test_dashboard_api.py:18-22` (which assert both keys), the FE type (`types/dashboard.ts:46,48`), and `StatsGrid.tsx:37,51`.
3. `GET /api/provisions/pending` — add an additive `"expires_at"` field to each item (`main.py:2981`, value already available in `raw`) so the Expiring tile can compute the 48h window. Additive-safe for `tests/test_dashboard_api.py:118-155`.
4. `GET /api/users` — add `"statusCounts"` (`Counter` over `accountStatus` from the already-loaded `list_users()`), computed before the search/status filters. No new LDAP query.
5. Activity — expand icon coverage across REST + live-bus feeds; replace the REST `qr-generated` default with a neutral type (per D2, minimal — no cross-feed rename).

## Out of scope
Full capacity/utilization dashboard, new utilization-ratio endpoints, real active-sessions (Authentik API), system-wide entity totals, live UC session counts, real UC reachability probes, REST↔live-bus event-name normalization. Tracked for a later scope.

## Acceptance criteria
- No dashboard tile displays a hardcoded/placeholder value; every rendered number traces to a live endpoint.
- The health panel shows only services with real probes (PostgreSQL, LDAP, Redis, Authentik); no always-green non-probe (XMPP/SIP) rows remain.
- When a **core** service (PostgreSQL/LDAP/Redis/Authentik) is genuinely down, the Health tile names it. *(Configured-UC down-detection is explicitly out of scope — D1.)*
- Compliance alerts are visible on the dashboard, sorted critical-first; a critical `cross-user-device` alert is unmistakable (severity color + hero count) and renders correctly despite a `null` subject_uid.
- Users-by-status reflects the whole directory via `statusCounts`, not a single page.
- No activity event — from the REST feed or the live bus — renders with the QR icon unless it is actually a QR event.
- `/api/provisions/pending` exposes a machine-readable `expires_at`.
- The dashboard reflows without horizontal overflow from mobile width up through desktop.
- No orphaned query keys, dead invalidations, dead controls, or stale scaffolding comments remain in the dashboard surface.

## Risks / notes
- **API contract changes:** dropping `active_sessions`/`success_rate` and changing the health service list are response-shape changes — the stats change must move with `test_dashboard_api.py` and the FE type/consumer together (no Pydantic model enforces the stats shape, so the test is the only guard).
- **Compliance is frontend-heavy:** severity color, critical-first sort, and null-subject handling are all frontend responsibilities — the API gives type-order alerts and a severity-less summary.
- **Activity naming divergence remains:** the minimal fix (D2) gives correct icons but leaves REST (`device-provisioned`) and the live bus (`provisioning`) using different names for the same event. Acceptable for now; full normalization is deferred.
- **Architecture governance:** `/api/dashboard/health`, `/api/dashboard/stats`, `/api/provisions/pending`, and `/api/users` may be governed surfaces (`docs/architecture/surfaces.yaml`). At implementation time, carry the appropriate commit trailer (`Spec-Patch:` for non-decisional edits, or an `ARD:` if the conditional-UC-health behavior is deemed decisional) per `docs/architecture/SOP.md`.
