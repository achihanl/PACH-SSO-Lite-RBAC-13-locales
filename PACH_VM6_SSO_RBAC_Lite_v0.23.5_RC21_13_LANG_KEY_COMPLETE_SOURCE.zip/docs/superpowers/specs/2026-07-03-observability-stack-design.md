# Design — Observability Stack (dev-first, prod-parity)

> **Date:** 2026-07-03 · **Status:** approved (brainstorm) · **Branch:** `feat/observability-stack`
> **Governance:** ARD-008 (proposed). Touches governed surfaces `deploy/dev/docker-compose.yml`, `deploy/dev/Dockerfile.*`, `src/backend/main.py` → implementation PRs carry `ARD: ARD-008`. Spec §06 (deployment topology) + §07 (security) updates.

## Problem / goal

The platform has **no observability system**. Audit (2026-07-03) found:

- **No metrics** — no `/metrics`, no request/latency/error/resource telemetry. `docker stats` only, unrecorded.
- **No log aggregation** — stdlib `logging`, unconfigured (no `dictConfig`/`LOG_LEVEL`), plain-text, per-container json-file with **no rotation** (P1, confirmed live: `json-file opts=map[]`) → unbounded disk growth, host-fill risk. Logs lost on `docker rm`.
- **No dashboards, no alerting, no tracing.**
- **No restart policy** on 5 core services (postgres, redis, openldap, directory-api, directory-ui) → crash = silent extended outage.
- Health endpoints exist (`/api/health`, `/api/health/deep`, `/api/dashboard/health`) but nothing scrapes/records/alerts on them.

**Goal:** a real, prod-shaped observability stack — metrics + centralized logs + dashboards + alerting — built **dev-first**, where **dev is a faithful shadow of prod**. The only dev↔prod difference is a thin internal/external boundary layer (exposure, TLS, auth on the one external UI); the stack itself is byte-identical across environments.

**Scope:** dev environment, production-ready shape. Full test pyramid per repo convention (real Docker stack, no mocks).

## Non-goals

- **Distributed tracing (OpenTelemetry/Tempo)** — deferred. Request-ID correlation (Phase 0) lays the groundwork cheaply; traces are a later phase if needed.
- **External alert push (Telegram/email)** — user chose Grafana-UI-only notifications. No Alertmanager, no SMTP/bot receiver.
- **Production exposure/TLS/auth hardening** — deferred as tracked tech debt (Phase 4). Prod = this same stack + the thin boundary layer.
- **Long-term/remote storage** (Mimir/Thanos/S3) — local retention (15d metrics / 7d logs) is sufficient for now.
- **APM / profiling** — out of scope.

## Design decisions (locked in brainstorm)

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Scope | Full stack, phased | Matches "same as prod"; foundation-first de-risks |
| Collector topology | **Grafana Alloy** (unified agent) | Fewest moving parts; Grafana's current direction; cheap path to traces |
| Metric store | Prometheus | Canonical pull-model TSDB, fits internal Docker net |
| Log store | Loki | Grafana-native, label-indexed, cheap |
| Viz + alerting | Grafana (Grafana-managed alerts, UI notifications) | One UI; no Alertmanager needed |
| Alert routing | Grafana UI only | User choice — no external push |
| Metrics retention | 15 days | Local disk budget |
| Logs retention | 7 days | Local disk budget |
| Dev Grafana auth | `admin`/`admin` + provisioned dashboards | Editable in dev; baseline as code |
| Config delivery | Provisioned-as-code (datasources/dashboards/alerts) | dev==prod, reproducible, no click-ops |
| Compose strategy | Single compose, internal-only default; exposure per-env | No separate prod compose to drift |

## Architecture / topology

New observability service group in the **same** `deploy/dev/docker-compose.yml`, on `azblink-net`. One collector (Alloy), two stores (Prometheus, Loki), one UI (Grafana).

```
  host /proc,/sys ─┐
  docker.sock ─────┼─► Alloy ──(remote_write metrics)─► Prometheus ─┐
  api:8000/metrics┘        └──(push logs)────────────► Loki ────────┼─► Grafana ─► dashboards + alerts (UI)
  container stdout ───────(tail via docker.sock)─────► Loki ────────┘
```

**Invariant:** observability never takes down the app plane. No `depends_on` from `directory-api` → any obs service. Obs failure = blind, not outage.

## Components

### alloy (Grafana Alloy)
- **Purpose:** single collection agent — host metrics, container metrics, container-log tailing, scrape `directory-api:8000/metrics`.
- **Reads:** `/var/run/docker.sock:ro` (container discovery + logs + cgroup metrics), host `/proc`+`/sys` (bind-mounted ro), `directory-api:8000/metrics`.
- **Writes:** metrics → Prometheus (`remote_write`); logs → Loki (`loki.write`).
- **Config:** `deploy/dev/obs/alloy/config.alloy` (River/Alloy syntax), mounted ro.
- **Deps:** none hard; targets discovered dynamically. Buffers/drops on store outage — never blocks a container.

### prometheus
- **Purpose:** metrics TSDB + query. **Internal-only** (no host port either env).
- **Config:** `deploy/dev/obs/prometheus/prometheus.yml` — 15d retention (`--storage.tsdb.retention.time=15d`), receives Alloy remote-write; may also self-scrape.
- **Volume:** `azblink_prometheus_data`.

### loki
- **Purpose:** log store + LogQL. **Internal-only.**
- **Config:** `deploy/dev/obs/loki/loki-config.yml` — filesystem storage, 7d retention (`table_manager`/`compactor` retention).
- **Volume:** `azblink_loki_data`.

### grafana
- **Purpose:** dashboards + Grafana-managed alerting (UI notifications). **The one obs UI that gets external exposure** = the thin layer.
- **Provisioned (config-as-code):** `deploy/dev/obs/grafana/provisioning/` — datasources (Prometheus + Loki), dashboards, alert rules; dashboard JSON in `deploy/dev/obs/grafana/dashboards/`.
- **Dev:** host port `3002`, `admin`/`admin`, no TLS.
- **Volume:** `azblink_grafana_data`.

## Backend changes (Phase 0)

`src/backend/` — hot-reloads (no rebuild) except the new dependency.

- **Structured logging:** `logging.dictConfig` at startup — level from `LOG_LEVEL` env (default `INFO`), JSON formatter (`ts`, `level`, `logger`, `msg`, `request_id`), fix propagation so app `__name__` loggers surface (today they ride uvicorn defaults inconsistently). Delivery: fold into `config.py`/`main.py` startup **or** a small dedicated module — see New Files.
- **`/metrics` endpoint:** `prometheus_client` (new pinned dep → `just lock-backend && just api-rebuild`). ASGI middleware records request count / latency histogram / in-flight gauge / error count by `method`,`path_template`,`status`. Re-expose existing signals — rate-limit rejections (Redis), audit counts, health-probe latencies, LDAP-collector bind activity.
- **Request-ID middleware:** accept/generate `X-Request-ID`, bind into log records (contextvar) and echo in response header. Correlates logs now; trace-ready later.

## Infra changes (Phase 0) — closes audit P1/P2, zero new containers

- **Log rotation:** compose `logging:` block (`driver: json-file`, `max-size: 10m`, `max-file: 3`) on **every** service → kills the unbounded-log risk.
- **Restart policies:** `restart: unless-stopped` on postgres, redis, openldap, directory-api, directory-ui (healthchecks already present to surface crash-loops).
- **Traefik hygiene:** `--log.level=INFO` (from DEBUG), `--accesslog=true` (JSON — free structured request telemetry into the log pipeline), add container healthcheck; dashboard stays dev-only (prod gates/closes it).

## The internal/external boundary (the thin layer)

Single compose, **internal-only by default; exposure added per-environment** — no separate prod compose to drift.

| Component | Dev | Prod (deferred, Phase 4) |
|-----------|-----|--------------------------|
| prometheus / loki / alloy | No host port; `azblink-net` only | **Identical** — internal-only, never exposed |
| grafana | Host port `3002`, `admin`/`admin`, no TLS | Cloudflare tunnel + **Authentik OIDC** (reuse Plane B) + Traefik auth middleware; no direct host port; TLS |
| Redis | No auth | Password + TLS (DEPLOYMENT_SPEC §prod) |
| LDAP | Plain | LDAPS / StartTLS (DEPLOYMENT_SPEC §prod) |

The obs stack config (Alloy/Prometheus/Loki/Grafana provisioning) is **byte-identical** across envs. Prod↔dev delta = exposure/auth/TLS only, rendered via **ansible group_vars per inventory** (matches how ansible already templates compose/env). This is exactly the DEPLOYMENT_SPEC §474–497 internal-only model.

## Phasing — each phase = own PR, independently shippable + tested

- **P0 Foundation** (no new containers): log rotation, restart policies, JSON logging + `LOG_LEVEL`, `/metrics`, request-id, Traefik hygiene. Closes all audit P1/P2. Prerequisite for scraping.
- **P1 Metrics + dashboards:** Alloy (metrics) + Prometheus + Grafana + provisioned Prometheus datasource + baseline dashboards (per-service health, host/container resources, request rate/latency/error, LDAP binds, rate-limit rejections).
- **P2 Logs:** Alloy (logs) + Loki + provisioned Loki datasource + Grafana log explore + metric↔log correlation via request-id.
- **P3 Alerting:** Grafana-managed alert rules (service-down via `/api/health/deep`, disk %, error-rate spike, restart-loop) → Grafana UI.
- **P4 (deferred → tech debt):** prod exposure/TLS/auth boundary layer only. Tracked in memory + tech-debt register.

## Testing strategy (repo convention: real Docker stack, no mocks)

- **P0:** unit (formatter emits JSON + request_id; `/metrics` returns valid Prometheus exposition); integration (counters increment on real requests; config test asserts compose has `logging:` + `restart:` on required services); smoke (`curl /metrics` on live stack).
- **P1/P2:** integration (Prometheus API: `up==1` for the api target; Loki LogQL query returns ingested container lines; Grafana datasource-health API green); e2e smoke (Grafana `/api/health` + a provisioned dashboard renders).
- **P3:** induce failure (stop redis) → assert the service-down alert transitions to firing in Grafana's alert API.

## Failure isolation / error handling

- **No `depends_on` from `directory-api` → any obs service.** Obs down = blind, never an outage.
- `/metrics` and logging degrade gracefully — endpoint or formatter failure must not fail a request (formatter falls back to plain text).
- Alloy buffers/drops on Prometheus/Loki push failure — never blocks a container's stdout.
- Obs containers get their own `restart: unless-stopped` + healthchecks; their failure is self-contained.

## Governance

- **ARD-008** (proposed) — "Observability stack (metrics/logs/dashboards/alerting)". Created at implementation start (PR-1 of §6.1 pattern).
- Governed surfaces touched: `deploy/dev/docker-compose.yml`, `deploy/dev/Dockerfile.*`, `src/backend/main.py` → each implementation PR carries `ARD: ARD-008`.
- Spec sections to update: §06 deployment topology (new service group + data flow), §07 security (Grafana exposure/auth boundary). Bump `spec-meta.version` per SOP.

## New files to be created (per ask-before-new-file rule — approved in brainstorm)

- `deploy/dev/obs/alloy/config.alloy`
- `deploy/dev/obs/prometheus/prometheus.yml`
- `deploy/dev/obs/loki/loki-config.yml`
- `deploy/dev/obs/grafana/provisioning/**` (datasources, dashboards, alerting)
- `deploy/dev/obs/grafana/dashboards/*.json`
- Backend logging/metrics: prefer folding into existing `config.py`/`main.py`; a small `src/backend/observability.py` module only if it keeps `main.py` focused (decide at plan time).
- Tests under `tests/` (obs integration + config assertions).
- `docs/architecture/decisions/ARD-008-observability-stack.md` (at implementation).

Modified (no new file): `deploy/dev/docker-compose.yml`, `deploy/dev/Dockerfile.api`, `src/backend/main.py`, `src/backend/config.py`, `src/backend/requirements.txt` (+ `.lock`).

## As-built notes (2026-07-03) — reconciliation vs. design above

Delivered as one PR (P0–P3 + the single Operator Dashboard). Deviations found during live integration:

- **No cAdvisor.** The dev/prod host runs **Docker 29 with the containerd-snapshotter image store** (`Storage Driver: overlayfs`, `io.containerd.snapshotter.v1`). That store has no classic `image/overlay2/layerdb`, so cAdvisor (both Alloy's in-process exporter and a dedicated `gcr.io/cadvisor/cadvisor` container, incl. `cgroup: host`) cannot identify container rw-layers → reports **zero containers**. cAdvisor was removed entirely.
- **Per-service health via a backend probe.** Replaced cAdvisor-derived `container_last_seen` liveness with an authoritative backend gauge **`azblink_service_up{service}`** — a 20s lifespan probe (off the event loop, double fault-isolated) covering 11 platform services: directory-api, postgresql, redis, ldap, authentik, prometheus, loki, grafana, traefik, directory-ui, alloy. This is *better* operator signal (actual reachability, not container-running) and fully prod-portable. Trade-off: **no per-container CPU/mem panels** (host CPU/mem/disk retained via Alloy's node exporter).
- **Logs scoped to `azblink-*`.** Alloy `discovery.docker` tails only containers whose name matches `/azblink-.*` (a relabel keep rule) — satisfies the operator "no noise, this platform only" requirement and eliminates Loki `timestamp too old` 400s from unrelated host containers.
- **Alerting = 4 Grafana-managed rules** (UI-only): target-down (`up==0`), **service-down (`azblink_service_up==0`)**, API 5xx ratio >5%, host disk >85%.
- **Pinned images:** `prom/prometheus:v3.1.0`, `grafana/loki:3.3.2`, `grafana/alloy:v1.5.1`, `grafana/grafana:11.4.0`.
- **Metric access:** `/metrics` is API-internal (Alloy scrapes `directory-api:8000/metrics`); it is *not* routed through Traefik. Prometheus/Loki have no host ports; Grafana (`:3002`, admin/admin dev) is the only host-published obs UI — the thin boundary.
- Governance: **ARD-008**; implementation commits carry `ARD: ARD-008`.

## Deferred (tech debt — see memory `project_observability_prod_parity_tech_debt_2026_07_03`)

- Phase 4 prod boundary: Grafana behind tunnel + Authentik OIDC + Traefik auth; internal-only enforcement; Redis password+TLS; LDAPS.
- Optional later: OpenTelemetry + Tempo tracing (request-id groundwork already laid).
- Frontend RUM: wire `ErrorBoundaryCard` → backend error sink (currently `console.error` only).
