# Design — Multi-language (i18n) support: English · Traditional Chinese · Simplified Chinese

- **Date:** 2026-07-06
- **Branch:** `feat/i18n-multilanguage`
- **Status:** design → implementation (combined draft PR)
- **Author:** Keith + Claude (autopilot)

## Goal

- Make the admin UI fully translatable; ship `en` (default), `zh-Hant` (Traditional), `zh-Hans` (Simplified).
- Two switch surfaces: (1) per-user in the profile dropdown (beside Theme); (2) a **Language** section on the Configuration page.
- Persist per-user: `localStorage` (instant, offline) **and** LDAP `preferredLanguage` (follows the user across browsers).
- Extract **all** user-facing strings across the frontend (178 `.tsx`) into namespaced locale files.
- Guard against regressions with a lint rule that fails CI on new hardcoded JSX literals.

## Non-goals

- RTL languages (none of the three are RTL; `dir` stays `ltr`). Provider still sets `document.dir` for future-proofing.
- Translating backend log/exception strings (operator-facing, English).
- Translating Authentik's own login page (separate system; tracked separately).
- Number/date/currency localization beyond what `Intl`/i18next gives for free (no formatting churn this PR).

## Library choice

`i18next` + `react-i18next` + `i18next-browser-languagedetector` — the pragmatic React standard (namespaces, interpolation, plurals, type-safe keys, huge ecosystem). Confirmed current via Context7 (`/i18next/react-i18next`, `/i18next/i18next`, 2026-07-06).

Alternatives considered:
- **react-intl (FormatJS)** — heavier ICU authoring, more ceremony; no advantage here.
- **LinguiJS / Paraglide** — compile-step extraction is nice but adds build complexity; react-i18next's runtime + a lint guard covers our needs with less moving machinery.

## Architecture

### Resource model

- **Static bundling** (not HTTP backend): locale JSON is imported and bundled by Vite. At ~500 strings × 3 locales the total is small (tens of KB gzip); lazy-loading complexity isn't worth it for an authenticated admin app. Synchronous resources ⇒ no Suspense flash (`react.useSuspense: false`).
- **Namespaced, one file per domain** — mirrors the feature-dir layout, keeps files small, and lets extraction fan out per-domain without merge conflicts.

```
src/frontend/src/
  i18n/
    index.ts          # init: resources, detection, fallback, languageChanged→<html lang/dir>
    resources.ts      # static imports → { [lng]: { [ns]: json } }
    languages.ts      # SUPPORTED = [{code,label,nativeLabel}], type Language
    i18next.d.ts      # module augmentation → type-safe keys (defaultNS='common')
    useSetLanguage.ts # switch hook: changeLanguage + PATCH /api/me (best-effort)
    useLanguageSync.ts# on-auth: seed i18n from /api/me preferredLanguage (once)
  locales/
    en/       common nav auth dashboard users groups orgs provisioning settings profile audit errors .json
    zh-Hant/  (same 13 files)
    zh-Hans/  (same 13 files)
```

**Namespaces (13):** `common, nav, auth, dashboard, users, groups, orgs, provisioning, settings, profile, audit, errors` (+ `onboarding` folded into `users`). `defaultNS: 'common'`, `fallbackNS: 'common'`, `fallbackLng: 'en'`, `supportedLngs: ['en','zh-Hant','zh-Hans']`.

**Key convention (uniform, fan-out-safe):** every call fully qualified — `t('users:table.headers.email')`, `t('common:actions.cancel')`. Components use bare `const { t } = useTranslation()`; `ns:key` resolves from any loaded namespace, so subagents cannot pick the wrong namespace. Interpolation `t('users:toasts.created', { uid })` → `"created": "User \"{{uid}}\" created"`. Plurals via i18next `_one`/`_other` suffixes.

### Init (`i18n/index.ts`)

```ts
i18n.use(LanguageDetector).use(initReactI18next).init({
  resources,
  fallbackLng: 'en',
  supportedLngs: ['en', 'zh-Hant', 'zh-Hans'],
  defaultNS: 'common', fallbackNS: 'common', ns: NAMESPACES,
  interpolation: { escapeValue: false },   // React already escapes
  detection: { order: ['localStorage', 'navigator'], caches: ['localStorage'],
               lookupLocalStorage: 'azblink-language' },
  react: { useSuspense: false },
})
i18n.on('languageChanged', (lng) => {
  document.documentElement.lang = lng
  document.documentElement.dir = i18n.dir(lng)   // 'ltr' for all three
})
```

Imported for side-effect in `main.tsx` before `createRoot` (mirrors `globals.css` import). No provider needed — `initReactI18next` wires the context.

### Persistence (localStorage + LDAP)

- **Detection order** `localStorage → navigator`; cache to `localStorage['azblink-language']`. Zero-backend path works pre-login and offline.
- **Server sync (LDAP `preferredLanguage`, RFC 2798 `inetOrgPerson` — already the structural class, no schema change):**
  - `useLanguageSync()` (mounted in `__root.tsx`): once auth is present, read `preferredLanguage` from the existing `/api/me` data; if set and ≠ current, `changeLanguage`. localStorage still wins for immediacy; server value seeds a fresh browser.
  - `useSetLanguage()` (both switchers): `i18n.changeLanguage(lng)` then best-effort `PATCH /api/me { preferredLanguage: lng }`. Failure is swallowed (anonymous/degraded LDAP must not block the UI switch).

### Backend (minimal, 3 edits + validation)

- `MeUpdateReq` (`main.py:2080`): add `preferredLanguage: Optional[str] = None`.
- `PATCH /api/me` handler: accept it, **validate** against `{en, zh-Hant, zh-Hans}` (reject others with 422 — prevents arbitrary attribute writes).
- `update_user` `FIELD_MAP` (`ldap_client.py:1004`): add `"preferredLanguage": "preferredLanguage"`.
- `get_user` read list (`ldap_client.py:809`) + output dict: add `preferredLanguage`.
- Round-trips through the existing `MODIFY_REPLACE` path (empty string → attr delete, already handled).

### Switch surfaces

1. **Profile dropdown** (`profile-dropdown.tsx`): a `DropdownMenuSub` "Language" beside "Theme", `DropdownMenuRadioGroup` over `SUPPORTED` (native labels: `English`, `繁體中文`, `简体中文`). `onValueChange` → `useSetLanguage()`.
2. **Configuration → Language section** (`settings/sections/LanguageSection.tsx`): new section via the `SettingsNav` registry (`SECTION_IDS` + `NAV_ITEMS` + render in `SettingsManagementPage`). Radio/segmented control + copy explaining per-user scope and cross-device sync.

### Regression guard

- ESLint flat-config rule scoped to `src/**` (excluding `locales/`, `i18n/`, `routeTree.gen.ts`, tests): flags string literals in JSX text/labels. Options: `eslint-plugin-i18next` `no-literal-string`, or `@typescript-eslint` `no-restricted-syntax` on `JSXText`. Prefer `eslint-plugin-i18next` (purpose-built, allow-list for punctuation/aria-hidden). Wired into the existing `just ui-lint` (already CI-gated).

## Data flow

```
boot → i18n init (localStorage|navigator) → render (en default)
login → useLanguageSync reads /api/me.preferredLanguage → changeLanguage (if differs)
user switches → useSetLanguage → changeLanguage (localStorage cache) → PATCH /api/me (best-effort)
languageChanged event → <html lang>/<html dir> updated
```

## Translation approach

- `en` is authored inline during extraction (source of truth).
- `zh-Hant` + `zh-Hans` produced by translation of the `en` namespace files, key-parity enforced (a test asserts every locale has the same key set as `en`).
- Technical/UC terms (LDAP, XMPP, SIP, OIDC, Authentik, UID) kept as-is or with a glossary; product nouns (Users, Groups, Devices) translated.
- **Machine/LLM translations flagged for native review** before production (noted in PR body). Not a merge blocker for a draft PR; correctness of *plumbing* is.

## Testing

- **Frontend unit (vitest):** (a) key-parity — every namespace file in `zh-Hant`/`zh-Hans` has the exact key set of `en` (catches missing/extra keys); (b) i18n init sanity (default `en`, fallback resolves); (c) `useSetLanguage` calls `changeLanguage` + PATCH.
- **Frontend e2e (Playwright):** switch to 繁體中文 via profile dropdown → assert a known label changed + `<html lang="zh-Hant">` + persisted across reload; switch back.
- **Backend (pytest, real stack):** `PATCH /api/me {preferredLanguage:'zh-Hant'}` → `GET /api/me` returns it; invalid value → 422; empty string clears it.

## Combined-PR scope (draft)

1. **feat:** i18n framework + full extraction + `en/zh-Hant/zh-Hans` + two switchers + backend `preferredLanguage` + lint guard + tests.
2. **docs (governance, folded in):**
   - Close **TD-2** in `docs/reports/tech-debt.md` (fixture merged in #187) → moves TD-1 `blocked`→`open`; update counts.
   - Convert `proposals/2026-07-05-tenant-isolation-and-machine-identity.md` C1 tranche → **ARD-009** (clears the `ARD-POST: placeholder` clock from #187/#196). Fix README ARD table (also missing ARD-008).
3. **open decision (yours, checkbox in PR body):** address-book visibility of aggregate browse (`/api/users`, `/api/org/tree`) — gate to operators vs keep "any authed employee". Not coded here.

### Governed-surface trailers

- Backend `/api/me` + `ldap_client` touch → `Spec-Patch:` (additive self-service field, non-decisional) unless it rises to a decision.
- ARD-009 conversion → `ARD: ARD-009`.
- Frontend is not a governed surface (per `surfaces.yaml`).

## Build sequence

1. Framework files + deps + `main.tsx` wire-in; verify build + one manual switch works. ✅ gate before mass work.
2. Backend `preferredLanguage` (BE tests pass).
3. Two switch surfaces + sync hooks.
4. **Full extraction** — fan out per-domain subagents → `en` namespace files + `t()` replacements. Verify build after each domain.
5. Translations `zh-Hant` + `zh-Hans` (key-parity test green).
6. Lint guard on; fix stragglers it catches.
7. Frontend + backend tests green; `just ui-lint`/`ui-format` clean.
8. Governance docs (TD-2, ARD-009).
9. Draft PR with the open address-book checkbox.

## Risks

- **Extraction scale (178 files):** mitigated by per-domain fan-out + build-after-each + the lint guard catching misses.
- **Translation fidelity:** flagged for native review; key-parity test prevents structural drift.
- **Interpolation/pluralization correctness:** covered by unit tests on representative keys.
- **`useSuspense:false` + missing key:** returns the key (visible), fallbackNS/fallbackLng reduce blanks; parity test is the real backstop.
