# web-configure: Headless Web App Configuration Skill

**Date:** 2026-04-10
**Status:** Draft
**Author:** Keith + Claude

## Problem

Configuring remote web-based admin panels (LDAP clients, network settings, service integrations) requires manual browser interaction that is:
- Not repeatable without documentation
- Not auditable (no before/after evidence)
- Not replayable by agents or automation

Today's AZBlink Server LDAP client configuration session proved that a structured curl-first, browse-second approach produces reliable, repeatable results. This spec codifies that approach into a reusable Claude skill.

## Scope

**In scope:**
- Server-rendered web apps (PHP, Django, Rails, WordPress, CGI panels)
- Legacy admin panels on embedded devices and appliances
- Form-based configuration (text inputs, checkboxes, selects, AJAX submissions)
- Session-cookie authentication (with or without CAPTCHA bypass)
- Portable YAML playbooks that record the full procedure

**Out of scope:**
- Single Page Applications (React/Vue/Angular) — different discovery architecture needed
- OAuth/OIDC login flows — these need browser-only auth
- File upload configuration — future extension
- Multi-step wizards with state between pages — future extension

## Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Skill type | Standalone in `.claude/skills/` | Configuration is not bug investigation; patrol is wrong domain |
| Primary tool | curl | Reliable, no browser deps, works in CI, no sandbox issues |
| Replay strategy | Stored literal data | Replay never re-parses HTML; uses stored POST payloads and expected values |
| Secondary tool | /browse (gstack) | Visual evidence, screenshots, form interaction verification |
| Playbook storage | `playbooks/web-configure/` at project root | Portable, visible, committable, parseable by any tool |
| Discovery method | Directed exploration with user hint | Full crawl is wasteful; user already knows roughly where to go |
| Staleness detection | Form field ID fingerprinting | Cheap to check, catches structural page changes |

## Architecture

### 3-Layer Execution Model

Each phase runs through three layers in order:

```
Layer 1: curl (discovery + operations)
  - Fetch HTML, extract forms/links
  - POST config data, read responses
  - Fast, reliable, no browser dependencies

Layer 2: browse (visual evidence)
  - Screenshots before/after each action
  - Snapshot interactive elements for documentation
  - Cookie bridge from curl session

Layer 3: validate (confirm effect)
  - curl re-reads page, checks persisted values
  - browse snapshot for visual confirmation
  - Domain-specific smoke test (e.g., LDAP search)
```

**Key rule:** curl always runs. Browse is additive. If browse fails (sandbox, crash, timeout), the phase still succeeds if curl succeeded.

### Two Modes

| Mode | Trigger | Behavior |
|------|---------|----------|
| Discover + Configure | No matching playbook for target URL | Full workflow: discovery through verification, saves new playbook |
| Replay | Matching playbook found | Loads playbook, runs curl ops, browse verification, appends to run log |

Auto-detected based on whether `playbooks/web-configure/*.yml` contains a match for the target base URL + navigation hint. Two playbooks for the same server but different pages (e.g., LDAP config vs DNS config) coexist by matching on `target.baseUrl` + `phases.navigate.hint`.

## Phases

### Phase 1: Auth

Authenticates to the target web app and acquires a session cookie.

**curl layer:**
- POST login form with credentials (without following redirects, to inspect each hop)
- Extract session cookies from all `Set-Cookie` headers (may be multiple: session, CSRF, etc.)
- Verify redirect location indicates successful login

**browse layer (optional):**
- Navigate to login page
- Fill credentials via snapshot-then-ref pattern
- Submit form

**Recorded in playbook:**
- Login URL, method, form fields
- Cookie extraction list (one or more cookie names)
- Redirect handling: `followRedirects: false` for auth (inspect hops), `true` for navigate
- Notes (e.g., "CAPTCHA exists but not enforced")

**Security rule:** Cookie values are never written to the playbook file or run log. They exist only in the shell environment during execution.

### Phase 2: Navigate

Follows the user's navigation hint from the root to the target page.

**curl layer:**
- Fetch each page in the chain
- Extract links, match against hint segments
- Verify arrival at target page (check for expected content)

**browse layer (optional):**
- Navigate visually, clicking through menus/dropdowns
- Screenshot the navigation path

**Fallback escalation:**
1. Hint matches a link → follow it
2. Hint doesn't match → list available links, ask user to pick
3. Still stuck → browse handoff for user to point to the right page

**Recorded in playbook:**
- Chain of URLs from root to target
- The hint that was used
- Alternative link text found at each step

### Phase 3: Discover (first run only)

Maps the form structure on the target page.

**curl layer:**
- Fetch target page HTML
- Parse all `<form>` elements
- For each form: field names, IDs, types, current values, action URL
- Identify submission mechanism (standard POST, AJAX, JS function)
- Build structural fingerprint for staleness detection

**Recorded in playbook:**
- `discover.forms` — full form map with fields, selectors, types
- `discover.fingerprint` — structural hash for change detection
- Hidden fields and their static values
- `submitMechanism` per form: `standard-post | ajax-post | ajax-json | js-function`
  - If `ajax-*` or `js-function`: curl adds `X-Requested-With: XMLHttpRequest`, expects text/JSON body
  - If `standard-post`: curl follows redirect after POST

### Phase 4: Configure

Submits the new configuration values.

**curl layer:**
- Execute one or more named operations in order
- Each operation: POST form data to the discovered endpoint, include hidden fields + configured values
- Check response per operation (typically `1` for AJAX success, or redirect for standard POST)
- Operations within a phase are implicitly ordered (sequential execution)

**browse layer:**
- Screenshot before state
- Fill fields using snapshot refs
- Register dialog handlers (for AJAX alert callbacks)
- Click submit
- Wait for page reload
- Screenshot after state

**Recorded in playbook:**
- Ordered list of named operations, each with its own method/url/data/expect
- `${VARIABLE}` references in POST data
- Before/after screenshot paths

### Phase 5: Verify

Confirms the configuration persisted and works.

**curl layer:**
- Re-fetch the target page
- Assert field values using body matching (substring, regex, or `value="X"` pattern match — no CSS selector resolution)
- Run optional HTTP-based smoke test (e.g., LDAP search POST)
- Run optional shell command verification (`verifyCommand` — e.g., `ldapsearch -x -H ldap://...`)

**browse layer:**
- Final verification screenshot
- Snapshot of current field values

**Recorded in playbook:**
- Per-field assertion results (expected vs actual) using body matching
- Smoke test results (HTTP and/or shell command)
- Verification screenshot path

**Important:** Replay never re-parses HTML with CSS selectors. Verification uses `bodyContains`, `bodyRegex`, or `valuePattern` (searches for `value="X"` in input tags). This keeps replay deterministic and parser-free.

## Playbook Format

Stored at `playbooks/web-configure/<playbook-id>.yml`.

```yaml
schemaVersion: "1.0"
id: "<playbook-id>"
title: "<human-readable title>"
created: "<ISO 8601>"
lastRun: "<ISO 8601>"
status: "verified"          # draft | verified | stale | failed

target:
  baseUrl: "<url or ${VAR}>"    # supports variable substitution for fleet use
  description: "<what this web app is>"
  type: "server-rendered"
  tlsVerify: true               # false = curl uses -k, logs a warning

variables:
  VAR_NAME:
    description: "<what this value is>"
    default: "<optional default>"   # MUST NOT be set when secret: true
    secret: false            # true = never logged in runs, no default allowed
    pattern: "<optional regex>"     # validation pattern (e.g., "^ldap://.*" for URIs)

phases:
  auth:
    description: "<what this phase does>"
    curl:
      method: POST
      url: "<relative url>"
      contentType: form          # form | json | multipart (default: form)
      followRedirects: false     # inspect each hop for Set-Cookie headers
      data: { key: value }
      extract:
        cookies: ["PHPSESSID"]   # array — extract all listed cookies
      expect:
        status: 302
      timeout: 30                # seconds (default: 30)
      retries: 1                 # retry count on timeout (default: 1)
    browse:
      steps:
        - goto: "<url>"
        - fill: { ref: "<description>", value: "${VAR}" }
        - click: "<button text>"
    notes: "<anything discovered about auth>"

  navigate:
    description: "<breadcrumb path>"
    hint: ["Segment1", "Segment2", "Segment3"]
    curl:
      chain:
        - url: "<url>"
          extract: { links: "a[href]" }
        - url: "<final target url>"
          expect: { contains: "<expected content>" }
    browse:
      steps:
        - goto: "<url>"
        - frame: "<selector or 'main'>"   # enter iframe context (legacy frameset apps)
        - hover: "<menu text>"
        - click: "<link text>"

  discover:
    description: "<what was found>"
    pageUrl: "<target page url>"
    fingerprint:
      fetchedAt: "<ISO 8601>"
      pageTitle: "<title text>"
      formCount: N
      fieldIds: [id1, id2, ...]
      actionUrls: ["<url>"]
      submitMechanisms: ["<mechanism>"]
    forms:
      - id: "<form id or name>"
        submitMechanism: "<js:functionName() | post | ajax>"
        ajaxEndpoint:
          method: POST
          url: "<url>"
        fields:
          - { id: "<id>", name: "<name>", type: "<type>", label: "<label>" }
        hiddenFields:
          - { name: "<name>", value: "<value>" }

  configure:
    description: "<what is being configured>"
    screenshots: { before: true, after: true }
    operations:                  # ordered list of named operations
      - name: "<operation name>"
        curl:
          method: POST
          url: "<url>"
          contentType: form
          data: { key: "${VARIABLE}" }
          expect: { body: "1" }
          timeout: 30
          retries: 1
    browse:
      steps:
        - screenshot: { path: "before" }
        - snapshot: { interactive: true }
        - fill: { selector: "<sel>", value: "${VAR}" }
        - click: "<submit>"
        - screenshot: { path: "after" }

  verify:
    description: "<what is being verified>"
    delay: 0                     # seconds to wait before verifying (for slow apps)
    curl:
      - action: "<re-read page>"
        url: "<url>"
        assertions:
          - { bodyContains: "<expected text>" }
          - { valuePattern: { name: "<field name>", value: "${VAR}" } }  # matches value="X" in HTML
          - { bodyRegex: "<pattern>" }                                    # regex match on body
      - action: "<optional HTTP smoke test>"
        method: POST
        url: "<url>"
        data: { ... }
        assertions:
          - { bodyContains: "<expected>" }
    command:                     # optional shell command verification
      - action: "<domain-specific check>"
        run: "ldapsearch -x -H ldap://${LDAP_HOST} -b ${LDAP_BASE_DN} -D ${LDAP_BIND_DN} -w ${LDAP_BIND_PW} uid=*"
        assertions:
          - { outputContains: "uid:" }
    browse:
      steps:
        - screenshot: { path: "verified" }

runs:
  - timestamp: "<ISO 8601>"
    mode: "discover+configure"    # or "replay"
    duration: N                   # seconds
    result: "verified"            # verified | failed
    fingerprint: { match: "100%", fieldsChecked: N, fieldsMissing: 0 }
    variables:
      VAR_NAME: "<value>"         # secrets omitted
    screenshots:
      before: "<relative path>"
      after: "<relative path>"
      verified: "<relative path>"
    assertions:
      - { check: "<description>", expected: "<val>", actual: "<val>", pass: true }
```

## Staleness Detection

On replay, before the configure phase:

1. curl fetches the target page
2. Extracts current form field IDs and action URLs
3. Compares against `discover.fingerprint`

Match rate = `(fields found on live page / fields in fingerprint.fieldIds) * 100`.

| Match rate | Status | Action |
|-----------|--------|--------|
| 100% | `verified` | Continue replay |
| 70-99% | `stale` | Warn, show changes, offer to patch or rediscover |
| <70% | `stale` | Stop. Require full rediscovery |

### Fingerprint Fields

- `fieldIds` — ordered list of form field IDs on the page
- `actionUrls` — form action URLs
- `submitMechanisms` — how forms are submitted (JS function, standard POST)
- `formCount` — number of forms on the page

### Rediscovery Flow

1. Re-run discover phase
2. Diff new form map against stored
3. Show user what changed
4. User approves update → rewrite discover + configure, preserve auth + navigate + variables
5. Run configure + verify with updated structure

## Workflow

### Entry Point

```
/web-configure <url> <objective> [--playbook <id>] [--replay] [--hint "Path > To > Page"]
```

### Execution Steps

1. **Playbook resolution** — search `playbooks/web-configure/` for matching URL
2. **Variable resolution** — env vars → --var flags → user prompt (secrets prompted, never stored)
3. **Execute phases** in order: auth → navigate → discover → configure → verify
4. **Save playbook** — new file on first run, append to `runs` on replay
5. **Output summary** — status, screenshots, assertion results, replay command

### Browse Batching

All browse commands for a phase must be emitted as a single shell script block:

```bash
B=~/.claude/skills/gstack/browse/dist/browse
COOKIE="<from-curl>"
CI=1 $B goto <url>
CI=1 $B cookie "PHPSESSID=$COOKIE"
CI=1 $B goto <target>
CI=1 $B screenshot <before>
CI=1 $B snapshot -i
CI=1 $B fill @eN "<value>"
CI=1 $B screenshot <after>
```

**Reason:** The browse server tracks parent PID and auto-terminates when the shell exits. Each Bash tool call is a separate process. Splitting browse commands across tool calls loses the session.

**`CI=1` requirement:** Ubuntu 24.04+ restricts Chromium sandbox via AppArmor (`kernel.apparmor_restrict_unprivileged_userns=1`). The `CI=1` env var triggers `--no-sandbox` in the browse server.

### Error Handling

| Situation | Action |
|-----------|--------|
| curl auth fails (non-302) | Stop. "Auth failed. Check credentials." |
| curl timeout | Retry up to `retries` count, then fail |
| curl 200-with-error-body | Not retryable. Stop and report. |
| Navigation hint no match | List available links, ask user |
| Navigation still stuck | Browse handoff for user to point to page |
| Form field ID missing | Flag playbook `stale`, offer rediscovery |
| Browse crash / non-zero exit | Continue curl-only. Note "Browse unavailable" |
| AJAX returns failure (`0` or error) | Stop at configure. "Save failed." |
| Verify assertions fail | Stop. Show expected vs actual per field |
| Secret variable has `default` | Reject playbook at load. "Secret vars must not have defaults." |
| 3 consecutive browse fails | Set `browseDisabled` flag, skip browse for remaining phases. Logged in run record. |

**Browse fail definition:** A browse command returns non-zero exit code or produces no output. Counter is global across the entire run.

## Security Rules

1. **Secret variable defaults rejected.** Variables with `secret: true` MUST NOT have a `default` field. The skill rejects playbooks violating this at load time.
2. **Cookie values never persisted.** Session cookies exist only in shell environment variables during execution. Never written to playbook YAML or run logs.
3. **Secret values omitted from run logs.** The `runs[].variables` section records non-secret values only. Secret variable names appear but values are replaced with `"***"`.
4. **Screenshots may contain sensitive data.** Password fields, tokens in URL bars, or configuration secrets may appear in screenshots. Default screenshot policy: `always` on first run, `prompt` on replay. Configurable via `screenshotPolicy: always | never | prompt`.
5. **TLS verification.** `target.tlsVerify: true` by default. When `false`, curl uses `-k` and a warning is logged. Self-signed certs on legacy panels are expected but must be explicitly opted into.

## File Layout

```
project-root/
├── .claude/skills/
│   └── web-configure/
│       └── SKILL.md
├── playbooks/
│   └── web-configure/
│       ├── <playbook-id>.yml
│       └── screenshots/
│           └── <playbook-id>/
│               ├── YYYY-MM-DD-before.png
│               ├── YYYY-MM-DD-after.png
│               └── YYYY-MM-DD-verified.png
└── .gitignore   # screenshots/ gitignored by default
```

## Reference Implementation

The AZBlink Server LDAP client configuration (2026-04-10 session) serves as the reference. The patrol issue file at `qa/patrol/issues/2026-04-10-azblink-server-ldap-client-navigation-route.yml` contains the raw investigation data. The first playbook to be created from this skill will be `azblink-server-ldap-client.yml`.

## Implementation Notes

- **Skills manifest registration:** Add `web-configure` to `.claude/skills-manifest.json` following the existing pattern.
- **Shared browse patterns:** Both patrol and web-configure use identical browse setup boilerplate (CI=1, snapshot-then-ref, console filtering). Extract to `.claude/skills/_shared/browse-patterns.md` and reference from both. Follow-up, not a blocker.
- **`--from-issue` import:** Support `--from-issue <issue-id>` flag to read a patrol issue file with an `automation` section and pre-populate the playbook's auth, navigate, and configure phases. Bridges the patrol → web-configure workflow.

## Future Extensions

- **SPA support** — browse-first discovery for JS-rendered apps (different architecture)
- **File upload fields** — upload via browse, verify via curl
- **Multi-step wizards** — phase chaining with inter-page state
- **CI integration** — run playbooks from GitHub Actions as configuration smoke tests
- **Ansible/shell export** — generate standalone scripts from playbook curl sections
- **Diff mode** — compare two runs to see what changed (config drift detection)
- **Variable computed values** — derive a variable from a prior phase's output (e.g., concatenate host + port)
