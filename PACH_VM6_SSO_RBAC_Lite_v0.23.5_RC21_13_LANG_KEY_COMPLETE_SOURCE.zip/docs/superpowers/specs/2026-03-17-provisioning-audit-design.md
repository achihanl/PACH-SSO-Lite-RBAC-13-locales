# Device Provisioning Audit — Design Spec

**Date:** 2026-03-17
**Status:** Approved
**Scope:** Add `device_provisions` as a 5th audit source in the unified audit system

## Problem

The device provisioning system (SSO sealed-credential flow, QR token consumption, revocation, extension, bulk operations) has zero audit trail. All provisioning state changes are invisible to the unified audit log, the activity bus, and the audit export. This is a compliance and security visibility gap.

## Decision Summary

- **Architecture:** Dedicated `provisioning_audit` table with explicit INSERT on each state-changing operation (Approach B — same pattern as the other 4 audit sources)
- **Category:** New `provisioning` EventCategory (5th category, distinct from user/auth/config/admin)
- **Events:** All state-changing provisioning operations generate audit records
- **Real-time:** All provisioning events fire activity bus events
- **Bulk granularity:** Hybrid — one summary record per bulk operation with count + token hash list in detail JSONB

## Event Types

| DB Action | AuditEventType | Title | Trigger |
|-----------|---------------|-------|---------|
| `provisioned` | `device-provisioned` | Device Provisioned (SSO) | `POST /api/provision/device` |
| `consumed` | `device-provisioned` | Device Provisioned (QR) | `POST /api/provision/consume` |
| `consumed` | `device-provisioned` | Device Provisioned (QR) | `POST /api/provision/validate` (calls `validate_and_consume_token` — state-changing) |
| `revoked` | `device-revoked` | Device Revoked | `DELETE /api/provision/device/{id}` |
| `bulk-revoked` | `device-revoked` | Bulk Token Revocation | `POST /api/provisioning/tokens/bulk-revoke` |
| `extended` | `device-extended` | Token Extended | `POST /api/provisioning/tokens/{hash}/extend` |
| `bulk-revoked` | `device-revoked` | Tokens Revoked (Termination) | Inside `revoke_tokens_for_user()` during user termination |

## Database Schema

### New table: `provisioning_audit`

```sql
CREATE TABLE provisioning_audit (
    id            SERIAL PRIMARY KEY,
    action        VARCHAR(32) NOT NULL,    -- provisioned, consumed, revoked, bulk-revoked, extended
    actor         VARCHAR(128) NOT NULL,   -- uid (self-service) or admin username
    target_uid    VARCHAR(128) NOT NULL,   -- user whose device was affected
    device_id     VARCHAR(128),            -- nullable (bulk-revoke spans multiple devices)
    token_hash    VARCHAR(128),            -- nullable (SSO provision may not have one)
    auth_method   VARCHAR(16),             -- 'sso' or 'qr' (Plane B vs Plane A)
    platform      VARCHAR(32),             -- ios, android, etc.
    client_ip     VARCHAR(45),             -- IPv4/IPv6
    detail        JSONB,                   -- operation-specific: extend amounts, bulk token lists, etc.
    timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_prov_audit_target ON provisioning_audit(target_uid);
CREATE INDEX idx_prov_audit_timestamp ON provisioning_audit(timestamp);
CREATE INDEX idx_prov_audit_action ON provisioning_audit(action);
```

**Migration file:** `migrations/026_provisioning_audit.sql`

### UNION ALL integration

- **ID offset:** 50000
- **Reference ID prefix:** `PRV-` (e.g., `PRV-0042`)
- **Audit ID format:** `AUD-50042`

```sql
SELECT
  'AUD-' || LPAD((50000 + pa.id)::text, 5, '0') AS id,
  CASE pa.action
    WHEN 'provisioned' THEN 'device-provisioned'
    WHEN 'consumed'    THEN 'device-provisioned'
    WHEN 'revoked'     THEN 'device-revoked'
    WHEN 'bulk-revoked' THEN 'device-revoked'
    WHEN 'extended'    THEN 'device-extended'
  END AS event_type,
  pa.timestamp,
  CASE pa.action
    WHEN 'provisioned' THEN 'Device Provisioned (SSO)'
    WHEN 'consumed'    THEN 'Device Provisioned (QR)'
    WHEN 'revoked'     THEN 'Device Revoked'
    WHEN 'bulk-revoked' THEN 'Bulk Token Revocation'
    WHEN 'extended'    THEN 'Token Extended'
  END AS title,
  COALESCE(pa.detail->>'description', pa.action || ' for ' || pa.target_uid) AS description,
  pa.actor,
  pa.target_uid AS target,
  'PRV-' || LPAD(pa.id::text, 4, '0') AS reference_id,
  'success' AS result,
  'provisioning' AS category,
  NULL::int AS duration_ms,
  NULL AS organization,
  pa.client_ip AS ip_address,
  json_build_object('device_id', pa.device_id, 'platform', pa.platform)::text AS device_json,
  row_to_json(pa.*)::text AS raw_data
FROM provisioning_audit pa
```

## Backend Integration

### New orgdb method

```python
async def record_provisioning_audit(
    self,
    action: str,
    actor: str,
    target_uid: str,
    *,
    device_id: str | None = None,
    token_hash: str | None = None,
    auth_method: str | None = None,
    platform: str | None = None,
    client_ip: str | None = None,
    detail: dict | None = None,
) -> None:
    """Insert provisioning audit record and publish activity bus event."""
```

### Endpoint audit calls

| Endpoint | Action | Actor Source | Detail JSONB |
|----------|--------|-------------|--------------|
| `POST /api/provision/device` | `provisioned` | `claims["preferred_username"]` | `{auth_method: 'sso', device_cap_used, device_cap_max}` |
| `POST /api/provision/consume` | `consumed` | `target_uid` (unauthenticated — client IP stored in `client_ip` column) | `{auth_method: 'qr', platform, client_version}` |
| `POST /api/provision/validate` | `consumed` | Same as consume (unauthenticated, calls `validate_and_consume_token`) | Same as consume |
| `DELETE /api/provision/device/{id}` | `revoked` | `claims["preferred_username"]` (self-service via `require_user`) | `{previous_status, expiry_remaining_sec}` |
| `POST /api/provisioning/tokens/bulk-revoke` | `bulk-revoked` | `extract_actor(claims)` (admin via `require_permission`) | `{count, skipped, token_hashes: [...]}` |
| `POST /api/provisioning/tokens/{hash}/extend` | `extended` | `extract_actor(claims)` (admin via `require_permission`) | `{old_expires_at, new_expires_at, extend_seconds}` |
| `revoke_tokens_for_user()` (termination) | `bulk-revoked` | `terminated_by` (threaded param) | `{count, reason: 'user_termination', token_hashes: [...]}` |

### revoke_tokens_for_user() signature change

Add `terminated_by: str` parameter so the audit record captures who initiated the termination. The termination endpoint already has `extract_actor(claims)` — thread it through.

## Frontend Changes

### Types (`src/frontend/src/types/audit.ts`)

```typescript
type AuditEventType =
  | 'user-created' | 'user-terminated' | 'sso-enrolled'
  | 'config-change' | 'admin-action' | 'login'
  | 'device-provisioned' | 'device-revoked' | 'device-extended'  // NEW

type EventCategory = 'user' | 'auth' | 'config' | 'admin' | 'provisioning'  // NEW
```

### Event config (`audit-event-config.ts`)

| Event Type | Icon | Color | Label |
|-----------|------|-------|-------|
| `device-provisioned` | `Smartphone` | Green (success) | "Device Provisioned" |
| `device-revoked` | `ShieldX` | Red (danger) | "Device Revoked" |
| `device-extended` | `Clock` | Amber (warning) | "Token Extended" |

### Filter bar (`AuditFilterBar.tsx`)

- Category dropdown: add `{ value: 'provisioning', label: 'Provisioning' }`
- Filter chips: new `provisioning-events` chip toggling all 3 provisioning event types

### AuditDetailPanel device info shape

The existing `AuditDeviceInfo` interface expects `{model, os, app_version, user_agent}`, but provisioning `device_json` produces `{device_id, platform}`. The `AuditDeviceInfo` type needs optional `device_id` and `platform` fields, and `AuditDetailPanel.tsx` needs a small conditional to render either shape (existing device info or provisioning device info).

### No changes needed

- `AuditList.tsx`, `AuditRow.tsx` — rendering driven by config, no changes
- `audit.ts` (queries) — existing unified endpoint handles provisioning category
- `keys.ts` — existing `queryKeys.audit.events()` covers new category
- `activity_bus.py` — `_publish_activity_event()` already generic

## Activity Bus

`record_provisioning_audit()` calls `_publish_activity_event()` after INSERT (follows the `record_admin_action` / `record_lifecycle_event` / `record_auth_failure` pattern — only `record_termination` does NOT publish bus events):

Event shape should match the existing `_publish_activity_event()` pattern (`id`, `type`, `text`, `meta`, `time`, `timestamp`):

```python
{
    "id": 42,
    "type": "provisioning",
    "text": "Device Provisioned (SSO) — jsmith",
    "meta": {
        "action": "provisioned",
        "actor": "jdoe",
        "target": "jsmith",
        "device_id": "iphone-14-abc123",
        "auth_method": "sso"
    },
    "time": "2m ago",
    "timestamp": "2026-03-17T15:30:00Z"
}
```

Audit log `staleTime: 15s` ensures refetch on next interaction. No custom WebSocket handler needed.

## Testing

**New file:** `tests/test_provisioning_audit.py`

| Test | Verifies |
|------|----------|
| `test_provision_device_creates_audit` | SSO provision → audit record with correct actor/device_id/auth_method |
| `test_consume_token_creates_audit` | QR consume → audit record with `auth_method='qr'`, client IP |
| `test_revoke_device_creates_audit` | Single revoke → audit record with previous status in detail |
| `test_bulk_revoke_creates_audit` | Bulk revoke 3 tokens → single record, count=3, token_hashes in detail |
| `test_extend_token_creates_audit` | Extension → record with old/new expiry in detail |
| `test_termination_creates_provisioning_audit` | Termination with tokens → `bulk-revoked`, `reason='user_termination'` |
| `test_provisioning_audit_in_unified_events` | Unified API returns event with `PRV-` prefix |
| `test_unified_audit_provisioning_filter` | `category=provisioning` filters correctly |
| `test_provisioning_audit_search` | Search by target_uid returns matches (note: device_id search requires extending ILIKE clause — out of scope) |
| `test_audit_export_includes_provisioning` | CSV export includes provisioning events |

**Cleanup fixture:** `DELETE FROM provisioning_audit` in `conftest.py` teardown.

## File Change Summary

**New files (2):**
- `migrations/026_provisioning_audit.sql`
- `tests/test_provisioning_audit.py`

**Modified files (6):**

| File | Change | ~Lines |
|------|--------|--------|
| `src/backend/orgdb.py` | Table def, `record_provisioning_audit()`, 5th UNION ALL, category filter, `revoke_tokens_for_user()` returns token hashes | +90 |
| `src/backend/main.py` | Audit calls in 7 provisioning endpoints, thread `terminated_by`, add `"provisioning"` to `valid_categories` (remove stale `"qr"`) in both `/api/audit/events` and `/api/audit/export` | +35 |
| `src/frontend/src/types/audit.ts` | 3 event types, 1 category | +5 |
| `src/frontend/src/components/features/audit-management/audit-event-config.ts` | 3 event configs | +20 |
| `src/frontend/src/components/features/audit-management/AuditFilterBar.tsx` | Category option, filter chips | +10 |
| `src/frontend/src/components/features/audit-management/AuditDetailPanel.tsx` | Conditional rendering for provisioning device info shape | +8 |
| `tests/conftest.py` | Cleanup fixture | +2 |

**Total:** 2 new files, 7 modified files, ~170 lines added.

## Implementation Notes

- **`POST /api/provision/validate`**: Confirmed state-changing — calls `validate_and_consume_token()` which atomically sets `status="consumed"`. Needs audit call identical to `/api/provision/consume`.
- **Actor consistency**: Use `extract_actor(claims)` consistently across all admin endpoints (replaces existing `claims.get("sub", "admin")` pattern in bulk-revoke). Self-service endpoints use `claims["preferred_username"]`. Unauthenticated consume/validate uses `target_uid` as actor with IP in `client_ip`. Termination reuses existing `terminated_by = claims.get("sub", "unknown")` value from the termination endpoint to stay consistent with `termination_events`.
- **`revoke_tokens_for_user()` must return token hashes**: Currently returns only `result.rowcount`. Modify to use `RETURNING token_hash` or SELECT-before-UPDATE so the audit detail can include the list of affected hashes.
- **Stale `"qr"` category**: Remove `"qr"` from `valid_categories` in both audit endpoints — no UNION ALL subquery produces this category.
- **`valid_categories` whitelist**: Both `/api/audit/events` and `/api/audit/export` endpoints hard-code allowed categories — must add `"provisioning"` to both.
- **`::text` casts**: UNION ALL `device_json` and `raw_data` must use `::text` cast to match existing subqueries' JSON string encoding (required by `json.loads()` in post-processing).
- **`AuditDeviceInfo` type**: Extend with optional `device_id?: string` and `platform?: string` fields; detail panel conditionally renders either shape.
- **ID offset ceiling**: 10000 IDs per source before collision. Acceptable for current scale; document as known limitation if audit volume grows.
