# UC Journey Client — Design Spec

- **Status:** Proposed (design approved 2026-07-04, pre-implementation)
- **Date:** 2026-07-04
- **Author:** Keith (with Claude)
- **Related ARDs:** ARD-001 (Single-LDAP), ARD-002 (Authentik-only web auth), ARD-004 (Profile services)
- **Supersedes/duplicates:** nothing — fills a gap between existing tools (see §2)

## 1. Summary

A single launchable Python tool that walks the **entire UC onboarding journey end-to-end**:

```
SSO login → device provision → credential unseal → XMPP connect → SIP register → verdict
```

Headless-first (CLI, CI-usable, non-zero exit on failure). An **optional** web GUI
(`--gui`) drives the same core and shows each step live. It is the reference future
apps (mobile, desktop, other services leveraging XMPP/SIP) diff their implementation
against.

## 2. Problem & context

The SSO ↔ XMPP/SIP integration **already exists** as the *device-provisioning bridge*
(ARD-001/002): Authentik OIDC authenticates the human to authorize
`POST /api/provision/device`, which returns a libsodium sealed-box of UC credentials;
the client then authenticates the **XMPP socket via LDAP bind (SASL PLAIN,
`userPassword`)** and the **SIP socket via MD5 digest (`AstAuthPassword`)**. SSO does
**not** authenticate the transport sockets — deliberately, so UC works without Authentik.
(Mechanically, the sealed `xmppPassword` the client receives is read from
`azbXmppBindPassword`, a plaintext twin `ldap_client.py` keeps atomically in sync with the
SSHA `userPassword`, so the SASL PLAIN bind still matches — one auth secret, two encodings.)

Three artifacts already cover *parts* of this journey; none covers all of it as one
launchable client:

| Artifact | SSO | Provision | XMPP transport | SIP transport | Form |
|---|---|---|---|---|---|
| `tools/web-sso-provision-ref/` | ✅ browser OIDC | ✅ | ❌ (explicit handoff) | ❌ | web page |
| `tools/e2e_xmpp_notebook.py` | ⚠️ M2M only | ✅ | ✅ | ❌ | marimo notebook |
| `tests/test_xmpp_e2e.py` / `test_sip_ring_e2e.py` | ⚠️ M2M only | ✅ | ✅ | ✅ | pytest (not launchable) |

**The gap:** no single launchable client that does SSO → provision → **connect
XMPP AND register SIP** → verify, reusable as a clean reference. This spec fills it
without re-architecting auth (Option 1 of brainstorm).

**Critical environment fact (shapes CI/lab split, §8/§11):** the dev Docker stack has
**no XMPP or SIP server** — `deploy/dev/docker-compose.yml` runs postgres/redis/openldap/
api/ui/traefik/authentik×4/obs×4 only, and `UCCHAT_*` domains are placeholder strings.
Real XMPP/SIP transport is **external lab hardware** (XMPP `192.168.122.89:5222` domain
`private.z`; SIP UED `192.168.122.220:5060`), which both e2e reuse sources gate behind
`pytest.mark.external_network` ("unreachable from CI"). Therefore the CI-runnable part of
this client is **SSO + provision + unseal**; the **XMPP/SIP transport legs require those
lab hosts** and are env-gated, never asserted in stack-only CI.

**Neither test artifact does browser PKCE.** Their "real OIDC tokens" come from Authentik
**M2M `client_credentials`** using a per-user **app-password token** (`tests/conftest.py`
mints one with `intent: "app_password"` and passes its key as the password grant param;
`e2e_xmpp_notebook.py` does the same). Browser PKCE lives only in TypeScript
(`lib/oidc.ts`) and its drift-guarded inline JS copy in `web-sso-provision-ref/index.html`.

## 3. Goals / Non-goals

**Goals**
- One Python tool, headless by default, that runs the full 5-step journey and returns a
  pass/fail verdict with a per-step report.
- Optional web GUI (`--gui`) reusing the presentable `web-sso-provision-ref` page,
  extended to also run + display the XMPP and SIP transport legs.
- Maximal reuse of existing proven code; near-zero new protocol logic (see §7).
- CI-runnable via a `just` recipe; guards against regression with one smoke test.

**Non-goals (YAGNI)**
- Re-architecting UC auth to validate SSO tokens on the XMPP/SIP socket
  (SASL OAUTHBEARER / SIP OAuth) — that contradicts ARD-001/002 and would need a new ARD.
- Token refresh, multi-user concurrency, TLS / prod exposure, pip-wheel packaging.
- Replacing the existing tools — this complements them.

## 4. Architecture

One core package; CLI and web GUI are thin frontends over the **same** `runner.py`.

```
tools/uc-journey-client/
├── journey/
│   ├── __init__.py
│   ├── config.py     # stack URLs, user creds/OIDC mode, endpoints, feature flags
│   ├── oidc.py       # OIDC PKCE (S256) auth-URL + code→token; M2M client_credentials
│   ├── provision.py  # POST /api/provision/device (Curve25519); sealed-box unseal → cred kit
│   ├── xmpp_leg.py   # slixmpp connect + SASL-PLAIN bind + optional self-message
│   ├── sip_leg.py    # pure-stdlib UDP: REGISTER (MD5 digest) + optional INVITE
│   └── runner.py     # orchestrate the 5 steps, emit StepEvent stream, aggregate verdict
├── cli.py            # headless entrypoint (default); flags; step table; exit code
├── server.py         # optional GUI: serve page + POST /run/xmpp, /run/sip, SSE /events
├── web/journey-ext.js# injected into the UNMODIFIED web-sso-ref page: adds §5/§6 + deviceId override
├── requirements.txt  # slixmpp, httpx, pynacl  (SIP + OIDC use stdlib)
└── README.md         # run instructions, prereqs (mirrors web-sso-ref prereqs)
```

**Isolation:** each leg module has one job, a typed input (creds/endpoints) and a typed
`StepResult` output; `runner.py` depends on the legs, not vice-versa. Each leg is
independently testable and understandable without reading the others.

## 5. Data flow

```
                 ┌─ browser PKCE (real SSO)  ──┐
oidc.get_token ──┤                              ├──► access_token
                 └─ M2M client_credentials ────┘
                                │
provision.run(token) ──► POST /api/provision/device {curve25519 pubkey}
                         → response {sealedCredentials, endpoints{xmpp{domain,wsUrl},
                                     sip{domain,wssUrl}}, uid, expiresAt}
                         → nacl unseal(sealedCredentials) → {xmppPassword, sipPassword,
                                                              sipUsername}
                         → assemble CredKit (see provenance table below)
                                │
        ┌───────────────────────┴───────────────────────┐
xmpp_leg.run(kit.xmpp)                           sip_leg.run(kit.sip)
  slixmpp connect + SASL PLAIN                     UDP REGISTER + MD5 digest
  (+ optional self-message)                        (+ optional INVITE)
        │                                                 │
        └───────────────► runner aggregate ◄─────────────┘
                     → StepResult[] → report (table|json) → exit code
```

**CredKit provenance** (which fields are real API output vs. client config — none are invented):

| CredKit field | Source |
|---|---|
| `xmpp.password`, `sip.password`, `sip.user` | unsealed `sealedCredentials` (`xmppPassword`/`sipPassword`/`sipUsername`) |
| `xmpp.domain` / `xmpp.ws_url`, `sip.domain` / `sip.wss_url` | response `endpoints.*` (dev = placeholders; see below) |
| `xmpp.jid` | derived `sipUsername@<xmpp-domain>` (real lab domain is `private.z`, **not** the dev endpoint) |
| `xmpp.host`/`port`, `sip.host`/`port` | **client flags/env** — the transport lab hosts (`--xmpp-host`, `--sip-host`, defaults from `env`); the API returns no host/port |
| `sip.realm` | **not an input** — parsed from the SIP `401/407` challenge (as `test_sip_ring_e2e.py` does) |

Because dev `endpoints` are unroutable placeholders, transport legs are driven by explicit
`--xmpp-host`/`--sip-host` flags pointing at the lab hosts; the domain/JID for SASL come
from `--xmpp-domain` (default `private.z`).

**OIDC modes**
- `--login browser` (default under `--gui`): open system browser to Authentik, catch the
  code on a **fixed** loopback redirect `http://localhost:5173/callback`, exchange for
  token. 5173 is the only pre-registered loopback (`seed_authentik.py` strict-match
  `redirect_uris`); other ports require appending to `OAUTH2_REDIRECT_URIS`. Note the
  5173 port collision if `just sso-ref` runs concurrently — pick one at a time.
- `--login m2m` (default headless/CI): Authentik `client_credentials` grant using a
  **per-user app-password token** (`intent: "app_password"`), supplied via `--app-token`
  / `AUTHENTIK_APP_TOKEN`. This is how `conftest.py` + `e2e_xmpp_notebook.py` authenticate.
  **`just seed-uc-test-user` does NOT currently mint this token** — it only sets the login
  password — so this spec extends that seed script to mint + print an app-password token
  for `alanl` (idempotent), OR the smoke test mints an ephemeral user via the conftest
  token factory. Without a token, m2m fails at acquisition, not at provisioning.

## 6. Web GUI design

The browser cannot open UDP/TCP sockets, so the transport legs run in the **core**, not
the page. `server.py` today is a **59-line GET/HEAD-only** `SimpleHTTPRequestHandler`
(SPA fallback); adding a JSON API + SSE is genuinely new code, specced explicitly:

- **Static:** serve the SSO page + SPA fallback (reuse the existing handler).
- `POST /run/xmpp` — body = unsealed xmpp creds + transport host/port; runs `xmpp_leg`;
  **blocking JSON result** (final pass/fail).
- `POST /run/sip` — same shape for `sip_leg`.
- `GET /events` — SSE stream of `StepEvent`s for **live progress** (the blocking POST
  returns the verdict; SSE carries intermediate steps).

**New-code risks called out (avoid discovering them mid-build):**
- **slixmpp is asyncio.** Each `/run/xmpp` handler thread must `asyncio.run(...)` a fresh
  loop and construct `ClientXMPP` **inside** that loop (it binds the running loop at init).
  Event-loop cleanup warnings are cosmetic (known).
- **SSE handoff:** leg threads push `StepEvent`s onto a thread-safe queue; the `/events`
  handler drains it. Must be explicit — `ThreadingHTTPServer` gives one thread per request.
- **Creds over the wire:** `/run/*` receive **unsealed** creds from the page. Keep the
  `/run/*` + `/events` endpoints **loopback-only regardless of the static bind** (LAN
  exposure of the static page is fine; posting plaintext creds across the LAN is not).

**Page reuse (do NOT fork the 37 KB `index.html`):** it carries drift-guarded inline
copies of `oidc.ts` helpers (guarded by `just sso-ref-check`). Copying it would fork those
outside the guard, violating §7's no-duplication rule. Instead serve the **original**
`web-sso-provision-ref/index.html` and inject a small **extension script** (`web/journey-ext.js`)
that adds §5 (XMPP) / §6 (SIP) and **overrides the deviceId to `uc-journey-<user>`** (§9)
so it doesn't reuse web-sso-ref's `web-sso-ref-dev-<user>` slot. §1–4 (OIDC→provision→
unseal) run unchanged in-browser; the extension POSTs the unsealed creds to the core.

Bind `127.0.0.1` by default; LAN opt-in for the static page only, same as web-sso-ref.

## 7. Reuse map (explicit — honors "no duplicated code")

| Piece | Source | Reuse or NEW |
|---|---|---|
| OIDC PKCE S256 (browser: challenge/verifier, loopback code, token exchange) | **port** from `lib/oidc.ts` + `web-sso-provision-ref/index.html` JS | **NEW Python code** (no Python PKCE exists in repo) |
| M2M `client_credentials` w/ app-password token | `tools/e2e_xmpp_notebook.py`, `tests/conftest.py` | reuse |
| Curve25519 sealed-box unseal | `tests/test_xmpp_e2e.py` (`nacl.public`) | reuse |
| XMPP connect + SASL PLAIN + message | `tools/e2e_xmpp_notebook.py`, `tests/test_xmpp_e2e.py` | reuse |
| SIP REGISTER/INVITE + MD5 digest (`_digest_response`) | `tests/test_sip_ring_e2e.py` | reuse |
| Web OIDC UI + error table + redaction | `tools/web-sso-provision-ref/index.html` (served unmodified) | reuse |
| SPA static server | `tools/web-sso-provision-ref/server.py` | reuse handler; **POST/SSE endpoints are NEW** |

Net new protocol code is small but non-zero: Python browser-PKCE and the GUI POST/SSE
server. Everything else is lifted from proven repo code. Where the proven logic lives
inline in a test, the client extracts a small reusable function in the relevant
`journey/*.py` module; tests may later import from the client to converge on one copy
(follow-up, not v1).

## 8. Success criteria — two tiers (stack-only vs lab transport)

Because the dev stack has no XMPP/SIP server (§2), success is tiered:

**Tier 1 — stack-only (the CI gate, no lab needed):**
- **SSO:** token obtained (browser or M2M app-token); decoded claims logged.
- **Provision:** `200` from `/api/provision/device`; `sealedCredentials` unseals to a
  non-empty `{xmppPassword, sipPassword, sipUsername}`; `endpoints` present.

**Tier 2 — transport (requires reachable lab hosts; env-gated, skipped not failed when absent):**
- **XMPP:** SASL PLAIN bind to `--xmpp-host` succeeds; **optional** self-message round-trips.
- **SIP:** REGISTER to `--sip-host` → `200 OK` (**primary**); **optional** INVITE → `100/180`.

**Verdict:** exit non-zero if any *attempted* leg fails. Tier-2 legs that are **skipped**
for lack of a lab host are reported as `SKIPPED` (not failures), mirroring
`pytest.mark.external_network`. `--require-transport` flips skips into failures for a full
lab run. JSON report via `--json`.

## 9. Error handling

- Legs are fault-isolated: a failing leg records its error and the runner **continues**
  remaining legs, so a single run surfaces every problem, then exits non-zero overall.
- Known failures mapped to actionable text (reuse web-sso-ref's table): `403
  NOT_UC_PROVISIONED`, `409 DEVICE_CAP_REACHED`, `500 CREDENTIAL_READ_FAILED`, SIP
  `401/407` (digest), XMPP `not-authorized`.
- Stable `deviceId` (`uc-journey-<user>`) so re-runs replace the same provisioning slot
  rather than stacking toward the device cap (same trick web-sso-ref uses).

## 10. Security

- Credentials redacted by default in CLI output and the wire-log; per-field reveal toggle
  in the GUI (reused).
- GUI server binds `127.0.0.1` by default; LAN exposure is explicit env opt-in.
- Dev-only `slixmpp` `unencrypted_plain = True` is explicit and flagged (matches the
  dev XMPP server having no TLS on `:5222`).
- No secrets written to disk; token + creds live in-process for the run only.

## 11. Testing

- **CI smoke test (stack-only, Tier 1):** `--login m2m --legs provision` full SSO→provision
  →unseal against the dev stack → asserts exit 0. Requires an app-password token: the seed
  step mints one (see §5), OR the test mints an ephemeral user via the conftest token
  factory. **No lab host needed** — this is the CI gate.
- **Lab transport check (Tier 2, opt-in):** `--legs all --require-transport` against the
  lab XMPP/SIP hosts — run by an operator/lab job, not stack-only CI.
- New `just uc-journey` recipe (headless, M2M, Tier 1 by default) for local + CI use.
- Does **not** duplicate the pytest e2e suite — the client is a launchable tool; the smoke
  test only guards it from bit-rot.

## 12. CLI interface (sketch)

Run from `tools/uc-journey-client/` (so `python -m journey` resolves), or via `cli.py`:

```
  --stack-url URL            # directory API base (default http://localhost:8081)
  --authentik-url URL        # default http://localhost:9000
  --login {browser,m2m}      # default m2m headless; browser under --gui
  --user NAME                # subject user (default alanl)
  --app-token TOKEN          # m2m app-password token (env AUTHENTIK_APP_TOKEN)
  --legs {provision,xmpp,sip,all}  # default provision (Tier 1); all needs lab hosts
  --xmpp-host HOST[:PORT]    # lab XMPP host (env; required for xmpp/all leg)
  --xmpp-domain DOMAIN       # SASL/JID domain (default private.z)
  --sip-host HOST[:PORT]     # lab SIP host (env; required for sip/all leg)
  --sip-invite               # opt-in secondary INVITE assertion
  --require-transport        # turn Tier-2 SKIPPED into failures (full lab run)
  --json                     # machine-readable report
  --gui [--gui-port 5173]    # launch optional web GUI (fixed 5173 loopback redirect)
```

## 13. Open questions

None blocking. Deferred follow-ups: (a) converge tests onto the client's extracted
helpers; (b) optional headless browser-PKCE (Playwright) for full-SSO CI without a human.

## 14. References

- `src/backend/main.py` — `POST /api/provision/device`
- `src/frontend/src/lib/oidc.ts` — PKCE source of truth
- `tools/web-sso-provision-ref/` — SSO+provision web reference (handoff point)
- `tools/e2e_xmpp_notebook.py` — XMPP transport reference
- `tests/test_xmpp_e2e.py`, `tests/test_sip_ring_e2e.py` — automated e2e
