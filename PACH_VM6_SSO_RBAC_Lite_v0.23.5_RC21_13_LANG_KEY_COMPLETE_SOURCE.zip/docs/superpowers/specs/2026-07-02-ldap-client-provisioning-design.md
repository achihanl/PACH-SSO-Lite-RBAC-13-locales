# LDAP Client Provisioning — Design

- **Date:** 2026-07-02
- **Surface:** `/configuration/ldap-clients` page + backend (`ldap_provisioning.py`, `ldap_activity.py` classify, `orgdb.py`, API) + CLI (`directoryctl.py`) + OpenLDAP bootstrap
- **Goal:** provision unique, tracked LDAP client credentials from the platform (UI for operators, CLI for dev) so every external client binds with its own identity that the inventory (PR #179) recognizes as **known** instead of mislabeling.
- **Status:** design approved; pending spec review → implementation plan.
- **Builds on:** PR #179 (LDAP client inventory & acknowledgement), ARD-001 (single-LDAP).

## Problem

The inventory from #179 detects binds but cannot attribute a directory/service bind to a distinct external client. Verified empirically 2026-07-02 by driving the real PED80 VM (ejabberd, `192.168.122.220`) through its `System >> User >> AD / LDAP` panel against the platform OpenLDAP:

- **Source IP is NAT-masked.** PED (`192.168.122.220`) → libvirt NAT → host `192.168.4.111:1390` → Docker DNAT/MASQUERADE → slapd sees **`172.18.0.1`** (docker bridge gateway; the openldap container itself is `172.18.0.4`). No `192.168.122.x` ever reaches slapd. `LDAP_KNOWN_SERVICE_CIDRS` cannot help — the only matching CIDR is the gateway, which matches every off-host client.
- **Bind-DN collision.** The PED is configured to bind as `cn=admin,dc=azblink,dc=com` — the platform API's own `LDAP_BIND_DN`. `classify()` rule 3 (`dn == api_bind_dn → "api"`) folds the PED's search into the existing `(cn=admin, 172.18.0.1)` row (id 425). Triggering the panel's "LDAP Search" bumped that row's `session_count` **131 → 133** with **no new row** — indistinguishable from the platform's own API traffic.

So identity must ride on a **unique bind DN per client**. The platform should hand out those DNs.

## Verified findings (empirical, `osixia/openldap:1.5.0`, 2026-07-02)

| Fact | Evidence |
|---|---|
| A distinct bind DN surfaces as a distinct client | Created `cn=ped80-svc,dc=azblink,dc=com`; PED search bound as it → **new row id 17626**, `service=unknown`, `status=unknown` (unacknowledged). |
| A bare account has no read access | Default ACLs grant directory read only to `cn=admin` + self (`{2} to * by self read by dn="cn=admin" write by * none`). `ped80-svc` search of base → **err 32 (No such object)** until granted read. **Provisioning must grant an ACL.** |
| `userPassword` stays protected under read-minus-secrets | After granting `ped80-svc` read on `to *`, rule `{1}` (`to attrs=userPassword… by * none`) still hid the hash: `ped80-svc` sees **0** `userPassword` values; `cn=admin` sees 1. Compare on `userPassword` as `ped80-svc` → denied. |
| User authentication does **not** depend on the client account reading the password | Seeded `uid=ldapprobe` / `LdapProbe!2026`. **bind-as-user** with correct pw → succeeds; wrong pw → rejected (49). The restricted `ped80-svc` cannot read `ldapprobe`'s `userPassword` (0) but **can** find it by `uid`. Auth is verified server-side via bind (authorized by `{1} … by anonymous auth`), independent of the manager account. SSO (Authentik, Plane B) is orthogonal. |
| The app's data bind cannot install ACLs | `LDAP_BIND_DN = cn=admin,dc=azblink,dc=com` is data-admin; it cannot write `cn=config`. The ACL edit today only worked via `ldapmodify -Y EXTERNAL` inside the container. **ACL rule must ship as a bootstrap ldif (EXTERNAL at init), not app runtime.** |

## Design decisions (approved)

1. **Extend the inventory (close the loop).** Provisioning records intent; the passive detector reconciles on first bind → provisioned clients show as **known**, unprovisioned binds stay **unknown**.
2. **ACL scope = read-all-minus-secrets** (uniform). Sufficient for search + user auth; ALL secret attrs stay hidden — `userPassword`, `shadowLastChange`, plus the UC secrets `azbXmppBindPassword` (plaintext XMPP), `AstAuthPassword` (SIP digest), and `AstAuthMd5Cred` (SIP MD5). Proven safe for authentication above.
3. **Lifecycle = create + list + rotate + revoke.** No auto-expiry/scheduler in v1.
4. **Secret = generate-strong + show-once + never stored**, with an optional **operator-supplied password that is strength-validated**. Platform persists only the DN reference; the hash lives in LDAP.
5. **ACL engine = subtree + one static ACL.** All clients under `ou=clients,dc=azblink,dc=com`; a single static rule grants read-minus-secrets to anything under it. No per-client `cn=config` edits.

## Architecture & data flow

```
Operator (UI) / Dev (CLI)
      │  provision "ped80"
      ▼
ldap_provisioning.provision() ── ldapadd ──► cn=ped80,ou=clients,dc=azblink,dc=com (+ userPassword)
      │                                        (static ACL already grants read-minus-secrets)
      ▼
ldap_provisioned_clients (Postgres: intent registry, NO secret)
      │
      ▼  ...client binds later...
slapd stats log ─► ldap_activity collector ─► classify(): dn under ou=clients → "provisioned"
      │                                        upsert marks status="known"
      ▼
ldap_clients row reconciled → UI shows KNOWN (green); non-provisioned binds stay "unknown"
```

## 1. LDAP layer

- **Subtree:** `ou=clients,dc=azblink,dc=com`. Each client = `cn=<client_id>,ou=clients,…`, objectClasses `organizationalRole` + `simpleSecurityObject`, holding `userPassword` (SSHA). Validated shape via `ped80-svc`.
- **Static ACL** (bootstrap ldif, applied EXTERNAL at OpenLDAP init) grants the `ou=clients` read via rule `{3}`:
  `to * by self read by dn="cn=admin,dc=azblink,dc=com" write by dn.children="ou=clients,dc=azblink,dc=com" read by * none`.
  ALL secret attrs stay hidden from provisioned clients: login/bind secrets (`userPassword`, `shadowLastChange`) by rule `{1}`, and UC secrets (`azbXmppBindPassword`, `AstAuthPassword`, `AstAuthMd5Cred`) by rule `{2}` — both ordered before the `ou=clients` read grant so a client never reaches them.
- **`ou=clients`** created idempotently by the app at startup (`ensure_clients_ou()`, bound as `cn=admin` — data plane, allowed). The bootstrap ldif installs the ACL only.
- **Privilege split:** ACL rule = infra/bootstrap (EXTERNAL); per-client add/modify/delete = app runtime (`cn=admin`).

## 2. Backend

- New module `src/backend/ldap_provisioning.py` (single purpose; reuses `ldap_client.py` connection/CRUD helpers — no duplicated bind/conn code):
  - `provision(client_id, label, password=None) -> secret` — generate strong (`secrets.token_urlsafe`) or validate supplied; `ldapadd` under `ou=clients`; insert registry row; return secret once.
  - `rotate(client_id, password=None) -> secret` — MODIFY `userPassword`; update `last_rotated_at`.
  - `revoke(client_id)` — delete entry; set `revoked_at`.
  - `list()` — registry joined with observed `ldap_clients` (last_seen, session_count, connected_now).
  - `ensure_clients_ou()` — idempotent, called from the `main.py` lifespan next to the collector wiring.
- `ldap_activity.classify()` gains one ordered rule before the `uid=` rule: **`dn` under `ou=clients` → `"provisioned"`**. `orgdb.upsert_ldap_session` sets `status="known"` when `bind_dn` matches a live (non-revoked) provisioned client.
- **API** (admin-guarded via `require_permission("system_configuration")`, aligned under the existing `/api/settings/ldap/clients` base):
  - `POST /api/settings/ldap/clients/provisioned` → `{client_id, bind_dn, secret}` (secret returned once)
  - `GET  /api/settings/ldap/clients/provisioned`
  - `POST /api/settings/ldap/clients/provisioned/{client_id}/rotate` → `{secret}`
  - `DELETE /api/settings/ldap/clients/provisioned/{client_id}`
- **Migration** `029_ldap_provisioned_clients.sql`: `id, client_id (unique), bind_dn (unique), label, created_by, created_at, last_rotated_at, revoked_at`. **No secret column.**
- **Config:** `LDAP_CLIENTS_OU` (default `ou=clients,dc=azblink,dc=com`).
- **`client_id` policy:** constrained slug `^[a-z0-9][a-z0-9-]{1,30}$` → clean, predictable DN.

## 3. CLI (dev)

- Extend `src/cli/directoryctl.py` with `ldap-client provision|list|rotate|revoke`.
- **Thin API client** (admin/`DEV_AUTH_TOKEN` bearer) → one authz path, one source of truth, sidesteps the known "host pyenv can't import `main`" constraint. Operator path = UI; dev path = CLI; both hit the same endpoints.

## 4. Frontend

- Extend the existing `/configuration/ldap-clients` page (reuse `lib/queries/ldap-clients.ts` + `types/ldap-clients.ts`; no new page):
  - "Provision client" → modal (client_id, label, optional password + strength meter).
  - Success → **show-once secret panel** (copy button, "you won't see this again").
  - List separates **Provisioned / known** (rotate + revoke actions) from **Detected / unknown** (needs attention).

## 5. Security & authz

- All endpoints admin-only (existing `system_configuration` permission).
- Secret: strong-generated default, show-once, never persisted; supplied passwords strength-validated server-side (reuse `uc_validation` patterns where they fit).
- Read-minus-secrets ACL keeps ALL secret attrs hidden from provisioned clients — `userPassword`, `shadowLastChange`, `azbXmppBindPassword`, `AstAuthPassword`, `AstAuthMd5Cred` (verified; negative regression test in `tests/test_ldap_provisioning.py`).
- Provision / rotate / revoke are security events → **audited** (activity bus + audit trail, mirroring `user_lifecycle_audit`).

## 6. Testing (real Docker stack)

- **Integration:** provision → entry under `ou=clients`; client can bind + search; **cannot** read any secret attr (`userPassword`, `azbXmppBindPassword`, `AstAuthPassword`, `AstAuthMd5Cred`); inventory row reconciles to `provisioned/known`. Rotate → old pw fails, new works. Revoke → bind fails + row `revoked`.
- **Bootstrap idempotency:** `ou=clients` + static ACL apply once, safe to re-run.
- **Auth regression:** bind-as-user still succeeds for a normal user while the manager DN is a provisioned client (guards the "still works with SSO" property).
- **Negatives:** weak supplied password rejected; non-admin → 403; duplicate `client_id` → 409.

## 7. Governance

- Touches governed surfaces (`ldap_activity.py`, `orgdb.py`, API). Implementation carries the correct `ARD:` / `Spec-Patch:` trailer per `docs/architecture/SOP.md`. Decide at PR time whether the `ou=clients` + reconciliation model warrants an ARD-001 amendment.

## Out of scope (v1 / YAGNI)

- Per-client custom ACL scoping (Q2 chose uniform read-minus-secrets).
- Credential expiry + scheduled auto-rotation.
- Retrievable/encrypted secret store (show-once only).
- Un-masking the real source IP (host networking / PROXY protocol) — identity rides on the unique DN instead.
