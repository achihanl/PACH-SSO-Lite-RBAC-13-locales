# QA Pipeline Design: gstack-to-Playwright Export Pipeline

**Date:** 2026-03-24
**Status:** Approved
**Version:** 1.0

## Summary

A three-layer QA pipeline for AZBlink Directory that uses gstack `/browse` for exploratory testing and discovery, exports sessions to deterministic Playwright specs, and runs them locally and in CI. A YAML manifest defines what to test, a local Claude Code skill (`/qa-azblink`) orchestrates the workflow, and Playwright provides the deterministic, version-controlled test execution.

## Goals

1. **Regression safety net** — catch UI breakages on every PR (priority 1)
2. **Feature acceptance** — verify new features end-to-end before marking done (priority 2)
3. **Comprehensive coverage** — grow toward full platform QA over time (priority 3)
4. **Token efficiency** — explore once with gstack, run deterministically with Playwright thereafter
5. **Version control** — manifest, skill, and generated specs all live in the repo

## Non-Goals

- Visual regression testing (Percy/Chromatic) — future consideration
- Load/stress testing — separate concern
- Mobile native testing — web-only platform
- Running gstack in CI — exploration stays local

## Test Environments

The app runs in two environments with different URLs and auth models:

| Environment | URL | Auth | When to use |
|---|---|---|---|
| Vite dev server | `http://localhost:3000` | Form-based login (existing tests use `#username`/`#password`) | Rapid frontend iteration, existing hand-written tests |
| Docker stack (Traefik) | `http://localhost:8081` | Authentik SSO (OIDC) | Full integration testing, CI |

The Playwright config must support both via `BASE_URL` env var:
- Default: `http://localhost:8081` (Docker stack — the primary QA target)
- Override: `BASE_URL=http://localhost:3000 just qa-smoke` for dev server testing

The `webServer` block in `playwright.config.ts` is conditional:
- Local dev: `webServer` starts Vite on port 3000 (existing behavior, opt-in via env var)
- Docker/CI: no `webServer` — assumes stack is already running via `just up`

## Architecture

### Three Layers

```
┌─────────────────────────────────────────────────┐
│  Layer 1: QA Manifest (qa/manifest.yml)         │
│  WHAT to test — pages, flows, auth, assertions  │
│  Version-controlled, PR-reviewable              │
├─────────────────────────────────────────────────┤
│  Layer 2: Local Skill (/qa-azblink)             │
│  HOW to orchestrate — explore, export, run      │
│  Lives in .claude/skills/qa-azblink/SKILL.md    │
├─────────────────────────────────────────────────┤
│  Layer 3: Playwright Specs (src/frontend/e2e/)  │
│  Deterministic output — generated or promoted   │
│  Standard Playwright, any dev can own them       │
└─────────────────────────────────────────────────┘
```

### Data Flow

```
manifest.yml ──→ /qa-azblink explore ──→ session log (JSON)
                                              │
                 /qa-azblink export  ◄────────┘
                       │
                       ▼
              e2e/generated/*.spec.ts ──→ /qa-azblink promote ──→ e2e/*.spec.ts
                       │                                              │
                       └──────────────┬───────────────────────────────┘
                                      ▼
                              npx playwright test
                                      │
                              ┌───────┴───────┐
                              │  Local run    │  CI (GitHub Actions)
                              │  just qa-*    │  on PR to main
                              └───────────────┘
```

## QA Manifest Schema

File: `qa/manifest.yml`

```yaml
version: "1.0"
app:
  name: "AZBlink Directory"
  baseUrl: "http://localhost:8081"

auth:
  devBypass:
    token: "dev-test-token"
    header: "Authorization"
    scheme: "Bearer"
  sso:
    provider: "authentik"
    loginUrl: "https://authentik.keithmoc.dev"
    credentials:
      username: "${QA_SSO_USER}"
      password: "${QA_SSO_PASSWORD}"
    storageStatePath: "qa/.auth/sso-state.json"

pages:
  - id: dashboard
    path: /
    title: "Dashboard"
    requiresAuth: true
    assertions:
      - visible: "Dashboard"
      - type: elementCount
        selector: "[aria-live='polite']"
        operator: ">="
        count: 3
      - type: noConsoleErrors

  - id: users-list
    path: /directory/users
    title: "User Management"
    requiresAuth: true
    assertions:
      - visible: "User Management"
      - interactive: ["search", "pagination", "add-user"]

  - id: groups-list
    path: /directory/groups
    title: "Groups"
    requiresAuth: true
    assertions:
      - visible: "Groups"

  - id: orgs-list
    path: /directory/orgs
    title: "Organization Management"
    requiresAuth: true
    assertions:
      - visible: "Organization Management"

  - id: device-management
    path: /provisioning/devices
    title: "Device Management"
    requiresAuth: true
    assertions:
      - visible: "Device Management"

  - id: audit-log
    path: /audit-log
    title: "Audit Log"
    requiresAuth: true
    assertions:
      - visible: "Audit Log"

  - id: org-profiles
    path: /configuration/org-profiles
    title: "Org Profiles"
    requiresAuth: true
    assertions:
      - visible: "Org Profiles"

  - id: settings
    path: /configuration/settings
    title: "Settings"
    requiresAuth: true
    assertions:
      - visible: "Settings"

  - id: my-profile
    path: /my-profile
    title: "My Profile"
    requiresAuth: true
    assertions:
      - visible: "My Profile"

  - id: login
    path: /login
    title: "Login"
    requiresAuth: false
    assertions:
      - visible: "Sign in with Authentik"

  - id: auth-callback
    path: /auth/callback
    title: "Auth Callback"
    requiresAuth: false
    assertions:
      - note: "Handles OIDC code exchange — tested implicitly via sso-login flow"

  - id: user-onboarding
    path: /directory/users/onboard
    title: "User Onboarding"
    requiresAuth: true
    assertions:
      - visible: "Onboard"

redirects:
  - from: /settings
    to: /configuration/settings
  - from: /directory/users/{uid}
    to: /directory/users?userId={uid}
  - from: /directory/groups/{cn}
    to: /directory/groups?groupId={cn}
  - from: /directory/orgs/{dn}
    to: /directory/orgs?orgId={dn}

flows:
  - id: sso-login
    description: "Complete SSO login flow"
    # Note: Steps match Authentik's current 2-step password flow. Update if flow config changes.
    steps:
      - goto: /login
      - click: "Sign in with Authentik"
      - fill: { selector: "Email or Username", value: "${QA_SSO_USER}" }
      - click: "Log in"
      - fill: { selector: "password", value: "${QA_SSO_PASSWORD}" }
      - click: "Continue"
      - assert: { url: "/", visible: "Dashboard" }

  - id: user-search
    description: "Search for a user"
    requiresAuth: true
    steps:
      - goto: /directory/users
      - fill: { selector: "search", value: "jsmith" }
      - assert: { visible: "jsmith" }

  - id: navigation-sidebar
    description: "Navigate through all sidebar links"
    requiresAuth: true
    steps:
      - goto: /
      - click: "Users"
      - assert: { url: "/directory/users" }
      - click: "Groups"
      - assert: { url: "/directory/groups" }
      - click: "Organizations"
      - assert: { url: "/directory/orgs" }
      - click: "Device Management"
      - assert: { url: "/provisioning/devices" }
      - click: "Audit Log"
      - assert: { url: "/audit-log" }
```

## Local Skill: /qa-azblink

File: `.claude/skills/qa-azblink/SKILL.md`

### Subcommands

#### `/qa-azblink explore [page|flow|all]`
- Reads `qa/manifest.yml`
- Launches gstack `/browse` against specified targets
- For pages: navigates, runs assertions, captures annotated snapshots
- For flows: executes step sequences, captures diffs at each step
- Outputs session log to `qa/sessions/YYYY-MM-DD-<id>.json`
- Session log records every browse command, its result, element accessibility roles/names, and timing
- This is the exploratory phase — token-intensive, run only when needed

#### `/qa-azblink export [session-file|latest]`
- Reads a session log from `qa/sessions/`
- Generates Playwright `.spec.ts` files per page/flow tested
- Command mapping:
  | gstack browse | Playwright |
  |---|---|
  | `goto <url>` | `await page.goto('<url>')` |
  | `click @e1 [button "Submit"]` | `await page.getByRole('button', { name: 'Submit' }).click()` |
  | `fill @e1 [textbox "Email"]` | `await page.getByRole('textbox', { name: 'Email' }).fill('value')` |
  | `is visible ".selector"` | `await expect(page.locator('.selector')).toBeVisible()` |
  | `text (contains "X")` | `await expect(page).toContainText('X')` |
  | `console --errors` | `page.on('console', ...)` listener |
- Uses `getByRole`/`getByText` over CSS selectors for resilience
- Session log captures accessibility role + name per element (not just @e refs)
- Writes to `src/frontend/e2e/generated/`
- Generated files include `// Source: qa/sessions/<file>.json` header

#### `/qa-azblink run [smoke|full|flow-id]`
- `smoke`: login + every page loads (< 2 min target)
- `full`: all generated + hand-written specs
- `flow-id`: run a specific flow's test
- Wraps `npx playwright test` with appropriate config
- Handles auth setup (storageState) automatically

#### `/qa-azblink report`
- Cross-references manifest against existing spec files
- Shows: pages tested / total, flows tested / total
- Flags pages in manifest with no test coverage
- Flags specs that reference pages no longer in manifest
- Outputs coverage percentage

#### `/qa-azblink promote [generated-spec]`
- Moves a generated spec from `e2e/generated/` to `e2e/`
- If a file with the same name exists in `e2e/`, prompts for confirmation before overwriting
- Promoted tests are "owned" — hand-editable, not overwritten by future exports
- The `report` command flags generated specs that have a promoted counterpart as "stale/superseded"
- Explore timeout: 5-minute default per page; `--dry-run` flag previews what would be explored without launching gstack

## Auth Persistence

### Strategy 1: Playwright Auth Setup Project

```typescript
// src/frontend/e2e/setup/auth.setup.ts
import { test as setup, expect } from '@playwright/test';

setup('authenticate via SSO', async ({ page }) => {
  await page.goto('/login');
  await page.getByRole('button', { name: 'Sign in with Authentik' }).click();
  await page.getByRole('textbox', { name: 'Email or Username' }).fill(process.env.QA_SSO_USER!);
  await page.getByRole('button', { name: 'Log in' }).click();
  await page.getByRole('textbox', { name: 'password' }).fill(process.env.QA_SSO_PASSWORD!);
  await page.getByRole('button', { name: 'Continue' }).click();
  await expect(page).toHaveURL('/');
  await page.context().storageState({ path: 'qa/.auth/sso-state.json' });
});
```

- Runs once before all test projects
- Saves cookies/tokens to `qa/.auth/sso-state.json` (.gitignored)
- All test projects declare `dependencies: ['setup']` and load storageState
- Token refresh: setup runs before each suite, expired tokens refresh automatically

### Strategy 2: Dev Bypass (for speed)

```typescript
// src/frontend/e2e/fixtures/authenticated-page.ts
import { test as base } from '@playwright/test';

export const test = base.extend({
  authenticatedPage: async ({ page }, use) => {
    await page.setExtraHTTPHeaders({
      'Authorization': `Bearer ${process.env.DEV_AUTH_TOKEN || 'dev-test-token'}`,
    });
    await use(page);
  },
});
```

- No browser login needed — tests start on target page immediately
- ~10x faster per test vs SSO login

### Strategy 3: Existing Form-Based Login (DEAD)

The existing e2e tests (`pagination.spec.ts`, `settings-pending-changes.spec.ts`) were written against a local login form with `#username`/`#password` selectors. **This form no longer exists** — the login page was migrated to Authentik OIDC (single "Sign in with Authentik" button). Additionally, `dashboard.spec.ts` and `resizable-panel.spec.ts` have no auth at all and will redirect to login.

**All 4 existing tests are broken.** Migration to the `authenticatedPage` fixture (dev bypass) is required in Phase 1, not a future pass.

### When to Use Which

- **SSO strategy**: login flow tests, auth callback tests, session expiry tests (Docker stack)
- **Dev bypass**: everything else — dashboard, CRUD, navigation, search (fastest)
- **Form-based login**: ~~existing tests only~~ **REMOVED** — login page is now Authentik OIDC only, form fields no longer exist

### Prerequisites

- The `Authorization: Bearer <DEV_AUTH_TOKEN>` bypass is verified in `src/backend/main.py` (`_claims_from_auth_header()`). Returns synthetic admin claims (`dev-admin`, `IT-Admins` group).
- The Docker stack (`just up`) must include Authentik for SSO strategy to work. Verify `docker-compose.yml` includes the `authentik-server` and `authentik-worker` services.

## File Layout

```
qa/
  manifest.yml                    # what to test (version-controlled)
  .auth/                          # .gitignored
    sso-state.json                # Playwright storageState
  sessions/                       # .gitignored
    2026-03-24-explore.json       # gstack session logs

.claude/skills/
  qa-azblink/
    SKILL.md                      # the local skill (version-controlled)

src/frontend/
  e2e/
    setup/
      auth.setup.ts               # Playwright auth setup project
    fixtures/
      authenticated-page.ts       # dev bypass fixture
    generated/                    # exported from gstack sessions
      dashboard.spec.ts
      users-list.spec.ts
      sso-login.spec.ts
    *.spec.ts                     # promoted/hand-written specs

  playwright.config.ts            # updated with setup project + generated dir
```

## Session Log Schema

File: `qa/sessions/YYYY-MM-DD-<id>.json`

```json
{
  "version": "1.0",
  "createdAt": "2026-03-24T06:50:00Z",
  "manifestVersion": "1.0",
  "target": { "type": "flow", "id": "sso-login" },
  "commands": [
    {
      "index": 0,
      "command": "goto",
      "args": ["http://localhost:8081/login"],
      "result": { "status": "ok", "url": "http://localhost:8081/login", "httpStatus": 200 },
      "timing": { "startMs": 0, "durationMs": 1200 }
    },
    {
      "index": 1,
      "command": "snapshot",
      "args": ["-i"],
      "result": {
        "elements": [
          { "ref": "@e1", "role": "button", "name": "Sign in with Authentik" },
          { "ref": "@e2", "role": "button", "name": "Open TanStack Router Devtools" }
        ]
      },
      "timing": { "startMs": 1200, "durationMs": 150 }
    },
    {
      "index": 2,
      "command": "click",
      "args": ["@e1"],
      "element": { "role": "button", "name": "Sign in with Authentik" },
      "result": { "status": "ok", "navigatedTo": "https://authentik.keithmoc.dev/..." },
      "timing": { "startMs": 1350, "durationMs": 2500 }
    }
  ]
}
```

Key: the `element` field captures the accessibility role + name at click/fill time, so the export command maps to `getByRole()` without depending on transient @e ref numbers.

## Migration of Existing Tests

Four existing spec files in `src/frontend/e2e/`:
- `dashboard.spec.ts`
- `pagination.spec.ts`
- `resizable-panel.spec.ts`
- `settings-pending-changes.spec.ts`

**Migration plan:**
1. Existing tests stay in `e2e/` as "hand-written/promoted" specs
2. **Phase 1 blocker:** All 4 tests must be migrated to the `authenticatedPage` dev bypass fixture — the form-based login they depend on no longer exists
3. `dashboard.spec.ts` and `resizable-panel.spec.ts` need auth added (currently have none)
4. `pagination.spec.ts` and `settings-pending-changes.spec.ts` need `login()` helper replaced with `authenticatedPage` fixture
5. The new `projects` array in `playwright.config.ts` runs all tests in `e2e/` recursively, including both hand-written and generated

## Playwright Config Changes

Target diff for `src/frontend/playwright.config.ts`:

```typescript
import { defineConfig, devices } from '@playwright/test';

const baseURL = process.env.BASE_URL || 'http://localhost:8081';
const useDevServer = process.env.USE_DEV_SERVER === 'true';

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL,
    trace: 'on-first-retry',
  },

  projects: [
    // Auth setup — runs once before all other projects
    {
      name: 'setup',
      testMatch: /auth\.setup\.ts/,
    },
    // Smoke tests — quick page-load checks (< 2 min)
    {
      name: 'smoke',
      testMatch: /generated\/.*\.spec\.ts/,
      use: {
        ...devices['Desktop Chrome'],
      },
    },
    // Full suite — all tests including hand-written
    {
      name: 'full',
      testIgnore: /auth\.setup\.ts/,
      use: {
        ...devices['Desktop Chrome'],
      },
    },
    // SSO suite — tests needing real Authentik auth
    {
      name: 'sso',
      testMatch: /sso\/.*\.spec\.ts/,
      dependencies: ['setup'],
      use: {
        ...devices['Desktop Chrome'],
        storageState: '../../qa/.auth/sso-state.json',
      },
    },
  ],

  // Only start dev server if explicitly requested
  ...(useDevServer ? {
    webServer: {
      command: 'npm run dev',
      url: 'http://localhost:3000',
      reuseExistingServer: !process.env.CI,
    },
  } : {}),
});
```

## Checklist: .gitignore Updates

Add to project root `.gitignore`:
```
# QA pipeline
qa/.auth/
qa/sessions/
```

## CI Integration

### GitHub Actions Workflow

File: `.github/workflows/qa.yml`

```yaml
name: QA
on:
  pull_request:
    branches: [main]

jobs:
  qa:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 22
      - name: Install dependencies
        run: npm ci
        working-directory: src/frontend
      - name: Install Playwright browsers
        run: npx playwright install --with-deps chromium
        working-directory: src/frontend
      - name: Start Docker stack
        run: just up && just wait-healthy
      - name: Run Playwright smoke suite
        run: npx playwright test --project=smoke
        working-directory: src/frontend
        env:
          QA_SSO_USER: ${{ secrets.QA_SSO_USER }}
          QA_SSO_PASSWORD: ${{ secrets.QA_SSO_PASSWORD }}
      - name: Upload test report
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: playwright-report
          path: src/frontend/playwright-report/
```

### Justfile Commands

Added under a new `# QA Pipeline` section, after the existing `# Testing` section:

```just
# QA Pipeline

# Run Playwright smoke tests (< 2 min, requires Docker stack running)
qa-smoke:
    cd src/frontend && npx playwright test --project=smoke

# Run full Playwright suite (all generated + hand-written specs)
qa-full:
    cd src/frontend && npx playwright test --project=full

# Run Playwright tests with UI mode for debugging
qa-ui:
    cd src/frontend && npx playwright test --ui

# Show QA coverage report (manifest pages/flows vs existing specs)
qa-report:
    @echo "QA Coverage Report"
    @echo "==================="
    @echo "Manifest pages: $(grep -c '  - id:' qa/manifest.yml || echo 0)"
    @echo "Generated specs: $(ls src/frontend/e2e/generated/*.spec.ts 2>/dev/null | wc -l)"
    @echo "Hand-written specs: $(ls src/frontend/e2e/*.spec.ts 2>/dev/null | wc -l)"
```

## Separation of Concerns

| Concern | Local | CI |
|---|---|---|
| Exploration (gstack) | Developer-driven | Never |
| Export (skill) | Developer-driven | Never |
| Smoke tests (Playwright) | `just qa-smoke` | On every PR |
| Full tests (Playwright) | `just qa-full` | Future: nightly |
| Report | `just qa-report` | Future: PR comment |

gstack never runs in CI. CI only runs deterministic Playwright output. This keeps CI fast, cheap, and reproducible.

## Example: Generated Playwright Spec

From the SSO login flow explored on 2026-03-23:

```typescript
// Source: qa/sessions/2026-03-24-sso-login.json
// Manifest flow: sso-login
// Generated by: /qa-azblink export
import { test, expect } from '@playwright/test';

test.describe('SSO Login Flow', () => {
  test('complete SSO login via Authentik', async ({ page }) => {
    await page.goto('/login');
    await expect(page.getByRole('button', { name: 'Sign in with Authentik' })).toBeVisible();

    await page.getByRole('button', { name: 'Sign in with Authentik' }).click();
    await page.getByRole('textbox', { name: 'Email or Username' }).fill(process.env.QA_SSO_USER!);
    await page.getByRole('button', { name: 'Log in' }).click();

    await page.getByRole('textbox', { name: /password/i }).fill(process.env.QA_SSO_PASSWORD!);
    await page.getByRole('button', { name: 'Continue' }).click();

    await expect(page).toHaveURL('/');
    await expect(page.getByText('Dashboard')).toBeVisible();
  });
});
```

## Implementation Priority

1. **Phase 1:** QA manifest + skill skeleton + auth setup project
2. **Phase 2:** Explore + export subcommands (the core pipeline)
3. **Phase 3:** Smoke tests for all pages in manifest
4. **Phase 4:** CI workflow (GitHub Actions)
5. **Phase 5:** Report + promote subcommands
