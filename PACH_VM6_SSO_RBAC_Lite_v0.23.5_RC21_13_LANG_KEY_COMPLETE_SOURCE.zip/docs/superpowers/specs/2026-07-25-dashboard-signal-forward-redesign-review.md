# Dashboard Signal-Forward Redesign — Spec ↔ Source Review

**Date:** 2026-07-25
**Reviews:** `2026-07-25-dashboard-signal-forward-redesign-design.md`
**Method:** every spec claim mapped to backend + frontend source (file:line evidence). Read-only audit.

## Verdict

Directionally sound. All structural claims (dead `trends`, orphaned `recentQR`, dead "View All", stale comments, hardcoded `active_sessions`/`success_rate`, no-breakpoint layout, existing compliance/versions/ldap hooks) are **CONFIRMED**. Six corrections are needed — all bounded, no showstoppers — and two genuine scope decisions remain. Net effort is close to the spec's estimate: **users-by-status turned out free**, offsetting the **activity fix turning out larger**.

## Claim → verdict map

| # | Spec claim | Verdict | Correction |
|---|---|---|---|
| C1 | Compliance drives Alerts tile + card | CONFIRMED + caveats | `summary` is per-*type* counts, no severity, no total; alerts **not** severity-sorted; `cross-user-device` has `subject_uid=None`; endpoint is `require_permission("device_provisioning")`, **not** `require_admin` |
| C2 | Conditional health, detect down UC | PARTIAL | Field is `latency` (string `"12ms"`), not `latency_ms`; conditional fix is trivial & test-safe; **configured UC probe is a no-op** → "detect genuinely-down UC" is unmet without new probe code |
| C3 | Drop fake `active_sessions`/`success_rate` | CONFIRMED, not free | Breaks `tests/test_dashboard_api.py:18-22` + FE type + `StatsGrid`; coordinated change |
| C4 | Expiring-within-48h from pending | INACCURATE | `/api/provisions/pending` exposes only a formatted `detail` string, **not** `expires_at`; needs an additive field |
| C5 | Fix `type_map` + `ActivityEventType` union | UNDERSTATED | **Two divergent vocabularies** (REST vs live-bus) that also disagree with the FE union; a `type_map`-only fix leaves live events iconless |
| C6 | Users-by-status needs backend aggregation (risk) | OVER-CAUTIOUS | Status counts are **effectively free**; option (b) fallback unnecessary |

## Corrections to fold into the spec

**C1 — Compliance (`GET /api/provisioning/compliance`, `main.py:2513`; `orgdb.py:2203`).**
Response is `{"ok", "alerts":[…], "summary":{…}}`. `summary` = `{expired-unused, multi-issue, stale-active, cross-user-device, high-failure-rate}` counts only — **no severity, no total**. Severity vocabulary is `critical` / `warning` / `low` (no `info`/`error`); `cross-user-device` is the only `critical`, and its `subject_uid` is `None` (affected users live in `evidence.users`). Alerts are appended in type order (critical lands 4th), so:
- **Alerts hero count** = sum of `summary` values (or `alerts.length`).
- **Worst-severity color** and **critical-first sort** are **frontend responsibilities** — derive from `alerts[].severity` (or the fixed type→severity map above). The Compliance card must render alerts with `subject_uid=None`.
- Auth: hits a **permission-gated** endpoint (`device_provisioning`), not `require_admin`. Admin roles carry it, but note the divergence from the other dashboard tiles.
- **Reuse:** `complianceQueryOptions()` (`lib/queries/provisioning-ops.ts:65`) and `ComplianceSummaryCards.tsx` already exist against this endpoint.

**C2 — Health (`GET /api/dashboard/health`, `main.py:2752`).**
Per-service shape is `{"name", "status", "latency"}` where `latency` is a **formatted string** (`"12ms"`) and `status` ∈ `{"healthy","error"}` only (no `"warning"` is ever emitted). Conditional-UC fix is minimal and test-safe — guard the two `_check` calls instead of raising:
```python
if UCCHAT_XMPP_DOMAIN: _check("XMPP Server", _xmpp)
if UCCHAT_SIP_DOMAIN:  _check("SIP Server", _sip)
```
Existing consumers: `tests/test_dashboard_api.py:66-99` (asserts core services + `latency.endswith("ms")`) and `tests/test_account_lock.py:183` — neither breaks. **RISK:** even configured, `_xmpp`/`_sip` do no real connectivity probe — they report `healthy` from the config var alone.

**Correction (post-Task-1 review):** the "false-red when unconfigured" scenario is itself *unreachable* — `config.py:368` `_validate_uc_config` raises at import if `UCCHAT_*` is empty (spec `05:59`), so the domain is always set and XMPP/SIP are always green. The resolution is therefore to **drop XMPP/SIP from the health panel** as non-probes (unconditional), not to make them conditional. Health keeps only the real-probe services (PostgreSQL/LDAP/Redis/Authentik). See D1 (revised). Real UC reachability probing stays deferred.

**C3 — Stats (`GET /api/dashboard/stats`, `main.py:2691`).**
Returns a plain dict (no Pydantic model). Dropping `active_sessions`/`success_rate` is a **coordinated** change across: `orgdb.get_dashboard_stats_db` (`orgdb.py:1156-1160`), the endpoint dict (`main.py:2726-2731`), `tests/test_dashboard_api.py:18-22` (assert both keys), FE type `types/dashboard.ts:46,48`, and `StatsGrid.tsx:37,51`. Safe when done together.

**C4 — Pending provisions (`GET /api/provisions/pending`, `main.py:2923`).**
Sort is soonest-first (`orgdb.py:1184`). Item shape is `{id, uid, user{…}, detail, action}` — `detail` is a pre-formatted `"Expires in Nh"` string; **`expires_at` is not exposed**. Add it additively at `main.py:2981` (`"expires_at": raw["expires_at"]`) so the Expiring tile can compute the 48h window; `tests/test_dashboard_api.py:118-155` is additive-safe.

**C5 — Activity vocabularies.**
Two feeds, three disagreeing vocabularies:
- **REST `/api/activity/recent`** `type_map` (`main.py:3019-3031`) collapses `config-change`, `admin-action`, and the never-mapped `device-provisioned`/`device-revoked`/`device-extended` onto the **QR icon** (fallback `qr-generated`), and mis-maps `login → user-created`. Dead map keys (`qr-consumed/generated/expired/revoked`) are never emitted (QR table removed).
- **Live WS/SSE bus** `_publish_activity_event` (`orgdb.py:69`) writes `type` **unremapped**: `provisioning`, `user-suspended`, `user-unsuspended`, `sso-enrolled`, and admin verbs (`create-user`, `update-org`, …). The same event the REST feed calls `device-provisioned`, the bus calls `provisioning`.
- **FE union** is only 6 types (`types/dashboard.ts:30-36`).

A correct fix must cover **both feeds** and replace the `qr-generated` default with a neutral icon; scope depends on Decision 2.

**C6 — Users-by-status (free).**
`GET /api/users` already calls `list_users()` (`main.py:1594`), which does **one** unpaginated subtree search returning every user with `accountStatus` already derived (`ldap_client.py:684-708`); pagination is in-memory slicing. So add per-status counts with **zero** extra LDAP cost:
```python
# in api_users, before search/status filtering:
"statusCounts": dict(Counter(u["accountStatus"] for u in all_users))
```
No new route, no schema, no fragile `userPassword`-sentinel LDAP filtering. **Drop the option-(b) fallback** — it's unnecessary.

## Acceptance-criteria amendments
- **Replace** "when configured UC is genuinely down, the Health tile surfaces the failing service" → "when a **core** service (PG/LDAP/Redis/Authentik) is genuinely down, the Health tile names it." UC health = configured-presence only (revisit under Decision 1).
- **Add:** `/api/provisions/pending` exposes a machine-readable `expires_at`.
- **Add:** users-by-status reflects the whole directory (via `statusCounts`), not one page.
- **Add:** no activity event — from either REST or the live bus — renders with the QR icon unless it is actually a QR event.

## Decisions (resolved)

**D1 — UC health → drop XMPP/SIP (revised after Task 1 review).** The Task 1 review found `config.py:368` `_validate_uc_config` makes `UCCHAT_*` mandatory at startup (spec `05:59`), so the backend cannot boot UC-unconfigured — the "false-red on directory-only" premise is unreachable, and XMPP/SIP are always-green non-probes. Decision: **remove XMPP/SIP from the health panel** (unconditional; no dead code). Health keeps PostgreSQL/LDAP/Redis/Authentik. Real UC reachability probing remains deferred.

**D2 — Activity fix depth → (a) minimal.** Expand the FE union + icon map to cover the types that actually flow from **both** feeds (provisioning/device, admin-action, config-change, login, suspension) and replace the REST `qr-generated` default with a neutral icon. REST↔live-bus name normalization is deferred.

## Reuse wins (lower effort than the spec assumed)
- `complianceQueryOptions()` + `ComplianceSummaryCards.tsx` → Alerts tile + Compliance card.
- `CollapsibleSection` primitive → expandable Health tile; `HealthItem`/`SystemHealthCard` markup for the detail.
- `statusCounts` piggybacks the `list_users()` call the dashboard already pays (twice).
- `systemVersionsQueryOptions()` and `useLdapClients()` already exist — the deferred "update-available" and "live LDAP connections" signals are wire-ready if scope expands later.
- In-repo breakpoint precedent (`grid-cols-1 sm:grid-cols-2 lg:…`) to follow for the responsive fix.

## Revised backend workstream (all additive / read-only, no schema)
1. `health` — conditional UC (guard `_check`).
2. `stats` — drop the two fake fields **+ update `test_dashboard_api.py`**.
3. `pending` — add `expires_at` field.
4. `users` — add `statusCounts` to the response.
5. `activity` — expand icon coverage across both feeds; replace the `qr-generated` default (depth per D2).
