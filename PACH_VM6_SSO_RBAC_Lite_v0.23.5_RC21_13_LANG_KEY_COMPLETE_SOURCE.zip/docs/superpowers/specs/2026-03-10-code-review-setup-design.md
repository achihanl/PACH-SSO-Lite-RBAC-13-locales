# Code Review Setup — Design Spec

**Date:** 2026-03-10
**Status:** Approved

## Context

- Solo developer, not on Claude Code Teams/Enterprise plan
- Managed Code Review service (auto-reviews PRs on Anthropic infra) requires Teams/Enterprise
- `code-review` plugin is installed locally — runs on-demand reviews via `gh` CLI

## Decision

Create `REVIEW.md` at repo root with AZBlink-specific review rules covering:
- **Security:** LDAP injection, auth bypass, secret leakage, rate limiting, HMAC validation
- **Architecture:** Single-LDAP invariant, dual auth planes, two-layer component system, token compliance
- **Test coverage:** Integration tests for new API routes, real Docker stack (no mocks)
- **Database:** Backward-compatible migrations, parameterized SQL

## How It Works

- The `code-review` plugin (`/code-review`) reads `CLAUDE.md` files and checks PR diffs against them
- `REVIEW.md` provides additional review-specific rules that don't belong in `CLAUDE.md`
- If/when the managed Code Review service becomes available, it reads `REVIEW.md` natively

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| **REVIEW.md (chosen)** | Separation of concerns, future-proof for managed service | Local plugin only reads CLAUDE.md today |
| Review rules in CLAUDE.md | Plugin reads it directly | CLAUDE.md already ~300 lines, mixes concerns |
| GitHub Actions self-hosted | Automated on every PR | More infra setup, API key management, CI cost |

## Files Created

- `REVIEW.md` — review-specific rules at repo root
- This design doc
