# Provisioning Device Management Frontend — Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the deprecated QR provisioning placeholder with a full device management page at `/provisioning/devices` — two-tab split-panel UI (Devices | Compliance) consuming existing backend endpoints.

**Architecture:** URL-driven two-tab page following the Audit Log split-panel pattern. The Devices tab renders a ListPanel (left) + DetailPanel (right) with device CRUD actions. The Compliance tab renders summary cards + alert list. All queries/mutations already exist in `provisioning-ops.ts`.

**Tech Stack:** React 19, TanStack Router (file-based routing), TanStack Query (Suspense), @azblink/ui primitives, Tailwind CSS 4, lucide-react icons

**Spec:** `docs/superpowers/specs/2026-03-18-provisioning-devices-frontend-design.md`

---

## Chunk 1: Foundation (Types, Route, Navigation)

### Task 1: Update types in `provisioning-ops.ts`

**Files:**
- Modify: `src/frontend/src/types/provisioning-ops.ts:101-116`

- [ ] **Step 1: Update OpsTab and search params types**

In `src/frontend/src/types/provisioning-ops.ts`, replace the `/* ---- Page state ---- */` section (lines 101–116) with:

```ts
/* ---- Page state ---- */

export type OpsTab = 'devices' | 'compliance';
export type OpsDateRange = '7d' | '30d' | '90d' | 'all';

export interface ProvisioningDevicesSearchParams {
  tab?: OpsTab;
  deviceId?: string;
  platform?: string;
  alertType?: string;
  dateRange?: OpsDateRange;
  search?: string;
  page?: number;
  pageSize?: number;
}
```

Changes from original:
- `OpsTab`: removed `'lifecycle'`
- Renamed `ProvisioningOpsSearchParams` → `ProvisioningDevicesSearchParams`
- Removed `tokenHash` and `filter` fields
- Added `platform` field

- [ ] **Step 2: Verify no other files import the old type name**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -30`

Expected: Clean compile (no files currently import `ProvisioningOpsSearchParams`).

- [ ] **Step 3: Commit**

```bash
git add src/frontend/src/types/provisioning-ops.ts
git commit -m "refactor(types): update OpsTab and rename search params for device management page"
```

---

### Task 2: Create route file and delete old placeholder

**Files:**
- Delete: `src/frontend/src/routes/provisioning/tokens.tsx`
- Create: `src/frontend/src/routes/provisioning/devices.tsx`

- [ ] **Step 1: Delete the old placeholder route**

Delete `src/frontend/src/routes/provisioning/tokens.tsx`.

- [ ] **Step 2: Create the new route file**

Create `src/frontend/src/routes/provisioning/devices.tsx`:

```tsx
/**
 * Device Management page — /provisioning/devices
 * Two-tab layout: Devices (split-panel) + Compliance (alerts).
 * URL search params drive all state.
 */
import { createFileRoute } from '@tanstack/react-router';
import { ProvisioningDevicesPage } from '@/components/features/provisioning-management/ProvisioningDevicesPage';
import type { OpsTab, OpsDateRange, ProvisioningDevicesSearchParams } from '@/types/provisioning-ops';

const validTabs: OpsTab[] = ['devices', 'compliance'];
const validDateRanges: OpsDateRange[] = ['7d', '30d', '90d', 'all'];
const validPageSizes = [10, 25, 50];

export const Route = createFileRoute('/provisioning/devices')({
  validateSearch: (search: Record<string, unknown>): ProvisioningDevicesSearchParams => ({
    tab: validTabs.includes(search.tab as OpsTab) ? (search.tab as OpsTab) : 'devices',
    deviceId: typeof search.deviceId === 'string' ? search.deviceId : undefined,
    platform: typeof search.platform === 'string' ? search.platform : undefined,
    dateRange: validDateRanges.includes(search.dateRange as OpsDateRange)
      ? (search.dateRange as OpsDateRange)
      : '30d',
    search: typeof search.search === 'string' ? search.search : undefined,
    page: search.page != null ? Number(search.page) || 1 : 1,
    pageSize: validPageSizes.includes(Number(search.pageSize))
      ? Number(search.pageSize)
      : 25,
    alertType: typeof search.alertType === 'string' ? search.alertType : undefined,
  }),
  component: DeviceManagementRoute,
});

function DeviceManagementRoute() {
  const searchParams = Route.useSearch();
  return <ProvisioningDevicesPage searchParams={searchParams} />;
}
```

Note: This will have a TypeScript error until Task 4 creates `ProvisioningDevicesPage`. That's expected.

- [ ] **Step 3: Regenerate route tree**

Run: `cd src/frontend && npx @tanstack/router-cli generate`

Do NOT use `npx tsr generate` — that's a different package (`ts-remove-unused`).

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/routes/provisioning/devices.tsx
git rm src/frontend/src/routes/provisioning/tokens.tsx
git add src/frontend/src/routeTree.gen.ts
git commit -m "feat(route): replace /provisioning/tokens with /provisioning/devices"
```

---

### Task 3: Update sidebar navigation

**Files:**
- Modify: `src/frontend/src/components/layout/sidebar.tsx`

- [ ] **Step 1: Update the nav item**

In `src/frontend/src/components/layout/sidebar.tsx`:

1. Update the lucide-react import — add `Smartphone`, remove `KeyRound` (no longer used by anything):
```ts
// Before:
import { LayoutDashboard, Users, Building2, FolderTree, KeyRound, FileText, ... } from 'lucide-react';
// After:
import { LayoutDashboard, Users, Building2, FolderTree, Smartphone, FileText, ... } from 'lucide-react';
```

2. Change the nav item:
- `{ label: 'Provisioning Ops', href: '/provisioning/tokens', icon: KeyRound }` → `{ label: 'Device Management', href: '/provisioning/devices', icon: Smartphone }`

- [ ] **Step 2: Update compliance alert dot href checks**

In the same file, find the two locations that check `item.href === '/provisioning/tokens'` (for the compliance alert dot rendering in both collapsed and expanded sidebar modes). Change both to `item.href === '/provisioning/devices'`.

- [ ] **Step 3: Verify sidebar renders**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`

Expected: No errors in `sidebar.tsx`.

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/components/layout/sidebar.tsx
git commit -m "fix(sidebar): update provisioning nav to /provisioning/devices"
```

---

## Chunk 2: Page Orchestrator + Header + Filter Bar

### Task 4: Create PageHeader component

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/PageHeader.tsx`

Reference: `src/frontend/src/components/features/audit-management/PageHeader.tsx` (follow exact same structure).

- [ ] **Step 1: Create the component**

Create `src/frontend/src/components/features/provisioning-management/PageHeader.tsx`:

```tsx
/**
 * Device management page header — title, search input.
 * - Icon + title + subtitle (left)
 * - Search input with Cmd+K hint (right)
 * - Responsive: stacks vertically below sm
 */
import { Smartphone } from 'lucide-react';
import { SearchInput } from '@/components/features/search-input';

interface PageHeaderProps {
  search: string;
  onSearchChange: (value: string) => void;
  searchInputRef?: React.RefObject<HTMLInputElement | null>;
}

export function PageHeader({
  search,
  onSearchChange,
  searchInputRef,
}: PageHeaderProps) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[var(--color-primary)]/10">
          <Smartphone className="h-5 w-5 text-[var(--color-primary)]" />
        </div>
        <div>
          <h1 className="text-xl font-semibold text-text">Device Management</h1>
          <p className="text-sm text-muted-foreground">
            Manage provisioned devices and compliance alerts
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <SearchInput
          value={search}
          onChange={onSearchChange}
          inputRef={searchInputRef}
          shortcutKey="K"
          placeholder="Search devices by ID, user, or platform..."
          ariaLabel="Search devices"
        />
      </div>
    </div>
  );
}
```

- [ ] **Step 2: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/PageHeader.tsx
git commit -m "feat(provisioning): add PageHeader component"
```

---

### Task 5: Create DeviceFilterBar component

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/DeviceFilterBar.tsx`

Reference: `src/frontend/src/components/features/audit-management/AuditFilterBar.tsx` (pill button pattern lines 80–104).

- [ ] **Step 1: Create the component**

Create `src/frontend/src/components/features/provisioning-management/DeviceFilterBar.tsx`:

```tsx
/**
 * Device filter bar — platform pills + date range select.
 * - Platform: styled button pills with aria-pressed (single-select)
 * - Date range: native select
 * - Responsive: pills wrap, dropdown fallback on small screens
 */
import { Smartphone, Monitor, LayoutList, HelpCircle } from 'lucide-react';
import { cn } from '@azblink/ui';
import type { OpsDateRange } from '@/types/provisioning-ops';
import type { ReactNode } from 'react';

interface DeviceFilterBarProps {
  platform: string | undefined;
  onPlatformChange: (platform: string | undefined) => void;
  dateRange: OpsDateRange;
  onDateRangeChange: (range: OpsDateRange) => void;
}

const platformPills: { value: string | undefined; label: string; icon: ReactNode }[] = [
  { value: undefined, label: 'All', icon: <LayoutList className="h-3.5 w-3.5" /> },
  { value: 'ios', label: 'iOS', icon: <Smartphone className="h-3.5 w-3.5" /> },
  { value: 'android', label: 'Android', icon: <Smartphone className="h-3.5 w-3.5" /> },
  { value: 'desktop', label: 'Desktop', icon: <Monitor className="h-3.5 w-3.5" /> },
];

const dateRangeOptions: { value: OpsDateRange; label: string }[] = [
  { value: '7d', label: 'Last 7 days' },
  { value: '30d', label: 'Last 30 days' },
  { value: '90d', label: 'Last 90 days' },
  { value: 'all', label: 'All time' },
];

export function DeviceFilterBar({
  platform,
  onPlatformChange,
  dateRange,
  onDateRangeChange,
}: DeviceFilterBarProps) {
  return (
    <div className="flex items-center gap-3 flex-wrap">
      {/* Platform — dropdown on small screens */}
      <select
        value={platform ?? ''}
        onChange={(e) => onPlatformChange(e.target.value || undefined)}
        className="md:hidden h-8 rounded-md border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] px-2.5 text-sm text-text"
        aria-label="Platform filter"
        data-testid="device-platform-select"
      >
        {platformPills.map((opt) => (
          <option key={opt.label} value={opt.value ?? ''}>
            {opt.label}
          </option>
        ))}
      </select>

      {/* Platform — pill buttons on md+ screens */}
      <div
        className="hidden md:flex gap-2 flex-wrap"
        role="group"
        aria-label="Platform filter"
      >
        {platformPills.map((opt) => (
          <button
            key={opt.label}
            type="button"
            onClick={() => onPlatformChange(opt.value)}
            aria-pressed={platform === opt.value}
            data-testid={`device-platform-${opt.value ?? 'all'}`}
            className={cn(
              'inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full border text-sm font-medium cursor-pointer transition-all whitespace-nowrap',
              platform === opt.value
                ? 'bg-[var(--color-primary-bg)] border-[var(--color-primary)] text-[var(--color-primary)]'
                : 'border-[var(--color-border-subtle)] text-[var(--color-text-muted)] hover:bg-[var(--color-bg-hover)] hover:border-[var(--color-border-default)]',
            )}
          >
            <span className="flex items-center justify-center w-3.5 h-3.5 shrink-0">
              {opt.icon}
            </span>
            {opt.label}
          </button>
        ))}
      </div>

      {/* Date Range */}
      <div className="flex items-center gap-2">
        <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Period:
        </label>
        <select
          value={dateRange}
          onChange={(e) => onDateRangeChange(e.target.value as OpsDateRange)}
          className="h-8 rounded-md border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] px-2.5 text-sm text-text"
          aria-label="Date range"
          data-testid="device-date-range"
        >
          {dateRangeOptions.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}
```

- [ ] **Step 2: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/DeviceFilterBar.tsx
git commit -m "feat(provisioning): add DeviceFilterBar with platform pills and date range"
```

---

### Task 6: Create ProvisioningDevicesPage orchestrator

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/ProvisioningDevicesPage.tsx`

Reference: `src/frontend/src/components/features/audit-management/AuditLogPage.tsx` (exact same orchestration pattern).

- [ ] **Step 1: Create the page orchestrator**

Create `src/frontend/src/components/features/provisioning-management/ProvisioningDevicesPage.tsx`:

```tsx
/**
 * Device Management page orchestrator — URL state + tab switching.
 * - Devices tab: split-panel (DeviceList left, DeviceDetailPanel right)
 * - Compliance tab: summary cards + alert list
 * - Cmd+K to focus search, Escape to close detail
 */
import { useCallback, useEffect, useRef, Suspense } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { Smartphone } from 'lucide-react';
import { ContentArea, Tabs, TabsList, TabsTrigger, TabsContent, Skeleton } from '@azblink/ui';
import { PageHeader } from './PageHeader';
import { DeviceFilterBar } from './DeviceFilterBar';
import { complianceQueryOptions } from '@/lib/queries/provisioning-ops';
import type {
  ProvisioningDevicesSearchParams,
  OpsTab,
  OpsDateRange,
} from '@/types/provisioning-ops';

interface ProvisioningDevicesPageProps {
  searchParams: ProvisioningDevicesSearchParams;
}

export function ProvisioningDevicesPage({ searchParams }: ProvisioningDevicesPageProps) {
  const {
    tab = 'devices',
    deviceId,
    platform,
    dateRange = '30d',
    search = '',
    page = 1,
    pageSize = 25,
    alertType,
  } = searchParams;

  const navigate = useNavigate();
  const searchRef = useRef<HTMLInputElement>(null);

  const updateSearch = useCallback(
    (updates: Partial<ProvisioningDevicesSearchParams>) => {
      navigate({
        to: '/provisioning/devices',
        search: (prev: Record<string, unknown>) => ({ ...prev, ...updates }),
        replace: true,
      });
    },
    [navigate],
  );

  // Cmd+K to focus search, Escape to close detail
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchRef.current?.focus();
      }
      if (e.key === 'Escape' && deviceId) {
        updateSearch({ deviceId: undefined });
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [deviceId, updateSearch]);

  const handleTabChange = useCallback(
    (value: string | number) => updateSearch({ tab: value as OpsTab, page: 1 }),
    [updateSearch],
  );
  const handleSearchChange = useCallback(
    (s: string) => updateSearch({ search: s || undefined, page: 1 }),
    [updateSearch],
  );
  const handlePlatformChange = useCallback(
    (p: string | undefined) => updateSearch({ platform: p, page: 1 }),
    [updateSearch],
  );
  const handleDateRangeChange = useCallback(
    (r: OpsDateRange) => updateSearch({ dateRange: r, page: 1 }),
    [updateSearch],
  );
  const handleSelectDevice = useCallback(
    (id: string) => updateSearch({ deviceId: id }),
    [updateSearch],
  );
  const handleCloseDetail = useCallback(
    () => updateSearch({ deviceId: undefined }),
    [updateSearch],
  );
  const handlePageChange = useCallback(
    (p: number) => updateSearch({ page: p }),
    [updateSearch],
  );
  const handlePageSizeChange = useCallback(
    (size: number) => updateSearch({ pageSize: size, page: 1 }),
    [updateSearch],
  );

  return (
    <ContentArea className="gap-4">
      <PageHeader
        search={search}
        onSearchChange={handleSearchChange}
        searchInputRef={searchRef}
      />

      <Suspense fallback={null}>
        <ComplianceBadgeLoader tab={tab} onTabChange={handleTabChange}>
          <TabsContent value="devices">
            <div className="flex flex-col gap-4">
              <DeviceFilterBar
                platform={platform}
                onPlatformChange={handlePlatformChange}
                dateRange={dateRange as OpsDateRange}
                onDateRangeChange={handleDateRangeChange}
              />

              <div className="flex flex-1 min-h-0 gap-6">
                {/* Left panel: device list */}
                <div className="flex-1 min-w-0">
                  <Suspense fallback={<DeviceListSkeleton />}>
                    <DeviceListPlaceholder />
                  </Suspense>
                </div>

                {/* Right panel: detail */}
                <div className="hidden lg:flex w-[380px] shrink-0 flex-col rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] overflow-hidden">
                  <Suspense fallback={<DetailSkeleton />}>
                    <EmptyDetailPanel />
                  </Suspense>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="compliance">
            <div className="text-sm text-[var(--color-text-muted)] py-12 text-center">
              Compliance tab — implemented in Task 10
            </div>
          </TabsContent>
        </ComplianceBadgeLoader>
      </Suspense>
    </ContentArea>
  );
}

/**
 * Wraps Tabs with compliance data to show alert count badge.
 * Renders as a controlled Tabs component.
 */
function ComplianceBadgeLoader({
  tab,
  onTabChange,
  children,
}: {
  tab: OpsTab;
  onTabChange: (value: string | number) => void;
  children: React.ReactNode;
}) {
  const { data: compliance } = useSuspenseQuery(complianceQueryOptions());
  const alertCount = compliance?.alerts?.length ?? 0;

  return (
    <Tabs value={tab} onValueChange={onTabChange}>
      <TabsList variant="pill">
        <TabsTrigger value="devices">Devices</TabsTrigger>
        <TabsTrigger
          value="compliance"
          count={alertCount > 0 ? alertCount : undefined}
          countVariant={alertCount > 0 ? 'warning' : undefined}
        >
          Compliance
        </TabsTrigger>
      </TabsList>
      {children}
    </Tabs>
  );
}

/** Placeholder for DeviceList — replaced in Task 8 */
function DeviceListPlaceholder() {
  return (
    <div className="text-sm text-[var(--color-text-muted)] py-12 text-center">
      Device list — implemented in Task 7–8
    </div>
  );
}

function EmptyDetailPanel() {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-2 text-[var(--color-text-muted)]">
      <Smartphone className="h-12 w-12 opacity-30" />
      <p className="text-sm">Select a device to view details</p>
    </div>
  );
}

function DeviceListSkeleton() {
  return (
    <div className="rounded-lg border border-[var(--color-border-subtle)] p-2 space-y-2">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="h-14 bg-muted animate-pulse rounded" />
      ))}
    </div>
  );
}

function DetailSkeleton() {
  return (
    <div className="p-5 space-y-4">
      <div className="h-8 w-48 bg-muted animate-pulse rounded" />
      <div className="grid grid-cols-2 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-16 bg-muted animate-pulse rounded" />
        ))}
      </div>
    </div>
  );
}
```

Note: This includes placeholder functions for `DeviceListPlaceholder` and `EmptyDetailPanel` so the page compiles and renders with correct layout. They get replaced in subsequent tasks.

- [ ] **Step 2: Verify it compiles**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`

Expected: Clean compile.

- [ ] **Step 3: Visual smoke test**

Run the dev stack (`just up-bg` if not running) and navigate to `http://localhost:8081/provisioning/devices`.

Expected: Page renders with header, pill tabs (Devices | Compliance with badge count), filter bar, and placeholder content. Sidebar shows "Device Management" with correct link.

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/ProvisioningDevicesPage.tsx
git commit -m "feat(provisioning): add page orchestrator with tabs, filters, and skeleton layout"
```

---

## Chunk 3: Device List + Row

### Task 7a: Create shared utils for provisioning-management

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/utils.ts`

- [ ] **Step 1: Create the shared utility file**

Create `src/frontend/src/components/features/provisioning-management/utils.ts`:

```ts
/**
 * Shared utilities for provisioning device management components.
 * - mapTokenStatus: API token_status → StatusBadge status prop
 */
import type { StatusBadgeStatus } from '@azblink/ui';

/** Map API token_status string → valid StatusBadgeStatus value */
export function mapTokenStatus(status: string): StatusBadgeStatus {
  switch (status) {
    case 'active': return 'healthy';
    case 'consumed': return 'consumed';
    case 'revoked': return 'error';
    case 'expired': return 'expired';
    default: return 'pending';
  }
}
```

- [ ] **Step 2: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/utils.ts
git commit -m "feat(provisioning): add shared utils with mapTokenStatus"
```

---

### Task 7b: Create DeviceRow component

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/DeviceRow.tsx`

Reference: `src/frontend/src/components/features/audit-management/AuditRow.tsx` (grid row pattern).

- [ ] **Step 1: Create the component**

Create `src/frontend/src/components/features/provisioning-management/DeviceRow.tsx`:

```tsx
/**
 * Device list row — grid row matching ListPanelColumns template.
 * - Device ID (truncated, monospace, tooltip)
 * - User name + uid
 * - Platform icon
 * - StatusBadge
 * - Relative timestamp from consumed_at
 */
import { Smartphone, Monitor, HelpCircle } from 'lucide-react';
import { cn, StatusBadge, Tooltip, TooltipTrigger, TooltipContent } from '@azblink/ui';
import { formatRelativeTime } from '@/lib/utils/date-helpers';
import { mapTokenStatus } from './utils';
import type { ProvisionedDevice } from '@/types/provisioning-ops';

/** Map platform string → icon component */
function PlatformIcon({ platform }: { platform: string | null }) {
  switch (platform?.toLowerCase()) {
    case 'ios':
    case 'android':
      return <Smartphone className="h-4 w-4 text-[var(--color-text-muted)]" />;
    case 'desktop':
      return <Monitor className="h-4 w-4 text-[var(--color-text-muted)]" />;
    default:
      return <HelpCircle className="h-4 w-4 text-[var(--color-text-muted)]" />;
  }
}

const GRID_COLS = 'grid-cols-[1fr_1fr_100px_100px_120px]';

export { GRID_COLS as DEVICE_GRID_COLS };

export function DeviceRow({ device, isSelected, onSelect }: DeviceRowProps) {
  const truncatedId = device.device_id.slice(0, 8) + '…';
  const provisioned = device.consumed_at
    ? formatRelativeTime(device.consumed_at)
    : 'Pending';
  const fullDate = device.consumed_at ?? '';

  return (
    <button
      onClick={onSelect}
      aria-current={isSelected ? 'true' : undefined}
      data-testid={`device-row-${device.device_id}`}
      className={cn(
        'group w-full grid items-center gap-4 px-5 py-3 text-left transition-colors border-b border-[var(--color-border-subtle)]',
        GRID_COLS,
        isSelected
          ? 'bg-[var(--color-primary-bg)] border-l-2 border-l-[var(--color-primary)]'
          : 'hover:bg-[var(--color-bg-hover)]',
      )}
    >
      {/* Device ID */}
      <Tooltip>
        <TooltipTrigger asChild>
          <span className="font-mono text-sm text-text truncate cursor-default">
            {truncatedId}
          </span>
        </TooltipTrigger>
        <TooltipContent>{device.device_id}</TooltipContent>
      </Tooltip>

      {/* User */}
      <div className="min-w-0">
        <p className="text-sm font-medium text-text truncate">{device.user_display_name}</p>
        <p className="text-xs text-muted-foreground truncate">{device.user_uid}</p>
      </div>

      {/* Platform */}
      <div className="flex items-center gap-1.5">
        <PlatformIcon platform={device.platform} />
        <span className="text-sm text-muted-foreground capitalize">
          {device.platform ?? '—'}
        </span>
      </div>

      {/* Status */}
      <StatusBadge status={mapTokenStatus(device.token_status)}>
        {device.token_status}
      </StatusBadge>

      {/* Provisioned */}
      <span className="text-sm text-muted-foreground" title={fullDate}>
        {provisioned}
      </span>
    </button>
  );
}
```

Important: The `StatusBadgeStatus` type import — check if `@azblink/ui` re-exports it. If not, import from `@azblink/ui/primitives/StatusBadge/StatusBadge.types`. Verify via: `grep 'StatusBadgeStatus' src/frontend/packages/azblink-ui/index.ts`.

Also: `DEVICE_GRID_COLS` is exported so `DeviceList` can use the same grid template for `ListPanelColumns`.

- [ ] **Step 2: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/DeviceRow.tsx
git commit -m "feat(provisioning): add DeviceRow grid component with status mapping"
```

---

### Task 8: Create DeviceList component

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/DeviceList.tsx`

Reference: `src/frontend/src/components/features/audit-management/AuditList.tsx` (exact same ListPanel compound usage).

- [ ] **Step 1: Create the component**

Create `src/frontend/src/components/features/provisioning-management/DeviceList.tsx`:

```tsx
/**
 * Device list — left panel of split-panel layout.
 * - ListPanel compound component (header, columns, body, footer)
 * - Pagination (0-based pageIndex conversion)
 * - Empty state
 */
import {
  ListPanel,
  ListPanelHeader,
  ListPanelColumns,
  ListPanelBody,
  ListPanelFooter,
  Pagination,
} from '@azblink/ui';
import { DeviceRow, DEVICE_GRID_COLS } from './DeviceRow';
import type { ProvisionedDevice } from '@/types/provisioning-ops';

interface DeviceListProps {
  devices: ProvisionedDevice[];
  total: number;
  page: number;
  pageSize: number;
  selectedDeviceId?: string;
  onSelectDevice: (id: string) => void;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
}

const DEVICE_COLUMNS = [
  { label: 'Device' },
  { label: 'User' },
  { label: 'Platform' },
  { label: 'Status' },
  { label: 'Provisioned' },
];

export function DeviceList({
  devices,
  total,
  page,
  pageSize,
  selectedDeviceId,
  onSelectDevice,
  onPageChange,
  onPageSizeChange,
}: DeviceListProps) {
  return (
    <ListPanel data-testid="device-list">
      <ListPanelHeader
        title="Devices"
        count={total}
        countLabel="devices"
      />

      <ListPanelColumns
        columns={DEVICE_COLUMNS}
        className={`${DEVICE_GRID_COLS} gap-4 px-5`}
      />

      <ListPanelBody>
        {devices.length === 0 ? (
          <DeviceListEmpty />
        ) : (
          devices.map((device) => (
            <DeviceRow
              key={device.device_id}
              device={device}
              isSelected={selectedDeviceId === device.device_id}
              onSelect={() => onSelectDevice(device.device_id)}
            />
          ))
        )}
      </ListPanelBody>

      <ListPanelFooter>
        <Pagination
          pageIndex={page - 1}
          pageSize={pageSize}
          totalCount={total}
          onPageChange={(idx) => onPageChange(idx + 1)}
          onPageSizeChange={onPageSizeChange}
        />
      </ListPanelFooter>
    </ListPanel>
  );
}

export function DeviceListSkeleton() {
  return (
    <ListPanel>
      <ListPanelHeader title="Devices" />
      <ListPanelBody>
        <div className="p-2 space-y-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-14 bg-muted animate-pulse rounded" />
          ))}
        </div>
      </ListPanelBody>
    </ListPanel>
  );
}

function DeviceListEmpty() {
  return (
    <div
      className="flex flex-col items-center justify-center h-full gap-2 text-[var(--color-text-muted)] py-12"
      role="status"
      aria-live="polite"
    >
      <p className="text-sm">No devices found for current filters</p>
    </div>
  );
}
```

- [ ] **Step 2: Wire DeviceList into ProvisioningDevicesPage**

In `src/frontend/src/components/features/provisioning-management/ProvisioningDevicesPage.tsx`:

1. Add imports at top:
```tsx
import { DeviceList, DeviceListSkeleton } from './DeviceList';
import { devicesQueryOptions } from '@/lib/queries/provisioning-ops';
```

2. Inside the `<TabsContent value="devices">` block (which is passed as `children` to `<ComplianceBadgeLoader>`), replace the `<Suspense fallback={<DeviceListSkeleton />}><DeviceListPlaceholder /></Suspense>` block in the left panel div with:

```tsx
<Suspense fallback={<DeviceListSkeleton />}>
  <DeviceListPanel
    dateRange={dateRange as OpsDateRange}
    platform={platform}
    search={search}
    page={page}
    pageSize={pageSize}
    selectedDeviceId={deviceId}
    onSelectDevice={handleSelectDevice}
    onPageChange={handlePageChange}
    onPageSizeChange={handlePageSizeChange}
  />
</Suspense>
```

3. Add a `DeviceListPanel` Suspense wrapper function (same pattern as `AuditListPanel` in AuditLogPage):

```tsx
/** Suspense-wrapped device list that fetches devices */
function DeviceListPanel({
  dateRange,
  platform,
  search,
  page,
  pageSize,
  selectedDeviceId,
  onSelectDevice,
  onPageChange,
  onPageSizeChange,
}: {
  dateRange: OpsDateRange;
  platform: string | undefined;
  search: string;
  page: number;
  pageSize: number;
  selectedDeviceId?: string;
  onSelectDevice: (id: string) => void;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
}) {
  const { data } = useSuspenseQuery(
    devicesQueryOptions({
      limit: pageSize,
      offset: (page - 1) * pageSize,
      search: search || undefined,
      date_range: dateRange,
      platform: platform || undefined,
    }),
  );

  return (
    <DeviceList
      devices={data.devices}
      total={data.total}
      page={page}
      pageSize={pageSize}
      selectedDeviceId={selectedDeviceId}
      onSelectDevice={onSelectDevice}
      onPageChange={onPageChange}
      onPageSizeChange={onPageSizeChange}
    />
  );
}
```

4. Remove the old `DeviceListPlaceholder` and `DeviceListSkeleton` functions from the page file (they're now in `DeviceList.tsx`).

- [ ] **Step 3: Verify it compiles and renders**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`

Navigate to `http://localhost:8081/provisioning/devices` — should show the device list with pagination (may be empty if no devices provisioned in dev stack).

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/DeviceList.tsx
git add src/frontend/src/components/features/provisioning-management/ProvisioningDevicesPage.tsx
git commit -m "feat(provisioning): add DeviceList with ListPanel and wire into page"
```

---

## Chunk 4: Device Detail Panel

### Task 9: Create DeviceDetailPanel component

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/DeviceDetailPanel.tsx`

Reference: `src/frontend/src/components/features/audit-management/AuditDetailPanel.tsx` (header + scrollable sections + DetailGrid/FieldCard).

- [ ] **Step 1: Create the component**

Create `src/frontend/src/components/features/provisioning-management/DeviceDetailPanel.tsx`:

```tsx
/**
 * Device detail panel — right side of split-panel.
 * - Header: device ID, platform badge, close button
 * - Sub-tabs: Overview (DetailGrid) | History (timeline)
 * - Actions: Extend Token, Revoke
 */
import { useState } from 'react';
import { X, Clock, Trash2 } from 'lucide-react';
import {
  Button,
  DetailGrid,
  FieldCard,
  StatusBadge,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  Badge,
  CodeBlock,
  cn,
} from '@azblink/ui';
import { useSuspenseQuery } from '@tanstack/react-query';
import { deviceHistoryQueryOptions, useBulkRevokeTokens, useExtendToken } from '@/lib/queries/provisioning-ops';
import { formatDateTime, formatRelativeTime } from '@/lib/utils/date-helpers';
import { mapTokenStatus } from './utils';
import type { ProvisionedDevice, DeviceHistoryEntry } from '@/types/provisioning-ops';

export function DeviceDetailPanel({ device, onClose }: DeviceDetailPanelProps) {
  const [detailTab, setDetailTab] = useState<string>('overview');
  const [showExtendDialog, setShowExtendDialog] = useState(false);
  const [showRevokeDialog, setShowRevokeDialog] = useState(false);

  const isActive = device.token_status === 'active';
  const isActionable = device.token_status !== 'revoked' && device.token_status !== 'expired';

  return (
    <div className="flex flex-col h-full overflow-hidden" data-testid="device-detail-panel">
      {/* Header */}
      <div className="px-5 py-4 border-b border-[var(--color-border-subtle)] flex items-start justify-between">
        <div>
          <p className="font-mono text-sm text-text break-all">{device.device_id}</p>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline">{device.platform ?? 'Unknown'}</Badge>
            {device.client_version && (
              <span className="text-xs text-muted-foreground">v{device.client_version}</span>
            )}
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          aria-label="Close detail panel"
          className="shrink-0"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Sub-tabs */}
      <Tabs value={detailTab} onValueChange={setDetailTab}>
        <TabsList variant="underline" className="px-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="flex-1 overflow-y-auto">
          <div className="px-5 py-4">
            <DetailGrid>
              <FieldCard label="User" value={device.user_display_name} />
              <FieldCard label="UID" value={device.user_uid} mono />
              <FieldCard label="Device ID" value={device.device_id} mono />
              <FieldCard label="Platform" value={device.platform ?? '—'} />
              <FieldCard label="Client Version" value={device.client_version ?? '—'} />
              <FieldCard label="IP Address" value={device.ip_address ?? '—'} mono />
              <FieldCard
                label="Token Hash"
                value={device.token_hash.slice(0, 12) + '…'}
                mono
              />
              <FieldCard
                label="Status"
                value={
                  <StatusBadge status={mapTokenStatus(device.token_status)}>
                    {device.token_status}
                  </StatusBadge>
                }
              />
              <FieldCard
                label="Provisioned At"
                value={device.consumed_at ? formatDateTime(device.consumed_at) : 'Pending'}
              />
            </DetailGrid>

            {/* Actions */}
            <div className="flex gap-3 pt-4 mt-4 border-t border-[var(--color-border-subtle)]">
              <Button
                variant="outline"
                size="sm"
                disabled={!isActive}
                onClick={() => setShowExtendDialog(true)}
              >
                <Clock className="h-4 w-4 mr-1.5" />
                Extend
              </Button>
              <Button
                variant="danger"
                size="sm"
                disabled={!isActionable}
                onClick={() => setShowRevokeDialog(true)}
              >
                <Trash2 className="h-4 w-4 mr-1.5" />
                Revoke
              </Button>
            </div>
          </div>
        </TabsContent>

        {/* History */}
        <TabsContent value="history" className="flex-1 overflow-y-auto">
          <div className="px-5 py-4">
            <DeviceHistoryTimeline deviceId={device.device_id} />
          </div>
        </TabsContent>
      </Tabs>

      {/* Extend Token Dialog — inline for now, can extract later */}
      {showExtendDialog && (
        <ExtendTokenDialog
          tokenHash={device.token_hash}
          onClose={() => setShowExtendDialog(false)}
        />
      )}

      {/* Revoke Confirmation — inline for now */}
      {showRevokeDialog && (
        <RevokeConfirmDialog
          tokenHash={device.token_hash}
          deviceId={device.device_id}
          onClose={() => setShowRevokeDialog(false)}
        />
      )}
    </div>
  );
}

/** Device history timeline using deviceHistoryQueryOptions */
function DeviceHistoryTimeline({ deviceId }: { deviceId: string }) {
  const { data } = useSuspenseQuery(deviceHistoryQueryOptions(deviceId));

  if (data.history.length === 0) {
    return (
      <p className="text-sm text-[var(--color-text-muted)] py-6 text-center">
        No history for this device
      </p>
    );
  }

  return (
    <div className="space-y-0">
      {data.history.map((entry: DeviceHistoryEntry, idx: number) => (
        <div
          key={`${entry.token_hash}-${idx}`}
          className="flex gap-3 border-l-2 border-[var(--color-border-default)] pl-4 pb-4 last:pb-0"
        >
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <StatusBadge status={mapTokenStatus(entry.status)}>
                {entry.status}
              </StatusBadge>
              <span className="text-xs text-muted-foreground">
                {entry.consumed_at ? formatRelativeTime(entry.consumed_at) : 'Not consumed'}
              </span>
            </div>
            <p className="font-mono text-xs text-muted-foreground mt-1 truncate">
              {entry.token_hash.slice(0, 16)}…
            </p>
            {entry.platform && (
              <p className="text-xs text-muted-foreground mt-0.5">
                {entry.platform} {entry.client_version ? `v${entry.client_version}` : ''}
              </p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

/** Simple extend token dialog */
function ExtendTokenDialog({
  tokenHash,
  onClose,
}: {
  tokenHash: string;
  onClose: () => void;
}) {
  const [seconds, setSeconds] = useState(3600);
  const extendMutation = useExtendToken();

  const handleExtend = () => {
    extendMutation.mutate(
      { tokenHash, extendSeconds: seconds },
      { onSuccess: () => onClose() },
    );
  };

  const options = [
    { value: 3600, label: '1 hour' },
    { value: 21600, label: '6 hours' },
    { value: 43200, label: '12 hours' },
    { value: 86400, label: '1 day' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-[var(--color-bg-primary)] rounded-lg border border-[var(--color-border-subtle)] p-6 w-80 shadow-lg">
        <h3 className="text-base font-semibold text-text mb-3">Extend Token</h3>
        <select
          value={seconds}
          onChange={(e) => setSeconds(Number(e.target.value))}
          className="w-full h-9 rounded-md border border-[var(--color-border-subtle)] bg-[var(--color-bg-primary)] px-3 text-sm text-text mb-4"
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
        <div className="flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button
            variant="primary"
            size="sm"
            onClick={handleExtend}
            disabled={extendMutation.isPending}
          >
            {extendMutation.isPending ? 'Extending…' : 'Extend'}
          </Button>
        </div>
      </div>
    </div>
  );
}

/** Simple revoke confirmation dialog */
function RevokeConfirmDialog({
  tokenHash,
  deviceId,
  onClose,
}: {
  tokenHash: string;
  deviceId: string;
  onClose: () => void;
}) {
  const revokeMutation = useBulkRevokeTokens();

  const handleRevoke = () => {
    revokeMutation.mutate([tokenHash], { onSuccess: () => onClose() });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-[var(--color-bg-primary)] rounded-lg border border-[var(--color-border-subtle)] p-6 w-80 shadow-lg">
        <h3 className="text-base font-semibold text-text mb-2">Revoke Device</h3>
        <p className="text-sm text-muted-foreground mb-4">
          This will revoke access for device <span className="font-mono">{deviceId.slice(0, 8)}…</span>.
          This action cannot be undone.
        </p>
        <div className="flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button
            variant="danger"
            size="sm"
            onClick={handleRevoke}
            disabled={revokeMutation.isPending}
          >
            {revokeMutation.isPending ? 'Revoking…' : 'Revoke'}
          </Button>
        </div>
      </div>
    </div>
  );
}
```

- [ ] **Step 2: Wire DeviceDetailPanel into ProvisioningDevicesPage**

In `ProvisioningDevicesPage.tsx`:

1. Add import: `import { DeviceDetailPanel } from './DeviceDetailPanel';`

2. Inside the `<TabsContent value="devices">` block (within `ComplianceBadgeLoader` children), find the right panel div (`hidden lg:flex w-[380px]`) and replace its `<Suspense><EmptyDetailPanel /></Suspense>` with:

```tsx
<Suspense fallback={<DetailSkeleton />}>
  <DetailPanelWrapper
    dateRange={dateRange as OpsDateRange}
    platform={platform}
    search={search}
    page={page}
    pageSize={pageSize}
    selectedDeviceId={deviceId}
    onClose={handleCloseDetail}
  />
</Suspense>
```

3. Add the wrapper function:

```tsx
/** Suspense-wrapped detail panel — finds device from list data */
function DetailPanelWrapper({
  dateRange,
  platform,
  search,
  page,
  pageSize,
  selectedDeviceId,
  onClose,
}: {
  dateRange: OpsDateRange;
  platform: string | undefined;
  search: string;
  page: number;
  pageSize: number;
  selectedDeviceId?: string;
  onClose: () => void;
}) {
  const { data } = useSuspenseQuery(
    devicesQueryOptions({
      limit: pageSize,
      offset: (page - 1) * pageSize,
      search: search || undefined,
      date_range: dateRange,
      platform: platform || undefined,
    }),
  );

  const selectedDevice = selectedDeviceId
    ? data.devices.find((d) => d.device_id === selectedDeviceId)
    : undefined;

  if (!selectedDevice) {
    return <EmptyDetailPanel />;
  }

  return <DeviceDetailPanel device={selectedDevice} onClose={onClose} />;
}
```

- [ ] **Step 3: Verify it compiles and renders**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`

Navigate to `/provisioning/devices?deviceId=<some-id>` — should show detail panel (or empty state if no matching device).

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/DeviceDetailPanel.tsx
git add src/frontend/src/components/features/provisioning-management/ProvisioningDevicesPage.tsx
git commit -m "feat(provisioning): add DeviceDetailPanel with overview, history, and actions"
```

---

## Chunk 5: Compliance Tab

### Task 10: Create ComplianceAlertRow component

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/ComplianceAlertRow.tsx`

- [ ] **Step 1: Create the component**

Create `src/frontend/src/components/features/provisioning-management/ComplianceAlertRow.tsx`:

```tsx
/**
 * Compliance alert row — severity badge + description + expandable evidence.
 */
import { Badge, CollapsibleSection, CodeBlock } from '@azblink/ui';
import { formatRelativeTime } from '@/lib/utils/date-helpers';
import type { ComplianceAlert, AlertSeverity } from '@/types/provisioning-ops';
import type { BadgeVariant } from '@azblink/ui';

/** Map alert severity → Badge variant */
function severityVariant(severity: AlertSeverity): BadgeVariant {
  switch (severity) {
    case 'critical': return 'error';
    case 'warning': return 'warning';
    case 'low': return 'muted';
    default: return 'muted';
  }
}

interface ComplianceAlertRowProps {
  alert: ComplianceAlert;
}

export function ComplianceAlertRow({ alert }: ComplianceAlertRowProps) {
  return (
    <div className="flex items-start gap-4 p-4 border border-[var(--color-border-subtle)] rounded-lg">
      <Badge variant={severityVariant(alert.severity)}>{alert.severity}</Badge>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-[var(--color-text-primary)]">
          {alert.description}
        </p>
        <p className="text-xs text-[var(--color-text-muted)] mt-1">
          {alert.subject_uid && `User: ${alert.subject_uid}`}
          {alert.subject_device_id && ` · Device: ${alert.subject_device_id}`}
          {` · ${formatRelativeTime(alert.detected_at)}`}
        </p>
        <CollapsibleSection title="Evidence & Action">
          <CodeBlock
            language="json"
            maxHeight="200px"
            code={JSON.stringify(alert.evidence, null, 2)}
          />
          <p className="text-xs text-[var(--color-text-muted)] mt-2 italic">
            {alert.recommended_action}
          </p>
        </CollapsibleSection>
      </div>
    </div>
  );
}
```

Important: Check if `BadgeVariant` is re-exported from `@azblink/ui`. If not, import from `@azblink/ui/primitives/Badge/Badge.types`.

- [ ] **Step 2: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/ComplianceAlertRow.tsx
git commit -m "feat(provisioning): add ComplianceAlertRow with severity badge and evidence"
```

---

### Task 11: Create ComplianceSummaryCards component

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/ComplianceSummaryCards.tsx`

- [ ] **Step 1: Create the component**

Create `src/frontend/src/components/features/provisioning-management/ComplianceSummaryCards.tsx`:

```tsx
/**
 * Compliance summary cards — one clickable card per alert type.
 * - 6 cards in responsive grid
 * - Active filter state shown with ring
 */
import { cn, FieldCard } from '@azblink/ui';
import type { ComplianceAlertType, ComplianceSummary } from '@/types/provisioning-ops';

interface ComplianceSummaryCardsProps {
  summary: ComplianceSummary;
  activeFilter: ComplianceAlertType | undefined;
  onFilterChange: (type: ComplianceAlertType | undefined) => void;
}

const ALERT_TYPES: { type: ComplianceAlertType; label: string }[] = [
  { type: 'expired-unused', label: 'Expired Unused' },
  { type: 'rapid-consumption', label: 'Rapid Consumption' },
  { type: 'multi-issue', label: 'Multi-Issue Users' },
  { type: 'stale-active', label: 'Stale Active' },
  { type: 'cross-user-device', label: 'Cross-User Device' },
  { type: 'high-failure-rate', label: 'High Failure Rate' },
];

export function ComplianceSummaryCards({
  summary,
  activeFilter,
  onFilterChange,
}: ComplianceSummaryCardsProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {ALERT_TYPES.map(({ type, label }) => (
        <button
          key={type}
          onClick={() => onFilterChange(activeFilter === type ? undefined : type)}
          data-testid={`compliance-card-${type}`}
          className={cn(
            'text-left rounded-lg border border-[var(--color-border-subtle)] p-4',
            'hover:bg-[var(--color-bg-hover)] transition-colors',
            activeFilter === type && 'ring-2 ring-[var(--color-primary)]',
          )}
        >
          <FieldCard label={label} value={summary[type] ?? 0} />
        </button>
      ))}
    </div>
  );
}
```

- [ ] **Step 2: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/ComplianceSummaryCards.tsx
git commit -m "feat(provisioning): add ComplianceSummaryCards with clickable filter cards"
```

---

### Task 12: Create ComplianceTab and wire into page

**Files:**
- Create: `src/frontend/src/components/features/provisioning-management/ComplianceTab.tsx`
- Modify: `src/frontend/src/components/features/provisioning-management/ProvisioningDevicesPage.tsx`

- [ ] **Step 1: Create the ComplianceTab component**

Create `src/frontend/src/components/features/provisioning-management/ComplianceTab.tsx`:

```tsx
/**
 * Compliance tab — summary cards + alert list.
 * - Cards filter alert list on click
 * - Sorted by severity: critical → warning → low
 * - Empty state with checkmark
 */
import { CheckCircle } from 'lucide-react';
import { ComplianceSummaryCards } from './ComplianceSummaryCards';
import { ComplianceAlertRow } from './ComplianceAlertRow';
import type {
  ComplianceAlert,
  ComplianceAlertType,
  ComplianceSummary,
  AlertSeverity,
} from '@/types/provisioning-ops';

interface ComplianceTabProps {
  alerts: ComplianceAlert[];
  summary: ComplianceSummary;
  activeFilter: ComplianceAlertType | undefined;
  onFilterChange: (type: ComplianceAlertType | undefined) => void;
}

const SEVERITY_ORDER: Record<AlertSeverity, number> = {
  critical: 0,
  warning: 1,
  low: 2,
};

export function ComplianceTab({
  alerts,
  summary,
  activeFilter,
  onFilterChange,
}: ComplianceTabProps) {
  const filteredAlerts = activeFilter
    ? alerts.filter((a) => a.type === activeFilter)
    : alerts;

  const sortedAlerts = [...filteredAlerts].sort(
    (a, b) => (SEVERITY_ORDER[a.severity] ?? 9) - (SEVERITY_ORDER[b.severity] ?? 9),
  );

  return (
    <div className="flex flex-col gap-4">
      <ComplianceSummaryCards
        summary={summary}
        activeFilter={activeFilter}
        onFilterChange={onFilterChange}
      />

      {sortedAlerts.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-2 py-12 text-[var(--color-text-muted)]">
          <CheckCircle className="h-10 w-10 opacity-40" />
          <p className="text-sm">
            {activeFilter ? 'No alerts for this category' : 'No compliance alerts'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {sortedAlerts.map((alert) => (
            <ComplianceAlertRow key={alert.id} alert={alert} />
          ))}
        </div>
      )}
    </div>
  );
}
```

- [ ] **Step 2: Wire ComplianceTab into ProvisioningDevicesPage**

In `ProvisioningDevicesPage.tsx`:

1. Add import: `import { ComplianceTab } from './ComplianceTab';`

2. Add a handler for alert type filter:
```tsx
const handleAlertTypeChange = useCallback(
  (type: string | undefined) => updateSearch({ alertType: type }),
  [updateSearch],
);
```

3. Replace the compliance `TabsContent` placeholder with:

```tsx
<TabsContent value="compliance" keepMounted>
  <ComplianceTabWrapper
    alertType={alertType}
    onAlertTypeChange={handleAlertTypeChange}
  />
</TabsContent>
```

4. Add the wrapper function that passes compliance data:

```tsx
/** Compliance tab receives data from the ComplianceBadgeLoader's query */
function ComplianceTabWrapper({
  alertType,
  onAlertTypeChange,
}: {
  alertType: string | undefined;
  onAlertTypeChange: (type: string | undefined) => void;
}) {
  const { data: compliance } = useSuspenseQuery(complianceQueryOptions());

  return (
    <ComplianceTab
      alerts={compliance.alerts}
      summary={compliance.summary}
      activeFilter={alertType as ComplianceAlertType | undefined}
      onFilterChange={onAlertTypeChange}
    />
  );
}
```

5. Add `ComplianceAlertType` to the imports from `@/types/provisioning-ops`.

- [ ] **Step 3: Verify it compiles and renders**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`

Navigate to `/provisioning/devices?tab=compliance` — should show summary cards and alert list.

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/components/features/provisioning-management/ComplianceTab.tsx
git add src/frontend/src/components/features/provisioning-management/ProvisioningDevicesPage.tsx
git commit -m "feat(provisioning): add ComplianceTab with summary cards and alert list"
```

---

## Chunk 6: Polish + Final Verification

### Task 13: Lint, format, and type-check

**Files:**
- All new files in `src/frontend/src/components/features/provisioning-management/`

- [ ] **Step 1: Run TypeScript type check**

Run: `cd src/frontend && npx tsc --noEmit`

Expected: Clean — zero errors.

Fix any errors before proceeding.

- [ ] **Step 2: Run ESLint**

Run: `just ui-lint`

Fix any lint warnings/errors.

- [ ] **Step 3: Run Prettier**

Run: `just ui-format`

- [ ] **Step 4: Commit any formatting fixes**

```bash
git add -A src/frontend/src/components/features/provisioning-management/
git add src/frontend/src/types/provisioning-ops.ts
git add src/frontend/src/routes/provisioning/devices.tsx
git add src/frontend/src/components/layout/sidebar.tsx
git diff --cached --stat  # verify only expected files
git commit -m "style(provisioning): lint and format device management page"
```

---

### Task 14: End-to-end smoke test

- [ ] **Step 1: Start the dev stack (if not running)**

Run: `just up-bg` and wait for healthy: `just health-check`

- [ ] **Step 2: Navigate and verify each feature**

Test each of these in the browser at `http://localhost:8081/`:

1. Sidebar shows "Device Management" under "Provisioning" section
2. Click it → navigates to `/provisioning/devices`
3. Page header shows Smartphone icon + title + search input
4. Pill tabs: "Devices" (active) and "Compliance" (with count badge if alerts exist)
5. Filter bar shows platform pills + date range select
6. Device list renders (may be empty in dev) with proper empty state message
7. Switch to "Compliance" tab → summary cards + alert list render
8. Click a summary card → filters alert list
9. Click same card again → clears filter
10. `Cmd+K` / `Ctrl+K` → focuses search input
11. URL updates correctly with `?tab=`, `?platform=`, `?dateRange=` params
12. Back button navigates properly through URL state changes

- [ ] **Step 3: Record any issues found**

If issues found, fix them and commit with descriptive message before proceeding.

- [ ] **Step 4: Final commit (if any fixes)**

```bash
git add -A src/frontend/src/components/features/provisioning-management/
git commit -m "fix(provisioning): address smoke test issues"
```

---

## Deferred Items (Follow-Up)

These spec requirements are intentionally deferred from this plan to keep scope tight. They should be addressed in follow-up work:

1. **Arrow key navigation (↑/↓) on device list** — Spec requires `↑`/`↓` to navigate the device list. This needs a `keydown` handler that tracks ordered device IDs and moves selection. Non-trivial; defer to a follow-up keyboard navigation task after the base page is working.

2. **Mobile detail panel behavior** — Spec says `< lg`: "device row click navigates or opens sheet." The current implementation hides the detail panel below `lg` and clicking a device row sets `?deviceId=` in URL with no visible effect. Follow-up should either add a drawer/sheet component or navigate to a dedicated detail route on mobile.
