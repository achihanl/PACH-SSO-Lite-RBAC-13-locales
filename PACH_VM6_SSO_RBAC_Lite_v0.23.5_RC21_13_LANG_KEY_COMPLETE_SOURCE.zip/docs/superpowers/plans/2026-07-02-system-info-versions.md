# System Information — Stack Versions Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Surface precise per-service stack versions (platform + PostgreSQL, Redis, Authentik, OpenLDAP, Traefik) under the configuration System Info section.

**Architecture:** New admin-gated backend endpoint `GET /api/system/versions` probes each service live where reliable (Postgres/Redis/Authentik/platform) and falls back to declared docker image tags for services with no runtime version path (OpenLDAP/Traefik). Frontend extends the existing `SystemInfoSection` with a "Service Versions" card + a Platform Version row — no new page, no new component file. Two stale-data polish fixes ride along in the same card.

**Tech Stack:** FastAPI (backend, `main.py`), SQLAlchemy (`ORGDB`), `redis-py`, `urllib` (Authentik), pytest integration tests (real Docker stack), React 19 + TanStack Query + `@azblink/ui` (frontend).

**Governance:** backend commits touching `src/backend/main.py` carry a `Spec-Patch:` trailer (read-only diagnostics endpoint, non-decisional; mirrors `/api/dashboard/health`).

---

## File Structure

- `src/backend/main.py` — add `GET /api/system/versions` after `api_dashboard_health` (currently ends line 2464). Owns all probe logic (self-contained, per existing dashboard-health pattern).
- `tests/test_health.py` — add `TestSystemVersionsEndpoint` class (existing home of version/health tests). No new test file.
- `deploy/dev/docker-compose.yml` — add two env vars to the `directory-api` service (after line 130, `BUILD_TIME`).
- `src/frontend/src/lib/queries/keys.ts` — add `systemVersions` key.
- `src/frontend/src/lib/queries/health.ts` — add types + `systemVersionsQueryOptions()`.
- `src/frontend/src/components/features/settings/sections/SystemInfoSection.tsx` — Service Versions card, Platform Version row, 2 polish fixes.

---

## Task 1: Backend endpoint `GET /api/system/versions` (TDD)

**Files:**
- Modify: `src/backend/main.py` (insert after line 2464, before `@app.get("/api/provisions/pending")`)
- Test: `tests/test_health.py` (add class at end of file)

- [ ] **Step 1: Write the failing test**

Add to `tests/test_health.py`:

```python
class TestSystemVersionsEndpoint:
    """Stack version inventory — platform + per-service versions."""

    def test_requires_admin(self, anon_client):
        """Unauthenticated request is rejected."""
        resp = anon_client.get("/api/system/versions")
        assert resp.status_code in (401, 403)

    def test_returns_platform_and_services(self, client):
        """Response contains platform block + non-empty services list."""
        resp = client.get("/api/system/versions")
        assert resp.status_code == 200
        data = resp.json()
        assert "version" in data["platform"]
        assert isinstance(data["services"], list) and data["services"]
        for svc in data["services"]:
            assert {"name", "version", "source"} <= set(svc.keys())
            assert svc["source"] in ("live", "image", "unknown")

    def test_postgres_and_redis_are_live(self, client):
        """Postgres + Redis report live, non-null versions when stack is up."""
        resp = client.get("/api/system/versions")
        by_name = {s["name"]: s for s in resp.json()["services"]}
        assert by_name["PostgreSQL"]["source"] == "live"
        assert by_name["PostgreSQL"]["version"] is not None
        assert by_name["Redis"]["source"] == "live"
        assert by_name["Redis"]["version"] is not None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `just test-quick 2>/dev/null || (cd deploy/dev && just test-quick)` — or directly:
`cd deploy/dev && just psql >/dev/null 2>&1; pytest tests/test_health.py::TestSystemVersionsEndpoint -v`
Expected: FAIL — 404 Not Found (endpoint does not exist yet).

- [ ] **Step 3: Write minimal implementation**

Insert into `src/backend/main.py` immediately after the `return {"services": services}` line that closes `api_dashboard_health` (line 2464):

```python
@app.get("/api/system/versions")
def api_system_versions(
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Stack version inventory — platform + per-service versions.

    - Admin-gated (mirrors /api/dashboard/health).
    - Live probes where reliable (PostgreSQL, Redis, Authentik); declared
      docker image-tag fallback where no runtime version path exists
      (OpenLDAP, Traefik).
    - Each probe isolated: failure yields source="unknown", never a 500.
    """
    import re as _re
    import json as _json
    import urllib.request
    import redis as redis_client
    from sqlalchemy import text as sa_text

    services: List[Dict[str, Any]] = []

    # PostgreSQL — SELECT version() → "PostgreSQL 16.14 (Debian …)"
    try:
        with ORGDB.connect().begin() as conn:
            raw = conn.execute(sa_text("SELECT version()")).scalar() or ""
        m = _re.search(r"PostgreSQL (\d+\.\d+(?:\.\d+)?)", raw)
        services.append({
            "name": "PostgreSQL",
            "version": m.group(1) if m else None,
            "source": "live",
        })
    except Exception:
        services.append({"name": "PostgreSQL", "version": None, "source": "unknown"})

    # Redis — INFO server → redis_version
    try:
        r = redis_client.from_url(REDIS_URL)
        services.append({
            "name": "Redis",
            "version": r.info("server").get("redis_version"),
            "source": "live",
        })
    except Exception:
        services.append({"name": "Redis", "version": None, "source": "unknown"})

    # Authentik — GET /api/v3/admin/version/ → version_current (+ latest/outdated)
    try:
        if not (AUTHENTIK_API_URL and AUTHENTIK_API_TOKEN):
            raise RuntimeError("not configured")
        req = urllib.request.Request(
            f"{AUTHENTIK_API_URL.rstrip('/')}/api/v3/admin/version/",
            method="GET",
        )
        req.add_header("Authorization", f"Bearer {AUTHENTIK_API_TOKEN}")
        with urllib.request.urlopen(req, timeout=5) as resp:
            payload = _json.loads(resp.read().decode())
        services.append({
            "name": "Authentik",
            "version": payload.get("version_current"),
            "source": "live",
            "latest": payload.get("version_latest"),
            "outdated": payload.get("outdated"),
        })
    except Exception:
        services.append({"name": "Authentik", "version": None, "source": "unknown"})

    # OpenLDAP — no reliable runtime version path (verified osixia 1.5.0);
    # declared image tag from env.
    ldap_tag = os.environ.get("LDAP_IMAGE_TAG")
    services.append({
        "name": "OpenLDAP",
        "version": ldap_tag,
        "source": "image" if ldap_tag else "unknown",
        "note": "osixia wrapper tag, not slapd version",
    })

    # Traefik — no clean version API; declared image tag from env.
    traefik_tag = os.environ.get("TRAEFIK_IMAGE_TAG")
    services.append({
        "name": "Traefik",
        "version": traefik_tag,
        "source": "image" if traefik_tag else "unknown",
    })

    from _version import __version__
    return {
        "platform": {
            "version": __version__,
            "gitHash": os.environ.get("GIT_HASH", "unknown"),
            "gitBranch": os.environ.get("GIT_BRANCH", "unknown"),
            "buildTime": os.environ.get("BUILD_TIME", "unknown"),
        },
        "services": services,
    }
```

Note: `os`, `Depends`, `Dict`, `List`, `Any`, `require_admin`, `ORGDB`, `REDIS_URL`, `AUTHENTIK_API_URL`, `AUTHENTIK_API_TOKEN` are all already imported/defined in `main.py` (verified). Backend hot-reloads (~1s) — no rebuild.

- [ ] **Step 4: Run test to verify it passes**

Run: `cd deploy/dev && pytest ../../tests/test_health.py::TestSystemVersionsEndpoint -v`
Expected: PASS (4 tests). `test_postgres_and_redis_are_live` confirms live probes work against the running stack.

- [ ] **Step 5: Commit**

```bash
git add src/backend/main.py tests/test_health.py
git commit -m "feat(system-info): add GET /api/system/versions endpoint

Admin-gated stack version inventory. Live probes for PostgreSQL, Redis,
Authentik, and platform; image-tag fallback for OpenLDAP/Traefik.

Spec-Patch: observability read-only diagnostics endpoint
Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

(If the guard/commitizen hook objects to the trailer, fix the message shape — do NOT `--no-verify`.)

---

## Task 2: Compose image-tag env vars

**Files:**
- Modify: `deploy/dev/docker-compose.yml` (`directory-api` service `environment:`, after line 130 `BUILD_TIME`)

- [ ] **Step 1: Add the env vars**

After the `BUILD_TIME: ${BUILD_TIME:-unknown}` line, add:

```yaml
      LDAP_IMAGE_TAG: ${LDAP_IMAGE_TAG:-osixia/openldap:1.5.0}
      TRAEFIK_IMAGE_TAG: ${TRAEFIK_IMAGE_TAG:-v3.7}
```

- [ ] **Step 2: Recreate the api container to pick up env**

Run: `cd deploy/dev && docker compose up -d directory-api`
Expected: container recreated. (Compose env change needs recreate, not just hot-reload.)

- [ ] **Step 3: Verify OpenLDAP/Traefik now report `image`**

Run: `curl -s -H "Authorization: Bearer dev-test-token" http://localhost:8081/api/system/versions | python3 -m json.tool`
Expected: `OpenLDAP` and `Traefik` rows show `"source": "image"` with the tag string; Postgres/Redis/Authentik show `"source": "live"`.

- [ ] **Step 4: Commit**

```bash
git add deploy/dev/docker-compose.yml
git commit -m "feat(system-info): pass OpenLDAP/Traefik image tags to api

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 3: Frontend query options + types

**Files:**
- Modify: `src/frontend/src/lib/queries/keys.ts` (after the `health:` key, ~line 80)
- Modify: `src/frontend/src/lib/queries/health.ts` (append)

- [ ] **Step 1: Add query key**

In `keys.ts`, after `health: ['health'] as const,` add:

```ts
  // System versions
  systemVersions: ['system', 'versions'] as const,
```

- [ ] **Step 2: Add types + query options**

Append to `src/frontend/src/lib/queries/health.ts`:

```ts
export interface ServiceVersion {
  name: string
  version: string | null
  source: 'live' | 'image' | 'unknown'
  note?: string
  latest?: string | null
  outdated?: boolean | null
}

export interface PlatformVersion {
  version: string
  gitHash: string
  gitBranch: string
  buildTime: string
}

export interface SystemVersionsResponse {
  platform: PlatformVersion
  services: ServiceVersion[]
}

export const systemVersionsQueryOptions = () =>
  queryOptions({
    queryKey: queryKeys.systemVersions,
    queryFn: () => getApi().get<SystemVersionsResponse>('/system/versions'),
    staleTime: 60_000,
    refetchInterval: 60_000,
  })
```

- [ ] **Step 3: Verify typecheck + lint**

Run: `just ui-lint`
Expected: no new errors. (Vite HMR — no rebuild.)

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/lib/queries/keys.ts src/frontend/src/lib/queries/health.ts
git commit -m "feat(system-info): add systemVersions query options

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 4: Service Versions card + Platform Version row

**Files:**
- Modify: `src/frontend/src/components/features/settings/sections/SystemInfoSection.tsx`

- [ ] **Step 1: Update imports**

Change the React/query imports at the top to add `useQuery`, `Badge`, `Layers`, and the new query. Concretely:

```tsx
import { Suspense } from 'react'
import { useSuspenseQuery, useQuery } from '@tanstack/react-query'
import {
  CheckCircle,
  XCircle,
  MinusCircle,
  Server,
  Shield,
  Globe,
  Info,
  Layers,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Skeleton,
  Badge,
} from '@azblink/ui'
import { healthQueryOptions, systemVersionsQueryOptions } from '@/lib/queries/health'
import type { ServiceVersion } from '@/lib/queries/health'
import {
  FULL_VERSION,
  GIT_HASH,
  GIT_BRANCH,
  formatBuildTime,
} from '@/lib/version'
import { SettingsSection } from '../SettingsSection'
```

- [ ] **Step 2: Add the presentational Service Versions card**

Add this component just above `export function SystemInfoSection()`:

```tsx
/* ------------------------------------------------------------------ */
/*  Service Versions                                                   */
/* ------------------------------------------------------------------ */

const SOURCE_VARIANT: Record<ServiceVersion['source'], 'success' | 'muted' | 'warning'> = {
  live: 'success',
  image: 'muted',
  unknown: 'warning',
}

function ServiceVersionsCard({
  services,
  loading,
}: {
  services: ServiceVersion[] | undefined
  loading: boolean
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Layers className="h-4 w-4" />
          Service Versions
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading || !services ? (
          <StatusSkeleton />
        ) : (
          <dl className="space-y-3">
            {services.map((svc) => (
              <div
                key={svc.name}
                className="border-border flex items-center justify-between border-b py-2 last:border-0"
              >
                <dt className="text-text-secondary text-sm">{svc.name}</dt>
                <dd className="flex items-center gap-2">
                  <span className="text-text font-mono text-sm">
                    {svc.version ?? '—'}
                  </span>
                  <Badge variant={SOURCE_VARIANT[svc.source]}>{svc.source}</Badge>
                  {svc.outdated && svc.latest && (
                    <span className="text-xs text-amber-600 dark:text-amber-400">
                      update → {svc.latest}
                    </span>
                  )}
                </dd>
              </div>
            ))}
          </dl>
        )}
      </CardContent>
    </Card>
  )
}
```

- [ ] **Step 3: Lift the query into `SystemInfoSection` and render the card + Platform row**

At the top of `SystemInfoSection`'s body add the query, render `ServiceVersionsCard` right after the System Status card, and add a Platform Version row as the FIRST row of the Build Information `<dl>`:

```tsx
export function SystemInfoSection() {
  const { data: versions } = useQuery(systemVersionsQueryOptions())

  return (
    <SettingsSection
      sectionId="system-info"
      title="System Info"
      description="Service health, versions, authentication, and build information"
    >
      <div className="space-y-6">
        {/* System Status card … unchanged … */}

        {/* Service Versions — insert immediately AFTER the System Status <Card> */}
        <ServiceVersionsCard services={versions?.services} loading={!versions} />

        {/* … Authentication + API Configuration cards … */}

        {/* Build Information — add Platform Version as the first <dl> row: */}
        {/*
          <div className="border-border flex items-center justify-between border-b py-2">
            <dt className="text-text-secondary text-sm">Platform Version</dt>
            <dd className="text-text font-mono text-sm font-medium">
              {versions?.platform.version ?? '—'}
            </dd>
          </div>
        */}
      </div>
    </SettingsSection>
  )
}
```

Apply the three edits exactly: (a) add the `useQuery` line, (b) insert `<ServiceVersionsCard …/>` after the closing `</Card>` of System Status, (c) insert the Platform Version `<div>` row before the existing "UI Version" row inside the Build Information `<dl>`. Update the section `description` to include "versions".

- [ ] **Step 4: Verify in the browser**

Run: `/browse` (gstack) → log in via Authentik → navigate to `http://localhost:8081/configuration/settings`, System Info section.
Expected: "Service Versions" card lists PostgreSQL `16.14` (live), Redis `8.8.0` (live), Authentik `2026.5.x` (live), OpenLDAP tag (image), Traefik tag (image); Build Information shows a Platform Version row = `0.7.0`. Screenshot for evidence.

- [ ] **Step 5: Lint + commit**

```bash
just ui-lint && just ui-format
git add src/frontend/src/components/features/settings/sections/SystemInfoSection.tsx
git commit -m "feat(system-info): render Service Versions card + Platform Version row

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 5: Polish fixes (stale Authentication card + hardcoded conn strings)

**Files:**
- Modify: `src/frontend/src/components/features/settings/sections/SystemInfoSection.tsx`

- [ ] **Step 1: Fix the stale Authentication card**

The Authentication card currently asserts `OIDC Required: No (UC-only mode)` and `Break-glass Mode: Disabled` — wrong per ARD-002 (Authentik-only OIDC is the sole web-auth path). Replace the three `<dl>` rows with accurate values:

```tsx
            <dl className="space-y-3">
              <div className="border-border flex items-center justify-between border-b py-2 last:border-0">
                <dt className="text-text-secondary text-sm">Web Auth</dt>
                <dd className="text-text text-sm font-medium">
                  Authentik OIDC{' '}
                  <span className="text-icon-muted font-normal">(required)</span>
                </dd>
              </div>
              <div className="border-border flex items-center justify-between border-b py-2 last:border-0">
                <dt className="text-text-secondary text-sm">UC Bind Plane</dt>
                <dd className="text-text text-sm font-medium">
                  LDAP (SIP/XMPP)
                </dd>
              </div>
              <div className="flex items-center justify-between py-2">
                <dt className="text-text-secondary text-sm">Break-glass Mode</dt>
                <dd className="text-text text-sm font-medium">
                  None{' '}
                  <span className="text-icon-muted font-normal">(ARD-002)</span>
                </dd>
              </div>
            </dl>
```

- [ ] **Step 2: Stop asserting hardcoded dev connection strings**

In `SystemStatusWrapper`, the `services` array hardcodes `detail: 'localhost:5433'` / `'localhost:6379'` / `'ldap://openldap:389'` — dev literals that are wrong in any other deploy. Remove the `detail` field from each service object and delete the `<span>{service.detail}</span>` that renders it (keep name + status + error). This turns the row into an honest status indicator instead of asserting a fixed host:port.

- [ ] **Step 3: Verify in the browser**

Run: reload `http://localhost:8081/configuration/settings`.
Expected: Authentication card reads "Web Auth: Authentik OIDC (required)"; System Status rows no longer show hardcoded host:port. Screenshot.

- [ ] **Step 4: Lint + commit**

```bash
just ui-lint && just ui-format
git add src/frontend/src/components/features/settings/sections/SystemInfoSection.tsx
git commit -m "fix(system-info): correct stale auth card + drop hardcoded conn strings

Auth card said 'OIDC Required: No (UC-only)', contradicting ARD-002.
Connection detail strings were dev-only literals wrong in prod.

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 6: Full test run + PR

- [ ] **Step 1: Run the full backend suite**

Run: `just test-quick`
Expected: all pass (including the 4 new `TestSystemVersionsEndpoint` tests). Note any pre-existing SIP e2e env failures as pre-existing (per prior sessions).

- [ ] **Step 2: Push branch + open PR**

```bash
git push -u origin feat/system-info-versions
gh pr create --title "feat: System Information — stack versions" \
  --body "Adds per-service stack versions under the configuration System Info section. Hybrid source (live probes + image-tag fallback). Design: docs/superpowers/specs/2026-07-02-system-information-versions-design.md

🤖 Generated with [Claude Code](https://claude.com/claude-code)"
```

- [ ] **Step 3: Poll CI + CodeRabbit ~10 min after push** (per repo convention), fix valid findings.

---

## Self-Review

**Spec coverage:** hybrid source (T1), live probes PG/Redis/Authentik + tag OpenLDAP/Traefik (T1), image-tag env plumbing (T2), admin gate not public `/api/version` (T1), platform version row (T4), Service Versions card with source badge (T4), Authentik outdated hint (T4), 1 integration test (T1), 2 polish fixes (T5), Spec-Patch trailer (T1). All spec sections mapped.

**Placeholder scan:** every code step shows full code; no TBD/TODO-in-requirements; commit messages concrete.

**Type consistency:** `ServiceVersion`/`PlatformVersion`/`SystemVersionsResponse` (T3) match backend response keys (T1: `name/version/source/note/latest/outdated`, `platform.version/gitHash/gitBranch/buildTime`) and consumer usage (T4). `systemVersionsQueryOptions` / `queryKeys.systemVersions` consistent across T3→T4. `SOURCE_VARIANT` keys = `source` union.
