# QA Pipeline Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a three-layer QA pipeline — YAML manifest, local Claude Code skill, Playwright specs — that catches UI regressions on every PR.

**Architecture:** A `qa/manifest.yml` declares what to test (pages, flows, assertions). A local skill (`/qa-azblink`) orchestrates exploration via gstack and exports to Playwright. Playwright specs (generated or hand-written) run deterministically in local dev and CI. gstack never runs in CI.

**Tech Stack:** Playwright (existing `@playwright/test ^1.48.0`), YAML manifest, Claude Code skill (Markdown), GitHub Actions, Just

**Spec:** `docs/superpowers/specs/2026-03-24-qa-pipeline-design.md`
**Handover:** `docs/superpowers/specs/2026-03-24-qa-pipeline-handover.md`

---

## File Structure

### New files

| File | Responsibility |
|------|---------------|
| `qa/manifest.yml` | Declarative test manifest — pages, flows, redirects, auth config |
| `.claude/skills/qa-azblink/SKILL.md` | Local orchestration skill — explore, export, run, report, promote |
| `src/frontend/e2e/setup/auth.setup.ts` | Playwright auth setup project — SSO login, saves storageState |
| `src/frontend/e2e/fixtures/authenticated-page.ts` | Dev bypass fixture — `Authorization: Bearer` header injection |
| `src/frontend/e2e/generated/.gitkeep` | Placeholder for generated specs directory |
| `.github/workflows/qa.yml` | CI workflow — PR-triggered Playwright smoke suite |

### Modified files

| File | Change |
|------|--------|
| `src/frontend/playwright.config.ts` | Add setup/smoke/full projects, conditional webServer, `BASE_URL` env |
| `src/frontend/e2e/dashboard.spec.ts` | Migrate to `authenticatedPage` fixture (currently has no auth) |
| `src/frontend/e2e/resizable-panel.spec.ts` | Migrate to `authenticatedPage` fixture (currently has no auth) |
| `src/frontend/e2e/pagination.spec.ts` | Migrate to `authenticatedPage` fixture, remove dead "Tokens DataTable" section |
| `src/frontend/e2e/settings-pending-changes.spec.ts` | Migrate to `authenticatedPage` fixture |
| `.gitignore` | Add `qa/.auth/` and `qa/sessions/` |
| `Justfile` | Add `qa-smoke`, `qa-full`, `qa-ui`, `qa-report` commands |

---

## Task 1: Dev Bypass Fixture

The foundation for all test auth. Must exist before migrating existing tests.

**Files:**
- Create: `src/frontend/e2e/fixtures/authenticated-page.ts`

**Context:**
- Backend auth bypass: `Authorization: Bearer <DEV_AUTH_TOKEN>` in `src/backend/main.py` `_claims_from_auth_header()` (line ~225)
- Default token: `dev-test-token` (set via `DEV_AUTH_TOKEN` env var)
- Returns synthetic admin claims: `dev-admin` user, `IT-Admins` group
- The Docker stack's `.env` must have `DEV_AUTH_TOKEN=dev-test-token` for this to work

- [ ] **Step 1: Create the fixture file**

```typescript
/**
 * Authenticated page fixture — injects dev bypass Bearer token.
 * - Uses Authorization: Bearer header (NOT X-Dev-Auth)
 * - Backend returns synthetic admin claims when DEV_AUTH_TOKEN matches
 * - See: src/backend/main.py _claims_from_auth_header()
 */
import { test as base, type Page } from '@playwright/test'

export const test = base.extend<{ authenticatedPage: Page }>({
  authenticatedPage: async ({ page }, use) => {
    await page.setExtraHTTPHeaders({
      Authorization: `Bearer ${process.env.DEV_AUTH_TOKEN || 'dev-test-token'}`,
    })
    await use(page)
  },
})

export { expect } from '@playwright/test'
```

- [ ] **Step 2: Verify fixture compiles**

Run: `cd src/frontend && npx tsc --noEmit e2e/fixtures/authenticated-page.ts 2>&1 || echo "TypeScript check done"`

Note: This may show import errors depending on tsconfig scope — the important thing is that Playwright can import it at runtime. If tsc fails, proceed; Playwright uses its own transform.

- [ ] **Step 3: Commit**

```bash
git add src/frontend/e2e/fixtures/authenticated-page.ts
git commit -m "feat(qa): add authenticated-page dev bypass fixture

Injects Authorization: Bearer header for DEV_AUTH_TOKEN bypass.
Backend returns synthetic admin claims (dev-admin, IT-Admins)."
```

---

## Task 2: Migrate Existing E2E Tests to Dev Bypass

All 4 existing specs are broken — 2 have no auth, 2 use a form-based login that no longer exists. Migrate all to the `authenticatedPage` fixture.

**Files:**
- Modify: `src/frontend/e2e/dashboard.spec.ts` (26 lines, no auth)
- Modify: `src/frontend/e2e/resizable-panel.spec.ts` (144 lines, no auth)
- Modify: `src/frontend/e2e/pagination.spec.ts` (223 lines, form-based login + dead Tokens section)
- Modify: `src/frontend/e2e/settings-pending-changes.spec.ts` (152 lines, form-based login)

**Context:**
- `dashboard.spec.ts`: navigates to `/` without auth — gets redirected to `/login`
- `resizable-panel.spec.ts`: navigates to `/directory/users`, `/directory/groups`, `/directory/orgs` without auth
- `pagination.spec.ts`: uses `login()` helper with `#username`/`#password` selectors (dead form), plus "Tokens DataTable" section tests `/provisioning/tokens` (dead route)
- `settings-pending-changes.spec.ts`: same dead `login()` helper

- [ ] **Step 1: Migrate dashboard.spec.ts**

Replace the import and use `authenticatedPage` instead of `page`:

```typescript
/**
 * E2E tests for the Dashboard page.
 * - Heading visibility, stat cards, navigation, command palette
 */
import { test, expect } from './fixtures/authenticated-page'

test.describe('Dashboard', () => {
  test('should display dashboard heading', async ({ authenticatedPage: page }) => {
    await page.goto('/')
    await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible()
  })

  test('should display stats cards', async ({ authenticatedPage: page }) => {
    await page.goto('/')
    await expect(page.getByText('Users')).toBeVisible()
    await expect(page.getByText('Groups')).toBeVisible()
  })

  test('should navigate to users page', async ({ authenticatedPage: page }) => {
    await page.goto('/')
    await page.click('text=Users')
    await expect(page).toHaveURL(/\/directory\/users/)
  })

  test('should open command palette with keyboard shortcut', async ({ authenticatedPage: page }) => {
    await page.goto('/')
    await page.keyboard.press('Meta+k')
    // Command palette would open - test placeholder for now
  })
})
```

- [ ] **Step 2: Migrate resizable-panel.spec.ts**

Replace import and all `{ page }` destructuring with `{ authenticatedPage: page }`:

```typescript
/**
 * E2E tests for resizable split panels across all management pages.
 * - Verifies drag-to-resize changes panel width
 * - Verifies localStorage persistence across navigation
 * - Verifies double-click resets to default
 * - Verifies keyboard nudge (Arrow Left/Right)
 * - Verifies handle hidden on mobile
 */
import { test, expect } from './fixtures/authenticated-page'

const PAGES = [
  { name: 'Users', url: '/directory/users', storageKey: 'panel-width:user-management' },
  { name: 'Groups', url: '/directory/groups', storageKey: 'panel-width:group-management' },
  { name: 'Orgs', url: '/directory/orgs', storageKey: 'panel-width:org-management' },
] as const

for (const { name, url, storageKey } of PAGES) {
  test.describe(`${name} page — resizable panel`, () => {
    test.beforeEach(async ({ authenticatedPage: page }) => {
      await page.goto(url)
      await page.evaluate((key) => localStorage.removeItem(key), storageKey)
      await page.reload()
      await page.waitForSelector('[role="separator"]', { timeout: 10000 })
    })

    test('resize handle is visible on desktop viewport', async ({ authenticatedPage: page }) => {
      await page.setViewportSize({ width: 1280, height: 800 })
      await page.goto(url)
      const handle = page.getByRole('separator', { name: 'Resize panels' })
      await expect(handle).toBeVisible()
    })

    test('resize handle is hidden on mobile viewport', async ({ authenticatedPage: page }) => {
      await page.setViewportSize({ width: 375, height: 812 })
      await page.goto(url)
      const handle = page.getByRole('separator', { name: 'Resize panels' })
      await expect(handle).toBeHidden()
    })

    test('drag to resize changes left panel width', async ({ authenticatedPage: page }) => {
      await page.setViewportSize({ width: 1280, height: 800 })
      await page.goto(url)
      const handle = page.getByRole('separator', { name: 'Resize panels' })
      const container = handle.locator('..')
      const leftPanel = container.locator('> div').first()
      const initialWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width)

      const handleBox = await handle.boundingBox()
      if (!handleBox) throw new Error('Handle not found')
      await page.mouse.move(handleBox.x + handleBox.width / 2, handleBox.y + handleBox.height / 2)
      await page.mouse.down()
      await page.mouse.move(handleBox.x + 100, handleBox.y + handleBox.height / 2, { steps: 5 })
      await page.mouse.up()

      const newWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width)
      expect(newWidth).toBeGreaterThan(initialWidth + 50)
    })

    test('width persists in localStorage after drag', async ({ authenticatedPage: page }) => {
      await page.setViewportSize({ width: 1280, height: 800 })
      await page.goto(url)
      const handle = page.getByRole('separator', { name: 'Resize panels' })

      const handleBox = await handle.boundingBox()
      if (!handleBox) throw new Error('Handle not found')
      await page.mouse.move(handleBox.x + handleBox.width / 2, handleBox.y + handleBox.height / 2)
      await page.mouse.down()
      await page.mouse.move(handleBox.x + 80, handleBox.y + handleBox.height / 2, { steps: 5 })
      await page.mouse.up()

      const stored = await page.evaluate((key) => localStorage.getItem(key), storageKey)
      expect(stored).not.toBeNull()
      expect(Number(stored)).toBeGreaterThan(0)

      await page.reload()
      await page.waitForSelector('[role="separator"]')
      const storedAfterReload = await page.evaluate((key) => localStorage.getItem(key), storageKey)
      expect(storedAfterReload).toBe(stored)
    })

    test('double-click resets to default width', async ({ authenticatedPage: page }) => {
      await page.setViewportSize({ width: 1280, height: 800 })
      await page.goto(url)
      const handle = page.getByRole('separator', { name: 'Resize panels' })
      const container = handle.locator('..')
      const leftPanel = container.locator('> div').first()
      const defaultWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width)

      const handleBox = await handle.boundingBox()
      if (!handleBox) throw new Error('Handle not found')
      await page.mouse.move(handleBox.x + handleBox.width / 2, handleBox.y + handleBox.height / 2)
      await page.mouse.down()
      await page.mouse.move(handleBox.x + 150, handleBox.y + handleBox.height / 2, { steps: 5 })
      await page.mouse.up()

      const draggedWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width)
      expect(draggedWidth).not.toBeCloseTo(defaultWidth, -1)

      await handle.dblclick()

      const resetWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width)
      expect(Math.abs(resetWidth - defaultWidth)).toBeLessThan(5)
    })

    test('keyboard Arrow Left/Right nudges panel width', async ({ authenticatedPage: page }) => {
      await page.setViewportSize({ width: 1280, height: 800 })
      await page.goto(url)
      const handle = page.getByRole('separator', { name: 'Resize panels' })
      const container = handle.locator('..')
      const leftPanel = container.locator('> div').first()

      await handle.focus()
      const initialWidth = await leftPanel.evaluate((el) => el.getBoundingClientRect().width)

      await handle.press('ArrowRight')
      const afterRight = await leftPanel.evaluate((el) => el.getBoundingClientRect().width)
      expect(Math.abs(afterRight - initialWidth - 20)).toBeLessThan(5)

      await handle.press('ArrowLeft')
      const afterLeft = await leftPanel.evaluate((el) => el.getBoundingClientRect().width)
      expect(Math.abs(afterLeft - initialWidth)).toBeLessThan(5)
    })
  })
}
```

- [ ] **Step 3: Migrate pagination.spec.ts**

Replace import, use `authenticatedPage`, remove dead `login()` helper, and **remove the entire "Tokens DataTable" section** (lines 145-223) — it tests `/provisioning/tokens` which no longer exists.

```typescript
/**
 * E2E tests for pagination controls.
 * - User management: compact pagination in split-panel
 * - Group management: compact pagination in split-panel
 */
import { test, expect } from './fixtures/authenticated-page'

test.describe('User Management Pagination', () => {
  test.beforeEach(async ({ authenticatedPage: page }) => {
    await page.goto('/directory/users')
    await page.waitForLoadState('networkidle')
  })

  test('shows pagination controls when users exist', async ({ authenticatedPage: page }) => {
    const nav = page.locator('nav[aria-label="Pagination"]')
    const navCount = await nav.count()
    if (navCount > 0) {
      await expect(nav.first()).toBeVisible()
      await expect(nav.first()).toContainText(/Page \d+ of \d+/)
    } else {
      expect(navCount).toBe(0)
    }
  })

  test('page size selector is present and functional', async ({ authenticatedPage: page }) => {
    const nav = page.locator('nav[aria-label="Pagination"]')
    const navCount = await nav.count()
    if (navCount === 0) {
      test.skip(true, 'No users in system — pagination not rendered')
      return
    }
    const select = nav.first().locator('select[aria-label="Items per page"]')
    await expect(select).toBeVisible()
    const options = select.locator('option')
    const optionCount = await options.count()
    expect(optionCount).toBeGreaterThanOrEqual(2)
  })

  test('page size change updates URL search params', async ({ authenticatedPage: page }) => {
    const nav = page.locator('nav[aria-label="Pagination"]')
    const navCount = await nav.count()
    if (navCount === 0) {
      test.skip(true, 'No users in system — pagination not rendered')
      return
    }
    const select = nav.first().locator('select[aria-label="Items per page"]')
    await select.selectOption('25')
    await page.waitForTimeout(500)
    await expect(page).toHaveURL(/pageSize=25/)
  })

  test('next/prev buttons navigate pages', async ({ authenticatedPage: page }) => {
    await page.goto('/directory/users?pageSize=1')
    await page.waitForLoadState('networkidle')

    const nav = page.locator('nav[aria-label="Pagination"]')
    const navCount = await nav.count()
    if (navCount === 0) {
      test.skip(true, 'No users in system — pagination not rendered')
      return
    }

    const nextBtn = nav.first().locator('button[aria-label="Next page"]')
    const prevBtn = nav.first().locator('button[aria-label="Previous page"]')

    await expect(prevBtn).toBeDisabled()

    if (await nextBtn.isEnabled()) {
      await nextBtn.click()
      await page.waitForTimeout(500)
      await expect(page).toHaveURL(/page=1/)
      await expect(prevBtn).toBeEnabled()
    }
  })
})

test.describe('Group Management Pagination', () => {
  test.beforeEach(async ({ authenticatedPage: page }) => {
    await page.goto('/directory/groups')
    await page.waitForLoadState('networkidle')
  })

  test('shows pagination controls when groups exist', async ({ authenticatedPage: page }) => {
    const nav = page.locator('nav[aria-label="Pagination"]')
    const navCount = await nav.count()
    if (navCount > 0) {
      await expect(nav.first()).toBeVisible()
      await expect(nav.first()).toContainText(/Page \d+ of \d+/)
    } else {
      expect(navCount).toBe(0)
    }
  })

  test('page size selector has expected options', async ({ authenticatedPage: page }) => {
    const nav = page.locator('nav[aria-label="Pagination"]')
    const navCount = await nav.count()
    if (navCount === 0) {
      test.skip(true, 'No groups in system — pagination not rendered')
      return
    }
    const select = nav.first().locator('select[aria-label="Items per page"]')
    await expect(select).toBeVisible()
    const options = select.locator('option')
    const texts = await options.allTextContents()
    expect(texts).toContain('10 / page')
    expect(texts).toContain('25 / page')
    expect(texts).toContain('50 / page')
  })
})
```

- [ ] **Step 4: Migrate settings-pending-changes.spec.ts**

Replace import, use `authenticatedPage`, remove dead `login()` helper:

```typescript
/**
 * E2E tests for the Settings pending changes feature.
 * - Bottom save bar visibility and interaction
 * - Pending changes drawer open/close, per-item revert
 * - Save and discard flows
 */
import { test, expect } from './fixtures/authenticated-page'

test.describe('Settings Pending Changes', () => {
  test.beforeEach(async ({ authenticatedPage: page }) => {
    await page.goto('/configuration/settings')
    await expect(page.getByTestId('settings-section-system-info')).toBeVisible({ timeout: 15000 })
  })

  test('bottom save bar is hidden when no changes exist', async ({ authenticatedPage: page }) => {
    await expect(page.getByTestId('settings-bottom-save-bar')).not.toBeVisible()
  })

  test('bottom save bar appears when a field is changed', async ({ authenticatedPage: page }) => {
    const input = page.locator('#ldap-server-url')
    await input.clear()
    await input.fill('ldap://changed:389')
    await expect(page.getByTestId('settings-bottom-save-bar')).toBeVisible()
    await expect(page.getByTestId('settings-bottom-bar-view-changes')).toContainText('1')
  })

  test('clicking "unsaved changes" opens the drawer', async ({ authenticatedPage: page }) => {
    const input = page.locator('#ldap-server-url')
    await input.clear()
    await input.fill('ldap://changed:389')
    await page.getByTestId('settings-bottom-bar-view-changes').click()
    await expect(page.getByTestId('settings-pending-changes-drawer')).toBeVisible()
    await expect(page.getByTestId('settings-change-card-ldap.serverUrl')).toBeVisible()
  })

  test('per-item revert restores field value', async ({ authenticatedPage: page }) => {
    const input = page.locator('#ldap-server-url')
    const originalValue = await input.inputValue()
    await input.clear()
    await input.fill('ldap://changed:389')
    await page.getByTestId('settings-bottom-bar-view-changes').click()
    await page.getByTestId('settings-revert-ldap.serverUrl').click()
    await expect(input).toHaveValue(originalValue)
    await expect(page.getByTestId('settings-pending-changes-drawer')).not.toBeVisible()
    await expect(page.getByTestId('settings-bottom-save-bar')).not.toBeVisible()
  })

  test('discard all reverts all changes', async ({ authenticatedPage: page }) => {
    const ldapInput = page.locator('#ldap-server-url')
    const originalLdap = await ldapInput.inputValue()
    await ldapInput.clear()
    await ldapInput.fill('ldap://changed:389')
    await page.getByTestId('settings-bottom-bar-view-changes').click()
    await page.getByTestId('settings-drawer-discard-all').click()
    await expect(ldapInput).toHaveValue(originalLdap)
    await expect(page.getByTestId('settings-pending-changes-drawer')).not.toBeVisible()
    await expect(page.getByTestId('settings-bottom-save-bar')).not.toBeVisible()
  })

  test('drawer closes on Escape key', async ({ authenticatedPage: page }) => {
    const input = page.locator('#ldap-server-url')
    await input.clear()
    await input.fill('ldap://changed:389')
    await page.getByTestId('settings-bottom-bar-view-changes').click()
    await expect(page.getByTestId('settings-pending-changes-drawer')).toBeVisible()
    await page.keyboard.press('Escape')
    await expect(page.getByTestId('settings-pending-changes-drawer')).not.toBeVisible()
    await expect(page.getByTestId('settings-bottom-save-bar')).toBeVisible()
  })

  test('drawer closes on backdrop click', async ({ authenticatedPage: page }) => {
    const input = page.locator('#ldap-server-url')
    await input.clear()
    await input.fill('ldap://changed:389')
    await page.getByTestId('settings-bottom-bar-view-changes').click()
    await expect(page.getByTestId('settings-pending-changes-drawer')).toBeVisible()
    await page.getByTestId('settings-drawer-backdrop').click()
    await expect(page.getByTestId('settings-pending-changes-drawer')).not.toBeVisible()
    await expect(page.getByTestId('settings-bottom-save-bar')).toBeVisible()
  })

  test('editing field back to original removes it from pending changes', async ({ authenticatedPage: page }) => {
    const input = page.locator('#ldap-server-url')
    const originalValue = await input.inputValue()
    await input.clear()
    await input.fill('ldap://changed:389')
    await expect(page.getByTestId('settings-bottom-save-bar')).toBeVisible()
    await input.clear()
    await input.fill(originalValue)
    await expect(page.getByTestId('settings-bottom-save-bar')).not.toBeVisible()
  })
})
```

- [ ] **Step 5: Run all migrated tests against Docker stack**

Run: `cd src/frontend && BASE_URL=http://localhost:8081 npx playwright test --reporter=list 2>&1 | head -60`

Expected: Tests that hit authenticated pages should now pass (dev bypass token injected). Tests that depend on specific data (pagination, groups) may skip gracefully.

**Prerequisites:**
- Docker stack running: `just up-bg && just wait-healthy`
- `DEV_AUTH_TOKEN=dev-test-token` must be set in `deploy/dev/.env` — verify with: `grep DEV_AUTH_TOKEN deploy/dev/.env`
- If missing, add it: `echo 'DEV_AUTH_TOKEN=dev-test-token' >> deploy/dev/.env && just restart`

- [ ] **Step 6: Commit**

```bash
git add src/frontend/e2e/dashboard.spec.ts src/frontend/e2e/resizable-panel.spec.ts src/frontend/e2e/pagination.spec.ts src/frontend/e2e/settings-pending-changes.spec.ts
git commit -m "fix(e2e): migrate all specs to dev bypass fixture

All 4 existing specs were broken:
- dashboard + resizable-panel: no auth, redirected to login
- pagination + settings: used form-based login that no longer exists
- pagination: removed dead Tokens DataTable section (/provisioning/tokens is gone)

Now use authenticatedPage fixture with Authorization: Bearer header."
```

---

## Task 3: Update Playwright Config

Add setup/smoke/full projects, conditional webServer, and `BASE_URL` env var.

**Files:**
- Modify: `src/frontend/playwright.config.ts`

- [ ] **Step 1: Rewrite playwright.config.ts**

```typescript
/**
 * Playwright config — supports two environments:
 * - Docker stack (default): BASE_URL=http://localhost:8081, no webServer
 * - Vite dev server: USE_DEV_SERVER=true, starts npm run dev on :3000
 */
import { defineConfig, devices } from '@playwright/test'

const baseURL = process.env.BASE_URL || 'http://localhost:8081'
const useDevServer = process.env.USE_DEV_SERVER === 'true'

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL,
    trace: 'on-first-retry',
  },

  projects: [
    {
      name: 'setup',
      testMatch: /auth\.setup\.ts/,
    },
    {
      name: 'smoke',
      testMatch: /generated\/.*\.spec\.ts/,
      use: {
        ...devices['Desktop Chrome'],
      },
    },
    {
      name: 'full',
      testIgnore: /auth\.setup\.ts/,
      use: {
        ...devices['Desktop Chrome'],
      },
    },
    // SSO suite — tests needing real Authentik auth (depends on setup project)
    {
      name: 'sso',
      testMatch: /sso\/.*\.spec\.ts/,
      dependencies: ['setup'],
      use: {
        ...devices['Desktop Chrome'],
        storageState: '../../qa/.auth/sso-state.json',
      },
    },
  ],

  ...(useDevServer
    ? {
        webServer: {
          command: 'npm run dev',
          url: 'http://localhost:3000',
          reuseExistingServer: !process.env.CI,
        },
      }
    : {}),
})
```

- [ ] **Step 2: Verify config loads**

Run: `cd src/frontend && npx playwright test --list 2>&1 | head -20`

Expected: Lists available tests without errors. May show "no tests matched" for smoke project (no generated specs yet) — that's fine.

- [ ] **Step 3: Run existing tests with new config**

Run: `cd src/frontend && npx playwright test --project=full --reporter=list 2>&1 | head -60`

Expected: Existing tests run under the "full" project. Same results as Task 2 Step 5.

**Note:** The `smoke` and `full` projects do NOT depend on `setup` or use `storageState` — they rely on the `authenticatedPage` dev bypass fixture. A separate `sso` project (for future SSO-specific tests) depends on `setup` and uses `storageState` at `../../qa/.auth/sso-state.json` (relative to `src/frontend/`).

- [ ] **Step 4: Commit**

```bash
git add src/frontend/playwright.config.ts
git commit -m "feat(qa): update playwright config with setup/smoke/full projects

- BASE_URL defaults to Docker stack (:8081) instead of Vite dev (:3000)
- Conditional webServer (opt-in via USE_DEV_SERVER=true)
- Three projects: setup (auth), smoke (generated), full (all)"
```

---

## Task 4: QA Manifest

The declarative source of truth for what to test.

**Files:**
- Create: `qa/manifest.yml`

- [ ] **Step 1: Create qa directory**

Run: `mkdir -p qa/sessions qa/.auth`

- [ ] **Step 2: Create manifest.yml**

Copy the manifest from the design spec (`docs/superpowers/specs/2026-03-24-qa-pipeline-design.md`, lines 87-242). The corrected version has:
- `auth.devBypass.header: "Authorization"` + `scheme: "Bearer"`
- `users-list.title: "User Management"`
- `orgs-list.title: "Organization Management"`

```yaml
version: "1.0"
app:
  name: "AZBlink Directory"
  baseUrl: "http://localhost:8081"

auth:
  devBypass:
    token: "dev-test-token"
    header: "Authorization"
    scheme: "Bearer"
  sso:
    provider: "authentik"
    loginUrl: "https://authentik.keithmoc.dev"
    credentials:
      username: "${QA_SSO_USER}"
      password: "${QA_SSO_PASSWORD}"
    storageStatePath: "qa/.auth/sso-state.json"

pages:
  - id: dashboard
    path: /
    title: "Dashboard"
    requiresAuth: true
    assertions:
      - visible: "Dashboard"
      - type: elementCount
        selector: "[aria-live='polite']"
        operator: ">="
        count: 3
      - type: noConsoleErrors

  - id: users-list
    path: /directory/users
    title: "User Management"
    requiresAuth: true
    assertions:
      - visible: "User Management"
      - interactive: ["search", "pagination", "add-user"]

  - id: groups-list
    path: /directory/groups
    title: "Groups"
    requiresAuth: true
    assertions:
      - visible: "Groups"

  - id: orgs-list
    path: /directory/orgs
    title: "Organization Management"
    requiresAuth: true
    assertions:
      - visible: "Organization Management"

  - id: device-management
    path: /provisioning/devices
    title: "Device Management"
    requiresAuth: true
    assertions:
      - visible: "Device Management"

  - id: audit-log
    path: /audit-log
    title: "Audit Log"
    requiresAuth: true
    assertions:
      - visible: "Audit Log"

  - id: org-profiles
    path: /configuration/org-profiles
    title: "Org Profiles"
    requiresAuth: true
    assertions:
      - visible: "Org Profiles"

  - id: settings
    path: /configuration/settings
    title: "Settings"
    requiresAuth: true
    assertions:
      - visible: "Settings"

  - id: my-profile
    path: /my-profile
    title: "My Profile"
    requiresAuth: true
    assertions:
      - visible: "My Profile"

  - id: login
    path: /login
    title: "Login"
    requiresAuth: false
    assertions:
      - visible: "Sign in with Authentik"

  - id: auth-callback
    path: /auth/callback
    title: "Auth Callback"
    requiresAuth: false
    assertions:
      - note: "Handles OIDC code exchange — tested implicitly via sso-login flow"

  - id: user-onboarding
    path: /directory/users/onboard
    title: "User Onboarding"
    requiresAuth: true
    assertions:
      - visible: "Onboard"

redirects:
  - from: /settings
    to: /configuration/settings
  - from: /directory/users/{uid}
    to: /directory/users?userId={uid}
  - from: /directory/groups/{cn}
    to: /directory/groups?groupId={cn}
  - from: /directory/orgs/{dn}
    to: /directory/orgs?orgId={dn}

flows:
  - id: sso-login
    description: "Complete SSO login flow"
    steps:
      - goto: /login
      - click: "Sign in with Authentik"
      - fill: { selector: "Email or Username", value: "${QA_SSO_USER}" }
      - click: "Log in"
      - fill: { selector: "password", value: "${QA_SSO_PASSWORD}" }
      - click: "Continue"
      - assert: { url: "/", visible: "Dashboard" }

  - id: user-search
    description: "Search for a user"
    requiresAuth: true
    steps:
      - goto: /directory/users
      - fill: { selector: "search", value: "jsmith" }
      - assert: { visible: "jsmith" }

  - id: navigation-sidebar
    description: "Navigate through all sidebar links"
    requiresAuth: true
    steps:
      - goto: /
      - click: "Users"
      - assert: { url: "/directory/users" }
      - click: "Groups"
      - assert: { url: "/directory/groups" }
      - click: "Organizations"
      - assert: { url: "/directory/orgs" }
      - click: "Device Management"
      - assert: { url: "/provisioning/devices" }
      - click: "Audit Log"
      - assert: { url: "/audit-log" }
```

- [ ] **Step 3: Create generated specs placeholder**

Run: `mkdir -p src/frontend/e2e/generated && touch src/frontend/e2e/generated/.gitkeep`

- [ ] **Step 4: Commit**

```bash
git add qa/manifest.yml src/frontend/e2e/generated/.gitkeep
git commit -m "feat(qa): add test manifest and generated specs directory

Declarative manifest defines 12 pages, 4 redirects, 3 flows.
Generated specs directory ready for explore/export output."
```

---

## Task 5: Auth Setup Project (SSO)

Playwright auth setup for real SSO login — runs once before all test projects.

**Files:**
- Create: `src/frontend/e2e/setup/auth.setup.ts`

- [ ] **Step 1: Create the auth setup file**

```typescript
/**
 * Playwright auth setup project — authenticates via Authentik SSO.
 * - Runs once before all other test projects
 * - Saves cookies/tokens to qa/.auth/sso-state.json
 * - Requires QA_SSO_USER and QA_SSO_PASSWORD env vars
 * - Steps match Authentik's 2-step password flow (update if flow config changes)
 */
import { test as setup, expect } from '@playwright/test'

setup('authenticate via SSO', async ({ page }) => {
  const user = process.env.QA_SSO_USER
  const pass = process.env.QA_SSO_PASSWORD

  if (!user || !pass) {
    console.log('QA_SSO_USER/QA_SSO_PASSWORD not set — skipping SSO auth setup')
    return
  }

  await page.goto('/login')
  await page.getByRole('button', { name: 'Sign in with Authentik' }).click()

  // Authentik step 1: username
  await page.getByRole('textbox', { name: 'Email or Username' }).fill(user)
  await page.getByRole('button', { name: 'Log in' }).click()

  // Authentik step 2: password
  await page.getByRole('textbox', { name: /password/i }).fill(pass)
  await page.getByRole('button', { name: 'Continue' }).click()

  // Verify we landed on the dashboard
  await expect(page).toHaveURL('/')
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible()

  // Save auth state
  await page.context().storageState({ path: 'qa/.auth/sso-state.json' })
})
```

- [ ] **Step 2: Verify file compiles**

Run: `cd src/frontend && npx playwright test --list --project=setup 2>&1 | head -10`

Expected: Lists the "authenticate via SSO" test.

- [ ] **Step 3: Commit**

```bash
git add src/frontend/e2e/setup/auth.setup.ts
git commit -m "feat(qa): add SSO auth setup project

Playwright setup project authenticates via Authentik 2-step flow.
Saves storageState to qa/.auth/sso-state.json for downstream projects."
```

---

## Task 6: Gitignore + Justfile

Add QA pipeline entries to `.gitignore` and `Justfile`.

**Files:**
- Modify: `.gitignore` (line 11, append)
- Modify: `Justfile` (after line 300, append)

- [ ] **Step 1: Update .gitignore**

Append to `.gitignore`:

```
# QA pipeline
qa/.auth/
qa/sessions/
playwright-report/
test-results/
```

- [ ] **Step 2: Add Justfile commands**

Append after line 300 (`test-all: test`):

```just

# QA Pipeline
# =============================================================================

# Run Playwright smoke tests (< 2 min, requires Docker stack running)
qa-smoke:
    cd src/frontend && npx playwright test --project=smoke

# Run full Playwright suite (all generated + hand-written specs)
qa-full:
    cd src/frontend && npx playwright test --project=full

# Run Playwright tests with UI mode for debugging
qa-ui:
    cd src/frontend && npx playwright test --ui

# Show QA coverage report (manifest pages/flows vs existing specs)
qa-report:
    @echo "QA Coverage Report"
    @echo "==================="
    @echo "Manifest pages: $$(grep -c '  - id:' qa/manifest.yml 2>/dev/null || echo 0)"
    @echo "Generated specs: $$(ls src/frontend/e2e/generated/*.spec.ts 2>/dev/null | wc -l || echo 0)"
    @echo "Hand-written specs: $$(ls src/frontend/e2e/*.spec.ts 2>/dev/null | wc -l || echo 0)"
```

- [ ] **Step 3: Verify Justfile commands**

Run: `just --list | grep qa`

Expected: Shows `qa-smoke`, `qa-full`, `qa-ui`, `qa-report`.

- [ ] **Step 4: Run qa-report**

Run: `just qa-report`

Expected: Shows manifest page count (12), generated specs (0), hand-written specs (4).

- [ ] **Step 5: Commit**

```bash
git add .gitignore Justfile
git commit -m "feat(qa): add gitignore entries and Justfile QA commands

- .gitignore: qa/.auth/, qa/sessions/, playwright-report/, test-results/
- Justfile: qa-smoke, qa-full, qa-ui, qa-report"
```

---

## Task 7: Local Skill — /qa-azblink

The orchestration skill for explore, export, run, report, promote.

**Files:**
- Create: `.claude/skills/qa-azblink/SKILL.md`

**Context:**
- This is a Claude Code skill (Markdown file that gets loaded when user types `/qa-azblink`)
- It reads `qa/manifest.yml` and orchestrates gstack `/browse` sessions
- The skill itself is long — it defines 5 subcommands
- Reference: `docs/superpowers/specs/2026-03-24-qa-pipeline-design.md` §Local Skill and §Session Log Schema

- [ ] **Step 1: Create the skill file**

```markdown
---
name: qa-azblink
description: QA pipeline orchestrator — explore with gstack, export to Playwright, run tests, report coverage, promote specs
---

# /qa-azblink

QA pipeline orchestrator for AZBlink Directory. Reads `qa/manifest.yml` and orchestrates testing workflows.

## Subcommands

### /qa-azblink explore [page-id|flow-id|all]

Launches gstack `/browse` against manifest targets for exploratory testing.

**Process:**
1. Read `qa/manifest.yml`
2. For each target:
   - Navigate to the page URL (with auth if `requiresAuth: true`)
   - Run manifest assertions (visible text, element counts, console errors)
   - Capture annotated snapshots via `/browse snapshot -i`
   - For flows: execute step sequences, capture diffs at each step
3. Save session log to `qa/sessions/YYYY-MM-DD-<id>.json`

**Session log format:** See spec §Session Log Schema. Key: capture `element.role` + `element.name` at each interaction for export mapping.

**Flags:**
- `--dry-run`: Show what would be explored without launching gstack
- `--timeout <seconds>`: Per-page timeout (default: 300s)

**Example:**
```
/qa-azblink explore dashboard
/qa-azblink explore sso-login
/qa-azblink explore all --dry-run
```

### /qa-azblink export [session-file|latest]

Converts a gstack session log to Playwright `.spec.ts` files.

**Command mapping:**

| gstack browse | Playwright |
|---|---|
| `goto <url>` | `await page.goto('<url>')` |
| `click @eN [button "X"]` | `await page.getByRole('button', { name: 'X' }).click()` |
| `fill @eN [textbox "X"]` | `await page.getByRole('textbox', { name: 'X' }).fill('value')` |
| `is visible ".sel"` | `await expect(page.locator('.sel')).toBeVisible()` |
| `text (contains "X")` | `await expect(page).toContainText('X')` |
| `console --errors` | `page.on('console', ...)` listener |

**Rules:**
- Use `getByRole`/`getByText` over CSS selectors (resilient to DOM changes)
- Map from `element.role` + `element.name` in session log, NOT @e ref numbers
- Write to `src/frontend/e2e/generated/`
- Include `// Source: qa/sessions/<file>.json` header in each generated spec

**Example:**
```
/qa-azblink export latest
/qa-azblink export qa/sessions/2026-03-24-dashboard.json
```

### /qa-azblink run [smoke|full|flow-id]

Wraps `npx playwright test` with appropriate config.

- `smoke`: `npx playwright test --project=smoke` (generated specs only, < 2 min)
- `full`: `npx playwright test --project=full` (all specs)
- `<flow-id>`: `npx playwright test -g "<flow-id>"` (specific flow)

Handles auth setup automatically. Requires Docker stack running (`just health-check` first).

### /qa-azblink report

Cross-references `qa/manifest.yml` against existing spec files.

**Output:**
- Pages tested / total (with list of uncovered pages)
- Flows tested / total (with list of uncovered flows)
- Generated specs with no promoted counterpart
- Promoted specs that reference pages no longer in manifest
- Overall coverage percentage

### /qa-azblink promote [generated-spec]

Moves a generated spec from `e2e/generated/` to `e2e/`.

- If target exists, prompts for confirmation before overwriting
- Promoted tests are "owned" — hand-editable, not overwritten by future exports
- After promoting, run the test to verify: `npx playwright test e2e/<name>.spec.ts`

## Auth

Two strategies available:
1. **Dev bypass** (default for most tests): `authenticatedPage` fixture injects `Authorization: Bearer dev-test-token`
2. **SSO** (for login flow tests): Playwright auth setup project via `e2e/setup/auth.setup.ts`

## Environment

| Variable | Default | Purpose |
|---|---|---|
| `BASE_URL` | `http://localhost:8081` | App URL (Docker stack) |
| `USE_DEV_SERVER` | unset | Set `true` for Vite dev server on :3000 |
| `DEV_AUTH_TOKEN` | `dev-test-token` | Dev bypass bearer token |
| `QA_SSO_USER` | unset | Authentik SSO username |
| `QA_SSO_PASSWORD` | unset | Authentik SSO password |
```

- [ ] **Step 2: Verify skill is discoverable**

Run: `ls -la .claude/skills/qa-azblink/SKILL.md`

- [ ] **Step 3: Commit**

```bash
git add .claude/skills/qa-azblink/SKILL.md
git commit -m "feat(qa): add /qa-azblink orchestration skill

Local Claude Code skill with 5 subcommands:
explore (gstack), export (to Playwright), run, report, promote."
```

---

## Task 8: CI Workflow

GitHub Actions workflow for PR-triggered Playwright smoke suite.

**Files:**
- Create: `.github/workflows/qa.yml`

**Context:**
- Existing: `.github/workflows/release.yml` (tag-triggered release only)
- The stack needs `just up-bg && just wait-healthy` (NOT `just up` which runs in foreground)
- CI needs `DEV_AUTH_TOKEN=dev-test-token` in the environment for dev bypass tests
- SSO auth setup requires `QA_SSO_USER`/`QA_SSO_PASSWORD` secrets (optional — setup skips gracefully if unset)

- [ ] **Step 1: Create the workflow file**

```yaml
name: QA

on:
  pull_request:
    branches: [main]

jobs:
  playwright:
    runs-on: ubuntu-latest
    timeout-minutes: 15

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 22

      - name: Install just
        uses: extractions/setup-just@v2

      - name: Install frontend dependencies
        run: npm ci
        working-directory: src/frontend

      - name: Install Playwright browsers
        run: npx playwright install --with-deps chromium
        working-directory: src/frontend

      - name: Start Docker stack
        run: |
          cd deploy/dev
          cp .env.example .env
          docker compose up -d --wait
          cd ../..
          just wait-healthy

      - name: Run Playwright full suite
        run: npx playwright test --project=full --reporter=list
        working-directory: src/frontend
        env:
          BASE_URL: http://localhost:8081
          DEV_AUTH_TOKEN: dev-test-token
          QA_SSO_USER: ${{ secrets.QA_SSO_USER }}
          QA_SSO_PASSWORD: ${{ secrets.QA_SSO_PASSWORD }}

      - name: Upload test report
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: playwright-report
          path: src/frontend/playwright-report/
          retention-days: 14
```

- [ ] **Step 2: Validate YAML syntax**

Run: `python3 -c "import yaml; yaml.safe_load(open('.github/workflows/qa.yml'))" && echo "Valid YAML"`

- [ ] **Step 3: Commit**

```bash
git add .github/workflows/qa.yml
git commit -m "ci: add QA workflow with Playwright on PR

Runs full Playwright suite against Docker stack on every PR to main.
Uses dev bypass auth + optional SSO auth setup.
Uploads HTML report as artifact."
```

---

## Task 9: Smoke Test Generation

Generate page-load smoke tests for all manifest pages. This is the first use of the explore/export pipeline — but since gstack is interactive and token-intensive, we write these directly as a baseline.

**Files:**
- Create: `src/frontend/e2e/generated/page-smoke.spec.ts`

- [ ] **Step 1: Write smoke test for all pages**

```typescript
/**
 * Smoke tests — verify every manifest page loads and displays expected content.
 * Source: qa/manifest.yml
 * Generated baseline — will be replaced by /qa-azblink explore output
 */
import { test, expect } from '../fixtures/authenticated-page'

const PAGES = [
  { id: 'dashboard', path: '/', title: 'Dashboard', visible: 'Dashboard' },
  { id: 'users-list', path: '/directory/users', title: 'User Management', visible: 'User Management' },
  { id: 'groups-list', path: '/directory/groups', title: 'Groups', visible: 'Groups' },
  { id: 'orgs-list', path: '/directory/orgs', title: 'Organization Management', visible: 'Organization Management' },
  { id: 'device-management', path: '/provisioning/devices', title: 'Device Management', visible: 'Device Management' },
  { id: 'audit-log', path: '/audit-log', title: 'Audit Log', visible: 'Audit Log' },
  { id: 'org-profiles', path: '/configuration/org-profiles', title: 'Org Profiles', visible: 'Org Profiles' },
  { id: 'settings', path: '/configuration/settings', title: 'Settings', visible: 'Settings' },
  { id: 'my-profile', path: '/my-profile', title: 'My Profile', visible: 'My Profile' },
  { id: 'user-onboarding', path: '/directory/users/onboard', title: 'User Onboarding', visible: 'Onboard' },
] as const

for (const { id, path, visible } of PAGES) {
  test(`${id}: page loads and shows "${visible}"`, async ({ authenticatedPage: page }) => {
    await page.goto(path)
    await expect(page.getByText(visible, { exact: false })).toBeVisible({ timeout: 10000 })
  })
}

test('login: page loads without auth', async ({ page }) => {
  await page.goto('/login')
  await expect(page.getByRole('button', { name: 'Sign in with Authentik' })).toBeVisible()
})

test('dashboard: has at least 3 stat cards', async ({ authenticatedPage: page }) => {
  await page.goto('/')
  // StatCard renders value with aria-live="polite" — use that as anchor
  const statValues = page.locator('[aria-live="polite"]')
  await expect(statValues.first()).toBeVisible({ timeout: 10000 })
  const count = await statValues.count()
  expect(count).toBeGreaterThanOrEqual(3)
})

test('dashboard: no console errors', async ({ authenticatedPage: page }) => {
  const errors: string[] = []
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(msg.text())
  })
  await page.goto('/')
  await page.waitForLoadState('networkidle')
  expect(errors).toEqual([])
})
```

- [ ] **Step 2: Run smoke tests**

Run: `cd src/frontend && npx playwright test --project=smoke --reporter=list 2>&1 | head -40`

Expected: All page-load tests pass. Console error test may reveal issues — investigate and fix if so.

**Troubleshooting:**
- If tests fail with auth redirect, verify `DEV_AUTH_TOKEN=dev-test-token` is in `deploy/dev/.env` and the stack was restarted after adding it.
- The smoke project does NOT depend on the setup project or storageState — it uses the dev bypass fixture exclusively.

- [ ] **Step 3: Commit**

```bash
git add src/frontend/e2e/generated/page-smoke.spec.ts
git commit -m "feat(qa): add page-load smoke tests for all manifest pages

Tests all 12 pages from manifest load correctly with auth.
Includes stat card count and console error checks for dashboard."
```

---

## Task 10: Navigation + Redirect Tests

Test sidebar navigation flow and redirect rules from the manifest.

**Files:**
- Create: `src/frontend/e2e/generated/navigation.spec.ts`
- Create: `src/frontend/e2e/generated/redirects.spec.ts`

- [ ] **Step 1: Write navigation test**

```typescript
/**
 * Sidebar navigation flow — clicks through all sidebar links and verifies URLs.
 * Source: qa/manifest.yml flow "navigation-sidebar"
 */
import { test, expect } from '../fixtures/authenticated-page'

test.describe('Sidebar Navigation', () => {
  test('navigate through all sidebar links', async ({ authenticatedPage: page }) => {
    await page.goto('/')
    await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible()

    await page.getByRole('link', { name: 'Users' }).click()
    await expect(page).toHaveURL(/\/directory\/users/)

    await page.getByRole('link', { name: 'Groups' }).click()
    await expect(page).toHaveURL(/\/directory\/groups/)

    await page.getByRole('link', { name: 'Organizations' }).click()
    await expect(page).toHaveURL(/\/directory\/orgs/)

    await page.getByRole('link', { name: 'Device Management' }).click()
    await expect(page).toHaveURL(/\/provisioning\/devices/)

    await page.getByRole('link', { name: 'Audit Log' }).click()
    await expect(page).toHaveURL(/\/audit-log/)
  })
})
```

- [ ] **Step 2: Write redirect tests**

```typescript
/**
 * Redirect rules — verifies legacy URLs redirect to current routes.
 * Source: qa/manifest.yml redirects section
 */
import { test, expect } from '../fixtures/authenticated-page'

test.describe('Redirects', () => {
  test('/settings redirects to /configuration/settings', async ({ authenticatedPage: page }) => {
    await page.goto('/settings')
    await expect(page).toHaveURL(/\/configuration\/settings/)
  })

  test('/directory/users/:uid redirects to /directory/users?userId=:uid', async ({ authenticatedPage: page }) => {
    await page.goto('/directory/users/test-uid')
    await expect(page).toHaveURL(/\/directory\/users\?userId=test-uid/)
  })

  test('/directory/groups/:cn redirects to /directory/groups?groupId=:cn', async ({ authenticatedPage: page }) => {
    await page.goto('/directory/groups/test-group')
    await expect(page).toHaveURL(/\/directory\/groups\?groupId=test-group/)
  })

  test('/directory/orgs/:dn redirects to /directory/orgs?orgId=:dn', async ({ authenticatedPage: page }) => {
    await page.goto('/directory/orgs/test-org')
    await expect(page).toHaveURL(/\/directory\/orgs\?orgId=test-org/)
  })
})
```

- [ ] **Step 3: Run both tests**

Run: `cd src/frontend && npx playwright test e2e/generated/navigation.spec.ts e2e/generated/redirects.spec.ts --reporter=list 2>&1`

Expected: All pass. Sidebar links should be `<a>` elements (verify with `getByRole('link')`). If sidebar uses buttons instead of links, update to `getByRole('button')` or `getByText()`.

- [ ] **Step 4: Commit**

```bash
git add src/frontend/e2e/generated/navigation.spec.ts src/frontend/e2e/generated/redirects.spec.ts
git commit -m "feat(qa): add navigation flow and redirect tests

Sidebar navigation clicks through all 5 main sections.
Redirects verify 4 legacy URL patterns resolve correctly."
```

---

## Task 11: Full Pipeline Verification

End-to-end verification that everything works together.

- [ ] **Step 1: Verify Docker stack is healthy**

Run: `just health-check`

Expected: Exit code 0.

- [ ] **Step 2: Run full QA suite**

Run: `just qa-full 2>&1 | tail -30`

Expected: All tests pass — existing migrated specs + generated smoke/navigation/redirect specs.

- [ ] **Step 3: Run QA report**

Run: `just qa-report`

Expected output (approximately):
```
QA Coverage Report
===================
Manifest pages: 12
Generated specs: 3
Hand-written specs: 4
```

- [ ] **Step 4: Run smoke suite specifically**

Run: `just qa-smoke 2>&1 | tail -20`

Expected: Smoke project runs generated specs only.

- [ ] **Step 5: Verify CI workflow syntax**

Run: `cd .github/workflows && python3 -c "import yaml; yaml.safe_load(open('qa.yml')); print('Valid')" 2>&1`

- [ ] **Step 6: Final commit if any adjustments were needed**

If any fixes were made during verification, commit them:

```bash
git add -A
git commit -m "fix(qa): adjust pipeline from integration testing"
```

---

## Deferred: Phase 2+ (Not in this plan)

These are documented in the spec but intentionally excluded from this plan:

- **Explore + export engine** (Phase 2) — gstack `/browse` session capture and Playwright code generation. This is the token-intensive exploratory workflow. Requires a working pipeline first.
- **SSO login flow test** (Phase 3) — requires `QA_SSO_USER`/`QA_SSO_PASSWORD` credentials configured. The auth setup project is in place; writing the actual flow test is deferred.
- **Report + promote subcommands** (Phase 5) — the skill documents them; actual implementation is deferred until there are generated specs to manage.
