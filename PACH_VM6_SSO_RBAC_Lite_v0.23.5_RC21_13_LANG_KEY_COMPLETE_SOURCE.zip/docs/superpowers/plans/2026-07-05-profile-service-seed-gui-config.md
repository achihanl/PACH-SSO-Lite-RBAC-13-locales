# Profile-Service Deploy Seeding + GUI-Dynamic UC Config — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Every deploy (fresh prod + existing dev) ends with the Standard Profile carrying idempotently-seeded `xmpp`+`sip` services, and the operator can repoint those UC servers live from the GUI.

**Architecture:** `OrgDB.init()` self-heals the default profile's service rows on every backend boot (insert-if-missing, never clobber). `/api/health/deep` exposes a `default_profile_services_ok` flag that an Ansible verify gate asserts. The frontend wires the existing (dead) `useUpdateService`/`useAddService`/`useRemoveService` hooks into a `ServiceEditDialog` so config lives in the DB and is operator-editable.

**Tech Stack:** FastAPI + SQLAlchemy Core (backend), pytest against real Docker stack, React 19 + TanStack Query + `@azblink/ui` (Base UI) + vitest (frontend), Ansible (deploy).

## Global Constraints

- Config keys (verbatim): xmpp service `config = {"domain", "ws_url"}`; sip service `config = {"domain", "wss_url"}`. These match provisioning read (`main.py:466–476`) and GUI `CONFIG_LABELS` (`ServiceCard.tsx:11–17`).
- SIP extension range: `counter_start=1000`, `counter_end=1999`. XMPP has no counter (`None`).
- Seed is **insert-if-missing, never update** — must not overwrite existing rows/counters.
- Governed surfaces `src/backend/orgdb.py` + `src/backend/main.py` → every commit touching them carries trailer `Spec-Patch: 05`. Ansible + frontend commits carry no trailer.
- Backend tests run against the live stack via `just test-quick`; `client` fixture = authenticated (`DEV_AUTH_TOKEN`).
- Backend hot-reloads (no rebuild). Frontend hot-reloads (Vite HMR). Ansible not run locally.
- Lint gates: backend `ruff check --select F,E,W,B --ignore E501` on changed files; frontend `just ui-lint` + `prettier --check` (use repo-root `node_modules/.bin/prettier`, NOT `npx`).

---

### Task 1: Backend — resolver + idempotent per-service seed (`OrgDB`)

**Files:**
- Modify: `src/backend/orgdb.py` — `init()` (lines 370–388) + add `get_default_template()` and `_seed_default_profile_services()`
- Test: `tests/test_profile_seed.py` (new)

**Interfaces:**
- Consumes: `add_profile_service(profile_id, data)`, `get_profile_services(profile_id)` (existing), `config_templates`, `profile_services` tables.
- Produces: `OrgDB.get_default_template() -> dict | None` (resolves `template_type="default"`, else `name="Standard Profile"`); `OrgDB._seed_default_profile_services() -> None`.

**Model:** Opus (idempotency/edge-case reasoning).

- [ ] **Step 1: Write the failing tests** — `tests/test_profile_seed.py`

```python
"""Tests for idempotent default-profile UC service seeding (OrgDB.init)."""
import os
import uuid
import pytest
from orgdb import OrgDB

DB_URL = os.getenv("DATABASE_URL", "postgresql://azblink_directory:azblink_directory@localhost:5433/azblink_directory")


@pytest.fixture
def db():
    return OrgDB(database_url=DB_URL)


def test_get_default_template_resolves_standard_profile(db):
    tpl = db.get_default_template()
    assert tpl is not None
    assert tpl["template_type"] == "default" or tpl["name"] == "Standard Profile"


def test_seed_creates_xmpp_and_sip(monkeypatch, db):
    import config
    monkeypatch.setattr(config, "UCCHAT_XMPP_DOMAIN", "xmpp.seedtest.com", raising=False)
    monkeypatch.setattr(config, "UCCHAT_XMPP_WS_URL", "wss://xmpp.seedtest.com/ws", raising=False)
    monkeypatch.setattr(config, "UCCHAT_SIP_DOMAIN", "sip.seedtest.com", raising=False)
    monkeypatch.setattr(config, "UCCHAT_SIP_WSS_URL", "wss://sip.seedtest.com/ws", raising=False)
    db._seed_default_profile_services()
    tpl = db.get_default_template()
    svcs = {s["service_type"]: s for s in db.get_profile_services(tpl["id"])}
    assert "xmpp" in svcs and "sip" in svcs
    assert svcs["sip"]["counter_start"] == 1000 and svcs["sip"]["counter_end"] == 1999


def test_seed_is_idempotent_and_preserves_edits(monkeypatch, db):
    import json
    import config
    monkeypatch.setattr(config, "UCCHAT_SIP_DOMAIN", "sip.seedtest.com", raising=False)
    monkeypatch.setattr(config, "UCCHAT_SIP_WSS_URL", "wss://sip.seedtest.com/ws", raising=False)
    tpl = db.get_default_template()
    sip = next(s for s in db.get_profile_services(tpl["id"]) if s["service_type"] == "sip")
    # Snapshot the live default-profile sip config so we can restore it (shared state)
    orig = sip["config"]
    orig = json.loads(orig) if isinstance(orig, str) else dict(orig)
    try:
        # Simulate an operator GUI edit to the sip row
        db.update_profile_service(sip["id"], {"config": {"domain": "operator-edited.com", "wss_url": "wss://operator-edited.com"}})
        before = db.get_profile_services(tpl["id"])
        db._seed_default_profile_services()  # re-run
        after = db.get_profile_services(tpl["id"])
        assert len(before) == len(after)  # no duplicate rows
        sip_after = next(s for s in after if s["service_type"] == "sip")
        cfg = sip_after["config"]
        cfg = json.loads(cfg) if isinstance(cfg, str) else cfg
        assert cfg["domain"] == "operator-edited.com"  # edit preserved, NOT clobbered
    finally:
        db.update_profile_service(sip["id"], {"config": orig})  # restore shared state
```

- [ ] **Step 2: Run to verify they fail**

Run: `just test-quick tests/test_profile_seed.py -v` (or `cd deploy/dev && just test-quick ../../tests/test_profile_seed.py`)
Expected: FAIL — `AttributeError: 'OrgDB' object has no attribute 'get_default_template'`

- [ ] **Step 3: Implement `get_default_template()`** — add after `get_profile` (~line 407) in `orgdb.py`

```python
    def get_default_template(self) -> dict[str, Any] | None:
        """Resolve the default profile: template_type='default', else name='Standard Profile'."""
        eng = self.connect()
        with eng.begin() as conn:
            row = conn.execute(
                select(config_templates)
                .where(config_templates.c.template_type == "default")
                .limit(1)
            ).mappings().first()
            if row is None:
                row = conn.execute(
                    select(config_templates)
                    .where(config_templates.c.name == "Standard Profile")
                    .limit(1)
                ).mappings().first()
        return dict(row) if row else None
```

- [ ] **Step 4: Rewrite `init()` + add seed helper** — replace `init()` body (lines 370–388)

```python
    def init(self) -> None:
        eng = self.connect()
        metadata.create_all(eng)
        self._seed_default_profile_services()

    def _seed_default_profile_services(self) -> None:
        """Ensure the default profile exists and carries xmpp+sip service rows.

        - Idempotent: runs every startup; inserts only what is missing.
        - Never updates existing rows (preserves operator/GUI edits + counters).
        - UCCHAT_* env seeds initial config; a type with no domain is created
          disabled (a shell the operator completes via GUI).
        """
        from config import (
            UCCHAT_XMPP_DOMAIN, UCCHAT_XMPP_WS_URL,
            UCCHAT_SIP_DOMAIN, UCCHAT_SIP_WSS_URL,
        )
        profile = self.get_default_template()
        if profile is None:
            eng = self.connect()
            profile_id = str(uuid4())
            with eng.connect() as conn:
                conn.execute(config_templates.insert().values(
                    id=profile_id,
                    name="Standard Profile",
                    description="Default provisioning profile for all organizations",
                    template_type="default",
                    status="active",
                ))
                conn.commit()
            logger.info("Seeded default config template")
        else:
            profile_id = profile["id"]

        existing = {s["service_type"] for s in self.get_profile_services(profile_id)}
        seeds = [
            {"service_type": "xmpp",
             "config": {"domain": UCCHAT_XMPP_DOMAIN, "ws_url": UCCHAT_XMPP_WS_URL},
             "enabled": bool(UCCHAT_XMPP_DOMAIN),
             "counter_start": None, "counter_end": None},
            {"service_type": "sip",
             "config": {"domain": UCCHAT_SIP_DOMAIN, "wss_url": UCCHAT_SIP_WSS_URL},
             "enabled": bool(UCCHAT_SIP_DOMAIN),
             "counter_start": 1000, "counter_end": 1999},
        ]
        for seed in seeds:
            if seed["service_type"] in existing:
                continue
            self.add_profile_service(profile_id, seed)
            logger.info("Seeded %s service on default profile", seed["service_type"])
```

- [ ] **Step 5: Run tests to verify they pass** — `just test-quick tests/test_profile_seed.py -v` → PASS (3 tests)

- [ ] **Step 6: Lint changed file** — `ruff check --select F,E,W,B --ignore E501 src/backend/orgdb.py` → clean

- [ ] **Step 7: Commit**

```bash
git add src/backend/orgdb.py tests/test_profile_seed.py
git commit -m "feat(provisioning): idempotent default-profile UC service seeding

Spec-Patch: 05"
```

---

### Task 2: Backend — `default_profile_services_ok` deploy signal

**Files:**
- Modify: `src/backend/main.py` — `/api/health/deep` (lines 718–770) + add `_default_profile_services_ok()` helper
- Test: `tests/test_health_deep_services.py` (new)

**Interfaces:**
- Consumes: `ORGDB.get_default_template()`, `ORGDB.get_profile_services()` (Task 1).
- Produces: `/api/health/deep` JSON gains `default_profile_services_ok: bool`.

**Model:** Opus (correctness of the deploy-gate semantics).

- [ ] **Step 1: Write failing test** — `tests/test_health_deep_services.py`

```python
"""Deep-health exposes default_profile_services_ok for the deploy verify gate."""


def test_health_deep_reports_services_flag(client):
    resp = client.get("/api/health/deep")
    assert resp.status_code in (200, 503)
    body = resp.json()
    assert "default_profile_services_ok" in body
    assert isinstance(body["default_profile_services_ok"], bool)
```

- [ ] **Step 2: Run to verify it fails** — `just test-quick tests/test_health_deep_services.py -v` → FAIL (KeyError / assertion on missing key)

- [ ] **Step 3: Add helper** — insert above `api_health_deep` (~line 717) in `main.py`

```python
def _default_profile_services_ok() -> bool:
    """True when the default profile has its domain-configured UC services enabled.

    - Deploy-verify signal for profile-service seeding.
    - Vacuously true when no UCCHAT_* domain is configured (deploy ships no UC).
    """
    from config import UCCHAT_XMPP_DOMAIN, UCCHAT_SIP_DOMAIN
    required = set()
    if UCCHAT_XMPP_DOMAIN:
        required.add("xmpp")
    if UCCHAT_SIP_DOMAIN:
        required.add("sip")
    if not required:
        return True
    try:
        profile = ORGDB.get_default_template()
        if not profile:
            return False
        have = {
            s["service_type"]
            for s in ORGDB.get_profile_services(profile["id"])
            if s.get("enabled")
        }
        return required.issubset(have)
    except Exception:
        return False
```

- [ ] **Step 4: Add flag to response** — in `api_health_deep`, extend `response_data` (line 758)

```python
    response_data = {
        "ok": all_healthy,
        "status": "healthy" if all_healthy else "degraded",
        "checks": checks,
        "default_profile_services_ok": _default_profile_services_ok(),
    }
```

- [ ] **Step 5: Run test to verify it passes** — `just test-quick tests/test_health_deep_services.py -v` → PASS

- [ ] **Step 6: Lint** — `ruff check --select F,E,W,B --ignore E501 src/backend/main.py` → clean

- [ ] **Step 7: Commit**

```bash
git add src/backend/main.py tests/test_health_deep_services.py
git commit -m "feat(provisioning): expose default_profile_services_ok in deep health

Spec-Patch: 05"
```

---

### Task 3: Deploy — Ansible verify gate

**Files:**
- Modify: `deploy/ansible/roles/azblink_app/tasks/verify.yml` (append a task after the Grafana gate)

**Interfaces:**
- Consumes: `/api/health/deep` `default_profile_services_ok` (Task 2); vars `seed_verify_retries`, `seed_verify_delay`.

**Model:** Haiku (mechanical YAML edit, mirrors existing gates).

- [ ] **Step 1: Append gate** to end of `verify.yml`

```yaml
# Profile-service seed gate: init() self-heals the default profile's UC
# services on every boot; assert they landed. Vacuously true on a deploy
# with no UCCHAT_* domains configured (see _default_profile_services_ok).
- name: Wait for default-profile UC services to be seeded
  ansible.builtin.uri:
    url: http://localhost:8081/api/health/deep
    return_content: true
    status_code: [200, 503]
  register: svc_health
  until: (svc_health.json.default_profile_services_ok | default(false))
  retries: "{{ seed_verify_retries }}"
  delay: "{{ seed_verify_delay }}"
```

- [ ] **Step 2: YAML lint** — `python -c "import yaml,sys; yaml.safe_load(open('deploy/ansible/roles/azblink_app/tasks/verify.yml'))" && echo OK` → OK

- [ ] **Step 3: Commit**

```bash
git add deploy/ansible/roles/azblink_app/tasks/verify.yml
git commit -m "ci(deploy): assert default-profile UC services in verify gate"
```

---

### Task 4: Frontend — ServiceEditDialog + wire hooks into GUI

**Files:**
- Create: `src/frontend/src/components/features/org-profiles/modals/ServiceEditDialog.tsx` (NEW — needs user approval)
- Create: `src/frontend/src/components/features/org-profiles/modals/__tests__/service-edit-payload.test.ts` (NEW)
- Modify: `src/frontend/src/components/features/org-profiles/ServiceCard.tsx` (add Edit button → open dialog)
- Modify: `src/frontend/src/components/features/org-profiles/ConfigTab.tsx` (owns dialog state; passes `templateId`)

**Interfaces:**
- Consumes: `useUpdateService(templateId)`, `useRemoveService(templateId)` from `@/lib/queries/profile-services`; `ProfileService`, `ProfileDetail` types; `@azblink/ui` `Dialog*`, `Input`, `Label`, `Button`, `Switch`.
- Produces: `buildServiceConfig(serviceType, form) -> Record<string, unknown>` (pure, exported for test); `<ServiceEditDialog open service templateId onClose />`.

**Model:** Opus (form-state + payload logic + wiring).

- [ ] **Step 1: Write failing vitest for the pure payload builder** — `service-edit-payload.test.ts`

```typescript
import { describe, it, expect } from 'vitest'
import { buildServiceConfig } from '../ServiceEditDialog'

describe('buildServiceConfig', () => {
  it('maps xmpp fields to domain + ws_url', () => {
    expect(buildServiceConfig('xmpp', { domain: 'x.com', url: 'wss://x.com/ws' }))
      .toEqual({ domain: 'x.com', ws_url: 'wss://x.com/ws' })
  })
  it('maps sip fields to domain + wss_url', () => {
    expect(buildServiceConfig('sip', { domain: 's.com', url: 'wss://s.com' }))
      .toEqual({ domain: 's.com', wss_url: 'wss://s.com' })
  })
})
```

- [ ] **Step 2: Run to verify it fails** — `cd src/frontend && npx vitest run src/components/features/org-profiles/modals/__tests__/service-edit-payload.test.ts` → FAIL (module not found)

- [ ] **Step 3: Create `ServiceEditDialog.tsx`** (model on `CreateProfileModal.tsx`)

```tsx
/**
 * ServiceEditDialog -- edit a profile's UC service config live.
 * - Fields: domain, WS/WSS URL, enabled; SIP also has extension range.
 * - Submits via useUpdateService (PUT); config key differs per type.
 */
import { useState, useEffect, type FormEvent } from 'react'
import { Loader2 } from 'lucide-react'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
  DialogClose, DialogFooter, Button, Input, Label, Switch,
} from '@azblink/ui'
import { toast } from 'sonner'
import { useUpdateService } from '@/lib/queries/profile-services'
import type { ProfileService } from '@/types/org-profiles'

/** Pure: map form → service config JSON with the type's URL key. */
export function buildServiceConfig(
  serviceType: string,
  form: { domain: string; url: string },
): Record<string, unknown> {
  const urlKey = serviceType === 'sip' ? 'wss_url' : 'ws_url'
  return { domain: form.domain, [urlKey]: form.url }
}

interface Props {
  open: boolean
  service: ProfileService
  templateId: string
  onClose: () => void
}

export function ServiceEditDialog({ open, service, templateId, onClose }: Props) {
  const cfg = service.config as Record<string, unknown>
  const urlKey = service.serviceType === 'sip' ? 'wss_url' : 'ws_url'
  const [domain, setDomain] = useState('')
  const [url, setUrl] = useState('')
  const [enabled, setEnabled] = useState(true)
  const mutation = useUpdateService(templateId)

  useEffect(() => {
    if (open) {
      /* eslint-disable react-hooks/set-state-in-effect -- open→prefill from service */
      setDomain(String(cfg.domain ?? ''))
      setUrl(String(cfg[urlKey] ?? ''))
      setEnabled(service.enabled)
      /* eslint-enable react-hooks/set-state-in-effect */
    }
  }, [open, service.id]) // eslint-disable-line react-hooks/exhaustive-deps

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    mutation.mutate(
      { serviceId: service.id, config: buildServiceConfig(service.serviceType, { domain, url }), enabled },
      {
        onSuccess: () => {
          toast.success(`${service.serviceType.toUpperCase()} service updated`)
          onClose()
        },
        onError: (err: Error) => toast.error(err.message || 'Update failed'),
      },
    )
  }

  return (
    <Dialog open={open} onOpenChange={(n) => { if (!n) onClose() }}>
      <DialogContent size="md" data-testid="service-edit-dialog">
        <DialogClose />
        <DialogHeader>
          <DialogTitle>Edit {service.serviceType.toUpperCase()} service</DialogTitle>
          <DialogDescription>
            Repoint this profile's UC server. Applies to new provisions immediately.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 px-6 py-4">
            <div className="space-y-1.5">
              <Label htmlFor="svc-domain">Domain</Label>
              <Input id="svc-domain" value={domain} onChange={(e) => setDomain(e.target.value)} placeholder="xmpp.example.com" autoFocus />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="svc-url">{service.serviceType === 'sip' ? 'WSS URL' : 'WebSocket URL'}</Label>
              <Input id="svc-url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="wss://.../ws" />
            </div>
            <div className="flex items-center gap-2">
              <Switch id="svc-enabled" checked={enabled} onCheckedChange={setEnabled} />
              <Label htmlFor="svc-enabled">Enabled</Label>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending ? <><Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />Saving...</> : 'Save Changes'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
```

> NOTE: confirm `Switch` is exported by `@azblink/ui`; if not, use a checkbox `Input type="checkbox"` or the existing toggle primitive. Verify with `grep -r "export.*Switch" src/frontend/packages/azblink-ui/index.ts`.

- [ ] **Step 4: Run vitest to verify pass** — `npx vitest run .../service-edit-payload.test.ts` → PASS (2 tests)

- [ ] **Step 5: Wire Edit button into `ServiceCard.tsx`** — add an `onEdit` prop + a pencil button in the `ConfigSection` header area

```tsx
// add to imports: import { Button } from '@azblink/ui'; import { Pencil } from 'lucide-react'
// add to ServiceCardProps: onEdit?: () => void
// render (near title/Status): {onEdit && (
//   <Button variant="ghost" size="sm" onClick={onEdit} aria-label="Edit service"><Pencil className="h-3.5 w-3.5" /></Button>
// )}
```

- [ ] **Step 6: Own dialog state in `ConfigTab.tsx`**

```tsx
// import { useState } from 'react'; import { ServiceEditDialog } from './modals/ServiceEditDialog'
// ConfigTabProps already has `profile`; profile.id is the templateId.
// const [editing, setEditing] = useState<ProfileService | null>(null)
// <ServiceCard ... onEdit={() => setEditing(service)} />
// {editing && <ServiceEditDialog open service={editing} templateId={profile.id} onClose={() => setEditing(null)} />}
```

- [ ] **Step 7: Lint + format** — `just ui-lint` then `node_modules/.bin/prettier --check "src/frontend/src/components/features/org-profiles/**/*.tsx"` (from repo root) → clean

- [ ] **Step 8: Manual smoke via browser** — open a profile → Configuration tab → Edit on the SIP card → change domain → Save → toast + card shows new domain.

- [ ] **Step 9: Commit**

```bash
git add src/frontend/src/components/features/org-profiles/
git commit -m "feat(org-profiles): GUI edit dialog for UC service config"
```

---

### Task 5: Spec §05 + version bumps + CHANGELOG

**Files:**
- Modify: `docs/architecture/spec/05-provisioning.md` (add seeding subsection; bump meta `1.1.0 → 1.2.0`)
- Modify: `CHANGELOG.md` ([Unreleased] entry)

**Model:** Haiku (mechanical doc edits).

- [ ] **Step 1: Bump spec meta** (line 1) — `version: "1.1.0"` → `"1.2.0"`, `last_updated: "2026-07-05"`

- [ ] **Step 2: Add subsection** under §5.1 documenting default-profile service seeding (idempotent, insert-if-missing, env-seeded/GUI-authoritative, SIP 1000–1999).

- [ ] **Step 3: CHANGELOG [Unreleased] Features** — add:
  `- **provisioning:** Idempotent default-profile UC service seeding + GUI-editable service config`

- [ ] **Step 4: Commit**

```bash
git add docs/architecture/spec/05-provisioning.md CHANGELOG.md
git commit -m "docs(spec): document default-profile service seeding (§05 1.2.0)

Spec-Patch: 05"
```

---

### Task 6: e2e provisioning smoke (clean-profile → user → live edit)

**Files:**
- Test: `tests/test_profile_seed_e2e.py` (new) — integration, real stack.

**Interfaces:** Consumes seeded services (Task 1), provisioning endpoints, `/api/health/deep` flag (Task 2).

**Model:** Opus (end-to-end flow reasoning).

- [ ] **Step 1: Write the e2e test** — assert the default profile has enabled xmpp+sip after init, the health flag is true, then edit the SIP domain via API and confirm the DB row reflects it.

```python
"""e2e: default profile is seeded + services are live-editable (deploy proof)."""


def test_default_profile_seeded_and_editable(client):
    # Deploy signal is green
    health = client.get("/api/health/deep").json()
    assert health["default_profile_services_ok"] is True

    # Default profile carries xmpp + sip
    templates = client.get("/api/config-templates").json()["templates"]
    default = next(t for t in templates if t.get("templateType") == "default" or t["name"] == "Standard Profile")
    svcs = {s["serviceType"]: s for s in default["services"]}
    assert "xmpp" in svcs and "sip" in svcs

    # Operator repoints SIP live via the GUI's API (restore after — shared default profile)
    sip_id = svcs["sip"]["id"]
    orig_cfg = svcs["sip"]["config"]
    try:
        put = client.put(f"/api/config-templates/{default['id']}/services/{sip_id}",
                         json={"config": {"domain": "sip.newlab.com", "wss_url": "wss://sip.newlab.com"}})
        assert put.status_code == 200
        assert put.json()["service"]["config"]["domain"] == "sip.newlab.com"
    finally:
        client.put(f"/api/config-templates/{default['id']}/services/{sip_id}", json={"config": orig_cfg})
```

- [ ] **Step 2: Run** — `just test-quick tests/test_profile_seed_e2e.py -v` → PASS

- [ ] **Step 3: Commit**

```bash
git add tests/test_profile_seed_e2e.py
git commit -m "test(provisioning): e2e default-profile seed + live edit proof"
```

---

## Final: full suite + delivery

- [ ] Run full backend suite: `just test-quick` → all green.
- [ ] Run frontend: `cd src/frontend && npx vitest run` + `just ui-lint` → green.
- [ ] Create GitHub issue describing the deploy gap + GUI-config requirement.
- [ ] Push branch, open PR referencing the issue; poll CI + CodeRabbit.
- [ ] On merge → dev VM converge → prod VM converge.

## Self-Review (author checklist — completed)

- **Spec coverage:** seed (T1), verify signal (T2/T3), GUI edit (T4), governance/spec (T5), e2e proof (T6) — every design §4/§6/§7 item mapped. ✅
- **Placeholders:** none — all steps carry code/commands. The one flagged uncertainty (`Switch` export) has an explicit verify step. ✅
- **Type consistency:** config keys `domain`/`ws_url`/`wss_url` uniform across T1/T2/T4/T6; `get_default_template()` signature consistent T1↔T2; `buildServiceConfig` signature consistent dialog↔test. ✅
