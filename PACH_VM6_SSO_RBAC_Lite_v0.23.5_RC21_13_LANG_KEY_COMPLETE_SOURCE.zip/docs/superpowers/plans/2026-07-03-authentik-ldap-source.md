# Authentik LDAP Source Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Federate identity from the platform OpenLDAP into Authentik so a directory user can log into the web admin SSO with the same `userPassword` the PED uses — via a bind-based Authentik LDAP source, no password copy.

**Architecture:** One-directional federation. Authentik reads `ou=people` through a dogfooded provisioned sync client (`cn=authentik-sync,ou=clients`, read-minus-secrets). Sync maps `uid→username / cn→name / mail→email`; login binds AS the user to validate the password. ARD-002 (Authentik sole web-auth path) is preserved — its user store is now LDAP-backed. UC still works with Authentik absent (Authentik depends on LDAP, never the reverse). No `main.py` change: the provision/rotate/list endpoints already exist (#181); the seed calls them.

**Tech Stack:** Authentik Admin API v3 (2026.5.2), `deploy/dev/authentik-seed/seed_authentik.py` (stdlib urllib), FastAPI directory API (`/api/settings/ldap/clients/provisioned`), OpenLDAP (osixia 1.5.0), pytest + httpx integration tests, Ansible (`azblink_app` role), spec governance (ARD-007 + §04/§06).

**Source spec:** `docs/superpowers/specs/2026-07-03-authentik-ldap-source-design.md`

---

## Preconditions & Conventions

- **Verification model:** the seed script is I/O against a live stack, so it is **integration-verified**, not unit-TDD. Each seed sub-task pairs its change with a concrete verify command (re-run the seed idempotently, then `ldapsearch` / an Authentik API `GET`). The single automated regression is the Phase B integration test. Do not claim a seed task done until its verify command shows the expected output.
- **Dev auth to the directory API:** the seed authenticates to `directory-api` with `Authorization: Bearer <DEV_AUTH_TOKEN>` (value `dev-test-token` in dev). This works because `_claims_from_auth_header` (`main.py:324-332`) maps that token to synthetic claims with `groups: [OIDC_ADMIN_GROUP]`, satisfying `require_permission("system_configuration")`.
- **Dev vs prod secret source (critical seam):** in **dev** the seed self-provisions the sync client via the directory API and captures the show-once secret. In **prod** `DEV_AUTH_TOKEN` is empty, so the seed instead reads a pre-supplied `AUTHENTIK_LDAP_SYNC_PASSWORD` (rendered from vault) and does NOT self-provision. Every seed function below branches on `DEV_AUTH_TOKEN` presence.
- **Stack up:** `cd deploy/dev && just up-bg` then `just health`. Re-run the seed with `docker start -a azblink-authentik-seed`.
- **Commit discipline:** frequent commits at the step boundaries shown. Phase C is the governed-surface commit and MUST carry the `ARD: ARD-007` trailer (see Task C6).

---

## A0 Results — confirmed live against 2026.5.2 (2026-07-03)

The spike ran; the three unverified facts are now settled:

- **LDAP property-mapping managed IDs exist exactly as assumed** (resolve PKs by managed ID at runtime — PKs differ per install):
  - `goauthentik.io/sources/ldap/openldap-uid`, `goauthentik.io/sources/ldap/openldap-cn`, `goauthentik.io/sources/ldap/default-mail` (also present: `default-name`, `default-dn-path`).
- **`object_uniqueness_field` has NO OpenAPI default** → the Django model default (`objectSid`, AD-only) applies if omitted. **Set `object_uniqueness_field: "uid"` explicitly** (non-negotiable). Source required fields: `base_dn, name, server_uri, slug`.
- **Sync trigger mechanism (corrects the plan's earlier guess):**
  - Trigger: `POST /api/v3/tasks/schedules/{id}/send/`
  - Find the source's schedule by **`rel_obj_id == <source pk>`** (schedule objects carry `rel_obj_id`, `actor_name`, `id` — NOT the slug). Prefer the schedule whose `actor_name` contains `sync`.
  - Poll status: `GET /api/v3/sources/ldap/{slug}/sync/status/` (confirm the response shape live during A5 — best-effort poll; the real success signal is "LDAP users now present in Authentik").
  - Source-link assertion (B1): `GET /api/v3/sources/user_connections/ldap/?user={ak_pk}`.
- **0 pre-existing LDAP sources** — clean slate.

## File Structure

| File | Create/Modify | Responsibility |
|------|---------------|----------------|
| `deploy/dev/docker-compose.yml` | Modify (`authentik-seed` svc, ~L333-353) | Give the seed a route + creds to `directory-api`; gate on API health. **Governed surface → §06.** |
| `deploy/dev/authentik-seed/seed_authentik.py` | Modify | New `ensure_sync_client()`, `get_ldap_source_mapping_pks()`, `ensure_ldap_source()`, `trigger_ldap_sync()`, `delete_local_user()`, `add_ldap_user_to_admin_group()`; edit `SEED_USERS`, `main()`. Not a governed surface. |
| `tests/test_ldap_source.py` | Create (needs approval) | Integration regression: provision → create LDAP-only user → sync → assert import + `UserSourceConnection`. |
| `docs/architecture/decisions/ARD-007-authentik-ldap-source.md` | Create (needs approval) | Decision record (standalone; references ARD-002). |
| `docs/architecture/spec/04-authentication.md` | Modify | Plane B store cell + LDAP-source paragraph; bump `spec-meta last_updated`. |
| `docs/architecture/spec/06-deployment.md` | Modify | §6.5 bootstrap step + authentik-seed dep row; bump `spec-meta last_updated`. |
| `docs/architecture/README.md` | Modify | ARD-007 table row + spec version bump `1.2.1 → 1.3.0`. |
| `docs/architecture/CHANGELOG.md` | Create (needs approval) | **Does not exist today** despite SOP requiring it — create from SOP format with the 1.3.0 entry. |
| `deploy/ansible/inventories/dev/group_vars/all/main.yml` | Modify | `authentik_ldap_sync_client_id`, source config vars. |
| `deploy/ansible/inventories/dev/group_vars/all/vault.yml` | Modify | `authentik_ldap_sync_password` (dev throwaway). |
| `deploy/ansible/roles/azblink_app/templates/env.j2` | Modify | Render `AUTHENTIK_LDAP_SYNC_*` into `.env`. |
| `deploy/ansible/roles/azblink_app/tasks/ldap_source.yml` | Create (needs approval) | Prod: idempotent ACL apply (docker exec ldapmodify). |
| `deploy/ansible/roles/azblink_app/tasks/main.yml` | Modify | Import `ldap_source.yml`. |
| `deploy/ansible/roles/azblink_app/tasks/verify.yml` | Modify | Assert the LDAP source exists post-seed. |

> **New-file gate:** four files above are marked *needs approval* (per the user's "never create a new file without explicit permission" rule). Get a yes before the Write step in Tasks B1, C1, C5, D3.

---

# Phase A — Dev seed + compose wiring

Produces: a directory user can be synced into Authentik and log into the web UI on the dev stack.

### Task A0: Live-API spike — confirm the three unverified Authentik facts

**Files:** none (throwaway; nothing committed). Produces the confirmed constants the rest of Phase A hard-codes.

Fable's review verified the source *field names* and *managed mapping IDs* against the live 2026.5.2 schema, but three things are from Authentik source-knowledge and MUST be confirmed live before coding: (1) `object_uniqueness_field` default, (2) the exact LDAP property-mapping managed IDs, (3) the sync-trigger mechanism.

- [ ] **Step 1: Confirm the stack + token**

Run:
```bash
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  http://localhost:9000/api/v3/root/config/ | python3 -m json.tool | head -5
```
Expected: JSON (not 403). If 403, the bootstrap token differs — read it from `deploy/dev/.env` (`AUTHENTIK_BOOTSTRAP_TOKEN`).

- [ ] **Step 2: Confirm the LDAP property-mapping managed IDs**

Run:
```bash
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  "http://localhost:9000/api/v3/propertymappings/all/?page_size=200" \
  | python3 -c 'import sys,json; [print(m["managed"],"|",m["name"]) for m in json.load(sys.stdin)["results"] if m.get("managed","").startswith("goauthentik.io/sources/ldap")]'
```
Expected: lines including `goauthentik.io/sources/ldap/openldap-uid`, `.../openldap-cn`, `goauthentik.io/sources/ldap/default-mail`. **Record the exact managed strings** — Task A3 filters on them. If `openldap-uid`/`openldap-cn` are absent (only AD/`default-*` present), note the real OpenLDAP mapping IDs instead.

- [ ] **Step 3: Confirm the LDAP source schema — `object_uniqueness_field` default + required fields**

Run:
```bash
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  http://localhost:9000/api/v3/schema/ \
  | python3 -c 'import sys,json,re; s=json.load(sys.stdin); c=s["components"]["schemas"]["LDAPSourceRequest"]; import pprint; pprint.pprint({k:v.get("default","<none>") for k,v in c["properties"].items() if k in ("object_uniqueness_field","sync_users","sync_groups","delete_not_found_objects","user_object_filter")}); print("REQUIRED:",c.get("required"))'
```
Expected: shows the default for `object_uniqueness_field` (Fable predicts `objectSid` — AD-flavored, wrong for OpenLDAP) and the `required` list. **If the default is anything other than `uid`/`entryUUID`, Task A4 MUST set `object_uniqueness_field: "uid"` explicitly** — this is the "imports 0 users silently" trap.

- [ ] **Step 4: Confirm the sync-trigger mechanism**

Run:
```bash
# List task schedules — find the LDAP-source sync schedule shape
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  "http://localhost:9000/api/v3/tasks/schedules/?page_size=200" \
  | python3 -c 'import sys,json; [print(t.get("id"),"|",t.get("rel_obj_app"),"|",t.get("actor_name")) for t in json.load(sys.stdin)["results"]]' | grep -i ldap || echo "no ldap schedule yet (expected until a source exists)"
# Confirm the sync-status read endpoint exists on the schema
curl -s -o /dev/null -w "%{http_code}\n" -H "Authorization: Bearer dev-authentik-api-token" \
  "http://localhost:9000/api/v3/sources/ldap/"
```
Expected: `200` for the sources list. There is **no** `.../sync/` POST trigger — sync fires via `POST /api/v3/tasks/schedules/{id}/send/`. **Record** whether creating a source auto-dispatches an initial sync (re-check this list after Task A4); if it does, the explicit trigger in Task A5 becomes a no-op safety net but is still needed for the test.

- [ ] **Step 5: Write findings into the plan**

Edit the "Confirmed constants" block at the top of Task A3/A4/A5 below with the real values from Steps 2-4. No commit (spike only).

---

### Task A1: Compose — wire `authentik-seed` to `directory-api`

**Files:**
- Modify: `deploy/dev/docker-compose.yml:333-353` (`authentik-seed` service)

- [ ] **Step 1: Add env + dependency to the seed service**

In the `authentik-seed` service `environment:` block, add three keys; and change `depends_on` to also require the API healthy. Replace the service body:

```yaml
  # One-time Authentik OIDC app setup
  authentik-seed:
    networks:
      - azblink-net
    image: python:3.13-slim
    container_name: azblink-authentik-seed
    volumes:
      - ./authentik-seed:/seed:ro
    working_dir: /seed
    command: ["python3", "seed_authentik.py"]
    environment:
      AUTHENTIK_API_URL: http://authentik-server:9000
      AUTHENTIK_BOOTSTRAP_TOKEN: ${AUTHENTIK_BOOTSTRAP_TOKEN:-dev-authentik-api-token}
      OAUTH2_REDIRECT_URIS: ${OAUTH2_REDIRECT_URIS:-}
      OAUTH2_POST_LOGOUT_REDIRECT_URIS: ${OAUTH2_POST_LOGOUT_REDIRECT_URIS:-}
      # LDAP source federation (Flow 2): reach the directory API to self-provision
      # the sync client (dev), and configure the source's server_uri.
      DIRECTORY_API_URL: ${DIRECTORY_API_URL:-http://directory-api:8000}
      DEV_AUTH_TOKEN: ${DEV_AUTH_TOKEN:-}
      LDAP_URI: ${LDAP_URI:-ldap://openldap:389}
      AUTHENTIK_LDAP_SYNC_CLIENT_ID: ${AUTHENTIK_LDAP_SYNC_CLIENT_ID:-authentik-sync}
      # Prod supplies this from vault; dev leaves it empty and self-provisions.
      AUTHENTIK_LDAP_SYNC_PASSWORD: ${AUTHENTIK_LDAP_SYNC_PASSWORD:-}
      # Demo user (LDAP-only) added to IT-Admins post-sync for the SSO demo.
      LDAP_DEMO_SSO_USER: ${LDAP_DEMO_SSO_USER:-mei}
    depends_on:
      authentik-server:
        condition: service_started
      directory-api:
        condition: service_healthy
    restart: "no"
```

- [ ] **Step 2: Restart the stack (compose change → not hot-reload)**

Run: `cd deploy/dev && docker compose up -d --wait`
Expected: `azblink-directory-api` healthy; `azblink-authentik-seed` exits 0.

- [ ] **Step 3: Verify the seed container can reach the API**

Run:
```bash
docker run --rm --network deploy_azblink-net curlimages/curl:latest \
  -s -o /dev/null -w "%{http_code}\n" http://directory-api:8000/api/health
```
Expected: `200`. (Network name may be `azblink-net` or `deploy_azblink-net` — confirm with `docker network ls | grep azblink`.)

- [ ] **Step 4: Commit**

```bash
git add deploy/dev/docker-compose.yml
git commit -m "feat(compose): wire authentik-seed to directory-api for LDAP source"
```
> Note: this touches a governed surface (`deploy_topology`→§06). Committing here is fine — the `ARD:` trailer lands with the governed *spec* edits in Phase C, and arch-guard is warn-only. If you prefer a single governed commit, stage this with Phase C instead.

---

### Task A2: Seed — `ensure_sync_client()` (provision-or-rotate, dev-only)

**Files:**
- Modify: `deploy/dev/authentik-seed/seed_authentik.py` (add config reads near L20-25; add function; mirror the `api_request` + `ensure_*` idempotency style)

- [ ] **Step 1: Add config reads + a directory-API request helper**

Near the existing `os.getenv` block (after `API_TOKEN`, ~L21), add:

```python
# Directory API (for self-provisioning the LDAP sync client in dev)
DIRECTORY_API_URL = os.getenv("DIRECTORY_API_URL", "http://directory-api:8000")
DEV_AUTH_TOKEN = os.getenv("DEV_AUTH_TOKEN", "")
SYNC_CLIENT_ID = os.getenv("AUTHENTIK_LDAP_SYNC_CLIENT_ID", "authentik-sync")
SYNC_CLIENT_PASSWORD = os.getenv("AUTHENTIK_LDAP_SYNC_PASSWORD", "")
LDAP_SOURCE_URI = os.getenv("LDAP_URI", "ldap://openldap:389")
LDAP_DEMO_SSO_USER = os.getenv("LDAP_DEMO_SSO_USER", "mei")
```

Add a directory-API helper (mirrors `api_request` but for the directory API + DEV token):

```python
def directory_api_request(method: str, path: str, data: dict | None = None) -> tuple[int, dict | None]:
    """Call the directory API with the dev bypass token.

    - Returns (status_code, parsed_json_or_None).
    - Unlike api_request(), does NOT raise on 4xx — callers branch on status
      (e.g. 409 → rotate). Non-HTTP errors still propagate.
    """
    url = f"{DIRECTORY_API_URL}{path}"
    headers = {
        "Authorization": f"Bearer {DEV_AUTH_TOKEN}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    body = json.dumps(data).encode() if data else None
    req = Request(url, data=body, headers=headers, method=method)
    try:
        with urlopen(req, timeout=30) as resp:
            payload = None if resp.status == 204 else json.loads(resp.read().decode())
            return resp.status, payload
    except HTTPError as e:
        text = e.read().decode() if e.fp else ""
        try:
            payload = json.loads(text) if text else None
        except json.JSONDecodeError:
            payload = {"detail": text[:500]}
        return e.code, payload
```

- [ ] **Step 2: Add `ensure_sync_client()`**

```python
def ensure_sync_client() -> str | None:
    """Ensure the LDAP sync bind account exists; return its secret.

    - Prod (DEV_AUTH_TOKEN unset): the secret is supplied via
      AUTHENTIK_LDAP_SYNC_PASSWORD (from vault); do NOT self-provision.
    - Dev: POST /api/settings/ldap/clients/provisioned. On 409 (already
      exists), rotate to obtain a fresh show-once secret. Returns the secret.
    """
    if not DEV_AUTH_TOKEN:
        if not SYNC_CLIENT_PASSWORD:
            print("  WARNING: no DEV_AUTH_TOKEN and no AUTHENTIK_LDAP_SYNC_PASSWORD "
                  "— cannot configure LDAP source bind_password")
            return None
        print("  Using supplied AUTHENTIK_LDAP_SYNC_PASSWORD (prod path)")
        return SYNC_CLIENT_PASSWORD

    status, payload = directory_api_request(
        "POST", "/api/settings/ldap/clients/provisioned",
        {"client_id": SYNC_CLIENT_ID, "label": "Authentik LDAP sync"},
    )
    if status == 200:
        print(f"  Provisioned sync client '{SYNC_CLIENT_ID}'")
        return payload["secret"]
    if status == 409:
        print(f"  Sync client '{SYNC_CLIENT_ID}' exists — rotating for a fresh secret")
        rstatus, rpayload = directory_api_request(
            "POST", f"/api/settings/ldap/clients/provisioned/{SYNC_CLIENT_ID}/rotate",
        )
        if rstatus == 200:
            return rpayload["secret"]
        print(f"  ERROR: rotate failed ({rstatus}): {rpayload}")
        return None
    print(f"  ERROR: provision failed ({status}): {payload}")
    return None
```

- [ ] **Step 3: Temporarily call it from `main()` to test in isolation**

After `wait_for_authentik()` in `main()`, add a temporary line `print(ensure_sync_client())` (remove in Task A8). Re-run the seed.

Run: `docker start -a azblink-authentik-seed`
Expected: prints `Provisioned sync client 'authentik-sync'` then a secret on first run; on a second run prints `exists — rotating` then a (different) secret. **Idempotent, never stuck.**

- [ ] **Step 4: Verify the client landed in LDAP + registry**

Run:
```bash
docker exec azblink-openldap ldapsearch -x -H ldap://localhost:389 \
  -D "cn=admin,dc=azblink,dc=com" -w adminpassword \
  -b "ou=clients,dc=azblink,dc=com" "(cn=authentik-sync)" dn
```
Expected: `dn: cn=authentik-sync,ou=clients,dc=azblink,dc=com`.

- [ ] **Step 5: Commit**

```bash
git add deploy/dev/authentik-seed/seed_authentik.py
git commit -m "feat(seed): provision/rotate authentik-sync LDAP client"
```

---

### Task A3: Seed — `get_ldap_source_mapping_pks()`

**Files:**
- Modify: `deploy/dev/authentik-seed/seed_authentik.py` (add function; mirror `get_scope_mapping_pks` at L196-230)

> **Confirmed constants (fill from Task A0 Step 2):** managed IDs = `goauthentik.io/sources/ldap/openldap-uid`, `.../openldap-cn`, `goauthentik.io/sources/ldap/default-mail`.

- [ ] **Step 1: Add the function**

```python
def get_ldap_source_mapping_pks() -> list[str]:
    """PKs for the OpenLDAP user property mappings (uid, cn, mail).

    Mirrors get_scope_mapping_pks(): sweeps /propertymappings/all/ and filters
    on the managed ID. Retries because the worker creates default source
    mappings asynchronously (same race as scope mappings / flows).
    """
    wanted = {
        "goauthentik.io/sources/ldap/openldap-uid",
        "goauthentik.io/sources/ldap/openldap-cn",
        "goauthentik.io/sources/ldap/default-mail",
    }
    for attempt in range(1, SCOPE_MAPPING_RETRIES + 1):
        resp = api_request("GET", "/propertymappings/all/?page_size=200")
        results = resp.get("results", [])
        pks = [m["pk"] for m in results if m.get("managed", "") in wanted]
        if len(pks) == len(wanted):
            for m in results:
                if m.get("managed", "") in wanted:
                    print(f"  Found LDAP mapping: {m['name']} (pk={m['pk']})")
            return pks
        print(f"  Waiting for LDAP source mappings ({len(pks)}/{len(wanted)})... "
              f"attempt {attempt}/{SCOPE_MAPPING_RETRIES}")
        time.sleep(RETRY_DELAY)
    print(f"  WARNING: expected {len(wanted)} LDAP mappings, found {len(pks)}")
    return pks
```

- [ ] **Step 2: Verify against the live API**

Run:
```bash
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  "http://localhost:9000/api/v3/propertymappings/all/?page_size=200" \
  | python3 -c 'import sys,json; w={"goauthentik.io/sources/ldap/openldap-uid","goauthentik.io/sources/ldap/openldap-cn","goauthentik.io/sources/ldap/default-mail"}; print(sorted(m["managed"] for m in json.load(sys.stdin)["results"] if m.get("managed") in w))'
```
Expected: all three managed IDs printed. If any missing, correct `wanted` to the real IDs from Task A0.

- [ ] **Step 3: Commit**

```bash
git add deploy/dev/authentik-seed/seed_authentik.py
git commit -m "feat(seed): resolve OpenLDAP source property-mapping PKs"
```

---

### Task A4: Seed — `ensure_ldap_source()`

**Files:**
- Modify: `deploy/dev/authentik-seed/seed_authentik.py` (add function; GET-then-POST/PATCH idempotency like `ensure_oauth2_provider` at L273-334)

> **Confirmed constants (fill from Task A0 Step 3):** `object_uniqueness_field` — set to `"uid"` unless A0 proved the live default already imports OpenLDAP entries.

- [ ] **Step 1: Add module-level source config near the other constants**

```python
LDAP_SOURCE_SLUG = "azblink-ldap"
LDAP_SOURCE_NAME = "AZBlink Directory LDAP"
LDAP_BASE_DN = os.getenv("LDAP_BASE_DN", "dc=azblink,dc=com")
```

- [ ] **Step 2: Add `ensure_ldap_source(bind_password, mapping_pks)`**

```python
def ensure_ldap_source(bind_password: str, mapping_pks: list[str]) -> str | None:
    """Create or update the OpenLDAP source. Returns the source slug.

    Idempotent: GET by slug, PATCH drifted fields, else POST. bind_password is
    always synced (rotate-on-rerun means it changes each dev run).
    """
    desired = {
        "name": LDAP_SOURCE_NAME,
        "slug": LDAP_SOURCE_SLUG,
        "server_uri": LDAP_SOURCE_URI,
        "bind_cn": f"cn={SYNC_CLIENT_ID},ou=clients,{LDAP_BASE_DN}",
        "bind_password": bind_password,
        "base_dn": LDAP_BASE_DN,
        "additional_user_dn": "ou=people",
        "user_object_filter": "(&(objectClass=inetOrgPerson)(uid=*))",
        "object_uniqueness_field": "uid",   # CRITICAL — default objectSid imports 0 OpenLDAP users
        "user_property_mappings": mapping_pks,
        "sync_users": True,
        "sync_users_password": False,        # read-minus-secrets can't read userPassword; bind-based login
        "password_login_update_internal_password": False,
        "sync_groups": False,               # non-goal ②: no LDAP group/RBAC sync
        "delete_not_found_objects": False,  # deactivation handled by Plane A {DISABLED} swap
        "enabled": True,
    }
    resp = api_request("GET", f"/sources/ldap/?slug={LDAP_SOURCE_SLUG}")
    results = resp.get("results", [])
    if results:
        existing = results[0]
        pk = existing["pk"]
        patch = {k: v for k, v in desired.items()
                 if k in ("bind_password",) or existing.get(k) != v}
        # user_property_mappings compares as a set (order-insensitive)
        if set(existing.get("user_property_mappings", [])) == set(mapping_pks):
            patch.pop("user_property_mappings", None)
        if patch:
            api_request("PATCH", f"/sources/ldap/{pk}/", patch)
            print(f"  Patched LDAP source: {', '.join(sorted(patch.keys()))}")
        else:
            print(f"  LDAP source '{LDAP_SOURCE_SLUG}' already current")
        return LDAP_SOURCE_SLUG
    api_request("POST", "/sources/ldap/", desired)
    print(f"  Created LDAP source '{LDAP_SOURCE_SLUG}'")
    return LDAP_SOURCE_SLUG
```

- [ ] **Step 3: Wire A2+A3+A4 behind a single `ensure_ldap_federation()` and call from `main()` temporarily**

```python
def ensure_ldap_federation():
    """Provision sync client → resolve mappings → ensure source → trigger sync."""
    secret = ensure_sync_client()
    if not secret:
        print("  Skipping LDAP source (no sync secret)")
        return
    mapping_pks = get_ldap_source_mapping_pks()
    slug = ensure_ldap_source(secret, mapping_pks)
    if slug:
        trigger_ldap_sync(slug)   # added in Task A5
```
(For this task, stub `trigger_ldap_sync` as `def trigger_ldap_sync(slug): pass` — replaced in A5.) Add a temporary `ensure_ldap_federation()` call in `main()`.

- [ ] **Step 4: Run the seed + verify the source exists with the right uniqueness field**

Run: `docker start -a azblink-authentik-seed`
Then:
```bash
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  "http://localhost:9000/api/v3/sources/ldap/?slug=azblink-ldap" \
  | python3 -c 'import sys,json; s=json.load(sys.stdin)["results"][0]; print({k:s[k] for k in ("slug","server_uri","bind_cn","additional_user_dn","object_uniqueness_field","sync_users","sync_groups")})'
```
Expected: `object_uniqueness_field` = `uid`, `bind_cn` = `cn=authentik-sync,ou=clients,dc=azblink,dc=com`, `sync_users` True, `sync_groups` False.

- [ ] **Step 5: Commit**

```bash
git add deploy/dev/authentik-seed/seed_authentik.py
git commit -m "feat(seed): create/patch Authentik OpenLDAP source (bind-based, uid uniqueness)"
```

---

### Task A5: Seed — `trigger_ldap_sync()` (trigger + poll)

**Files:**
- Modify: `deploy/dev/authentik-seed/seed_authentik.py` (replace the A4 stub)

> **Confirmed mechanism (from Task A0 Step 4):** trigger via `POST /api/v3/tasks/schedules/{id}/send/`; read progress via `GET /api/v3/sources/ldap/{slug}/sync/status/`. Adjust the schedule-lookup filter to whatever A0 revealed.

- [ ] **Step 1: Replace the stub with the real function**

```python
def trigger_ldap_sync(slug: str) -> None:
    """Fire an initial sync and poll to completion.

    Finds the source's sync schedule by rel_obj_id == source pk (A0-confirmed:
    schedules carry rel_obj_id + actor_name, NOT the slug), POSTs /send/, then
    polls sync/status/. Retries the schedule lookup — the worker registers the
    schedule asynchronously after the source is created.
    """
    resp = api_request("GET", f"/sources/ldap/?slug={slug}")
    results = resp.get("results", [])
    if not results:
        print(f"  WARNING: source '{slug}' not found — cannot trigger sync")
        return
    source_pk = str(results[0]["pk"])

    schedule_id = None
    for attempt in range(1, FLOW_RETRIES + 1):
        resp = api_request("GET", "/tasks/schedules/?page_size=200")
        matches = [s for s in resp.get("results", [])
                   if str(s.get("rel_obj_id")) == source_pk]
        if matches:
            # Prefer the sync schedule if a source has more than one.
            sync = [s for s in matches if "sync" in (s.get("actor_name") or "").lower()]
            schedule_id = (sync or matches)[0]["id"]
            break
        print(f"  Waiting for LDAP sync schedule... attempt {attempt}/{FLOW_RETRIES}")
        time.sleep(RETRY_DELAY)
    if not schedule_id:
        print("  WARNING: no sync schedule found — source will sync on its next cycle")
        return

    api_request("POST", f"/tasks/schedules/{schedule_id}/send/")
    print(f"  Triggered LDAP sync (schedule {schedule_id})")

    # Poll sync/status/. Response shape is best-effort — confirm live in Step 2;
    # the authoritative success signal is "LDAP users now present in Authentik".
    for attempt in range(1, MAX_RETRIES + 1):
        status = api_request("GET", f"/sources/ldap/{slug}/sync/status/")
        if isinstance(status, dict):
            if status.get("is_running") is False:
                print("  LDAP sync complete")
                return
            tasks = status.get("tasks", [])
            if tasks and "is_running" not in status and not any(
                (t.get("status") or "").lower() in ("running", "unknown", "") for t in tasks
            ):
                print(f"  LDAP sync complete ({len(tasks)} task(s))")
                return
        time.sleep(RETRY_DELAY)
    print("  WARNING: LDAP sync did not report completion in time")
```

> **Implementer:** first `curl -s -H "Authorization: Bearer dev-authentik-api-token" "http://localhost:9000/api/v3/sources/ldap/azblink-ldap/sync/status/" | python3 -m json.tool` after the source exists to confirm whether the shape uses `is_running` or a `tasks[].status` list, and tighten the parse to match. Don't block the task on the poll — Step 2's user-count check is the real gate.

- [ ] **Step 2: Run the seed + verify users imported (the payoff — proves `object_uniqueness_field` works)**

Run: `docker start -a azblink-authentik-seed`
Then:
```bash
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  "http://localhost:9000/api/v3/core/users/?page_size=200" \
  | python3 -c 'import sys,json; u=json.load(sys.stdin)["results"]; print("total:",len(u)); print("ldap-ish:",[x["username"] for x in u if x["username"] in ("mei","alex","alanl","ewu","hsu")])'
```
Expected: **more than the 3 pre-existing Authentik users** — LDAP users (`mei`, `alex`, …) now present. If still only 3, `object_uniqueness_field` is wrong → revisit A4 Step 2 (this is the exact silent-zero-import failure).

- [ ] **Step 3: Verify a UserSourceConnection links them to the source**

```bash
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  "http://localhost:9000/api/v3/sources/user_connections/ldap/?page_size=200" \
  | python3 -c 'import sys,json; print("links:",json.load(sys.stdin)["pagination"]["count"])'
```
Expected: `links` > 0.

- [ ] **Step 4: Commit**

```bash
git add deploy/dev/authentik-seed/seed_authentik.py
git commit -m "feat(seed): trigger + poll initial LDAP source sync"
```

---

### Task A6: Seed — remove local `alanl`, delete any pre-existing one

**Files:**
- Modify: `deploy/dev/authentik-seed/seed_authentik.py` (`SEED_USERS` L71-80; add `delete_local_user`)

- [ ] **Step 1: Empty `SEED_USERS`**

Replace L71-80:
```python
# Seed users — alanl now federates from LDAP; keep akadmin local (break-glass).
SEED_USERS: list[dict] = []
```
(`ensure_seed_users()` already guards empty at L402-404 — safe.)

- [ ] **Step 2: Add `delete_local_user()` (first DELETE usage — no existing precedent, `api_request` supports it)**

```python
def delete_local_user(username: str) -> None:
    """Delete a LOCAL (internal, non-LDAP) Authentik user so it comes from LDAP.

    Skip-if-exists in ensure_seed_users can't remove an already-created local
    account; on existing stacks it would shadow the LDAP user (same password),
    so a 'successful' SSO would prove nothing about the LDAP path. Only deletes
    users with no LDAP source connection.
    """
    resp = api_request("GET", f"/core/users/?username={username}")
    for u in resp.get("results", []):
        # 'internal' type + no source link ⇒ locally-seeded, safe to delete.
        if u.get("type") == "internal":
            api_request("DELETE", f"/core/users/{u['pk']}/")
            print(f"  Deleted local user '{username}' (pk={u['pk']}) — now sourced from LDAP")
```

- [ ] **Step 3: Verify deletion is idempotent + correct**

Manually recreate a local alanl (simulating an old stack), then run the helper:
```bash
# create a fake local alanl
curl -s -X POST -H "Authorization: Bearer dev-authentik-api-token" -H "Content-Type: application/json" \
  http://localhost:9000/api/v3/core/users/ -d '{"username":"alanl","name":"Old Local","type":"internal"}' >/dev/null
docker start -a azblink-authentik-seed   # runs delete_local_user('alanl') via main() once wired (A8); or call ad hoc
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  "http://localhost:9000/api/v3/core/users/?username=alanl" \
  | python3 -c 'import sys,json; [print(u["username"],u.get("type"),[s for s in u.get("groups_obj",[])]) for u in json.load(sys.stdin)["results"]]'
```
Expected after wiring: the `internal` alanl is gone; if LDAP has an `alanl`, only the LDAP-sourced one remains.

- [ ] **Step 4: Commit**

```bash
git add deploy/dev/authentik-seed/seed_authentik.py
git commit -m "feat(seed): drop local alanl + delete pre-existing local copy (LDAP-sourced)"
```

---

### Task A7: Seed — add the demo LDAP user to IT-Admins post-sync

**Files:**
- Modify: `deploy/dev/authentik-seed/seed_authentik.py` (add `add_ldap_user_to_admin_group`; reuse the group-add pattern from `ensure_admin_group` L384-393)

- [ ] **Step 1: Add the function**

```python
def add_ldap_user_to_admin_group(username: str) -> None:
    """Add a synced LDAP user to IT-Admins so the SSO demo lands in the admin UI.

    Safe-by-default: sync grants NO admin rights; this is an explicit demo grant.
    No-op if the user isn't present yet (sync incomplete / user absent in LDAP).
    """
    resp = api_request("GET", f"/core/groups/?name={ADMIN_GROUP_NAME}")
    groups = resp.get("results", [])
    if not groups:
        print(f"  WARNING: group '{ADMIN_GROUP_NAME}' not found")
        return
    group_pk = groups[0]["pk"]

    resp = api_request("GET", f"/core/users/?username={username}")
    users = resp.get("results", [])
    if not users:
        print(f"  Demo user '{username}' not synced yet — skipping admin grant")
        return
    user = users[0]
    user_groups = [g["pk"] for g in user.get("groups_obj", [])]
    if group_pk in user_groups:
        print(f"  '{username}' already in '{ADMIN_GROUP_NAME}'")
        return
    user_groups.append(group_pk)
    api_request("PATCH", f"/core/users/{user['pk']}/", {"groups": user_groups})
    print(f"  Added demo user '{username}' to '{ADMIN_GROUP_NAME}'")
```

- [ ] **Step 2: Verify (after A8 wiring runs it)**

```bash
curl -s -H "Authorization: Bearer dev-authentik-api-token" \
  "http://localhost:9000/api/v3/core/users/?username=mei" \
  | python3 -c 'import sys,json; u=json.load(sys.stdin)["results"]; print([g["name"] for g in u[0]["groups_obj"]] if u else "mei not synced")'
```
Expected: `['IT-Admins']` if `mei` exists in LDAP. If `mei` isn't in the dev LDAP, set `LDAP_DEMO_SSO_USER` to a user that is (check `just ldap-users`), or provision one.

- [ ] **Step 3: Commit**

```bash
git add deploy/dev/authentik-seed/seed_authentik.py
git commit -m "feat(seed): grant demo LDAP user admin group for SSO demo"
```

---

### Task A8: Seed — wire everything into `main()` in the correct order

**Files:**
- Modify: `deploy/dev/authentik-seed/seed_authentik.py` (`main()` L555-589)

- [ ] **Step 1: Remove the temporary calls from A2-A4 and add the real sequence**

In `main()`, after step 5 (`ensure_seed_users()`) and before the flow-titles/branding steps, insert:

```python
    print("\n5b. Removing local users now sourced from LDAP...")
    delete_local_user("alanl")

    print("\n5c. Ensuring LDAP source federation (sync client + source + initial sync)...")
    ensure_ldap_federation()

    print("\n5d. Granting demo LDAP user admin access...")
    add_ldap_user_to_admin_group(LDAP_DEMO_SSO_USER)
```

Order rationale: IT-Admins exists after step 4 (`ensure_admin_group`); `delete_local_user` must precede sync so the LDAP `alanl` isn't shadowed; the demo grant runs last (needs the user synced). `ensure_ldap_federation` blocks on sync completion (A5), so the grant sees synced users.

- [ ] **Step 2: Full clean re-run (idempotency proof)**

Run: `docker start -a azblink-authentik-seed` twice.
Expected both times: exits 0; second run prints "already current" / "already exists — rotating" / "already in IT-Admins" — no errors, no duplicates.

- [ ] **Step 3: Fresh-stack proof**

Run: `cd deploy/dev && just reset && just up-bg && just health`
Then re-run the Task A5 Step 2 verify (LDAP users present in Authentik).
Expected: on a from-zero stack, LDAP users import and the source exists.

- [ ] **Step 4: Commit**

```bash
git add deploy/dev/authentik-seed/seed_authentik.py
git commit -m "feat(seed): wire LDAP source federation into main() sequence"
```

---

# Phase B — Integration test

### Task B1: `tests/test_ldap_source.py` — sync regression

**Files:**
- Create (needs approval): `tests/test_ldap_source.py`
- Reference: `tests/conftest.py` (`client`, `ldap_conn`, `_authentik_api`), `tests/test_xmpp_e2e.py` (full-chain precedent)

- [ ] **Step 1: Get new-file approval, then write the test**

```python
"""Integration test — Authentik LDAP source federation.
- Asserts the source exists, a fresh LDAP-only user syncs into Authentik,
  and a UserSourceConnection links it (username presence alone is insufficient).
- Requires the running Docker stack (directory-api + Authentik + OpenLDAP).
"""
import time
import uuid

import pytest

from conftest import _authentik_api  # low-level Authentik Admin API helper

LDAP_SOURCE_SLUG = "azblink-ldap"


def _trigger_sync_and_wait(timeout_s: int = 90) -> None:
    """Fire the source sync schedule and wait for it to settle.

    Matches the schedule by rel_obj_id == source pk (A0-confirmed); schedules
    do not carry the slug.
    """
    srcs = _authentik_api("GET", f"/sources/ldap/?slug={LDAP_SOURCE_SLUG}").get("results", [])
    assert srcs, "LDAP source not found — is it created?"
    source_pk = str(srcs[0]["pk"])
    schedules = _authentik_api("GET", "/tasks/schedules/?page_size=200").get("results", [])
    matches = [s for s in schedules if str(s.get("rel_obj_id")) == source_pk]
    assert matches, "no sync schedule for the LDAP source (rel_obj_id match)"
    sync = [s for s in matches if "sync" in (s.get("actor_name") or "").lower()]
    sched = (sync or matches)[0]
    _authentik_api("POST", f"/tasks/schedules/{sched['id']}/send/")
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        status = _authentik_api("GET", f"/sources/ldap/{LDAP_SOURCE_SLUG}/sync/status/")
        if status.get("is_running") is False:
            return
        tasks = status.get("tasks", [])
        if tasks and "is_running" not in status and not any(
            (t.get("status") or "").lower() in ("running", "unknown", "") for t in tasks
        ):
            return
        time.sleep(3)
    pytest.fail("LDAP sync did not complete in time")


def test_ldap_source_exists():
    """The seed created the OpenLDAP source with bind-based, uid-unique config."""
    results = _authentik_api("GET", f"/sources/ldap/?slug={LDAP_SOURCE_SLUG}").get("results", [])
    assert results, "LDAP source not found — seed did not run ensure_ldap_source()"
    src = results[0]
    assert src["object_uniqueness_field"] == "uid"
    assert src["sync_users"] is True
    assert src["sync_users_password"] is False
    assert src["bind_cn"].startswith("cn=authentik-sync,ou=clients")


def test_ldap_only_user_syncs_and_links(client, ldap_conn):
    """A directory-created LDAP user imports into Authentik with a source link."""
    uid = f"ldapsrc-{uuid.uuid4().hex[:8]}"
    # Create the user via the directory API on a UC-enabled profile so it lands
    # in ou=people with a userPassword. Reuse the same helper the e2e test uses.
    from test_xmpp_e2e import _create_uc_user_for_sso
    _create_uc_user_for_sso(client, uid, "LdapSrcTest_" + uuid.uuid4().hex[:8])

    _trigger_sync_and_wait()

    users = _authentik_api("GET", f"/core/users/?username={uid}").get("results", [])
    assert users, f"user {uid} was not imported into Authentik"
    ak_pk = users[0]["pk"]

    # The decisive assertion: a UserSourceConnection ties this user to the source
    # (a coincidentally-named local user would match username but not this).
    conns = _authentik_api(
        "GET", f"/sources/user_connections/ldap/?user={ak_pk}"
    ).get("results", [])
    assert conns, f"no UserSourceConnection for {uid} — imported but not source-linked"

    # Cleanup: delete the Authentik user + the directory/LDAP user.
    _authentik_api("DELETE", f"/core/users/{ak_pk}/")
    client.delete(f"/api/users/{uid}")
```

> Confirm `_create_uc_user_for_sso` is importable from `test_xmpp_e2e` (it is used there for setup). If it isn't module-level, inline an equivalent `POST /api/users` with a UC profile. Confirm the directory delete route (`DELETE /api/users/{uid}`) against `main.py`.

- [ ] **Step 2: Run only this test**

Run: `pytest tests/test_ldap_source.py -v --tb=short`
Expected: 2 passed. If `test_ldap_only_user_syncs_and_links` fails at the import assert, the seed sync isn't picking up new users between scheduled runs — that's the documented sync-latency edge case; the explicit trigger in the test covers it.

- [ ] **Step 3: Run the full suite (no regressions)**

Run: `just test-quick`
Expected: prior pass count + 2, no failures.

- [ ] **Step 4: Commit**

```bash
git add tests/test_ldap_source.py
git commit -m "test(ldap-source): assert federation sync + UserSourceConnection"
```

---

# Phase C — Governance (ARD-007 + spec §04/§06 + README/CHANGELOG)

> This is the governed-surface commit. The final Phase C commit MUST carry `ARD: ARD-007` (Task C6). ARD-007 may be `status: proposed` for this PR (SOP allows `ARD:` to reference a proposed ARD during PR-1).

### Task C1: Create ARD-007

**Files:**
- Create (needs approval): `docs/architecture/decisions/ARD-007-authentik-ldap-source.md`
- Reference: `_TEMPLATE.md`, `ARD-006` (precedent), `ARD-002` (referenced)

- [ ] **Step 1: Get approval, copy the template, fill it in**

```markdown
---
status: proposed
accepted_at:
decision_effective_date:
supersedes: []
superseded_by: []
pr:
spec_sections_affected: ["04-authentication", "06-deployment"]
---
<!-- summary:begin -->
<!-- Auto-generated from frontmatter. Do not edit by hand. -->
<!-- summary:end -->

# ARD-007: Authentik LDAP Source (LDAP-backed Web SSO)

## Context

ARD-002 made Authentik the sole web-auth path, backed by Authentik's internal
user DB — disjoint from the platform OpenLDAP that holds every UC user's
`userPassword`. A directory user provisioned for XMPP/SIP could not log into the
web admin UI; the two stores shared no identities (0 LDAP sources in Authentik).
ARD-006 shipped provisioned LDAP clients (`ou=clients`, read-minus-secrets),
giving us a dogfoodable, least-privilege bind account.

## Decision

Federate identity one-directionally: Authentik reads the platform OpenLDAP via an
LDAP **source**. LDAP stays the source of truth; Authentik's user store becomes
LDAP-backed. ARD-002 is preserved (Authentik remains the sole web-auth path) and
the core invariant holds (Authentik depends on LDAP, never the reverse — UC works
with Authentik absent).

- **Sync account:** dogfooded provisioned client `cn=authentik-sync,ou=clients`
  (ARD-006), read-minus-secrets. Sync reads only uid/cn/mail; it never reads a
  password.
- **Login:** Authentik `LDAPBackend` binds AS the user to validate the password —
  no password copied into Authentik (`sync_users_password=false`). Identical
  `userPassword` the PED uses.
- **Uniqueness:** `object_uniqueness_field=uid` (the model default `objectSid` is
  AD-only and would import zero OpenLDAP users).
- **Authorization (safe by default):** sync grants no admin rights. `require_admin`
  gates on `OIDC_ADMIN_GROUP`; `require_permission` checks ORGDB RBAC by
  `preferred_username` first. **Activation note:** synced usernames = uid = the
  ORGDB permission key, so any pre-existing (previously inert) RBAC grants for
  directory users activate when sync ships. This is intended but is an
  authorization-activation event, not a no-op.
- **Deactivation:** `delete_not_found_objects=false`; Plane A termination/suspend
  swaps `userPassword`→`{DISABLED}`/`{SUSPENDED}`, so bind-based login fails
  without deleting the Authentik account. Live session revocation still relies on
  `terminate_user_access()` (ARD-002).
- **Groups:** `sync_groups=false` (directory-driven admin RBAC via LDAP group sync
  is a non-goal here — deferred).
- **Secret lifecycle:** the provision API mints the secret show-once. Dev: the seed
  self-provisions (rotate-on-409). Prod: the secret is provisioned once and supplied
  via vault → `AUTHENTIK_LDAP_SYNC_PASSWORD`; the seed does not self-provision.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Amend ARD-002 | ARD-002's decision (Authentik sole web-auth path) is unchanged; this adds where identities come from — a new capability. ARDs are append-only. Precedent: ARD-006 chose a new ARD over amending ARD-001. |
| Copy password hashes into Authentik (`sync_users_password=true`) | Read-minus-secrets can't read `userPassword`, and duplicating the hash widens the leak surface. Bind-based login needs no copy. |
| Reverse federation (Authentik LDAP outpost as the PED's directory) | Breaks the single-LDAP UC model — UC attrs live only on the platform LDAP. |
| LDAP group sync for admin RBAC now | Larger surface; admin grant stays manual/ORGDB for v1. Deferred, not rejected. |

## Consequences

**Positive:** one identity for UC + web SSO; least-privilege dogfooded bind account; no password copy; ARD-002 + UC-without-Authentik invariant intact.

**Negative / trade-offs:** freshly provisioned users can't SSO until the next sync (latency); LDAP-deleted users leave orphaned (deactivated-on-bind) Authentik accounts; the prod secret must be provisioned out-of-band into vault (the API mints show-once).

**Risks:** a wrong `object_uniqueness_field` imports zero users silently (mitigated: explicit `uid` + integration test asserts import + link). The `ou=clients` read ACL must remain secret-complete (ARD-006 guard).

## References

- Design: `docs/superpowers/specs/2026-07-03-authentik-ldap-source-design.md`
- Plan: `docs/superpowers/plans/2026-07-03-authentik-ldap-source.md`
- Related ARDs: ARD-002 (Authentik-only auth — this makes its store LDAP-backed; ARD-002 already references "next LDAP Source sync ~5 min"), ARD-006 (provisioned clients — the sync account), ARD-001 (single LDAP)
- Spec: `spec/04-authentication.md`, `spec/06-deployment.md`
- Cross-ref: `spec/08-integration-points.md:104` already notes `userPassword ... web login (via Authentik LDAP source)`

## Amendments

<!-- Append-only. Each amendment adds a dated heading + PR link. -->
```

- [ ] **Step 2: Regenerate the summary block if a hook/just recipe exists**

Run: `just --list | grep -i ard` — if `new-ard`/a summary hook exists, run it; else leave the auto-summary markers (a pre-commit hook fills them).

- [ ] **Step 3: Commit** (bundled in Task C6)

---

### Task C2: Spec §04 — LDAP-backed Plane B

**Files:**
- Modify: `docs/architecture/spec/04-authentication.md:1` (spec-meta), `:9-16` (Plane table + Plane B paragraph)

- [ ] **Step 1: Bump the section spec-meta**

Change L1 from `version: "1.0.0", last_updated: "2026-03-07"` to `version: "1.1.0", last_updated: "2026-07-03"`.

- [ ] **Step 2: Update the Plane B store cell + add a paragraph**

Change the Plane B table row store cell from `Authentik internal DB` to `Authentik (LDAP-backed via source — ARD-007)`. After the "**Plane B** authenticates admin UI users via Authentik OIDC…" paragraph, add:

```markdown
Since ARD-007, Plane B's user store is federated from the platform OpenLDAP via
an Authentik **LDAP source** (`azblink-ldap`). Authentik binds as the provisioned
`cn=authentik-sync,ou=clients` client (read-minus-secrets, ARD-006) to sync
`uid→username / cn→name / mail→email` from `ou=people`; at login Authentik's
`LDAPBackend` binds AS the user to validate the same `userPassword` the PED uses —
no password is copied into Authentik (`sync_users_password=false`). One identity
serves UC (Plane A) and web SSO (Plane B). Authorization is unchanged: sync grants
no admin rights; `require_permission` still gates on ORGDB RBAC (by
`preferred_username`) then `OIDC_ADMIN_GROUP`. [PROPOSED: ARD-007]
```

- [ ] **Step 3: Verify markdown renders + arch-guard marker resolves**

Run: `just arch-guard` (warn-only) — confirm `[PROPOSED: ARD-007]` resolves to the new ARD.
Expected: no marker-consistency error for ARD-007.

- [ ] **Step 4: Commit** (bundled in Task C6)

---

### Task C3: Spec §06 — bootstrap step + seed dependency

**Files:**
- Modify: `docs/architecture/spec/06-deployment.md:1` (spec-meta), `:23-28` (authentik-seed dep row), `:124-150` (§6.5 sequence)

- [ ] **Step 1: Bump the section spec-meta**

L1 → `version: "1.1.0", last_updated: "2026-07-03"`.

- [ ] **Step 2: Update the authentik-seed dependency row**

Change the `authentik-seed` row's dependency cell from `authentik-server (started)` to `authentik-server (started), directory-api (healthy)` and its description to `One-shot OAuth2 app + LDAP source bootstrap`.

- [ ] **Step 3: Add an LDAP-source step to the §6.5 bootstrap sequence**

After the "**Test users**" bullet in the numbered "Once reachable, the script creates:" list, add:

```markdown
   - **LDAP source** (ARD-007) -- provisions the `authentik-sync` client via the
     directory API (dev; prod supplies the secret from vault), resolves the
     OpenLDAP property mappings, creates the `azblink-ldap` source
     (`object_uniqueness_field=uid`, bind-based login, `sync_users_password=false`),
     triggers an initial sync, then removes the now-LDAP-sourced local `alanl`.
```

And append to the "API Gotchas" list:
```markdown
- LDAP source `object_uniqueness_field` defaults to `objectSid` (AD) — must be set
  to `uid` for OpenLDAP or the sync imports zero users silently
- The sync client secret is minted show-once by the provision API; the seed
  rotates-on-rerun (dev) or reads `AUTHENTIK_LDAP_SYNC_PASSWORD` from vault (prod)
```

- [ ] **Step 4: Commit** (bundled in Task C6)

---

### Task C4: README ARD table + version bump

**Files:**
- Modify: `docs/architecture/README.md:1` + `:4` (spec-meta + badge), `:54-63` (ARD table), `:6-20` (rationale block)

- [ ] **Step 1: Bump the spec version `1.2.1 → 1.3.0` (MINOR — new integration point / auth capability)**

L1: `version: "1.3.0", last_updated: "2026-07-03"`. L4 badge: `**Version:** 1.3.0 | **Last Updated:** 2026-07-03 | **Status:** Current`.

- [ ] **Step 2: Add the ARD-007 row** (after the ARD-006 row):

```markdown
| [ARD-007](decisions/ARD-007-authentik-ldap-source.md) | Authentik LDAP Source (LDAP-backed Web SSO) | `proposed` | 2026-07-03 | (PR-1) |
```

- [ ] **Step 3: Add a rationale line** to the README history block (`:6-20`):
```markdown
- `1.3.0` (MINOR) adds the Authentik LDAP source — LDAP-backed web SSO (ARD-007).
```

- [ ] **Step 4: Commit** (bundled in Task C6)

---

### Task C5: Create the architecture CHANGELOG

**Files:**
- Create (needs approval): `docs/architecture/CHANGELOG.md`

> SOP mandates a CHANGELOG (SOP.md:17,25,83) but the file does not exist — history currently lives only in the README rationale comment. Create it with the 1.3.0 entry and backfill the two prior known versions from the README block.

- [ ] **Step 1: Get approval, then create the file**

```markdown
# Architecture Specification Changelog

All notable changes to the architecture specification are documented here.
Format follows `SOP.md`. The spec as a whole uses SemVer (`README.md` spec-meta).

## [1.3.0] - 2026-07-03

### Added
- ARD-007: Authentik LDAP Source (LDAP-backed Web SSO). Authentik federates
  identity from the platform OpenLDAP via an LDAP source; bind-based login,
  no password copy; dogfooded `cn=authentik-sync` provisioned client.

### Changed
- §04 Authentication — Plane B user store is now LDAP-backed (bumped to 1.1.0).
- §06 Deployment — §6.5 bootstrap adds the LDAP-source step; authentik-seed now
  depends on directory-api (bumped to 1.1.0).

### References
- ARD-007

## [1.2.1] - 2026-07-03

### Changed
- Formalized the shipped LDAP client provisioning capability as ARD-006 (PATCH).

### References
- ARD-006, PR #179, #181

## [1.2.0] - 2026-07-03

### Added
- LDAP client provisioning & reconciliation capability (ARD-006).
```

- [ ] **Step 2: Commit** (bundled in Task C6)

---

### Task C6: Governed commit with the ARD trailer

- [ ] **Step 1: Run the arch guard on the staged diff**

Run: `just arch-guard`
Expected (warn-only): reports the touched surfaces. Confirm `deploy/dev/docker-compose.yml` (→06) is covered by the trailer and no marker errors.

- [ ] **Step 2: Stage + commit all Phase C files together**

```bash
git add docs/architecture/decisions/ARD-007-authentik-ldap-source.md \
        docs/architecture/spec/04-authentication.md \
        docs/architecture/spec/06-deployment.md \
        docs/architecture/README.md \
        docs/architecture/CHANGELOG.md
git commit -m "docs(arch): ARD-007 Authentik LDAP source; spec §04/§06 + v1.3.0

ARD: ARD-007"
```

> Trailer coverage: ARD-007's `spec_sections_affected` = `["04-authentication","06-deployment"]` covers the §04/§06 edits and the `docker-compose.yml` deploy_topology surface (→06). `main.py` is NOT touched (no api_contracts surface). `seed_authentik.py` is not a governed surface.

---

# Phase D — Ansible / prod rollout

> Prod has `DEV_AUTH_TOKEN=""` (prod-safety), so the seed can't self-provision. Prod flow: provision the sync client once (operator or a one-shot task) → capture the show-once secret → store in vault → the seed reads `AUTHENTIK_LDAP_SYNC_PASSWORD` and configures the source. Ansible also applies the `ou=clients` ACL idempotently on already-initialized LDAP volumes.

### Task D1: group_vars + env template

**Files:**
- Modify: `deploy/ansible/inventories/dev/group_vars/all/main.yml`, `.../vault.yml`, `roles/azblink_app/templates/env.j2`

- [ ] **Step 1: Add non-secret vars to `main.yml`**

```yaml
authentik_ldap_sync_client_id: authentik-sync
ldap_demo_sso_user: mei
```

- [ ] **Step 2: Add the secret placeholder to `vault.yml`** (dev throwaway; prod = ansible-vault):

```yaml
authentik_ldap_sync_password: ""   # prod: provisioned show-once secret; dev: "" → seed self-provisions
```

- [ ] **Step 3: Render into `env.j2`** (after the Authentik block):

```jinja
# Authentik LDAP source (ARD-007)
AUTHENTIK_LDAP_SYNC_CLIENT_ID={{ authentik_ldap_sync_client_id }}
LDAP_DEMO_SSO_USER={{ ldap_demo_sso_user }}
{% if authentik_ldap_sync_password | default('') | length > 0 %}
AUTHENTIK_LDAP_SYNC_PASSWORD={{ authentik_ldap_sync_password }}
{%- endif %}
```

- [ ] **Step 4: Commit**

```bash
git add deploy/ansible/inventories/dev/group_vars/all/main.yml \
        deploy/ansible/inventories/dev/group_vars/all/vault.yml \
        deploy/ansible/roles/azblink_app/templates/env.j2
git commit -m "feat(ansible): LDAP source vars + env rendering"
```

### Task D2: Idempotent ACL apply task

**Files:**
- Create (needs approval): `deploy/ansible/roles/azblink_app/tasks/ldap_source.yml`
- Modify: `roles/azblink_app/tasks/main.yml` (import after `deploy.yml`)

- [ ] **Step 1: Get approval, then write the ACL-apply task**

```yaml
# Apply the ou=clients read-minus-secrets ACL on already-initialized LDAP volumes.
# The bootstrap ldif only runs at osixia fresh init; upgrades need this.
- name: Copy ou=clients ACL into the openldap container
  ansible.builtin.command:
    cmd: >-
      docker cp {{ install_dir }}/{{ deploy_subdir }}/ldap/ldap-clients-acl.ldif
      azblink-openldap:/tmp/acl.ldif
  changed_when: true

- name: Apply the ou=clients ACL (idempotent — replace olcAccess)
  ansible.builtin.command:
    cmd: >-
      docker exec azblink-openldap
      ldapmodify -Y EXTERNAL -H ldapi:/// -f /tmp/acl.ldif
  register: _acl_apply
  changed_when: "'modifying entry' in _acl_apply.stdout"
  failed_when:
    - _acl_apply.rc != 0
    - "'Type or value exists' not in _acl_apply.stderr"
```

> The ldif does `replace: olcAccess`, so re-applying is safe (declarative replace, not add). `failed_when` tolerates the no-op case.

- [ ] **Step 2: Import it from `main.yml`** after the `deploy.yml` import:

```yaml
- import_tasks: ldap_source.yml
  tags: [ldap_source]
```

- [ ] **Step 3: Verify (dev converge, ACL tag only)**

Run: `cd deploy/ansible && ansible-playbook -i inventories/dev site.yml --tags ldap_source --check` (or a real converge on a dev host).
Expected: task runs; second run reports ok/changed appropriately without error.

- [ ] **Step 4: Commit**

```bash
git add deploy/ansible/roles/azblink_app/tasks/ldap_source.yml \
        deploy/ansible/roles/azblink_app/tasks/main.yml
git commit -m "feat(ansible): idempotent ou=clients ACL apply for upgrades"
```

### Task D3: verify.yml — assert the source exists

**Files:**
- Modify: `deploy/ansible/roles/azblink_app/tasks/verify.yml`

- [ ] **Step 1: Add a poll next to the existing Authentik verifies**

```yaml
- name: Verify Authentik LDAP source exists
  ansible.builtin.uri:
    url: "{{ authentik_api_url }}/api/v3/sources/ldap/?slug=azblink-ldap"
    headers:
      Authorization: "Bearer {{ authentik_bootstrap_token }}"
    return_content: true
  register: _ldap_source
  until: (_ldap_source.json.pagination.count | default(0)) == 1
  retries: "{{ seed_verify_retries }}"
  delay: "{{ seed_verify_delay }}"
```

- [ ] **Step 2: Verify**

Run: `ansible-playbook -i inventories/dev site.yml --tags verify` (against a dev host with the stack up).
Expected: the new poll passes (count == 1).

- [ ] **Step 3: Commit**

```bash
git add deploy/ansible/roles/azblink_app/tasks/verify.yml
git commit -m "feat(ansible): verify LDAP source after seed"
```

### Task D4: Document the prod one-time provisioning step

**Files:**
- Modify: `deploy/ansible/README.md` (or the role README) — a runbook note

- [ ] **Step 1: Add a runbook note** describing the prod bootstrap: (1) provision the sync client once via the UI (`/configuration/ldap-clients`) or an admin-token API call, (2) copy the show-once secret into `vault.yml` as `authentik_ldap_sync_password`, (3) `ansible-vault encrypt`, (4) converge — the seed then configures the source with the vault secret.

- [ ] **Step 2: Commit**

```bash
git add deploy/ansible/README.md
git commit -m "docs(ansible): prod LDAP-source sync-client provisioning runbook"
```

---

## Live SSO demo (manual verification — not automated)

After Phase A on the dev stack:
1. Ensure the demo user (`mei` or your `LDAP_DEMO_SSO_USER`) exists in LDAP with a known password (`just ldap-users`; reset/provision if unknown — do NOT reuse `alanl`, whose historical local duplicate would false-positive the demo).
2. `/browse` (gstack) → open `http://localhost:8081/` → "Sign in with Authentik" → enter the LDAP user + LDAP password.
3. Expect: authenticated, lands in the admin UI (because the demo user is in IT-Admins). Screenshot as evidence.
4. Negative check: a synced LDAP user NOT in IT-Admins authenticates but is denied admin actions (403) — confirms safe-by-default.

`tools/web-sso-provision-ref/` is an existing browser-OIDC harness usable here.

---

## Self-Review (author checklist — completed)

**Spec coverage:** every spec section maps to a task — Components/field table → A4; sync client → A2; data flow sync/login → A4/A5; authorization safety → ARD-007 (C1) + §04 (C2); alanl collision → A6; sync-trigger → A5/B1; ordering → A1/A8; secret lifecycle → A2 + D1/D4; testing → B1 + manual demo; governance → C1-C6; ansible/prod → D1-D4. Non-goals (group sync) explicitly encoded as `sync_groups=false` (A4) + ARD-007 alternatives.

**Placeholder scan:** no TBD/"handle edge cases"/"similar to". The three genuinely-unverified Authentik facts are quarantined into Task A0 (a live spike that produces concrete values) rather than left as guesses in implementation tasks — this is deliberate, not a placeholder.

**Type/name consistency:** `SYNC_CLIENT_ID`/`AUTHENTIK_LDAP_SYNC_CLIENT_ID`, `LDAP_SOURCE_SLUG="azblink-ldap"`, `ensure_ldap_federation()`, `ensure_sync_client()`, `get_ldap_source_mapping_pks()`, `ensure_ldap_source()`, `trigger_ldap_sync()`, `delete_local_user()`, `add_ldap_user_to_admin_group()` — used consistently across A2-A8, B1, and the spec/ARD references. Response keys (`payload["secret"]`, `results[0]["pk"]`) match the exact endpoint contracts extracted from `main.py` / `seed_authentik.py`.

**Known open items surfaced (not hidden):** exact `/tasks/schedules/` discriminator and `sync/status/` response shape (A0/A5 tighten the loose `slug in json.dumps(...)` match); whether `mei` exists in the dev LDAP with a known password (A7/demo); the suspend-path session-revocation gap (ARD-007 References, unverified).
