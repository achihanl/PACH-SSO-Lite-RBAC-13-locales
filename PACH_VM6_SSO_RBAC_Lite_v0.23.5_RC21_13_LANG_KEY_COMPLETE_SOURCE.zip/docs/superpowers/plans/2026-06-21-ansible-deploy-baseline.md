# Ansible Deploy Baseline Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A native, idempotent Ansible process (`deploy/ansible/`) that deploys the AZBlink Directory stack to the dev VPN VM and fails loudly unless the Authentik IdP is correctly seeded — a reusable baseline for production.

**Architecture:** Local control node runs `ansible-playbook` against the VM (inline inventory host vars, `become -K`). Two roles: `host_prep` (Docker/just/utils) and `azblink_app` (git clone → render `.env` from a Jinja2 template → `docker compose up --build` → deep-health + Authentik-seed verification gate). Dev is fully working; `inventories/prod/*.example` are stubbed seams.

**Tech Stack:** Ansible (`community.docker` collection), `docker_compose_v2`, Jinja2 `.env` template, the existing Docker Compose stack at `deploy/dev/`.

**Spec:** `docs/superpowers/specs/2026-06-21-ansible-deploy-baseline-design.md`

**Branch:** `feat/ansible-deploy-baseline` (already created).

---

## Conventions for this plan

- **"Tests" for infrastructure code** are: `--syntax-check`, `ansible-inventory --list`, ad-hoc `ping`, `--check` dry runs, **idempotence** (second run reports `changed=0`), and the `verify.yml` gate (the real integration assertion). There are no pytest unit tests here.
- **Offline steps** run without the VM. **Live steps** (marked **[LIVE]**) need: VPN up (`ping 192.168.11.126`), the VM reachable, and the sudo password typed at `-K`. The VPN drops intermittently — re-run on `Connection timed out`; every play is idempotent.
- All `ansible-*` commands run from `deploy/ansible/` unless noted (`ansible.cfg` lives there).
- Commit scope is `deploy`. Hooks: protect-main (we're on a branch — fine), commitizen (use `type(scope): subject`), ruff (no Python here → skipped).

---

## File Structure

```
deploy/ansible/
  ansible.cfg
  requirements.yml
  site.yml
  README.md
  inventories/
    dev/
      hosts.ini
      group_vars/
        all.yml
        vault.yml
    prod/
      hosts.ini.example
      group_vars/
        all.yml.example
        vault.yml.example
  roles/
    host_prep/
      tasks/main.yml
      defaults/main.yml
    azblink_app/
      tasks/main.yml
      tasks/fetch.yml
      tasks/config.yml
      tasks/deploy.yml
      tasks/verify.yml
      templates/env.j2
      defaults/main.yml
```

---

## Task 1: Scaffold + control-node prerequisites + connectivity smoke

**Files:**
- Create: `deploy/ansible/ansible.cfg`
- Create: `deploy/ansible/requirements.yml`
- Create: `deploy/ansible/inventories/dev/hosts.ini`
- Create: `deploy/ansible/site.yml` (minimal ping play for now)

- [ ] **Step 1: Verify Ansible is on the control node**

Run: `ansible --version`
Expected: `ansible [core 2.1x...]`. If "command not found", install: `pipx install ansible` (or `sudo apt install -y ansible`), then re-run.

- [ ] **Step 2: Create `deploy/ansible/ansible.cfg`**

```ini
[defaults]
inventory = inventories/dev
roles_path = roles
host_key_checking = False
retry_files_enabled = False
stdout_callback = yaml
interpreter_python = auto_silent

[privilege_escalation]
become = True
become_method = sudo

[ssh_connection]
# Survive flaky VPN; reuse one connection across tasks.
ssh_args = -o ServerAliveInterval=5 -o ServerAliveCountMax=6 -o ConnectTimeout=20 -o ControlMaster=auto -o ControlPersist=60s
pipelining = True
```

Note: `host_key_checking = False` is pragmatic for the flaky-VPN dev box. Tighten to `True` + managed `known_hosts` for prod.

- [ ] **Step 3: Create `deploy/ansible/requirements.yml`**

```yaml
---
collections:
  - name: community.docker
    version: ">=4.0.0"
```

- [ ] **Step 4: Install the collection**

Run: `ansible-galaxy collection install -r requirements.yml`
Expected: `community.docker ... was installed successfully` (or "already installed").

- [ ] **Step 5: Confirm the `docker_compose_v2` `build` param (resolves the spec's open item)**

Run: `ansible-doc community.docker.docker_compose_v2 | grep -A6 'build:'`
Expected: a `build:` option listing choices including `always`. Note the exact choices — Task 6 uses `build: always`. If the param differs on the installed version, record the correct value to use in Task 6.

- [ ] **Step 6: Create `deploy/ansible/inventories/dev/hosts.ini`**

```ini
[azblink]
azb-ad ansible_host=192.168.11.126 ansible_user=keith ansible_ssh_private_key_file=~/.ssh/id_rsa
```

- [ ] **Step 7: Create a minimal `deploy/ansible/site.yml` (ping only for now)**

```yaml
---
- name: Deploy AZBlink Directory
  hosts: azblink
  gather_facts: false
  tasks:
    - name: Ping target
      ansible.builtin.ping:
```

- [ ] **Step 8: Syntax check (offline)**

Run: `ansible-playbook site.yml --syntax-check`
Expected: `playbook: site.yml` with no errors.

- [ ] **Step 9: Inventory sanity (offline)**

Run: `ansible-inventory --list`
Expected: JSON showing `azb-ad` under group `azblink` with `ansible_host=192.168.11.126`.

- [ ] **Step 10: [LIVE] Connectivity + become smoke**

Run: `ansible azblink -m ping`
Expected: `azb-ad | SUCCESS => {"ping": "pong"}`. (No `-K` needed — `ping` doesn't escalate.) On `Connection timed out`, re-run (VPN).

- [ ] **Step 11: Commit**

```bash
git add deploy/ansible/ansible.cfg deploy/ansible/requirements.yml \
        deploy/ansible/inventories/dev/hosts.ini deploy/ansible/site.yml
git commit -m "feat(deploy): scaffold ansible control config + dev inventory + ping smoke"
```

---

## Task 2: Variables + `.env` Jinja2 template + isolated render check

**Files:**
- Create: `deploy/ansible/inventories/dev/group_vars/all.yml`
- Create: `deploy/ansible/inventories/dev/group_vars/vault.yml`
- Create: `deploy/ansible/roles/azblink_app/templates/env.j2`

Authoring the template now (before the role that consumes it) lets us validate it in isolation against a `/tmp` render.

- [ ] **Step 1: Create `inventories/dev/group_vars/all.yml` (non-secret)**

```yaml
---
# Repo + target
azblink_repo: "git@github.com:KeithMoc/azb-azblink-directory-and-identity-stack.git"
azblink_branch: "main"
install_dir: "/opt/azblink-directory"
deploy_subdir: "deploy/dev"
server_host: "192.168.11.126"        # drives all browser-facing OIDC/CORS keys
docker_user: "keith"
azblink_environment: "development"   # → .env ENVIRONMENT

# LDAP (non-secret)
ldap_organisation: "AZBlink"
ldap_domain: "azblink.com"
ldap_uri: "ldap://openldap:389"
ldap_base_dn: "dc=azblink,dc=com"
ldap_tenant: "azblink"
ldap_bind_dn: "cn=admin,dc=azblink,dc=com"

# Backend OIDC (Docker-internal)
oidc_issuer: "http://authentik-server:9000/application/o/azblink-directory/"
oidc_audience: "azblink-directory"
oidc_admin_group: "IT-Admins"
oidc_groups_claim: "groups"
authentik_api_url: "http://authentik-server:9000"

# Frontend OIDC client (non-secret)
vite_oidc_client_id: "azblink-directory"
vite_oidc_admin_group: "IT-Admins"

# Postgres identifiers (non-secret)
postgres_user: "azblink_directory"
postgres_db: "azblink_directory"

# Authentik (non-secret)
authentik_bootstrap_email: "admin@azblink.local"

# UC Core placeholders (dev)
ucchat_xmpp_domain: "xmpp.example.com"
ucchat_xmpp_ws_url: "wss://xmpp.example.com/ws"
ucchat_sip_domain: "sip.example.com"
ucchat_sip_wss_url: "wss://sip.example.com/ws"

# Verify gate tuning
health_retries: 120                  # 120 × 5s = 10 min, matches install.sh
health_delay: 5
seed_verify_retries: 30              # 30 × 10s = 5 min for async seed
seed_verify_delay: 10
```

- [ ] **Step 2: Create `inventories/dev/group_vars/vault.yml` (dev secrets, plaintext — throwaway)**

```yaml
---
# DEV THROWAWAY CREDENTIALS. Prod uses the same keys under ansible-vault.
postgres_password: "azblink_directory"
ldap_admin_password: "adminpassword"
ldap_bind_pw: "adminpassword"
org_qr_signing_secret: "dev_signing_secret_change_in_prod"
authentik_pg_pass: "authentik-dev-password"
authentik_secret_key: "dev-authentik-secret-key-change-in-prod-minimum-50-chars!!"
authentik_bootstrap_password: "adminpassword"
authentik_bootstrap_token: "dev-authentik-api-token"
authentik_api_token: "dev-authentik-api-token"
dev_auth_token: "dev-test-token"     # prod seam: "" (empty → key omitted from .env)
```

- [ ] **Step 3: Create `roles/azblink_app/templates/env.j2`**

```jinja
# GENERATED by deploy/ansible (roles/azblink_app/templates/env.j2). Do not edit on host.
# Keep keys in sync with deploy/dev/.env.example.

# Database
POSTGRES_USER={{ postgres_user }}
POSTGRES_PASSWORD={{ postgres_password }}
POSTGRES_DB={{ postgres_db }}

# LDAP
LDAP_ORGANISATION={{ ldap_organisation }}
LDAP_DOMAIN={{ ldap_domain }}
LDAP_ADMIN_PASSWORD={{ ldap_admin_password }}
LDAP_URI={{ ldap_uri }}
LDAP_BASE_DN={{ ldap_base_dn }}
LDAP_TENANT={{ ldap_tenant }}
LDAP_BIND_DN={{ ldap_bind_dn }}
LDAP_BIND_PW={{ ldap_bind_pw }}

# API secrets
ORG_QR_SIGNING_SECRET={{ org_qr_signing_secret }}

# CORS (host-derived; keeps localhost for host-run tooling)
CORS_ORIGINS=http://localhost:8081,http://127.0.0.1:8081,http://{{ server_host }}:8081

# Authentik IdP
AUTHENTIK_PG_PASS={{ authentik_pg_pass }}
AUTHENTIK_SECRET_KEY={{ authentik_secret_key }}
AUTHENTIK_BOOTSTRAP_PASSWORD={{ authentik_bootstrap_password }}
AUTHENTIK_BOOTSTRAP_EMAIL={{ authentik_bootstrap_email }}
AUTHENTIK_BOOTSTRAP_TOKEN={{ authentik_bootstrap_token }}

# Backend OIDC
OIDC_ISSUER={{ oidc_issuer }}
OIDC_ACCEPTED_ISSUERS={{ oidc_issuer }},http://localhost:9000/application/o/azblink-directory/,http://{{ server_host }}:9000/application/o/azblink-directory/
OIDC_AUDIENCE={{ oidc_audience }}
OIDC_ADMIN_GROUP={{ oidc_admin_group }}
OIDC_GROUPS_CLAIM={{ oidc_groups_claim }}
AUTHENTIK_API_URL={{ authentik_api_url }}
AUTHENTIK_API_TOKEN={{ authentik_api_token }}

# Environment (prod-safety: API refuses to start if production + DEV_AUTH_TOKEN set)
ENVIRONMENT={{ azblink_environment }}
{% if dev_auth_token | default('') | length > 0 %}
DEV_AUTH_TOKEN={{ dev_auth_token }}
{% endif %}

# OAuth2 redirect URIs (host-derived)
OAUTH2_REDIRECT_URIS=http://localhost:8081/auth/callback,http://{{ server_host }}:8081/auth/callback
OAUTH2_POST_LOGOUT_REDIRECT_URIS=http://localhost:8081/login,http://{{ server_host }}:8081/login

# Frontend OIDC (browser-accessible)
VITE_OIDC_ISSUER=http://{{ server_host }}:9000/application/o/azblink-directory/
VITE_OIDC_CLIENT_ID={{ vite_oidc_client_id }}
VITE_OIDC_ADMIN_GROUP={{ vite_oidc_admin_group }}

# UC Core QR Provisioning
UCCHAT_XMPP_DOMAIN={{ ucchat_xmpp_domain }}
UCCHAT_XMPP_WS_URL={{ ucchat_xmpp_ws_url }}
UCCHAT_SIP_DOMAIN={{ ucchat_sip_domain }}
UCCHAT_SIP_WSS_URL={{ ucchat_sip_wss_url }}
```

- [ ] **Step 4: Isolated render check (offline) — write a throwaway play**

Create `deploy/ansible/_render_check.yml` (temporary, deleted in Step 6):

```yaml
---
- name: Render env.j2 locally for validation
  hosts: localhost
  gather_facts: false
  vars_files:
    - inventories/dev/group_vars/all.yml
    - inventories/dev/group_vars/vault.yml
  tasks:
    - name: Render to /tmp
      ansible.builtin.template:
        src: roles/azblink_app/templates/env.j2
        dest: /tmp/azblink-env-check.env
        mode: "0600"
```

Run: `ansible-playbook _render_check.yml`
Expected: `ok=1 changed=1`, no template errors.

- [ ] **Step 5: Assert the rendered output is correct**

Run: `grep -E 'server_host|192.168.11.126' /tmp/azblink-env-check.env; echo '---'; grep -c '{{' /tmp/azblink-env-check.env`
Expected: `VITE_OIDC_ISSUER=http://192.168.11.126:9000/...`, `CORS_ORIGINS=...192.168.11.126:8081`, and the `grep -c '{{'` count is `0` (no unrendered Jinja). Confirm `DEV_AUTH_TOKEN=dev-test-token` is present (dev). Confirm no `POSTGRES_PASSWORD=` empty values.

- [ ] **Step 6: Remove the throwaway render play**

Run: `rm deploy/ansible/_render_check.yml /tmp/azblink-env-check.env`

- [ ] **Step 7: Commit**

```bash
git add deploy/ansible/inventories/dev/group_vars/ deploy/ansible/roles/azblink_app/templates/env.j2
git commit -m "feat(deploy): ansible dev group_vars + host-derived .env Jinja template"
```

---

## Task 3: `host_prep` role (Docker, Compose, just, utils)

**Files:**
- Create: `deploy/ansible/roles/host_prep/defaults/main.yml`
- Create: `deploy/ansible/roles/host_prep/tasks/main.yml`
- Modify: `deploy/ansible/site.yml` (add the role)

- [ ] **Step 1: Create `roles/host_prep/defaults/main.yml`**

```yaml
---
host_prep_utils: [git, curl, jq]
```

- [ ] **Step 2: Create `roles/host_prep/tasks/main.yml`**

```yaml
---
- name: Assert a Python 3 interpreter exists (Ansible modules need it)
  ansible.builtin.raw: command -v python3
  changed_when: false

- name: Install host utilities
  ansible.builtin.package:
    name: "{{ host_prep_utils }}"
    state: present

- name: Check whether docker is installed
  ansible.builtin.command: docker --version
  register: docker_check
  changed_when: false
  failed_when: false

- name: Install Docker Engine + Compose v2 (only if absent)
  ansible.builtin.shell: |
    set -o pipefail
    curl -fsSL https://get.docker.com | sh
  args:
    executable: /bin/bash
  when: docker_check.rc != 0

- name: Ensure docker service is enabled and started
  ansible.builtin.systemd:
    name: docker
    enabled: true
    state: started

- name: Verify Compose v2 plugin is present
  ansible.builtin.command: docker compose version
  changed_when: false

- name: Check whether just is installed
  ansible.builtin.command: just --version
  register: just_check
  changed_when: false
  failed_when: false

- name: Install just (only if absent)
  ansible.builtin.shell: |
    set -o pipefail
    curl --proto '=https' --tlsv1.2 -fsSL https://just.systems/install.sh | bash -s -- --to /usr/local/bin
  args:
    executable: /bin/bash
  when: just_check.rc != 0

- name: Add deploy user to the docker group
  ansible.builtin.user:
    name: "{{ docker_user }}"
    groups: docker
    append: true
```

- [ ] **Step 3: Wire `host_prep` into `site.yml`**

Replace the `tasks:` ping block so `site.yml` reads:

```yaml
---
- name: Deploy AZBlink Directory
  hosts: azblink
  become: true
  roles:
    - role: host_prep
      tags: [host]
```

- [ ] **Step 4: Syntax check (offline)**

Run: `ansible-playbook site.yml --syntax-check`
Expected: no errors.

- [ ] **Step 5: [LIVE] Converge host_prep**

Run: `ansible-playbook site.yml --tags host -K`
(Type the VM sudo password at the `BECOME password:` prompt.)
Expected: play recap `failed=0`. On a box that already has Docker/just (azb-ad does), most tasks report `ok` (green), not `changed`.

- [ ] **Step 6: [LIVE] Idempotence proof — run again**

Run: `ansible-playbook site.yml --tags host -K`
Expected: `changed=0` in the recap (every task green/ok). If any task reports `changed` on the second run, fix its idempotency guard before continuing.

- [ ] **Step 7: Commit**

```bash
git add deploy/ansible/roles/host_prep/ deploy/ansible/site.yml
git commit -m "feat(deploy): ansible host_prep role (docker, compose, just, utils)"
```

---

## Task 4: `azblink_app` fetch + config (repo clone, .env render, network)

**Files:**
- Create: `deploy/ansible/roles/azblink_app/defaults/main.yml`
- Create: `deploy/ansible/roles/azblink_app/tasks/fetch.yml`
- Create: `deploy/ansible/roles/azblink_app/tasks/config.yml`
- Create: `deploy/ansible/roles/azblink_app/tasks/main.yml`
- Modify: `deploy/ansible/site.yml` (add the role; deploy/verify tasks come in Task 5)

- [ ] **Step 1: Create `roles/azblink_app/defaults/main.yml`**

```yaml
---
azblink_git_force: false   # set true to discard local edits in install_dir
```

- [ ] **Step 2: Create `roles/azblink_app/tasks/fetch.yml`**

```yaml
---
- name: Clone or update the AZBlink repo
  ansible.builtin.git:
    repo: "{{ azblink_repo }}"
    dest: "{{ install_dir }}"
    version: "{{ azblink_branch }}"
    update: true
    force: "{{ azblink_git_force }}"
  # force=false (default) FAILS on local edits in install_dir — operators must
  # not hand-edit /opt; pass -e azblink_git_force=true for an intentional reset.
```

- [ ] **Step 3: Create `roles/azblink_app/tasks/config.yml`**

```yaml
---
- name: Ensure the external 'cloudflare-tunnel' network placeholder exists
  community.docker.docker_network:
    name: cloudflare-tunnel
    state: present
  # compose declares this network external: true (traefik + authentik-server
  # attach). On a host without the central tunnel, the placeholder lets
  # `compose up` succeed.

- name: Render .env from template
  ansible.builtin.template:
    src: env.j2
    dest: "{{ install_dir }}/{{ deploy_subdir }}/.env"
    mode: "0640"
    owner: root
    group: root
```

- [ ] **Step 4: Create `roles/azblink_app/tasks/main.yml`**

```yaml
---
- name: Fetch repo
  ansible.builtin.import_tasks: fetch.yml
  tags: [fetch]

- name: Render config
  ansible.builtin.import_tasks: config.yml
  tags: [config]
```

- [ ] **Step 5: Add `azblink_app` to `site.yml`**

```yaml
---
- name: Deploy AZBlink Directory
  hosts: azblink
  become: true
  roles:
    - role: host_prep
      tags: [host]
    - role: azblink_app
      tags: [app]
```

- [ ] **Step 6: Syntax check (offline)**

Run: `ansible-playbook site.yml --syntax-check`
Expected: no errors.

- [ ] **Step 7: [LIVE] Converge fetch + config only**

Run: `ansible-playbook site.yml --tags fetch,config -K`
Expected: `failed=0`. The git task may report `ok` (already cloned) or `changed` (pulled `main`); the template + network tasks report `changed` on first apply.

- [ ] **Step 8: [LIVE] Verify the render landed correctly on the VM**

Run: `ansible azblink -b -m shell -a "grep -E 'VITE_OIDC_ISSUER|CORS_ORIGINS|ENVIRONMENT' {{ '{{' }} install_dir {{ '}}' }}/deploy/dev/.env" -K`

(Simpler equivalent — run directly over SSH:)
`ssh -F deploy/ssh_config vpn-vm "grep -E 'VITE_OIDC_ISSUER|CORS_ORIGINS|ENVIRONMENT' /opt/azblink-directory/deploy/dev/.env"`
Expected: `VITE_OIDC_ISSUER=http://192.168.11.126:9000/...`, host IP in `CORS_ORIGINS`, `ENVIRONMENT=development`.

- [ ] **Step 9: [LIVE] Confirm the network exists**

Run: `ssh -F deploy/ssh_config vpn-vm "docker network ls | grep cloudflare-tunnel"`
Expected: a line listing `cloudflare-tunnel`.

- [ ] **Step 10: Commit**

```bash
git add deploy/ansible/roles/azblink_app/ deploy/ansible/site.yml
git commit -m "feat(deploy): ansible azblink_app fetch + .env render + tunnel network"
```

---

## Task 5: `azblink_app` deploy + verify (compose up + IdP gate)

**Files:**
- Create: `deploy/ansible/roles/azblink_app/tasks/deploy.yml`
- Create: `deploy/ansible/roles/azblink_app/tasks/verify.yml`
- Modify: `deploy/ansible/roles/azblink_app/tasks/main.yml`

- [ ] **Step 1: Create `roles/azblink_app/tasks/deploy.yml`**

```yaml
---
- name: Bring up the stack (build images, recreate changed containers)
  community.docker.docker_compose_v2:
    project_src: "{{ install_dir }}/{{ deploy_subdir }}"
    state: present
    build: always        # reproduces `just up-bg` = docker compose up -d --build
    # recreate: auto (default) → recreates only containers whose config changed
  register: compose_up
```

(If Task 1 Step 5 found `build` does not accept `always` on the installed collection, use the value recorded there.)

- [ ] **Step 2: Create `roles/azblink_app/tasks/verify.yml`**

```yaml
---
- name: Wait for deep health to report ok
  ansible.builtin.uri:
    url: http://localhost:8081/api/health/deep
    return_content: true
  register: deep_health
  until: deep_health.status == 200 and (deep_health.json.ok | default(false))
  retries: "{{ health_retries }}"
  delay: "{{ health_delay }}"

- name: Wait for the Authentik OAuth2 provider (seed runs async after compose up)
  ansible.builtin.uri:
    url: http://localhost:9000/api/v3/providers/oauth2/
    headers:
      Authorization: "Bearer {{ authentik_bootstrap_token }}"
    return_content: true
  register: ak_providers
  until: ak_providers.status == 200 and (ak_providers.json.pagination.count | default(0)) == 1
  retries: "{{ seed_verify_retries }}"
  delay: "{{ seed_verify_delay }}"

- name: Assert exactly one Authentik application exists
  ansible.builtin.uri:
    url: http://localhost:9000/api/v3/core/applications/
    headers:
      Authorization: "Bearer {{ authentik_bootstrap_token }}"
    return_content: true
  register: ak_apps
  failed_when: (ak_apps.json.pagination.count | default(0)) != 1

- name: Assert the OIDC discovery endpoint is live
  ansible.builtin.uri:
    url: http://localhost:9000/application/o/azblink-directory/.well-known/openid-configuration
    status_code: 200

- name: Report deployment endpoints
  ansible.builtin.debug:
    msg:
      - "UI:        http://{{ server_host }}:8081/"
      - "API docs:  http://{{ server_host }}:8081/api/docs"
      - "Authentik: http://{{ server_host }}:9000/"
```

- [ ] **Step 3: Append deploy + verify to `roles/azblink_app/tasks/main.yml`**

```yaml
---
- name: Fetch repo
  ansible.builtin.import_tasks: fetch.yml
  tags: [fetch]

- name: Render config
  ansible.builtin.import_tasks: config.yml
  tags: [config]

- name: Bring up stack
  ansible.builtin.import_tasks: deploy.yml
  tags: [deploy]

- name: Verify deployment
  ansible.builtin.import_tasks: verify.yml
  tags: [verify]
```

- [ ] **Step 4: Syntax check (offline)**

Run: `ansible-playbook site.yml --syntax-check`
Expected: no errors.

- [ ] **Step 5: [LIVE] Full converge end-to-end**

Run: `ansible-playbook site.yml -K`
Expected: `failed=0`. The verify tasks poll, then the debug task prints the three URLs. If the IdP gate fails (`ak_providers` times out), the play fails here — that is the gate doing its job; investigate the seed (`ssh -F deploy/ssh_config vpn-vm "docker logs azblink-authentik-seed"`).

- [ ] **Step 6: [LIVE] Independent verification over SSH**

Run:
```bash
ssh -F deploy/ssh_config vpn-vm 'curl -s -H "Authorization: Bearer dev-authentik-api-token" http://localhost:9000/api/v3/providers/oauth2/ | python3 -c "import sys,json;print(\"providers=\",json.load(sys.stdin)[\"pagination\"][\"count\"])"'
```
Expected: `providers= 1`.

- [ ] **Step 7: Commit**

```bash
git add deploy/ansible/roles/azblink_app/tasks/
git commit -m "feat(deploy): ansible azblink_app compose-up + Authentik-seed verify gate"
```

---

## Task 6: Prod seams (stubbed) + README

**Files:**
- Create: `deploy/ansible/inventories/prod/hosts.ini.example`
- Create: `deploy/ansible/inventories/prod/group_vars/all.yml.example`
- Create: `deploy/ansible/inventories/prod/group_vars/vault.yml.example`
- Create: `deploy/ansible/README.md`

- [ ] **Step 1: Create `inventories/prod/hosts.ini.example`**

```ini
# Copy to hosts.ini and fill in. Prod target connection details.
[azblink]
prod-host ansible_host=REPLACE_WITH_PROD_IP ansible_user=REPLACE_WITH_USER ansible_ssh_private_key_file=~/.ssh/REPLACE
```

- [ ] **Step 2: Create `inventories/prod/group_vars/all.yml.example`**

```yaml
---
# Copy to all.yml and adjust. PROD non-secret config.
azblink_repo: "git@github.com:KeithMoc/azb-azblink-directory-and-identity-stack.git"
azblink_branch: "main"          # pin to a release tag for prod
install_dir: "/opt/azblink-directory"
deploy_subdir: "deploy/dev"     # prod compose split is future work
server_host: "REPLACE_WITH_PROD_HOSTNAME"
docker_user: "REPLACE_WITH_USER"
azblink_environment: "production"   # API refuses to start if DEV_AUTH_TOKEN is set

# ... mirror the non-secret keys from inventories/dev/group_vars/all.yml ...
health_retries: 120
health_delay: 5
seed_verify_retries: 30
seed_verify_delay: 10
```

- [ ] **Step 3: Create `inventories/prod/group_vars/vault.yml.example`**

```yaml
---
# Copy to vault.yml, fill REAL secrets, then: ansible-vault encrypt vault.yml
# Same keys as dev. dev_auth_token MUST be empty in prod (key is then omitted
# from .env so the API does not refuse to start).
postgres_password: "REPLACE"
ldap_admin_password: "REPLACE"
ldap_bind_pw: "REPLACE"
org_qr_signing_secret: "REPLACE"
authentik_pg_pass: "REPLACE"
authentik_secret_key: "REPLACE_MIN_50_CHARS"
authentik_bootstrap_password: "REPLACE"
authentik_bootstrap_token: "REPLACE"
authentik_api_token: "REPLACE"
dev_auth_token: ""
```

- [ ] **Step 4: Create `deploy/ansible/README.md`**

````markdown
# AZBlink Directory — Ansible Deploy

Native, idempotent deploy of the stack. Reusable baseline for production.
Spec: `docs/superpowers/specs/2026-06-21-ansible-deploy-baseline-design.md`.

## Prerequisites (control node)
- Ansible core 2.1x+
- `ansible-galaxy collection install -r requirements.yml`
- SSH reachability to the target (dev: VPN up to 192.168.11.126)

## Deploy (dev)
```bash
cd deploy/ansible
ansible-playbook site.yml -K        # type the target's sudo password
```

Run a subset with tags: `--tags host`, `--tags app`, `--tags verify`.

## What it does
1. `host_prep` — git/curl/jq, Docker Engine + Compose v2, just, docker group.
2. `azblink_app` — clone/update repo → render `.env` (host-derived OIDC/CORS) →
   ensure `cloudflare-tunnel` placeholder network → `docker compose up -d --build`
   → wait for deep health → **assert Authentik seeded** (providers=1/apps=1,
   discovery 200). The deploy FAILS if the IdP is not correctly seeded.

## Idempotency
Re-running converges to no-ops (`changed=0`). Do not hand-edit `/opt` — the git
task fails on a dirty tree (override with `-e azblink_git_force=true`).

## Production
Copy `inventories/prod/*.example` → real files, fill secrets, then
`ansible-vault encrypt inventories/prod/group_vars/vault.yml`. Run with
`-i inventories/prod --ask-vault-pass -K`. `dev_auth_token` MUST be empty in prod.
````

- [ ] **Step 5: Syntax check still clean (offline)**

Run: `ansible-playbook site.yml --syntax-check`
Expected: no errors (the `.example` files are not loaded).

- [ ] **Step 6: Commit**

```bash
git add deploy/ansible/inventories/prod/ deploy/ansible/README.md
git commit -m "docs(deploy): ansible prod inventory seams + README"
```

---

## Task 7: Full idempotence proof + finalize

- [ ] **Step 1: [LIVE] Run the whole playbook twice, capture the second recap**

Run: `ansible-playbook site.yml -K` then immediately `ansible-playbook site.yml -K`
Expected (second run): recap `changed=0` for converge tasks. The `verify.yml` `uri` polls always run (they are checks, not changes) and report `ok` — that is expected and not a `changed`. Confirm no role task (git/template/compose) reports `changed` on the second run.

- [ ] **Step 2: If any converge task is non-idempotent, fix it**

Common culprits + fixes:
- `template` reports `changed` every run → check for a trailing-newline/whitespace diff in `env.j2`; ensure the file ends with exactly one newline.
- `docker_compose_v2` reports `changed` every run → `build: always` rebuilds; if you want no-op-on-unchanged, switch to `build: policy` and confirm images still build on first deploy. Record the decision in the role comment.
Re-run Step 1 after any fix until the second run is clean.

- [ ] **Step 3: Cross-link the spec and plan as done**

Append to the spec file `docs/superpowers/specs/2026-06-21-ansible-deploy-baseline-design.md` under a new trailing line:

```markdown
## Implementation
Implemented per `docs/superpowers/plans/2026-06-21-ansible-deploy-baseline.md`.
```

- [ ] **Step 4: Commit**

```bash
git add docs/superpowers/specs/2026-06-21-ansible-deploy-baseline-design.md
git commit -m "docs(deploy): mark ansible baseline spec implemented"
```

- [ ] **Step 5: Push + open PR**

```bash
git push -u origin feat/ansible-deploy-baseline
gh pr create --base main --head feat/ansible-deploy-baseline \
  --title "feat(deploy): Ansible deploy baseline for AZBlink Directory" \
  --body "Implements docs/superpowers/specs/2026-06-21-ansible-deploy-baseline-design.md. Native idempotent Ansible deploy with a hard Authentik-seed verification gate. Dev working; prod seams stubbed."
```

---

## Self-Review (completed by plan author)

**Spec coverage:** D1 native (Tasks 3–5) ✓; D2 inline inventory + become -K (Task 1) ✓; D3 dev + prod seams (Tasks 2, 6) ✓; D4 env.j2 from vars (Task 2) ✓; §6.1 host_prep (Task 3) ✓; §6.2 fetch/config/deploy/verify (Tasks 4–5) ✓; §6.3 env.j2 + ENVIRONMENT×DEV_AUTH_TOKEN (Task 2 Step 3) ✓; §6.2 cloudflare-tunnel network (Task 4) ✓; §8 idempotence (Tasks 3, 7) ✓; §9 success criteria (Task 5 gate + Task 7 idempotence) ✓.

**Placeholder scan:** No "TBD/TODO" in task steps. `.example` files contain `REPLACE_*` by design (they are templates the operator fills). Every code step shows full content.

**Type/name consistency:** Variable names match across `all.yml`/`vault.yml`/`env.j2` (`server_host`, `authentik_bootstrap_token`, `install_dir`, `deploy_subdir`, `dev_auth_token`). Tags consistent (`host`, `fetch`, `config`, `deploy`, `verify`, `app`). `health_retries`/`seed_verify_retries` defined in Task 2, consumed in Task 5.

**One residual:** `build: always` is confirmed at runtime in Task 1 Step 5 (the only item the docs lookup left open); Task 5 references that recorded value.
