# Profile Services Restructuring — Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Remove SSO + QR from profiles, restructure XMPP/SIP into an extensible `profile_services` table with discriminator + JSON config.

**Architecture:** Three sequential PRs — PR 1 removes SSO and QR (pure deletions), PR 2 restructures UC services into `profile_services` (schema change + new CRUD), PR 3 cleans up dead code and updates documentation. Each PR is independently reviewable.

**Tech Stack:** FastAPI, SQLAlchemy Core, PostgreSQL, React 19, TanStack Router/Query, TypeScript

**Spec:** `docs/superpowers/specs/2026-03-17-profile-services-restructuring-design.md`

---

## Chunk 1: PR 1 — Remove SSO + QR (Pure Deletions)

### Task 1: Create branch and migration file

**Files:**
- Create: `migrations/024_remove_sso_qr.sql`

- [ ] **Step 1: Create feature branch**

```bash
git checkout -b chore/remove-sso-qr main
```

- [ ] **Step 2: Write migration**

```sql
-- 024_remove_sso_qr.sql
-- Remove SSO config and QR infrastructure from config_templates.
-- Rename provision_tokens → device_provisions (SSO-only going forward).

ALTER TABLE config_templates DROP COLUMN IF EXISTS sso_config;
ALTER TABLE config_templates DROP COLUMN IF EXISTS qr_settings;

DROP TABLE IF EXISTS qr_issuance_audit;
DROP TABLE IF EXISTS qr_issues;
DROP TABLE IF EXISTS qr_preview_links;

ALTER TABLE provision_tokens RENAME TO device_provisions;
ALTER TABLE device_provisions DROP COLUMN IF EXISTS auth_method;
```

- [ ] **Step 3: Commit migration**

```bash
git add migrations/024_remove_sso_qr.sql
git commit -m "chore(db): migration 024 — drop SSO/QR columns, rename provision_tokens"
```

---

### Task 2: Backend — Remove SSO config from orgdb.py

**Files:**
- Modify: `src/backend/orgdb.py`

Key locations (line numbers are approximate — verify before editing):
- `config_templates` table definition: lines 278–308, remove `sso_config` (line 285) and `qr_settings` (line 286)
- `toggle_config_template_section()`: lines 2779–2819 — delete entirely
- `create_config_template()`: ~line 2632, remove `sso_config=json.dumps(...)` and `qr_settings` from insert
- `update_config_template()`: ~line 2743, remove `sso_config`/`qr_settings` from update loop
- `clone_config_template()`: ~line 2831, remove `sso_config` and `qr_settings` from clone data

- [ ] **Step 1: Remove `sso_config` and `qr_settings` columns from `config_templates` Table definition**

Remove these two Column lines from the `config_templates` Table:
```python
Column("sso_config", JSON, nullable=False, server_default='{"enabled":false}'),
Column("qr_settings", JSON, nullable=False, server_default='{"defaultValidityMinutes":60,"oneTimeUse":true,"autoEmailOnCreate":false,"deepLinkScheme":"azblink"}'),
```

- [ ] **Step 2: Delete `toggle_config_template_section()` method entirely**

Remove the entire method (lines ~2779–2819). It only handled `sso` toggles.

- [ ] **Step 3: Remove SSO/QR from `create_config_template()`**

In the `insert().values(...)` call, remove:
```python
sso_config=json.dumps(data.get("sso_config", {"enabled": False})),
```
And any `qr_settings` value.

- [ ] **Step 4: Remove SSO/QR from `update_config_template()`**

In the update loop (~line 2743), remove `"sso_config"` and `"qr_settings"` from the iterable:
```python
for config_key in ("sso_config", "qr_settings"):
```
Delete this entire loop block.

- [ ] **Step 5: Remove SSO/QR from `clone_config_template()`**

In the clone data dict (~line 2831), remove:
```python
"sso_config": sso,
```
And the `sso`/`qr` variable assignments above it.

- [ ] **Step 6: Verify file parses**

```bash
cd src/backend && python -c "import orgdb; print('OK')"
```

- [ ] **Step 7: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "refactor(backend): remove SSO config and QR settings from orgdb config_templates"
```

---

### Task 3: Backend — Remove QR tables and methods from orgdb.py

**Files:**
- Modify: `src/backend/orgdb.py`

Key locations:
- `qr_issues` table: lines 109–119
- `qr_issuance_audit` table: lines 167–182
- `qr_preview_links` table: lines 343–358
- `record_org_qr_issue()`: ~line 539–556
- `revoke_issues_by_profile()`: (in delete_config_template area, ~line 522)
- `record_provision_token()`: ~line 570–599 (keep but update for device_provisions)
- `revoke_qr_issuance_for_user()`: ~line 1036–1048
- `list_qr_issuance()`: ~line 1051–1073
- `list_qr_issuance_for_user()`: ~line 1075–1099
- `list_qr_codes()`: ~line 1233–1349
- `get_qr_stats()`: ~line 1352–1400
- `record_user_qr_issuance()`: ~line 1670–1708
- `create_preview_link()`: ~line 2952–2980
- `get_preview_link()`: ~line 2982–2991
- `compute_compliance_alerts()`: ~line 2421–2586

- [ ] **Step 1: Delete QR table definitions**

Remove these three Table definitions:
- `qr_issues` (lines ~109–119)
- `qr_issuance_audit` (lines ~167–182)
- `qr_preview_links` (lines ~343–358)

- [ ] **Step 2: Delete QR-only methods**

Delete these methods entirely:
- `record_org_qr_issue()`
- `sso_profile_qrcode()`
- `revoke_issues_by_profile()` (standalone method, not just the call site)
- `revoke_qr_issuance_for_user()`
- `list_qr_issuance()`
- `list_qr_issuance_for_user()`
- `list_qr_codes()`
- `get_qr_stats()`
- `record_user_qr_issuance()`
- `create_preview_link()`
- `get_preview_link()`

Also remove any calls to `revoke_issues_by_profile()` from `delete_config_template()`.

- [ ] **Step 3: Update `compute_compliance_alerts()`**

This method JOINs `qr_issuance_audit`. Either:
- Remove QR-specific alert computations (any that query `qr_issuance_audit`)
- Keep only alerts that can be computed from `device_provisions`
- If the entire method is QR-only, delete it

- [ ] **Step 4: Verify file parses**

```bash
cd src/backend && python -c "import orgdb; print('OK')"
```

- [ ] **Step 5: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "refactor(backend): remove QR tables and methods from orgdb"
```

---

### Task 4: Backend — Rename provision_tokens → device_provisions in orgdb.py

**Files:**
- Modify: `src/backend/orgdb.py`

Key locations:
- `provision_tokens` table definition: lines ~122–141
- `count_active_sso_provisions()`: ~line 657
- `upsert_sso_provision()`: ~line 691
- `revoke_sso_provision()`: ~line 748
- All references to `provision_tokens.c.auth_method`

- [ ] **Step 1: Rename table definition**

```python
# Before
provision_tokens = Table(
    "provision_tokens", metadata,
    ...
)

# After
device_provisions = Table(
    "device_provisions", metadata,
    ...
)
```

Remove the `auth_method` Column from the definition.

- [ ] **Step 2: Rename all references throughout the file**

Find-replace `provision_tokens` → `device_provisions` for all `.c.` column references, queries, inserts, and updates.

- [ ] **Step 3: Remove `auth_method` from all queries**

Remove any `WHERE auth_method == "sso_token"` filters — they're now redundant.
Remove `auth_method` from any `insert().values(...)` calls.

- [ ] **Step 4: Rename methods**

- `count_active_sso_provisions()` → `count_active_provisions()`
- `upsert_sso_provision()` → `upsert_provision()`
- `revoke_sso_provision()` → `revoke_provision()`

- [ ] **Step 5: Update callers in orgdb.py**

Search for any internal calls to the old method names and update them.

- [ ] **Step 6: Verify file parses**

```bash
cd src/backend && python -c "import orgdb; print('OK')"
```

- [ ] **Step 7: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "refactor(backend): rename provision_tokens to device_provisions, drop auth_method"
```

---

### Task 5: Backend — Remove SSO + QR from main.py

**Files:**
- Modify: `src/backend/main.py`
- Delete: `src/backend/qr_signing.py`

Key locations in main.py:
- Line 11: `import qrcode`
- Line 29: `from qr_signing import sign_provisioning_payload`
- Lines 209–239: `_resolve_sso_payload()` helper
- Lines 503–527: SSO/QR Pydantic models (`SsoOidcClients`, `SsoOidc`, `QrPolicy2`, `SsoProfileConfig`)
- Lines 639–646: `QrPreviewCreateReq`
- Lines 866–907: `ssoConfig` in user detail response
- Lines 1817–1825: `GET /api/me/qrcodes`
- Lines 2049–2107: `GET /api/qr/codes`
- Lines 2110–2119: `GET /api/qr/stats`
- Lines 2216–2317: `GET /api/users/{uid}/qrcode`
- Lines 2321–2433: `GET /api/users/{uid}/qrcodes`
- Lines 2436–2448: `POST /api/users/{uid}/qrcode/revoke`
- Lines 2453–2464: `_strip_credentials()` helper
- Lines 2467–2510: `POST /api/users/{uid}/qrcode/share`
- Lines 2513–2551: `GET /api/qr/preview/{token}`
- Lines 2554–2570: `GET /api/users/{uid}/qr_history`
- Lines 2740–2767: `POST /api/orgprofiles/{id}/rotate_qr`
- Lines 2769–2804: `GET /api/orgprofiles/{id}/qrcode`
- Lines 2811–2857: `_build_sso_profile_payload()`
- Lines 2890–2932: `GET /api/orgprofiles/{id}/sso_profile/qrcode`
- Lines 2984–3038: `GET /api/qr-codes/recent`
- Lines 3372–3379: `GET /api/audit/qr_issuance`
- Lines 3527–3541: `SsoConfigUpdate`, `QrSettingsUpdate` models
- Lines 3564–3584: `_format_template_list_item()` — `ssoEnabled` field
- Lines 3587–3645: `_format_template_detail()` — `sso` and `qr` fields
- Lines 3747–3749: `ConfigTemplateSectionToggle` model
- Lines 3834–3848: `PATCH /api/config-templates/{id}/toggle` endpoint

- [ ] **Step 1: Remove QR/SSO imports**

Remove:
```python
import qrcode
from qr_signing import sign_provisioning_payload
```

- [ ] **Step 2: Delete `_resolve_sso_payload()` helper**

Remove lines ~209–239.

- [ ] **Step 3: Delete SSO/QR Pydantic models**

Remove: `SsoOidcClients`, `SsoOidc`, `QrPolicy2`, `SsoProfileConfig`, `QrPreviewCreateReq`, `SsoConfigUpdate`, `QrSettingsUpdate`, `ConfigTemplateSectionToggle`.

- [ ] **Step 4: Remove `ssoConfig` from user detail response**

In the user detail endpoint (~line 866–907), remove the `sso_config` resolution and `"ssoConfig": sso_config` from the response dict.

- [ ] **Step 5: Delete all QR endpoints**

Delete these endpoint functions entirely:
- `GET /api/me/qrcodes`
- `GET /api/qr/codes`
- `GET /api/qr/stats`
- `GET /api/users/{uid}/qrcode`
- `GET /api/users/{uid}/qrcodes`
- `POST /api/users/{uid}/qrcode/revoke`
- `POST /api/users/{uid}/qrcode/share`
- `GET /api/qr/preview/{token}`
- `GET /api/users/{uid}/qr_history`
- `POST /api/orgprofiles/{id}/rotate_qr`
- `GET /api/orgprofiles/{id}/qrcode`
- `GET /api/orgprofiles/{id}/sso_profile/qrcode`
- `GET /api/qr-codes/recent`
- `GET /api/audit/qr_issuance`
- `POST /api/provision/qr` (verify it exists before removing — may already be deleted)

Also delete helpers: `_strip_credentials()`, `_build_sso_profile_payload()`.

- [ ] **Step 6: Remove SSO/QR from template formatters**

In `_format_template_list_item()`:
- Remove `sso` variable and `"ssoEnabled": sso.get("enabled", False)` line

In `_format_template_detail()`:
- Remove `sso` and `qr` variables
- Remove `"sso": sso` and `"qr": qr` from response dict

- [ ] **Step 7: Delete toggle endpoint**

Remove `PATCH /api/config-templates/{template_id}/toggle` endpoint (~lines 3834–3848).

- [ ] **Step 8: Update method calls to renamed orgdb methods**

Search for `count_active_sso_provisions`, `upsert_sso_provision`, `revoke_sso_provision` and update to `count_active_provisions`, `upsert_provision`, `revoke_provision`.

- [ ] **Step 9: Delete `src/backend/qr_signing.py`**

```bash
rm src/backend/qr_signing.py
```

- [ ] **Step 10: Verify backend starts**

```bash
cd src/backend && python -c "import main; print('OK')"
```

- [ ] **Step 11: Commit**

```bash
git add -u src/backend/
git commit -m "refactor(backend): remove SSO/QR endpoints and models from main.py, delete qr_signing.py"
```

---

### Task 6: Backend — Update conftest.py and delete QR tests

**Files:**
- Modify: `tests/conftest.py`
- Delete: `tests/test_qr_signing_unit.py`
- Delete: `tests/test_qr_signing.py`
- Delete: `tests/test_qr_format.py`
- Delete: `tests/test_qrcode_v2.py`
- Delete: `tests/test_qr_revoke.py`
- Delete: `tests/test_qr_flow_integration.py`
- Delete: `tests/test_qr_management.py`

- [ ] **Step 1: Update conftest.py cleanup queries**

In the `created_users` fixture (~line 139–156), update:
```python
# Before
"DELETE FROM provision_tokens WHERE uid = %s"
"DELETE FROM qr_issuance_audit WHERE user_uid = %s"

# After
"DELETE FROM device_provisions WHERE uid = %s"
# Remove qr_issuance_audit line entirely
```

Also remove any `qr_preview_links` cleanup if present.

- [ ] **Step 2: Delete QR test files**

```bash
rm tests/test_qr_signing_unit.py tests/test_qr_signing.py tests/test_qr_format.py \
   tests/test_qrcode_v2.py tests/test_qr_revoke.py tests/test_qr_flow_integration.py \
   tests/test_qr_management.py
```

- [ ] **Step 3: Update `test_config_templates.py`**

Remove any assertions about `ssoEnabled`, `sso`, `qr`, or `toggle` endpoint tests.
Specifically remove `test_update_with_sso_config` and any toggle section tests.

- [ ] **Step 4: Commit**

```bash
git add -u tests/
git commit -m "test: remove QR tests, update conftest for device_provisions rename"
```

---

### Task 7: Frontend — Remove SSO components and references

**Files to delete:**
- `src/frontend/src/components/features/org-management/SSOConfigTab.tsx`
- `src/frontend/src/components/features/org-management/SSOStatusCard.tsx`
- `src/frontend/src/components/features/org-management/SSOBadge.tsx`
- `src/frontend/src/components/features/org-management/modals/EditSSOModal.tsx`

**Files to modify:**
- `src/frontend/src/components/features/org-management/DetailTabs.tsx` — remove SSO tab
- `src/frontend/src/components/features/org-management/OrgDetailPanel.tsx` — remove SSO toggle/edit logic
- `src/frontend/src/components/features/org-management/OverviewTab.tsx` — remove SSOBadge
- `src/frontend/src/lib/queries/org-mutations.ts` — remove `useToggleSSO` and `useUpdateSSOConfig`
- `src/frontend/src/components/features/org-profiles/ConfigTab.tsx` — remove SSO section (lines 58–74)
- `src/frontend/src/components/features/org-profiles/profile-type-config.ts` — remove `sso` from `sectionConfig`
- `src/frontend/src/types/org-profiles.ts` — remove `SsoConfig`, `FeatureKey`, `ToggleSectionPayload`, `sso` from `ProfileDetail`, `ssoEnabled` from `ProfileListItem`

- [ ] **Step 1: Delete SSO component files**

```bash
rm src/frontend/src/components/features/org-management/SSOConfigTab.tsx \
   src/frontend/src/components/features/org-management/SSOStatusCard.tsx \
   src/frontend/src/components/features/org-management/SSOBadge.tsx \
   src/frontend/src/components/features/org-management/modals/EditSSOModal.tsx
```

- [ ] **Step 2: Update `DetailTabs.tsx`**

Remove the SSO tab trigger and SSO tab content panel. The tabs become: Overview, Users, Provisioning.

- [ ] **Step 3: Update `OrgDetailPanel.tsx`**

Remove:
- `useToggleSSO()` import and call (~line 53)
- `editSSOOpen` state (~line 54)
- `executeToggle()` handler (~lines 59–72)
- `handleToggleSSO()` handler (~lines 74–88)
- `handleEditSSO()` handler (~lines 95–97)
- SSO confirmation dialog (~lines 115–131)
- `EditSSOModal` render (~lines 134–142)
- All SSO-related imports

- [ ] **Step 4: Update `OverviewTab.tsx`**

Remove `SSOBadge` import and its render (`<SSOBadge enabled={org.ssoConfig?.enabled}/>`).

- [ ] **Step 5: Update `org-mutations.ts`**

Remove `useToggleSSO()` (~lines 47–62) and `useUpdateSSOConfig()` (~lines 65–78).

- [ ] **Step 6: Update `ConfigTab.tsx`**

Remove the SSO section block (lines 58–74):
```tsx
{/* SSO */}
<ConfigSection
  title={sectionConfig.sso.label}
  ...
</ConfigSection>
```

Also remove the QR Settings section (lines 76–93).

- [ ] **Step 7: Update `profile-type-config.ts`**

Remove `sso` and `qr` entries from `sectionConfig`. Update the Record type key union.

- [ ] **Step 8: Update `org-profiles.ts` types**

Remove:
- `FeatureKey` type (line 15)
- `SsoConfig` interface (lines 51–58)
- `QrSettings` interface (lines 61–66)
- `ssoEnabled` from `ProfileListItem` (line 42)
- `sso: SsoConfig` from `ProfileDetail` (line 89)
- `qr: QrSettings` from `ProfileDetail` (line 90)
- `ToggleSectionPayload` interface (lines 202–205)
- SSO/QR fields from `CreateProfilePayload` and `UpdateProfilePayload`

- [ ] **Step 9: Verify frontend builds**

```bash
cd src/frontend && npx tsc --noEmit
```

- [ ] **Step 10: Commit**

```bash
git add -u src/frontend/
git commit -m "refactor(frontend): remove SSO config from org management and profiles"
```

---

### Task 8: Frontend — Remove QR components, routes, dashboard, and onboarding

**Files to delete:**
- `src/frontend/src/components/features/qr-management/` (entire directory — 9 files)
- `src/frontend/src/components/features/qr-preview/QRPreviewPage.tsx`
- `src/frontend/src/components/features/user-management/modals/QRGenerationModal.tsx`
- `src/frontend/src/components/features/user-management/onboarding/StepQRCode.tsx`
- `src/frontend/src/components/features/org-management/QRSettingItem.tsx`
- `src/frontend/src/components/features/dashboard/RecentQRCard.tsx`
- `src/frontend/src/components/features/dashboard/QRTable.tsx`
- `src/frontend/src/components/features/dashboard/QRTableRow.tsx` (if exists)
- `src/frontend/src/routes/qr/preview.$token.tsx`
- `src/frontend/src/routes/provisioning/qr-codes.tsx`
- `src/frontend/src/lib/queries/qr.ts`
- `src/frontend/src/lib/queries/qr-generation.ts`
- `src/frontend/src/lib/queries/qr-management.ts`
- `src/frontend/src/lib/queries/qr-share.ts`
- `src/frontend/src/lib/utils/qr-helpers.ts`
- `src/frontend/src/types/qr.ts`
- `src/frontend/src/types/qr-management.ts`

**Files to modify:**
- `src/frontend/src/components/features/dashboard/DashboardMain.tsx` — remove `RecentQRCard`
- `src/frontend/src/lib/queries/dashboard.ts` — remove `recentQRQueryOptions`
- `src/frontend/src/components/features/user-management/onboarding/OnboardingWizard.tsx` — remove Step 3 (QR), renumber
- `src/frontend/src/types/index.ts` — remove QR re-exports
- `src/frontend/src/components/features/org-management/ProvisioningTab.tsx` — remove QR content or delete if QR-only

- [ ] **Step 1: Delete QR component directories and files**

```bash
rm -rf src/frontend/src/components/features/qr-management/
rm -rf src/frontend/src/components/features/qr-preview/
rm src/frontend/src/components/features/user-management/modals/QRGenerationModal.tsx
rm src/frontend/src/components/features/user-management/onboarding/StepQRCode.tsx
rm src/frontend/src/components/features/org-management/QRSettingItem.tsx
rm src/frontend/src/components/features/dashboard/RecentQRCard.tsx
rm src/frontend/src/components/features/dashboard/QRTable.tsx
```

Also delete `QRTableRow.tsx` if it exists in the dashboard directory.

- [ ] **Step 2: Delete QR routes**

```bash
rm src/frontend/src/routes/qr/preview.\$token.tsx
rm src/frontend/src/routes/provisioning/qr-codes.tsx
```

After deleting routes, regenerate the route tree:
```bash
just ui-routes
```

- [ ] **Step 3: Delete QR query and type files**

```bash
rm src/frontend/src/lib/queries/qr.ts \
   src/frontend/src/lib/queries/qr-generation.ts \
   src/frontend/src/lib/queries/qr-management.ts \
   src/frontend/src/lib/queries/qr-share.ts \
   src/frontend/src/lib/utils/qr-helpers.ts \
   src/frontend/src/types/qr.ts \
   src/frontend/src/types/qr-management.ts
```

- [ ] **Step 4: Update `DashboardMain.tsx`**

Remove the `RecentQRCard` import and its `<RecentQRCard />` render. Keep other dashboard cards.

- [ ] **Step 5: Update `dashboard.ts` queries**

Remove `recentQRQueryOptions` export (~lines 61–68). Keep other dashboard query hooks.

- [ ] **Step 6: Update `OnboardingWizard.tsx`**

Remove Step 3 (QR Code) from the STEPS array (~lines 153–159). The new step order:
```
0: User Info
1: Organization
2: Profile
3: Complete  (was Step 4)
```

Remove the `StepQRCode` import and its render case. Also remove `useGenerateQR` import if present.

- [ ] **Step 7: Update `ProvisioningTab.tsx`**

Check if it's QR-only. If so, delete or replace with a placeholder. If it has non-QR content, remove only QR references.

- [ ] **Step 8: Update `types/index.ts`**

Remove these re-exports:
```typescript
export * from './qr';
export * from './qr-management';
```
Also remove any SSO type re-exports if present.

- [ ] **Step 9: Verify frontend builds**

```bash
cd src/frontend && npx tsc --noEmit
```

- [ ] **Step 10: Commit**

Stage with `git add` (not `-u`) to include the regenerated `routeTree.gen.ts`:
```bash
git add src/frontend/
git commit -m "refactor(frontend): remove all QR components, routes, queries, and types"
```

---

### Task 9: Apply migration and run full test suite

- [ ] **Step 1: Start stack if needed**

```bash
just up-bg
```

- [ ] **Step 2: Apply migration**

```bash
just psql < ../../migrations/024_remove_sso_qr.sql
```

- [ ] **Step 3: Run full test suite**

```bash
just test-quick
```

Expected: All remaining tests pass. QR tests are deleted. Config template tests updated.

- [ ] **Step 4: Fix any failures**

If tests reference deleted endpoints, tables, or methods — update them.

- [ ] **Step 5: Verify frontend builds cleanly**

```bash
just ui-build
```

- [ ] **Step 6: Final commit if any fixes**

```bash
git add -A
git commit -m "fix: resolve test/build failures after SSO+QR removal"
```

- [ ] **Step 7: Create PR 1**

```bash
git push -u origin chore/remove-sso-qr
gh pr create --title "chore: remove SSO config and QR provisioning" --body "$(cat <<'EOF'
## Summary
- Remove SSO config from profiles and org management (Authentik is platform SSO)
- Remove all QR provisioning infrastructure (replaced by SSO device provisioning)
- Rename provision_tokens → device_provisions
- Delete 7 QR test files, 9 QR management components, QR routes, dashboard QR card
- Migration 024: drop sso_config, qr_settings columns; drop qr_issuance_audit, qr_issues, qr_preview_links tables

## Test plan
- [ ] All remaining tests pass after QR/SSO removal
- [ ] Frontend builds without type errors
- [ ] Config template CRUD still works without SSO/QR fields
- [ ] Device provisioning (SSO) still works with renamed table
- [ ] Dashboard loads without QR card
- [ ] Onboarding wizard works without QR step
EOF
)"
```

---

## Chunk 2: PR 2 — Profile Services Restructuring

### Task 10: Create branch and migration file

**Files:**
- Create: `migrations/025_profile_services.sql`

- [ ] **Step 1: Create feature branch from main (after PR 1 merges)**

```bash
git checkout -b feat/profile-services main
```

- [ ] **Step 2: Write migration**

```sql
-- 025_profile_services.sql
-- Create profile_services table; migrate XMPP/SIP from flat columns.

CREATE TABLE profile_services (
    id            VARCHAR(128) PRIMARY KEY,
    profile_id    VARCHAR(128) NOT NULL REFERENCES config_templates(id) ON DELETE CASCADE,
    service_type  VARCHAR(50) NOT NULL,
    enabled       BOOLEAN NOT NULL DEFAULT true,
    config        JSON NOT NULL DEFAULT '{}',
    next_counter  INTEGER,
    counter_start INTEGER,
    counter_end   INTEGER,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(profile_id, service_type)
);

-- Migrate XMPP services
INSERT INTO profile_services (id, profile_id, service_type, enabled, config)
SELECT
    gen_random_uuid()::text, id, 'xmpp', xmpp_enabled,
    json_build_object('domain', COALESCE(xmpp_domain, ''), 'ws_url', COALESCE(xmpp_ws_url, ''))
FROM config_templates
WHERE xmpp_enabled = true OR xmpp_domain IS NOT NULL;

-- Migrate SIP services with counters
INSERT INTO profile_services (id, profile_id, service_type, enabled, config, next_counter, counter_start, counter_end)
SELECT
    gen_random_uuid()::text, id, 'sip', sip_enabled,
    json_build_object('domain', COALESCE(sip_domain, ''), 'wss_url', COALESCE(sip_wss_url, '')),
    next_extension, ext_range_start, ext_range_end
FROM config_templates
WHERE sip_enabled = true OR sip_domain IS NOT NULL;

-- NOTE: Profiles with no UC config intentionally have no profile_services rows (services: []).
-- NOTE: gen_random_uuid() requires PostgreSQL 13+ or pgcrypto extension.

-- Drop migrated columns
ALTER TABLE config_templates DROP COLUMN xmpp_enabled;
ALTER TABLE config_templates DROP COLUMN sip_enabled;
ALTER TABLE config_templates DROP COLUMN xmpp_domain;
ALTER TABLE config_templates DROP COLUMN xmpp_ws_url;
ALTER TABLE config_templates DROP COLUMN sip_domain;
ALTER TABLE config_templates DROP COLUMN sip_wss_url;
ALTER TABLE config_templates DROP COLUMN next_extension;
ALTER TABLE config_templates DROP COLUMN ext_range_start;
ALTER TABLE config_templates DROP COLUMN ext_range_end;
```

- [ ] **Step 3: Commit**

```bash
git add migrations/025_profile_services.sql
git commit -m "chore(db): migration 025 — create profile_services, migrate XMPP/SIP data"
```

---

### Task 11: Backend — Add profile_services table and CRUD to orgdb.py

**Files:**
- Modify: `src/backend/orgdb.py`

- [ ] **Step 1: Write failing test for `add_profile_service()`**

Create `tests/test_profile_services.py`:

```python
"""Tests for profile_services CRUD operations."""
import pytest
import uuid


def _create_test_template(client):
    """Create a minimal config template for testing."""
    name = f"test-svc-{uuid.uuid4().hex[:8]}"
    resp = client.post("/api/config-templates", json={"name": name})
    assert resp.status_code == 201
    return resp.json()["template"]["id"], name


def test_add_xmpp_service(client):
    """Adding an XMPP service to a profile creates a service record."""
    tid, _ = _create_test_template(client)
    resp = client.post(f"/api/config-templates/{tid}/services", json={
        "serviceType": "xmpp",
        "enabled": True,
        "config": {"domain": "test.example.com", "ws_url": "wss://xmpp.test.example.com/ws"},
    })
    assert resp.status_code == 201
    svc = resp.json()["service"]
    assert svc["serviceType"] == "xmpp"
    assert svc["enabled"] is True
    assert svc["config"]["domain"] == "test.example.com"


def test_add_sip_service_with_counters(client):
    """Adding a SIP service includes counter fields."""
    tid, _ = _create_test_template(client)
    resp = client.post(f"/api/config-templates/{tid}/services", json={
        "serviceType": "sip",
        "enabled": True,
        "config": {"domain": "sip.test.com", "wss_url": "wss://sip.test.com"},
        "counterStart": 6000,
        "counterEnd": 6999,
    })
    assert resp.status_code == 201
    svc = resp.json()["service"]
    assert svc["serviceType"] == "sip"
    assert svc["counterStart"] == 6000
    assert svc["counterEnd"] == 6999
    assert svc["nextCounter"] == 6000


def test_duplicate_service_type_rejected(client):
    """Cannot add two services of the same type to one profile."""
    tid, _ = _create_test_template(client)
    client.post(f"/api/config-templates/{tid}/services", json={
        "serviceType": "xmpp", "config": {"domain": "a.com", "ws_url": "wss://a.com/ws"},
    })
    resp = client.post(f"/api/config-templates/{tid}/services", json={
        "serviceType": "xmpp", "config": {"domain": "b.com", "ws_url": "wss://b.com/ws"},
    })
    assert resp.status_code == 409


def test_get_profile_services(client):
    """Profile detail includes services array."""
    tid, _ = _create_test_template(client)
    client.post(f"/api/config-templates/{tid}/services", json={
        "serviceType": "xmpp", "config": {"domain": "x.com", "ws_url": "wss://x.com/ws"},
    })
    resp = client.get(f"/api/config-templates/{tid}")
    assert resp.status_code == 200
    detail = resp.json()["template"]
    assert "services" in detail
    assert len(detail["services"]) == 1
    assert detail["services"][0]["serviceType"] == "xmpp"


def test_remove_service(client):
    """Deleting a service removes it from the profile."""
    tid, _ = _create_test_template(client)
    add_resp = client.post(f"/api/config-templates/{tid}/services", json={
        "serviceType": "xmpp", "config": {"domain": "x.com", "ws_url": "wss://x.com/ws"},
    })
    svc_id = add_resp.json()["service"]["id"]
    del_resp = client.delete(f"/api/config-templates/{tid}/services/{svc_id}")
    assert del_resp.status_code == 200
    detail = client.get(f"/api/config-templates/{tid}").json()["template"]
    assert len(detail["services"]) == 0


def test_update_service(client):
    """Updating a service modifies its config."""
    tid, _ = _create_test_template(client)
    add_resp = client.post(f"/api/config-templates/{tid}/services", json={
        "serviceType": "xmpp", "config": {"domain": "old.com", "ws_url": "wss://old.com/ws"},
    })
    svc_id = add_resp.json()["service"]["id"]
    put_resp = client.put(f"/api/config-templates/{tid}/services/{svc_id}", json={
        "config": {"domain": "new.com", "ws_url": "wss://new.com/ws"},
    })
    assert put_resp.status_code == 200
    assert put_resp.json()["service"]["config"]["domain"] == "new.com"


def test_clone_includes_services(client):
    """Cloning a profile also clones its services."""
    tid, name = _create_test_template(client)
    client.post(f"/api/config-templates/{tid}/services", json={
        "serviceType": "xmpp", "config": {"domain": "x.com", "ws_url": "wss://x.com/ws"},
    })
    clone_resp = client.post(f"/api/config-templates/{tid}/clone", json={})
    assert clone_resp.status_code == 201
    clone = clone_resp.json()["template"]
    assert len(clone["services"]) == 1
    assert clone["services"][0]["serviceType"] == "xmpp"
    assert clone["id"] != tid


def test_extensible_service_type(client):
    """Arbitrary service types work (future extensibility)."""
    tid, _ = _create_test_template(client)
    resp = client.post(f"/api/config-templates/{tid}/services", json={
        "serviceType": "matrix",
        "config": {"domain": "matrix.example.com", "homeserver_url": "https://matrix.example.com"},
    })
    assert resp.status_code == 201
    assert resp.json()["service"]["serviceType"] == "matrix"
```

- [ ] **Step 2: Run tests — confirm they fail**

```bash
pytest tests/test_profile_services.py -v 2>&1 | head -30
```

Expected: FAIL (endpoints don't exist yet)

- [ ] **Step 3: Add `profile_services` SQLAlchemy Table definition to orgdb.py**

Add after the `config_template_history` table definition (~line 329):

```python
# --- Profile Services (per-profile UC service configs) ---

profile_services = Table(
    "profile_services", metadata,
    Column("id", String(128), primary_key=True),
    Column("profile_id", String(128), ForeignKey("config_templates.id", ondelete="CASCADE"), nullable=False),
    Column("service_type", String(50), nullable=False),
    Column("enabled", Boolean, nullable=False, server_default="true"),
    Column("config", JSON, nullable=False, server_default='{}'),
    Column("next_counter", Integer, nullable=True),
    Column("counter_start", Integer, nullable=True),
    Column("counter_end", Integer, nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("updated_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    UniqueConstraint("profile_id", "service_type"),
)
```

- [ ] **Step 4: Add CRUD methods to OrgDB class**

```python
def get_profile_services(self, profile_id: str) -> list[dict]:
    """Get all services for a profile."""
    with self.engine.connect() as conn:
        rows = conn.execute(
            select(profile_services)
            .where(profile_services.c.profile_id == profile_id)
            .order_by(profile_services.c.service_type)
        ).mappings().all()
        return [dict(r) for r in rows]

def add_profile_service(self, profile_id: str, data: dict) -> dict:
    """Attach a service to a profile. Raises on duplicate service_type."""
    svc_id = str(uuid.uuid4())
    with self.engine.begin() as conn:
        conn.execute(profile_services.insert().values(
            id=svc_id,
            profile_id=profile_id,
            service_type=data["service_type"],
            enabled=data.get("enabled", True),
            config=json.dumps(data.get("config", {})),
            next_counter=data.get("counter_start"),  # init to start
            counter_start=data.get("counter_start"),
            counter_end=data.get("counter_end"),
        ))
        row = conn.execute(
            select(profile_services).where(profile_services.c.id == svc_id)
        ).mappings().first()
        return dict(row)

def update_profile_service(self, service_id: str, data: dict) -> dict | None:
    """Update a service's config/enabled/counters."""
    updates = {}
    if "config" in data:
        updates["config"] = json.dumps(data["config"])
    if "enabled" in data:
        updates["enabled"] = data["enabled"]
    if "counter_start" in data:
        updates["counter_start"] = data["counter_start"]
    if "counter_end" in data:
        updates["counter_end"] = data["counter_end"]
    updates["updated_at"] = func.now()
    with self.engine.begin() as conn:
        conn.execute(
            update(profile_services)
            .where(profile_services.c.id == service_id)
            .values(**updates)
        )
        row = conn.execute(
            select(profile_services).where(profile_services.c.id == service_id)
        ).mappings().first()
        return dict(row) if row else None

def remove_profile_service(self, service_id: str) -> bool:
    """Remove a service from a profile."""
    with self.engine.begin() as conn:
        result = conn.execute(
            delete(profile_services).where(profile_services.c.id == service_id)
        )
        return result.rowcount > 0
```

- [ ] **Step 5: Remove flat XMPP/SIP columns from `config_templates` Table definition**

Remove these columns:
```python
Column("xmpp_enabled", Boolean, ...),
Column("sip_enabled", Boolean, ...),
Column("xmpp_domain", Text, ...),
Column("xmpp_ws_url", Text, ...),
Column("sip_domain", Text, ...),
Column("sip_wss_url", Text, ...),
Column("next_extension", Integer, ...),
Column("ext_range_start", Integer, ...),
Column("ext_range_end", Integer, ...),
```

- [ ] **Step 6: Remove flat XMPP/SIP fields from `create_config_template()` and `update_config_template()`**

In `create_config_template()`, remove:
```python
xmpp_enabled=data.get("xmpp_enabled", False),
sip_enabled=data.get("sip_enabled", False),
xmpp_domain=data.get("xmpp_domain"),
...
```

In `update_config_template()`, remove XMPP/SIP from the updatable fields loop:
```python
"xmpp_enabled", "sip_enabled",
"xmpp_domain", "xmpp_ws_url", "sip_domain", "sip_wss_url",
"next_extension", "ext_range_start", "ext_range_end",
```

- [ ] **Step 7: Update `clone_config_template()` to clone services**

After cloning the template row, also clone associated services:

```python
# Clone services
services = self.get_profile_services(template_id)
for svc in services:
    self.add_profile_service(clone_id, {
        "service_type": svc["service_type"],
        "enabled": svc["enabled"],
        "config": svc["config"] if isinstance(svc["config"], dict) else json.loads(svc["config"]),
        "counter_start": svc["counter_start"],
        "counter_end": svc["counter_end"],
    })
```

- [ ] **Step 8: Verify orgdb imports**

```bash
cd src/backend && python -c "import orgdb; print('OK')"
```

- [ ] **Step 9: Commit**

```bash
git add src/backend/orgdb.py tests/test_profile_services.py
git commit -m "feat(backend): add profile_services table and CRUD methods to orgdb"
```

---

### Task 12: Backend — Rewrite allocate_extension and provisioning.py

**Files:**
- Modify: `src/backend/orgdb.py`
- Modify: `src/backend/provisioning.py`

- [ ] **Step 1: Rewrite `allocate_extension()` in orgdb.py**

Replace the existing method that queries `config_templates.next_extension`:

```python
def allocate_extension(self, profile_id: str) -> int:
    """Allocate next SIP extension from the profile's SIP service counter.

    - Atomically increments next_counter on the 'sip' profile_service row
    - Raises ExtensionRangeExhausted if counter exceeds counter_end
    """
    with self.engine.begin() as conn:
        row = conn.execute(
            profile_services.update()
            .where(
                (profile_services.c.profile_id == profile_id)
                & (profile_services.c.service_type == "sip")
                & (profile_services.c.next_counter <= profile_services.c.counter_end)
            )
            .values(next_counter=profile_services.c.next_counter + 1)
            .returning(profile_services.c.next_counter - 1)
        ).first()
        if row is None:
            raise ExtensionRangeExhausted(profile_id)
        return row[0]
```

Verify `ExtensionRangeExhausted` exception class exists. If not, define it:
```python
class ExtensionRangeExhausted(Exception):
    def __init__(self, profile_id: str):
        super().__init__(f"Extension range exhausted for profile {profile_id}")
```

- [ ] **Step 2: Update `allocate_uc_resources()` in provisioning.py**

Change signature from receiving booleans to receiving service list:

```python
def allocate_uc_resources(
    orgdb,
    profile_id: str,
    services: list[dict],
) -> ProvisioningResult:
    """Allocate UC resources based on profile services.

    - services: list of service dicts from orgdb.get_profile_services()
    - Allocates uidNumber (profile-level) if any service present
    - Allocates extension if 'sip' service present
    """
    if not services:
        return ProvisioningResult(uid_number=0, extension=None, sip_password=None)

    uid_number = orgdb.allocate_uid_number(profile_id)

    sip_service = next((s for s in services if s["service_type"] == "sip" and s.get("enabled", True)), None)
    extension = None
    sip_password = None
    if sip_service:
        extension = orgdb.allocate_extension(profile_id)
        sip_password = generate_sip_password()

    return ProvisioningResult(
        uid_number=uid_number,
        extension=extension,
        sip_password=sip_password,
    )
```

- [ ] **Step 3: Update caller in main.py**

Find the call site (~line 1515):
```python
# Before
prov = allocate_uc_resources(ORGDB, req.profileId, xmpp_on, sip_on)

# After
services = ORGDB.get_profile_services(req.profileId)
prov = allocate_uc_resources(ORGDB, req.profileId, services)
```

Also update `build_uc_attrs` call at the same site to derive enablement from services:
```python
xmpp_on = any(s["service_type"] == "xmpp" and s.get("enabled", True) for s in services)
sip_on = any(s["service_type"] == "sip" and s.get("enabled", True) for s in services)
```

- [ ] **Step 4: Verify backend starts**

```bash
cd src/backend && python -c "import main; print('OK')"
```

- [ ] **Step 5: Commit**

```bash
git add src/backend/orgdb.py src/backend/provisioning.py src/backend/main.py
git commit -m "feat(backend): rewrite allocate_extension for profile_services, update provisioning.py"
```

---

### Task 13: Backend — Update build_uc_attrs and main.py formatters

**Files:**
- Modify: `src/backend/ldap_client.py`
- Modify: `src/backend/main.py`

- [ ] **Step 1: Update `build_uc_attrs()` signature in ldap_client.py**

```python
# Before
def build_uc_attrs(
    *,
    xmpp_enabled: bool,
    sip_enabled: bool,
    uid_number: int | None,
    extension: int | None,
    sip_password: str | None,
    username: str,
    xmpp_password: str | None = None,
    profile_id: str | None = None,
) -> tuple[dict[str, str], list[str]]:

# After
def build_uc_attrs(
    *,
    services: list[dict],
    uid_number: int | None,
    extension: int | None,
    sip_password: str | None,
    username: str,
    xmpp_password: str | None = None,
    profile_id: str | None = None,
) -> tuple[dict[str, str], list[str]]:
    """Build UC LDAP attributes and objectClasses for a user entry.

    - services: list of profile service dicts (from get_profile_services())
    - Iterates services to determine which objectClasses/attrs to add
    """
    xmpp_enabled = any(s["service_type"] == "xmpp" and s.get("enabled", True) for s in services)
    sip_enabled = any(s["service_type"] == "sip" and s.get("enabled", True) for s in services)

    if not xmpp_enabled and not sip_enabled:
        return {}, []
    # ... rest of existing logic unchanged
```

- [ ] **Step 2: Update all callers of `build_uc_attrs()` in main.py**

Replace `xmpp_enabled=xmpp_on, sip_enabled=sip_on` with `services=services`.

- [ ] **Step 3: Add Pydantic models for service endpoints**

Add to main.py near the other Pydantic models:

```python
class XmppConfig(BaseModel):
    domain: str
    ws_url: str = Field(alias="wsUrl")

class SipConfig(BaseModel):
    domain: str
    wss_url: str = Field(alias="wssUrl")

class AddServiceRequest(BaseModel):
    service_type: str = Field(alias="serviceType")
    enabled: bool = True
    config: dict
    counter_start: int | None = Field(None, alias="counterStart")
    counter_end: int | None = Field(None, alias="counterEnd")

    model_config = {"populate_by_name": True}

class UpdateServiceRequest(BaseModel):
    config: dict | None = None
    enabled: bool | None = None
    counter_start: int | None = Field(None, alias="counterStart")
    counter_end: int | None = Field(None, alias="counterEnd")

    model_config = {"populate_by_name": True}
```

- [ ] **Step 4: Add service endpoints to main.py**

```python
@app.post("/api/config-templates/{template_id}/services", status_code=201)
def api_add_profile_service(template_id: str, req: AddServiceRequest, claims = require_permission("system_configuration")):
    """Attach a service to a profile."""
    if not ORGDB.get_config_template(template_id):
        raise HTTPException(404, "Config template not found")
    try:
        svc = ORGDB.add_profile_service(template_id, {
            "service_type": req.service_type,
            "enabled": req.enabled,
            "config": req.config,
            "counter_start": req.counter_start,
            "counter_end": req.counter_end,
        })
    except IntegrityError:
        raise HTTPException(409, f"Service type '{req.service_type}' already exists on this profile")
    return {"ok": True, "service": _format_service(svc)}


@app.put("/api/config-templates/{template_id}/services/{service_id}")
def api_update_profile_service(template_id: str, service_id: str, req: UpdateServiceRequest, claims = require_permission("system_configuration")):
    """Update a service on a profile."""
    updates = req.model_dump(exclude_none=True, by_alias=False)
    svc = ORGDB.update_profile_service(service_id, updates)
    if not svc:
        raise HTTPException(404, "Service not found")
    return {"ok": True, "service": _format_service(svc)}


@app.delete("/api/config-templates/{template_id}/services/{service_id}")
def api_remove_profile_service(template_id: str, service_id: str, claims = require_permission("system_configuration")):
    """Remove a service from a profile."""
    if not ORGDB.remove_profile_service(service_id):
        raise HTTPException(404, "Service not found")
    return {"ok": True}


def _format_service(svc: dict) -> dict:
    """Format a profile_services row for API response."""
    config = svc.get("config", {})
    if isinstance(config, str):
        config = json.loads(config)
    return {
        "id": svc["id"],
        "serviceType": svc["service_type"],
        "enabled": svc.get("enabled", True),
        "config": config,
        "nextCounter": svc.get("next_counter"),
        "counterStart": svc.get("counter_start"),
        "counterEnd": svc.get("counter_end"),
    }
```

- [ ] **Step 5: Update list query to include services**

The current `list_config_templates()` in orgdb.py returns rows without services. Update it to also fetch services for each template. Two approaches:

**Option A (simpler):** In the list API endpoint, after fetching template rows, batch-fetch services per template:
```python
@app.get("/api/config-templates")
def api_list_config_templates(claims = require_permission("system_configuration")):
    rows = ORGDB.list_config_templates()
    # Batch-fetch services for all templates
    all_services = {}
    for row in rows:
        all_services[row["id"]] = ORGDB.get_profile_services(row["id"])
    return {
        "ok": True,
        "templates": [
            {**_format_template_list_item(row),
             "services": [
                 {"serviceType": s["service_type"], "enabled": s.get("enabled", True)}
                 for s in all_services.get(row["id"], [])
             ]}
            for row in rows
        ],
    }
```

**Option B (more efficient):** Add a `list_all_profile_services()` method that fetches all services in one query and groups by profile_id.

- [ ] **Step 6: Update `_format_template_detail()` to include services**

In the detail endpoint, fetch services and pass to the formatter:
```python
@app.get("/api/config-templates/{template_id}")
def api_get_config_template(template_id, claims = ...):
    row = ORGDB.get_config_template(template_id)
    ...
    services = ORGDB.get_profile_services(template_id)
    ...
    detail = _format_template_detail(row, history, assignments)
    detail["services"] = [_format_service(s) for s in services]
    return {"ok": True, "template": detail}
```

Remove flat `xmppEnabled`/`sipEnabled`/`xmppDomain`/etc. fields from both `_format_template_list_item()` and `_format_template_detail()`.

- [ ] **Step 7: Update device provisioning endpoint**

The `POST /api/provision/device` endpoint resolves profile config for credential sealing. Update it to read from `get_profile_services()`:

```python
# In the device provisioning handler, after resolving profile_id:
services = ORGDB.get_profile_services(profile_id)

# Build credential payload from service configs:
xmpp_svc = next((s for s in services if s["service_type"] == "xmpp" and s.get("enabled")), None)
sip_svc = next((s for s in services if s["service_type"] == "sip" and s.get("enabled")), None)

# Extract endpoints for the sealed credential payload:
xmpp_config = json.loads(xmpp_svc["config"]) if xmpp_svc and isinstance(xmpp_svc["config"], str) else (xmpp_svc or {}).get("config", {})
sip_config = json.loads(sip_svc["config"]) if sip_svc and isinstance(sip_svc["config"], str) else (sip_svc or {}).get("config", {})

# Map service config → credential payload fields:
# xmpp_config["domain"] → payload "xmpp_domain"
# xmpp_config["ws_url"] → payload "xmpp_ws_url"
# sip_config["domain"] → payload "sip_domain"
# sip_config["wss_url"] → payload "sip_wss_url"
```

Add a test assertion that the device provision response contains correct service endpoint URLs from the profile's services.

- [ ] **Step 8: Run profile services tests**

```bash
pytest tests/test_profile_services.py -v
```

Expected: All tests pass.

- [ ] **Step 9: Commit**

```bash
git add src/backend/ldap_client.py src/backend/main.py
git commit -m "feat(backend): add service endpoints, update build_uc_attrs and formatters"
```

---

### Task 14: Frontend — Update types for services model

**Files:**
- Modify: `src/frontend/src/types/org-profiles.ts`

- [ ] **Step 1: Add service types**

```typescript
/** Known UC service types (extensible) */
export type ServiceType = 'xmpp' | 'sip' | (string & {});

/** Service record attached to a profile */
export interface ProfileService {
  id: string;
  serviceType: ServiceType;
  enabled: boolean;
  config: Record<string, unknown>;
  nextCounter?: number;
  counterStart?: number;
  counterEnd?: number;
}
```

- [ ] **Step 2: Update `ProfileListItem`**

```typescript
// Remove: xmppEnabled, sipEnabled
// Add:
export interface ProfileListItem extends ProfileBase {
  services: { serviceType: string; enabled: boolean }[];
  usageStats: ProfileUsageStats;
}
```

- [ ] **Step 3: Update `ProfileDetail`**

```typescript
// Remove: xmppEnabled, sipEnabled, xmppDomain, xmppWsUrl, sipDomain, sipWssUrl
// Remove: nextExtension, extRangeStart, extRangeEnd
// Add:
export interface ProfileDetail extends ProfileBase {
  services: ProfileService[];
  maxDevicesPerUser: number;
  nextUidNumber: number;
  uidRangeStart: number;
  uidRangeEnd: number;
  assignedOrgs: ProfileAssignedOrg[];
  history: ProfileHistoryEntry[];
  usageStats: ProfileUsageStats;
  createdBy: string | null;
  updatedBy: string | null;
}
```

- [ ] **Step 4: Update payloads**

Remove XMPP/SIP flat fields from `CreateProfilePayload` and `UpdateProfilePayload`.

- [ ] **Step 5: Commit**

```bash
git add src/frontend/src/types/org-profiles.ts
git commit -m "feat(frontend): update org-profiles types for services model"
```

---

### Task 15: Frontend — Update profile components for services

**Files:**
- Modify: `src/frontend/src/components/features/org-profiles/ConfigTab.tsx`
- Modify: `src/frontend/src/components/features/org-profiles/profile-type-config.ts`
- Modify: `src/frontend/src/components/features/org-profiles/ProfileCard.tsx`
- Create: `src/frontend/src/components/features/org-profiles/ServiceCard.tsx`
- Create: `src/frontend/src/components/features/org-profiles/modals/AddServiceModal.tsx`

- [ ] **Step 1: Update `profile-type-config.ts`**

Remove `uc` entry from `sectionConfig`. Update the type to `Record<string, ...>`:
```typescript
export const sectionConfig: Record<
  string,
  { icon: typeof MessageCircle; color: string; bg: string; label: string }
> = {
  xmpp: { icon: MessageCircle, color: 'text-blue-400', bg: 'bg-blue-500/10', label: 'XMPP' },
  sip: { icon: Phone, color: 'text-green-400', bg: 'bg-green-500/10', label: 'SIP' },
};

/** Fallback config for unknown service types */
export const defaultServiceConfig = {
  icon: Server,
  color: 'text-gray-400',
  bg: 'bg-gray-500/10',
  label: 'Service',
};
```

- [ ] **Step 2: Create `ServiceCard.tsx`**

```tsx
/**
 * ServiceCard — renders a single profile service with its config fields.
 * Resolves icon/color from sectionConfig, falls back for unknown types.
 */
import { ConfigSection, ConfigRow } from './ConfigSection';
import { sectionConfig, defaultServiceConfig } from './profile-type-config';
import type { ProfileService } from '@/types/org-profiles';

interface ServiceCardProps {
  service: ProfileService;
}

export function ServiceCard({ service }: ServiceCardProps) {
  const cfg = sectionConfig[service.serviceType] ?? {
    ...defaultServiceConfig,
    label: service.serviceType.toUpperCase(),
  };

  return (
    <ConfigSection
      title={cfg.label}
      sectionKey={service.serviceType}
      icon={cfg.icon}
      iconColor={cfg.color}
      iconBg={cfg.bg}
      enabled={service.enabled}
      showToggle={false}
    >
      {Object.entries(service.config).map(([key, value]) => (
        <ConfigRow key={key} label={key} value={String(value)} />
      ))}
      {service.counterStart != null && service.counterEnd != null && (
        <>
          <ConfigRow label="Counter Range" value={`${service.counterStart}–${service.counterEnd}`} />
          <ConfigRow label="Next Counter" value={service.nextCounter} />
        </>
      )}
    </ConfigSection>
  );
}
```

- [ ] **Step 3: Rewrite `ConfigTab.tsx`**

Replace the hardcoded UC Services section with a dynamic loop:

```tsx
/**
 * ConfigTab — "Configuration" tab for profile detail.
 * Renders a ServiceCard for each attached service.
 */
import { ServiceCard } from './ServiceCard';
import type { ProfileDetail } from '@/types/org-profiles';

interface ConfigTabProps {
  profile: ProfileDetail;
}

export function ConfigTab({ profile }: ConfigTabProps) {
  return (
    <div className="flex flex-col gap-4">
      {profile.services.length === 0 && (
        <p className="text-sm text-muted-foreground">No services configured.</p>
      )}
      {profile.services.map((svc) => (
        <ServiceCard key={svc.id} service={svc} />
      ))}
    </div>
  );
}
```

- [ ] **Step 4: Update `ProfileCard.tsx`**

Replace `xmppEnabled`/`sipEnabled` badge logic with dynamic service badges from `profile.services`.

- [ ] **Step 5: Create TanStack Query mutation hooks**

Create `src/frontend/src/lib/queries/profile-services.ts`:

```typescript
/**
 * TanStack Query hooks for profile service CRUD.
 */
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/api-client';
import type { ProfileService } from '@/types/org-profiles';

interface AddServicePayload {
  serviceType: string;
  enabled?: boolean;
  config: Record<string, unknown>;
  counterStart?: number;
  counterEnd?: number;
}

export function useAddService(templateId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: AddServicePayload) =>
      api.post(`/config-templates/${templateId}/services`, data)
        .then((r) => r.data as { ok: boolean; service: ProfileService }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['config-template', templateId] }),
  });
}

export function useUpdateService(templateId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ serviceId, ...data }: { serviceId: string } & Partial<AddServicePayload>) =>
      api.put(`/config-templates/${templateId}/services/${serviceId}`, data)
        .then((r) => r.data as { ok: boolean; service: ProfileService }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['config-template', templateId] }),
  });
}

export function useRemoveService(templateId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (serviceId: string) =>
      api.delete(`/config-templates/${templateId}/services/${serviceId}`)
        .then((r) => r.data as { ok: boolean }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['config-template', templateId] }),
  });
}
```

- [ ] **Step 6: Create `AddServiceModal.tsx`**

A modal that lets admins select a service type and configure its fields. Uses `useAddService()` mutation hook. Form with service_type selector, config JSON fields per type, optional counter range.

- [ ] **Step 7: Verify frontend builds**

```bash
cd src/frontend && npx tsc --noEmit
```

- [ ] **Step 8: Commit**

```bash
git add src/frontend/src/components/features/org-profiles/ src/frontend/src/lib/queries/profile-services.ts
git commit -m "feat(frontend): add ServiceCard, query hooks, rewrite ConfigTab for dynamic services"
```

---

### Task 16: Apply migration and run full test suite for PR 2

- [ ] **Step 1: Apply migration**

```bash
just psql < ../../migrations/025_profile_services.sql
```

- [ ] **Step 2: Run all tests**

```bash
just test-quick
```

- [ ] **Step 3: Run profile services tests specifically**

```bash
pytest tests/test_profile_services.py -v
```

- [ ] **Step 4: Verify frontend builds**

```bash
just ui-build
```

- [ ] **Step 5: Fix any failures and commit**

- [ ] **Step 6: Create PR 2**

```bash
git push -u origin feat/profile-services
gh pr create --title "feat: restructure profiles with extensible service model" --body "$(cat <<'EOF'
## Summary
- New `profile_services` table with service_type discriminator + JSON config
- XMPP and SIP are independent service records attached to profiles
- Migration 025 migrates existing flat columns to service rows
- New API: POST/PUT/DELETE /api/config-templates/{id}/services
- Updated build_uc_attrs and provisioning.py to read from services
- Frontend: dynamic ServiceCard replaces hardcoded UC section

## Test plan
- [ ] Profile services CRUD tests pass (9 tests)
- [ ] Existing config template tests pass with services model
- [ ] User creation with profile services works
- [ ] Device provisioning resolves services correctly
- [ ] Frontend profile detail shows services dynamically
- [ ] Clone profile includes cloned services
- [ ] Extensibility test: arbitrary service type roundtrips
EOF
)"
```

---

## Chunk 3: PR 3 — Cleanup & Documentation

### Task 17: Dead code removal and type cleanup

**Files:**
- Modify: `src/frontend/src/types/index.ts` — verify no stale re-exports remain
- Scan: all frontend files for orphaned imports to deleted SSO/QR types

- [ ] **Step 1: Search for orphaned imports**

```bash
cd src/frontend && grep -rn "SsoConfig\|QrSettings\|FeatureKey\|ToggleSectionPayload\|qr-management\|qr-generation\|qr-share\|qr-helpers\|SSOBadge\|SSOConfigTab\|SSOStatusCard\|EditSSOModal\|QRGenerationModal\|RecentQRCard\|QRTable\|StepQRCode" src/ --include="*.ts" --include="*.tsx" | grep -v node_modules
```

- [ ] **Step 2: Fix any remaining references**

- [ ] **Step 3: Commit**

```bash
git add -u src/frontend/
git commit -m "chore(frontend): remove orphaned imports after SSO/QR removal"
```

---

### Task 18: Update tests for services model

**Files:**
- Modify: `tests/test_config_templates.py`
- Modify: `tests/test_device_provisioning.py`
- Modify: `tests/conftest.py`

- [ ] **Step 1: Update `test_config_templates.py`**

Update any assertions that check for `xmppEnabled`, `sipEnabled`, `sso`, `qr` fields. Replace with `services` array checks.

- [ ] **Step 2: Update `test_device_provisioning.py`**

Update profile creation helpers to use `add_profile_service()` pattern instead of flat fields.

- [ ] **Step 3: Update `conftest.py` fixtures**

Any profile fixtures that pass `xmpp_enabled`/`sip_enabled` flat fields need updating to create the template first, then add services.

- [ ] **Step 4: Run full test suite**

```bash
just test-quick
```

- [ ] **Step 5: Commit**

```bash
git add tests/
git commit -m "test: update config template and device provisioning tests for services model"
```

---

### Task 19: Architecture documentation update

**Files:**
- Modify: `docs/architecture/README.md`
- Modify: `CLAUDE.md`
- Create: `docs/architecture/decisions/ARD-004-profile-services.md` (if ARD directory exists)

- [ ] **Step 1: Update architecture spec**

In `docs/architecture/README.md`, update the "Profile = Connector" section to describe:
- Profiles are named configuration containers
- Services (XMPP, SIP, future) are independent records in `profile_services`
- Each service owns its config JSON + optional allocation counters
- UID range stays on profile (shared across services)

- [ ] **Step 2: Update CLAUDE.md**

Update the Database section if it references `provision_tokens` → `device_provisions`.
Remove QR/SSO config references from profile descriptions.
Add `profile_services` to the table list.

- [ ] **Step 3: Create ARD (if applicable)**

Document the decision to restructure profiles with extensible services model, referencing the design spec.

- [ ] **Step 4: Commit**

```bash
git add docs/ CLAUDE.md
git commit -m "docs: update architecture for profile services model, create ARD-004"
```

- [ ] **Step 5: Create PR 3**

```bash
git push -u origin chore/profile-services-cleanup
gh pr create --title "chore: cleanup and documentation for profile services restructuring" --body "$(cat <<'EOF'
## Summary
- Remove orphaned SSO/QR imports across frontend
- Update config template and device provisioning tests for services model
- Update architecture documentation for new profile services model
- Create ARD-004 for profile services restructuring decision

## Test plan
- [ ] All tests pass
- [ ] Frontend builds cleanly
- [ ] No orphaned imports remain
EOF
)"
```
