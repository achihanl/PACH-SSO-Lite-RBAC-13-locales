# Implementation Plan — UED SIP Configuration + Web-SSO SIP RING E2E

Spec: `docs/superpowers/specs/2026-04-17-ued-sip-sso-e2e-design.md`
Mode: autopilot. Report-only deliverable.

## Phase 0 — Preconditions (DONE)

| Check | Result |
|---|---|
| Dev stack running | ✅ all healthy, 47h uptime |
| UED admin panel reachable | ✅ `HTTP 200` at `/apps/login.php` |
| UED admin login `admin/admin123` | ✅ `HTTP 302` with session cookie |
| UED XMPP:5222 | ✅ open (sanity) |
| UED SIP:5060 | ⏳ closed (expected — VoIP not started) |
| Platform OpenLDAP | ✅ `:1390`, 58 entries |
| Test users ready | ✅ `alanl` + `xmpptest01` both carry AsteriskPjsipEndpoint/Auth/Aor |
| /browse skill | ✅ `BROWSER_READY` |
| Python SIP deps | ✅ stdlib sufficient (raw UDP + MD5) |

## Phase 1 — Patrol-investigate (Task #9)

Goal: produce `qa/patrol/issues/2026-04-17-azblink-server-sip-config-navigation-route.yml` combining both target pages.

Steps (direct /browse calls, not via full patrol-investigate agent — faster in autopilot):

1. `goto /apps/login.php?item=admin`; fill admin/admin123; click Sign In.
2. After redirect to admin dashboard: `hover "Phone"`; `click "Basic"` or direct link.
3. Locate the "SIP in LDAP" dropdown option; navigate.
4. `snapshot { interactive: true }` + `html > /tmp/sip-in-ldap.html` for form introspection.
5. Record: form id, action URL, field IDs (filter, host, port, bind DN, bind pass, attr maps), hidden `active=`/`action=`.
6. Repeat for Phone » Basic » Dial Plan — same capture.
7. Locate "Start VoIP Process" — either on Dial Plan page or sibling VoIP service page.
8. Write combined patrol YAML.

Abort gates:
- If "SIP in LDAP" dropdown does not exist → STOP; report "page not found; UED version mismatch".
- If form action URLs are unfamiliar AJAX endpoints → document and continue.

## Phase 2 — Build playbook (Task #10)

Consume patrol YAML → write `playbooks/web-configure/azblink-server-sip-config.yml`.
Follow structure of sister `azblink-server-ldap-client.yml` (5-phase: auth/navigate/discover/configure/verify).
Add 3 configure operations: `configureSipInLdap`, `configureDialPlan`, `restartVoipProcess`.

## Phase 3 — Run playbook (Task #11)

Execute configure phase end-to-end:

```bash
export SERVER_URL=http://192.168.122.220:8082
export ADMIN_USER=admin ADMIN_PASS=admin123
export LDAP_HOST=192.168.122.1:1390
export LDAP_BASE_DN=dc=azblink,dc=com
export LDAP_BIND_DN=cn=admin,dc=azblink,dc=com
export LDAP_BIND_PW=adminpassword
export DIAL_CONTEXT=from-internal DIAL_PATTERN=_.
# Use web-configure skill's runner OR hand-issue curls if simpler
```

Verify:
- curl re-reads each page → assert configured values persisted.
- `nc -u -v -z 192.168.122.220 5060` → port open (UDP).
- Optional: UED LDAP-search form returns `AsteriskPjsipEndpoint` entries.

Abort gates:
- If SIP:5060 UDP still unreachable after VoIP restart → stop and document cause (probably form field guess wrong).
- If playbook `configureSipInLdap` POST returns non-success → re-open discover; adjust field names.

## Phase 4 — Write e2e test (Task #12)

`tests/test_sip_ring_e2e.py` structure:

```python
# Skeleton
import socket, hashlib, uuid, time, pytest
UED_IP, UED_PORT = "192.168.122.220", 5060
LOCAL_IP = "192.168.122.1"   # libvirt gateway reachable from UED

def _md5(x: bytes) -> str:
    return hashlib.md5(x, usedforsecurity=False).hexdigest()

def _digest(user, realm, pwd, method, uri, nonce):
    ha1 = _md5(f"{user}:{realm}:{pwd}".encode())
    ha2 = _md5(f"{method}:{uri}".encode())
    return _md5(f"{ha1}:{nonce}:{ha2}".encode())

def sip_register(user, pwd, ued=UED_IP, timeout=10): ...   # returns (status, raw)
def sip_invite_expect_180(caller, peer, pwd, ued=UED_IP, timeout=10): ...

def provision(client, user, device_id):
    # Mirror tests/test_xmpp_e2e.py provision fixture
    ...

@pytest.mark.e2e
def test_sip_ring_via_sso_provisioning(client):
    kit_a = provision(client, "alanl", "ring-test-a")
    kit_b = provision(client, "xmpptest01", "ring-test-b")
    assert sip_register("alanl", kit_a["sipPassword"]).status == 200
    assert sip_register("xmpptest01", kit_b["sipPassword"]).status == 200
    assert sip_invite_expect_180(
        "alanl", "xmpptest01", kit_a["sipPassword"]
    ).status == 180
```

Add `just` target `test-sip-e2e`.

## Phase 5 — Run e2e test (Task #13)

```bash
cd src/backend && python -m pytest -xvs ../../tests/test_sip_ring_e2e.py
```

Collect:
- Pytest output
- Any pcap or raw SIP trace printed to stdout
- 200 OK REGISTER proofs + 180 Ringing proof

Abort gates:
- If REGISTER fails with 401 after digest → LDAP bind not seeing the user; re-read SIP-in-LDAP config.
- If REGISTER fails with 403 → user blocked in dial context or dial plan rejects.
- If INVITE returns 404/603 → dial-plan pattern mismatch; adjust to `_.` or `_[2-9]XXX…`.

## Phase 6 — Compile report (Task #14)

Target: `docs/reports/2026-04-17-sip-sso-e2e-report.md`.

Sections:
1. Executive summary (PASS/FAIL + one-line verdict)
2. Environment snapshot
3. Preconditions table
4. Phase-by-phase outcome with timestamped evidence
5. Artifacts list (playbook YAML, test file, screenshots, patrol issue)
6. Failures encountered + how resolved
7. Next steps (promote nav, write ARD, etc.)

## Rollback

Playbook edits are UED admin-panel config changes — reversible by re-running the AD/LDAP playbook OR disabling the SIP-in-LDAP checkbox via the same form. No data migration. No destructive operations anticipated.

## Branching + commit

Work on `main` (dev-only VM config + new test file). Commit:
- Spec doc
- Plan doc
- Patrol issue
- Playbook YAML
- Test file
- Final report

One commit per artifact OR a single bundled commit at the end; decide at report time. No PR unless user requests.
