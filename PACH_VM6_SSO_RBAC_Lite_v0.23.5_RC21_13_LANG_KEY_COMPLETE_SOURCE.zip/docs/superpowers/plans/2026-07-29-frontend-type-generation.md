# Frontend Type Generation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Generate the frontend's API request types from the committed OpenAPI contract at build time, so a backend request-model change fails `tsc`.

**Architecture:** `openapi-typescript` reads `tests/contract/openapi.baseline.json` (already byte-pinned by `tests/contract/test_openapi_snapshot.py`) and emits `src/frontend/src/types/api.gen.ts`, which is **gitignored** and produced by an npm `postinstall`/`prebuild` hook. `src/frontend/src/types/requests.ts` aliases the generated schemas under stable names; the 15 hand-written request interfaces are deleted and their live call sites repointed. No new CI step: CI already runs `npm ci` then `npm run build` unscoped on every PR, so drift surfaces as a `tsc` failure in an existing job.

**Tech Stack:** TypeScript 7.0.2, Vite 8, Vitest 4, ESLint 10, Prettier 3.9.5, `openapi-typescript` 7.13.0, `just`.

**Spec:** `docs/superpowers/specs/2026-07-29-frontend-type-generation-design.md`

## Global Constraints

- **Generator version is pinned exact:** `"openapi-typescript": "7.13.0"` — no caret.
- **The generator dependency goes in the ROOT `package.json`, not `src/frontend/package.json`.** `openapi-typescript@7.13.0` peer-requires `typescript@^5.x`, and the frontend workspace pins `typescript@^7.0.2` (the native port, whose API has no `ts.factory`). Declaring it inside the workspace makes `npm install` fail ERESOLVE, and forcing past that crashes at generation time. The root `package.json` declares no dependencies, so npm resolves `typescript@5.9.3` into the root `node_modules` for the generator while `src/frontend/node_modules/typescript` stays at `7.0.2`. Verified: `npx openapi-typescript` run from inside `src/frontend` picks up the root bin and emits 5,585 lines in ~200 ms.
- **The generation command is fixed and identical everywhere.** Defined once, as the `gen:types` script in `src/frontend/package.json`; every other caller invokes `npm run gen:types`:
  `openapi-typescript --default-non-nullable=false ../../tests/contract/openapi.baseline.json -o src/types/api.gen.ts`
- **`--default-non-nullable=false` is mandatory, not stylistic.** Without it, every Pydantic field carrying a default emits as **required** — `GroupCreateReq.orgDn: string` instead of `orgDn?: string` — breaking every call site that passes a partial payload. Verified: the flag changes exactly 25 lines, all `x: T` → `x?: T`, all inside `components.schemas`.
- **`api.gen.ts` is gitignored and never hand-edited.** Do not `git add` it. Do not commit it.
- **Never use bare `Omit` on a generated schema.** `Omit<T, K>` constrains `K` to `keyof any`, so a stale key silently no-ops and the intersection adds a phantom field — which would defeat the drift detection this change exists for. Use the `OmitChecked` helper defined in Task 2. `Pick` is already safe (`K extends keyof T`).
- **Responses are out of scope.** 0 of 98 operations declare a success response schema, so they all generate as `unknown`. Do not attempt to type responses, and do not touch `api-client.ts`'s `request<T>` signature.
- **`just ui-format-check` is ALREADY RED on a clean tree** — `useModalState.ts` and `types/audit.ts` fail prettier, both unrelated to this change. Do not fix them. Verify formatting on the files you touched, using explicit filenames, not the glob recipe.
- **Do not fix the pre-existing defects** in the spec's "Out of scope" section. `PermissionKey` is already fixed separately in PR #251; the other three are reported, not repaired.
- **Commit trailers:** Task 3 touches `Justfile`, on the `ci_release_gates` surface → spec section `06-deployment`. That commit carries `Spec-Patch: 06`. All trailers go in one unbroken block at the end — a blank line before `Co-Authored-By:` silently voids them.

---

## File Structure

| Path | Action | Responsibility |
|---|---|---|
| `package.json` (repo root) | modify | pin the generator devDependency — see Global Constraints for why it cannot live in the workspace |
| `src/frontend/package.json` | modify | define `gen:types`, `postinstall`, `prebuild` |
| `src/frontend/.gitignore` | modify | ignore the generated file |
| `src/frontend/eslint.config.js` | modify | exempt the generated file from `eslint .` |
| `src/frontend/.prettierignore` | create | exempt the generated file from the glob format check |
| `src/frontend/src/types/requests.ts` | create | 9 named aliases + the `OmitChecked` helper |
| `src/frontend/src/types/index.ts` | modify | re-export `./requests`; drop the deleted `OrgCreateRequest` |
| `src/frontend/src/types/{group,org,user,org-profiles,provisioning-ops,ldap-clients}.ts` | modify | delete the 15 superseded interfaces |
| `src/frontend/src/lib/queries/{group-mutations,org-mutations,user-mutations,termination,ldap-clients,org-profiles-mutations,user-create}.ts` | modify | repoint to the alias names |
| `Justfile` | modify | add `ui-types` |

---

## Task 1: Generate the contract types at build time

**Files:**
- Modify: `package.json` (repo root) — add a `devDependencies` block
- Modify: `src/frontend/package.json` (scripts block at :5-15)
- Modify: `src/frontend/.gitignore:30-31`
- Modify: `src/frontend/eslint.config.js:9`
- Create: `src/frontend/.prettierignore`

**Interfaces:**
- Consumes: nothing.
- Produces: `src/frontend/src/types/api.gen.ts` (gitignored) exporting `components`, whose `components['schemas']` carries the 41 schemas. Task 2 aliases these.

- [ ] **Step 1: Verify the failure mode first**

Before adding anything, confirm the current state — the frontend compiles with hand-written request types and no generated file:

```bash
cd src/frontend && npx tsc -p tsconfig.json --noEmit; echo "EXIT=$?"
ls src/types/api.gen.ts 2>&1
```

Expected: `EXIT=0`, and `ls` reports the file does not exist. This is the baseline the rest of the task changes.

- [ ] **Step 2: Pin the generator and wire the lifecycle hooks**

In the **repo-root** `package.json` — which currently has no dependencies of any kind — add a `devDependencies` block after `workspaces`:

```json
  "devDependencies": {
    "openapi-typescript": "7.13.0"
  }
```

It must go here, not in `src/frontend/package.json`. The generator peer-requires `typescript@^5.x` while the frontend pins `^7.0.2`; declaring it inside the workspace fails ERESOLVE, and forcing past that crashes because the TS 7 native API has no `ts.factory`. At the root, npm nests `typescript@5.9.3` for the generator and leaves `src/frontend/node_modules/typescript` at `7.0.2`.

Then, in `src/frontend/package.json`, add three entries to `scripts`:

```json
    "gen:types": "openapi-typescript --default-non-nullable=false ../../tests/contract/openapi.baseline.json -o src/types/api.gen.ts",
    "postinstall": "npm run gen:types",
    "prebuild": "npm run gen:types",
```

`postinstall` is what CI depends on: the `frontend` job runs `npm ci` at the repo root before every other step, and a workspace package's `postinstall` runs on both root `npm install` and root `npm ci`, with cwd set to the workspace directory. `prebuild` covers anyone who edits the baseline and rebuilds without reinstalling.

- [ ] **Step 3: Install, which generates the file**

From the repo root, so the workspace lockfile updates:

```bash
npm install
```

Expected: the install log includes the `openapi-typescript` banner from the postinstall hook, and `src/frontend/src/types/api.gen.ts` now exists at ~5,585 lines / ~159 KB.

Verify it, and verify the mandatory flag actually took effect:

```bash
wc -l src/frontend/src/types/api.gen.ts
git grep -c "orgDn?: string" -- src/frontend/src/types/api.gen.ts
```

Expected: ~5585 lines. The second command must return a non-zero count — if `orgDn` appears as `orgDn: string` instead, `--default-non-nullable=false` is missing and every downstream task will break.

- [ ] **Step 4: Confirm generation is deterministic**

The build-time approach relies on repeated runs producing the same bytes:

```bash
cp src/frontend/src/types/api.gen.ts /tmp/api.gen.first.ts
cd src/frontend && npm run gen:types && cd ../..
cmp /tmp/api.gen.first.ts src/frontend/src/types/api.gen.ts; echo "CMP_EXIT=$?"
```

Expected: `CMP_EXIT=0`.

- [ ] **Step 5: Gitignore the generated file**

In `src/frontend/.gitignore`, under the existing `# Generated` heading, change:

```
# Generated
src/routeTree.gen.ts
```

to:

```
# Generated
src/routeTree.gen.ts
# API contract types — produced by `npm run gen:types` (postinstall/prebuild).
# Not committed: openapi.baseline.json is the reviewable artifact; this is a
# mechanical transliteration of it.
src/types/api.gen.ts
```

Confirm git agrees:

```bash
git status --short src/frontend/src/types/
```

Expected: no output. If `api.gen.ts` appears as untracked, the ignore is wrong.

- [ ] **Step 6: Exempt the generated file from lint and format**

The file is gitignored, so CI's diff-scoped lint and format steps never name it. But `just ui-lint` runs `eslint .` and `just ui-format-check` runs a glob, and both would otherwise pick it up.

In `src/frontend/eslint.config.js`, change line 9 from:

```js
  { ignores: ['**/dist'] },
```

to:

```js
  { ignores: ['**/dist', 'src/types/api.gen.ts'] },
```

Create `src/frontend/.prettierignore`:

```
# Generated by `npm run gen:types` — not ours to format.
src/types/api.gen.ts
```

- [ ] **Step 7: Verify the toolchain is green**

```bash
just ui-build
just ui-lint
just ui-test-unit
```

Expected: all three exit 0. Do **not** run `just ui-format-check` and expect green — it is pre-existing red on two unrelated files. Instead check only what this task touched:

```bash
cd src/frontend && npx prettier --check eslint.config.js package.json
```

Expected: clean.

- [ ] **Step 8: Prove `prebuild` regenerates a missing file**

```bash
rm src/frontend/src/types/api.gen.ts
cd src/frontend && npm run build 2>&1 | tail -5; cd ../..
ls -la src/frontend/src/types/api.gen.ts
```

Expected: the build succeeds and the file is back. This is what protects a contributor who deletes it or checks out a clean tree without reinstalling.

- [ ] **Step 9: Commit**

`src/frontend/**` here is not a governed surface (`surfaces.yaml` lists only `lib/oidc.ts` and `stores/auth-store.ts` from the frontend, neither touched), so no trailer.

```bash
git add package.json src/frontend/package.json package-lock.json \
  src/frontend/.gitignore src/frontend/.prettierignore src/frontend/eslint.config.js
git status --short
```

Confirm `api.gen.ts` is **not** in the staged set, then:

```bash
git commit -F - <<'EOF'
feat(frontend): generate API request types from the OpenAPI contract (#230)

Generates src/types/api.gen.ts from tests/contract/openapi.baseline.json, which
test_openapi_snapshot.py already pins byte-for-byte. Generating from the
committed baseline rather than importing the app keeps the step Node-only.

Gitignored and produced by postinstall/prebuild rather than committed, matching
how routeTree.gen.ts is already handled. The baseline JSON is the reviewable
artifact; api.gen.ts is a mechanical transliteration of it, and committing 5,585
lines of that per contract change would bury the diff it was meant to surface.
Measured, only the 519-line components block is consumed — 9.3% of the file.

No new CI step is needed: the frontend job already runs npm ci then npm run
build unscoped on every PR, so a contract change that breaks a call site fails
tsc there.

--default-non-nullable=false is required, not stylistic: without it every
Pydantic field carrying a default emits as required (GroupCreateReq.orgDn:
string rather than orgDn?: string) and every partial-payload call site breaks.

Co-Authored-By: Claude Opus 5 (1M context) <noreply@anthropic.com>
EOF
```

---

## Task 2: Replace the hand-written request types

**Files:**
- Create: `src/frontend/src/types/requests.ts`
- Modify: `src/frontend/src/types/index.ts:5-22`
- Modify (delete declarations): `group.ts:40-52`, `org.ts:94-99`, `user.ts:26-56`, `org-profiles.ts:131-158`, `provisioning-ops.ts:80-82` and `:91-93`, `ldap-clients.ts:59-63`
- Modify (repoint): `lib/queries/group-mutations.ts:10,24`, `org-mutations.ts:10,23`, `user-mutations.ts:7,16`, `termination.ts:9,13,26`, `ldap-clients.ts:16`, `org-profiles-mutations.ts:12-18,24,39,55`, `user-create.ts:163-175`

**Interfaces:**
- Consumes: `components` from `./api.gen` (Task 1).
- Produces: `src/frontend/src/types/requests.ts` exporting exactly 9 names — `GroupCreateReq`, `OrgCreateReq`, `ProvisionClientRequest`, `ConfigTemplateCreate`, `ConfigTemplateUpdate`, `ConfigTemplateClone`, `UserCreateReq`, `UserUpdateReq`, `UserTerminateReq` — all re-exported from `@/types`.

- [ ] **Step 1: Write the alias module**

Create `src/frontend/src/types/requests.ts`:

```ts
/**
 * API request payload types, backed by the generated OpenAPI schemas.
 *
 * These alias `components['schemas'][...]` from ./api.gen.ts instead of
 * restating field lists, so a backend request-model change surfaces here as a
 * compile error rather than a runtime surprise. api.gen.ts is generated by
 * `npm run gen:types` (postinstall/prebuild) and is not committed.
 *
 * Responses are NOT generated. No handler in src/backend/routers/ declares a
 * response_model, so the OpenAPI document types every success response body as
 * `unknown`. Response shapes stay hand-written in the sibling domain files
 * until the backend declares them — see the response-model follow-up issue.
 *
 * Only payloads with a live consumer are aliased. The other request schemas are
 * reachable as `components['schemas'][...]` if a call site ever needs one; an
 * alias nothing imports is checked by nothing.
 */
import type { components } from './api.gen'
import type { GroupType } from './group'
import type { OrgNodeType } from './org'
import type { ProfileStatus } from './org-profiles'

type Schemas = components['schemas']

/**
 * `Omit` with the removed key checked against the source type.
 *
 * Bare `Omit<T, K>` constrains K to `keyof any`, so if the backend renames the
 * field this file re-narrows, the Omit silently removes nothing and the
 * intersection bolts a phantom property on top — compiling clean and defeating
 * the drift detection that is the entire point of generating these types.
 * `Pick` needs no such wrapper; its key parameter is already `keyof T`.
 */
type OmitChecked<T, K extends keyof T> = Omit<T, K>

/**
 * POST /api/groups/create
 *
 * `group_type` is re-narrowed: the backend constrains it with
 * `constr(pattern=...)`, which OpenAPI renders as a bare `string` rather than
 * an enum, unlike `Literal[...]`.
 */
export type GroupCreateReq = OmitChecked<
  Schemas['GroupCreateReq'],
  'group_type'
> & {
  group_type?: GroupType
}

/** POST /api/org/create — `orgType` re-narrowed, same reason as above. */
export type OrgCreateReq = OmitChecked<Schemas['OrgCreateReq'], 'orgType'> & {
  orgType?: OrgNodeType | null
}

/** POST /api/settings/ldap/clients/provisioned */
export type ProvisionClientRequest = Schemas['ProvisionClientRequest']

/** POST /api/config-templates */
export type ConfigTemplateCreate = Schemas['ConfigTemplateCreate']

/** PUT /api/config-templates/{template_id} — `status` re-narrowed. */
export type ConfigTemplateUpdate = OmitChecked<
  Schemas['ConfigTemplateUpdate'],
  'status'
> & {
  status?: ProfileStatus | null
}

/** POST /api/config-templates/{template_id}/clone */
export type ConfigTemplateClone = Schemas['ConfigTemplateClone']

/** POST /api/users/create */
export type UserCreateReq = Schemas['UserCreateReq']

/** PATCH /api/users/{uid} */
export type UserUpdateReq = Schemas['UserUpdateReq']

/** POST /api/users/{uid}/terminate */
export type UserTerminateReq = Schemas['UserTerminateReq']
```

- [ ] **Step 2: Prove `OmitChecked` actually catches a rename**

This is the guard that protects the whole design; verify it rather than trusting it. Temporarily change one alias to reference a key that does not exist:

```bash
cd src/frontend
```

Edit `src/types/requests.ts` and change `'group_type'` to `'group_typo'` in the `GroupCreateReq` alias, then:

```bash
npx tsc -p tsconfig.json --noEmit 2>&1 | head -5; echo "EXIT=$?"
```

Expected: FAIL, with an error on the `OmitChecked` type argument — something like `Type '"group_typo"' does not satisfy the constraint 'keyof ...'`. If it compiles clean, `OmitChecked` is wrong; fix it before continuing.

Revert `'group_typo'` back to `'group_type'`.

- [ ] **Step 3: Re-export from the barrel**

In `src/frontend/src/types/index.ts`, add after line 5 (`export * from './api'`):

```ts
export * from './requests'
```

and remove the line `  type OrgCreateRequest,` from the curated `./org` export block, since that interface is deleted in Step 5.

- [ ] **Step 4: Verify the aliases compile before deleting anything**

```bash
just ui-build
```

Expected: PASS. Both the old interfaces and the new aliases exist; nothing has broken yet. If this fails, the aliases are wrong — fix them now, before the fallback disappears.

- [ ] **Step 5: Delete the 15 superseded interfaces**

Delete these declarations entirely, including their doc comments:

- `src/frontend/src/types/group.ts` — `CreateGroupPayload` (40-46), `UpdateGroupPayload` (48-52).
- `src/frontend/src/types/org.ts` — `OrgCreateRequest` (94-99).
- `src/frontend/src/types/user.ts` — `UserCreateRequest` (26-37), `UserUpdateRequest` (39-43), `UserTerminateRequest` (45-48), `UserSuspendRequest` (50-52), `UserUnsuspendRequest` (54-56).
- `src/frontend/src/types/org-profiles.ts` — the whole `// --- Payload types ---` block (131-158): the banner comment plus `CreateProfilePayload`, `UpdateProfilePayload`, `CloneProfilePayload`, `AssignProfilePayload`.
- `src/frontend/src/types/provisioning-ops.ts` — `BulkRevokeRequest` (80-82) and `ExtendTokenRequest` (91-93). Keep the `/* ---- Bulk actions ---- */` banner and the two `*Response` interfaces around them.
- `src/frontend/src/types/ldap-clients.ts` — `ProvisionClientRequest` (59-63).

Seven of these — `UpdateGroupPayload`, `AssignProfilePayload`, `BulkRevokeRequest`, `ExtendTokenRequest`, `UserCreateRequest`, `UserSuspendRequest`, `UserUnsuspendRequest` — have no consumers and get no alias. That is deliberate.

**No import cleanup is needed.** This was checked: `group.ts`, `org-profiles.ts` and `ldap-clients.ts` have no imports at all; `org.ts`, `user.ts` and `provisioning-ops.ts` all still use `DN` / `UID` / `ISOTimestamp` elsewhere in the file. Do not remove any import.

- [ ] **Step 6: Repoint the live call sites**

`src/frontend/src/lib/queries/group-mutations.ts` — line 10 becomes `import type { GroupCreateReq } from '@/types'`; line 24 becomes `mutationFn: (data: GroupCreateReq) =>`.

`src/frontend/src/lib/queries/org-mutations.ts` — line 10 becomes `import type { OrgCreateReq } from '@/types'`; line 23 becomes `mutationFn: (data: OrgCreateReq) =>`.

`src/frontend/src/lib/queries/user-mutations.ts` — line 7 becomes `import type { UserUpdateReq } from '@/types'`; line 16 becomes `      updates: UserUpdateReq`.

`src/frontend/src/lib/queries/termination.ts` — line 9 becomes `import type { TerminationResponse, UserTerminateReq } from '@/types'`; line 13 becomes `interface TerminateParams extends UserTerminateReq {`; line 26 becomes `      } satisfies UserTerminateReq),`.

`src/frontend/src/lib/queries/ldap-clients.ts` — the name `ProvisionClientRequest` is unchanged, but it must now resolve through the barrel. Move that one name out of the `@/types/ldap-clients` import block at line 16 into an import from `@/types`, leaving the other names in that block where they are. Line 78 is unchanged.

`src/frontend/src/lib/queries/org-profiles-mutations.ts` — replace the import block at lines 12-18 with:

```ts
import type {
  ConfigTemplateCreate,
  ConfigTemplateUpdate,
  ConfigTemplateClone,
} from '@/types'
import type {
  ConfigTemplateMutationResponse,
  ConfigTemplateDeleteResponse,
} from '@/types/org-profiles'
```

then line 24 → `mutationFn: (payload: ConfigTemplateCreate) =>`, line 39 → `mutationFn: (payload: ConfigTemplateUpdate) =>`, line 55 → `mutationFn: (payload?: ConfigTemplateClone) =>`.

- [ ] **Step 7: Re-base the live create-user payload**

`src/frontend/src/lib/queries/user-create.ts:163-175` declares its own `CreateUserPayload` because the shared `UserCreateRequest` had drifted. Do **not** replace it with a bare `UserCreateReq`: the schema makes `displayName`, `mail`, `mobile` and `title` optional (the backend defaults them to `""`), while the onboarding form requires all four.

This file has **no** `@/types` import today, so add one alongside the existing imports:

```ts
import type { UserCreateReq } from '@/types'
```

Then replace lines 163-175 with:

```ts
/**
 * POST /api/users/create payload.
 *
 * Derived from the generated contract so a backend rename breaks the build,
 * with the four fields the onboarding form always collects marked required.
 * The schema leaves them optional because the backend defaults them to "" —
 * a server-side convenience, not a licence for the form to omit them.
 *
 * `Pick` rather than a literal `& { mail: string; ... }`: Pick's key parameter
 * is checked against `keyof UserCreateReq`, so a rename fails here. A literal
 * object type would silently bolt on a phantom field instead.
 */
export type CreateUserPayload = UserCreateReq &
  Required<Pick<UserCreateReq, 'displayName' | 'mail' | 'mobile' | 'title'>>
```

- [ ] **Step 8: Verify the whole frontend compiles**

```bash
just ui-build
```

Expected: PASS. Read any failure before changing anything — if the error says `group_type`, `orgType` or `status` is `string`, the narrowing override in `requests.ts` is wrong; fix `requests.ts`, not the call site.

- [ ] **Step 9: Confirm no hand-written request type survives**

```bash
git grep -n -E "CreateGroupPayload|UpdateGroupPayload|OrgCreateRequest|CreateProfilePayload|UpdateProfilePayload|CloneProfilePayload|AssignProfilePayload|BulkRevokeRequest|ExtendTokenRequest|UserCreateRequest|UserUpdateRequest|UserTerminateRequest|UserSuspendRequest|UserUnsuspendRequest" -- src/frontend/src
```

Expected: no output.

`ProvisionClientRequest` is deliberately absent from that list — the alias reuses the name, so grepping for it proves nothing. Verify that one by hand instead: `src/frontend/src/types/ldap-clients.ts` must no longer declare it, and `requests.ts` must.

```bash
git grep -n "interface ProvisionClientRequest" -- src/frontend/src
```

Expected: no output — the only remaining definition is the `export type` in `requests.ts`.

- [ ] **Step 10: Run the rest of the gate**

```bash
just ui-lint
just ui-test-unit
cd src/frontend && npx prettier --check "src/types/requests.ts" "src/types/index.ts" "src/lib/queries/*.ts" "src/types/*.ts"
```

Expected: lint and tests exit 0. For prettier, the only acceptable failure is the pre-existing `src/types/audit.ts` — anything else you touched must be clean; run `npx prettier --write` on your own files if needed.

- [ ] **Step 11: Commit**

```bash
git add src/frontend/src/types src/frontend/src/lib/queries
git status --short
```

Confirm `api.gen.ts` is not staged, then:

```bash
git commit -F - <<'EOF'
refactor(frontend): replace hand-written request types with generated aliases (#230)

Deletes the 15 hand-maintained request interfaces and points their live call
sites at requests.ts, which aliases the generated schemas. One source of truth
per payload, as #230's fifth acceptance criterion requires.

Only 8 of the 15 had a consumer; the other 7 were dead. Those are deleted
without an alias, since an alias nothing imports is verified by nothing and
would surface as an unused export in the dead-code report.

group_type, orgType and status keep their hand-written unions via OmitChecked,
a wrapper that constrains the removed key to keyof T. Bare Omit does not: it
accepts any string, so a backend rename would silently remove nothing and the
intersection would bolt on a phantom field, compiling clean and defeating the
drift detection this change exists for. Pick needs no wrapper, which is why
CreateUserPayload uses Required<Pick<...>> to keep the four fields the
onboarding form always collects required while the schema leaves them optional.

Three swaps change shape rather than relocating it: ConfigTemplateCreate/Update
gain maxDevicesPerUser, and OrgCreateReq makes parentDn optional because the
backend defaults it. None alters runtime behaviour today — maxDevicesPerUser has
no frontend consumer and every call site already passes parentDn.

Response types are untouched and stay hand-written.

Co-Authored-By: Claude Opus 5 (1M context) <noreply@anthropic.com>
EOF
```

---

## Task 3: Add the Justfile recipe and prove the drift path

**Files:**
- Modify: `Justfile` — insert after the `ui-routes` recipe (comment at 141, recipe at 142, body at 143; insert at 144)

**Interfaces:**
- Consumes: the `gen:types` script (Task 1), `requests.ts` (Task 2).
- Produces: `just ui-types`.

- [ ] **Step 1: Add the recipe**

In `Justfile`, immediately after the `ui-routes` recipe body, add:

```just

# Regenerate frontend API types from the committed OpenAPI baseline.
# Runs automatically on npm install and npm run build; this is the manual
# escape hatch for when you have edited the baseline in place.
ui-types:
    cd src/frontend && npm run gen:types
```

- [ ] **Step 2: Verify it runs**

```bash
just ui-types
git status --short src/frontend/src/types/
```

Expected: the generator banner, and no git output (the file stays ignored).

- [ ] **Step 3: Prove a backend change breaks the build**

This is the acceptance-criterion-2 demonstration. It must actually run — do not tick this step off on the basis that CI would catch it, because Step 5 reverts the change and CI never sees it.

Rename a field on a request model the frontend consumes. In `src/backend/schemas/users.py`, on `UserTerminateReq`, rename `reason` to `terminationReason`.

- [ ] **Step 4: Refresh the baseline and regenerate**

`LDAP_BASE_DN` is **required**. `OU_ORG` derives from it and reaches the wire as the default for `GroupCreateReq.orgDn`, `OrgCreateReq.parentDn` and `UserCreateReq.orgDn`; without it the baseline rewrites three unrelated schema defaults and reds the snapshot gate (documented at `pr-checks.yml:157-162`).

```bash
LDAP_BASE_DN=dc=azblink,dc=com python tools/openapi_baseline.py --write
git diff --stat tests/contract/openapi.baseline.json
just ui-types
just ui-build
```

Expected: the baseline diff touches only `UserTerminateReq`, and `ui-build` **FAILS** in `src/frontend/src/lib/queries/termination.ts`, because `satisfies UserTerminateReq` no longer holds.

That failure is the deliverable. Before this change, the same backend rename compiled green and failed only at runtime in a browser.

If `openapi_baseline.py` cannot run locally for want of backend dependencies, install them into a venv from `src/backend/requirements.lock` and retry. Do not skip.

- [ ] **Step 5: Revert the experiment**

```bash
git checkout -- src/backend/schemas/users.py tests/contract/openapi.baseline.json
just ui-types
just ui-build
git status --short
```

Expected: `ui-build` passes and `git status --short` shows only the `Justfile` change. If anything else is dirty, the revert was incomplete — stop and fix it.

- [ ] **Step 6: Determine the governance lane**

`just arch-guard` runs `arch_guard.py --staged --warn-only`, which reports nothing when nothing is staged and exits 0 even on failure. So stage first and drop `--warn-only`:

```bash
git add Justfile
python tools/arch_guard.py --staged; echo "EXIT=$?"
```

If PyYAML is missing locally, run it from a venv holding `tools/arch_guard_requirements.txt` (`just arch-guard-setup` installs the pinned deps). Use the lane the guard accepts. `Spec-Patch: 06` is expected; fall back to `ARD-POST: placeholder` only if the guard rejects it.

- [ ] **Step 7: Commit**

Note the trailer block — `Spec-Patch:` and `Co-Authored-By:` contiguous, no blank line between them.

```bash
git commit -F - <<'EOF'
build(frontend): add `just ui-types` for manual contract regeneration (#230)

Generation already runs on npm install and npm run build. This is the manual
escape hatch for editing openapi.baseline.json in place, and it satisfies
#230's fourth acceptance criterion, which asks for a documented Justfile
command specifically.

Verified the drift path end to end before committing: renaming
UserTerminateReq.reason in src/backend/schemas/users.py, refreshing the
baseline with LDAP_BASE_DN set and regenerating produced a tsc failure in
termination.ts, where `satisfies UserTerminateReq` no longer held. That same
rename previously compiled green and failed only at runtime in a browser.

Spec-Patch: 06
Co-Authored-By: Claude Opus 5 (1M context) <noreply@anthropic.com>
EOF
```

---

## Post-implementation

Not tasks — do these after the three commits land, before opening the PR.

- [ ] Run `/review` (gstack) per CLAUDE.md's PR Review Gate.
- [ ] Open the PR. State the honest accounting: 15 declarations deleted (89 of 1,112 lines, 8.0%), of which 7 were dead; requests and params covered, success responses not, because 0 of 98 operations declare one. Say plainly that no runtime behaviour changes today — the deliverable is the mechanism.
- [ ] Comment the premise correction on issue #230: it assumes the document sources both request and response types, and it does not.
- [ ] File the follow-up issue for backend response declarations, recommending `responses={200: {"model": X}}` over `response_model=`, and noting `shapes.baseline.json` supplies the key sets. Then add its number to the `requests.ts` header comment.
- [ ] File the three remaining pre-existing defects from the spec's "Out of scope" section (`ComplianceAlertType`, the dead `ssoConfig`/`qrSettings`/`ssoEnabled` fields, `RateLimitError.retryAfter`). `PermissionKey` is already done in PR #251.
- [ ] Squash-merge with `gh pr merge --squash --body-file <file>` so the `Spec-Patch: 06` trailer survives.
