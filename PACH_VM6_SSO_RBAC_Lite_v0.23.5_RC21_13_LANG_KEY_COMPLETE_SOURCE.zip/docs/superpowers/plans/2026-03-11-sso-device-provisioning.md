# SSO Device Provisioning Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add authenticated, SSO-based device provisioning so UC client apps can self-provision XMPP/SIP credentials without QR codes.

**Architecture:** Extend existing provisioning infrastructure (`provision_tokens` table, LDAP UC attributes, OIDC auth) with a new `POST /api/provision/device` endpoint. Credentials are E2E encrypted via libsodium sealed box. A new LDAP attribute `azbXmppBindPassword` stores the readable XMPP password synchronized with `userPassword`.

**Tech Stack:** FastAPI, PyNaCl (libsodium), ldap3, SQLAlchemy, PostgreSQL

**Spec:** `docs/superpowers/specs/2026-03-11-sso-device-provisioning-design.md`

---

## File Structure

| File | Responsibility | Action |
|------|----------------|--------|
| `deploy/dev/ldap/azblink.schema` | Custom LDAP schema | Modify — add `azbXmppBindPassword` attribute to azblinkUser objectClass |
| `migrations/022_device_provisioning.sql` | DB schema extension | Create — add columns + indexes to `provision_tokens` |
| `src/backend/requirements.txt` | Python dependencies | Modify — add `PyNaCl` |
| `src/backend/config.py` | Environment config | Modify — add `DEVICE_PROVISION_TTL_SEC` |
| `src/backend/rate_limit.py` | Rate limiting constants | Modify — add `LIMIT_DEVICE_PROVISION` |
| `src/backend/ldap_client.py` | LDAP operations | Modify — extend `build_uc_attrs()`, add `get_uc_credentials()`, add `_set_user_passwords()` |
| `src/backend/orgdb.py` | Database operations | Modify — extend table definition, add `count_active_device_provisions()`, add `upsert_device_provision()` |
| `src/backend/main.py` | API routes | Modify — add `POST /api/provision/device`, `DELETE /api/provision/device/{device_id}` |
| `tests/test_device_provisioning.py` | Integration tests | Create |

---

## Chunk 1: Infrastructure (LDAP Schema + Migration + Dependencies)

### Task 1: Add `azbXmppBindPassword` to LDAP schema

**Files:**
- Modify: `deploy/dev/ldap/azblink.schema:55-60` (add after last attribute)

- [ ] **Step 1: Add attribute definition**

After `azblinkGroupType` (line 60), before the objectClasses section (line 62), add:

```schema
# azbXmppBindPassword — plaintext XMPP bind password for device provisioning
# Synchronized with userPassword at creation; decoupled when XMPP server switches.
attributetype ( AZBlinkAttr:7
    NAME 'azbXmppBindPassword'
    DESC 'Plaintext XMPP bind password for device provisioning'
    EQUALITY caseExactMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15
    SINGLE-VALUE )
```

Note: uses OID `AZBlinkAttr:7` (next in sequence after `:6`). `caseExactMatch` because passwords are case-sensitive.

- [ ] **Step 2: Add attribute to `azblinkUser` objectClass MAY list**

Modify the `azblinkUser` objectClass (line 66-71) to include the new attribute:

```schema
objectclass ( AZBlinkOC:1
    NAME 'azblinkUser'
    DESC 'AZBlink user extensions for provisioning and lifecycle'
    SUP top AUXILIARY
    MAY ( azblinkAccountStatus $ azblinkProfileId $
          azblinkProvisionedAt $ azbXmppBindPassword ) )
```

- [ ] **Step 3: Verify schema loads**

Run: `just down && just up`

Verify OpenLDAP starts without schema errors:
```bash
docker logs azblink-openldap 2>&1 | grep -i "schema\|error"
```

Expected: No schema errors, slapd starts normally.

- [ ] **Step 4: Commit**

```bash
git add deploy/dev/ldap/azblink.schema
git commit -m "feat(ldap): add azbXmppBindPassword attribute to schema"
```

---

### Task 2: Create database migration

**Files:**
- Create: `migrations/022_device_provisioning.sql`

- [ ] **Step 1: Write migration**

```sql
-- 022_device_provisioning.sql
-- Add SSO device provisioning support to provision_tokens table.
-- New columns discriminate QR vs SSO tokens and store E2E encrypted payloads.

ALTER TABLE provision_tokens
  ADD COLUMN auth_method VARCHAR(32) NOT NULL DEFAULT 'qr',
  ADD COLUMN sealed_payload BYTEA,
  ADD COLUMN public_key_hash VARCHAR(128);

-- Index for device cap counting (SSO tokens by user + status)
CREATE INDEX idx_pt_uid_auth_method_status
  ON provision_tokens (uid, auth_method, status);

-- Unique partial index for SSO device upsert (prevents duplicate device registrations)
CREATE UNIQUE INDEX idx_pt_sso_device_upsert
  ON provision_tokens (uid, consumed_by_device_id, auth_method)
  WHERE auth_method = 'sso_token';

-- Rollback:
-- DROP INDEX IF EXISTS idx_pt_sso_device_upsert;
-- DROP INDEX IF EXISTS idx_pt_uid_auth_method_status;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS public_key_hash;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS sealed_payload;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS auth_method;
```

- [ ] **Step 2: Apply migration**

```bash
just psql < ../../migrations/022_device_provisioning.sql
```

Expected: `ALTER TABLE`, `CREATE INDEX` x2 — no errors.

- [ ] **Step 3: Verify columns exist**

```bash
just psql -c "\\d provision_tokens" | grep -E "auth_method|sealed_payload|public_key_hash"
```

Expected: Three new columns visible.

- [ ] **Step 4: Commit**

```bash
git add migrations/022_device_provisioning.sql
git commit -m "feat(db): add device provisioning columns to provision_tokens (022)"
```

---

### Task 3: Add PyNaCl dependency

**Files:**
- Modify: `src/backend/requirements.txt`

- [ ] **Step 1: Add PyNaCl to requirements**

Add after the `cryptography>=42.0` line (line 12):

```
PyNaCl>=1.5
```

- [ ] **Step 2: Rebuild API container**

```bash
just api-rebuild
```

Expected: Container builds, PyNaCl installs successfully.

- [ ] **Step 3: Verify import works**

```bash
docker exec azblink-api python -c "import nacl.public; print('PyNaCl OK:', nacl.__version__)"
```

Expected: `PyNaCl OK: 1.5.0` (or similar)

- [ ] **Step 4: Commit**

```bash
git add src/backend/requirements.txt
git commit -m "feat(deps): add PyNaCl for libsodium sealed box encryption"
```

---

### Task 4: Add config and rate limit constants

**Files:**
- Modify: `src/backend/config.py:86-98` (after SIP_AUTH_REALM)
- Modify: `src/backend/rate_limit.py:57-60` (rate limit constants)

- [ ] **Step 1: Add DEVICE_PROVISION_TTL_SEC to config.py**

After `SIP_AUTH_REALM` (line 86), add:

```python
# ----------------------------
# SSO Device Provisioning
# ----------------------------
DEVICE_PROVISION_TTL_SEC = int(os.getenv("DEVICE_PROVISION_TTL_SEC", "2592000"))  # 30 days
DEVICE_PROVISION_MAX_DEFAULT = int(os.getenv("DEVICE_PROVISION_MAX_DEFAULT", "5"))
```

- [ ] **Step 2: Add LIMIT_DEVICE_PROVISION to rate_limit.py**

After `LIMIT_DEFAULT` (line 60), add:

```python
LIMIT_DEVICE_PROVISION = "5/minute"
```

- [ ] **Step 3: Verify API starts**

```bash
just logs | head -5
```

Expected: No import errors, API starts normally.

- [ ] **Step 4: Commit**

```bash
git add src/backend/config.py src/backend/rate_limit.py
git commit -m "feat(config): add device provisioning TTL and rate limit constants"
```

---

## Chunk 2: LDAP Layer (build_uc_attrs + password helpers)

### Task 5: Extend `build_uc_attrs()` with `xmpp_password` parameter

**Files:**
- Modify: `src/backend/ldap_client.py:30-79`
- Test: run existing tests to verify no regression

- [ ] **Step 1: Write test for new parameter**

Create `tests/test_device_provisioning.py` with the first test:

```python
"""Integration tests for SSO device provisioning.

- Endpoint auth, device cap, sealed box roundtrip, revocation
- Tests run against the real Docker stack (no mocks)
"""
import pytest
from ldap_client import build_uc_attrs


class TestBuildUcAttrs:
    """Verify build_uc_attrs includes azbXmppBindPassword."""

    def test_xmpp_enabled_includes_bind_password(self):
        attrs, ocs = build_uc_attrs(
            xmpp_enabled=True,
            sip_enabled=False,
            uid_number=5001,
            extension=None,
            sip_password=None,
            username="testuser",
            xmpp_password="test-xmpp-pass-123",
        )
        assert attrs["azbXmppBindPassword"] == "test-xmpp-pass-123"
        assert "posixAccount" in ocs

    def test_xmpp_disabled_excludes_bind_password(self):
        attrs, ocs = build_uc_attrs(
            xmpp_enabled=False,
            sip_enabled=False,
            uid_number=None,
            extension=None,
            sip_password=None,
            username="testuser",
            xmpp_password="test-xmpp-pass-123",
        )
        assert "azbXmppBindPassword" not in attrs
        assert ocs == []

    def test_both_enabled_includes_both_passwords(self):
        attrs, ocs = build_uc_attrs(
            xmpp_enabled=True,
            sip_enabled=True,
            uid_number=5001,
            extension=1001,
            sip_password="sip-pass-456",
            username="testuser",
            xmpp_password="xmpp-pass-789",
        )
        assert attrs["azbXmppBindPassword"] == "xmpp-pass-789"
        assert attrs["AstAuthPassword"] == "sip-pass-456"
```

- [ ] **Step 2: Run test to verify it fails**

```bash
just test-quick -- tests/test_device_provisioning.py::TestBuildUcAttrs -v
```

Expected: FAIL — `build_uc_attrs() got an unexpected keyword argument 'xmpp_password'`

- [ ] **Step 3: Add `xmpp_password` parameter to `build_uc_attrs()`**

In `src/backend/ldap_client.py`, modify the function signature (lines 30-38) to add the new parameter:

```python
def build_uc_attrs(
    *,
    xmpp_enabled: bool,
    sip_enabled: bool,
    uid_number: int | None,
    extension: int | None,
    sip_password: str | None,
    username: str,
    xmpp_password: str | None = None,
) -> tuple[dict[str, str], list[str]]:
```

Then after the posixAccount attrs block (after line 56), add:

```python
    # XMPP bind password — plaintext, synchronized with userPassword at creation.
    # Stored in LDAP for device provisioning (E2E encrypted to client).
    if xmpp_enabled and xmpp_password:
        attrs["azbXmppBindPassword"] = xmpp_password
```

- [ ] **Step 4: Run test to verify it passes**

```bash
just test-quick -- tests/test_device_provisioning.py::TestBuildUcAttrs -v
```

Expected: 3 passed

- [ ] **Step 5: Run existing provisioning tests to verify no regression**

The existing callers of `build_uc_attrs()` don't pass `xmpp_password` (it defaults to `None`), so the new attribute won't be set. This is correct — existing users created without device provisioning won't have the attribute until they're re-provisioned.

```bash
just test-quick -- tests/test_provisioning.py -v
```

Expected: All existing tests pass (no regression).

- [ ] **Step 6: Commit**

```bash
git add src/backend/ldap_client.py tests/test_device_provisioning.py
git commit -m "feat(ldap): add xmpp_password param to build_uc_attrs"
```

---

### Task 6: Pass plaintext password through user creation flow

**Files:**
- Modify: `src/backend/main.py:1499-1506` (user creation endpoint)

- [ ] **Step 1: Write test**

Add to `tests/test_device_provisioning.py`:

```python
import uuid
import httpx


class TestUserCreationXmppPassword:
    """Verify user creation stores azbXmppBindPassword in LDAP."""

    def test_created_user_has_xmpp_bind_password(self, client, ldap_conn, created_users):
        uid = f"devprov-{uuid.uuid4().hex[:8]}"
        created_users.append(uid)
        # Create user with a profile that has XMPP enabled
        # First, get or create a config template with xmpp_enabled
        tpl_name = f"devprov-tpl-{uuid.uuid4().hex[:8]}"
        tpl_resp = client.post("/api/config-templates", json={
            "name": tpl_name,
            "description": "test template",
            "xmppEnabled": True,
            "sipEnabled": False,
            "xmppDomain": "test.example.com",
            "xmppWsUrl": "wss://test.example.com/ws",
            "sipDomain": "sip.example.com",
            "sipWssUrl": "wss://sip.example.com",
            "uidRangeStart": 60000,
            "uidRangeEnd": 69999,
            "extRangeStart": 6000,
            "extRangeEnd": 6999,
        })
        assert tpl_resp.status_code == 201
        tpl_id = tpl_resp.json()["id"]

        password = "TestPass123!"
        resp = client.post("/api/users/create", json={
            "uid": uid,
            "displayName": "Dev Prov Test",
            "mail": f"{uid}@test.com",
            "mobile": "",
            "orgDn": f"ou=org,dc=azblink,dc=com",
            "password": password,
            "profileId": tpl_id,
        })
        assert resp.status_code == 201
        assert resp.json()["status"] == "created"

        # Verify azbXmppBindPassword is set in LDAP
        ldap_conn.search(
            f"ou=people,dc=azblink,dc=com",
            f"(uid={uid})",
            attributes=["azbXmppBindPassword"],
        )
        assert len(ldap_conn.entries) == 1
        xmpp_pw = str(ldap_conn.entries[0]["azbXmppBindPassword"])
        assert xmpp_pw == password
```

- [ ] **Step 2: Run test to verify it fails**

```bash
just test-quick -- tests/test_device_provisioning.py::TestUserCreationXmppPassword -v
```

Expected: FAIL — `azbXmppBindPassword` not present or not matching.

- [ ] **Step 3: Pass password to build_uc_attrs in main.py**

In `src/backend/main.py`, modify the `build_uc_attrs()` call (lines 1499-1506). The plaintext password is available as `req.password` (line 1468). Add it to the call:

```python
                            uc_attrs, uc_ocs = build_uc_attrs(
                                xmpp_enabled=xmpp_on,
                                sip_enabled=sip_on,
                                uid_number=prov.uid_number,
                                extension=prov.extension,
                                sip_password=prov.sip_password,
                                username=req.uid,
                                xmpp_password=req.password if xmpp_on else None,
                            )
```

- [ ] **Step 4: Run test to verify it passes**

```bash
just test-quick -- tests/test_device_provisioning.py::TestUserCreationXmppPassword -v
```

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/backend/main.py tests/test_device_provisioning.py
git commit -m "feat: pass plaintext password to LDAP as azbXmppBindPassword"
```

---

### Task 7: Add `get_uc_credentials()` helper

**Files:**
- Modify: `src/backend/ldap_client.py` (add after `add_uc_attrs_to_user`, ~line 99)

- [ ] **Step 1: Write test**

Add to `tests/test_device_provisioning.py`:

```python
from ldap_client import get_uc_credentials


class TestGetUcCredentials:
    """Verify get_uc_credentials reads passwords from LDAP."""

    def test_returns_xmpp_password(self, client, ldap_conn, created_users):
        """Create a user with XMPP enabled, then read back credentials."""
        uid = f"ucred-{uuid.uuid4().hex[:8]}"
        created_users.append(uid)
        tpl_name = f"ucred-tpl-{uuid.uuid4().hex[:8]}"
        tpl_resp = client.post("/api/config-templates", json={
            "name": tpl_name, "description": "test",
            "xmppEnabled": True, "sipEnabled": True,
            "xmppDomain": "test.example.com", "xmppWsUrl": "wss://test.example.com/ws",
            "sipDomain": "sip.example.com", "sipWssUrl": "wss://sip.example.com",
            "uidRangeStart": 70000, "uidRangeEnd": 79999,
            "extRangeStart": 7000, "extRangeEnd": 7999,
        })
        assert tpl_resp.status_code == 201
        password = "CredTest456!"
        resp = client.post("/api/users/create", json={
            "uid": uid, "displayName": "UC Cred Test",
            "mail": f"{uid}@test.com", "mobile": "",
            "orgDn": "ou=org,dc=azblink,dc=com",
            "password": password, "profileId": tpl_resp.json()["id"],
        })
        assert resp.status_code == 201

        creds = get_uc_credentials(uid)
        assert creds["xmpp_password"] == password
        assert creds["sip_password"]  # non-empty, generated random

    def test_returns_none_for_missing_user(self):
        creds = get_uc_credentials("nonexistent-user-xyz")
        assert creds is None
```

- [ ] **Step 2: Run test to verify it fails**

```bash
just test-quick -- tests/test_device_provisioning.py::TestGetUcCredentials -v
```

Expected: FAIL — `cannot import name 'get_uc_credentials'`

- [ ] **Step 3: Implement `get_uc_credentials()`**

In `src/backend/ldap_client.py`, add after `add_uc_attrs_to_user()` (after line 98):

```python
def get_uc_credentials(uid: str) -> dict[str, str | None] | None:
    """Read UC bind passwords from LDAP for device provisioning.

    - Returns {"xmpp_password": str|None, "sip_password": str|None}
    - Returns None if user not found
    """
    def _op():
        conn = get_conn()
        user_dn = find_user_dn(conn, OU_PEOPLE, uid)
        if not user_dn:
            conn.unbind()
            return None
        conn.search(
            user_dn, "(objectClass=*)",
            search_scope="BASE",
            attributes=["azbXmppBindPassword", "AstAuthPassword"],
        )
        if not conn.entries:
            conn.unbind()
            return None
        entry = conn.entries[0]
        xmpp_pw = str(entry["azbXmppBindPassword"]) if "azbXmppBindPassword" in entry and str(entry["azbXmppBindPassword"]) else None
        sip_pw = str(entry["AstAuthPassword"]) if "AstAuthPassword" in entry and str(entry["AstAuthPassword"]) else None
        conn.unbind()
        return {"xmpp_password": xmpp_pw, "sip_password": sip_pw}
    return safe_ldap(_op)
```

- [ ] **Step 4: Run test to verify it passes**

```bash
just test-quick -- tests/test_device_provisioning.py::TestGetUcCredentials -v
```

Expected: 2 passed

- [ ] **Step 5: Commit**

```bash
git add src/backend/ldap_client.py tests/test_device_provisioning.py
git commit -m "feat(ldap): add get_uc_credentials helper for device provisioning"
```

---

### Task 8: Add `_set_user_passwords()` and update `reset_user_password()`

**Files:**
- Modify: `src/backend/ldap_client.py:903-916`

- [ ] **Step 1: Write test**

Add to `tests/test_device_provisioning.py`:

```python
from ldap_client import reset_user_password


class TestPasswordSync:
    """Verify password reset syncs azbXmppBindPassword."""

    def test_reset_syncs_xmpp_bind_password(self, client, ldap_conn, created_users):
        uid = f"pwsync-{uuid.uuid4().hex[:8]}"
        created_users.append(uid)
        tpl_name = f"pwsync-tpl-{uuid.uuid4().hex[:8]}"
        tpl_resp = client.post("/api/config-templates", json={
            "name": tpl_name, "description": "test",
            "xmppEnabled": True, "sipEnabled": False,
            "xmppDomain": "test.example.com", "xmppWsUrl": "wss://test.example.com/ws",
            "sipDomain": "sip.example.com", "sipWssUrl": "wss://sip.example.com",
            "uidRangeStart": 80000, "uidRangeEnd": 89999,
            "extRangeStart": 8000, "extRangeEnd": 8999,
        })
        assert tpl_resp.status_code == 201
        old_pw = "OldPassword123!"
        resp = client.post("/api/users/create", json={
            "uid": uid, "displayName": "PW Sync Test",
            "mail": f"{uid}@test.com", "mobile": "",
            "orgDn": "ou=org,dc=azblink,dc=com",
            "password": old_pw, "profileId": tpl_resp.json()["id"],
        })
        assert resp.status_code == 201

        # Reset password
        new_pw = "NewPassword456!"
        result = reset_user_password(uid, new_pw)
        assert result["ok"]

        # Verify azbXmppBindPassword updated
        creds = get_uc_credentials(uid)
        assert creds["xmpp_password"] == new_pw
```

- [ ] **Step 2: Run test to verify it fails**

```bash
just test-quick -- tests/test_device_provisioning.py::TestPasswordSync -v
```

Expected: FAIL — `azbXmppBindPassword` still has old value.

- [ ] **Step 3: Implement `_set_user_passwords()` and update `reset_user_password()`**

In `src/backend/ldap_client.py`, add before `reset_user_password()` (before line 903):

```python
def _set_user_passwords(user_dn: str, plaintext: str) -> None:
    """Update both userPassword (SSHA) and azbXmppBindPassword (plaintext) atomically.

    - Single LDAP MODIFY for both attributes
    - azbXmppBindPassword is only updated if the attribute exists on the entry
      (i.e., user has azblinkUser objectClass with XMPP provisioning)
    """
    def _op():
        conn = get_conn()
        # Check if entry has azbXmppBindPassword (azblinkUser objectClass)
        conn.search(user_dn, "(objectClass=*)", search_scope="BASE",
                     attributes=["objectClass"])
        changes = {
            "userPassword": [(MODIFY_REPLACE, [ssha_password(plaintext)])],
        }
        if conn.entries:
            entry_ocs = [str(oc) for oc in conn.entries[0]["objectClass"]]
            if "azblinkUser" in entry_ocs:
                changes["azbXmppBindPassword"] = [(MODIFY_REPLACE, [plaintext])]
        conn.modify(user_dn, changes)
        if conn.result.get("description") != "success":
            raise RuntimeError(f"LDAP password update failed: {conn.result}")
        conn.unbind()
    safe_ldap(_op)
```

Then update `reset_user_password()` (lines 903-916) to use the new helper:

```python
def reset_user_password(uid: str, new_password: str) -> Dict[str, Any]:
    """Reset a user's password (LDAP + XMPP bind password sync)."""
    if not new_password:
        raise ValueError("new_password must not be empty")
    def _op():
        conn = get_conn()
        user_dn = find_user_dn(conn, OU_PEOPLE, uid)
        if not user_dn:
            raise RuntimeError("User not found")
        conn.unbind()
        _set_user_passwords(user_dn, new_password)
        return {"ok": True}
    return safe_ldap(_op)
```

- [ ] **Step 4: Run test to verify it passes**

```bash
just test-quick -- tests/test_device_provisioning.py::TestPasswordSync -v
```

Expected: PASS

- [ ] **Step 5: Run all tests to verify no regression**

```bash
just test-quick
```

Expected: All tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/backend/ldap_client.py tests/test_device_provisioning.py
git commit -m "feat(ldap): sync azbXmppBindPassword on password reset"
```

---

## Chunk 3: Database Layer (OrgDB extensions)

### Task 9: Extend `provision_tokens` table definition and add `count_active_device_provisions()`

**Files:**
- Modify: `src/backend/orgdb.py:116-131` (table definition)
- Modify: `src/backend/orgdb.py:~577` (add new method after `record_provision_token`)

- [ ] **Step 1: Write test**

Add to `tests/test_device_provisioning.py`:

```python
class TestDeviceCapCounting:
    """Verify device cap counting in orgdb."""

    def test_count_zero_when_no_provisions(self, db_conn):
        from orgdb import OrgDB
        orgdb = OrgDB()
        count = orgdb.count_active_device_provisions("nonexistent-user-xyz")
        assert count == 0

    def test_count_excludes_qr_tokens(self, db_conn, client, created_users):
        """QR tokens should not count toward SSO device cap."""
        from orgdb import OrgDB
        orgdb = OrgDB()
        uid = f"cap-{uuid.uuid4().hex[:8]}"
        # Insert a QR token (auth_method='qr' is default)
        from datetime import datetime, timezone, timedelta
        orgdb.record_provision_token(
            token_hash=f"qr-hash-{uid}",
            uid=uid,
            profile_id="test-profile",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
        )
        count = orgdb.count_active_device_provisions(uid)
        assert count == 0  # QR tokens don't count
```

- [ ] **Step 2: Run test to verify it fails**

```bash
just test-quick -- tests/test_device_provisioning.py::TestDeviceCapCounting -v
```

Expected: FAIL — `count_active_device_provisions` not found.

- [ ] **Step 3: Update table definition**

In `src/backend/orgdb.py`, add the new columns to the `provision_tokens` table definition (after line 130):

```python
    Column("auth_method", String(32), nullable=False, server_default="qr"),
    Column("sealed_payload", LargeBinary, nullable=True),
    Column("public_key_hash", String(128), nullable=True),
```

Also add the `LargeBinary` import at the top of the file if not present:

```python
from sqlalchemy import LargeBinary
```

- [ ] **Step 4: Add `count_active_device_provisions()` method**

In `src/backend/orgdb.py`, add after `update_provision_token_device()` (after line 626):

```python
    def count_active_device_provisions(
        self, uid: str, exclude_device_id: str | None = None
    ) -> int:
        """Count active SSO device provisions for a user.

        - Only counts auth_method='sso_token' with status='active'
        - Optionally excludes a specific device_id (for re-provisioning)
        """
        eng = self.connect()
        with eng.begin() as conn:
            conditions = [
                provision_tokens.c.uid == uid,
                provision_tokens.c.auth_method == "sso_token",
                provision_tokens.c.status == "active",
            ]
            if exclude_device_id:
                conditions.append(
                    provision_tokens.c.consumed_by_device_id != exclude_device_id
                )
            from sqlalchemy import func
            row = conn.execute(
                select(func.count()).select_from(provision_tokens).where(*conditions)
            ).scalar()
            return row or 0
```

- [ ] **Step 5: Run test to verify it passes**

```bash
just test-quick -- tests/test_device_provisioning.py::TestDeviceCapCounting -v
```

Expected: 2 passed

- [ ] **Step 6: Commit**

```bash
git add src/backend/orgdb.py tests/test_device_provisioning.py
git commit -m "feat(db): add device cap counting to orgdb"
```

---

### Task 10: Add `upsert_device_provision()` method

**Files:**
- Modify: `src/backend/orgdb.py` (add after `count_active_device_provisions`)

- [ ] **Step 1: Write test**

Add to `tests/test_device_provisioning.py`:

```python
from datetime import datetime, timezone, timedelta


class TestUpsertDeviceProvision:
    """Verify upsert behavior for SSO device provisioning."""

    def test_insert_new_device(self, db_conn):
        from orgdb import OrgDB
        orgdb = OrgDB()
        uid = f"upsert-{uuid.uuid4().hex[:8]}"
        device_id = str(uuid.uuid4())
        orgdb.upsert_device_provision(
            uid=uid,
            device_id=device_id,
            profile_id="test-profile",
            expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            sealed_payload=b"encrypted-blob",
            public_key_hash="abc123hash",
            client_platform="iOS",
            client_version="1.0.0",
        )
        count = orgdb.count_active_device_provisions(uid)
        assert count == 1

    def test_upsert_same_device_updates(self, db_conn):
        from orgdb import OrgDB
        orgdb = OrgDB()
        uid = f"upsert2-{uuid.uuid4().hex[:8]}"
        device_id = str(uuid.uuid4())
        orgdb.upsert_device_provision(
            uid=uid, device_id=device_id, profile_id="test-profile",
            expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            sealed_payload=b"blob-v1", public_key_hash="hash1",
        )
        orgdb.upsert_device_provision(
            uid=uid, device_id=device_id, profile_id="test-profile",
            expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            sealed_payload=b"blob-v2", public_key_hash="hash2",
        )
        # Should still be 1 (upsert, not duplicate)
        count = orgdb.count_active_device_provisions(uid)
        assert count == 1
```

- [ ] **Step 2: Run test to verify it fails**

```bash
just test-quick -- tests/test_device_provisioning.py::TestUpsertDeviceProvision -v
```

Expected: FAIL — `upsert_device_provision` not found.

- [ ] **Step 3: Implement `upsert_device_provision()`**

In `src/backend/orgdb.py`, add after `count_active_device_provisions()`:

```python
    def upsert_device_provision(
        self,
        uid: str,
        device_id: str,
        profile_id: str,
        expires_at: datetime,
        sealed_payload: bytes,
        public_key_hash: str,
        client_platform: str | None = None,
        client_version: str | None = None,
        client_ip: str | None = None,
    ) -> str:
        """Insert or update an SSO device provision record.

        - Upserts keyed on (uid, device_id, auth_method='sso_token')
        - Returns the token_hash for the record
        """
        import hashlib, time
        token_hash = hashlib.sha256(
            f"{device_id}{uid}{int(time.time())}".encode()
        ).hexdigest()

        eng = self.connect()
        with eng.begin() as conn:
            # Try update first (existing device re-provisioning)
            result = conn.execute(
                update(provision_tokens)
                .where(
                    (provision_tokens.c.uid == uid)
                    & (provision_tokens.c.consumed_by_device_id == device_id)
                    & (provision_tokens.c.auth_method == "sso_token")
                )
                .values(
                    token_hash=token_hash,
                    profile_id=profile_id,
                    issued_at=utcnow(),
                    expires_at=expires_at,
                    used_at=None,
                    status="active",
                    sealed_payload=sealed_payload,
                    public_key_hash=public_key_hash,
                    client_platform=client_platform,
                    client_version=client_version,
                    consumed_from_ip=client_ip,
                )
            )
            if result.rowcount == 0:
                # New device — insert
                conn.execute(
                    insert(provision_tokens).values(
                        token_hash=token_hash,
                        uid=uid,
                        profile_id=profile_id,
                        issued_at=utcnow(),
                        expires_at=expires_at,
                        used_at=None,
                        status="active",
                        auth_method="sso_token",
                        consumed_by_device_id=device_id,
                        sealed_payload=sealed_payload,
                        public_key_hash=public_key_hash,
                        client_platform=client_platform,
                        client_version=client_version,
                        consumed_from_ip=client_ip,
                    )
                )
        return token_hash
```

- [ ] **Step 4: Run test to verify it passes**

```bash
just test-quick -- tests/test_device_provisioning.py::TestUpsertDeviceProvision -v
```

Expected: 2 passed

- [ ] **Step 5: Commit**

```bash
git add src/backend/orgdb.py tests/test_device_provisioning.py
git commit -m "feat(db): add upsert_device_provision for SSO provisioning"
```

---

### Task 11: Add `revoke_device_provision()` method

**Files:**
- Modify: `src/backend/orgdb.py` (add after `upsert_device_provision`)

- [ ] **Step 1: Write test**

Add to `tests/test_device_provisioning.py`:

```python
class TestRevokeDeviceProvision:
    """Verify device revocation."""

    def test_revoke_existing_device(self, db_conn):
        from orgdb import OrgDB
        orgdb = OrgDB()
        uid = f"revoke-{uuid.uuid4().hex[:8]}"
        device_id = str(uuid.uuid4())
        orgdb.upsert_device_provision(
            uid=uid, device_id=device_id, profile_id="test-profile",
            expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            sealed_payload=b"blob", public_key_hash="hash",
        )
        assert orgdb.count_active_device_provisions(uid) == 1
        result = orgdb.revoke_device_provision(uid, device_id)
        assert result is True
        assert orgdb.count_active_device_provisions(uid) == 0

    def test_revoke_nonexistent_device(self, db_conn):
        from orgdb import OrgDB
        orgdb = OrgDB()
        result = orgdb.revoke_device_provision("nobody", "no-device")
        assert result is False

    def test_revoke_other_users_device_fails(self, db_conn):
        from orgdb import OrgDB
        orgdb = OrgDB()
        uid = f"rvk-own-{uuid.uuid4().hex[:8]}"
        device_id = str(uuid.uuid4())
        orgdb.upsert_device_provision(
            uid=uid, device_id=device_id, profile_id="test-profile",
            expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            sealed_payload=b"blob", public_key_hash="hash",
        )
        result = orgdb.revoke_device_provision("other-user", device_id)
        assert result is False  # different uid
```

- [ ] **Step 2: Run test to verify it fails**

```bash
just test-quick -- tests/test_device_provisioning.py::TestRevokeDeviceProvision -v
```

Expected: FAIL — `revoke_device_provision` not found.

- [ ] **Step 3: Implement `revoke_device_provision()`**

```python
    def revoke_device_provision(self, uid: str, device_id: str) -> bool:
        """Revoke an SSO device provision. Returns True if found and revoked."""
        eng = self.connect()
        with eng.begin() as conn:
            result = conn.execute(
                update(provision_tokens)
                .where(
                    (provision_tokens.c.uid == uid)
                    & (provision_tokens.c.consumed_by_device_id == device_id)
                    & (provision_tokens.c.auth_method == "sso_token")
                    & (provision_tokens.c.status == "active")
                )
                .values(status="revoked", used_at=utcnow())
            )
            return result.rowcount > 0
```

- [ ] **Step 4: Run test to verify it passes**

```bash
just test-quick -- tests/test_device_provisioning.py::TestRevokeDeviceProvision -v
```

Expected: 3 passed

- [ ] **Step 5: Commit**

```bash
git add src/backend/orgdb.py tests/test_device_provisioning.py
git commit -m "feat(db): add revoke_device_provision for SSO device removal"
```

---

## Chunk 4: API Endpoints

### Task 12: Implement `POST /api/provision/device`

**Files:**
- Modify: `src/backend/main.py` — add route, Pydantic models, sealed box logic

- [ ] **Step 1: Write integration test — happy path**

Add to `tests/test_device_provisioning.py`:

```python
import base64
import json

try:
    import nacl.public
    import nacl.utils
    HAS_NACL = True
except ImportError:
    HAS_NACL = False


@pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
class TestProvisionDeviceEndpoint:
    """Integration tests for POST /api/provision/device."""

    def _make_keypair(self):
        """Generate ephemeral Curve25519 keypair for testing."""
        private_key = nacl.public.PrivateKey.generate()
        public_key = private_key.public_key
        return private_key, public_key

    def _create_uc_user(self, client, created_users):
        """Helper: create a user with XMPP+SIP enabled."""
        uid = f"devep-{uuid.uuid4().hex[:8]}"
        created_users.append(uid)
        tpl_name = f"devep-tpl-{uuid.uuid4().hex[:8]}"
        tpl_resp = client.post("/api/config-templates", json={
            "name": tpl_name, "description": "test",
            "xmppEnabled": True, "sipEnabled": True,
            "xmppDomain": "test.example.com", "xmppWsUrl": "wss://test.example.com/ws",
            "sipDomain": "sip.example.com", "sipWssUrl": "wss://sip.example.com",
            "uidRangeStart": 90000, "uidRangeEnd": 99999,
            "extRangeStart": 9000, "extRangeEnd": 9999,
        })
        assert tpl_resp.status_code == 201
        password = "ProvTest789!"
        resp = client.post("/api/users/create", json={
            "uid": uid, "displayName": "Device EP Test",
            "mail": f"{uid}@test.com", "mobile": "",
            "orgDn": "ou=org,dc=azblink,dc=com",
            "password": password, "profileId": tpl_resp.json()["id"],
        })
        assert resp.status_code == 201
        return uid, password

    def test_provision_device_happy_path(self, client, created_users):
        uid, password = self._create_uc_user(client, created_users)
        private_key, public_key = self._make_keypair()
        pub_b64 = base64.b64encode(public_key.encode()).decode()

        resp = client.post("/api/provision/device", json={
            "publicKey": pub_b64,
            "deviceId": str(uuid.uuid4()),
            "clientInfo": {"platform": "iOS", "version": "1.0.0"},
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["uid"] == uid
        assert "sealedCredentials" in data
        assert "endpoints" in data

        # Decrypt sealed credentials
        sealed = base64.b64decode(data["sealedCredentials"])
        unseal_box = nacl.public.SealedBox(private_key)
        plaintext = unseal_box.decrypt(sealed)
        creds = json.loads(plaintext)
        assert creds["xmppPassword"] == password
        assert creds["sipPassword"]  # non-empty
        assert creds["sipUsername"] == uid

    def test_provision_device_no_auth(self, anon_client):
        resp = anon_client.post("/api/provision/device", json={
            "publicKey": base64.b64encode(b"x" * 32).decode(),
            "deviceId": str(uuid.uuid4()),
        })
        assert resp.status_code == 401

    def test_provision_device_invalid_public_key(self, client):
        resp = client.post("/api/provision/device", json={
            "publicKey": base64.b64encode(b"too-short").decode(),
            "deviceId": str(uuid.uuid4()),
        })
        assert resp.status_code == 422
```

- [ ] **Step 2: Run test to verify it fails**

```bash
just test-quick -- tests/test_device_provisioning.py::TestProvisionDeviceEndpoint -v
```

Expected: FAIL — 404 (route doesn't exist yet)

- [ ] **Step 3: Implement the endpoint in main.py**

Add Pydantic models near the top of `main.py` (with other request/response models):

```python
class DeviceProvisionReq(BaseModel):
    publicKey: str  # base64-encoded 32-byte Curve25519 public key
    deviceId: str
    clientInfo: Optional[Dict[str, str]] = None

class DeviceProvisionResp(BaseModel):
    ok: bool
    uid: str
    sealedCredentials: str  # base64-encoded sealed box
    endpoints: Dict[str, Any]
    provisioned: Dict[str, bool]
    expiresAt: str
```

Add imports at the top of `main.py`:

```python
import nacl.public
from config import DEVICE_PROVISION_TTL_SEC, DEVICE_PROVISION_MAX_DEFAULT
from rate_limit import LIMIT_DEVICE_PROVISION
from ldap_client import get_uc_credentials
```

Add the endpoint (near the existing provisioning endpoints ~line 1940):

```python
@app.post("/api/provision/device")
@limiter.limit(LIMIT_DEVICE_PROVISION)
def api_provision_device(request: Request, req: DeviceProvisionReq,
                         claims: Dict[str, Any] = Depends(require_user)):
    """SSO-authenticated device provisioning with E2E encrypted credentials."""
    import base64, hashlib, json as json_mod
    from datetime import timedelta

    uid = claims.get("preferred_username", "")
    if not uid:
        raise HTTPException(401, detail={"error": "INVALID_TOKEN", "message": "No preferred_username in token"})

    # Validate public key
    try:
        pub_bytes = base64.b64decode(req.publicKey)
        if len(pub_bytes) != 32:
            raise ValueError("Public key must be 32 bytes")
        client_pub = nacl.public.PublicKey(pub_bytes)
    except Exception:
        raise HTTPException(422, detail={"error": "INVALID_REQUEST", "message": "Invalid Curve25519 public key"})

    # Resolve user in LDAP
    user = get_user(uid)
    if not user:
        raise HTTPException(403, detail={"error": "NOT_UC_PROVISIONED", "message": "User not found"})

    # Check for posixAccount (UC provisioned)
    user_dn = user.get("dn", "")
    if not user_dn:
        raise HTTPException(403, detail={"error": "NOT_UC_PROVISIONED", "message": "User has no DN"})

    # Resolve config template
    org_dn = user_dn.split(",ou=people,")[1] if ",ou=people," in user_dn else ""
    template = ORGDB.resolve_template_for_org(org_dn) if org_dn else None
    max_devices = DEVICE_PROVISION_MAX_DEFAULT
    xmpp_enabled = False
    sip_enabled = False
    xmpp_domain = ""
    xmpp_ws_url = ""
    sip_domain = ""
    sip_wss_url = ""

    if template:
        max_devices = template.get("max_devices_per_user", DEVICE_PROVISION_MAX_DEFAULT)
        xmpp_enabled = template.get("xmpp_enabled", False)
        sip_enabled = template.get("sip_enabled", False)
        xmpp_domain = template.get("xmpp_domain", "") or UCCHAT_XMPP_DOMAIN
        xmpp_ws_url = template.get("xmpp_ws_url", "") or UCCHAT_XMPP_WS_URL
        sip_domain = template.get("sip_domain", "") or UCCHAT_SIP_DOMAIN
        sip_wss_url = template.get("sip_wss_url", "") or UCCHAT_SIP_WSS_URL
    else:
        # Fallback to env-var defaults
        xmpp_domain = UCCHAT_XMPP_DOMAIN
        xmpp_ws_url = UCCHAT_XMPP_WS_URL
        sip_domain = UCCHAT_SIP_DOMAIN
        sip_wss_url = UCCHAT_SIP_WSS_URL

    if not xmpp_enabled and not sip_enabled:
        raise HTTPException(403, detail={"error": "NOT_UC_PROVISIONED", "message": "No UC services enabled"})

    # Check device cap
    current_count = ORGDB.count_active_device_provisions(uid, exclude_device_id=req.deviceId)
    if current_count >= max_devices:
        raise HTTPException(409, detail={
            "error": "DEVICE_CAP_REACHED",
            "message": f"Device limit reached ({current_count}/{max_devices})",
            "current": current_count,
            "max": max_devices,
        })

    # Read credentials from LDAP
    creds = get_uc_credentials(uid)
    if not creds:
        raise HTTPException(500, detail={"error": "CREDENTIAL_READ_FAILED"})

    cred_payload = {}
    if xmpp_enabled:
        if not creds.get("xmpp_password"):
            logger.error("azbXmppBindPassword missing for UC user %s", uid)
            raise HTTPException(500, detail={"error": "CREDENTIAL_READ_FAILED"})
        cred_payload["xmppPassword"] = creds["xmpp_password"]
    if sip_enabled:
        if not creds.get("sip_password"):
            logger.error("AstAuthPassword missing for UC user %s", uid)
            raise HTTPException(500, detail={"error": "CREDENTIAL_READ_FAILED"})
        cred_payload["sipPassword"] = creds["sip_password"]
        cred_payload["sipUsername"] = uid

    # Seal credentials with client's public key
    sealed_box = nacl.public.SealedBox(client_pub)
    sealed = sealed_box.encrypt(json_mod.dumps(cred_payload).encode())
    sealed_b64 = base64.b64encode(sealed).decode()

    # Record in provision_tokens
    expires = utcnow() + timedelta(seconds=DEVICE_PROVISION_TTL_SEC)
    pub_hash = hashlib.sha256(pub_bytes).hexdigest()
    profile_id = template.get("id", "") if template else ""

    ORGDB.upsert_device_provision(
        uid=uid,
        device_id=req.deviceId,
        profile_id=profile_id,
        expires_at=expires,
        sealed_payload=sealed,
        public_key_hash=pub_hash,
        client_platform=(req.clientInfo or {}).get("platform"),
        client_version=(req.clientInfo or {}).get("version"),
        client_ip=request.client.host if request.client else None,
    )

    return {
        "ok": True,
        "uid": uid,
        "sealedCredentials": sealed_b64,
        "endpoints": {
            "xmpp": {"domain": xmpp_domain, "wsUrl": xmpp_ws_url},
            "sip": {"domain": sip_domain, "wssUrl": sip_wss_url},
        },
        "provisioned": {"xmppEnabled": xmpp_enabled, "sipEnabled": sip_enabled},
        "expiresAt": iso(expires),
    }
```

- [ ] **Step 4: Run test to verify it passes**

```bash
just test-quick -- tests/test_device_provisioning.py::TestProvisionDeviceEndpoint -v
```

Expected: 3 passed

- [ ] **Step 5: Commit**

```bash
git add src/backend/main.py tests/test_device_provisioning.py
git commit -m "feat(api): add POST /api/provision/device endpoint"
```

---

### Task 13: Implement `DELETE /api/provision/device/{device_id}`

**Files:**
- Modify: `src/backend/main.py` — add delete route

- [ ] **Step 1: Write test**

Add to `tests/test_device_provisioning.py`:

```python
@pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
class TestDeleteDeviceEndpoint:
    """Integration tests for DELETE /api/provision/device/{device_id}."""

    def test_delete_own_device(self, client, created_users):
        # Create user + provision device
        uid = f"deldv-{uuid.uuid4().hex[:8]}"
        created_users.append(uid)
        tpl_name = f"deldv-tpl-{uuid.uuid4().hex[:8]}"
        tpl_resp = client.post("/api/config-templates", json={
            "name": tpl_name, "description": "test",
            "xmppEnabled": True, "sipEnabled": False,
            "xmppDomain": "test.example.com", "xmppWsUrl": "wss://test.example.com/ws",
            "sipDomain": "sip.example.com", "sipWssUrl": "wss://sip.example.com",
            "uidRangeStart": 50000, "uidRangeEnd": 59999,
            "extRangeStart": 5000, "extRangeEnd": 5999,
        })
        assert tpl_resp.status_code == 201
        resp = client.post("/api/users/create", json={
            "uid": uid, "displayName": "Del Dev Test",
            "mail": f"{uid}@test.com", "mobile": "",
            "orgDn": "ou=org,dc=azblink,dc=com",
            "password": "DelTest123!", "profileId": tpl_resp.json()["id"],
        })
        assert resp.status_code == 201

        # Provision device
        private_key, public_key = nacl.public.PrivateKey.generate(), None
        public_key = private_key.public_key
        device_id = str(uuid.uuid4())
        prov_resp = client.post("/api/provision/device", json={
            "publicKey": base64.b64encode(public_key.encode()).decode(),
            "deviceId": device_id,
        })
        assert prov_resp.status_code == 200

        # Delete device
        del_resp = client.delete(f"/api/provision/device/{device_id}")
        assert del_resp.status_code == 200
        assert del_resp.json()["status"] == "revoked"

    def test_delete_nonexistent_device(self, client):
        resp = client.delete(f"/api/provision/device/{uuid.uuid4()}")
        assert resp.status_code == 404

    def test_delete_no_auth(self, anon_client):
        resp = anon_client.delete(f"/api/provision/device/{uuid.uuid4()}")
        assert resp.status_code == 401
```

- [ ] **Step 2: Run test to verify it fails**

```bash
just test-quick -- tests/test_device_provisioning.py::TestDeleteDeviceEndpoint -v
```

Expected: FAIL — 405 Method Not Allowed (route doesn't exist)

- [ ] **Step 3: Implement the endpoint**

Add to `main.py` after the provision device endpoint:

```python
@app.delete("/api/provision/device/{device_id}")
@limiter.limit(LIMIT_DEVICE_PROVISION)
def api_revoke_device(request: Request, device_id: str,
                      claims: Dict[str, Any] = Depends(require_user)):
    """Revoke an SSO-provisioned device. User can only revoke own devices."""
    uid = claims.get("preferred_username", "")
    if not uid:
        raise HTTPException(401, detail={"error": "INVALID_TOKEN"})

    revoked = ORGDB.revoke_device_provision(uid, device_id)
    if not revoked:
        raise HTTPException(404, detail={"error": "DEVICE_NOT_FOUND",
                            "message": "Device not found or belongs to another user"})

    return {"ok": True, "deviceId": device_id, "status": "revoked"}
```

- [ ] **Step 4: Run test to verify it passes**

```bash
just test-quick -- tests/test_device_provisioning.py::TestDeleteDeviceEndpoint -v
```

Expected: 3 passed

- [ ] **Step 5: Commit**

```bash
git add src/backend/main.py tests/test_device_provisioning.py
git commit -m "feat(api): add DELETE /api/provision/device/{device_id} endpoint"
```

---

## Chunk 5: Device Cap + Edge Cases

### Task 14: Test device cap enforcement

**Files:**
- Modify: `tests/test_device_provisioning.py`

- [ ] **Step 1: Write device cap test**

Add to `tests/test_device_provisioning.py`:

```python
@pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
class TestDeviceCapEnforcement:
    """Verify device cap is enforced at the API level."""

    def _provision_device(self, client, device_id=None):
        private_key = nacl.public.PrivateKey.generate()
        pub_b64 = base64.b64encode(private_key.public_key.encode()).decode()
        return client.post("/api/provision/device", json={
            "publicKey": pub_b64,
            "deviceId": device_id or str(uuid.uuid4()),
        })

    def test_cap_enforcement(self, client, created_users, db_conn):
        """Provision max+1 devices, verify last one is rejected."""
        uid = f"cap-{uuid.uuid4().hex[:8]}"
        created_users.append(uid)
        tpl_name = f"cap-tpl-{uuid.uuid4().hex[:8]}"
        tpl_resp = client.post("/api/config-templates", json={
            "name": tpl_name, "description": "test",
            "xmppEnabled": True, "sipEnabled": False,
            "xmppDomain": "test.example.com", "xmppWsUrl": "wss://test.example.com/ws",
            "sipDomain": "sip.example.com", "sipWssUrl": "wss://sip.example.com",
            "uidRangeStart": 40000, "uidRangeEnd": 49999,
            "extRangeStart": 4000, "extRangeEnd": 4999,
            "maxDevicesPerUser": 2,  # low cap for testing
        })
        assert tpl_resp.status_code == 201
        resp = client.post("/api/users/create", json={
            "uid": uid, "displayName": "Cap Test",
            "mail": f"{uid}@test.com", "mobile": "",
            "orgDn": "ou=org,dc=azblink,dc=com",
            "password": "CapTest123!", "profileId": tpl_resp.json()["id"],
        })
        assert resp.status_code == 201

        # Provision 2 devices (at cap)
        assert self._provision_device(client).status_code == 200
        assert self._provision_device(client).status_code == 200

        # Third device should be rejected
        resp3 = self._provision_device(client)
        assert resp3.status_code == 409
        assert resp3.json()["error"] == "DEVICE_CAP_REACHED"

    def test_reprovision_same_device_bypasses_cap(self, client, created_users):
        """Re-provisioning same deviceId should not count as new slot."""
        uid = f"recap-{uuid.uuid4().hex[:8]}"
        created_users.append(uid)
        tpl_name = f"recap-tpl-{uuid.uuid4().hex[:8]}"
        tpl_resp = client.post("/api/config-templates", json={
            "name": tpl_name, "description": "test",
            "xmppEnabled": True, "sipEnabled": False,
            "xmppDomain": "test.example.com", "xmppWsUrl": "wss://test.example.com/ws",
            "sipDomain": "sip.example.com", "sipWssUrl": "wss://sip.example.com",
            "uidRangeStart": 41000, "uidRangeEnd": 41999,
            "extRangeStart": 4100, "extRangeEnd": 4199,
            "maxDevicesPerUser": 1,
        })
        assert tpl_resp.status_code == 201
        resp = client.post("/api/users/create", json={
            "uid": uid, "displayName": "Recap Test",
            "mail": f"{uid}@test.com", "mobile": "",
            "orgDn": "ou=org,dc=azblink,dc=com",
            "password": "RecapTest123!", "profileId": tpl_resp.json()["id"],
        })
        assert resp.status_code == 201

        device_id = str(uuid.uuid4())
        assert self._provision_device(client, device_id=device_id).status_code == 200
        # Re-provision same device — should succeed despite cap=1
        assert self._provision_device(client, device_id=device_id).status_code == 200
```

- [ ] **Step 2: Run tests**

```bash
just test-quick -- tests/test_device_provisioning.py::TestDeviceCapEnforcement -v
```

Expected: 2 passed

Note: If the `maxDevicesPerUser` field isn't read from the template yet, this test will help identify that. The config template JSON schema may need updating — handle inline.

- [ ] **Step 3: Commit**

```bash
git add tests/test_device_provisioning.py
git commit -m "test: add device cap enforcement integration tests"
```

---

### Task 15: Full regression test run

- [ ] **Step 1: Run all tests**

```bash
just test
```

Expected: All tests pass, including all new tests in `test_device_provisioning.py` and all existing tests unchanged.

- [ ] **Step 2: Verify API docs include new endpoints**

Open `http://localhost:8081/api/docs` and confirm:
- `POST /api/provision/device` appears with correct request/response schema
- `DELETE /api/provision/device/{device_id}` appears

- [ ] **Step 3: Final commit (if any fixes needed)**

```bash
git add -A
git commit -m "fix: address test regressions from device provisioning feature"
```

---

## Summary

| Task | What | Files |
|------|------|-------|
| 1 | LDAP schema: `azbXmppBindPassword` attribute | `deploy/dev/ldap/azblink.schema` |
| 2 | DB migration: 3 columns + 2 indexes | `migrations/022_device_provisioning.sql` |
| 3 | Add PyNaCl dependency | `src/backend/requirements.txt` |
| 4 | Config + rate limit constants | `src/backend/config.py`, `rate_limit.py` |
| 5 | `build_uc_attrs()` + `xmpp_password` param | `src/backend/ldap_client.py` |
| 6 | Pass plaintext password through user creation | `src/backend/main.py` |
| 7 | `get_uc_credentials()` LDAP helper | `src/backend/ldap_client.py` |
| 8 | `_set_user_passwords()` + password sync | `src/backend/ldap_client.py` |
| 9 | `count_active_device_provisions()` DB method | `src/backend/orgdb.py` |
| 10 | `upsert_device_provision()` DB method | `src/backend/orgdb.py` |
| 11 | `revoke_device_provision()` DB method | `src/backend/orgdb.py` |
| 12 | `POST /api/provision/device` endpoint | `src/backend/main.py` |
| 13 | `DELETE /api/provision/device/{device_id}` endpoint | `src/backend/main.py` |
| 14 | Device cap enforcement tests | `tests/test_device_provisioning.py` |
| 15 | Full regression test run | all |
