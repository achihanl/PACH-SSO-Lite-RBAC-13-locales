# LDAP Client Provisioning Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Provision unique, tracked LDAP client credentials from the platform (UI for operators, CLI for dev) that the #179 inventory recognizes as known instead of mislabeling.

**Architecture:** Each provisioned client is an entry `cn=<client_id>,ou=clients,dc=azblink,dc=com` (organizationalRole + simpleSecurityObject) whose bind is authorized by ONE static ACL (installed via osixia bootstrap ldif, EXTERNAL). A Postgres registry (`ldap_provisioned_clients`, no secret) records intent; the existing stats-log collector reconciles binds (classify → `provisioned_client`, status auto `acknowledged`). Per-client add/rotate/revoke run at app runtime as `cn=admin` (data plane). CLI is a thin API client.

**Tech Stack:** FastAPI + Pydantic v2, SQLAlchemy Core (Postgres), ldap3, osixia/openldap:1.5.0, React 19 + TanStack Query + @azblink/ui, stdlib argparse/urllib.

**Spec:** `docs/superpowers/specs/2026-07-02-ldap-client-provisioning-design.md`

**Reference facts (verified in recon):**
- `metadata.create_all()` in `orgdb.py:358` auto-creates any new `Table` on the same `metadata` → fresh stacks need no migration, but ship `migrations/029_*.sql` as the hand-mirror for running stacks. **028 is taken** by `ldap_clients`.
- `ldap_client.get_conn()` → bound `ldap3.Connection`; wrap ops in `safe_ldap(_op)`; `conn.add/modify/delete` then check `conn.result.get("description")`; `ssha_password(plain)` (`ldap_client.py:21`) hashes; `ensure_ou(conn, dn)` (`ldap_client.py:234`) idempotently creates OUs.
- Endpoints under `/api/settings/ldap/clients`, guarded `require_permission("system_configuration")`, `{"ok": True, ...}` envelope; audit via `ORGDB.record_admin_action(extract_actor(claims), action, "settings", id, detail={...})` in best-effort try/except.
- `secrets` is imported in `main.py`; `uuid` is NOT.
- Frontend: hooks in `lib/queries/ldap-clients.ts`, keys in `lib/queries/keys.ts`, types in `types/ldap-clients.ts`, page `components/features/ldap-clients/LdapClientsPage.tsx`. Reuse `generatePassword()` (`lib/queries/user-create.ts:117`), copy pattern from `CopyableDN.tsx`, secret-shown-once from `StepComplete.tsx:161-197`, Dialog shape from `AddUserModal.tsx`. `getApi().get/post/delete`; base path omits `/api`.

---

## Phase 1 — LDAP layer + config foundation

### Task 1: Add `OU_CLIENTS` config + document env var

**Files:**
- Modify: `src/backend/config.py` (near lines 11-13, the `OU_ORG/OU_PEOPLE/OU_GROUPS` block)
- Modify: `deploy/dev/.env.example` (LDAP section, after `LDAP_BIND_PW`)

- [ ] **Step 1: Add the derived DN to config.py**

After the `OU_GROUPS = f"ou=groups,{LDAP_BASE_DN}"` line, add:
```python
# Provisioned LDAP client accounts (client-provisioning feature) live here.
OU_CLIENTS = os.getenv("LDAP_CLIENTS_OU", f"ou=clients,{LDAP_BASE_DN}")
```

- [ ] **Step 2: Document the var in .env.example**

After the `LDAP_BIND_PW=adminpassword` line, add:
```
# Provisioned LDAP client accounts subtree (client-provisioning feature).
# Defaults to ou=clients,<LDAP_BASE_DN>; override only if you relocate the subtree.
# LDAP_CLIENTS_OU=ou=clients,dc=azblink,dc=com
```

- [ ] **Step 3: Verify config imports**

Run: `cd deploy/dev && just psql -c "SELECT 1"` is unrelated — instead verify the module parses:
```bash
docker exec azblink-directory-api python -c "import config; print(config.OU_CLIENTS)"
```
Expected: `ou=clients,dc=azblink,dc=com`

- [ ] **Step 4: Commit**
```bash
git add src/backend/config.py deploy/dev/.env.example
git commit -m "feat(ldap): add OU_CLIENTS config for client provisioning subtree"
```

---

### Task 2: Bootstrap ACL ldif granting read-minus-secrets to `ou=clients`

**Files:**
- Create: `deploy/dev/ldap/ldap-clients-acl.ldif`
- Modify: `deploy/dev/docker-compose.yml` (openldap `volumes:`, after the `logfile-config.ldif` mount ~line 65)

**Context:** osixia applies top-level `bootstrap/ldif/*.ldif` as `cn=config` modifies via EXTERNAL on fresh init. `olcAccess` is multivalued/ordered — replace the whole attribute with the known-good rule set plus the new `ou=clients` grant (verified current rules on 2026-07-02).

- [ ] **Step 1: Write the ACL ldif**

Create `deploy/dev/ldap/ldap-clients-acl.ldif`:
```
# ldap-clients-acl.ldif — grant read-minus-secrets to provisioned client accounts.
# Applied by osixia at fresh init via EXTERNAL (top-level bootstrap ldif).
# For an ALREADY-RUNNING stack, apply manually:
#   docker cp deploy/dev/ldap/ldap-clients-acl.ldif azblink-openldap:/tmp/acl.ldif
#   docker exec azblink-openldap ldapmodify -Y EXTERNAL -H ldapi:/// -f /tmp/acl.ldif
# Rule {2} adds: by dn.children="ou=clients,dc=azblink,dc=com" read
# userPassword/shadowLastChange stay protected by rule {1}.
dn: olcDatabase={1}mdb,cn=config
changetype: modify
replace: olcAccess
olcAccess: {0}to * by dn.exact=gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth manage by * break
olcAccess: {1}to attrs=userPassword,shadowLastChange by self write by dn="cn=admin,dc=azblink,dc=com" write by anonymous auth by * none
olcAccess: {2}to * by self read by dn="cn=admin,dc=azblink,dc=com" write by dn.children="ou=clients,dc=azblink,dc=com" read by * none
```

- [ ] **Step 2: Mount it in docker-compose.yml**

In the `openldap` service `volumes:` list, after the `logfile-config.ldif` line, add:
```yaml
      # Client-provisioning ACL: read-minus-secrets for entries under ou=clients (EXTERNAL, fresh init)
      - ./ldap/ldap-clients-acl.ldif:/container/service/slapd/assets/config/bootstrap/ldif/ldap-clients-acl.ldif:ro
```

- [ ] **Step 3: Apply to the running stack (dev) and verify**

The bootstrap ldif only auto-applies on fresh volumes. Apply manually to the current stack:
```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack
docker cp deploy/dev/ldap/ldap-clients-acl.ldif azblink-openldap:/tmp/acl.ldif
docker exec azblink-openldap ldapmodify -Y EXTERNAL -H ldapi:/// -f /tmp/acl.ldif
docker exec azblink-openldap ldapsearch -Y EXTERNAL -H ldapi:/// -b "olcDatabase={1}mdb,cn=config" olcAccess -o ldif-wrap=no 2>/dev/null | grep -i "ou=clients"
```
Expected: the `{2}` line containing `by dn.children="ou=clients,dc=azblink,dc=com" read`.

- [ ] **Step 4: Verify a fresh reset applies it automatically**
```bash
cd deploy/dev && just reset && just up-bg && just health-check
docker exec azblink-openldap ldapsearch -Y EXTERNAL -H ldapi:/// -b "olcDatabase={1}mdb,cn=config" olcAccess -o ldif-wrap=no 2>/dev/null | grep -c "ou=clients"
```
Expected: `1`. (Note: `just reset` wipes the `ped80-svc`/`ldapprobe` verification artifacts — expected.)

- [ ] **Step 5: Commit**
```bash
git add deploy/dev/ldap/ldap-clients-acl.ldif deploy/dev/docker-compose.yml
git commit -m "feat(ldap): bootstrap ACL granting read-minus-secrets to ou=clients"
```

---

### Task 3: `ensure_clients_ou()` in ldap_client.py, wired at startup

**Files:**
- Modify: `src/backend/ldap_client.py` (import `OU_CLIENTS`; add function; wire into `bootstrap_base_ous()` ~line 252)
- Test: `tests/test_ldap_provisioning.py` (new file)

- [ ] **Step 1: Write the failing test**

Create `tests/test_ldap_provisioning.py`:
```python
"""Integration tests for LDAP client provisioning (real Docker stack)."""
import ldap_client


def test_ensure_clients_ou_creates_subtree():
    conn = ldap_client.get_conn()
    try:
        ldap_client.ensure_clients_ou()  # idempotent
        conn.search(ldap_client.OU_CLIENTS, "(objectClass=organizationalUnit)",
                    search_scope="BASE", attributes=["ou"])
        assert conn.entries, "ou=clients should exist after ensure_clients_ou()"
    finally:
        conn.unbind()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py::test_ensure_clients_ou_creates_subtree`
Expected: FAIL — `AttributeError: module 'ldap_client' has no attribute 'ensure_clients_ou'`

- [ ] **Step 3: Implement**

In `src/backend/ldap_client.py`, add `OU_CLIENTS` to the `from config import (...)` block, then add near `bootstrap_base_ous()`:
```python
def ensure_clients_ou() -> None:
    """Idempotently create the provisioned-client subtree (ou=clients)."""
    def _op():
        conn = get_conn()
        ensure_ou(conn, OU_CLIENTS)
        conn.unbind()
        return None
    return safe_ldap(_op)
```
And in `bootstrap_base_ous()`, add `ensure_ou(conn, OU_CLIENTS)` alongside the existing OU ensures.

- [ ] **Step 4: Wire into app startup**

In `src/backend/main.py` lifespan (after `init_activity_bus()`, before the collector task), add:
```python
    try:
        ldap_client.ensure_clients_ou()
        logger.info("ou=clients subtree ensured")
    except Exception:
        logger.warning("ensure_clients_ou failed (non-fatal)", exc_info=True)
```
(Backend hot-reloads; wait ~2s.)

- [ ] **Step 5: Run test to verify it passes**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py::test_ensure_clients_ou_creates_subtree`
Expected: PASS

- [ ] **Step 6: Commit**
```bash
git add src/backend/ldap_client.py src/backend/main.py tests/test_ldap_provisioning.py
git commit -m "feat(ldap): ensure_clients_ou() at startup"
```

---

## Phase 2 — Provisioning backend core

### Task 4: `ldap_provisioned_clients` table + OrgDB methods + migration 029

**Files:**
- Modify: `src/backend/orgdb.py` (Table after `ldap_clients` ~line 337; methods after `delete_ldap_client` ~line 1968)
- Create: `migrations/029_ldap_provisioned_clients.sql`
- Test: `tests/test_ldap_provisioning.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_ldap_provisioning.py`:
```python
from orgdb import OrgDB
import os

def _db():
    return OrgDB(os.environ["DATABASE_URL"])

def test_provisioned_client_registry_crud():
    db = _db()
    db.add_provisioned_client("regtest", "cn=regtest,ou=clients,dc=azblink,dc=com",
                              label="reg", created_by="tester")
    got = db.get_provisioned_client("regtest")
    assert got and got["bind_dn"] == "cn=regtest,ou=clients,dc=azblink,dc=com"
    assert got["revoked_at"] is None
    assert db.is_provisioned_bind_dn("cn=regtest,ou=clients,dc=azblink,dc=com") is True
    db.revoke_provisioned_client("regtest")
    assert db.get_provisioned_client("regtest")["revoked_at"] is not None
    assert db.is_provisioned_bind_dn("cn=regtest,ou=clients,dc=azblink,dc=com") is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py::test_provisioned_client_registry_crud`
Expected: FAIL — `AttributeError: 'OrgDB' object has no attribute 'add_provisioned_client'`

- [ ] **Step 3: Add the Table (orgdb.py, after `ldap_clients` definition)**
```python
ldap_provisioned_clients = Table(
    "ldap_provisioned_clients", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("client_id", String(64), nullable=False, unique=True),
    Column("bind_dn", String(255), nullable=False, unique=True),
    Column("label", String(255), nullable=True),
    Column("created_by", String(100), nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("last_rotated_at", DateTime(timezone=True), nullable=True),
    Column("revoked_at", DateTime(timezone=True), nullable=True),
)
```

- [ ] **Step 4: Add OrgDB methods (after `delete_ldap_client`)**
```python
    def add_provisioned_client(self, client_id: str, bind_dn: str,
                               label: str | None, created_by: str) -> dict[str, Any]:
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(insert(ldap_provisioned_clients).values(
                client_id=client_id, bind_dn=bind_dn, label=label, created_by=created_by,
            ))
            row = conn.execute(select(ldap_provisioned_clients).where(
                ldap_provisioned_clients.c.client_id == client_id)).mappings().first()
        return dict(row)

    def list_provisioned_clients(self, include_revoked: bool = False) -> list[dict[str, Any]]:
        eng = self.connect()
        stmt = select(ldap_provisioned_clients)
        if not include_revoked:
            stmt = stmt.where(ldap_provisioned_clients.c.revoked_at.is_(None))
        stmt = stmt.order_by(ldap_provisioned_clients.c.created_at.desc())
        with eng.begin() as conn:
            return [dict(r) for r in conn.execute(stmt).mappings().all()]

    def get_provisioned_client(self, client_id: str) -> dict[str, Any] | None:
        eng = self.connect()
        with eng.begin() as conn:
            row = conn.execute(select(ldap_provisioned_clients).where(
                ldap_provisioned_clients.c.client_id == client_id)).mappings().first()
        return dict(row) if row else None

    def mark_provisioned_client_rotated(self, client_id: str) -> None:
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(update(ldap_provisioned_clients)
                         .where(ldap_provisioned_clients.c.client_id == client_id)
                         .values(last_rotated_at=func.now()))

    def revoke_provisioned_client(self, client_id: str) -> None:
        eng = self.connect()
        with eng.begin() as conn:
            conn.execute(update(ldap_provisioned_clients)
                         .where(ldap_provisioned_clients.c.client_id == client_id)
                         .values(revoked_at=func.now()))

    def is_provisioned_bind_dn(self, bind_dn: str) -> bool:
        eng = self.connect()
        with eng.begin() as conn:
            row = conn.execute(select(ldap_provisioned_clients.c.id).where(
                (ldap_provisioned_clients.c.bind_dn == bind_dn) &
                (ldap_provisioned_clients.c.revoked_at.is_(None)))).first()
        return row is not None
```

- [ ] **Step 5: Write the migration (hand-mirror)**

Create `migrations/029_ldap_provisioned_clients.sql`:
```sql
-- migrations/029_ldap_provisioned_clients.sql
-- Registry of LDAP client credentials PROVISIONED by the platform (intent).
-- Distinct from ldap_clients (observed/detected). No secret column — the hash
-- lives only in LDAP. Hand-mirror of the ldap_provisioned_clients Table in orgdb.py.

CREATE TABLE IF NOT EXISTS ldap_provisioned_clients (
    id              SERIAL PRIMARY KEY,
    client_id       VARCHAR(64)  NOT NULL UNIQUE,
    bind_dn         VARCHAR(255) NOT NULL UNIQUE,
    label           VARCHAR(255),
    created_by      VARCHAR(100) NOT NULL,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_rotated_at TIMESTAMPTZ,
    revoked_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_ldap_prov_clients_active
    ON ldap_provisioned_clients(revoked_at);
```

- [ ] **Step 6: Run test to verify it passes**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py::test_provisioned_client_registry_crud`
Expected: PASS (table auto-created by `metadata.create_all` on backend reload)

- [ ] **Step 7: Commit**
```bash
git add src/backend/orgdb.py migrations/029_ldap_provisioned_clients.sql tests/test_ldap_provisioning.py
git commit -m "feat(ldap): ldap_provisioned_clients registry + OrgDB methods + migration 029"
```

---

### Task 5: classify() → `provisioned_client` for entries under ou=clients

**Files:**
- Modify: `src/backend/ldap_activity.py` (`classify()` ~lines 173-205; helper near `_api_bind_dn` ~line 163)
- Test: `tests/unit/test_ldap_activity_classify.py` (extend if exists, else create)

- [ ] **Step 1: Write the failing test**

Create/extend `tests/unit/test_ldap_activity_classify.py`:
```python
from ldap_activity import classify

def test_classify_provisioned_client_under_ou_clients():
    dn = "cn=ped80,ou=clients,dc=azblink,dc=com"
    assert classify(dn, "172.18.0.1", cidr_rules=[], api_bind_dn="cn=admin,dc=azblink,dc=com") == "provisioned_client"

def test_classify_uid_under_ou_clients_not_xmpp():
    # A uid= entry that lives under ou=clients must NOT be misread as xmpp
    dn = "uid=svc,ou=clients,dc=azblink,dc=com"
    assert classify(dn, "172.18.0.1", cidr_rules=[]) == "provisioned_client"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd deploy/dev && just test-quick tests/unit/test_ldap_activity_classify.py`
Expected: FAIL — returns `"unknown"`/`"xmpp"`, not `"provisioned_client"`

- [ ] **Step 3: Add a lazy helper + the ordered rule**

Near `_api_bind_dn()` in `ldap_activity.py`, add:
```python
def _clients_ou() -> str:
    """The provisioned-client subtree DN (lowercased), from config."""
    try:
        import config
        return (getattr(config, "OU_CLIENTS", "") or "").strip().lower()
    except Exception:
        return ""
```
In `classify()`, insert BEFORE the `# 4. person bind` block:
```python
    # 3b. provisioned client accounts (under ou=clients) — check before uid= fallback
    clients_ou = _clients_ou()
    if clients_ou and dnl.endswith("," + clients_ou):
        return "provisioned_client"
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd deploy/dev && just test-quick tests/unit/test_ldap_activity_classify.py`
Expected: PASS

- [ ] **Step 5: Commit**
```bash
git add src/backend/ldap_activity.py tests/unit/test_ldap_activity_classify.py
git commit -m "feat(ldap): classify provisioned clients under ou=clients"
```

---

### Task 6: Reconcile — auto-acknowledge provisioned binds on insert

**Files:**
- Modify: `src/backend/orgdb.py` (`upsert_ldap_session` ~lines 1872-1899)
- Test: `tests/test_ldap_provisioning.py`

- [ ] **Step 1: Write the failing test**
```python
def test_provisioned_bind_auto_acknowledged_on_insert():
    db = _db()
    # simulate a fresh provisioned-client bind seen by the collector
    dn = "cn=acktest,ou=clients,dc=azblink,dc=com"
    db.upsert_ldap_session(dn, "172.18.0.99", "SIMPLE", "provisioned_client")
    row = next(c for c in db.list_ldap_clients(include_healthcheck=True)
               if c["bind_dn"] == dn and c["source_ip"] == "172.18.0.99")
    assert row["service"] == "provisioned_client"
    assert row["status"] == "acknowledged"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py::test_provisioned_bind_auto_acknowledged_on_insert`
Expected: FAIL — status is `"unknown"`

- [ ] **Step 3: Implement — set status on insert only**

In `upsert_ldap_session`, change the `pg_insert(...).values(...)` to include a computed status, and leave `on_conflict_do_update` unchanged (so operator status edits survive):
```python
        insert_status = "acknowledged" if service == "provisioned_client" else "unknown"
        stmt = pg_insert(ldap_clients).values(
            bind_dn=bind_dn,
            source_ip=source_ip,
            service=service,
            status=insert_status,
            last_bind_mech=mech,
            session_count=1,
        )
```
(The `on_conflict_do_update` set_ stays as-is — no `status` key — so re-binds never clobber operator decisions.)

- [ ] **Step 4: Run test to verify it passes**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py::test_provisioned_bind_auto_acknowledged_on_insert`
Expected: PASS

- [ ] **Step 5: Commit**
```bash
git add src/backend/orgdb.py tests/test_ldap_provisioning.py
git commit -m "feat(ldap): auto-acknowledge provisioned-client binds on first sight"
```

---

### Task 7: `ldap_provisioning.py` — provision / rotate / revoke / list

**Files:**
- Create: `src/backend/ldap_provisioning.py`
- Test: `tests/test_ldap_provisioning.py`

- [ ] **Step 1: Write the failing test**
```python
import ldap_provisioning, ldap_client, pytest

def test_provision_rotate_revoke_end_to_end():
    cid = "e2eclient"
    # clean slate
    try:
        ldap_provisioning.revoke(cid)
    except Exception:
        pass
    res = ldap_provisioning.provision(cid, label="e2e", created_by="tester")
    assert res["bind_dn"] == f"cn={cid},ldap_clients_ou".replace("ldap_clients_ou", ldap_client.OU_CLIENTS)
    secret = res["secret"]
    # the provisioned client can bind + search, but cannot read userPassword
    conn = ldap_client.get_conn()
    try:
        conn.rebind(user=res["bind_dn"], password=secret)
        assert conn.bound is True
    finally:
        conn.unbind()
    # rotate → old secret fails, new works
    new = ldap_provisioning.rotate(cid)["secret"]
    assert new != secret
    c2 = ldap_client.get_conn()
    try:
        assert c2.rebind(user=res["bind_dn"], password=secret) is False  # old rejected
    except Exception:
        pass
    finally:
        c2.unbind()
    # revoke → entry gone, registry marked
    ldap_provisioning.revoke(cid)
    assert ldap_provisioning.orgdb().get_provisioned_client(cid)["revoked_at"] is not None

def test_provision_rejects_bad_client_id():
    with pytest.raises(ValueError):
        ldap_provisioning.provision("Bad ID!", label=None, created_by="t")

def test_provision_rejects_weak_supplied_password():
    with pytest.raises(ValueError):
        ldap_provisioning.provision("weakpwclient", label=None, created_by="t", password="short")
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py::test_provision_rotate_revoke_end_to_end`
Expected: FAIL — `ModuleNotFoundError: No module named 'ldap_provisioning'`

- [ ] **Step 3: Implement the module**

Create `src/backend/ldap_provisioning.py`:
```python
"""ldap_provisioning.py — provision/rotate/revoke platform LDAP client credentials.

- client entry: cn=<client_id>,ou=clients,dc=azblink,dc=com (organizationalRole +
  simpleSecurityObject); read granted by the static bootstrap ACL.
- secret: generated strong by default, or operator-supplied + strength-validated;
  never persisted (only the DN reference in ldap_provisioned_clients).
- registry: ldap_provisioned_clients (OrgDB); reconciled into the inventory by the
  stats-log collector (classify → provisioned_client, auto-acknowledged).
"""
from __future__ import annotations

import re
import secrets as _secrets

from ldap3 import MODIFY_REPLACE

import ldap_client
from config import DATABASE_URL, OU_CLIENTS
from orgdb import OrgDB

_CLIENT_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,30}$")

_ORGDB: OrgDB | None = None


def orgdb() -> OrgDB:
    global _ORGDB
    if _ORGDB is None:
        _ORGDB = OrgDB(DATABASE_URL)
    return _ORGDB


def _bind_dn(client_id: str) -> str:
    return f"cn={client_id},{OU_CLIENTS}"


def generate_secret() -> str:
    """A strong URL-safe secret (~24 chars)."""
    return _secrets.token_urlsafe(18)


def validate_client_id(client_id: str) -> str:
    if not _CLIENT_ID_RE.match(client_id or ""):
        raise ValueError(
            "client_id must be a slug: lowercase letters, digits, hyphens, 2-31 chars"
        )
    return client_id


def validate_password(pw: str) -> str:
    """Minimal strength policy: >=12 chars with upper, lower, and digit."""
    if len(pw or "") < 12:
        raise ValueError("password must be at least 12 characters")
    if not (any(c.islower() for c in pw) and any(c.isupper() for c in pw)
            and any(c.isdigit() for c in pw)):
        raise ValueError("password must include lower, upper, and digit characters")
    return pw


def provision(client_id: str, label: str | None, created_by: str,
              password: str | None = None) -> dict:
    """Create a client entry + registry row. Returns {client_id, bind_dn, secret}."""
    validate_client_id(client_id)
    secret = validate_password(password) if password else generate_secret()
    dn = _bind_dn(client_id)

    def _op():
        conn = ldap_client.get_conn()
        ldap_client.ensure_ou(conn, OU_CLIENTS)
        if ldap_client.entry_exists(conn, dn):
            conn.unbind()
            raise ValueError(f"client '{client_id}' already exists")
        attrs = {"cn": client_id, "userPassword": ldap_client.ssha_password(secret)}
        if label:
            attrs["description"] = label
        conn.add(dn, ["top", "organizationalRole", "simpleSecurityObject"], attrs)
        if conn.result.get("description") != "success":
            conn.unbind()
            raise RuntimeError(f"LDAP client create failed: {conn.result}")
        conn.unbind()
        return None

    ldap_client.safe_ldap(_op)
    orgdb().add_provisioned_client(client_id, dn, label, created_by)
    return {"client_id": client_id, "bind_dn": dn, "secret": secret}


def rotate(client_id: str, password: str | None = None) -> dict:
    """Set a new secret on an existing client. Returns {client_id, bind_dn, secret}."""
    row = orgdb().get_provisioned_client(client_id)
    if row is None or row["revoked_at"] is not None:
        raise ValueError(f"client '{client_id}' not found")
    secret = validate_password(password) if password else generate_secret()
    dn = row["bind_dn"]

    def _op():
        conn = ldap_client.get_conn()
        conn.modify(dn, {"userPassword": [(MODIFY_REPLACE, [ldap_client.ssha_password(secret)])]})
        if conn.result.get("description") != "success":
            conn.unbind()
            raise RuntimeError(f"LDAP rotate failed: {conn.result}")
        conn.unbind()
        return None

    ldap_client.safe_ldap(_op)
    orgdb().mark_provisioned_client_rotated(client_id)
    return {"client_id": client_id, "bind_dn": dn, "secret": secret}


def revoke(client_id: str) -> dict:
    """Delete the LDAP entry (if present) and mark the registry row revoked."""
    row = orgdb().get_provisioned_client(client_id)
    dn = row["bind_dn"] if row else _bind_dn(client_id)

    def _op():
        conn = ldap_client.get_conn()
        if ldap_client.entry_exists(conn, dn):
            conn.delete(dn)
            if conn.result.get("description") != "success":
                conn.unbind()
                raise RuntimeError(f"LDAP revoke failed: {conn.result}")
        conn.unbind()
        return None

    ldap_client.safe_ldap(_op)
    if row is not None:
        orgdb().revoke_provisioned_client(client_id)
    return {"ok": True, "client_id": client_id}


def list_clients() -> list[dict]:
    """Registry rows for non-revoked clients (no secrets)."""
    return orgdb().list_provisioned_clients(include_revoked=False)
```
Note: `entry_exists`, `get_conn`, `safe_ldap`, `ssha_password`, `ensure_ou`, `OU_CLIENTS` are all exported by `ldap_client`/imported there. If `ldap3.Connection.rebind` in the test needs `auto_bind`, adjust the test to open a fresh `Connection(Server(LDAP_URI), user=dn, password=secret, auto_bind=True)` instead of `rebind` (use whichever the installed ldap3 supports — verify against ldap3 docs).

- [ ] **Step 4: Run tests to verify they pass**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py`
Expected: PASS (all provisioning tests). If a bind-verification assertion is flaky due to ldap3 `rebind` semantics, switch to a fresh `Connection(..., auto_bind=True)` and assert `.bound`.

- [ ] **Step 5: Commit**
```bash
git add src/backend/ldap_provisioning.py tests/test_ldap_provisioning.py
git commit -m "feat(ldap): ldap_provisioning module (provision/rotate/revoke/list)"
```

---

## Phase 3 — API endpoints

### Task 8: POST provision endpoint + models

**Files:**
- Modify: `src/backend/main.py` (after the LDAP inventory block ~line 3607; import `ldap_provisioning` at top with the other backend imports)
- Test: `tests/test_ldap_provisioning.py`

- [ ] **Step 1: Write the failing test** (uses the authenticated `client` fixture)
```python
def test_api_provision_lists_and_revokes(client):
    # provision
    r = client.post("/api/settings/ldap/clients/provisioned",
                    json={"client_id": "apitest", "label": "api"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["ok"] and body["client"]["client_id"] == "apitest"
    assert body["secret"] and len(body["secret"]) >= 20  # returned once
    # list
    r = client.get("/api/settings/ldap/clients/provisioned")
    assert any(c["client_id"] == "apitest" for c in r.json()["clients"])
    # revoke (cleanup)
    r = client.delete("/api/settings/ldap/clients/provisioned/apitest")
    assert r.status_code == 200 and r.json()["ok"]

def test_api_provision_rejects_bad_id(client):
    r = client.post("/api/settings/ldap/clients/provisioned", json={"client_id": "Bad!"})
    assert r.status_code == 422 or r.status_code == 400

def test_api_provision_requires_auth(anon_client):
    r = anon_client.post("/api/settings/ldap/clients/provisioned", json={"client_id": "x"})
    assert r.status_code in (401, 403)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py::test_api_provision_lists_and_revokes`
Expected: FAIL — 404 (route not defined)

- [ ] **Step 3: Implement models + POST**

At the top of `main.py`, add `import ldap_provisioning` with the other module imports. After the inventory endpoints block, add:
```python
class ProvisionClientRequest(BaseModel):
    client_id: str = Field(..., min_length=2, max_length=31)
    label: Optional[str] = Field(None, max_length=255)
    password: Optional[str] = None

    @field_validator("client_id")
    @classmethod
    def _slug(cls, v: str) -> str:
        import re
        if not re.match(r"^[a-z0-9][a-z0-9-]{1,30}$", v):
            raise ValueError("client_id must be a lowercase slug (a-z, 0-9, -)")
        return v


@app.post("/api/settings/ldap/clients/provisioned")
def api_provision_ldap_client(
    req: ProvisionClientRequest,
    claims: dict = require_permission("system_configuration"),
):
    try:
        result = ldap_provisioning.provision(
            req.client_id, label=req.label,
            created_by=extract_actor(claims), password=req.password,
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    try:
        ORGDB.record_admin_action(
            extract_actor(claims), "provision_ldap_client", "settings",
            req.client_id, detail={"label": req.label},
        )
    except Exception:
        pass
    return {
        "ok": True,
        "client": {"client_id": result["client_id"], "bind_dn": result["bind_dn"]},
        "secret": result["secret"],  # shown once; never stored
    }
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py::test_api_provision_lists_and_revokes`
Expected: the provision + list assertions pass (revoke/list depend on Tasks 9 & 11 — run the full file after those). For now assert provision returns 200 with a secret.

- [ ] **Step 5: Commit**
```bash
git add src/backend/main.py tests/test_ldap_provisioning.py
git commit -m "feat(api): POST provision LDAP client endpoint"
```

---

### Task 9: GET list provisioned + Task 10: rotate + Task 11: revoke

**Files:** `src/backend/main.py` (same block), `tests/test_ldap_provisioning.py`

- [ ] **Step 1: Add the three endpoints**
```python
@app.get("/api/settings/ldap/clients/provisioned")
def api_list_provisioned_clients(
    claims: dict = require_permission("system_configuration"),
):
    return {"ok": True, "clients": ldap_provisioning.list_clients()}


@app.post("/api/settings/ldap/clients/provisioned/{client_id}/rotate")
def api_rotate_provisioned_client(
    client_id: str,
    claims: dict = require_permission("system_configuration"),
):
    try:
        result = ldap_provisioning.rotate(client_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc))
    try:
        ORGDB.record_admin_action(
            extract_actor(claims), "rotate_ldap_client", "settings", client_id,
        )
    except Exception:
        pass
    return {"ok": True, "client_id": client_id, "secret": result["secret"]}


@app.delete("/api/settings/ldap/clients/provisioned/{client_id}")
def api_revoke_provisioned_client(
    client_id: str,
    claims: dict = require_permission("system_configuration"),
):
    ldap_provisioning.revoke(client_id)
    try:
        ORGDB.record_admin_action(
            extract_actor(claims), "revoke_ldap_client", "settings", client_id,
        )
    except Exception:
        pass
    return {"ok": True, "client_id": client_id}
```
Note on route ordering: define `/provisioned` and `/provisioned/{client_id}/rotate` BEFORE the existing `PATCH/DELETE /api/settings/ldap/clients/{client_id}` (which takes an `int`) — FastAPI matches in definition order and `{client_id}: int` would otherwise 422 on the string path. Since the new routes have a distinct literal `/provisioned` segment, collision is avoided regardless, but keep them grouped.

- [ ] **Step 2: Add rotate test**
```python
def test_api_rotate_returns_new_secret(client):
    client.post("/api/settings/ldap/clients/provisioned", json={"client_id": "rottest"})
    r = client.post("/api/settings/ldap/clients/provisioned/rottest/rotate")
    assert r.status_code == 200 and r.json()["secret"]
    client.delete("/api/settings/ldap/clients/provisioned/rottest")
```

- [ ] **Step 3: Run the full provisioning suite**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py`
Expected: ALL PASS

- [ ] **Step 4: Commit**
```bash
git add src/backend/main.py tests/test_ldap_provisioning.py
git commit -m "feat(api): list/rotate/revoke provisioned LDAP clients"
```

---

## Phase 4 — CLI (dev)

### Task 12: `directoryctl.py ldap-client provision|list|rotate|revoke`

**Files:**
- Modify: `src/cli/directoryctl.py`
- Test: manual (CLI is a thin API client; endpoint behavior is covered by Phase 3 tests)

- [ ] **Step 1: Add a thin API helper + subcommands**

Extend `src/cli/directoryctl.py` — add imports `import json, urllib.request, urllib.error`, an `api()` helper (copied from `tools/dev-seed-uc-user.py:44-70`), and:
```python
def _print(status, body):
    print(json.dumps(body, indent=2) if not isinstance(body, str) else body)
    return 0 if 200 <= status < 300 else 1

def cmd_ldap_client(args):
    if args.action == "provision":
        body = {"client_id": args.client_id}
        if args.label: body["label"] = args.label
        if args.password: body["password"] = args.password
        return _print(*api("POST", "/api/settings/ldap/clients/provisioned", body))
    if args.action == "list":
        return _print(*api("GET", "/api/settings/ldap/clients/provisioned"))
    if args.action == "rotate":
        return _print(*api("POST", f"/api/settings/ldap/clients/provisioned/{args.client_id}/rotate"))
    if args.action == "revoke":
        return _print(*api("DELETE", f"/api/settings/ldap/clients/provisioned/{args.client_id}"))
```
Wire the subparser in `main()`:
```python
    lc = sub.add_parser("ldap-client", help="Provision/manage LDAP client credentials")
    lcsub = lc.add_subparsers(dest="action", required=True)
    p = lcsub.add_parser("provision"); p.add_argument("client_id"); p.add_argument("--label"); p.add_argument("--password")
    lcsub.add_parser("list")
    p = lcsub.add_parser("rotate"); p.add_argument("client_id")
    p = lcsub.add_parser("revoke"); p.add_argument("client_id")
```
And dispatch: `elif args.cmd == "ldap-client": raise SystemExit(cmd_ldap_client(args))`.

- [ ] **Step 2: Manual smoke test**
```bash
cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack
DEV_AUTH_TOKEN=dev-test-token python src/cli/directoryctl.py ldap-client provision clitest --label "cli smoke"
DEV_AUTH_TOKEN=dev-test-token python src/cli/directoryctl.py ldap-client list
DEV_AUTH_TOKEN=dev-test-token python src/cli/directoryctl.py ldap-client rotate clitest
DEV_AUTH_TOKEN=dev-test-token python src/cli/directoryctl.py ldap-client revoke clitest
```
Expected: provision prints a `secret`; list shows `clitest`; rotate prints a new secret; revoke returns `{"ok": true}`.

- [ ] **Step 3: Commit**
```bash
git add src/cli/directoryctl.py
git commit -m "feat(cli): directoryctl ldap-client provision/list/rotate/revoke"
```

---

## Phase 5 — Frontend

### Task 13: Types + query hooks + keys

**Files:**
- Modify: `src/frontend/src/types/ldap-clients.ts`
- Modify: `src/frontend/src/lib/queries/keys.ts` (~line 88-91)
- Modify: `src/frontend/src/lib/queries/ldap-clients.ts`

- [ ] **Step 1: Add types**

Append to `types/ldap-clients.ts`:
```ts
export interface ProvisionedLdapClient {
  id: number;
  client_id: string;
  bind_dn: string;
  label: string | null;
  created_by: string;
  created_at: string;
  last_rotated_at: string | null;
  revoked_at: string | null;
}
export interface ProvisionClientRequest { client_id: string; label?: string; password?: string; }
export interface ProvisionClientResponse {
  ok: boolean;
  client: { client_id: string; bind_dn: string };
  secret: string; // shown once
}
export interface ProvisionedClientsResponse { ok: boolean; clients: ProvisionedLdapClient[]; }
export interface RotateClientResponse { ok: boolean; client_id: string; secret: string; }
```

- [ ] **Step 2: Add query key**

In `keys.ts` after `ldapClients`, add:
```ts
  provisionedClients: () => ['ldap-clients', 'provisioned'] as const,
```

- [ ] **Step 3: Add hooks**

Append to `lib/queries/ldap-clients.ts`:
```ts
export function useProvisionedClients() {
  return useQuery({
    queryKey: queryKeys.provisionedClients(),
    queryFn: () => getApi().get<ProvisionedClientsResponse>('/settings/ldap/clients/provisioned'),
  });
}
export function useProvisionClient() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: ProvisionClientRequest) =>
      getApi().post<ProvisionClientResponse>('/settings/ldap/clients/provisioned', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: queryKeys.ldapClientsRoot }),
  });
}
export function useRotateClient() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (clientId: string) =>
      getApi().post<RotateClientResponse>(`/settings/ldap/clients/provisioned/${clientId}/rotate`),
    onSuccess: () => qc.invalidateQueries({ queryKey: queryKeys.ldapClientsRoot }),
  });
}
export function useRevokeClient() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (clientId: string) =>
      getApi().delete<{ ok: boolean }>(`/settings/ldap/clients/provisioned/${clientId}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: queryKeys.ldapClientsRoot }),
  });
}
```
Add the new types to the existing `import type { ... } from '@/types/ldap-clients'` line.

- [ ] **Step 4: Verify build**

Run: `cd src/frontend && just ui-lint && npx tsc --noEmit`
Expected: no errors.

- [ ] **Step 5: Commit**
```bash
git add src/frontend/src/types/ldap-clients.ts src/frontend/src/lib/queries/keys.ts src/frontend/src/lib/queries/ldap-clients.ts
git commit -m "feat(ui): provisioned LDAP client types + query hooks"
```

---

### Task 14: Provision modal (form + optional password + strength meter + secret-shown-once)

**Files:**
- Create: `src/frontend/src/components/features/ldap-clients/ProvisionClientModal.tsx`
- Create: `src/frontend/src/components/features/ldap-clients/passwordStrength.ts`

- [ ] **Step 1: Strength helper (no dependency)**

Create `passwordStrength.ts`:
```ts
// Lightweight password strength (0-4): length + character classes. No external dep.
export function scorePassword(pw: string): { score: number; label: string } {
  if (!pw) return { score: 0, label: 'Empty' };
  let s = 0;
  if (pw.length >= 12) s++;
  if (pw.length >= 16) s++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
  if (/\d/.test(pw) && /[^A-Za-z0-9]/.test(pw)) s++;
  const labels = ['Very weak', 'Weak', 'Fair', 'Good', 'Strong'];
  return { score: s, label: labels[s] };
}
// Mirrors backend validate_password: >=12 chars, lower+upper+digit.
export function meetsPolicy(pw: string): boolean {
  return pw.length >= 12 && /[a-z]/.test(pw) && /[A-Z]/.test(pw) && /\d/.test(pw);
}
```

- [ ] **Step 2: The modal**

Create `ProvisionClientModal.tsx` (modeled on `AddUserModal.tsx` Dialog + generate/copy, `StepComplete.tsx:161-197` secret panel, `CopyableDN.tsx` copy fallback):
```tsx
import { useState } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
  DialogFooter, DialogClose, Button, Input, Label, Toggle,
} from '@azblink/ui';
import { Check, Copy, Loader2 } from 'lucide-react';
import { toast } from '@/lib/toast';
import { generatePassword } from '@/lib/queries/user-create';
import { useProvisionClient } from '@/lib/queries/ldap-clients';
import { scorePassword, meetsPolicy } from './passwordStrength';

export function ProvisionClientModal({ open, onOpenChange }:
  { open: boolean; onOpenChange: (o: boolean) => void }) {
  const provision = useProvisionClient();
  const [clientId, setClientId] = useState('');
  const [label, setLabel] = useState('');
  const [useOwnPw, setUseOwnPw] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const idValid = /^[a-z0-9][a-z0-9-]{1,30}$/.test(clientId);
  const pwOk = !useOwnPw || meetsPolicy(password);
  const strength = scorePassword(password);

  const reset = () => {
    setClientId(''); setLabel(''); setUseOwnPw(false);
    setPassword(''); setError(null); setSecret(null); setCopied(false);
  };
  const close = () => { reset(); onOpenChange(false); };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    provision.mutate(
      { client_id: clientId, label: label || undefined, password: useOwnPw ? password : undefined },
      {
        onSuccess: (data) => { setSecret(data.secret); toast.success(`Provisioned ${clientId}`); },
        onError: (err: Error) => setError(err.message),
      },
    );
  };

  const copy = async () => {
    if (!secret) return;
    try { await navigator.clipboard.writeText(secret); }
    catch { /* HTTP fallback */
      const ta = document.createElement('textarea'); ta.value = secret;
      document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
    }
    setCopied(true); setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => (o ? onOpenChange(true) : close())}>
      <DialogContent size="md" data-testid="provision-client-modal">
        <DialogHeader>
          <DialogTitle>Provision LDAP client</DialogTitle>
          <DialogDescription>
            Creates a dedicated bind account under ou=clients with read-only directory access.
          </DialogDescription>
        </DialogHeader>

        {secret ? (
          <div className="space-y-3">
            <Label>Client secret (shown once)</Label>
            <div className="flex items-center gap-2">
              <code className="flex-1 select-all rounded bg-[var(--color-surface-2)] px-3 py-2 font-mono text-sm">{secret}</code>
              <Button type="button" variant="outline" size="sm" onClick={copy}
                      leftIcon={copied ? <Check size={14} /> : <Copy size={14} />}>
                {copied ? 'Copied' : 'Copy'}
              </Button>
            </div>
            <p className="text-sm text-[var(--color-warning)]">
              This secret is not stored and cannot be retrieved later. Copy it now.
            </p>
            <DialogFooter><Button onClick={close}>Done</Button></DialogFooter>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            <div>
              <Label htmlFor="cid">Client ID</Label>
              <Input id="cid" value={clientId} onChange={(e) => setClientId(e.target.value.toLowerCase())}
                     placeholder="ped80" autoFocus />
              {clientId && !idValid && (
                <p className="mt-1 text-xs text-[var(--color-error)]">Lowercase letters, digits, hyphens (2-31 chars).</p>
              )}
            </div>
            <div>
              <Label htmlFor="lbl">Label (optional)</Label>
              <Input id="lbl" value={label} onChange={(e) => setLabel(e.target.value)} placeholder="UED PED80 XMPP" />
            </div>
            <div className="flex items-center gap-2">
              <Toggle checked={useOwnPw} onCheckedChange={setUseOwnPw} />
              <span className="text-sm">Set my own password (otherwise a strong one is generated)</span>
            </div>
            {useOwnPw && (
              <div>
                <div className="flex gap-2">
                  <Input type="text" value={password} onChange={(e) => setPassword(e.target.value)}
                         className="font-mono" placeholder="min 12 chars, upper+lower+digit" />
                  <Button type="button" variant="outline" size="sm"
                          onClick={() => setPassword(generatePassword())}>Generate</Button>
                </div>
                <div className="mt-1 text-xs">
                  Strength: <span className={strength.score >= 3 ? 'text-[var(--color-success)]' : 'text-[var(--color-warning)]'}>{strength.label}</span>
                  {password && !meetsPolicy(password) && (
                    <span className="text-[var(--color-error)]"> — must be ≥12 chars with upper, lower, digit</span>
                  )}
                </div>
              </div>
            )}
            {error && <p className="text-sm text-[var(--color-error)]">{error}</p>}
            <DialogFooter>
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit" disabled={!idValid || !pwOk || provision.isPending}>
                {provision.isPending && <Loader2 className="mr-2 animate-spin" size={14} />}
                Provision
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
```
Note: verify the exact import path for `toast` (grep an existing modal, e.g. `AddUserModal.tsx` line ~34 uses `import { toast } from '...'`) and the `Toggle`/`Button` prop names (`onCheckedChange`, `leftIcon`) against `@azblink/ui` — match the versions used in `AddUserModal.tsx`.

- [ ] **Step 3: Verify build**

Run: `cd src/frontend && just ui-lint && npx tsc --noEmit`
Expected: no errors.

- [ ] **Step 4: Commit**
```bash
git add src/frontend/src/components/features/ldap-clients/ProvisionClientModal.tsx src/frontend/src/components/features/ldap-clients/passwordStrength.ts
git commit -m "feat(ui): ProvisionClientModal with optional password + strength + show-once secret"
```

---

### Task 15: Wire into LdapClientsPage — button, provisioned/detected split, rotate/revoke

**Files:**
- Modify: `src/frontend/src/components/features/ldap-clients/LdapClientsPage.tsx`

- [ ] **Step 1: Add state, hooks, and the button**

Near the other hooks (~line 154-159) add:
```tsx
  const provisioned = useProvisionedClients();
  const rotate = useRotateClient();
  const revoke = useRevokeClient();
  const [provisionOpen, setProvisionOpen] = useState(false);
  const [rotatedSecret, setRotatedSecret] = useState<string | null>(null);
```
Import the hooks + `ProvisionClientModal` at the top. In the header button cluster (~line 290-328) add before/after Refresh:
```tsx
        <Button size="sm" leftIcon={<Plus size={14} />} onClick={() => setProvisionOpen(true)}>
          Provision client
        </Button>
```
(Import `Plus` from `lucide-react`.) Render the modal near the end of the returned JSX:
```tsx
      <ProvisionClientModal open={provisionOpen} onOpenChange={setProvisionOpen} />
```

- [ ] **Step 2: Render a "Provisioned clients" section**

Above the existing detected-clients table, add a section listing `provisioned.data?.clients` with rotate/revoke actions (mirror the row-action `<Button variant="ghost">` pattern at lines 708-746):
```tsx
      {(provisioned.data?.clients?.length ?? 0) > 0 && (
        <section className="mb-6">
          <h3 className="mb-2 text-sm font-semibold">Provisioned clients</h3>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Client ID</TableHead><TableHead>Bind DN</TableHead>
                <TableHead>Label</TableHead><TableHead>Created</TableHead><TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {provisioned.data!.clients.map((c) => (
                <TableRow key={c.client_id}>
                  <TableCell className="font-mono">{c.client_id}</TableCell>
                  <TableCell className="font-mono text-xs">{c.bind_dn}</TableCell>
                  <TableCell>{c.label ?? '—'}</TableCell>
                  <TableCell>{new Date(c.created_at).toLocaleDateString()}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" disabled={rotate.isPending}
                      onClick={() => rotate.mutate(c.client_id, {
                        onSuccess: (d) => setRotatedSecret(d.secret),
                      })}>Rotate</Button>
                    <Button variant="ghost" size="sm" disabled={revoke.isPending}
                      onClick={() => { if (confirm(`Revoke ${c.client_id}?`)) revoke.mutate(c.client_id); }}>Revoke</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </section>
      )}
```
For the rotate secret, reuse the same show-once panel — simplest: a tiny inline dialog showing `rotatedSecret` with a copy button and a "Done" that clears it. (Extract the secret panel from `ProvisionClientModal` into a shared `SecretOnce.tsx` if you prefer DRY — optional.)

- [ ] **Step 3: (Optional) badge the detected list**

In the detected table, a row whose `service === 'provisioned_client'` should render a distinct "Provisioned" badge (extend the badge variant map ~lines 67-79). This visually ties a provisioned credential to its observed binds.

- [ ] **Step 4: Verify build + lint + format**

Run: `cd src/frontend && just ui-format && just ui-lint && npx tsc --noEmit`
Expected: no errors. (CI runs diff-scoped eslint + `prettier --check` — format locally before pushing.)

- [ ] **Step 5: Commit**
```bash
git add src/frontend/src/components/features/ldap-clients/LdapClientsPage.tsx
git commit -m "feat(ui): provision button + provisioned clients section (rotate/revoke)"
```

---

## Phase 6 — E2E, docs, governance

### Task 16: End-to-end reconciliation test

**Files:** `tests/test_ldap_provisioning.py`

- [ ] **Step 1: Write the e2e test — provision → bind → appears known in inventory**
```python
import time

def test_e2e_provisioned_bind_shows_known_in_inventory(client):
    cid = "e2einv"
    r = client.post("/api/settings/ldap/clients/provisioned", json={"client_id": cid})
    secret = r.json()["secret"]
    dn = r.json()["client"]["bind_dn"]
    # bind as the client to generate a stats-log BIND the collector will ingest
    import ldap_client
    from ldap3 import Server, Connection
    conn = Connection(Server(ldap_client.LDAP_URI), user=dn, password=secret, auto_bind=True)
    conn.search(ldap_client.LDAP_BASE_DN, "(uid=*)", attributes=["uid"])
    conn.unbind()
    # collector polls ~1s; give it a moment
    time.sleep(3)
    inv = client.get("/api/settings/ldap/clients", params={"include_healthcheck": "false"}).json()
    row = next((c for c in inv["clients"] if c["bind_dn"] == dn), None)
    assert row is not None, "provisioned client bind should appear in inventory"
    assert row["service"] == "provisioned_client"
    assert row["status"] == "acknowledged"
    client.delete(f"/api/settings/ldap/clients/provisioned/{cid}")
```

- [ ] **Step 2: Run the full suite**

Run: `cd deploy/dev && just test-quick tests/test_ldap_provisioning.py -v`
Expected: ALL PASS. If the timing assertion flakes, poll in a loop up to ~8s instead of a fixed sleep.

- [ ] **Step 3: Commit**
```bash
git add tests/test_ldap_provisioning.py
git commit -m "test(ldap): e2e provisioned bind reconciles as known in inventory"
```

---

### Task 17: Docs + governance trailer

**Files:**
- Modify: `CLAUDE.md` (Key Environment Variables — add `LDAP_CLIENTS_OU`)
- Modify: `docs/architecture/spec/*` per SOP (whichever section covers LDAP/inventory) — bump `spec-meta.version`

- [ ] **Step 1: Document the env var in CLAUDE.md**

Under "Key Environment Variables" → LDAP block, add:
```bash
LDAP_CLIENTS_OU=ou=clients,dc=azblink,dc=com   # provisioned client accounts subtree
```

- [ ] **Step 2: Update the architecture spec**

Add a short subsection to the LDAP/inventory spec section describing provisioning (ou=clients, static ACL, reconciliation) and bump `spec-meta.version` per `docs/architecture/SOP.md`. Decide whether this warrants an ARD-001 amendment (the single-LDAP record) or a `Spec-Patch:` — the reconciliation + ou=clients is arguably decisional → lean ARD amendment.

- [ ] **Step 3: Commit with the architecture trailer**
```bash
git add CLAUDE.md docs/architecture/
git commit -m "docs(arch): document LDAP client provisioning (ou=clients + static ACL)

Spec-Patch: <section-number>"
```
(Use `ARD:` if you file an ARD-001 amendment instead; run `just arch-guard` to check.)

---

## Self-Review notes (author)

- **Spec coverage:** §1 LDAP layer → Tasks 1-3; §2 backend → Tasks 4-7; §3 CLI → Task 12; §4 FE → Tasks 13-15; §5 security (admin guard, show-once, read-minus-secrets, audit) → Tasks 7-11 (audit in each endpoint); §6 tests → Tasks 3,4,5,6,7,8,9,16; §7 governance → Task 17. All covered.
- **Migration number:** 029 (028 taken) — spec updated to match.
- **Type/name consistency:** `provisioned_client` service string used identically in classify (Task 5), upsert (Task 6), e2e (Task 16), FE badge (Task 15). `client_id` slug regex `^[a-z0-9][a-z0-9-]{1,30}$` identical in `ldap_provisioning.validate_client_id` (Task 7), Pydantic validator (Task 8), FE `idValid` (Task 14). Endpoint paths identical across Tasks 8-12.
- **Known risk to verify during execution:** ldap3 `Connection.rebind` semantics in Task 7's test — prefer a fresh `Connection(..., auto_bind=True)` and assert `.bound`; consult ldap3 docs if the bind-verification assertions misbehave.
- **ACL bootstrap caveat:** the ldif (Task 2) only auto-applies on fresh volumes / `just reset`; running stacks need the manual `ldapmodify -Y EXTERNAL` (documented in the ldif header). Note this in the eventual PR description for operators upgrading in place.
