# web-configure Skill Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Create a Claude Code skill that discovers, configures, and verifies settings on remote web admin panels, producing portable YAML playbooks for replay.

**Architecture:** Standalone skill in `.claude/skills/web-configure/` using a 3-layer approach: curl for reliable discovery and form submission, gstack /browse for visual evidence, curl validation for confirmation. Playbooks stored at `playbooks/web-configure/` as portable YAML artifacts.

**Tech Stack:** Claude Code SKILL.md, gstack /browse, curl, YAML, Bash

**Spec:** `docs/superpowers/specs/2026-04-10-web-configure-design.md`

---

## File Structure

| File | Responsibility |
|------|---------------|
| `.claude/skills/web-configure/SKILL.md` | Skill definition — workflow logic, phase structure (~300 lines) |
| `.claude/skills/web-configure/references/browse-patterns.md` | Browse batching rules, CI=1 workaround, cookie bridge pattern (~150 lines) |
| `playbooks/web-configure/.gitkeep` | Playbook storage directory (committed empty) |
| `playbooks/web-configure/screenshots/.gitkeep` | Screenshot storage directory (committed empty) |
| `playbooks/web-configure/templates/playbook.yml` | Annotated playbook template with all fields documented |
| `playbooks/web-configure/azblink-server-ldap-client.yml` | Reference playbook from today's session (real, tested data) |
| `.claude/skills/web-configure/references/browse-patterns.md` | Browse batching rules, CI=1 workaround, cookie bridge, iframe nav |
| `.claude/skills-manifest.json` | Modify: register web-configure skill |
| `.gitignore` | Modify: add `playbooks/web-configure/screenshots/**/*.png` |

---

## Parallelism Guide

Tasks 1, 2, 3 are **fully independent** — dispatch as parallel subagents.
Tasks 4-8 are **sequential** — each appends to SKILL.md.
Task 9 is **independent** of 4-8 — can run in parallel with them.
Task 10 depends on **all prior tasks** — run last.

---

### Task 1: Create Directory Structure and Gitignore

**Files:**
- Create: `playbooks/web-configure/.gitkeep`
- Create: `playbooks/web-configure/screenshots/.gitkeep`
- Modify: `.gitignore`

- [ ] **Step 1: Create playbook directories**

```bash
mkdir -p playbooks/web-configure/screenshots
touch playbooks/web-configure/.gitkeep
touch playbooks/web-configure/screenshots/.gitkeep
```

- [ ] **Step 2: Add screenshot gitignore rule**

Add to `.gitignore`:

```
# web-configure playbook screenshots (large binary evidence)
playbooks/web-configure/screenshots/**/*.png
```

- [ ] **Step 3: Verify structure**

```bash
find playbooks/ -type f
# Expected:
# playbooks/web-configure/.gitkeep
# playbooks/web-configure/screenshots/.gitkeep
```

- [ ] **Step 4: Commit**

```bash
git add playbooks/web-configure/.gitkeep playbooks/web-configure/screenshots/.gitkeep .gitignore
git commit -m "chore: add web-configure playbook directory structure"
```

---

### Task 2: Create Playbook Template

**Files:**
- Create: `playbooks/web-configure/templates/playbook.yml`

This is the annotated reference template that documents every field in the playbook schema. The skill will reference it, and users can copy it to bootstrap new playbooks manually.

- [ ] **Step 1: Create template directory**

```bash
mkdir -p playbooks/web-configure/templates
```

- [ ] **Step 2: Write the playbook template**

Create `playbooks/web-configure/templates/playbook.yml` with the full annotated schema from the design spec. Every field must have a YAML comment explaining its purpose, allowed values, and defaults.

The template must include:
- `schemaVersion: "1.0"`
- `target` section with `baseUrl` (supports `${VAR}`), `description`, `type`, `tlsVerify`
- `variables` section with `description`, `default`, `secret`, `pattern` fields
- All 5 phases: `auth`, `navigate`, `discover`, `configure`, `verify`
- Each phase with both `curl` and `browse` layers
- `auth.curl` with `contentType`, `followRedirects`, `extract.cookies` (array), `timeout`, `retries`
- `configure.operations` as ordered array of named operations
- `verify.curl` assertions using `bodyContains`, `valuePattern`, `bodyRegex` (no CSS selectors)
- `verify.command` for shell command verification
- `verify.delay` field
- `discover.fingerprint` section with `fieldIds`, `actionUrls`, `submitMechanisms`, `formCount`
- `runs` array with `timestamp`, `mode`, `duration`, `result`, `fingerprint`, `variables`, `screenshots`, `assertions`
- Security: comment on secret defaults rejection, cookie non-persistence

- [ ] **Step 3: Validate YAML**

```bash
python3 -c "import yaml; yaml.safe_load(open('playbooks/web-configure/templates/playbook.yml')); print('VALID')"
```

Expected: `VALID`

- [ ] **Step 4: Commit**

```bash
git add playbooks/web-configure/templates/playbook.yml
git commit -m "docs: add web-configure playbook template with annotated schema"
```

---

### Task 3: Create Reference Playbook from Today's Session

**Files:**
- Create: `playbooks/web-configure/azblink-server-ldap-client.yml`

Convert the raw investigation data from `qa/patrol/issues/2026-04-10-azblink-server-ldap-client-navigation-route.yml` into a proper web-configure playbook. This is real, tested data from today's session — not a template.

- [ ] **Step 1: Write the reference playbook**

Create `playbooks/web-configure/azblink-server-ldap-client.yml` with:

**target:**
- `baseUrl: "${SERVER_URL}"` (default: `http://192.168.122.220:8082`)
- `type: server-rendered`
- `tlsVerify: false` (legacy HTTP-only panel)

**variables:**
- `SERVER_URL`: description "Azblink Server base URL", default `http://192.168.122.220:8082`
- `ADMIN_USER`: description "System admin login", default `admin`
- `ADMIN_PASS`: description "System admin password", secret true (NO default)
- `LDAP_HOST`: description "LDAP server host:port"
- `LDAP_BASE_DN`: description "LDAP base DN"
- `LDAP_BIND_DN`: description "LDAP bind DN"
- `LDAP_BIND_PW`: description "LDAP bind password", secret true

**phases.auth:**
- curl: POST to `/apps/login.php?item=admin`, data `action=UserLogin&active=true&loginid=${ADMIN_USER}&loginpasswd=${ADMIN_PASS}&authimage=&select=en_us`
- extract.cookies: `["PHPSESSID"]`
- followRedirects: false
- expect.status: 302, expect.redirectContains: `item=systema`
- notes: "CAPTCHA field exists but is not server-validated"

**phases.navigate:**
- hint: `["System", "User", "AD / LDAP"]`
- curl.chain: fetch `/apps/index.php?item=systema&action=aSystem` then `/apps/index.php?item=systema&action=aSystemAdLdapUserAuth`
- expect.contains: "Use LDAP Client for Authentication"

**phases.discover:**
- pageUrl: `/apps/index.php?item=systema&action=aSystemAdLdapUserAuth`
- fingerprint.fieldIds: `[dirServiceLDAP, uri, base, binddn, bindpw, anonymous]`
- fingerprint.actionUrls: `["/apps/index.php?item=systema"]`
- fingerprint.submitMechanisms: `["js:saveDirectory()"]`
- fingerprint.formCount: 3
- forms[0]: id `formDirectory`, submitMechanism `js:saveDirectory()`, ajaxEndpoint POST `/apps/index.php?item=systema`
- fields: dirServiceLDAP (checkbox, enabler), uri (text, "Host"), base (text, "Base DN"), binddn (text, "Username"), bindpw (password, "Password"), anonymous (checkbox, "Anonymous")
- hiddenFields: action=aSystemAdLdapUserAuth, active=save, dir_service=ldap

**phases.configure:**
- operations[0]: name "configureLdapClient"
  - curl POST to `/apps/index.php?item=systema`
  - data: action, active, dir_service, uri=${LDAP_HOST}, base=${LDAP_BASE_DN}, binddn=${LDAP_BIND_DN}, bindpw=${LDAP_BIND_PW}
  - expect.body: "1"
- browse steps: screenshot before, snapshot -i, fill fields, dialogAccept, click Submit, wait 3, screenshot after

**phases.verify:**
- delay: 0
- curl[0]: re-read page, assertions using valuePattern for uri, base, binddn
- curl[1]: LDAP search smoke test POST, assertion bodyContains "uid:"
- command[0]: optional ldapsearch CLI check

**runs:** One entry from today's session (2026-04-10), mode discover+configure, result verified, 55 LDAP users found.

- [ ] **Step 2: Validate YAML**

```bash
python3 -c "import yaml; yaml.safe_load(open('playbooks/web-configure/azblink-server-ldap-client.yml')); print('VALID')"
```

Expected: `VALID`

- [ ] **Step 3: Verify no secret defaults**

```bash
python3 -c "
import yaml
pb = yaml.safe_load(open('playbooks/web-configure/azblink-server-ldap-client.yml'))
for name, var in pb.get('variables', {}).items():
    if var.get('secret') and var.get('default'):
        print(f'VIOLATION: {name} is secret with default')
        exit(1)
print('OK: no secret variables have defaults')
"
```

Expected: `OK: no secret variables have defaults`

- [ ] **Step 4: Commit**

```bash
git add playbooks/web-configure/azblink-server-ldap-client.yml
git commit -m "feat: add reference playbook for Azblink Server LDAP client config"
```

---

### Task 4: Write the SKILL.md — Setup and Entry Point

**Files:**
- Create: `.claude/skills/web-configure/SKILL.md`

This is the core skill file. Due to its size (~400 lines), it will be built across Tasks 4-8, with each task adding a section and committing.

- [ ] **Step 1: Create skill directory**

```bash
mkdir -p .claude/skills/web-configure
```

- [ ] **Step 2: Write frontmatter and setup section**

Create `.claude/skills/web-configure/SKILL.md` with:

```markdown
---
name: web-configure
version: 1.0.0
description: |
  Discover, configure, and verify settings on remote web admin panels.
  Produces portable YAML playbooks for replay. Uses curl for reliable
  operations and gstack /browse for visual evidence.
  Use this skill whenever the user wants to configure a remote web app,
  set up LDAP/DNS/network/service settings on an admin panel, replay a
  saved configuration playbook, or automate web form submission. Triggers
  on: "configure the X on this server", "set up LDAP client", "replay
  playbook", "web-configure", "admin panel config", "headless configuration",
  or any request to fill in forms on a remote web UI and verify the result.
  NOT for SPAs (React/Vue/Angular), OAuth login flows, or file uploads.
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
  - Grep
---

# web-configure: Headless Web App Configuration

Configure remote web admin panels and produce replayable YAML playbooks.

## 1. Setup

```bash
mkdir -p playbooks/web-configure/screenshots
```

Check for gstack /browse availability:

```bash
_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
B=""
[ -n "$_ROOT" ] && [ -x "$_ROOT/.claude/skills/gstack/browse/dist/browse" ] && B="$_ROOT/.claude/skills/gstack/browse/dist/browse"
[ -z "$B" ] && B=~/.claude/skills/gstack/browse/dist/browse
if [ -x "$B" ]; then
  echo "BROWSER_READY"
else
  echo "BROWSER_NOT_AVAILABLE"
fi
```

If `BROWSER_NOT_AVAILABLE`: warn "gstack /browse not available. Skill will run in curl-only mode (no screenshots)." Set `BROWSE_AVAILABLE=false` for the session.

If `BROWSER_READY`: set `BROWSE_AVAILABLE=true`. All browse commands use `CI=1 $B` prefix.
```

- [ ] **Step 3: Write entry point and playbook resolution section**

Append to SKILL.md:

```markdown
## 2. Parse Input

Extract from the user's request:
1. `url` — base URL of the target web app (required)
2. `objective` — what to configure (required, freeform)
3. `navigation_hint` — breadcrumb path (optional, e.g., "System > User > AD/LDAP")
4. `playbook_id` — existing playbook ID (optional, for replay)
5. `--replay` flag — force replay mode

## 3. Playbook Resolution

Search `playbooks/web-configure/*.yml` for a matching playbook:

```bash
grep -l "<baseUrl>" playbooks/web-configure/*.yml 2>/dev/null
```

For each candidate, check if `phases.navigate.hint` matches the user's navigation hint.

**Decision tree:**
- Match found + `--replay` flag → **Replay mode**
- Match found, no flag → Ask: "Found existing playbook '<id>'. Replay it, or rediscover?"
- No match → **Discover + Configure mode**

## 4. Variable Resolution

Read `variables` from the playbook (replay) or build from user input (discover).

For each variable:
1. Check env var: `echo "${VAR_NAME:-__UNSET__}"`
2. Check `--var` flag: if user passed `--var VAR_NAME=value`, use that value
3. If still unset and has `default` → use default
4. If still unset and no default → ask user (use AskUserQuestion for non-secrets, prompt for secrets)

**Validation:** If a variable has `pattern`, validate the resolved value against it. Stop if invalid.

**Security gate:** If any variable has `secret: true` AND `default` is set in the playbook, reject: "Secret variable '<name>' has a default value. Remove the default from the playbook."

**Example invocation:**
```
User: "Configure the LDAP client on the admin panel at http://192.168.122.220:8082,
       it's under System > User > AD/LDAP"
Result: Discovers page, configures LDAP, saves playbook at
        playbooks/web-configure/ldap-client.yml with 3 screenshots,
        all verification assertions passed.
```
```

- [ ] **Step 4: Commit**

```bash
git add .claude/skills/web-configure/SKILL.md
git commit -m "feat(web-configure): add skill setup, entry point, and variable resolution"
```

---

### Task 5: Write the SKILL.md — Auth and Navigate Phases

**Files:**
- Modify: `.claude/skills/web-configure/SKILL.md`

- [ ] **Step 1: Write auth phase**

Append to SKILL.md:

```markdown
## 5. Phase: Auth

Authenticate to the target web app and acquire session cookies.

### curl layer

**TLS handling:** If `target.tlsVerify` is `false`, add `-k` to ALL curl commands in this and subsequent phases. Log: "Warning: TLS verification disabled for this target."

```bash
# Build curl TLS flag
TLS_FLAG=""
# If target.tlsVerify is false:
TLS_FLAG="-k"

# Extract cookies without following redirects
COOKIES=$(curl -s $TLS_FLAG -D - -o /tmp/wc-auth-body.txt \
  -d "<url-encoded form data with ${VAR} substituted>" \
  "${BASE_URL}<auth_url>" | grep -i 'Set-Cookie:')

# Parse each cookie name from extract.cookies list
PHPSESSID=$(echo "$COOKIES" | grep -oP 'PHPSESSID=\K[^;]+')
# ... repeat for each cookie in extract.cookies array

# Check redirect
REDIRECT=$(curl -s -D - -o /dev/null \
  -d "<form data>" \
  "${BASE_URL}<auth_url>" 2>&1 | grep -i 'Location:')
```

Verify: redirect location contains the expected string from `expect.redirectContains`.

If auth fails (no redirect, wrong status): Stop. Report "Auth failed. Check credentials in variables."

### browse layer (if BROWSE_AVAILABLE)

All browse commands for auth MUST be in a single Bash call:

```bash
B=<browse binary>
CI=1 $B goto "${BASE_URL}<login_url>"
CI=1 $B snapshot -i
CI=1 $B fill @eN "<username>"
CI=1 $B fill @eN "<password>"
CI=1 $B click "Sign In"
sleep 2
CI=1 $B url
```

### Cookie bridge

For all subsequent browse commands, inject cookies acquired by curl:

```bash
CI=1 $B cookie "<COOKIE_NAME>=<COOKIE_VALUE>"
```

This is done at the start of each browse batch (since the server may restart between Bash calls).
```

- [ ] **Step 2: Write navigate phase**

Append to SKILL.md:

```markdown
## 6. Phase: Navigate

Follow the navigation hint from root to target page.

### curl layer

For each URL in `navigate.curl.chain`:

```bash
PAGE=$(curl -s -b "PHPSESSID=$COOKIE" "${BASE_URL}<url>")
```

At each step, verify the expected content is present:
- `expect.contains` → check if the string appears in `$PAGE`
- `extract.links` → use grep to list all `<a href="...">` tags (for debugging if hint fails)

If the target page contains the expected content: navigation succeeded. Record the final URL.

### Fallback escalation

If curl cannot find expected content at the target URL:
1. List all links found on the page
2. Ask user: "Navigation hint didn't match. Available links: [list]. Which one leads to the target?"
3. If user provides a link, follow it and retry
4. If still stuck and BROWSE_AVAILABLE: offer browse handoff

### browse layer (if BROWSE_AVAILABLE, same Bash call pattern)

```bash
B=<browse binary>
CI=1 $B goto "${BASE_URL}<first_url>"
CI=1 $B cookie "PHPSESSID=$COOKIE"
CI=1 $B goto "${BASE_URL}<target_url>"
CI=1 $B snapshot -i
# If frameset app: CI=1 $B frame "<selector>"
```
```

- [ ] **Step 3: Commit**

```bash
git add .claude/skills/web-configure/SKILL.md
git commit -m "feat(web-configure): add auth and navigate phase instructions"
```

---

### Task 6: Write the SKILL.md — Discover and Configure Phases

**Files:**
- Modify: `.claude/skills/web-configure/SKILL.md`

- [ ] **Step 1: Write discover phase**

Append to SKILL.md:

```markdown
## 7. Phase: Discover (first run only)

Map the form structure on the target page. Skip this phase on replay.

### curl layer

Fetch the target page:

```bash
PAGE=$(curl -s -b "PHPSESSID=$COOKIE" "${BASE_URL}<pageUrl>")
```

From the HTML response, extract:
1. All `<form>` elements — count them, note their `id`/`name` and `action` attributes
2. All `<input>`, `<select>`, `<textarea>` within each form — note `id`, `name`, `type`, `value`
3. Hidden fields — `<input type="hidden">`
4. Submit mechanism — look for `onclick` handlers, `$.ajax` calls, `<input type="submit">`

Build the `discover.forms` and `discover.fingerprint` sections for the playbook.

### Staleness check (replay only)

On replay, instead of full discovery, do a lightweight fingerprint check:

```bash
PAGE=$(curl -s -b "PHPSESSID=$COOKIE" "${BASE_URL}<pageUrl>")
```

For each field ID in `discover.fingerprint.fieldIds`:
```bash
echo "$PAGE" | grep -c 'id="<fieldId>"'
```

Count matches. Calculate match rate = `(found / expected) * 100`.

| Match | Action |
|-------|--------|
| 100% | Continue replay |
| 70-99% | Warn user, show missing fields, trigger rediscovery flow below |
| <70% | Stop. "Page structure changed significantly. Run with --rediscover." |

### Rediscovery flow (when staleness detected or user requests --rediscover)

1. Re-run the discover phase with curl (fetch page, parse forms)
2. Diff the new form map against the stored `discover.forms`:
   - List fields added, removed, or renamed
   - List action URL changes
   - List submit mechanism changes
3. Show the user what changed:
   "Field #uri renamed to #ldap_host. Field #anonymous removed. New field #tls_enabled added."
4. Ask: "Update playbook with new structure, or abort?"
5. If update:
   - Rewrite `discover` phase with new form map and fingerprint
   - Rewrite `configure` phase with new field selectors/names
   - Preserve `auth`, `navigate`, `variables`, and `runs` unchanged
   - Set playbook status to `draft` until next successful verify
6. Run configure + verify with the updated structure
7. If verify passes, set status back to `verified`
```

- [ ] **Step 2: Write configure phase**

Append to SKILL.md:

```markdown
## 8. Phase: Configure

Execute named operations to apply the configuration.

### curl layer

For each operation in `configure.operations` (in order):

```bash
RESULT=$(curl -s -b "PHPSESSID=$COOKIE" \
  -H "X-Requested-With: XMLHttpRequest" \
  -d "<url-encoded data with ${VAR} substituted>" \
  "${BASE_URL}<operation_url>")
```

Notes on content type:
- `contentType: form` (default) → `-d` flag, `application/x-www-form-urlencoded`
- `contentType: json` → `-H "Content-Type: application/json" -d '<json>'`
- `contentType: multipart` → `-F` flags

Notes on submit mechanism:
- `ajax-post`, `ajax-json`, `js-function` → add `-H "X-Requested-With: XMLHttpRequest"`
- `standard-post` → use `-L` to follow redirect

Check response against `expect`:
- `expect.body: "1"` → `[ "$RESULT" = "1" ]`
- `expect.status: 200` → check HTTP status code

If any operation fails: Stop. Report "Operation '<name>' failed. Response: <body>."

### browse layer (if BROWSE_AVAILABLE)

All browse commands for configure phase in a single Bash call:

```bash
B=<browse binary>
COOKIE="<session cookie>"

# Navigate and inject cookie
CI=1 $B goto "${BASE_URL}<login_url>"
CI=1 $B cookie "PHPSESSID=$COOKIE"
CI=1 $B goto "${BASE_URL}<target_page>"

# Before screenshot
CI=1 $B screenshot "playbooks/web-configure/screenshots/<id>/<date>-before.png"

# Fill fields
CI=1 $B snapshot -i
CI=1 $B fill @eN "<value>"   # for each field
# ... repeat for all fields

# Submit
CI=1 $B dialog-accept
CI=1 $B click "Submit"
sleep 3

# After screenshot
CI=1 $B screenshot "playbooks/web-configure/screenshots/<id>/<date>-after.png"
```

Show screenshots to the user with the Read tool after capturing them.
```

- [ ] **Step 3: Commit**

```bash
git add .claude/skills/web-configure/SKILL.md
git commit -m "feat(web-configure): add discover and configure phase instructions"
```

---

### Task 7: Write the SKILL.md — Verify Phase and Playbook Save

**Files:**
- Modify: `.claude/skills/web-configure/SKILL.md`

- [ ] **Step 1: Write verify phase**

Append to SKILL.md:

```markdown
## 9. Phase: Verify

Confirm the configuration persisted and works.

### Delay

If `verify.delay` is set and > 0:
```bash
sleep <delay>
```

### curl layer

For each assertion in `verify.curl`:

**bodyContains:**
```bash
PAGE=$(curl -s -b "PHPSESSID=$COOKIE" "${BASE_URL}<url>")
echo "$PAGE" | grep -q "<expected text>" && echo "PASS" || echo "FAIL"
```

**valuePattern:**
```bash
echo "$PAGE" | grep -q 'value="<expected value>"' && echo "PASS" || echo "FAIL"
```

**bodyRegex:**
```bash
echo "$PAGE" | grep -qP '<pattern>' && echo "PASS" || echo "FAIL"
```

For HTTP smoke tests (e.g., LDAP search):
```bash
RESULT=$(curl -s -b "PHPSESSID=$COOKIE" \
  -d "<post data>" \
  "${BASE_URL}<url>")
echo "$RESULT" | grep -q "<expected>" && echo "PASS" || echo "FAIL"
```

### Shell command verification

For each entry in `verify.command`:
```bash
OUTPUT=$(<command with ${VAR} substituted> 2>&1)
echo "$OUTPUT" | grep -q "<expected>" && echo "PASS" || echo "FAIL"
```

### browse layer (if BROWSE_AVAILABLE)

Single Bash call:
```bash
B=<browse binary>
CI=1 $B goto "${BASE_URL}<login_url>"
CI=1 $B cookie "PHPSESSID=$COOKIE"
CI=1 $B goto "${BASE_URL}<target_page>"
CI=1 $B screenshot "playbooks/web-configure/screenshots/<id>/<date>-verified.png"
```

### Result

If all assertions pass: status = `verified`.
If any assertion fails: status = `failed`. Stop. Show expected vs actual for each assertion.
```

- [ ] **Step 2: Write playbook save section**

Append to SKILL.md:

```markdown
## 10. Save Playbook

### First run (discover + configure)

Write the new playbook to `playbooks/web-configure/<id>.yml` using the Write tool.

The playbook ID is derived from the objective:
1. Take first 5 words of objective
2. Lowercase, replace non-alphanumeric with hyphens, collapse multiples
3. Check for collision in `playbooks/web-configure/`, append `-2` if needed

Include all phases with both curl and browse data collected during the run.

Add the first entry to `runs`:
```yaml
runs:
  - timestamp: "<ISO 8601 now>"
    mode: "discover+configure"
    duration: <elapsed seconds>
    result: "<verified or failed>"
    fingerprint: { match: "100%", fieldsChecked: N, fieldsMissing: 0 }
    variables:
      # non-secret values only, secrets show "***"
    screenshots:
      before: "<relative path or null>"
      after: "<relative path or null>"
      verified: "<relative path or null>"
    assertions:
      - { check: "<description>", expected: "<val>", actual: "<val>", pass: true }
```

### Replay

Read the existing playbook, append a new entry to `runs`, update `lastRun` and `status`.

### Validate

```bash
python3 -c "import yaml; yaml.safe_load(open('playbooks/web-configure/<id>.yml')); print('VALID')"
```

If invalid: fix YAML, re-write, re-validate. Max 2 retries.
```

- [ ] **Step 3: Commit**

```bash
git add .claude/skills/web-configure/SKILL.md
git commit -m "feat(web-configure): add verify phase and playbook save logic"
```

---

### Task 8: Write the SKILL.md — Output Summary and Error Handling

**Files:**
- Modify: `.claude/skills/web-configure/SKILL.md`

- [ ] **Step 1: Write output summary section**

Append to SKILL.md:

```markdown
## 11. Output Summary

Print a clear summary after execution:

```
## Web Configure Complete

**Playbook:** <playbook-id>
**Mode:** discover+configure (or replay)
**Target:** <baseUrl>
**Status:** verified (or failed at phase X)

**Phases:**
  ✓ auth      — session acquired (<cookie count> cookies)
  ✓ navigate  — reached <page title>
  ✓ discover  — mapped <N> forms, <N> fields
  ✓ configure — <N> operations completed
  ✓ verify    — <N>/<N> assertions passed

**Screenshots:**
  - before:   playbooks/web-configure/screenshots/.../before.png
  - after:    playbooks/web-configure/screenshots/.../after.png
  - verified: playbooks/web-configure/screenshots/.../verified.png

**Replay command:**
  /web-configure <url> --replay --playbook <id>
```

If any phase failed, show the failure details inline under that phase.

## 12. Error Handling

| Situation | Action |
|-----------|--------|
| curl auth fails (non-302) | Stop. "Auth failed. Check credentials." |
| curl timeout | Retry up to `retries` count, then fail |
| curl 200-with-error-body | Not retryable. Stop and report. |
| Navigation hint no match | List available links, ask user |
| Navigation still stuck | Browse handoff for user to point to page |
| Form field ID missing on replay | Flag playbook `stale`, offer rediscovery |
| Browse crash / non-zero exit | Continue curl-only. Note "Browse unavailable" |
| AJAX returns failure | Stop at configure. "Save failed." |
| Verify assertions fail | Stop. Show expected vs actual per field |
| Secret variable has default | Reject playbook at load. "Secret vars must not have defaults." |
| 3 consecutive browse fails | Set browseDisabled, skip browse for remaining phases |

**Browse fail definition:** browse command returns non-zero exit code or produces no output. Counter is global across the run.

## 13. Browse Integration

Before executing any browse commands, read `references/browse-patterns.md` for:
- Browse server setup and binary resolution
- The batching rule (all commands in single Bash call)
- CI=1 sandbox workaround for Ubuntu 24.04+
- Cookie bridge pattern
- Iframe navigation with `$B frame`
- Screenshot capture and error handling
```

In addition to the SKILL.md content above, create `references/browse-patterns.md` with the following content:

```markdown
# Browse Patterns for web-configure

## Server Setup

```bash
_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
B=""
[ -n "$_ROOT" ] && [ -x "$_ROOT/.claude/skills/gstack/browse/dist/browse" ] && B="$_ROOT/.claude/skills/gstack/browse/dist/browse"
[ -z "$B" ] && B=~/.claude/skills/gstack/browse/dist/browse
if [ -x "$B" ]; then
  echo "BROWSER_READY"
else
  echo "BROWSER_NOT_AVAILABLE"
fi
```

## Batching Rule

The gstack /browse server auto-terminates when its parent shell exits. In Claude Code, each Bash tool call is a separate process.

**ALL browse commands for a phase MUST be in a SINGLE Bash tool call.** Never split commands across tool calls.

## CI=1 Sandbox Workaround

Ubuntu 24.04+ restricts Chromium sandbox via AppArmor (`kernel.apparmor_restrict_unprivileged_userns=1`). Prefix all browse commands with `CI=1`:

```bash
CI=1 $B goto <url>
CI=1 $B snapshot -i
```

## Cookie Bridge Pattern

Inject curl-acquired session cookies into browse:

```bash
B=<browse binary>
COOKIE="<session cookie from curl>"
CI=1 $B goto "${BASE_URL}<login_page>"
CI=1 $B cookie "<COOKIE_NAME>=$COOKIE"
CI=1 $B goto "${BASE_URL}<target_page>"
```

Repeat cookie injection at the start of each browse batch (since the server restarts between Bash calls).

## Iframe Navigation

For frameset-based apps, enter the iframe context before interacting:

```bash
CI=1 $B frame "<selector or index>"
CI=1 $B snapshot -i
```

Use `CI=1 $B frame main` to return to the top-level context.

## Error Handling

If a browse command returns non-zero or empty output, increment the global browse fail counter. After 3 consecutive fails, set `browseDisabled=true` and skip all remaining browse commands.
```
```

- [ ] **Step 2: Commit**

```bash
git add .claude/skills/web-configure/SKILL.md
git commit -m "feat(web-configure): add output summary, error handling, browse batching rules"
```

---

### Task 9: Register in Skills Manifest

**Files:**
- Modify: `.claude/skills-manifest.json`

- [ ] **Step 1: Add web-configure to manifest**

Read `.claude/skills-manifest.json` and add the `web-configure` entry following the existing pattern:

```json
"web-configure": {
  "type": "standalone",
  "installed_at": "<ISO 8601 now>",
  "verified_at": "<ISO 8601 now>",
  "dependencies": {
    "system": {},
    "skills": {}
  }
}
```

- [ ] **Step 2: Validate JSON**

```bash
python3 -c "import json; json.load(open('.claude/skills-manifest.json')); print('VALID')"
```

Expected: `VALID`

- [ ] **Step 3: Commit**

```bash
git add .claude/skills-manifest.json
git commit -m "chore: register web-configure in skills manifest"
```

---

### Task 10: Smoke Test — Dry Run the Skill

**Files:** None (read-only verification)

This task verifies the skill works end-to-end by doing a manual dry run of each phase against the Azblink Server using the reference playbook values.

- [ ] **Step 1: Verify skill file is loadable**

```bash
head -20 .claude/skills/web-configure/SKILL.md
# Expected: frontmatter with name: web-configure, version: 1.0.0
```

- [ ] **Step 2: Test auth phase with curl**

Use values from the reference playbook variables. Prompt for ADMIN_PASS (secret) at runtime — do not hardcode.

```bash
# Read non-secret defaults from playbook
BASE_URL="http://192.168.122.220:8082"
ADMIN_USER="admin"
# ADMIN_PASS must be provided at runtime — never hardcode in plan or test files

COOKIES=$(curl -s -D - -o /dev/null \
  -d "action=UserLogin&active=true&loginid=${ADMIN_USER}&loginpasswd=${ADMIN_PASS}&authimage=&select=en_us" \
  "${BASE_URL}/apps/login.php?item=admin")
echo "$COOKIES" | grep -i 'Set-Cookie.*PHPSESSID'
echo "$COOKIES" | grep -i 'Location.*systema'
```

Expected: PHPSESSID cookie set, redirect to systema page.

- [ ] **Step 3: Test navigate phase with curl**

```bash
COOKIE=$(echo "$COOKIES" | grep -oP 'PHPSESSID=\K[^;]+')
PAGE=$(curl -s -b "PHPSESSID=$COOKIE" \
  "http://192.168.122.220:8082/apps/index.php?item=systema&action=aSystemAdLdapUserAuth")
echo "$PAGE" | grep -c "Use LDAP Client for Authentication"
```

Expected: `1` (string found on page)

- [ ] **Step 4: Test staleness fingerprint check**

```bash
for FIELD in dirServiceLDAP uri base binddn bindpw anonymous; do
  COUNT=$(echo "$PAGE" | grep -c "id=\"$FIELD\"")
  echo "$FIELD: $COUNT"
done
```

Expected: all fields show `1` (100% match).

- [ ] **Step 5: Test verify assertions**

```bash
echo "$PAGE" | grep -q 'value="192.168.4.111:1390"' && echo "uri: PASS" || echo "uri: FAIL"
echo "$PAGE" | grep -q 'value="dc=azblink,dc=com"' && echo "base: PASS" || echo "base: FAIL"
echo "$PAGE" | grep -q 'value="cn=admin,dc=azblink,dc=com"' && echo "binddn: PASS" || echo "binddn: FAIL"
```

Expected: all PASS (values from today's configuration session).

- [ ] **Step 6: Test reference playbook loads**

```bash
python3 -c "
import yaml
pb = yaml.safe_load(open('playbooks/web-configure/azblink-server-ldap-client.yml'))
print(f'Playbook: {pb[\"id\"]}')
print(f'Phases: {list(pb[\"phases\"].keys())}')
print(f'Variables: {list(pb[\"variables\"].keys())}')
for name, var in pb['variables'].items():
    if var.get('secret') and var.get('default'):
        print(f'VIOLATION: {name}')
        exit(1)
print('Security check: PASS')
"
```

Expected: playbook loads, lists phases and variables, security check passes.

- [ ] **Step 7: Document smoke test results and commit any fixes**

If any step failed, fix the relevant file and re-test before committing.

```bash
git add -A
git commit -m "test: verify web-configure skill with Azblink Server dry run"
```

Only commit if there were fixes. If all passed clean, skip this commit.

---

## Plan Self-Review

**Spec coverage check:**
- ✓ 3-layer architecture (curl/browse/validate) — Tasks 5-7
- ✓ Two modes (discover+configure, replay) — Task 4 entry point
- ✓ 5 phases (auth, navigate, discover, configure, verify) — Tasks 5-7
- ✓ Playbook format with all schema fields — Task 2 template
- ✓ Reference playbook — Task 3
- ✓ Variable resolution with security gate — Task 4
- ✓ Staleness detection via fingerprint — Task 6
- ✓ Browse batching rule — Task 8
- ✓ Error handling table — Task 8
- ✓ Output summary — Task 8
- ✓ Skills manifest registration — Task 9
- ✓ Multiple operations per configure phase — Task 6
- ✓ Multiple cookies — Task 5
- ✓ contentType — Task 6
- ✓ followRedirects — Task 5
- ✓ verifyCommand — Task 7
- ✓ verifyDelay — Task 7
- ✓ Secret default rejection — Task 4
- ✓ Cookie non-persistence — Task 5
- ✓ tlsVerify — Task 3 reference playbook
- ✓ baseUrl variable substitution — Task 3 reference playbook
- ✓ Iframe handling — Task 5 navigate browse layer
- ✓ screenshotPolicy — not in plan (follow-up per spec)
- ✓ --from-issue import — not in plan (follow-up per spec)
- ✓ Shared browse patterns extraction — not in plan (follow-up per spec)

**Placeholder scan:** No TBD, TODO, or "implement later" found.

**Type consistency:** Playbook field names (`phases.configure.operations`, `verify.curl[].assertions`, `extract.cookies`) are consistent across template (Task 2), reference playbook (Task 3), and SKILL.md (Tasks 4-8).
