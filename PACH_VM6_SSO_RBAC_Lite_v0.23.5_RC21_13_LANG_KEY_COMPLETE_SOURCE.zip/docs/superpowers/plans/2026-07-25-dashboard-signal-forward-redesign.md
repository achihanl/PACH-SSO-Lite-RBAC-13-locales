# Dashboard Signal-Forward Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn the AZBlink dashboard from vanity-first (two fake-zero hero tiles, false-red health) into attention-first — surfacing compliance alerts, real health, expiring provisions, and users-by-status — using existing endpoints plus additive backend changes only.

**Architecture:** Backend changes are additive (no schema): make UC health conditional, drop two fabricated stat fields, expose `expires_at`, add `statusCounts`, and stop collapsing activity types onto the QR icon. Frontend extracts all decision logic (severity sort, 48h window, health rollup, icon resolution) into pure functions unit-tested with vitest, then wires thin React components (verified by build/lint + e2e) into an attention-first, responsive layout.

**Tech Stack:** FastAPI + pytest (backend), React 19 + TanStack Router/Query + @azblink/ui + Tailwind 4 + vitest (frontend).

## Global Constraints

- **Vitest is pure-function only** — tests live at `src/frontend/src/**/__tests__/**/*.test.ts` (NOT `.test.tsx`); no DOM/component rendering (`vitest.config.ts:3,16`). Component behavior is verified by `just ui-build` + `just ui-lint` + the QA e2e pipeline, never by fabricated render tests.
- **Frontend gate:** `just pr-checks` (ui-lint, ui-format-check, ui-build, ui-test-unit, ruff, mypy, `pytest tests/unit`). Run before every frontend commit.
- **Backend integration gate:** `just test-quick` (stack must be up: `just up-bg`) — runs `tests/test_dashboard_api.py` against the real Docker stack.
- **Component layers** (`.claude/rules/frontend-components.md`): domain-agnostic atoms → primitives in `packages/azblink-ui/primitives/` (CSS Modules + `tokens.css` vars); domain composites → `src/components/features/<domain>/` (Tailwind utilities referencing bridged tokens). Import primitives from `@azblink/ui`. Never hardcode color/font/size values.
- **Badge variants** are exactly: `success`, `warning`, `error`, `info`, `muted`, `purple`, `outline` — no others.
- **Scope is additive** — no new DB tables/columns, no new LDAP round-trips, no REST↔live-bus event-name normalization (deferred), no UC reachability probe (deferred).
- **Arch trailer:** commits touching `/api/dashboard/health`, `/api/dashboard/stats`, `/api/provisions/pending`, `/api/users` carry `Spec-Patch: <section>` (or `ARD:` if deemed decisional) per `docs/architecture/SOP.md`. Run `just arch-guard` before pushing.
- **Severity vocabulary** (compliance): `critical` > `warning` > `low`. Only `cross-user-device` is `critical`, and its `subject_uid` is `null` (affected users in `evidence.users`).

---

## Phase A — Backend (additive; each independently testable)

### Task 1: Remove XMPP/SIP from the health endpoint

> **Revised after the original Task 1 review.** XMPP/SIP were always-green non-probes: `config.py:368` `_validate_uc_config` makes `UCCHAT_*` mandatory at startup (the backend cannot boot without them; spec `05-provisioning.md:59`), so the old "error when the domain is unset" branch is unreachable and the rows convey no signal. Drop them from the panel entirely — unconditional, no dead code. The health rollup (Task 8) and Health tile (Task 11) then cover only the four services with real probes.

**Files:**
- Modify: `src/backend/main.py` — the XMPP/SIP `_check` block in `api_dashboard_health` (locate via code_search `_check("XMPP Server"` / `UCCHAT_XMPP_DOMAIN`)
- Test: `tests/test_dashboard_api.py` (add a case)

**Interfaces:**
- Produces: `GET /api/dashboard/health` → `{"services": [{"name","status","latency"}]}` containing ONLY `PostgreSQL`, `LDAP`, `Redis`, `Authentik`. XMPP/SIP no longer appear. `status ∈ {"healthy","error"}`, `latency` is a string like `"12ms"`.

- [ ] **Step 1: Write the failing test**

Add to `tests/test_dashboard_api.py` (place it as a method on the existing `TestDashboardHealth` class, matching this file's class-per-endpoint structure):

```python
def test_health_excludes_uc_services(self, client):
    resp = client.get("/api/dashboard/health")
    assert resp.status_code == 200
    names = {s["name"] for s in resp.json()["services"]}
    # UC (XMPP/SIP) removed — always-green non-probes, no signal
    assert "XMPP Server" not in names
    assert "SIP Server" not in names
    # The four real-probe services remain
    assert {"PostgreSQL", "LDAP", "Redis", "Authentik"} <= names
```

- [ ] **Step 2: Run test to verify it fails**

Run: `just up-bg && just test-quick -- tests/test_dashboard_api.py -v`
Expected: FAIL — `"XMPP Server"`/`"SIP Server"` currently appear in `services` (they are always configured, hence always `healthy`).

- [ ] **Step 3: Implement — delete the XMPP/SIP checks**

Locate the two `_check("XMPP Server", …)` / `_check("SIP Server", …)` calls in `api_dashboard_health` and the `_xmpp`/`_sip` closures they invoke, and **remove them entirely** (both the `_check` calls and the now-unused closures). Leave the four core-service `_check` calls (PostgreSQL, LDAP, Redis, Authentik) untouched. If `UCCHAT_XMPP_DOMAIN`/`UCCHAT_SIP_DOMAIN` are now unused imports in this function's scope, leave the module-level names alone (they are used elsewhere) — only remove what your change orphaned locally.

- [ ] **Step 4: Run test to verify it passes**

Run: `just test-quick -- tests/test_dashboard_api.py -v`
Expected: PASS. **Also confirm no pre-existing health test asserts XMPP/SIP are present** (search `tests/` for `"XMPP Server"` / `"SIP Server"`); the audit found the existing cases assert only core services + `latency.endswith("ms")`, but verify and update any that break.

- [ ] **Step 5: Commit**

```bash
git add src/backend/main.py tests/test_dashboard_api.py
git commit -m "fix(dashboard): drop always-green XMPP/SIP rows from health panel

Spec-Patch: 05"
```

---

### Task 2: Drop fabricated `active_sessions` / `success_rate` from stats

**Files:**
- Modify: `src/backend/orgdb.py:1156-1160` (`get_dashboard_stats_db`)
- Modify: `src/backend/main.py:2726-2731` (`api_dashboard_stats` response dict)
- Test: `tests/test_dashboard_api.py:18-22` (update assertions)

**Interfaces:**
- Produces: `GET /api/dashboard/stats` → `{"total_users": int, "pending_provisions": int}` (the two fabricated keys removed).

- [ ] **Step 1: Update the test to assert the NEW contract (write it failing)**

Replace the assertions at `tests/test_dashboard_api.py:18-22` that currently require `active_sessions`/`success_rate`:

```python
def test_dashboard_stats_shape(client):
    data = client.get("/api/dashboard/stats").json()
    assert set(data.keys()) == {"total_users", "pending_provisions"}
    assert isinstance(data["total_users"], int)
    assert isinstance(data["pending_provisions"], int)
    assert "active_sessions" not in data   # fabricated zero — removed
    assert "success_rate" not in data      # QR table removed — removed
```

- [ ] **Step 2: Run to verify it fails**

Run: `just test-quick -- tests/test_dashboard_api.py::test_dashboard_stats_shape -v`
Expected: FAIL — response still contains `active_sessions`/`success_rate`.

- [ ] **Step 3: Implement**

In `orgdb.py` `get_dashboard_stats_db` (`:1156-1160`), remove the hardcoded `active_sessions`/`success_rate` keys from the returned dict. In `main.py:2726-2731`, reduce the response dict to:

```python
return {"total_users": total_users, "pending_provisions": pending_count}
```

(`pending_count` is the orphan-filtered value already derived at `main.py:2716-2724` — keep that logic.)

- [ ] **Step 4: Run to verify it passes**

Run: `just test-quick -- tests/test_dashboard_api.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py tests/test_dashboard_api.py
git commit -m "fix(dashboard): stop returning fabricated active_sessions/success_rate

Spec-Patch: 05"
```

> Frontend type/consumer for these fields is removed in Task 10/Task 11 (coordinated change).

---

### Task 3: Expose `expires_at` on pending provisions

**Files:**
- Modify: `src/backend/main.py:2981` (per-item dict in `api_provisions_pending`)
- Test: `tests/test_dashboard_api.py` (extend the pending-item test near `:118-155`)

**Interfaces:**
- Produces: each `/api/provisions/pending` item gains `"expires_at": <iso8601 str | null>` (already present in the row as `raw["expires_at"]`). Existing `id`/`uid`/`user`/`detail`/`action` unchanged.

- [ ] **Step 1: Write the failing test**

```python
def test_pending_item_exposes_expires_at(client):
    items = client.get("/api/provisions/pending").json()
    assert isinstance(items, list)
    for item in items:
        assert "expires_at" in item  # machine-readable, for the 48h Expiring tile
```

- [ ] **Step 2: Run to verify it fails**

Run: `just test-quick -- tests/test_dashboard_api.py::test_pending_item_exposes_expires_at -v`
Expected: FAIL — `expires_at` absent (only formatted `detail`).

- [ ] **Step 3: Implement**

Read `main.py:2964-2997`. Add the raw ISO timestamp to the item dict at `:2981` (keep the formatted `detail` too):

```python
"expires_at": raw["expires_at"],  # ISO str or None; detail string stays for display
```

- [ ] **Step 4: Run to verify it passes**

Run: `just test-quick -- tests/test_dashboard_api.py -v`
Expected: PASS (existing `test_item_has_separate_id_and_uid` still green — additive field).

- [ ] **Step 5: Commit**

```bash
git add src/backend/main.py tests/test_dashboard_api.py
git commit -m "feat(dashboard): expose expires_at on pending provisions

Spec-Patch: 05"
```

---

### Task 4: Add `statusCounts` to the users endpoint

**Files:**
- Modify: `src/backend/main.py:1594-1625` (`api_users` — compute before search/status filtering)
- Test: `tests/test_dashboard_api.py` or `tests/test_users_api.py` (whichever holds users-list cases — grep first)

**Interfaces:**
- Produces: `GET /api/users` response gains `"statusCounts": {"active": int, "pending": int, "suspended": int, "terminated": int}`, computed over the FULL directory (not the returned page). Existing `users`/`total`/`hasMore` unchanged.

- [ ] **Step 1: Write the failing test**

```python
def test_users_response_has_status_counts(client):
    data = client.get("/api/users?limit=1").json()
    assert "statusCounts" in data
    sc = data["statusCounts"]
    assert set(sc) >= {"active", "pending", "suspended", "terminated"}
    # counts reflect the whole directory, not the 1-item page
    assert sum(sc.values()) == data["total"]
```

- [ ] **Step 2: Run to verify it fails**

Run: `just test-quick -- tests/test_dashboard_api.py::test_users_response_has_status_counts -v`
Expected: FAIL — `statusCounts` absent.

- [ ] **Step 3: Implement**

At the top of `api_users`, after `all_users = list_users()` (`main.py:1594`) and BEFORE the in-memory search/status filtering (`:1607-1619`), compute counts from the already-loaded list (zero extra LDAP cost):

```python
from collections import Counter  # ensure imported at module top
_status_counts = Counter(u["accountStatus"] for u in all_users)
status_counts = {
    "active": _status_counts.get("active", 0),
    "pending": _status_counts.get("pending", 0),
    "suspended": _status_counts.get("suspended", 0),
    "terminated": _status_counts.get("terminated", 0),
}
```

Add `"statusCounts": status_counts` to the response dict at `main.py:1625`.

- [ ] **Step 4: Run to verify it passes**

Run: `just test-quick -- tests/test_dashboard_api.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/backend/main.py tests/
git commit -m "feat(users): add whole-directory statusCounts to users list

Spec-Patch: 03"
```

---

### Task 5: Stop collapsing activity types onto the QR icon (REST feed)

**Files:**
- Modify: `src/backend/main.py:3019-3031` (`type_map` + default in `api_activity_recent`)
- Test: `tests/test_dashboard_api.py` (add an activity-typing case if the stack can seed one; otherwise assert the map has no QR fallback for non-QR types)

**Interfaces:**
- Produces: `/api/activity/recent` items whose `type` preserves the real event class — `config-change`, `admin-action`, `login`, and device events map to their own type strings (not `qr-generated`); unknown types fall back to a neutral `"activity"` (NOT `qr-generated`).

- [ ] **Step 1: Write the failing test**

```python
def test_activity_type_map_has_no_qr_fallback():
    # Import the module-level map used by api_activity_recent
    from src.backend.main import ACTIVITY_TYPE_MAP, ACTIVITY_TYPE_DEFAULT
    # Non-QR events must not resolve to a qr-* icon type
    for src_type in ("config-change", "admin-action", "login",
                     "device-provisioned", "device-revoked", "device-extended"):
        assert not ACTIVITY_TYPE_MAP.get(src_type, ACTIVITY_TYPE_DEFAULT).startswith("qr-")
    assert not ACTIVITY_TYPE_DEFAULT.startswith("qr-")
```

- [ ] **Step 2: Run to verify it fails**

Run: `just test-quick -- tests/test_dashboard_api.py::test_activity_type_map_has_no_qr_fallback -v`
Expected: FAIL — map/default currently collapse to `qr-generated` (and the map is an inline local, not importable).

- [ ] **Step 3: Implement**

Read `main.py:3019-3031`. Lift the map to a module-level constant and give real types + a neutral default:

```python
ACTIVITY_TYPE_MAP = {
    "qr-consumed": "qr-consumed", "qr-generated": "qr-generated", "qr-expired": "qr-expired",
    "qr-revoked": "qr-expired",
    "user-terminated": "user-terminated", "user-created": "user-created",
    "sso-enrolled": "sso-enrolled",
    "login": "login",
    "config-change": "config-change",
    "admin-action": "admin-action",
    "device-provisioned": "provisioning", "device-revoked": "provisioning",
    "device-extended": "provisioning",
}
ACTIVITY_TYPE_DEFAULT = "activity"
```

Use `ACTIVITY_TYPE_MAP.get(event_type, ACTIVITY_TYPE_DEFAULT)` in `api_activity_recent`. (Note: `provisioning` aligns the REST device events with the live-bus name; the FE resolver in Task 9 handles both `provisioning` and any residual `device-*`.)

- [ ] **Step 4: Run to verify it passes**

Run: `just test-quick -- tests/test_dashboard_api.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/backend/main.py tests/test_dashboard_api.py
git commit -m "fix(activity): stop mapping non-QR events onto the QR icon

Spec-Patch: 05"
```

---

## Phase B — Frontend pure-logic modules (TDD with vitest)

> All modules live under `src/frontend/src/lib/dashboard/` with tests in `src/frontend/src/lib/dashboard/__tests__/*.test.ts`. Run: `just ui-test-unit` (or `cd src/frontend && npm run test:unit`).

### Task 6: Compliance logic (count, worst-severity, critical-first sort)

**Files:**
- Create: `src/frontend/src/lib/dashboard/compliance.ts`
- Test: `src/frontend/src/lib/dashboard/__tests__/compliance.test.ts`

**Interfaces:**
- Consumes: the compliance API shape `{ summary: Record<string, number>, alerts: ComplianceAlert[] }` where `ComplianceAlert = { id, type, severity: 'critical'|'warning'|'low', subject_uid: string|null, description, evidence, ... }` (from `src/frontend/src/types/` provisioning-ops types; reuse, don't redefine).
- Produces:
  - `alertCount(summary: Record<string, number>): number`
  - `worstSeverity(alerts: ComplianceAlert[]): 'critical'|'warning'|'low'|'none'`
  - `sortAlertsCriticalFirst(alerts: ComplianceAlert[]): ComplianceAlert[]`
  - `severityToBadgeVariant(sev): 'error'|'warning'|'muted'` (critical→error, warning→warning, low→muted)

- [ ] **Step 1: Write the failing test**

```ts
import { describe, it, expect } from 'vitest'
import { alertCount, worstSeverity, sortAlertsCriticalFirst, severityToBadgeVariant } from '../compliance'

const A = (severity: string, id = severity) => ({ id, type: 't', severity, subject_uid: null } as any)

describe('compliance logic', () => {
  it('counts alerts from the per-type summary', () => {
    expect(alertCount({ 'expired-unused': 2, 'cross-user-device': 1, 'stale-active': 0 })).toBe(3)
    expect(alertCount({})).toBe(0)
  })
  it('picks the worst severity present', () => {
    expect(worstSeverity([A('low'), A('warning'), A('critical')])).toBe('critical')
    expect(worstSeverity([A('low'), A('warning')])).toBe('warning')
    expect(worstSeverity([])).toBe('none')
  })
  it('sorts critical first, stable within severity (API returns type order)', () => {
    const out = sortAlertsCriticalFirst([A('warning', 'w'), A('critical', 'c'), A('low', 'l')])
    expect(out.map(a => a.id)).toEqual(['c', 'w', 'l'])
  })
  it('maps severity to an allowed badge variant', () => {
    expect(severityToBadgeVariant('critical')).toBe('error')
    expect(severityToBadgeVariant('warning')).toBe('warning')
    expect(severityToBadgeVariant('low')).toBe('muted')
  })
})
```

- [ ] **Step 2: Run to verify it fails**

Run: `just ui-test-unit`
Expected: FAIL — module not found.

- [ ] **Step 3: Implement `compliance.ts`**

```ts
const RANK = { critical: 3, warning: 2, low: 1 } as const
type Sev = keyof typeof RANK

export function alertCount(summary: Record<string, number>): number {
  return Object.values(summary).reduce((n, v) => n + (v || 0), 0)
}
export function worstSeverity(alerts: { severity: string }[]): Sev | 'none' {
  let best = 0, out: Sev | 'none' = 'none'
  for (const a of alerts) {
    const r = RANK[a.severity as Sev] ?? 0
    if (r > best) { best = r; out = a.severity as Sev }
  }
  return out
}
export function sortAlertsCriticalFirst<T extends { severity: string }>(alerts: T[]): T[] {
  return [...alerts].sort((a, b) => (RANK[b.severity as Sev] ?? 0) - (RANK[a.severity as Sev] ?? 0))
}
export function severityToBadgeVariant(sev: string): 'error' | 'warning' | 'muted' {
  return sev === 'critical' ? 'error' : sev === 'warning' ? 'warning' : 'muted'
}
```

- [ ] **Step 4: Run to verify it passes**

Run: `just ui-test-unit`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/frontend/src/lib/dashboard/compliance.ts src/frontend/src/lib/dashboard/__tests__/compliance.test.ts
git commit -m "feat(dashboard): compliance count/severity/sort logic + tests"
```

---

### Task 7: Expiring-window logic

**Files:**
- Create: `src/frontend/src/lib/dashboard/expiring.ts`
- Test: `src/frontend/src/lib/dashboard/__tests__/expiring.test.ts`

**Interfaces:**
- Produces: `countExpiringWithin(items: {expires_at: string|null}[], withinMs: number, now: number): number` — counts items whose `expires_at` is in `(now, now+withinMs]`; null and already-expired excluded. `EXPIRING_WINDOW_MS = 48*60*60*1000`.

- [ ] **Step 1: Write the failing test**

```ts
import { describe, it, expect } from 'vitest'
import { countExpiringWithin, EXPIRING_WINDOW_MS } from '../expiring'

const now = Date.parse('2026-07-25T00:00:00Z')
const at = (h: number) => new Date(now + h * 3600_000).toISOString()

describe('expiring window', () => {
  it('counts only items expiring within the window and not yet expired', () => {
    const items = [
      { expires_at: at(1) },     // in 1h  -> counts
      { expires_at: at(47) },    // in 47h -> counts
      { expires_at: at(72) },    // in 72h -> excluded
      { expires_at: at(-1) },    // expired -> excluded
      { expires_at: null },      // no expiry -> excluded
    ]
    expect(countExpiringWithin(items, EXPIRING_WINDOW_MS, now)).toBe(2)
  })
  it('window constant is 48h', () => {
    expect(EXPIRING_WINDOW_MS).toBe(48 * 3600_000)
  })
})
```

- [ ] **Step 2: Run to verify it fails** — `just ui-test-unit` → FAIL (module missing).

- [ ] **Step 3: Implement `expiring.ts`**

```ts
export const EXPIRING_WINDOW_MS = 48 * 60 * 60 * 1000

export function countExpiringWithin(
  items: { expires_at: string | null }[],
  withinMs: number,
  now: number,
): number {
  const limit = now + withinMs
  return items.reduce((n, it) => {
    if (!it.expires_at) return n
    const t = Date.parse(it.expires_at)
    return Number.isFinite(t) && t > now && t <= limit ? n + 1 : n
  }, 0)
}
```

- [ ] **Step 4: Run to verify it passes** — `just ui-test-unit` → PASS.

- [ ] **Step 5: Commit**

```bash
git add src/frontend/src/lib/dashboard/expiring.ts src/frontend/src/lib/dashboard/__tests__/expiring.test.ts
git commit -m "feat(dashboard): 48h expiring-window count logic + tests"
```

---

### Task 8: Health rollup logic

**Files:**
- Create: `src/frontend/src/lib/dashboard/health-rollup.ts`
- Test: `src/frontend/src/lib/dashboard/__tests__/health-rollup.test.ts`

**Interfaces:**
- Consumes: health API `{ services: { name: string; status: 'healthy'|'error'; latency: string }[] }`.
- Produces: `rollupHealth(services): { ok: boolean; degraded: string[]; label: string }` — `ok` when every service is `healthy`; `degraded` = names of non-healthy services; `label` = "All systems OK" or "N degraded".

- [ ] **Step 1: Write the failing test**

```ts
import { describe, it, expect } from 'vitest'
import { rollupHealth } from '../health-rollup'

const s = (name: string, status: string) => ({ name, status, latency: '1ms' })

describe('health rollup', () => {
  it('reports ok when all healthy', () => {
    const r = rollupHealth([s('PostgreSQL', 'healthy'), s('LDAP', 'healthy')])
    expect(r.ok).toBe(true)
    expect(r.degraded).toEqual([])
    expect(r.label).toBe('All systems OK')
  })
  it('names degraded services', () => {
    const r = rollupHealth([s('PostgreSQL', 'healthy'), s('LDAP', 'error'), s('Redis', 'error')])
    expect(r.ok).toBe(false)
    expect(r.degraded).toEqual(['LDAP', 'Redis'])
    expect(r.label).toBe('2 degraded')
  })
  it('handles empty list as ok', () => {
    expect(rollupHealth([]).ok).toBe(true)
  })
})
```

- [ ] **Step 2: Run to verify it fails** — `just ui-test-unit` → FAIL.

- [ ] **Step 3: Implement `health-rollup.ts`**

```ts
export function rollupHealth(
  services: { name: string; status: string }[],
): { ok: boolean; degraded: string[]; label: string } {
  const degraded = services.filter(s => s.status !== 'healthy').map(s => s.name)
  const ok = degraded.length === 0
  return { ok, degraded, label: ok ? 'All systems OK' : `${degraded.length} degraded` }
}
```

- [ ] **Step 4: Run to verify it passes** — `just ui-test-unit` → PASS.

- [ ] **Step 5: Commit**

```bash
git add src/frontend/src/lib/dashboard/health-rollup.ts src/frontend/src/lib/dashboard/__tests__/health-rollup.test.ts
git commit -m "feat(dashboard): health rollup logic + tests"
```

---

### Task 9: Activity icon resolver (both feeds + neutral fallback)

**Files:**
- Create: `src/frontend/src/lib/dashboard/activity-icons.ts`
- Test: `src/frontend/src/lib/dashboard/__tests__/activity-icons.test.ts`

**Interfaces:**
- Produces: `resolveActivityIcon(type: string): ActivityIconKey` mapping every type that flows from **either** feed to a stable icon key; unknown → `'activity'` (neutral), never a `qr-*` key. `ActivityIconKey` union: `'qr' | 'user-created' | 'user-terminated' | 'user-suspended' | 'sso' | 'admin' | 'config' | 'login' | 'provisioning' | 'activity'`.
- Covered inputs — REST: `qr-consumed|qr-generated|qr-expired`, `user-created|user-terminated`, `sso-enrolled`, `login`, `config-change`, `admin-action`, `provisioning`; live-bus extras: `user-suspended|user-unsuspended`, admin verbs (`create-user|update-org|…`), `provisioning`, and raw actions (`password_reset`, …).

- [ ] **Step 1: Write the failing test**

```ts
import { describe, it, expect } from 'vitest'
import { resolveActivityIcon } from '../activity-icons'

describe('activity icon resolver', () => {
  it('maps QR events to the qr icon', () => {
    for (const t of ['qr-consumed', 'qr-generated', 'qr-expired']) expect(resolveActivityIcon(t)).toBe('qr')
  })
  it('gives non-QR events their own icon (never qr)', () => {
    expect(resolveActivityIcon('config-change')).toBe('config')
    expect(resolveActivityIcon('admin-action')).toBe('admin')
    expect(resolveActivityIcon('login')).toBe('login')
    expect(resolveActivityIcon('provisioning')).toBe('provisioning')
    expect(resolveActivityIcon('device-provisioned')).toBe('provisioning')
    expect(resolveActivityIcon('user-suspended')).toBe('user-suspended')
    expect(resolveActivityIcon('user-unsuspended')).toBe('user-suspended')
  })
  it('maps admin verbs and unknown types to non-qr icons', () => {
    expect(resolveActivityIcon('update-org')).toBe('admin')
    expect(resolveActivityIcon('password_reset')).toBe('activity')
    expect(resolveActivityIcon('totally-unknown')).toBe('activity')
  })
})
```

- [ ] **Step 2: Run to verify it fails** — `just ui-test-unit` → FAIL.

- [ ] **Step 3: Implement `activity-icons.ts`**

```ts
export type ActivityIconKey =
  | 'qr' | 'user-created' | 'user-terminated' | 'user-suspended'
  | 'sso' | 'admin' | 'config' | 'login' | 'provisioning' | 'activity'

const EXACT: Record<string, ActivityIconKey> = {
  'qr-consumed': 'qr', 'qr-generated': 'qr', 'qr-expired': 'qr', 'qr-revoked': 'qr',
  'user-created': 'user-created', 'user-terminated': 'user-terminated',
  'user-suspended': 'user-suspended', 'user-unsuspended': 'user-suspended',
  'sso-enrolled': 'sso',
  'login': 'login',
  'config-change': 'config',
  'admin-action': 'admin',
  'provisioning': 'provisioning',
  'device-provisioned': 'provisioning', 'device-revoked': 'provisioning', 'device-extended': 'provisioning',
}

export function resolveActivityIcon(type: string): ActivityIconKey {
  if (EXACT[type]) return EXACT[type]
  // live-bus admin verbs: create-user / update-org / delete-group / reset-password ...
  if (/^(create|update|delete|reset|enable|disable|assign|revoke)-/.test(type)) return 'admin'
  return 'activity'
}
```

- [ ] **Step 4: Run to verify it passes** — `just ui-test-unit` → PASS.

- [ ] **Step 5: Commit**

```bash
git add src/frontend/src/lib/dashboard/activity-icons.ts src/frontend/src/lib/dashboard/__tests__/activity-icons.test.ts
git commit -m "feat(dashboard): activity icon resolver covering both feeds + tests"
```

---

## Phase C — Frontend types & query hooks

### Task 10: Update types + wire hooks for new/changed data

**Files:**
- Modify: `src/frontend/src/types/dashboard.ts` (stats fields, `ActivityEventType` union, pending `expires_at`, remove `trends`)
- Modify: `src/frontend/src/types/api.ts` (users `statusCounts` on `PaginatedUsersResponse` — confirm location, `api.ts:62-71`)
- Modify: `src/frontend/src/lib/queries/dashboard.ts` (remove stale header comment `:3-8`; ensure hooks return updated types)
- Reuse (no change): `complianceQueryOptions()` (`lib/queries/provisioning-ops.ts:65`), `paginatedUsersQueryOptions` (`lib/queries/users.ts:68`)

**Interfaces:**
- Produces: `DashboardStatsApiResponse = { total_users: number; pending_provisions: number }` (no `active_sessions`, `success_rate`, `trends`); pending item type gains `expires_at: string | null`; `PaginatedUsersResponse` gains `statusCounts: { active; pending; suspended; terminated }`; `ActivityEventType` union covers the resolver keys (align with Task 9's `ActivityIconKey` domain).

- [ ] **Step 1: Update `types/dashboard.ts`**

- Remove `active_sessions` and `success_rate` from `DashboardStatsApiResponse` (`:46,48`).
- Remove the `trends?` block (`:49-54`).
- Add `expires_at: string | null` to the pending-provision item type.
- Expand `ActivityEventType` (`:30-36`) to: `'qr-consumed'|'qr-generated'|'qr-expired'|'sso-enrolled'|'user-created'|'user-terminated'|'user-suspended'|'login'|'config-change'|'admin-action'|'provisioning'|'activity'`.

- [ ] **Step 2: Update `types/api.ts`**

Add to `PaginatedUsersResponse` (`api.ts:62-71`):

```ts
statusCounts: { active: number; pending: number; suspended: number; terminated: number }
```

- [ ] **Step 3: Remove the stale comment block**

Delete the "Backend endpoints (#50, #51) not yet implemented … 404" comment at `lib/queries/dashboard.ts:3-8`.

- [ ] **Step 4: Verify types compile**

Run: `just ui-build`
Expected: type errors ONLY where `StatsGrid.tsx` still reads the removed fields — those are fixed in Task 11. If any OTHER file breaks, note it (unexpected consumer). Do not commit a broken build alone; sequence Task 11 immediately after, OR temporarily guard.

- [ ] **Step 5: Commit (with Task 11 if build is red in isolation)**

```bash
git add src/frontend/src/types/dashboard.ts src/frontend/src/types/api.ts src/frontend/src/lib/queries/dashboard.ts
git commit -m "refactor(dashboard): types for real stats/pending/users/activity shapes"
```

> If `ui-build` is red solely due to `StatsGrid.tsx`, land Task 10 + Task 11 as one commit.

---

## Phase D — Frontend components (verified by build + lint; logic already unit-tested)

### Task 11: Hero row — 4 attention-first tiles (replaces StatsGrid)

**Files:**
- Create: `src/frontend/src/components/features/dashboard/hero/AlertsTile.tsx`, `HealthTile.tsx`, `ExpiringTile.tsx`, `UsersTile.tsx`
- Create: `src/frontend/src/components/features/dashboard/hero/HeroRow.tsx`
- Modify: `src/frontend/src/routes/index.tsx` (swap `StatsGrid` → `HeroRow`)
- Delete/retire: `StatsGrid.tsx` (and its `trends`/`active_sessions`/`success_rate` reads)

**Interfaces:**
- Consumes: `dashboardStatsQueryOptions`, `dashboardHealthQueryOptions`, `pendingProvisionsQueryOptions`, `paginatedUsersQueryOptions` (hooks from Phase C); pure logic from Tasks 6–8 (`alertCount`, `worstSeverity`, `severityToBadgeVariant`, `countExpiringWithin`, `EXPIRING_WINDOW_MS`, `rollupHealth`); `complianceQueryOptions()`.
- Produces: `<HeroRow />` rendering four tiles in `grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4`.

- [ ] **Step 1: Build the four tiles on `StatCard`**

Each tile is a thin wrapper over the shared `stat-card.tsx` primitive/feature file, feeding it a value + variant computed by the Phase-B logic. Key wiring:
- `AlertsTile`: `const { data } = useQuery(complianceQueryOptions()); const count = alertCount(data?.summary ?? {}); const variant = severityToBadgeVariant(worstSeverity(data?.alerts ?? []))`. Clicking scrolls to `#compliance-card` (`document.getElementById('compliance-card')?.scrollIntoView({behavior:'smooth'})`).
- `HealthTile`: `const r = rollupHealth(data?.services ?? [])`; label = `r.label`; green when `r.ok`, else error/amber; wraps the per-service detail in `CollapsibleSection` (from `@azblink/ui`), auto-open when `!r.ok`.
- `ExpiringTile`: `countExpiringWithin(pending ?? [], EXPIRING_WINDOW_MS, Date.now())`.
- `UsersTile`: `total` from users query + `statusCounts.pending` as sublabel.

Use only allowed Badge variants and token-bridged Tailwind colors (no hardcoded hex).

- [ ] **Step 2: Assemble `HeroRow` and swap it into the route**

Replace `<StatsGrid />` at `routes/index.tsx:41-…` (the first `ErrorBoundaryCard` region) with `<HeroRow />`. Keep the `ErrorBoundaryCard` wrapper.

- [ ] **Step 3: Delete `StatsGrid.tsx`** and remove its import from the route. (This removes the last readers of the dropped stats fields + the dead `trends` path.)

- [ ] **Step 4: Verify build + lint**

Run: `just ui-build && just ui-lint`
Expected: PASS, no type errors (Task 10's removed fields now have no readers).

- [ ] **Step 5: Commit**

```bash
git add src/frontend/src/components/features/dashboard/hero/ src/frontend/src/routes/index.tsx
git rm src/frontend/src/components/features/dashboard/StatsGrid.tsx
git commit -m "feat(dashboard): attention-first hero row (alerts/health/expiring/users)"
```

---

### Task 12: Compliance alerts sidebar card

**Files:**
- Create: `src/frontend/src/components/features/dashboard/ComplianceAlertsCard.tsx`
- Modify: `src/frontend/src/components/features/dashboard/DashboardSidebar.tsx` (insert card; update stale "Phase 3" comment at `:4`)

**Interfaces:**
- Consumes: `complianceQueryOptions()`; `sortAlertsCriticalFirst`, `severityToBadgeVariant` (Task 6). Optionally reuse `ComplianceSummaryCards.tsx` (`provisioning-management/`) for row layout.
- Produces: `<ComplianceAlertsCard />` with `id="compliance-card"` (the AlertsTile scroll target).

- [ ] **Step 1: Implement the card**

- `const alerts = sortAlertsCriticalFirst(data?.alerts ?? [])`.
- Render each: severity `Badge` (`severityToBadgeVariant`), `type`, and affected subject: `alert.subject_uid ?? alert.evidence?.users?.join(', ') ?? '—'` (handle `cross-user-device` null subject).
- Empty state: "No compliance issues." via the shared `empty-state.tsx`.
- Wrap the outer element with `id="compliance-card"`.

- [ ] **Step 2: Insert into sidebar** near the top (attention-first order: Compliance → Expiring → Activity → Quick actions). Update the stale JSDoc comment at `DashboardSidebar.tsx:4`.

- [ ] **Step 3: Verify** — `just ui-build && just ui-lint` → PASS.

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/components/features/dashboard/ComplianceAlertsCard.tsx src/frontend/src/components/features/dashboard/DashboardSidebar.tsx
git commit -m "feat(dashboard): compliance alerts card (critical-first, null-subject safe)"
```

---

### Task 13: Users-by-status segmented bar (main column)

**Files:**
- Create: `src/frontend/src/components/features/dashboard/UsersByStatusBar.tsx`
- Modify: `src/frontend/src/components/features/dashboard/DashboardMain.tsx` (add below the chart; fix stale "Phase 2" comment at `:3`)

**Interfaces:**
- Consumes: `paginatedUsersQueryOptions({})` → `data.statusCounts`.
- Produces: `<UsersByStatusBar />` — a horizontal segmented bar with 4 segments (active/pending/suspended/terminated) sized proportionally, using token-bridged status colors + a legend with counts.

- [ ] **Step 1: Implement the bar** — compute segment widths as `count/total*100%`; label each segment; use `STATUS_STYLES` tokens (no hardcoded hex). Zero-total → render a muted "No users" state.

- [ ] **Step 2: Insert into `DashboardMain`** below `ProvisioningChartCard`; fix the stale comment at `DashboardMain.tsx:3`.

- [ ] **Step 3: Verify** — `just ui-build && just ui-lint` → PASS.

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/components/features/dashboard/UsersByStatusBar.tsx src/frontend/src/components/features/dashboard/DashboardMain.tsx
git commit -m "feat(dashboard): users-by-status segmented bar"
```

---

### Task 14: Activity feed icon wiring

**Files:**
- Modify: `src/frontend/src/components/features/dashboard/ActivityIcon.tsx` (map `ActivityIconKey` → icon component)
- Modify: `src/frontend/src/types/dashboard.ts` (`ACTIVITY_ICON_STYLES` — add style entries for the new keys)
- Modify: `ActivityItem.tsx` if it references the icon key directly

**Interfaces:**
- Consumes: `resolveActivityIcon` (Task 9).
- Produces: `ActivityIcon` renders a distinct icon for every `ActivityIconKey`; no event resolves to the QR icon unless it is a QR event.

- [ ] **Step 1: Route the event type through the resolver** — in `ActivityIcon.tsx` (`:12-19`) replace the direct `EVENT_ICONS[type]` lookup with `EVENT_ICONS[resolveActivityIcon(type)]`, and extend `EVENT_ICONS` + `ACTIVITY_ICON_STYLES` (`types/dashboard.ts:180-208`) with entries for `user-suspended`, `admin`, `config`, `login`, `provisioning`, `activity` (pick sensible lucide icons already used in the app; neutral `activity` → a generic dot/pulse). Use only token colors.

- [ ] **Step 2: Verify** — `just ui-build && just ui-lint && just ui-test-unit` → PASS.

- [ ] **Step 3: Commit**

```bash
git add src/frontend/src/components/features/dashboard/ActivityIcon.tsx src/frontend/src/components/features/dashboard/ActivityItem.tsx src/frontend/src/types/dashboard.ts
git commit -m "fix(dashboard): distinct activity icons across both feeds"
```

---

### Task 15: Wire "View All", relative expiry, and trim Quick Actions

**Files:**
- Modify: `src/frontend/src/components/features/dashboard/PendingProvisionsCard.tsx` (wire View All; `PendingItem.tsx:3` stale comment)
- Modify: `src/frontend/src/components/features/dashboard/QuickActionsCard.tsx` + `QuickActionButton.tsx` (trim to 3, fix "2x2" comments, responsive grid)

**Interfaces:**
- Produces: "View All" navigates to `/provisioning/devices`; QuickActions renders exactly 3 actions with no empty cell.

- [ ] **Step 1: Wire "View All"** — add `onClick={() => navigate({ to: '/provisioning/devices' })}` (TanStack Router `useNavigate`) to the dead button at `PendingProvisionsCard.tsx:72-79`. Fix the stale "Resend/Generate" comment at `PendingItem.tsx:3` to "Manage".

- [ ] **Step 2: Trim Quick Actions** — keep Add User / Audit Log / Settings; change the grid to `grid-cols-1 sm:grid-cols-3` (no empty 4th cell); fix the "2x2 grid" comments in `QuickActionsCard.tsx:2` and `QuickActionButton.tsx:2,4`.

- [ ] **Step 3: Verify** — `just ui-build && just ui-lint` → PASS.

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/components/features/dashboard/PendingProvisionsCard.tsx src/frontend/src/components/features/dashboard/PendingItem.tsx src/frontend/src/components/features/dashboard/QuickActionsCard.tsx src/frontend/src/components/features/dashboard/QuickActionButton.tsx
git commit -m "fix(dashboard): wire View All, trim quick actions, drop stale comments"
```

---

### Task 16: Responsive layout, remove standalone health card, dead-code sweep

**Files:**
- Modify: `src/frontend/src/components/features/dashboard/DashboardGrid.tsx:15` (responsive grid)
- Modify: `src/frontend/src/routes/index.tsx` (remove `SystemHealthCard` from sidebar composition; remove `recentQR` invalidation `:56`)
- Delete: standalone `SystemHealthCard.tsx` usage (detail now lives in `HealthTile` — remove the sidebar instance; keep `HealthItem.tsx` if reused by `HealthTile`)
- Modify: `src/frontend/src/lib/queries/keys.ts:73` (remove orphaned `recentQR` key)

**Interfaces:** No new interfaces; layout + cleanup only.

- [ ] **Step 1: Responsive grid** — change `DashboardGrid.tsx:15` from `grid grid-cols-[1fr_380px]` to `grid grid-cols-1 lg:grid-cols-[1fr_minmax(320px,380px)]`; update the header comment.

- [ ] **Step 2: Remove the standalone health card** from the sidebar (its per-service detail is now the `HealthTile` expand). If `HealthTile` reuses `SystemHealthCard`'s grid markup, extract the shared `HealthItem` grid into a small subcomponent; otherwise delete `SystemHealthCard.tsx`.

- [ ] **Step 3: Dead-code sweep** — delete `dashboard.recentQR` (`keys.ts:73`) and the `isDashboardQuery('recentQR')` invalidation at `index.tsx:56` (leave the adjacent `'chart'` invalidation). Grep-confirm no remaining `recentQR` / `trends` / `active_sessions` / `success_rate` references in `src/frontend/`.

- [ ] **Step 4: Verify** — `just ui-build && just ui-lint && just ui-test-unit` → PASS; then load `/` at a mobile width (375px) and desktop and confirm no horizontal overflow (QA step; use gstack `/browse`).

- [ ] **Step 5: Commit**

```bash
git add src/frontend/src/components/features/dashboard/DashboardGrid.tsx src/frontend/src/routes/index.tsx src/frontend/src/lib/queries/keys.ts
git commit -m "refactor(dashboard): responsive layout + remove orphaned recentQR/health card"
```

---

## Phase E — Verification & handoff

### Task 17: Full-gate verification, e2e, arch guard

**Files:** none (verification only)

- [ ] **Step 1: Full PR gate** — `just pr-checks`. Expected: all green (ui-lint, ui-format-check, ui-build, ui-test-unit, ruff, mypy, `pytest tests/unit`).
- [ ] **Step 2: Backend integration** — `just up-bg && just test-quick -- tests/test_dashboard_api.py -v`. Expected: all dashboard cases pass (health-conditional, stats-shape, expires_at, statusCounts, activity-map).
- [ ] **Step 3: e2e / visual** — run the QA pipeline (qa-azblink skill) or `/browse` the dashboard: verify (a) no fake-zero tiles, (b) health panel shows only PostgreSQL/LDAP/Redis/Authentik (no XMPP/SIP rows), (c) compliance alerts visible + critical distinct, (d) users-by-status renders, (e) activity events show non-QR icons, (f) no horizontal overflow at 375px.
- [ ] **Step 4: Arch guard** — `just arch-guard` against the staged range; confirm the touched surfaces (`/api/dashboard/*`, `/api/provisions/pending`, `/api/users`) carry `Spec-Patch:`/`ARD:` trailers.
- [ ] **Step 5: Acceptance-criteria sign-off** — walk the design doc's Acceptance Criteria list; confirm each. Note the explicit out-of-scope item: XMPP/SIP are removed from health; real UC reachability probing is NOT covered (D1).

---

## Self-Review notes (author)

- **Spec coverage:** every design section maps to a task — hero (T11), users-by-status (T4+T13), compliance (T1 n/a; card T12; count logic T6), health XMPP/SIP drop (T1) + rollup (T8+T11), expiring (T3+T7+T11), activity both-feeds (T5+T9+T14), View All (T15), quick actions (T15), layout+responsive (T16), cleanup (T10/T11/T16), backend additive (T1–T5). Acceptance criteria checked in T17.
- **Vitest constraint honored:** only pure-logic tasks (T6–T9) carry vitest tests; component tasks verify via build/lint/e2e — no fabricated DOM tests.
- **Type consistency:** `ActivityIconKey` (T9) is the domain the `ActivityEventType` union (T10) and `ACTIVITY_ICON_STYLES` (T14) must cover; `statusCounts` keys are identical across T4/T10/T13; `expires_at` naming identical across T3/T7/T10/T11.
- **Ordering:** backend (T1–T5) lands first so frontend consumes real shapes; T10 types + T11 hero should land together if `ui-build` is red in isolation.
