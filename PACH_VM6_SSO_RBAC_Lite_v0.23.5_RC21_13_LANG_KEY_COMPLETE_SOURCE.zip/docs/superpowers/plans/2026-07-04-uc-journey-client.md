# UC Journey Client Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a launchable Python client that walks the whole UC journey — SSO login → device provision → credential unseal → XMPP connect → SIP register → verdict — headless-first, with an optional web GUI reusing `web-sso-provision-ref`.

**Architecture:** One core package (`journey/`) with fault-isolated leg modules and an orchestrator; a `cli.py` (headless, default) and `server.py` (optional `--gui`) are thin frontends over the same `runner.py`. Near-zero new protocol logic — OIDC-M2M, sealed-box unseal, slixmpp XMPP, and stdlib UDP SIP are ported from existing repo code (`tests/`, `tools/`).

**Tech Stack:** Python 3.13, `httpx` (OIDC + provision), `pynacl` (sealed-box), `slixmpp` (XMPP), stdlib `socket`/`hashlib` (SIP), stdlib `http.server` (GUI). All deps already in `tests/requirements.txt`.

**Spec:** `docs/superpowers/specs/2026-07-04-uc-journey-client-design.md`

## Global Constraints

- **Location:** everything under `tools/uc-journey-client/`. Run from that dir so `python -m journey` resolves.
- **Two-tier success (CI vs lab):** Tier 1 = SSO + provision + unseal (dev-stack-testable, the CI gate). Tier 2 = XMPP/SIP transport, requires external lab hosts (XMPP `192.168.122.89:5222` domain `private.z`; SIP UED `192.168.122.220:5060`). Tier-2 legs are **SKIPPED (not failed)** when no host is configured, unless `--require-transport`.
- **Provision contract (verbatim):** request `POST /api/provision/device` body `{publicKey: <base64 32-byte Curve25519>, deviceId: <str>, clientInfo: {platform, version, appName}}` + `Authorization: Bearer <OIDC access token>`. Response `{ok, uid, sealedCredentials, endpoints: {xmpp: {domain, wsUrl}, sip: {domain, wssUrl}}, provisioned, expiresAt}`; unsealed payload JSON `{xmppPassword, sipPassword, sipUsername}`.
- **OIDC M2M:** `client_credentials` grant at `{authentik_url}/application/o/token/` with `username` + `password=<app-password token>`. Client id `azblink-directory`.
- **deviceId:** `uc-journey-<user>` (stable, so re-runs reuse one device-cap slot).
- **Redaction:** credentials redacted by default in all output.
- **GUI:** static page binds `127.0.0.1` by default; the `/run/*` + `/events` endpoints are **loopback-only regardless of static bind**. Do NOT fork `web-sso-provision-ref/index.html` (it is drift-guarded by `just sso-ref-check`) — serve it unmodified + inject `journey-ext.js`.
- **Conventional commits** (repo uses commitizen); each task ends by committing.

---

### Task 1: Package scaffold — models, config, requirements

**Files:**
- Create: `tools/uc-journey-client/journey/__init__.py`
- Create: `tools/uc-journey-client/journey/models.py`
- Create: `tools/uc-journey-client/journey/config.py`
- Create: `tools/uc-journey-client/requirements.txt`
- Test: `tools/uc-journey-client/tests/test_config.py`

**Interfaces:**
- Produces:
  - `StepStatus` = `Enum("PASS", "FAIL", "SKIP")`
  - `@dataclass StepResult(name: str, status: StepStatus, detail: str = "", data: dict | None = None)`
  - `@dataclass XmppCreds(jid: str, password: str, domain: str, ws_url: str, host: str | None, port: int)`
  - `@dataclass SipCreds(user: str, password: str, domain: str, wss_url: str, host: str | None, port: int)`
  - `@dataclass CredKit(xmpp: XmppCreds, sip: SipCreds, uid: str, expires_at: str)`
  - `@dataclass Config(stack_url, authentik_url, user, login, app_token, xmpp_host, xmpp_port, xmpp_domain, sip_host, sip_port, legs, sip_invite, require_transport, json_out, gui, gui_port)` with a `Config.from_args(ns) -> Config` classmethod that layers env defaults.

- [ ] **Step 1: Write the failing test**

```python
# tools/uc-journey-client/tests/test_config.py
import os
from journey.config import Config
from journey.models import StepResult, StepStatus


def test_config_defaults_and_env(monkeypatch):
    monkeypatch.setenv("AUTHENTIK_APP_TOKEN", "tok-abc")
    monkeypatch.setenv("UC_XMPP_HOST", "192.168.122.89")
    cfg = Config.from_args_dict({"user": "alanl"})
    assert cfg.stack_url == "http://localhost:8081"
    assert cfg.authentik_url == "http://localhost:9000"
    assert cfg.user == "alanl"
    assert cfg.login == "m2m"
    assert cfg.app_token == "tok-abc"        # from env
    assert cfg.xmpp_host == "192.168.122.89"  # from env
    assert cfg.xmpp_domain == "private.z"
    assert cfg.legs == "provision"            # Tier-1 default
    assert cfg.device_id == "uc-journey-alanl"


def test_stepresult_holds_status():
    r = StepResult("sso", StepStatus.PASS, "token ok")
    assert r.status is StepStatus.PASS and r.name == "sso"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_config.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'journey'`

- [ ] **Step 3: Write models.py**

```python
# tools/uc-journey-client/journey/models.py
"""Value types for the UC journey client.
- StepStatus/StepResult: per-leg outcome
- XmppCreds/SipCreds/CredKit: assembled transport credentials + provenance
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum


class StepStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    SKIP = "SKIP"


@dataclass
class StepResult:
    name: str
    status: StepStatus
    detail: str = ""
    data: dict | None = None


@dataclass
class XmppCreds:
    jid: str
    password: str
    domain: str
    ws_url: str
    host: str | None
    port: int = 5222


@dataclass
class SipCreds:
    user: str
    password: str
    domain: str
    wss_url: str
    host: str | None
    port: int = 5060


@dataclass
class CredKit:
    xmpp: XmppCreds
    sip: SipCreds
    uid: str
    expires_at: str = ""
```

- [ ] **Step 4: Write config.py**

```python
# tools/uc-journey-client/journey/config.py
"""Runtime config for the journey client — flags layered over env defaults.
- from_args_dict: build Config from a parsed-args dict (CLI) or plain dict (tests)
- device_id is derived (uc-journey-<user>) so re-runs reuse one device-cap slot
"""
from __future__ import annotations
import os
from dataclasses import dataclass


def _split_hostport(value: str | None, default_port: int) -> tuple[str | None, int]:
    if not value:
        return None, default_port
    if ":" in value:
        host, port = value.rsplit(":", 1)
        return host, int(port)
    return value, default_port


@dataclass
class Config:
    stack_url: str
    authentik_url: str
    user: str
    login: str            # "m2m" | "browser"
    app_token: str | None
    xmpp_host: str | None
    xmpp_port: int
    xmpp_domain: str
    sip_host: str | None
    sip_port: int
    legs: str             # "provision" | "xmpp" | "sip" | "all"
    sip_invite: bool
    require_transport: bool
    json_out: bool
    gui: bool
    gui_port: int

    @property
    def device_id(self) -> str:
        return f"uc-journey-{self.user}"

    @classmethod
    def from_args_dict(cls, a: dict) -> "Config":
        xmpp_host, xmpp_port = _split_hostport(
            a.get("xmpp_host") or os.getenv("UC_XMPP_HOST"), 5222)
        sip_host, sip_port = _split_hostport(
            a.get("sip_host") or os.getenv("UC_SIP_HOST"), 5060)
        return cls(
            stack_url=a.get("stack_url") or os.getenv("UC_STACK_URL", "http://localhost:8081"),
            authentik_url=a.get("authentik_url") or os.getenv("UC_AUTHENTIK_URL", "http://localhost:9000"),
            user=a.get("user") or "alanl",
            login=a.get("login") or "m2m",
            app_token=a.get("app_token") or os.getenv("AUTHENTIK_APP_TOKEN"),
            xmpp_host=xmpp_host, xmpp_port=xmpp_port,
            xmpp_domain=a.get("xmpp_domain") or os.getenv("UC_XMPP_DOMAIN", "private.z"),
            sip_host=sip_host, sip_port=sip_port,
            legs=a.get("legs") or "provision",
            sip_invite=bool(a.get("sip_invite")),
            require_transport=bool(a.get("require_transport")),
            json_out=bool(a.get("json_out")),
            gui=bool(a.get("gui")),
            gui_port=int(a.get("gui_port") or 5173),
        )
```

- [ ] **Step 5: Write __init__.py and requirements.txt**

```python
# tools/uc-journey-client/journey/__init__.py
"""UC journey client — full SSO→provision→XMPP→SIP reference/test client."""
```

```text
# tools/uc-journey-client/requirements.txt
# All already present in tests/requirements.txt — pinned floors here for standalone runs.
httpx>=0.27
pynacl>=1.5
slixmpp>=1.16.0
```

- [ ] **Step 6: Run tests to verify they pass**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_config.py -v`
Expected: PASS (2 passed)

- [ ] **Step 7: Commit**

```bash
git add tools/uc-journey-client/journey/__init__.py tools/uc-journey-client/journey/models.py tools/uc-journey-client/journey/config.py tools/uc-journey-client/requirements.txt tools/uc-journey-client/tests/test_config.py
git commit -m "feat(uc-journey): scaffold package — models + config"
```

---

### Task 2: Extend seed to mint an app-password token (unblocks M2M)

**Why first:** every M2M path (Tasks 3, 9 smoke) needs a per-user app-password token. `just seed-uc-test-user` today only sets the login password. Fable finding [MED-HIGH].

**Files:**
- Modify: `tools/dev-seed-uc-user.py` (add token mint + print, after user/UC provisioning)
- Test: `tools/uc-journey-client/tests/test_seed_token.py`

**Interfaces:**
- Produces: after `just seed-uc-test-user`, an app-password token for `alanl` printed as `APP_TOKEN=<key>` and (idempotently) usable in the `client_credentials` grant.

- [ ] **Step 1: Read the existing seed structure**

Run: `grep -nE "def |authentik|/core/|token|alanl" tools/dev-seed-uc-user.py`
Expected: locate the Authentik API helper and the end-of-run summary print.

- [ ] **Step 2: Write the failing test**

```python
# tools/uc-journey-client/tests/test_seed_token.py
import os, subprocess, httpx, pytest

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))

@pytest.mark.external_network  # needs the dev stack up
def test_seed_prints_usable_app_token():
    out = subprocess.check_output(["just", "seed-uc-test-user"], cwd=REPO, text=True)
    line = next(l for l in out.splitlines() if l.startswith("APP_TOKEN="))
    token = line.split("=", 1)[1].strip()
    assert token
    # token authenticates the client_credentials grant
    r = httpx.post("http://localhost:9000/application/o/token/", data={
        "grant_type": "client_credentials", "client_id": "azblink-directory",
        "username": "alanl", "password": token, "scope": "openid profile email"})
    assert r.status_code == 200 and "access_token" in r.json()
```

- [ ] **Step 3: Run test to verify it fails**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_seed_token.py -v -m external_network`
Expected: FAIL — no `APP_TOKEN=` line in seed output.

- [ ] **Step 4: Add token minting to the seed script**

In `tools/dev-seed-uc-user.py`, after the user is provisioned, add (reusing the same Authentik API helper the file already defines — match its function name; pattern taken verbatim from `tests/conftest.py:259-271`):

```python
def _mint_app_token(user_pk: int, identifier: str = "uc-journey-alanl") -> str:
    """Idempotently mint an app-password token and return its key.
    - Mirrors tests/conftest.py: POST /core/tokens/ then GET .../view_key/
    - Delete-then-create keeps it idempotent across re-runs.
    """
    _authentik_api("DELETE", f"/core/tokens/{identifier}/")  # best-effort; ignore 404
    _authentik_api("POST", "/core/tokens/", {
        "identifier": identifier, "intent": "app_password", "user": user_pk})
    return _authentik_api("GET", f"/core/tokens/{identifier}/view_key/")["key"]
```

Call it after provisioning `alanl` (use the resolved Authentik user pk the script already has) and print at the end:

```python
    app_token = _mint_app_token(alanl_pk)
    print(f"APP_TOKEN={app_token}")
```

Wrap the `DELETE` best-effort (`try/except`) so a missing token on first run doesn't abort.

- [ ] **Step 5: Run test to verify it passes**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_seed_token.py -v -m external_network`
Expected: PASS (dev stack up)

- [ ] **Step 6: Commit**

```bash
git add tools/dev-seed-uc-user.py tools/uc-journey-client/tests/test_seed_token.py
git commit -m "feat(uc-journey): mint app-password token in seed for M2M auth"
```

---

### Task 3: OIDC module — M2M token + PKCE pair

**Files:**
- Create: `tools/uc-journey-client/journey/oidc.py`
- Test: `tools/uc-journey-client/tests/test_oidc.py`

**Interfaces:**
- Consumes: `Config`
- Produces:
  - `pkce_pair() -> tuple[str, str]` (verifier, S256 challenge)
  - `get_token_m2m(cfg: Config) -> str` (access token via client_credentials)
  - `get_token_browser(cfg: Config) -> str` (opens system browser to Authentik, catches loopback code on `:5173`, exchanges) — implemented here; exercised only under `--gui`/manual.

- [ ] **Step 1: Write the failing test**

```python
# tools/uc-journey-client/tests/test_oidc.py
import base64, hashlib
import httpx
from journey import oidc
from journey.config import Config


def test_pkce_pair_is_valid_s256():
    verifier, challenge = oidc.pkce_pair()
    expected = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    assert challenge == expected
    assert "=" not in verifier and "=" not in challenge  # url-safe, unpadded


def test_get_token_m2m_builds_client_credentials(monkeypatch):
    captured = {}
    def fake_post(url, data=None, **kw):
        captured["url"] = url; captured["data"] = data
        return httpx.Response(200, json={"access_token": "AT-123"})
    monkeypatch.setattr(httpx, "post", fake_post)
    cfg = Config.from_args_dict({"user": "alanl", "app_token": "tok"})
    tok = oidc.get_token_m2m(cfg)
    assert tok == "AT-123"
    assert captured["url"].endswith("/application/o/token/")
    assert captured["data"]["grant_type"] == "client_credentials"
    assert captured["data"]["username"] == "alanl"
    assert captured["data"]["password"] == "tok"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_oidc.py -v`
Expected: FAIL — `No module named 'journey.oidc'`

- [ ] **Step 3: Write oidc.py**

```python
# tools/uc-journey-client/journey/oidc.py
"""OIDC token acquisition.
- get_token_m2m: client_credentials + app-password token (CI path; port of conftest)
- get_token_browser: PKCE S256 via system browser + loopback :5173 (real SSO; new code)
- pkce_pair: RFC 7636 S256 verifier/challenge
"""
from __future__ import annotations
import base64, hashlib, http.server, secrets, threading, urllib.parse, webbrowser
import httpx
from .config import Config

CLIENT_ID = "azblink-directory"


def pkce_pair() -> tuple[str, str]:
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode()
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge


def get_token_m2m(cfg: Config) -> str:
    if not cfg.app_token:
        raise SystemExit("m2m login needs --app-token / AUTHENTIK_APP_TOKEN "
                         "(run `just seed-uc-test-user` to mint one)")
    resp = httpx.post(
        f"{cfg.authentik_url}/application/o/token/",
        data={"grant_type": "client_credentials", "client_id": CLIENT_ID,
              "username": cfg.user, "password": cfg.app_token,
              "scope": "openid profile email"},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_token_browser(cfg: Config) -> str:
    """PKCE flow: open browser to Authentik, catch code on http://localhost:5173/callback.
    5173 is the only pre-registered loopback (seed_authentik.py strict-match).
    """
    verifier, challenge = pkce_pair()
    state = secrets.token_urlsafe(16)
    redirect = "http://localhost:5173/callback"
    disc = httpx.get(f"{cfg.authentik_url}/application/o/azblink-directory/"
                     f".well-known/openid-configuration", timeout=15).json()
    auth_url = disc["authorization_endpoint"] + "?" + urllib.parse.urlencode({
        "response_type": "code", "client_id": CLIENT_ID, "redirect_uri": redirect,
        "scope": "openid profile email", "state": state,
        "code_challenge": challenge, "code_challenge_method": "S256"})

    box: dict[str, str] = {}
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if "code" in q:
                box["code"] = q["code"][0]
            self.send_response(200); self.end_headers()
            self.wfile.write(b"You may close this tab.")
        def log_message(self, *a):  # silence
            pass

    srv = http.server.HTTPServer(("127.0.0.1", 5173), H)
    threading.Thread(target=srv.handle_request, daemon=True).start()
    webbrowser.open(auth_url)
    srv.serve_forever() if False else None
    # handle_request above serves exactly one request; wait for it
    while "code" not in box:
        pass
    srv.server_close()
    tok = httpx.post(disc["token_endpoint"], data={
        "grant_type": "authorization_code", "code": box["code"],
        "redirect_uri": redirect, "client_id": CLIENT_ID,
        "code_verifier": verifier}, timeout=30)
    tok.raise_for_status()
    return tok.json()["access_token"]
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_oidc.py -v`
Expected: PASS (2 passed). `get_token_browser` is not unit-tested (manual/GUI path).

- [ ] **Step 5: Commit**

```bash
git add tools/uc-journey-client/journey/oidc.py tools/uc-journey-client/tests/test_oidc.py
git commit -m "feat(uc-journey): OIDC M2M token + PKCE pair"
```

---

### Task 4: Provision + unseal + CredKit assembly

**Files:**
- Create: `tools/uc-journey-client/journey/provision.py`
- Test: `tools/uc-journey-client/tests/test_provision.py`

**Interfaces:**
- Consumes: `Config`, an OIDC access token (str), `CredKit`/`XmppCreds`/`SipCreds` from Task 1
- Produces:
  - `provision(cfg: Config, token: str) -> CredKit` — POST /api/provision/device, unseal, assemble
  - `_unseal(sealed_b64_or_hex: str, private_key: nacl.public.PrivateKey) -> dict` (internal, tested)

- [ ] **Step 1: Write the failing test** (round-trips a real sealed-box locally — no stack needed)

```python
# tools/uc-journey-client/tests/test_provision.py
import base64, json
import nacl.public
from journey.provision import _unseal, assemble_credkit
from journey.config import Config


def test_unseal_roundtrip():
    sk = nacl.public.PrivateKey.generate()
    payload = {"xmppPassword": "xp", "sipPassword": "sp", "sipUsername": "alanl"}
    sealed = nacl.public.SealedBox(sk.public_key).encrypt(json.dumps(payload).encode())
    sealed_b64 = base64.b64encode(sealed).decode()
    assert _unseal(sealed_b64, sk) == payload


def test_assemble_credkit_provenance():
    cfg = Config.from_args_dict({"user": "alanl", "xmpp_host": "192.168.122.89",
                                 "sip_host": "192.168.122.220", "xmpp_domain": "private.z"})
    resp = {"uid": "alanl", "expiresAt": "2026-01-01T00:00:00Z",
            "endpoints": {"xmpp": {"domain": "xmpp.azblink.com", "wsUrl": "wss://x/ws"},
                          "sip": {"domain": "sip.azblink.com", "wssUrl": "wss://s/ws"}}}
    creds = {"xmppPassword": "xp", "sipPassword": "sp", "sipUsername": "alanl"}
    kit = assemble_credkit(cfg, resp, creds)
    assert kit.xmpp.password == "xp" and kit.sip.password == "sp"
    assert kit.xmpp.host == "192.168.122.89"           # from flag, NOT response
    assert kit.xmpp.jid == "alanl@private.z"           # sipUsername @ --xmpp-domain
    assert kit.sip.user == "alanl" and kit.sip.host == "192.168.122.220"
    assert kit.uid == "alanl"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_provision.py -v`
Expected: FAIL — `No module named 'journey.provision'`

- [ ] **Step 3: Write provision.py**

```python
# tools/uc-journey-client/journey/provision.py
"""Device provisioning + sealed-box unseal + CredKit assembly.
- provision: POST /api/provision/device (base64 Curve25519 pubkey) with Bearer token
- _unseal: libsodium sealed-box open (PyNaCl) of sealedCredentials
- assemble_credkit: merge unsealed secrets + response endpoints + client flags (provenance)
"""
from __future__ import annotations
import base64, binascii, json
import httpx
import nacl.public
from .config import Config
from .models import CredKit, XmppCreds, SipCreds


def _decode(s: str) -> bytes:
    try:
        return base64.b64decode(s, validate=True)
    except (binascii.Error, ValueError):
        return bytes.fromhex(s)  # backend may hex-encode; index.html §4 confirms encoding


def _unseal(sealed: str, private_key: nacl.public.PrivateKey) -> dict:
    plaintext = nacl.public.SealedBox(private_key).decrypt(_decode(sealed))
    return json.loads(plaintext)


def assemble_credkit(cfg: Config, resp: dict, creds: dict) -> CredKit:
    ep = resp.get("endpoints", {})
    xe, se = ep.get("xmpp", {}), ep.get("sip", {})
    user = creds["sipUsername"]
    return CredKit(
        uid=resp.get("uid", cfg.user),
        expires_at=resp.get("expiresAt", ""),
        xmpp=XmppCreds(
            jid=f"{user}@{cfg.xmpp_domain}", password=creds["xmppPassword"],
            domain=cfg.xmpp_domain, ws_url=xe.get("wsUrl", ""),
            host=cfg.xmpp_host, port=cfg.xmpp_port),
        sip=SipCreds(
            user=user, password=creds["sipPassword"],
            domain=se.get("domain", ""), wss_url=se.get("wssUrl", ""),
            host=cfg.sip_host, port=cfg.sip_port),
    )


def provision(cfg: Config, token: str) -> CredKit:
    sk = nacl.public.PrivateKey.generate()
    pub_b64 = base64.b64encode(bytes(sk.public_key)).decode()
    resp = httpx.post(
        f"{cfg.stack_url}/api/provision/device",
        headers={"Authorization": f"Bearer {token}"},
        json={"publicKey": pub_b64, "deviceId": cfg.device_id,
              "clientInfo": {"platform": "cli", "version": "1.0",
                             "appName": "uc-journey-client"}},
        timeout=30,
    )
    resp.raise_for_status()
    body = resp.json()
    creds = _unseal(body["sealedCredentials"], sk)
    return assemble_credkit(cfg, body, creds)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_provision.py -v`
Expected: PASS (2 passed)

- [ ] **Step 5: Commit**

```bash
git add tools/uc-journey-client/journey/provision.py tools/uc-journey-client/tests/test_provision.py
git commit -m "feat(uc-journey): device provision + sealed-box unseal + CredKit"
```

---

### Task 5: SIP leg — stdlib UDP REGISTER + digest

Port `tests/test_sip_ring_e2e.py` helpers verbatim (they already handle qop per RFC 2617).

**Files:**
- Create: `tools/uc-journey-client/journey/sip_leg.py`
- Test: `tools/uc-journey-client/tests/test_sip_leg.py`

**Interfaces:**
- Consumes: `SipCreds`, `Config`
- Produces: `run_sip(cfg: Config, sip: SipCreds) -> StepResult` (SKIP if `sip.host` is None and not `require_transport`)

- [ ] **Step 1: Write the failing test** (digest is deterministic → unit-testable; REGISTER is lab-gated)

```python
# tools/uc-journey-client/tests/test_sip_leg.py
import hashlib
from journey.sip_leg import _digest_response, run_sip
from journey.models import SipCreds, StepStatus
from journey.config import Config


def test_digest_response_rfc2617_no_qop():
    # ha1=md5(user:realm:pw), ha2=md5(method:uri), resp=md5(ha1:nonce:ha2)
    md5 = lambda s: hashlib.md5(s.encode()).hexdigest()
    ha1 = md5("alanl:asterisk:pw"); ha2 = md5("REGISTER:sip:host")
    expected = md5(f"{ha1}:NONCE:{ha2}")
    assert _digest_response("alanl", "asterisk", "pw", "REGISTER", "sip:host", "NONCE") == expected


def test_run_sip_skips_without_host():
    cfg = Config.from_args_dict({"user": "alanl"})  # no sip_host
    sip = SipCreds(user="alanl", password="pw", domain="", wss_url="", host=None)
    r = run_sip(cfg, sip)
    assert r.status is StepStatus.SKIP
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_sip_leg.py -v`
Expected: FAIL — `No module named 'journey.sip_leg'`

- [ ] **Step 3: Write sip_leg.py** — copy the proven functions from `tests/test_sip_ring_e2e.py:41-213` (`_md5`, `_digest_response`, `_build_auth_header`, `_parse_digest`, `_parse_status`, `_header`, and the `SipClient` class with `register()`), then wrap in `run_sip`:

```python
# tools/uc-journey-client/journey/sip_leg.py
"""SIP transport leg — stdlib UDP REGISTER with MD5 digest (RFC 2617, qop-aware).
Ported verbatim from tests/test_sip_ring_e2e.py:41-213. Lab-gated: needs --sip-host.
"""
from __future__ import annotations
import hashlib, os, re, socket, uuid
from .config import Config
from .models import SipCreds, StepResult, StepStatus

SIP_TIMEOUT = 6.0


def _md5(s: str) -> str:
    return hashlib.md5(s.encode(), usedforsecurity=False).hexdigest()

# ---- paste verbatim from test_sip_ring_e2e.py:45-118 ----
#   _digest_response, _build_auth_header, _parse_digest, _parse_status, _header
# ---- paste verbatim from test_sip_ring_e2e.py:121-213 ----
#   class SipClient (constructor takes ued_ip/ued_port; register())
#   NOTE: replace module constants UED_IP/UED_SIP_PORT/LOCAL_BIND_IP with
#   the values passed into run_sip (sip.host / sip.port / "0.0.0.0").


def run_sip(cfg: Config, sip: SipCreds) -> StepResult:
    if not sip.host:
        if cfg.require_transport:
            return StepResult("sip", StepStatus.FAIL, "no --sip-host but --require-transport")
        return StepResult("sip", StepStatus.SKIP, "no --sip-host (lab-gated)")
    client = SipClient(sip.user, sip.password, ued_ip=sip.host, ued_port=sip.port)
    try:
        status, _ = client.register()
        if status == 200:
            return StepResult("sip", StepStatus.PASS, "REGISTER 200 OK")
        return StepResult("sip", StepStatus.FAIL, f"REGISTER -> {status}")
    except (OSError, socket.timeout) as e:
        return StepResult("sip", StepStatus.FAIL, f"REGISTER error: {e}")
    finally:
        client.close()
```

(Do NOT re-derive the digest — paste the exact functions. INVITE from `:215-295` is optional; add a `--sip-invite` branch only if Task 9 wires the flag.)

- [ ] **Step 4: Run tests to verify they pass**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_sip_leg.py -v`
Expected: PASS (2 passed)

- [ ] **Step 5: Commit**

```bash
git add tools/uc-journey-client/journey/sip_leg.py tools/uc-journey-client/tests/test_sip_leg.py
git commit -m "feat(uc-journey): SIP REGISTER leg (stdlib UDP digest)"
```

---

### Task 6: XMPP leg — slixmpp connect + SASL PLAIN

**Files:**
- Create: `tools/uc-journey-client/journey/xmpp_leg.py`
- Test: `tools/uc-journey-client/tests/test_xmpp_leg.py`

**Interfaces:**
- Consumes: `XmppCreds`, `Config`
- Produces: `run_xmpp(cfg: Config, xmpp: XmppCreds) -> StepResult` (SKIP without `xmpp.host`)

- [ ] **Step 1: Write the failing test** (skip path is unit-testable; live connect is lab-gated)

```python
# tools/uc-journey-client/tests/test_xmpp_leg.py
from journey.xmpp_leg import run_xmpp
from journey.models import XmppCreds, StepStatus
from journey.config import Config


def test_run_xmpp_skips_without_host():
    cfg = Config.from_args_dict({"user": "alanl"})
    x = XmppCreds(jid="alanl@private.z", password="pw", domain="private.z",
                  ws_url="", host=None)
    assert run_xmpp(cfg, x).status is StepStatus.SKIP
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_xmpp_leg.py -v`
Expected: FAIL — `No module named 'journey.xmpp_leg'`

- [ ] **Step 3: Write xmpp_leg.py** (slixmpp pattern from `tools/e2e_xmpp_notebook.py:310-330,964`; construct `ClientXMPP` INSIDE the asyncio loop — Fable note)

```python
# tools/uc-journey-client/journey/xmpp_leg.py
"""XMPP transport leg — slixmpp connect + SASL PLAIN bind (dev servers have no TLS).
Pattern from tools/e2e_xmpp_notebook.py. Lab-gated: needs --xmpp-host.
"""
from __future__ import annotations
import asyncio
import slixmpp
from .config import Config
from .models import XmppCreds, StepResult, StepStatus


def _connect_once(jid: str, password: str, host: str, port: int) -> bool:
    """Return True if session established. ClientXMPP is built inside this loop
    (it binds the running loop at init — Fable finding on asyncio)."""
    async def _run() -> bool:
        client = slixmpp.ClientXMPP(jid, password)
        client["feature_mechanisms"].unencrypted_plain = True  # dev only, no TLS
        done: asyncio.Future = asyncio.get_event_loop().create_future()
        client.add_event_handler("session_start", lambda _: done.set_result(True))
        client.add_event_handler("failed_auth", lambda _: done.set_result(False))
        client.connect(host=host, port=port)
        try:
            return await asyncio.wait_for(done, timeout=10)
        finally:
            client.disconnect()
    return asyncio.run(_run())


def run_xmpp(cfg: Config, xmpp: XmppCreds) -> StepResult:
    if not xmpp.host:
        if cfg.require_transport:
            return StepResult("xmpp", StepStatus.FAIL, "no --xmpp-host but --require-transport")
        return StepResult("xmpp", StepStatus.SKIP, "no --xmpp-host (lab-gated)")
    try:
        ok = _connect_once(xmpp.jid, xmpp.password, xmpp.host, xmpp.port)
    except Exception as e:  # slixmpp raises varied transport errors
        return StepResult("xmpp", StepStatus.FAIL, f"connect error: {e}")
    return StepResult("xmpp", StepStatus.PASS if ok else StepStatus.FAIL,
                      "SASL bind ok" if ok else "SASL bind failed")
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_xmpp_leg.py -v`
Expected: PASS (1 passed)

- [ ] **Step 5: Commit**

```bash
git add tools/uc-journey-client/journey/xmpp_leg.py tools/uc-journey-client/tests/test_xmpp_leg.py
git commit -m "feat(uc-journey): XMPP SASL-PLAIN connect leg (slixmpp)"
```

---

### Task 7: Runner — orchestrate, verdict, exit code

**Files:**
- Create: `tools/uc-journey-client/journey/runner.py`
- Test: `tools/uc-journey-client/tests/test_runner.py`

**Interfaces:**
- Consumes: `Config`, `oidc`, `provision`, `run_xmpp`, `run_sip`
- Produces:
  - `run_journey(cfg, *, get_token, do_provision, xmpp_leg, sip_leg) -> list[StepResult]` (deps injected for testability)
  - `verdict(results) -> int` (0 if no FAIL, else 1; SKIP is not a failure)

- [ ] **Step 1: Write the failing test**

```python
# tools/uc-journey-client/tests/test_runner.py
from journey.runner import run_journey, verdict
from journey.models import StepResult, StepStatus, CredKit, XmppCreds, SipCreds
from journey.config import Config


def _kit():
    return CredKit(uid="alanl", xmpp=XmppCreds("a@private.z", "p", "private.z", "", None),
                   sip=SipCreds("alanl", "p", "", "", None))


def test_provision_only_skips_transport():
    cfg = Config.from_args_dict({"user": "alanl", "app_token": "t", "legs": "provision"})
    res = run_journey(cfg,
        get_token=lambda c: "AT", do_provision=lambda c, t: _kit(),
        xmpp_leg=lambda c, x: StepResult("xmpp", StepStatus.PASS),
        sip_leg=lambda c, s: StepResult("sip", StepStatus.PASS))
    names = {r.name: r.status for r in res}
    assert names["sso"] is StepStatus.PASS and names["provision"] is StepStatus.PASS
    assert "xmpp" not in names and "sip" not in names   # provision-only
    assert verdict(res) == 0


def test_verdict_fails_on_any_fail():
    res = [StepResult("sso", StepStatus.PASS), StepResult("sip", StepStatus.FAIL),
           StepResult("xmpp", StepStatus.SKIP)]
    assert verdict(res) == 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_runner.py -v`
Expected: FAIL — `No module named 'journey.runner'`

- [ ] **Step 3: Write runner.py**

```python
# tools/uc-journey-client/journey/runner.py
"""Journey orchestrator: SSO -> provision -> (xmpp, sip). Legs injected for tests.
- run_journey: ordered execution; a failed leg records + continues (full picture)
- verdict: exit 0 unless any StepResult is FAIL (SKIP never fails)
"""
from __future__ import annotations
from .config import Config
from .models import StepResult, StepStatus


def run_journey(cfg: Config, *, get_token, do_provision, xmpp_leg, sip_leg) -> list[StepResult]:
    results: list[StepResult] = []
    try:
        token = get_token(cfg)
        results.append(StepResult("sso", StepStatus.PASS, "token acquired"))
    except Exception as e:
        results.append(StepResult("sso", StepStatus.FAIL, str(e)))
        return results
    try:
        kit = do_provision(cfg, token)
        results.append(StepResult("provision", StepStatus.PASS, f"uid={kit.uid}", {"uid": kit.uid}))
    except Exception as e:
        results.append(StepResult("provision", StepStatus.FAIL, str(e)))
        return results
    if cfg.legs in ("xmpp", "all"):
        results.append(xmpp_leg(cfg, kit.xmpp))
    if cfg.legs in ("sip", "all"):
        results.append(sip_leg(cfg, kit.sip))
    return results


def verdict(results: list[StepResult]) -> int:
    return 1 if any(r.status is StepStatus.FAIL for r in results) else 0
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_runner.py -v`
Expected: PASS (2 passed)

- [ ] **Step 5: Commit**

```bash
git add tools/uc-journey-client/journey/runner.py tools/uc-journey-client/tests/test_runner.py
git commit -m "feat(uc-journey): runner orchestration + verdict"
```

---

### Task 8: CLI — argparse, report table, exit code, `just` recipe

**Files:**
- Create: `tools/uc-journey-client/journey/__main__.py`
- Create: `tools/uc-journey-client/cli.py`
- Create: `tools/uc-journey-client/journey/report.py`
- Modify: `Justfile` (add `uc-journey` recipe)
- Test: `tools/uc-journey-client/tests/test_cli.py`

**Interfaces:**
- Consumes: everything above
- Produces: `build_parser() -> argparse.ArgumentParser`; `main(argv=None) -> int`; `render_table(results, *, redact=True) -> str`

- [ ] **Step 1: Write the failing test**

```python
# tools/uc-journey-client/tests/test_cli.py
from journey.report import render_table
from journey.models import StepResult, StepStatus
from cli import build_parser


def test_parser_defaults():
    ns = build_parser().parse_args(["--user", "alanl"])
    assert ns.login == "m2m" and ns.legs == "provision"


def test_render_table_redacts_and_marks_status():
    out = render_table([StepResult("sso", StepStatus.PASS, "token=abcdef")], redact=True)
    assert "PASS" in out and "sso" in out and "abcdef" not in out  # redacted
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_cli.py -v`
Expected: FAIL — `No module named 'cli'` / `journey.report`

- [ ] **Step 3: Write report.py**

```python
# tools/uc-journey-client/journey/report.py
"""Render StepResult list as a table or JSON; redact secrets by default."""
from __future__ import annotations
import json, re
from .models import StepResult

_SECRET = re.compile(r"(token|password|key)\S*", re.I)


def _redact(text: str, redact: bool) -> str:
    return _SECRET.sub(r"\1=***", text) if redact else text


def render_table(results: list[StepResult], *, redact: bool = True) -> str:
    rows = [f"  {r.status.value:4}  {r.name:10}  {_redact(r.detail, redact)}" for r in results]
    return "UC Journey\n" + "\n".join(rows)


def render_json(results: list[StepResult]) -> str:
    return json.dumps([{"name": r.name, "status": r.status.value, "detail": r.detail}
                       for r in results], indent=2)
```

- [ ] **Step 4: Write cli.py + __main__.py**

```python
# tools/uc-journey-client/cli.py
"""Headless entrypoint for the UC journey client. `--gui` delegates to server.py."""
from __future__ import annotations
import argparse, sys
from journey.config import Config
from journey import oidc, provision as prov, report
from journey.runner import run_journey, verdict
from journey.xmpp_leg import run_xmpp
from journey.sip_leg import run_sip


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="uc-journey")
    p.add_argument("--stack-url"); p.add_argument("--authentik-url")
    p.add_argument("--user"); p.add_argument("--app-token", dest="app_token")
    p.add_argument("--login", choices=["m2m", "browser"])
    p.add_argument("--legs", choices=["provision", "xmpp", "sip", "all"])
    p.add_argument("--xmpp-host", dest="xmpp_host"); p.add_argument("--xmpp-domain", dest="xmpp_domain")
    p.add_argument("--sip-host", dest="sip_host"); p.add_argument("--sip-invite", action="store_true")
    p.add_argument("--require-transport", dest="require_transport", action="store_true")
    p.add_argument("--json", dest="json_out", action="store_true")
    p.add_argument("--gui", action="store_true"); p.add_argument("--gui-port", dest="gui_port")
    return p


def main(argv=None) -> int:
    ns = build_parser().parse_args(argv)
    cfg = Config.from_args_dict(vars(ns))
    if cfg.gui:
        from server import serve
        return serve(cfg)
    get_token = oidc.get_token_browser if cfg.login == "browser" else oidc.get_token_m2m
    results = run_journey(cfg, get_token=get_token, do_provision=prov.provision,
                          xmpp_leg=run_xmpp, sip_leg=run_sip)
    print(report.render_json(results) if cfg.json_out else report.render_table(results))
    return verdict(results)


if __name__ == "__main__":
    sys.exit(main())
```

```python
# tools/uc-journey-client/journey/__main__.py
"""`python -m journey` → CLI."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from cli import main  # noqa: E402
sys.exit(main())
```

- [ ] **Step 5: Add the `just` recipe** — append to `Justfile`:

```make
# Run the UC journey client headless (Tier-1: SSO+provision). Needs dev stack + seeded app-token.
uc-journey *ARGS:
    cd tools/uc-journey-client && python -m journey {{ARGS}}
```

- [ ] **Step 6: Run tests + a live Tier-1 smoke**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_cli.py -v`
Expected: PASS (2 passed)

Live smoke (dev stack up + `just seed-uc-test-user` run to get `APP_TOKEN`):
Run: `AUTHENTIK_APP_TOKEN=<key> just uc-journey --user alanl --legs provision`
Expected: table shows `PASS sso`, `PASS provision`; exit 0.

- [ ] **Step 7: Commit**

```bash
git add tools/uc-journey-client/cli.py tools/uc-journey-client/journey/__main__.py tools/uc-journey-client/journey/report.py Justfile tools/uc-journey-client/tests/test_cli.py
git commit -m "feat(uc-journey): CLI + report + just recipe"
```

---

### Task 9: CI smoke test (Tier-1, stack-only)

**Files:**
- Create: `tools/uc-journey-client/tests/test_smoke_journey.py`

**Interfaces:**
- Consumes: `cli.main`, the seeded app-token from Task 2

- [ ] **Step 1: Write the test** (this IS the deliverable — a passing Tier-1 journey)

```python
# tools/uc-journey-client/tests/test_smoke_journey.py
"""Tier-1 CI gate: SSO -> provision -> unseal against the dev stack. No lab host."""
import os, subprocess, pytest
REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))


@pytest.mark.external_network  # needs dev stack (not a lab host — the local stack)
def test_tier1_journey_exit_zero():
    token = None
    for line in subprocess.check_output(["just", "seed-uc-test-user"], cwd=REPO, text=True).splitlines():
        if line.startswith("APP_TOKEN="):
            token = line.split("=", 1)[1].strip()
    assert token, "seed did not print APP_TOKEN"
    from cli import main
    rc = main(["--user", "alanl", "--app-token", token, "--legs", "provision"])
    assert rc == 0
```

- [ ] **Step 2: Run it to verify it passes** (dev stack up)

Run: `cd tools/uc-journey-client && python -m pytest tests/test_smoke_journey.py -v -m external_network`
Expected: PASS — exit 0 (SSO + provision green)

- [ ] **Step 3: Commit**

```bash
git add tools/uc-journey-client/tests/test_smoke_journey.py
git commit -m "test(uc-journey): Tier-1 stack-only smoke (SSO+provision)"
```

---

### Task 10: Optional web GUI — server + extension script

**Files:**
- Create: `tools/uc-journey-client/server.py`
- Create: `tools/uc-journey-client/web/journey-ext.js`
- Test: `tools/uc-journey-client/tests/test_server.py`

**Interfaces:**
- Consumes: `Config`, `run_xmpp`, `run_sip`, `models`
- Produces: `serve(cfg: Config) -> int`; the handler exposes `POST /run/xmpp`, `POST /run/sip` (JSON verdict), `GET /events` (SSE), and serves the unmodified `web-sso-provision-ref/index.html` + injects `journey-ext.js`.

- [ ] **Step 1: Write the failing test** (POST endpoints are request-level testable with a stub leg)

```python
# tools/uc-journey-client/tests/test_server.py
import json, threading, http.client
from journey.config import Config
import server


def test_run_sip_endpoint_returns_verdict(monkeypatch):
    from journey.models import StepResult, StepStatus
    monkeypatch.setattr(server, "run_sip", lambda cfg, s: StepResult("sip", StepStatus.PASS, "200"))
    cfg = Config.from_args_dict({"user": "alanl", "sip_host": "1.2.3.4", "gui_port": 5199})
    httpd = server.build_server(cfg)
    threading.Thread(target=httpd.handle_request, daemon=True).start()
    c = http.client.HTTPConnection("127.0.0.1", 5199); 
    c.request("POST", "/run/sip", json.dumps({"user": "alanl", "password": "p"}),
              {"Content-Type": "application/json"})
    body = json.loads(c.getresponse().read())
    assert body["status"] == "PASS"
    httpd.server_close()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_server.py -v`
Expected: FAIL — `No module named 'server'`

- [ ] **Step 3: Write server.py** (extend web-sso-ref's SPA handler with POST + SSE; `/run/*` loopback-only; build `ClientXMPP`/leg inside the request thread)

```python
# tools/uc-journey-client/server.py
"""Optional GUI server: serve the web-sso-ref page (unmodified) + journey-ext.js,
plus POST /run/xmpp, /run/sip (blocking JSON verdict) and GET /events (SSE progress).
- /run/* + /events are 127.0.0.1-only regardless of static bind (unsealed creds).
- Reuses web-sso-provision-ref/index.html — never forks it (drift guard).
"""
from __future__ import annotations
import json, os
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from journey.config import Config
from journey.models import XmppCreds, SipCreds, StepResult, StepStatus
from journey.xmpp_leg import run_xmpp
from journey.sip_leg import run_sip

SSO_REF = os.path.abspath(os.path.join(os.path.dirname(__file__), "../web-sso-provision-ref"))


def _make_handler(cfg: Config):
    class H(SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=SSO_REF, **k)

        def _json(self, code: int, obj: dict):
            data = json.dumps(obj).encode()
            self.send_response(code); self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data))); self.end_headers()
            self.wfile.write(data)

        def _loopback_only(self) -> bool:
            return self.client_address[0] in ("127.0.0.1", "::1")

        def do_POST(self):  # noqa: N802
            if self.path not in ("/run/xmpp", "/run/sip"):
                return self._json(404, {"error": "not found"})
            if not self._loopback_only():
                return self._json(403, {"error": "loopback only"})
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            if self.path == "/run/xmpp":
                r = run_xmpp(cfg, XmppCreds(jid=body["jid"], password=body["password"],
                             domain=cfg.xmpp_domain, ws_url="", host=cfg.xmpp_host, port=cfg.xmpp_port))
            else:
                r = run_sip(cfg, SipCreds(user=body["user"], password=body["password"],
                            domain="", wss_url="", host=cfg.sip_host, port=cfg.sip_port))
            self._json(200, {"name": r.name, "status": r.status.value, "detail": r.detail})

        def do_GET(self):  # noqa: N802
            if self.path == "/callback" or (not os.path.splitext(self.path)[1] and self.path != "/"):
                self.path = "/index.html"  # SPA fallback (mirror web-sso-ref/server.py)
            super().do_GET()
    return H


def build_server(cfg: Config) -> ThreadingHTTPServer:
    return ThreadingHTTPServer(("127.0.0.1", cfg.gui_port), _make_handler(cfg))


def serve(cfg: Config) -> int:
    httpd = build_server(cfg)
    print(f"UC journey GUI: http://localhost:{cfg.gui_port}  (Ctrl+C to stop)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0
```

- [ ] **Step 4: Write journey-ext.js** — injected extension that adds §5/§6 to the served page, overrides deviceId, and calls the core:

```javascript
// tools/uc-journey-client/web/journey-ext.js
// Extends the web-sso-ref page: after unseal (§4), run XMPP (§5) + SIP (§6) via the core.
// Overrides deviceId to uc-journey-<user> so it uses its own device-cap slot.
window.UC_JOURNEY_DEVICE_ID = (u) => `uc-journey-${u}`;
async function ucRun(path, creds) {
  const r = await fetch(path, {method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(creds)});
  return r.json();
}
window.ucRunXmpp = (jid, password) => ucRun('/run/xmpp', {jid, password});
window.ucRunSip = (user, password) => ucRun('/run/sip', {user, password});
// UI wiring (buttons for §5/§6 that render {status, detail}) — append to the page's
// section container; keep the existing redaction toggle. See README for the DOM hooks.
```

(The page loads this via `<script src="/journey-ext.js">` — add that one line by serving a tiny wrapper, OR document injecting it through the served index. Keep index.html itself untouched.)

- [ ] **Step 5: Run tests to verify they pass**

Run: `cd tools/uc-journey-client && python -m pytest tests/test_server.py -v`
Expected: PASS (1 passed)

- [ ] **Step 6: Manual GUI check** (optional, lab): `just uc-journey --gui --sip-host 192.168.122.220 --xmpp-host 192.168.122.89`, open `http://localhost:5173`, walk §1–§6.

- [ ] **Step 7: Commit**

```bash
git add tools/uc-journey-client/server.py tools/uc-journey-client/web/journey-ext.js tools/uc-journey-client/tests/test_server.py
git commit -m "feat(uc-journey): optional web GUI (POST/SSE server + extension)"
```

---

### Task 11: README + final wiring

**Files:**
- Create: `tools/uc-journey-client/README.md`

- [ ] **Step 1: Write README.md** covering: purpose (full-journey vs web-sso-ref's handoff), the Tier-1/Tier-2 split, prereqs (`just up`, `just seed-uc-test-user` → `APP_TOKEN`), headless usage (`just uc-journey ...`), lab transport usage (`--legs all --xmpp-host --sip-host --require-transport`), GUI usage (`--gui`), the CredKit provenance table, and the reuse map (link the spec). Mirror the tone/sections of `tools/web-sso-provision-ref/README.md`.

- [ ] **Step 2: Run the full client test suite**

Run: `cd tools/uc-journey-client && python -m pytest tests/ -v` (excludes `external_network` by default)
Expected: all unit tests PASS.

- [ ] **Step 3: Commit**

```bash
git add tools/uc-journey-client/README.md
git commit -m "docs(uc-journey): README — usage, tiers, reuse map"
```

---

## Self-Review (completed during authoring)

- **Spec coverage:** §4 modules → Tasks 1,3,4,5,6,7,8,10; §5 OIDC modes → Task 3; §5 app-token → Task 2; §6 GUI (POST/SSE, loopback-only, no index.html fork, deviceId) → Task 10; §8 Tier-1/Tier-2 + SKIP → Tasks 5,6,7,9; §11 smoke + `just` recipe → Tasks 8,9; §12 CLI flags → Task 8. All covered.
- **Placeholder scan:** the only "paste verbatim" markers (Task 5) point at exact source lines (`test_sip_ring_e2e.py:45-213`) — reproduced there rather than re-derived, to avoid a subtly-wrong digest. Acceptable per the reuse mandate.
- **Type consistency:** `StepResult`/`StepStatus`/`CredKit`/`XmppCreds`/`SipCreds`/`Config` names + fields identical across Tasks 1→10; `run_journey`'s injected `get_token`/`do_provision`/`xmpp_leg`/`sip_leg` signatures match Tasks 3,4,5,6.
