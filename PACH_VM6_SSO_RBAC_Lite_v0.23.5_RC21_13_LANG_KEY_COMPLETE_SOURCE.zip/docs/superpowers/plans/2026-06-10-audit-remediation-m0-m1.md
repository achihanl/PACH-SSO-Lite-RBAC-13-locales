# Audit Remediation M0+M1 (Safety Net + Critical Fixes) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.
> Create an isolated worktree first via superpowers:using-git-worktrees (branch: `audit-remediation-m0-m1`).

**Goal:** Fix the Critical/High audit findings — swallowed exceptions in user create/terminate, leaky error details, untyped LDAP failures, DEV_AUTH_TOKEN prod guard, unpinned backend deps, org-tree N+1 — and build the missing safety net (Docker-free unit test layer, OIDC tests frontend+backend, mypy in CI).

**Architecture:** Surgical edits only; no router split in this plan (that is follow-up plan M2). New test layer at `tests/unit/` shadows the Docker-dependent autouse fixtures from `tests/conftest.py` so pure-logic tests run with no stack. Handlers gain a `warnings`/`partial` response contract instead of silently swallowing sub-step failures.

**Tech Stack:** FastAPI, pytest (unit + existing integration suite), PyJWT + cryptography (test JWTs), pip-tools (lockfile), vitest (frontend), mypy + ruff (CI).

**Audit traceability:** Task 1→D1, Task 2-5→T1, Task 6→S1, Task 7→Q3, Task 8→A4/M1.4, Task 9→Q2, Task 10→Q1, Task 11→O1/O2/T3, Task 12→T2, Task 13→P1.

**Conventions that apply to every task:**
- Repo uses conventional commits (commitizen pre-commit hook). Never `--no-verify`.
- After staging each commit that touches `src/backend/main.py`, `ldap_client.py`, config, or workflows, run `just arch-guard`; if it reports governed surfaces, append the trailer it suggests (e.g. `Spec-Patch: 04`) to the commit message. Guard is warn-only but trailers are required by SOP.
- Integration tests require the dev stack: `just up-bg && just wait-healthy` once at the start.
- All file paths relative to repo root.

---

### Task 1: Backend dependency lockfile

Pin the fully-unpinned `src/backend/requirements.txt` (audit D1, High) via pip-tools, compiled inside the same Python 3.13 image the API ships on, and make the Docker build consume the lock.

**Files:**
- Create: `src/backend/requirements.lock` (generated)
- Modify: `deploy/dev/Dockerfile.api`

- [ ] **Step 1: Generate the lockfile inside python:3.13-slim**

```bash
docker run --rm -v "$PWD/src/backend:/w" -w /w python:3.13-slim \
  sh -c "pip install -q pip-tools && pip-compile --strip-extras requirements.txt -o requirements.lock"
```

Expected: `src/backend/requirements.lock` exists, every line `pkg==X.Y.Z` with `# via` comments.

- [ ] **Step 2: Point Dockerfile.api at the lock**

In `deploy/dev/Dockerfile.api` replace:

```dockerfile
COPY src/backend/requirements.txt /tmp/requirements.txt
RUN pip install --no-cache-dir -r /tmp/requirements.txt && rm /tmp/requirements.txt
```

with:

```dockerfile
# requirements.lock is compiled from requirements.txt via pip-compile (see Justfile: lock-backend)
COPY src/backend/requirements.lock /tmp/requirements.lock
RUN pip install --no-cache-dir -r /tmp/requirements.lock && rm /tmp/requirements.lock
```

- [ ] **Step 3: Add a Justfile recipe so the lock is regenerable**

Append to `Justfile` (near the other backend recipes):

```make
# Regenerate the backend lockfile (run after editing src/backend/requirements.txt)
lock-backend:
    docker run --rm -v "$(pwd)/src/backend:/w" -w /w python:3.13-slim \
      sh -c "pip install -q pip-tools && pip-compile --strip-extras requirements.txt -o requirements.lock"
```

- [ ] **Step 4: Verify the image builds and the stack is healthy**

```bash
just api-rebuild && just wait-healthy
```

Expected: build succeeds, health check exit 0.

- [ ] **Step 5: Commit**

```bash
git add src/backend/requirements.lock deploy/dev/Dockerfile.api Justfile
git commit -m "build(deps): pin backend dependencies via pip-compile lockfile"
```

---

### Task 2: Docker-free unit test layer scaffolding

`tests/conftest.py` has autouse fixtures (`clear_rate_limits`, `cleanup_test_templates`) that connect to Redis/Postgres — they would force Docker onto every test in `tests/unit/`. Shadow them with no-ops in a child conftest. The parent conftest already inserts `src/backend` on `sys.path` (tests/conftest.py:19-21), so unit tests import backend modules directly.

**Files:**
- Create: `tests/unit/__init__.py` (empty)
- Create: `tests/unit/conftest.py`
- Create: `tests/unit/test_smoke.py`

- [ ] **Step 1: Write conftest with no-op fixture shadows**

`tests/unit/conftest.py`:

```python
"""Unit-test conftest — keeps tests/unit/ free of Docker/network dependencies.

- Shadows the autouse fixtures from tests/conftest.py (clear_rate_limits,
  cleanup_test_templates) with no-ops so no Redis/Postgres connection is made
- Backend imports work via the sys.path insertion in the parent conftest
"""
import pytest


@pytest.fixture(autouse=True)
def clear_rate_limits():
    """No-op shadow: unit tests touch no Redis/Postgres."""
    yield


@pytest.fixture(autouse=True)
def cleanup_test_templates():
    """No-op shadow: unit tests create no config templates."""
    yield
```

- [ ] **Step 2: Write a failing smoke test (proves imports + isolation)**

`tests/unit/test_smoke.py`:

```python
"""Smoke test: backend modules importable without the Docker stack."""


def test_backend_modules_import_without_stack():
    import provisioning
    import uc_validation
    import oidc_verify

    assert callable(provisioning.allocate_uc_resources)
    assert callable(uc_validation.validate_endpoints)
    assert callable(oidc_verify.verify_bearer_token)
```

- [ ] **Step 3: Run with the stack DOWN to prove isolation**

```bash
just down
pytest tests/unit -v
```

Expected: 1 passed, no connection errors. (Bring stack back with `just up-bg` afterwards for later tasks.)

- [ ] **Step 4: Commit**

```bash
git add tests/unit/
git commit -m "test(unit): add Docker-free unit test layer with fixture shadows"
```

---

### Task 3: Unit tests — provisioning.py

Pure-logic coverage for `src/backend/provisioning.py` (audit T1). No production code change expected; if a test exposes a bug, stop and fix with its own failing-test-first cycle.

**Files:**
- Create: `tests/unit/test_provisioning_unit.py`

- [ ] **Step 1: Write the tests**

```python
"""Unit tests for provisioning.py — SIP password generation + UC allocation."""
import string

from provisioning import ProvisioningResult, allocate_uc_resources, generate_sip_password


class FakeOrgDB:
    """Stands in for orgdb: records allocator calls, returns fixed values."""

    def __init__(self):
        self.uid_calls = []
        self.ext_calls = []

    def allocate_uid_number(self, profile_id):
        self.uid_calls.append(profile_id)
        return 10001

    def allocate_extension(self, profile_id):
        self.ext_calls.append(profile_id)
        return 2001


def test_sip_password_length_and_alphabet():
    pw = generate_sip_password()
    assert len(pw) == 24
    allowed = set(string.ascii_letters + string.digits + "!@#%^&*-_=+")
    assert set(pw) <= allowed


def test_sip_passwords_are_unique():
    assert generate_sip_password() != generate_sip_password()


def test_empty_services_returns_none():
    db = FakeOrgDB()
    assert allocate_uc_resources(db, "p1", []) is None
    assert db.uid_calls == []


def test_all_services_disabled_returns_none():
    services = [
        {"service_type": "xmpp", "enabled": False},
        {"service_type": "sip", "enabled": False},
    ]
    db = FakeOrgDB()
    assert allocate_uc_resources(db, "p1", services) is None
    assert db.uid_calls == []


def test_xmpp_only_allocates_uid_but_no_extension():
    db = FakeOrgDB()
    res = allocate_uc_resources(db, "p1", [{"service_type": "xmpp"}])
    assert res == ProvisioningResult(uid_number=10001, extension=None, sip_password=None)
    assert db.ext_calls == []


def test_sip_allocates_extension_and_password():
    db = FakeOrgDB()
    res = allocate_uc_resources(db, "p1", [{"service_type": "sip"}])
    assert res.uid_number == 10001
    assert res.extension == 2001
    assert res.sip_password is not None and len(res.sip_password) == 24
```

- [ ] **Step 2: Run**

```bash
pytest tests/unit/test_provisioning_unit.py -v
```

Expected: 6 passed.

- [ ] **Step 3: Commit**

```bash
git add tests/unit/test_provisioning_unit.py
git commit -m "test(unit): cover provisioning allocation and SIP password generation"
```

---

### Task 4: Unit tests — uc_validation.py

Error-path coverage with DNS mocked via monkeypatch (audit T1). `uc_validation` references `dns.resolver.Resolver` at call time, so patching the class on the module works.

**Files:**
- Create: `tests/unit/test_uc_validation_unit.py`

- [ ] **Step 1: Write the tests**

```python
"""Unit tests for uc_validation.py — aggregation + DNS/WS error paths (DNS mocked)."""
import dns.resolver

import uc_validation
from uc_validation import _check_ws_handshake, validate_endpoints


class _RaisingResolver:
    """Fake dns.resolver.Resolver whose resolve() raises a preset exception."""

    exc: type[Exception] = dns.resolver.NXDOMAIN
    lifetime = None

    def resolve(self, qname, rtype):
        raise self.exc()


def test_no_inputs_returns_zero_counts():
    assert validate_endpoints() == {"checks": [], "passed": 0, "failed": 0, "total": 0}


def test_ws_empty_url_fails_without_network():
    res = _check_ws_handshake("", "XMPP WS")
    assert res.passed is False
    assert res.error == "URL is empty"
    assert res.latency_ms == 0


def test_dns_nxdomain_reported_as_failed_check(monkeypatch):
    _RaisingResolver.exc = dns.resolver.NXDOMAIN
    monkeypatch.setattr(uc_validation.dns.resolver, "Resolver", _RaisingResolver)
    res = validate_endpoints(xmpp_domain="example.invalid")
    assert res["total"] == 1 and res["failed"] == 1 and res["passed"] == 0
    assert "NXDOMAIN" in res["checks"][0]["error"]


def test_sip_domain_produces_sip_and_sips_checks(monkeypatch):
    _RaisingResolver.exc = dns.resolver.NoAnswer
    monkeypatch.setattr(uc_validation.dns.resolver, "Resolver", _RaisingResolver)
    res = validate_endpoints(sip_domain="example.invalid")
    assert res["total"] == 2  # _sip._tcp + _sips._tcp
    names = [c["name"] for c in res["checks"]]
    assert any("_sip._tcp" in n for n in names)
    assert any("_sips._tcp" in n for n in names)
```

- [ ] **Step 2: Run**

```bash
pytest tests/unit/test_uc_validation_unit.py -v
```

Expected: 4 passed, completes in <1s (no real DNS).

- [ ] **Step 3: Commit**

```bash
git add tests/unit/test_uc_validation_unit.py
git commit -m "test(unit): cover uc_validation DNS/WS error paths with mocked resolver"
```

---

### Task 5: Unit tests — oidc_verify.py

The backend's token-verification core (audit T1) currently has zero Docker-free coverage. Sign JWTs with a locally generated RSA key, monkeypatch `_get_jwk_client`, and assert the audience / issuer / expiry / infra-error contracts.

**Files:**
- Create: `tests/unit/test_oidc_verify_unit.py`

- [ ] **Step 1: Write the tests**

```python
"""Unit tests for oidc_verify.verify_bearer_token — sig/aud/iss/expiry/infra paths.

JWKS is mocked: tokens are signed with a locally generated RSA key and the
module's _get_jwk_client is monkeypatched to return that key.
"""
import time
from urllib.error import URLError

import jwt as pyjwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa

import oidc_verify
from oidc_verify import OIDCInfraError, verify_bearer_token

_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)


class _FakeSigningKey:
    key = _KEY.public_key()


class _FakeJWKClient:
    def get_signing_key_from_jwt(self, token):
        return _FakeSigningKey()


def _make_token(aud="test-aud", iss="https://idp.test", exp_delta=600):
    payload = {
        "sub": "u1",
        "preferred_username": "u1",
        "aud": aud,
        "iss": iss,
        "exp": int(time.time()) + exp_delta,
    }
    return pyjwt.encode(payload, _KEY, algorithm="RS256")


@pytest.fixture(autouse=True)
def fake_oidc_env(monkeypatch):
    monkeypatch.setattr(oidc_verify, "_get_jwk_client", lambda: _FakeJWKClient())
    monkeypatch.setattr(oidc_verify, "OIDC_AUDIENCE", "test-aud")
    monkeypatch.setattr(
        oidc_verify, "OIDC_ACCEPTED_ISSUERS", ["https://idp.test", "https://idp.test/"]
    )


def test_valid_token_returns_claims():
    claims = verify_bearer_token(_make_token())
    assert claims["preferred_username"] == "u1"


def test_wrong_audience_rejected():
    with pytest.raises(pyjwt.InvalidAudienceError):
        verify_bearer_token(_make_token(aud="someone-else"))


def test_wrong_issuer_rejected():
    with pytest.raises(pyjwt.InvalidIssuerError):
        verify_bearer_token(_make_token(iss="https://evil.test"))


def test_expired_token_rejected():
    with pytest.raises(pyjwt.ExpiredSignatureError):
        verify_bearer_token(_make_token(exp_delta=-60))


def test_jwks_unreachable_raises_infra_error_not_auth_failure(monkeypatch):
    def _boom():
        raise URLError("connection refused")

    monkeypatch.setattr(oidc_verify, "_get_jwk_client", _boom)
    with pytest.raises(OIDCInfraError):
        verify_bearer_token(_make_token())
```

- [ ] **Step 2: Run**

```bash
pytest tests/unit/test_oidc_verify_unit.py -v
```

Expected: 5 passed. Gotcha: if `test_valid_token_returns_claims` fails with `InvalidIssuerError`, the monkeypatched `OIDC_ACCEPTED_ISSUERS` didn't take — confirm you patched the `oidc_verify` module attribute, not `config`.

- [ ] **Step 3: Commit**

```bash
git add tests/unit/test_oidc_verify_unit.py
git commit -m "test(unit): cover oidc_verify token validation contracts with mocked JWKS"
```

---

### Task 6: DEV_AUTH_TOKEN production guard

Audit S1 (High): nothing stops the dev auth bypass from running in production. Add a pure guard function in `config.py` (testable without importing `main`) and call it at API startup.

**Files:**
- Modify: `src/backend/config.py` (after the DEV_AUTH_TOKEN block, line ~70)
- Modify: `src/backend/main.py` (config import block + one call near app construction)
- Modify: `deploy/dev/.env.example` (document ENVIRONMENT)
- Test: `tests/unit/test_config_guard.py`

- [ ] **Step 1: Write the failing test**

`tests/unit/test_config_guard.py`:

```python
"""Unit tests for the DEV_AUTH_TOKEN production guard in config.py."""
import pytest

from config import assert_dev_token_safe


def test_production_with_dev_token_refuses_startup():
    with pytest.raises(RuntimeError, match="DEV_AUTH_TOKEN"):
        assert_dev_token_safe("dev-test-token", "production")


def test_production_case_insensitive():
    with pytest.raises(RuntimeError):
        assert_dev_token_safe("x", "Production")


def test_production_without_dev_token_is_fine():
    assert assert_dev_token_safe("", "production") is None


def test_development_with_dev_token_is_fine():
    assert assert_dev_token_safe("dev-test-token", "development") is None
```

- [ ] **Step 2: Run to verify failure**

```bash
pytest tests/unit/test_config_guard.py -v
```

Expected: FAIL — `ImportError: cannot import name 'assert_dev_token_safe'`.

- [ ] **Step 3: Implement in config.py**

Append after the `DEV_AUTH_TOKEN` assignment (src/backend/config.py:70):

```python
# ----------------------------
# Deployment environment guard
# ----------------------------
# ENVIRONMENT=production must never run with the DEV_AUTH_TOKEN bypass enabled.
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")


def assert_dev_token_safe(dev_token: str, environment: str) -> None:
    """Refuse startup when the dev auth bypass is enabled in production.

    - DEV_AUTH_TOKEN grants full admin claims to anyone holding the token
    - raising here fails the process fast instead of running exposed
    """
    if environment.lower() == "production" and dev_token:
        raise RuntimeError(
            "DEV_AUTH_TOKEN is set while ENVIRONMENT=production — this would "
            "allow full authentication bypass. Unset DEV_AUTH_TOKEN to start."
        )
```

- [ ] **Step 4: Run test to verify pass**

```bash
pytest tests/unit/test_config_guard.py -v
```

Expected: 4 passed.

- [ ] **Step 5: Wire into main.py startup**

In `src/backend/main.py`, find the existing `from config import (...)` block and add `ENVIRONMENT, assert_dev_token_safe` to it (and `DEV_AUTH_TOKEN` if not already imported). Immediately after the imports/`app = FastAPI(...)` construction add:

```python
# Fail fast if the dev auth bypass is enabled in a production environment.
assert_dev_token_safe(DEV_AUTH_TOKEN, ENVIRONMENT)
```

- [ ] **Step 6: Document in .env.example**

Add under the DEV_AUTH_TOKEN comment block in `deploy/dev/.env.example`:

```
# Deployment environment: development | production.
# When production, the API refuses to start if DEV_AUTH_TOKEN is set.
ENVIRONMENT=development
```

- [ ] **Step 7: Verify the running stack still boots**

```bash
just restart && just health-check
```

Expected: exit 0 (dev stack has ENVIRONMENT unset → "development" → guard passes).

- [ ] **Step 8: Commit (auth surface — check arch-guard)**

```bash
git add src/backend/config.py src/backend/main.py deploy/dev/.env.example tests/unit/test_config_guard.py
just arch-guard
git commit -m "feat(security): refuse startup when DEV_AUTH_TOKEN set in production

Spec-Patch: 04"
```

(If `just arch-guard` names different sections, use those in the trailer instead.)

---

### Task 7: Stop leaking exception text in HTTP error details

Audit Q3: `main.py:1536` interpolates raw exception text into a client-facing 500. Fix the one known site and add a source-scan guard test so the pattern can't return.

**Files:**
- Create: `tests/unit/test_error_hygiene.py`
- Modify: `src/backend/main.py:1531-1537`

- [ ] **Step 1: Write the failing guard test**

`tests/unit/test_error_hygiene.py`:

```python
"""Source-scan guard: HTTPException details must not interpolate raw exception text.

Raw `{e}` in client-facing details leaks LDAP hosts/DN structure (CLAUDE.md
'PR Review Gate' rule). Log the exception server-side; return a generic detail.
"""
import re
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[2] / "src" / "backend"
# matches: detail=f"... {e} ..." / {exc} / {err} (word-boundary, attr access too)
PATTERN = re.compile(r'detail=f"[^"]*\{(?:e|exc|err)\b')


def test_no_exception_text_in_http_details():
    offenders = []
    for py in sorted(BACKEND.glob("*.py")):
        for lineno, line in enumerate(py.read_text().splitlines(), 1):
            if PATTERN.search(line):
                offenders.append(f"{py.name}:{lineno}: {line.strip()}")
    assert offenders == [], "\n".join(offenders)
```

- [ ] **Step 2: Run to verify it fails on the known offender**

```bash
pytest tests/unit/test_error_hygiene.py -v
```

Expected: FAIL listing `main.py:1536`. Gotcha: the f-string spans lines 1533-1536; if the `{e}` is not on the same physical line as `detail=f"`, adjust PATTERN to scan `py.read_text()` (whole file) with `re.DOTALL`-safe pattern `r'detail=f"[^"]*\{(?:e|exc|err)\b'` against the full text and report match offsets instead of line numbers.

- [ ] **Step 3: Fix the offender**

In `src/backend/main.py` replace (around lines 1531-1537):

```python
    except Exception as e:
        # LDAP disable is critical - user could still authenticate if this fails
        raise HTTPException(
            500,
            detail=f"Critical: Failed to disable LDAP account: {e}. Termination aborted.",
        )
```

with:

```python
    except Exception as e:
        # LDAP disable is critical - user could still authenticate if this fails
        logger.error("Failed to disable LDAP account for %s: %s", uid, e, exc_info=True)
        raise HTTPException(
            500,
            detail="Critical: failed to disable LDAP account. Termination aborted.",
        )
```

- [ ] **Step 4: Run guard test to verify pass**

```bash
pytest tests/unit/test_error_hygiene.py -v
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add tests/unit/test_error_hygiene.py src/backend/main.py
git commit -m "fix(security): strip raw exception text from termination 500 detail"
```

---

### Task 8: Typed LDAP errors → 503 mapping

Audit A4/M1.4: `safe_ldap` collapses all LDAP failures into bare `RuntimeError` → clients get 500 for an outage that should be 503. Introduce `LdapUnavailableError(RuntimeError)` (subclassing keeps any existing `except RuntimeError` callers working) and a FastAPI exception handler.

**Files:**
- Modify: `src/backend/ldap_client.py:175-179` (safe_ldap) + class definition above it
- Modify: `src/backend/main.py` (import + exception handler near the existing `app.add_exception_handler` at main.py:131)
- Test: `tests/unit/test_ldap_errors_unit.py`

- [ ] **Step 1: Write the failing test**

`tests/unit/test_ldap_errors_unit.py`:

```python
"""Unit tests for safe_ldap typed error mapping."""
import pytest
from ldap3.core.exceptions import LDAPException

from ldap_client import LdapUnavailableError, safe_ldap


def test_ldap_exception_becomes_typed_error():
    def op():
        raise LDAPException("server down")

    with pytest.raises(LdapUnavailableError):
        safe_ldap(op)


def test_typed_error_is_runtimeerror_subclass():
    # existing `except RuntimeError` call sites must keep working
    assert issubclass(LdapUnavailableError, RuntimeError)


def test_successful_op_passes_through():
    assert safe_ldap(lambda: 42) == 42
```

- [ ] **Step 2: Run to verify failure**

```bash
pytest tests/unit/test_ldap_errors_unit.py -v
```

Expected: FAIL — `ImportError: cannot import name 'LdapUnavailableError'`.

- [ ] **Step 3: Implement in ldap_client.py**

Replace (src/backend/ldap_client.py:175-179):

```python
def safe_ldap(op_fn):
    try:
        return op_fn()
    except LDAPException as e:
        raise RuntimeError(str(e))
```

with:

```python
class LdapUnavailableError(RuntimeError):
    """LDAP backend unreachable or an operation failed at the LDAP layer.

    Subclasses RuntimeError so existing `except RuntimeError` callers
    keep working; main.py maps this to HTTP 503.
    """


def safe_ldap(op_fn):
    try:
        return op_fn()
    except LDAPException as e:
        raise LdapUnavailableError(str(e)) from e
```

- [ ] **Step 4: Run test to verify pass**

```bash
pytest tests/unit/test_ldap_errors_unit.py -v
```

Expected: 3 passed.

- [ ] **Step 5: Add the 503 handler in main.py**

Add `LdapUnavailableError` to the existing `from ldap_client import (...)` block (main.py:33-62). Next to the existing exception-handler registration (main.py:131) add:

```python
@app.exception_handler(LdapUnavailableError)
async def ldap_unavailable_handler(request: Request, exc: LdapUnavailableError):
    """Directory outage is a 503 (retryable), not a generic 500."""
    logger.error("LDAP unavailable on %s: %s", request.url.path, exc)
    return JSONResponse(status_code=503, content={"ok": False, "error": "directory_unavailable"})
```

If `JSONResponse` is not yet imported, add `from fastapi.responses import JSONResponse` to the imports.

- [ ] **Step 6: Run the integration suite to catch contract changes**

```bash
pytest tests/ -m "not external_network" --tb=short -q
```

Expected: all pass. Risk note: any test that previously asserted 500 on an LDAP failure would now see 503 — if one fails on a status assertion, update the test (503 is the correct contract) and say so in the commit body.

- [ ] **Step 7: Commit (api/data surface — check arch-guard)**

```bash
git add src/backend/ldap_client.py src/backend/main.py tests/unit/test_ldap_errors_unit.py
just arch-guard
git commit -m "feat(api): map LDAP outages to typed error and HTTP 503

Spec-Patch: 05"
```

---

### Task 9: Termination partial-failure surfacing

Audit Q2 (High): token-revocation failure during termination is recorded in the `actions` accumulator (`tokens_revoked_error`, main.py:1556-1560) but the response says plain success. Derive `partial`/`warnings` from the accumulator with a pure helper.

**Files:**
- Create: `src/backend/response_utils.py`
- Modify: `src/backend/main.py` (terminate handler return, ~main.py:1605-1623)
- Test: `tests/unit/test_response_utils.py`, addition to `tests/test_users.py`

- [ ] **Step 1: Write the failing unit test**

`tests/unit/test_response_utils.py`:

```python
"""Unit tests for response_utils.summarize_termination."""
from response_utils import summarize_termination


def test_clean_actions_not_partial():
    actions = {"ldap_disabled": True, "tokens_revoked": 2}
    assert summarize_termination(actions) == {"partial": False, "warnings": []}


def test_error_keys_produce_partial_with_warnings():
    actions = {
        "ldap_disabled": True,
        "tokens_revoked_error": "db timeout",
        "authentik_revoke_error": "api 502",
    }
    summary = summarize_termination(actions)
    assert summary["partial"] is True
    assert "tokens_revoked: db timeout" in summary["warnings"]
    assert "authentik_revoke: api 502" in summary["warnings"]


def test_empty_actions_not_partial():
    assert summarize_termination({}) == {"partial": False, "warnings": []}
```

- [ ] **Step 2: Run to verify failure**

```bash
pytest tests/unit/test_response_utils.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'response_utils'`.

- [ ] **Step 3: Implement response_utils.py**

`src/backend/response_utils.py`:

```python
"""Response-shaping helpers for API handlers.

- summarize_termination: derive partial/warnings from a step-accumulator dict
- kept import-light so tests/unit can import without pulling main.py
"""
from typing import Any, Dict, List


def summarize_termination(actions: Dict[str, Any]) -> Dict[str, Any]:
    """Map `*_error` keys in an actions accumulator to a partial-outcome summary.

    - `partial=True` whenever any sub-step recorded an error
    - warnings carry the step name + error text for the admin UI
    """
    warnings: List[str] = [
        f"{key.removesuffix('_error')}: {val}"
        for key, val in actions.items()
        if key.endswith("_error")
    ]
    return {"partial": bool(warnings), "warnings": warnings}
```

- [ ] **Step 4: Run unit test to verify pass**

```bash
pytest tests/unit/test_response_utils.py -v
```

Expected: 3 passed.

- [ ] **Step 5: Wire into the terminate handler**

In `src/backend/main.py` add to imports: `from response_utils import summarize_termination`. In `api_user_terminate`, the final return (~main.py:1610-1623) currently rebuilds an actions dict; merge the summary of the **accumulator variable** `actions` (which holds the `*_error` keys):

```python
    return {
        "ok": True,
        "status": "terminated",
        "user_uid": uid,
        "event_id": event_id,
        "actions": actions,
        **summarize_termination(actions),
        "timestamp": iso(utcnow()),
    }
```

Note: this also fixes a latent bug — the old return rebuilt `actions` from four locals, silently dropping the `tokens_revoked_error` / `authentik_*` error keys the handler had stored.

- [ ] **Step 6: Add the integration assertion (happy path contract)**

Append to `tests/test_users.py` (uses existing helpers `create_test_user`, `created_users` from conftest; add `import uuid` and `from conftest import create_test_user` if not present in the file — check its existing imports first and reuse its local pattern):

```python
def test_terminate_reports_partial_status(client, created_users):
    uid = f"test-term-{uuid.uuid4().hex[:6]}"
    resp = create_test_user(client, uid, created_users)
    assert resp.status_code == 201
    t = client.post(f"/api/users/{uid}/terminate", json={"reason": "test", "immediate": True})
    assert t.status_code == 200
    body = t.json()
    assert body["partial"] is False
    assert body["warnings"] == []
    assert "tokens_revoked" in body["actions"]
```

- [ ] **Step 7: Run both layers**

```bash
pytest tests/unit/test_response_utils.py tests/test_users.py -v --tb=short
```

Expected: all pass (stack must be up: `just up-bg && just wait-healthy`).

- [ ] **Step 8: Commit (api surface — check arch-guard)**

```bash
git add src/backend/response_utils.py src/backend/main.py tests/unit/test_response_utils.py tests/test_users.py
just arch-guard
git commit -m "feat(api): surface partial termination outcomes instead of silent success

Spec-Patch: 05"
```

---

### Task 10: User-create warnings instead of swallowed failures

Audit Q1 (Critical): in `api_user_create` (main.py:1411-1470) group assignment failures are `except: pass`, unknown groups are silently skipped, and UC-provisioning failures only log. Return a `warnings` array so 201 means "created, and here is what didn't happen".

**Files:**
- Modify: `src/backend/main.py:1411-1470` (api_user_create)
- Test: addition to `tests/test_users.py`

- [ ] **Step 1: Write the failing integration test**

Append to `tests/test_users.py`:

```python
def test_create_user_surfaces_unknown_group_warning(client, created_users):
    uid = f"test-warn-{uuid.uuid4().hex[:6]}"
    resp = client.post("/api/users/create", json={
        "uid": uid,
        "displayName": "Warn Test",
        "mail": f"{uid}@test.com",
        "mobile": "1234567890",
        "password": "testpass123",
        "orgDn": f"ou=org,{LDAP_BASE_DN}",
        "groups": ["no-such-group-xyz"],
    })
    assert resp.status_code == 201
    created_users.append(uid)
    body = resp.json()
    assert any("no-such-group-xyz" in w for w in body["warnings"])


def test_create_user_without_issues_has_empty_warnings(client, created_users):
    uid = f"test-warn-{uuid.uuid4().hex[:6]}"
    resp = create_test_user(client, uid, created_users)
    assert resp.status_code == 201
    assert resp.json()["warnings"] == []
```

(`LDAP_BASE_DN` is defined in `tests/conftest.py:25`; import it the same way the file's existing tests do.)

- [ ] **Step 2: Run to verify failure**

```bash
pytest tests/test_users.py -k warn -v
```

Expected: FAIL with `KeyError: 'warnings'`.

- [ ] **Step 3: Implement the warnings accumulator**

In `api_user_create` (main.py:1411-1470), replace the group-assignment block:

```python
    # group assignment (best-effort) — uses find_group_dn from ldap_client
    if req.groups:
        conn = get_conn()
        user_dn = find_user_dn(conn, OU_PEOPLE, req.uid)
        conn.unbind()
        if user_dn:
            for gcn in req.groups:
                gdn = find_group_dn(gcn)
                if gdn:
                    try:
                        group_add_member(gdn, user_dn)
                    except Exception:
                        pass
```

with:

```python
    warnings: list[str] = []
    # group assignment (best-effort, but every miss is reported)
    if req.groups:
        conn = get_conn()
        user_dn = find_user_dn(conn, OU_PEOPLE, req.uid)
        conn.unbind()
        if user_dn:
            for gcn in req.groups:
                gdn = find_group_dn(gcn)
                if not gdn:
                    warnings.append(f"group not found: {gcn}")
                    continue
                try:
                    group_add_member(gdn, user_dn)
                except Exception as e:
                    logger.warning("group add failed for %s -> %s: %s", req.uid, gcn, e)
                    warnings.append(f"group assignment failed: {gcn}")
        else:
            warnings.append("user DN not found for group assignment")
```

Then update the remaining swallow sites in the same handler:
- lifecycle event `except Exception: pass` → `except Exception as e: logger.warning("lifecycle event not recorded for %s: %s", req.uid, e); warnings.append("lifecycle event not recorded")`
- UC provisioning `except Exception as e: logger.error(...)` → keep the log, add `warnings.append("uc provisioning failed — user has no UC services")`
- admin-action audit `except Exception: pass` → `except Exception as e: logger.warning("admin audit not recorded for create_user %s: %s", req.uid, e); warnings.append("admin audit not recorded")`

And in the response assembly at the end of the handler:

```python
    response = {"ok": True, "warnings": warnings, **res}
    if provisioning_info:
        response["provisioning"] = provisioning_info
    return response
```

(The `warnings: list[str] = []` line shown above sits right after the `create_user(...)` call and before the `if req.groups:` block, so the list exists on every path through the handler.)

- [ ] **Step 4: Run to verify pass + no regression**

```bash
pytest tests/test_users.py -v --tb=short
```

Expected: all pass, including the two new tests.

- [ ] **Step 5: Commit (api surface — check arch-guard)**

```bash
git add src/backend/main.py tests/test_users.py
just arch-guard
git commit -m "feat(api): report user-create sub-step failures as response warnings

Spec-Patch: 05"
```

---

### Task 11: CI — always-run unit job, mypy, broader ruff

Audit O1/O2/T3: backend has no type checking, ruff only covers F+E9, and the new unit layer should run on every PR regardless of diff scope (it is fast).

**Files:**
- Create: `mypy.ini`
- Modify: `.github/workflows/pr-checks.yml`

- [ ] **Step 1: Create lenient mypy config**

`mypy.ini`:

```ini
[mypy]
python_version = 3.13
ignore_missing_imports = True
check_untyped_defs = False
no_implicit_optional = False
exclude = (?x)(^tests/|^tools/|^_ARCHIVE_/|^docs/|^src/cli/)
```

- [ ] **Step 2: Run locally and triage**

```bash
pip install -q mypy
mypy src/backend
```

If errors are reported, for each offending module add an explicit opt-out section to `mypy.ini` (do NOT loosen the global config further):

```ini
[mypy-orgdb]
ignore_errors = True
```

Goal state: `mypy src/backend` exits 0 with the opt-outs documenting exactly which legacy modules are excluded. Record the excluded module list in the commit body.

- [ ] **Step 3: Add mypy to the python-lint job**

In `.github/workflows/pr-checks.yml`, in the `python-lint` job after the ruff step (line ~108), add:

```yaml
      - name: Type-check backend (mypy, lenient baseline)
        if: steps.changed.outputs.run == 'true'
        run: |
          pip install -q mypy
          mypy src/backend
```

- [ ] **Step 4: Broaden ruff selectors**

Change line 108 from `ruff check --select F,E9 $FILES` to:

```
ruff check --select F,E,W,B --ignore E501 $FILES
```

Then run locally over the whole backend to pre-clear violations on files this branch touched:

```bash
ruff check --select F,E,W,B --ignore E501 src/backend tests/unit
```

Fix anything reported in files modified by this branch; pre-existing violations in untouched files stay (the CI step is diff-scoped so they won't fail PRs until touched).

- [ ] **Step 5: Add the always-run unit-test job**

Add a new job to `.github/workflows/pr-checks.yml` (copy the `runs-on`/`timeout` shape and the exact pinned `actions/checkout@...` line used by the existing jobs in this file):

```yaml
  backend-unit:
    name: Backend unit tests (no stack)
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@<same pinned ref as the other jobs in this file>
      - uses: actions/setup-python@v5
        with:
          python-version: '3.13'
          cache: pip
          cache-dependency-path: src/backend/requirements.lock
      - name: Install deps
        run: pip install -q -r src/backend/requirements.lock pytest pytest-asyncio
      - name: Run unit tests
        run: pytest tests/unit -v --tb=short
```

(Python 3.13 to match the lockfile's compile target. Not diff-scoped on purpose — it is the cheap, always-on gate.)

- [ ] **Step 6: Validate workflow syntax + commit (ci_release_gates surface)**

```bash
just pr-checks   # local mirror of the gate — must pass
git add mypy.ini .github/workflows/pr-checks.yml
just arch-guard
git commit -m "ci(quality): add always-run unit job, mypy baseline, broader ruff

Spec-Patch: 06"
```

---

### Task 12: Frontend unit tests for oidc.ts pure functions

Audit T2 (Critical-rated test gap): `lib/oidc.ts` has zero tests. Cover the pure exported functions (`sanitizeRedirectPath`, `decodeIdTokenClaims`) first — they are the security-relevant, network-free core. (Network-bound functions — `exchangeCodeForTokens`, `refreshTokens` — belong to the follow-up frontend plan with fetch mocking.)

**Files:**
- Create: `src/frontend/src/lib/__tests__/oidc.test.ts`

- [ ] **Step 1: Write the tests**

```typescript
/**
 * Unit tests for oidc.ts pure functions:
 * - sanitizeRedirectPath: open-redirect prevention contract
 * - decodeIdTokenClaims: base64url JWT payload decoding
 */
import { describe, expect, it } from 'vitest'
import { decodeIdTokenClaims, sanitizeRedirectPath } from '../oidc'

describe('sanitizeRedirectPath', () => {
  it('accepts same-origin absolute paths', () => {
    expect(sanitizeRedirectPath('/directory/users')).toBe('/directory/users')
  })
  it('rejects protocol-relative URLs', () => {
    expect(sanitizeRedirectPath('//evil.test/x')).toBe('/')
  })
  it('rejects backslash-normalized URLs (Chromium // coercion)', () => {
    expect(sanitizeRedirectPath('/\\evil.test')).toBe('/')
  })
  it('rejects schemed URLs and bare hosts', () => {
    expect(sanitizeRedirectPath('https://evil.test')).toBe('/')
    expect(sanitizeRedirectPath('evil.test')).toBe('/')
  })
  it('rejects non-strings and empty input, honoring fallback', () => {
    expect(sanitizeRedirectPath(undefined)).toBe('/')
    expect(sanitizeRedirectPath(42)).toBe('/')
    expect(sanitizeRedirectPath('', '/fallback')).toBe('/fallback')
  })
})

describe('decodeIdTokenClaims', () => {
  const payload = { sub: 'u1', preferred_username: 'mei', email: 'mei@example.test' }
  const b64url = Buffer.from(JSON.stringify(payload))
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '')
  const token = `header.${b64url}.sig`

  it('decodes base64url payload claims', () => {
    const claims = decodeIdTokenClaims(token)
    expect(claims.preferred_username).toBe('mei')
    expect(claims.email).toBe('mei@example.test')
  })
  it('throws on malformed token', () => {
    expect(() => decodeIdTokenClaims('not-a-jwt')).toThrow('Invalid id_token format')
  })
})
```

- [ ] **Step 2: Run**

```bash
cd src/frontend && npx vitest run src/lib/__tests__/oidc.test.ts
```

Expected: 7 passed. Gotcha: importing `../oidc` evaluates module-level `import.meta.env.VITE_*` reads — vitest under the Vite config resolves these; if it errors on a missing env var, add the var to a `vitest` `env` block in `vite.config.ts` rather than stubbing the module.

- [ ] **Step 3: Lint + commit**

```bash
cd src/frontend && npm run lint && cd ../..
git add src/frontend/src/lib/__tests__/oidc.test.ts
git commit -m "test(frontend): cover oidc sanitizeRedirectPath and id_token decoding"
```

---

### Task 13: Batch org-tree user counts (kill the N+1)

Audit P1 (High): `api_orgs_tree` (main.py:744-764) and `api_orgs_detail` (main.py:812-821) issue one LDAP search per org node. Replace with one subtree search grouped by parent DN. Extract the org→people DN mapping (currently inlined in `list_users_for_org`, ldap_client.py:692-697) into a shared helper — removes a DRY violation at the same time.

**Files:**
- Modify: `src/backend/ldap_client.py` (new `org_dn_to_people_dn` + `count_users_by_people_base`; refactor `list_users_for_org` to use the helper)
- Modify: `src/backend/main.py:744-846` (tree + detail endpoints)
- Test: `tests/unit/test_ldap_mapping_unit.py`

- [ ] **Step 1: Write the failing unit test for the mapping helper**

`tests/unit/test_ldap_mapping_unit.py`:

```python
"""Unit tests for org-DN → people-DN mirroring helper."""
import ldap_client
from ldap_client import org_dn_to_people_dn


def test_org_root_maps_to_people_root():
    assert org_dn_to_people_dn(ldap_client.OU_ORG) == ldap_client.OU_PEOPLE


def test_nested_org_maps_to_mirrored_people_branch():
    org = f"ou=Sales,{ldap_client.OU_ORG}"
    assert org_dn_to_people_dn(org) == f"ou=Sales,{ldap_client.OU_PEOPLE}"


def test_deeply_nested_org_keeps_relative_path():
    org = f"ou=Emea,ou=Sales,{ldap_client.OU_ORG}"
    assert org_dn_to_people_dn(org) == f"ou=Emea,ou=Sales,{ldap_client.OU_PEOPLE}"


def test_non_org_dn_falls_back_to_people_root():
    assert org_dn_to_people_dn("") == ldap_client.OU_PEOPLE
```

- [ ] **Step 2: Run to verify failure**

```bash
pytest tests/unit/test_ldap_mapping_unit.py -v
```

Expected: FAIL — `ImportError: cannot import name 'org_dn_to_people_dn'`.

- [ ] **Step 3: Implement the helpers in ldap_client.py**

Add above `list_users_for_org` (ldap_client.py:~681):

```python
def org_dn_to_people_dn(org_dn: str) -> str:
    """Map an org-tree DN to its mirrored OU_PEOPLE base DN.

    - ou=Sales,<OU_ORG> -> ou=Sales,<OU_PEOPLE>
    - OU_ORG itself / anything else -> OU_PEOPLE
    """
    if org_dn and org_dn.endswith("," + OU_ORG):
        rel = org_dn[: -(len(OU_ORG) + 1)]
        return f"{rel},{OU_PEOPLE}" if rel else OU_PEOPLE
    return OU_PEOPLE


def count_users_by_people_base() -> Dict[str, int]:
    """Count inetOrgPerson entries grouped by immediate parent DN.

    One SUBTREE search over OU_PEOPLE (uid attribute only) replaces the
    per-org-node searches in the org tree endpoints (N+1 fix).
    """
    def _op():
        conn = get_conn()
        if not entry_exists(conn, OU_PEOPLE):
            conn.unbind()
            return {}
        conn.search(OU_PEOPLE, "(objectClass=inetOrgPerson)", SUBTREE, attributes=["uid"])
        counts: Dict[str, int] = {}
        for e in conn.entries:
            parent = e.entry_dn.split(",", 1)[1]
            counts[parent] = counts.get(parent, 0) + 1
        conn.unbind()
        return counts
    return safe_ldap(_op)
```

Then refactor the inline mapping inside `list_users_for_org` (ldap_client.py:692-697) to call the helper:

```python
        people_dn = org_dn_to_people_dn(org_dn)
```

(delete the now-duplicated 4-line mapping block it replaces).

- [ ] **Step 4: Run unit test to verify pass**

```bash
pytest tests/unit/test_ldap_mapping_unit.py -v
```

Expected: 4 passed.

- [ ] **Step 5: Use the batch counts in api_orgs_tree**

In `src/backend/main.py` add `org_dn_to_people_dn, count_users_by_people_base` to the `from ldap_client import (...)` block. Rewrite the enrich closure (main.py:749-761):

```python
    user_counts = count_users_by_people_base()  # one LDAP search for the whole tree

    def enrich(node: dict, depth: int = 0) -> dict:
        dn = node["dn"]
        profile = profile_map.get(dn)
        return {
            "dn": dn,
            "name": node["name"],
            "type": (profile or {}).get("org_type") or _infer_org_type(depth),
            "userCount": user_counts.get(org_dn_to_people_dn(dn), 0),
            "hasProfile": profile is not None,
            "children": [enrich(c, depth + 1) for c in node.get("children", [])],
        }
```

(Remove the now-stale `# TODO: batch user counts` comment on main.py:749.)

- [ ] **Step 6: Same treatment in api_orgs_detail's children loop**

In `api_orgs_detail` (main.py:812-821), before the loop add `user_counts = count_users_by_people_base()` and a profile map (`profiles = ORGDB.list_profiles(tenant=LDAP_TENANT)` → `profile_map = {p["org_dn"]: p for p in profiles}` — mirror exactly what `api_orgs_tree` does at main.py:746-747). Replace per-child calls:

```python
    for c in target_node.get("children", []):
        child_users_count = user_counts.get(org_dn_to_people_dn(c["dn"]), 0)
        child_profile = profile_map.get(c["dn"])
```

and update the loop body's uses of `len(child_users)` → `child_users_count` and `child_profile` accordingly (read the existing loop body first; keep its output shape byte-identical).

- [ ] **Step 7: Run the org/group integration tests**

```bash
pytest tests/test_org_groups.py tests/test_orgprofiles.py tests/test_orgdb_device.py -v --tb=short
```

Expected: all pass — response shapes unchanged, only query count drops. Gotcha: `count_users_by_people_base` counts by *immediate parent* (matches the old `include_sub=False` semantics); if a tree test asserts subtree-inclusive counts, that test was already passing against `include_sub=False` — investigate before changing semantics.

- [ ] **Step 8: Full suite + commit**

```bash
pytest tests/ -m "not external_network" --tb=short -q
git add src/backend/ldap_client.py src/backend/main.py tests/unit/test_ldap_mapping_unit.py
just arch-guard
git commit -m "perf(orgs): batch org-tree user counts into one LDAP search

Spec-Patch: 05"
```

---

### Final verification (whole plan)

- [ ] `just down && pytest tests/unit -v` — unit layer green with no stack
- [ ] `just up-bg && just wait-healthy && pytest tests/ -m "not external_network" --tb=short` — full integration suite green
- [ ] `cd src/frontend && npm run lint && npm run test:unit` — frontend green
- [ ] `just pr-checks` — local CI mirror green
- [ ] Use superpowers:requesting-code-review, then superpowers:finishing-a-development-branch (PR per repo's PR Review Gate; run `/review` before `/ship`)

---

## Follow-up plans (separate documents, in priority order)

These were audited but deliberately excluded — each is its own plan per the one-plan-one-subsystem rule:

1. **M2.1 Router split** (`main.py` → APIRouter modules) — XL; needs its own plan + likely an ARD (governed surfaces). Safety net from this plan (unit layer, full suite) is its prerequisite.
2. **M2.3/M2.4 Frontend refactor** — UserDetailPanel tab extraction, `useFormModal` shared hook, error states for the ~60 unhandled `useQuery` sites, fetch-mocked tests for `exchangeCodeForTokens`/`refreshTokens`.
3. **M2.5 Production deployment doc** — `deploy/prod/PRODUCTION.md`, `.env.prod.template`, CSP/HSTS in nginx configs.
4. **M1.5 Exception-handler sweep** — triage the remaining ~70 broad `except Exception` sites outside the two handlers fixed here.
5. **M3 polish** — coverage ratchet, Docker digest pins, structured logging, SOP spec-meta drift fix.

---

## Execution addendum (2026-06-11)

Material deltas between this plan and what landed (all reviewed):

1. **Task 6:** guard became a default-deny allowlist (`_DEV_ENVIRONMENTS = {development, dev, test, ci}`) wired at config import time (protects all entrypoints), plus `ENVIRONMENT` plumbing in docker-compose and `.env.example` — plan had a `== "production"` check wired in main.py.
2. **Task 9:** terminate returns `merged_actions` (accumulator merged over the four baseline keys the frontend reads) instead of the bare accumulator; also fixed a latent bug where the old return dropped `*_error` keys. Error values are sanitized at write time (raw text → logs only).
3. **Task 12:** required a `window.location` setupFiles stub in vitest.config.ts (oidc.ts reads window at import); plan anticipated an import.meta.env gotcha instead.
4. **Task 11:** added `ruff.toml` (B008 per-file-ignore for main.py) and scoped the Justfile `pr-checks` ruff mirror to `src/backend tests/unit` pending a tests/-tree lint ratchet (~28 pre-existing F401s). Frontend ui-lint/ui-format steps of `just pr-checks` remain red from pre-existing main-branch debt (26 eslint errors / 11 files) — separate follow-up.
5. **Tasks 1/2 commits** (`11b6e0e`, `b206afd`) lack architecture trailers (guard warn-only at the time) — noted for the PR body rather than history rewrite.
