# Dashboard Phase 4 — Naming & Contract Reconciliation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix naming/type/path mismatches between Phase 4 query hooks and their issue specs so frontend-backend contracts align before backend work (#50) begins.

**Architecture:** 4 frontend files changed (types, hooks, keys, quick actions component) + 3 GitHub issues updated. No new files. No backend changes.

**Tech Stack:** TypeScript, TanStack Query v5 (`queryOptions` factory pattern), TanStack Router (`useNavigate`)

**Spec:** `docs/superpowers/specs/2026-03-10-dashboard-phase4-reconciliation-design.md`

---

## File Map

| File | Action | Responsibility |
|------|--------|----------------|
| `src/frontend/src/types/dashboard.ts` | Modify (lines 35-44) | Add `DashboardStatsApiResponse` after `TrendDirection` |
| `src/frontend/src/lib/queries/dashboard.ts` | Modify (lines 14-39, 66-73, 120-127) | Fix stats type, add limit params, delete stale interface |
| `src/frontend/src/lib/queries/keys.ts` | Modify (lines 70, 73) | Parameterize `recentQR` and `activity` keys |
| `src/frontend/src/components/features/dashboard/QuickActionsCard.tsx` | Modify (lines 1-34) | Fix labels, wire navigate handlers |

---

## Chunk 1: Contract Fixes (Types + Hooks + Keys)

### Task 1: Add `DashboardStatsApiResponse` type

**Files:**
- Modify: `src/frontend/src/types/dashboard.ts:33-44`

- [ ] **Step 1: Add the API response type after `TrendDirection`**

Insert after line 33 (`export type TrendDirection = 'up' | 'down';`), before the `// ── Data Interfaces` section comment:

```typescript
/** API response from /api/dashboard/stats — flat aggregate, no presentation fields */
export interface DashboardStatsApiResponse {
  total_users: number;
  active_sessions: number;
  pending_provisions: number;
  success_rate: number;
  trends?: {
    users?: { value: string; direction: TrendDirection };
    sessions?: { value: string; direction: TrendDirection };
    pending?: { value: string; direction: TrendDirection };
    success_rate?: { value: string; direction: TrendDirection };
  };
}
```

- [ ] **Step 2: Verify TypeScript compiles**

Run: `npx tsc --noEmit --project src/frontend/tsconfig.json`
Expected: No errors (new type is additive, nothing references it yet)

- [ ] **Step 3: Commit**

```bash
git add src/frontend/src/types/dashboard.ts
git commit -m "feat(dashboard): add DashboardStatsApiResponse type for backend contract"
```

---

### Task 2: Fix dashboard query hooks

**Files:**
- Modify: `src/frontend/src/lib/queries/dashboard.ts`

- [ ] **Step 1: Update stats hook — change import and response type**

Replace the import line (line 14-22) to add `DashboardStatsApiResponse`:

```typescript
import type {
  DashboardStatsApiResponse,
  ChartDataPoint,
  ChartPeriod,
  QRCodeRow,
  HealthService,
  PendingProvision,
  ActivityEvent,
} from '@/types/dashboard';
```

Note: `StatCardData` removed from import — no longer needed here.

- [ ] **Step 2: Replace `DashboardStatsResponse` interface and hook**

Replace lines 24-39 (the entire stats section) with:

```typescript
// ── Dashboard Stats ──────────────────────────────────────────────────

/** Fetches summary stats — 30s polling. Returns flat aggregate; frontend maps to StatCardData[]. */
export const dashboardStatsQueryOptions = () =>
  queryOptions({
    queryKey: queryKeys.dashboard.stats,
    queryFn: () =>
      getApi().get<DashboardStatsApiResponse>('/dashboard/stats'),
    staleTime: 15_000,
    refetchInterval: 30_000,
  });
```

This deletes `DashboardStatsResponse` and uses `DashboardStatsApiResponse` directly.

> **Note:** Frontend components will map `DashboardStatsApiResponse` → `StatCardData[]` during Phase 4 wiring (#49). The hook returns the raw API shape for flexibility.

- [ ] **Step 3: Add `limit` param to `recentQRQueryOptions`**

Replace lines 65-73 with:

```typescript
/** Fetches recent QR codes — 15s polling */
export const recentQRQueryOptions = (limit = 5) =>
  queryOptions({
    queryKey: queryKeys.dashboard.recentQR(limit),
    queryFn: () =>
      getApi().get<RecentQRResponse>('/qr-codes/recent', { limit }),
    staleTime: 10_000,
    refetchInterval: 15_000,
  });
```

- [ ] **Step 4: Add `limit` param to `activityFeedQueryOptions`**

Replace lines 119-127 with:

```typescript
/**
 * Fetches recent activity — 10s polling (fallback).
 * Phase 4 will add WebSocket subscription for real-time push.
 */
export const activityFeedQueryOptions = (limit = 20) =>
  queryOptions({
    queryKey: queryKeys.dashboard.activity(limit),
    queryFn: () =>
      getApi().get<ActivityFeedResponse>('/activity/recent', { limit }),
    staleTime: 5_000,
    refetchInterval: 10_000,
  });
```

- [ ] **Step 5: Verify TypeScript compiles**

Run: `npx tsc --noEmit --project src/frontend/tsconfig.json`
Expected: No errors

- [ ] **Step 6: Commit**

```bash
git add src/frontend/src/lib/queries/dashboard.ts
git commit -m "fix(dashboard): align hook response types and add limit params to recentQR/activity"
```

---

### Task 3: Parameterize query keys

**Files:**
- Modify: `src/frontend/src/lib/queries/keys.ts:67-74`

- [ ] **Step 1: Update dashboard key definitions**

Replace lines 67-74 with:

```typescript
  // Dashboard
  dashboard: {
    stats: ['dashboard', 'stats'] as const,
    chart: (period: string) => ['dashboard', 'chart', period] as const,
    recentQR: (limit: number = 5) => ['dashboard', 'recentQR', limit] as const,
    health: ['dashboard', 'health'] as const,
    pending: ['dashboard', 'pending'] as const,
    activity: (limit: number = 20) => ['dashboard', 'activity', limit] as const,
  },
```

Only `recentQR` (was static array, now function) and `activity` (was static array, now function) change.

- [ ] **Step 2: Verify TypeScript compiles**

Run: `npx tsc --noEmit --project src/frontend/tsconfig.json`
Expected: No errors (hooks already updated in Task 2 to call these as functions)

- [ ] **Step 3: Commit**

```bash
git add src/frontend/src/lib/queries/keys.ts
git commit -m "fix(dashboard): parameterize recentQR and activity query keys with limit"
```

---

## Chunk 2: Component Fix (Quick Actions)

### Task 4: Fix QuickActionsCard labels and wire navigation

**Files:**
- Modify: `src/frontend/src/components/features/dashboard/QuickActionsCard.tsx`

- [ ] **Step 1: Rewrite QuickActionsCard with navigation**

Replace the entire file contents with:

```tsx
/**
 * QuickActionsCard — 2x2 grid of action buttons for common admin tasks.
 * Labels link to existing routes. No modals (future work).
 */

import { useNavigate } from '@tanstack/react-router';
import { QrCode, UserPlus, FileText, Settings } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@azblink/ui';
import { QuickActionButton } from './QuickActionButton';
import type { QuickAction } from '@/types/dashboard';

export function QuickActionsCard() {
  const navigate = useNavigate();

  const actions: QuickAction[] = [
    {
      id: 'generate-qr',
      icon: QrCode,
      label: 'Generate QR',
      onClick: () => navigate({ to: '/provisioning/qr-generator' }),
    },
    {
      id: 'add-user',
      icon: UserPlus,
      label: 'Add User',
      onClick: () => navigate({ to: '/directory/users/onboard' }),
    },
    {
      id: 'audit-log',
      icon: FileText,
      label: 'Audit Log',
      onClick: () => navigate({ to: '/audit-log' }),
    },
    {
      id: 'settings',
      icon: Settings,
      label: 'Settings',
      onClick: () => navigate({ to: '/configuration' }),
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3">
          {actions.map((action) => (
            <QuickActionButton key={action.id} action={action} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
```

Key changes:
- `useNavigate` imported from `@tanstack/react-router`
- `Download` icon → `Settings` icon (Lucide)
- "Bulk QR" → "Generate QR" (route: `/provisioning/qr-generator`)
- "Add User" → route: `/directory/users/onboard` (actual route, not `/users/new`)
- "Audit Log" → route: `/audit-log`
- "Export" → "Settings" (route: `/configuration`)
- Actions moved inside component (they use `navigate` hook, can't be module-level const)
- Removed `QUICK_ACTIONS` const and mock comment

- [ ] **Step 2: Verify TypeScript compiles**

Run: `npx tsc --noEmit --project src/frontend/tsconfig.json`
Expected: No errors

- [ ] **Step 3: Verify production build**

Run: `cd src/frontend && npx vite build`
Expected: Build succeeds with no errors

- [ ] **Step 4: Commit**

```bash
git add src/frontend/src/components/features/dashboard/QuickActionsCard.tsx
git commit -m "fix(dashboard): correct quick action labels and wire navigation routes"
```

---

## Chunk 3: GitHub Issue Updates

### Task 5: Update GitHub issue #49

- [ ] **Step 1: Update issue body**

Use `gh` CLI or GitHub API to update issue #49 body. Changes:
- Replace `useDashboardStats()` → `dashboardStatsQueryOptions()` in data wiring table
- Replace `useProvisioningChart(period)` → `provisioningChartQueryOptions(period)`
- Replace `useRecentQRCodes()` → `recentQRQueryOptions(limit?)`
- Replace `useSystemHealth()` → `dashboardHealthQueryOptions()`
- Replace `usePendingProvisions()` → `pendingProvisionsQueryOptions()`
- Replace `useActivityFeed()` → `activityFeedQueryOptions(limit?)`
- Update quick action labels: "New User" → "Add User", "Generate QR" (keep), "View Reports" → "Audit Log", "System Settings" → "Settings"
- Update quick action routes: `/users/new` → `/directory/users/onboard`, `/qr/generate` → `/provisioning/qr-generator`, `/audit` → `/audit-log`, `/configuration` (keep)
- Add note: "Hooks already merged in PR #55. Contract types reconciled in reconciliation PR."

---

### Task 6: Update GitHub issue #50

- [ ] **Step 1: Update issue body**

Changes to issue #50:
- Stats endpoint: change return type from `{ users, sessions, pending, successRate }` to `DashboardStatsApiResponse` (flat numeric fields with optional trends)
- Health endpoint: change path from `/api/health/deep` extension to new `/api/dashboard/health` endpoint (auth-required, separate from public health check)
- Add `?limit=` query param to `/api/qr-codes/recent` (default 5) and `/api/activity/recent` (default 20)
- Note all responses use wrapped format: `{ field: [...] }`

---

### Task 7: Update GitHub epic #42

- [ ] **Step 1: Add reconciliation decisions section**

Add a "Phase 4 Reconciliation Decisions" section to issue #42 body, after the "Key decisions" table:

```markdown
### Phase 4 Reconciliation (PR #XX)

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Hook pattern | `*QueryOptions()` factory (not `use*`) | TQ v5 best practice; matches codebase convention |
| Health endpoint | New `/api/dashboard/health` | Separate from public `/api/health/deep` (different auth, shape, purpose) |
| Stats API shape | Backend flat aggregate → frontend maps to `StatCardData[]` | Icons/variants are presentation concerns |
| Response wrappers | All wrapped (`{ field: [...] }`) | Future-proof; matches audit pattern |
| Quick action labels | "Generate QR", "Add User", "Audit Log", "Settings" | Link to existing routes |
```

---

### Task 8: Final verification and squash commit

- [ ] **Step 1: Run full TypeScript check**

Run: `npx tsc --noEmit --project src/frontend/tsconfig.json`
Expected: Zero errors

- [ ] **Step 2: Run production build**

Run: `cd src/frontend && npx vite build`
Expected: Build succeeds

- [ ] **Step 3: Run backend tests (sanity check — no backend changes)**

Run: `just test-quick`
Expected: All tests pass (no backend files changed)
