# Unified Platform Versioning Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Establish unified platform versioning with git-cliff (changelog) + commitizen (version bumps + commit validation), a backend `/api/version` endpoint, and release automation via `just` commands.

**Architecture:** Single version in root `package.json` synced to `src/frontend/package.json` and `src/backend/_version.py` by commitizen. git-cliff generates `CHANGELOG.md` from conventional commits. Pre-commit hook enforces commit message format. Optional GitHub Actions workflow creates GitHub Releases on tag push.

**Tech Stack:** git-cliff (Rust binary), commitizen (Python), pre-commit (Python), just (existing)

**Spec:** `docs/superpowers/specs/2026-03-11-unified-versioning-design.md`

---

## Chunk 1: Version Source of Truth + Configuration Files

### Task 1: Install tools and verify availability

**Files:** None (system-level installs)

- [ ] **Step 1: Install commitizen and pre-commit**

```bash
pip install commitizen pre-commit
```

- [ ] **Step 2: Install git-cliff**

```bash
# Check if already installed
git-cliff --version 2>/dev/null || cargo install git-cliff
```

If cargo is not available, use an alternative:
```bash
# Alternative: npm (runs Rust binary via WASM)
npm install -g git-cliff
# Alternative: snap
sudo snap install git-cliff
# Alternative: prebuilt binary
curl -sSfL https://github.com/orhun/git-cliff/releases/latest/download/git-cliff-x86_64-unknown-linux-gnu.tar.gz | tar xz -C ~/.local/bin/
```

- [ ] **Step 3: Verify all three tools**

Run:
```bash
cz version && git-cliff --version && pre-commit --version
```
Expected: Version numbers for all three.

---

### Task 2: Add version to root package.json

**Files:**
- Modify: `package.json`

- [ ] **Step 1: Add version field to root package.json**

Edit `package.json` to add `"version": "0.2.0"`:

```json
{
  "name": "azb-azblink-directory-and-identity-stack",
  "version": "0.2.0",
  "private": true,
  "workspaces": [
    "src/frontend/packages/azblink-ui",
    "src/frontend"
  ]
}
```

- [ ] **Step 2: Sync frontend package.json version**

Edit `src/frontend/package.json` line 3: change `"version": "0.1.0"` to `"version": "0.2.0"`.

- [ ] **Step 3: Verify JSON is valid**

Run:
```bash
node -p "require('./package.json').version"
node -p "require('./src/frontend/package.json').version"
```
Expected: Both print `0.2.0`.

---

### Task 3: Create commitizen config

**Files:**
- Create: `.cz.toml`

- [ ] **Step 1: Create .cz.toml**

```toml
[tool.commitizen]
name = "cz_conventional_commits"
version = "0.2.0"
tag_format = "v$version"
version_files = [
    "package.json:version",
    "src/frontend/package.json:version",
    "src/backend/_version.py:__version__"
]
update_changelog_on_bump = false
```

- [ ] **Step 2: Verify commitizen reads config**

Run:
```bash
cz version --project
```
Expected: `0.2.0`

---

### Task 4: Create git-cliff config

**Files:**
- Create: `cliff.toml`

- [ ] **Step 1: Create cliff.toml**

```toml
[remote.github]
owner = "KeithMoc"
repo = "azb-azblink-directory-and-identity-stack"

[changelog]
header = """
# Changelog

All notable changes to AZBlink Directory are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/).

"""
body = """
{% if version %}\
    ## [{{ version | trim_start_matches(pat="v") }}] - {{ timestamp | date(format="%Y-%m-%d") }}
{% else %}\
    ## [Unreleased]
{% endif %}\
{% for group, commits in commits | group_by(attribute="group") %}
    ### {{ group | upper_first }}
    {% for commit in commits %}
        - {% if commit.scope %}**{{ commit.scope }}:** {% endif %}\
            {{ commit.message | split(pat="\n") | first | upper_first }}\
            {% if commit.github.pr_number %} \
                ([#{{ commit.github.pr_number }}](https://github.com/{{ remote.github.owner }}/{{ remote.github.repo }}/pull/{{ commit.github.pr_number }}))\
            {% endif %}\
    {% endfor %}
{% endfor %}
"""
footer = ""
trim = true

[git]
conventional_commits = true
filter_unconventional = true
commit_parsers = [
    { message = "^feat", group = "Features" },
    { message = "^fix", group = "Bug Fixes" },
    { message = "^doc", group = "Documentation" },
    { message = "^perf", group = "Performance" },
    { message = "^refactor", group = "Refactor" },
    { message = "^style", group = "Styling" },
    { message = "^test", group = "Testing" },
    { message = "^chore\\(release\\)", skip = true },
    { message = "^chore", group = "Miscellaneous" },
]
protect_breaking_commits = false
filter_commits = false
tag_pattern = "v[0-9].*"
sort_commits = "oldest"

[bump]
features_always_bump_minor = true
breaking_always_bump_major = true
initial_tag = "v0.2.0"
```

- [ ] **Step 2: Test changelog generation (dry run)**

Run:
```bash
git-cliff --config cliff.toml --unreleased
```
Expected: Renders recent conventional commits grouped by type. Non-conventional commits are filtered out.

---

### Task 5: Create pre-commit hook config

**Files:**
- Create: `.pre-commit-config.yaml`

- [ ] **Step 1: Create .pre-commit-config.yaml**

```yaml
repos:
  - repo: https://github.com/commitizen-tools/commitizen
    rev: v4.2.2
    hooks:
      - id: commitizen
        stages: [commit-msg]
```

- [ ] **Step 2: Install the hook**

Run:
```bash
pre-commit install --hook-type commit-msg
```
Expected: `pre-commit installed at .git/hooks/commit-msg`

- [ ] **Step 3: Verify hook rejects bad messages**

Run:
```bash
echo "bad message" | cz check
```
Expected: Exit code 1, error about invalid commit message format.

Run:
```bash
echo "feat: add versioning" | cz check
```
Expected: Exit code 0, passes validation.

---

### Task 6: Commit configuration files

- [ ] **Step 1: Commit all config files**

```bash
git add .cz.toml cliff.toml .pre-commit-config.yaml package.json src/frontend/package.json
git commit -m "feat: add unified versioning configuration (commitizen + git-cliff)

- Add .cz.toml for commitizen (version bumps + commit validation)
- Add cliff.toml for git-cliff (changelog generation)
- Add .pre-commit-config.yaml for commit-msg hook
- Set platform version to 0.2.0 in root and frontend package.json

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

## Chunk 2: Backend Version Endpoint

### Task 7: Write test for /api/version endpoint

**Files:**
- Modify: `tests/test_health.py`

- [ ] **Step 1: Add version endpoint tests to test_health.py**

Append to the end of `tests/test_health.py`:

```python
class TestVersionEndpoint:
    """Version endpoint for deployment traceability."""

    def test_version_returns_200(self, client):
        """Version endpoint is public and returns 200."""
        resp = client.get("/api/version")
        assert resp.status_code == 200

    def test_version_contains_required_fields(self, client):
        """Version response includes version, gitHash, gitBranch, buildTime."""
        resp = client.get("/api/version")
        data = resp.json()
        assert "version" in data
        assert "gitHash" in data
        assert "gitBranch" in data
        assert "buildTime" in data

    def test_version_is_semver_format(self, client):
        """Version string matches semver pattern."""
        import re
        resp = client.get("/api/version")
        version = resp.json()["version"]
        assert re.match(r"^\d+\.\d+\.\d+", version), f"Version '{version}' is not semver"

    def test_health_includes_version(self, client):
        """Basic health check also includes version field."""
        resp = client.get("/api/health")
        data = resp.json()
        assert "version" in data
```

- [ ] **Step 2: Run tests to verify they fail**

Run:
```bash
pytest tests/test_health.py::TestVersionEndpoint -v
```
Expected: All 4 tests FAIL (endpoint doesn't exist yet, health doesn't have version).

---

### Task 8: Create backend _version.py

**Files:**
- Create: `src/backend/_version.py`

- [ ] **Step 1: Create _version.py**

```python
"""Platform version — updated by commitizen during `cz bump`."""
__version__ = "0.2.0"
```

---

### Task 9: Add /api/version endpoint and version to /api/health

**Files:**
- Modify: `src/backend/main.py`

- [ ] **Step 1: Add os import to main.py**

Add `os` to the import on `main.py:7`, maintaining alphabetical order (between `json` and `time`). Change:
```python
import json, time, secrets, base64, hmac, hashlib, logging, asyncio, ipaddress
```
to:
```python
import json, os, time, secrets, base64, hmac, hashlib, logging, asyncio, ipaddress
```

- [ ] **Step 2: Add /api/version endpoint**

Insert between `api_health_deep` (ends at line 459) and the Models section (line 463). Place the new endpoint in the existing health check section block:

```python
@app.get("/api/version")
def api_version():
    """Platform version + build metadata for deployment traceability.

    - version: SemVer from _version.py (bumped by commitizen)
    - gitHash, gitBranch, buildTime: injected via env vars at build time
    """
    from _version import __version__
    return {
        "version": __version__,
        "gitHash": os.environ.get("GIT_HASH", "unknown"),
        "gitBranch": os.environ.get("GIT_BRANCH", "unknown"),
        "buildTime": os.environ.get("BUILD_TIME", "unknown"),
    }
```

- [ ] **Step 3: Add version to /api/health response**

Change the `api_health` function (lines 401-404) from:
```python
def api_health():
    """Basic liveness check - always returns 200 if app is running."""
    return {"ok": True, "status": "healthy"}
```
to:
```python
def api_health():
    """Basic liveness check - always returns 200 if app is running."""
    from _version import __version__
    return {"ok": True, "status": "healthy", "version": __version__}
```

- [ ] **Step 4: Add GIT_HASH/GIT_BRANCH/BUILD_TIME env vars to backend container**

These env vars are currently only passed to the frontend container. Add them to the `directory-api` service in `deploy/dev/docker-compose.yml`, in the `environment:` block (after the REDIS_URL line):

```yaml
      # Version metadata (for /api/version endpoint)
      GIT_HASH: ${GIT_HASH:-unknown}
      GIT_BRANCH: ${GIT_BRANCH:-unknown}
      BUILD_TIME: ${BUILD_TIME:-unknown}
```

Note: The Justfile already exports `GIT_HASH`, `GIT_BRANCH`, and `BUILD_TIME` (lines 9-11), so they flow through to `docker compose` automatically when using `just up`.

- [ ] **Step 5: Run tests to verify they pass**

Run:
```bash
pytest tests/test_health.py -v
```
Expected: All tests pass, including the 4 new `TestVersionEndpoint` tests and the existing 3 `TestHealthEndpoints` tests (7 total).

---

### Task 10: Commit backend version changes

- [ ] **Step 1: Commit**

```bash
git add src/backend/_version.py src/backend/main.py tests/test_health.py deploy/dev/docker-compose.yml
git commit -m "feat: add /api/version endpoint and backend version tracking

- Create _version.py as commitizen-managed version source
- Add GET /api/version with version, gitHash, gitBranch, buildTime
- Add version field to GET /api/health response
- Pass GIT_HASH/GIT_BRANCH/BUILD_TIME env vars to backend container
- Add 4 integration tests for version endpoint

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

## Chunk 3: Frontend Rewire + Justfile Commands

### Task 11: Rewire frontend to read version from root package.json

**Files:**
- Modify: `src/frontend/vite.config.ts`

- [ ] **Step 1: Change package.json import**

In `src/frontend/vite.config.ts` line 13, change:
```typescript
import pkg from './package.json'
```
to:
```typescript
import pkg from '../../package.json'
```

- [ ] **Step 2: Verify Vite still resolves the version**

Run:
```bash
cd src/frontend && node -e "
  const pkg = require('../../package.json');
  console.log('version:', pkg.version);
  console.assert(pkg.version === '0.2.0', 'Version mismatch');
  console.log('OK');
"
```
Expected: `version: 0.2.0` then `OK`.

- [ ] **Step 3: Verify TypeScript compilation**

Run:
```bash
cd src/frontend && npx tsc --noEmit 2>&1 | head -20
```
Expected: No errors related to version or package.json import.

---

### Task 12: Add versioning commands to Justfile

**Files:**
- Modify: `Justfile`

- [ ] **Step 1: Add versioning section to Justfile**

Append before the `# =============================================================================` / `# Database & LDAP` section (before line 198):

```just
# =============================================================================
# Versioning & Release
# =============================================================================

# Show current platform version
version:
    @node -p "require('./package.json').version"

# Guided conventional commit (interactive TUI)
cz-commit:
    cz commit

# Preview next version bump (dry run)
release-dry:
    @echo "=== Dry Run: Version Bump ==="
    @cz bump --dry-run
    @echo ""
    @echo "=== Dry Run: Changelog Preview ==="
    @git-cliff --bump --unreleased

# Bump version + generate changelog + tag
release:
    cz bump --yes && git-cliff -o CHANGELOG.md && git add CHANGELOG.md && git commit --amend --no-edit
```

- [ ] **Step 2: Verify just version works**

Run:
```bash
just version
```
Expected: `0.2.0`

- [ ] **Step 3: Verify just --list shows new commands**

Run:
```bash
just --list | grep -E "version|release|cz"
```
Expected: Lists `version`, `cz-commit`, `release-dry`, `release`.

---

### Task 13: Commit frontend + Justfile changes

- [ ] **Step 1: Commit**

```bash
git add src/frontend/vite.config.ts Justfile
git commit -m "feat: rewire frontend version to root package.json and add release commands

- Frontend vite.config.ts reads version from root package.json
- Add just version, cz-commit, release-dry, release commands

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

## Chunk 4: GitHub Actions + Changelog + Final Verification

### Task 14: Create GitHub Actions release workflow

**Files:**
- Create: `.github/workflows/release.yml`

- [ ] **Step 1: Create .github directory**

```bash
mkdir -p .github/workflows
```

- [ ] **Step 2: Create release.yml**

```yaml
name: Release

on:
  push:
    tags: ['v*']

jobs:
  release:
    name: Create GitHub Release
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - name: Checkout
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Generate release notes
        uses: orhun/git-cliff-action@v4
        id: changelog
        with:
          config: cliff.toml
          args: --latest --strip header
        env:
          GITHUB_REPO: ${{ github.repository }}

      - name: Create GitHub Release
        uses: softprops/action-gh-release@v2
        with:
          body: ${{ steps.changelog.outputs.content }}
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

---

### Task 15: Generate initial CHANGELOG.md

**Files:**
- Create: `CHANGELOG.md`

- [ ] **Step 1: Create initial git tag for changelog baseline**

The tag marks the starting point for changelog generation. This does NOT trigger a release — it just gives git-cliff a baseline.

```bash
git tag v0.2.0
```

- [ ] **Step 2: Generate changelog**

Run:
```bash
git-cliff --config cliff.toml -o CHANGELOG.md
```

- [ ] **Step 3: Verify changelog content**

Run:
```bash
head -30 CHANGELOG.md
```
Expected: Header with "# Changelog", followed by `## [0.2.0]` section with grouped commits.

---

### Task 16: Update .gitignore

**Files:**
- Modify: `.gitignore`

- [ ] **Step 1: Add SCR cache directory**

The `.scr/` directory from the SCR skill should be ignored. Append to `.gitignore`:

```
.scr/
```

(Note: No version-related files need ignoring — `CHANGELOG.md`, `_version.py`, configs are all tracked.)

---

### Task 17: Run full test suite

- [ ] **Step 1: Run all tests**

Run:
```bash
just test-quick
```
Expected: All existing tests pass with no new failures. Pay special attention to:
- `tests/test_health.py` — 7 tests (3 existing + 4 new)
- No import errors from `_version.py`

---

### Task 18: Final commit and tag

- [ ] **Step 1: Commit remaining files**

```bash
git add .github/workflows/release.yml CHANGELOG.md .gitignore
git commit -m "feat: add GitHub Actions release workflow and initial changelog

- Add .github/workflows/release.yml for GitHub Release on tag push
- Generate initial CHANGELOG.md with git-cliff
- Update .gitignore with .scr/ directory

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

- [ ] **Step 2: Move tag to include all changes**

```bash
git tag -d v0.2.0
git tag v0.2.0
```

- [ ] **Step 3: Verify everything**

Run:
```bash
just version          # → 0.2.0
cz version --project  # → 0.2.0
git tag -l             # → v0.2.0
cat CHANGELOG.md | head -20  # → changelog header + 0.2.0 section
curl -s http://localhost:8081/api/version | jq .  # → version object
curl -s http://localhost:8081/api/health | jq .version  # → "0.2.0"
```

---

## Summary: File Map

### Created (6 files)
| File | Purpose |
|------|---------|
| `.cz.toml` | Commitizen config — version bumps + commit validation |
| `cliff.toml` | git-cliff config — changelog template + commit parsing |
| `.pre-commit-config.yaml` | Pre-commit hook — commit message validation |
| `src/backend/_version.py` | Backend version source (commitizen-managed) |
| `CHANGELOG.md` | Auto-generated changelog |
| `.github/workflows/release.yml` | GitHub Release creation on tag push |

### Modified (7 files)
| File | Change |
|------|--------|
| `package.json` | Add `"version": "0.2.0"` |
| `src/frontend/package.json` | Sync version `0.1.0` → `0.2.0` |
| `src/frontend/vite.config.ts:13` | Import from `../../package.json` |
| `src/backend/main.py` | Add `os` import (line 7), `/api/version` endpoint (after line 459), version in `/api/health` (line 402) |
| `deploy/dev/docker-compose.yml` | Add GIT_HASH/GIT_BRANCH/BUILD_TIME env vars to backend container |
| `Justfile` | Add versioning & release commands (before Database & LDAP section) |
| `tests/test_health.py` | Add 4 version endpoint tests (append after existing class) |
| `.gitignore` | Add `.scr/` |
