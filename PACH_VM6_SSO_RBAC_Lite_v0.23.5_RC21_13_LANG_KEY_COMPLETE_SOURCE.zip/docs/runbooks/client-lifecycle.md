---
title: Client lifecycle
description: Register a building client, rotate its credentials, and deregister it, as the code and the prod playbooks do it today
type: runbook
product: azb-azblink-directory-and-identity-stack
status: current
updated: 2026-10-26
---

# Client lifecycle

A building box is a **client**. This runbook registers one, rotates its
credentials, and deregisters it. Every step describes what the seed, the
playbooks and the API do on `main` today (v0.19.0 plus #383 to #388). Where a
step is manual because no tooling exists, the step says so.

For a building `<b>` (2 to 16 characters, `[a-z0-9]`), SafeNest's ids are:

| Name | Value | What it is |
|---|---|---|
| `<c>` | `safenest-<b>` | Headless first-party client: the relay's OAuth2 provider and its role-group prefix ([ARD-018](../architecture/decisions/ARD-018-headless-first-party-client-login.md)) |
| `<svc>` | `safenest-<b>-directory` | Client-scoped service principal: the roster writer ([ARD-019](../architecture/decisions/ARD-019-client-scoped-service-principals.md)) |
| PBX identity | `cn=<c>,ou=pbx,ou=clients,<base>` | The building's UED box reads SIP secrets with it ([ARD-020](../architecture/decisions/ARD-020-client-sip-provisioning-and-pbx-read.md)) |

`<base>` is `ldap_base_dn` (`dc=azblink,dc=com` in the prod example), and
`<host>` is `azblink_public_host`. Vars live in
`deploy/ansible/inventories/prod/group_vars/all/main.yml`.

## Before you start

You need:

- the vault password, and `sudo` on the stack's host;
- an `IT-Admins` member who can sign in to the admin UI at `https://<host>/`;
- a fresh backup. Take one before every converge:
  `sudo systemctl start azblink-backup.service` ([backup and restore](backup-restore.md)).

Authentik Admin API calls run **on the host**, over SSH: port 9000 binds
loopback only. Load the token once per shell:

```bash
AK=$(sudo grep -oP '^AUTHENTIK_BOOTSTRAP_TOKEN=\K.*' /opt/azblink-directory/deploy/dev/.env)
ak() { curl -sf -H "Authorization: Bearer $AK" -H 'Content-Type: application/json' "$@"; }
```

Directory steps run as the `IT-Admins` member, in the admin UI. The API calls
next to them are the same operation, for reference. Prod has no CLI sign-in:
`directoryctl` authenticates with `DEV_AUTH_TOKEN`, which prod refuses. To
`curl` the directory API you need that admin's own access token.

> [!WARNING]
> A [restore](backup-restore.md#restore) rolls every client secret back to the
> archive's time. After a restore, repeat any rotation or deregistration made
> since that archive.

## Register a building

About 1 hour, plus the converge. Inputs from the building's operator:

- `<b>`, the building id;
- the relay's redirect URI or URIs, exact (`/authorize` checks them);
- the relay box's static IPv4 address on the private path, not shared with another client;
- whether the building has a UED PBX. If it does: its extension range (no overlap
  with another profile's, at most 1000 numbers) and a UID range for its users.

The relay box itself must map `<host>` to `azblink_private_ip` and trust
`azblink_tls_ca` ([ARD-021](../architecture/decisions/ARD-021-prod-issuer-tls-and-relay-path.md)).
That is set up on the client's side.

> [!NOTE]
> **One call since [ARD-022](../architecture/decisions/ARD-022-first-party-client-onboarding.md).**
> An `IT-Admins` member's `POST /api/clients/onboard {clientId: "safenest-<b>", redirectUris: [...],
> sipBlockSize?, sipRangeStart?, sipContext?}` does everything in steps 1 to 4 below except trusting the
> relay's address. It returns both Authentik secrets, the PBX and ejabberd bind secrets and the XMPP
> bridge password, each only from the call that creates it: save the first response. Hand them over as
> in step 2. An env client (already in `authentik_first_party_clients`) is refused. The admin UI's
> Add client screen makes this call: [onboard a building](onboard-a-building.md) walks through it.
> To let an AI agent make this call, register the MCP server
> [`tools/directory-mcp`](../../tools/directory-mcp/README.md) with its MCP client, with an admin's token.
>
> **The relay address.** Trusting a relay's `X-Forwarded-For` is Authentik startup config (ARD-021),
> so it stays a converge. Pass the relay box's static IPv4 as `relayIp`; the response's
> `relay.operatorStep` names what is left: add the client to `authentik_onboarded_clients` and
> `<c>: <ip>` to `authentik_relay_ips` in `main.yml`, then converge (step 1). Until then Authentik
> sees the relay box as the source of every sign-in it relays. A building that does not relay
> sign-ins needs neither entry, and preflight asks nothing of it. Step 5 applies either way.
> A `relayIp` another onboarded client already has is refused (409). To stop trusting a relay, call
> again with `relayIp: null`: `relay.operatorStep` then names the two entries to remove before the
> next converge.

### 1. Inventory and converge

1. Add all four entries in `main.yml`, in one change:

   ```yaml
   authentik_first_party_clients:
     safenest-<b>: ["https://<relay>/auth/callback"]
   authentik_relay_ips:
     safenest-<b>: <relay ip>           # bare IPv4; env.j2 trusts it as a /32
   authentik_service_clients:
     safenest-<b>-directory: []        # a scoped principal holds no permissions
   authentik_service_client_scopes:
     safenest-<b>-directory: {client: safenest-<b>, roles: [admin, staff, resident, visitor]}
   ```

   The API refuses to start when a scope names a client that is not in
   `authentik_first_party_clients`, or when a service client holds both
   permissions and a scope (`config.py:130-155`). The seed refuses a client id
   that nests with another one (`safenest` beside `safenest-a1`). `preflight.yml`
   refuses a first-party client with no relay IP, a relay IP for no client, and
   an address that is shared, loopback, unspecified, multicast or the box's own
   (ARD-021 amendment 2026-10-22). Leave `authentik_trusted_proxy_cidrs` alone:
   relays go in `authentik_relay_ips`.
2. Back up, then converge:
   `ansible-playbook -i inventories/prod site.yml --ask-vault-pass -K`
3. `verify.yml` waits for both providers. The changed `.env` reruns
   `authentik-seed`, which creates:
   - for `<c>`: a confidential provider (`authorization_code` + `refresh_token`,
     access 15 min, refresh 7 d) on the shared `headless-first-party-auth` flow,
     an application, and the access policy `<c>: member of <c>-*`;
   - for `<svc>`: a confidential `client_credentials`-only provider (access
     15 min), an application, and the access policy
     `<svc>: only ak-<svc>-client_credentials`, so a person's app password cannot
     mint a token through it (#390). Authentik creates the service account
     `ak-<svc>-client_credentials` later, on the first `client_credentials`
     token, not here.

   The API now accepts `<svc>` as an audience and loads its scope.

### 2. Hand over the two client secrets

Authentik generates each secret. The seed never reads it back, never rotates it,
and never overwrites it.

```bash
for id in safenest-<b> safenest-<b>-directory; do
  ak "http://localhost:9000/api/v3/providers/oauth2/?client_id=$id" \
    | jq -r --arg id "$id" '.results[] | select(.client_id == $id) | "\(.client_id) \(.client_secret)"'
done
```

Put each one straight into the building's vault: the relay needs `<c>`'s, the
roster writer needs `<svc>`'s. Do not paste them into tickets or chat.

### 3. Directory objects

Do these after the converge: the API reserves the org name `<c>` for admins and
treats `<c>-*` groups as client role groups only once `<c>` is registered.

1. Check that `ou=<c>,ou=people,<base>` is empty or absent (directory → orgs).
   API: `GET /api/org/users?orgDn=ou=<c>,ou=org,<base>&includeSub=1` lists no users.
2. Create the org `<c>` at the top of the org tree.
   API: `POST /api/org/create {"name": "safenest-<b>"}`. Only `IT-Admins` may use a client id as an org name.
3. Create the four role groups at the top of `ou=groups`, lowercase:
   `safenest-<b>-admin`, `-staff`, `-resident`, `-visitor`.
   API: `POST /api/groups/create {"cn": "safenest-<b>-admin"}`, once per role.
   Each create queues the Authentik LDAP source sync.

   Never create groups under `ou=<c>,ou=groups`: membership there makes the
   building's users non-contained, and the principal gets 403 on them
   ([spec 08](../architecture/spec/08-integration-points.md#first-party-headless-login-as-built)).

The roster writer then creates the building's users under `ou=<c>,ou=people`
(owned). A person in two buildings stays in `ou=people` and joins both buildings'
groups (adopted).

### 4. Phones (buildings with a UED PBX)

1. Create a SIP profile for the building, then assign it to the org:
   `POST /api/config-templates` with `uidRangeStart`/`uidRangeEnd` set (the default
   5000-65533 collides with Standard Profile), `POST /api/config-templates/{id}/services`
   with the SIP service and its extension range, then
   `POST /api/config-templates/{id}/assign {"org_dn": "ou=<c>,ou=org,<base>"}`.
   An overlapping SIP range answers 409; one wider than 1000 answers 422.
2. Optional org default context:
   `POST /api/org/sip_context {"dn": "ou=<c>,ou=org,<base>", "sipContext": "default"}`.
3. Provision the PBX identity:
   `POST /api/settings/ldap/clients/provisioned {"client_id": "safenest-<b>", "kind": "pbx"}`.
   The response holds the bind DN and a secret, **shown once**. It goes into the
   UED box's SIP-in-LDAP settings
   ([spec 08 §3](../architecture/spec/08-integration-points.md#asterisk--sip)).
4. UED cannot do LDAPS. The prod default publishes LDAP plaintext on loopback
   only. Either tunnel the box to it, or set `azblink_allow_plaintext_ldap: true`
   and `ldap_publish: "<private ip>:389"`, firewall it to the box's `/32`, and
   converge.

### 5. Verify

1. The service principal gets a token and the API takes it. The check only
   reads, so it is safe on a live building too. On the host:

   ```bash
   read -rs SECRET          # paste the <svc> secret; it is not echoed or kept in history
   TOKEN=$(curl -sf http://localhost:9000/application/o/token/ \
     -d grant_type=client_credentials -d client_id=safenest-<b>-directory \
     --data-urlencode "client_secret=$SECRET" | jq -r .access_token)
   unset SECRET
   curl -s -o /dev/null -w '%{http_code}\n' \
     -H "Authorization: Bearer $TOKEN" http://localhost:8081/api/users/<uid>
   ```

   For `<uid>`, use a user the building owns. Before it has any, use one that
   does not exist.

   | Answer | Meaning |
   |---|---|
   | `200` with an owned uid, or `404` with a missing uid | Accepted and in scope. A `404` also writes a `scoped_denied` audit row |
   | `401` | Audience or issuer not accepted: the converge did not apply |
   | `403` | Token accepted, but no scope loaded |

   An empty `TOKEN` means the token endpoint refused the secret.

   Do not check with a scoped write. `PATCH /api/groups/{cn}` with `sipContext`
   recomputes every member's SIP context, so on a live group it overwrites the
   building's choice.
2. The relay signs in a test user who is in a `<c>-*` group. A user in none of
   them is refused at `/authorize`. This is SafeNest's acceptance check, run from
   the relay box.
3. With a PBX: a phone registers with its extension and SIP password.
4. Add the building to the client registry table in
   [spec 08](../architecture/spec/08-integration-points.md#first-party-headless-login-as-built)
   in a docs PR, with the trailer `Spec-Patch: 08`.

## Rotate credentials

About 10 minutes per secret. Each client has three: two in Authentik and one in
LDAP.

> [!IMPORTANT]
> Authentik holds **one** secret per provider. There is no overlap window: the old
> secret stops working the moment the new one is saved. Measured on dev
> (2026-10-22): after the change, the token endpoint refused the old secret
> (`invalid_grant`) and took the new one. Until the client has the new secret,
> the relay cannot sign anyone in, or the roster writer cannot write. Agree a
> time with the building's operator first.

No tooling rotates these: the seed never touches a secret, and there is no API
for it. Each rotation is the Admin API call below.

### Relay or service-client secret

1. Find the provider and make a new secret:

   ```bash
   ID=safenest-<b>            # or safenest-<b>-directory
   PK=$(ak "http://localhost:9000/api/v3/providers/oauth2/?client_id=$ID" \
     | jq -r --arg id "$ID" '.results[] | select(.client_id == $id) | .pk')
   NEW=$(python3 -c 'import secrets; print(secrets.token_urlsafe(64))')
   ```

2. Save it: `ak -X PATCH -d "{\"client_secret\": \"$NEW\"}" "http://localhost:9000/api/v3/providers/oauth2/$PK/" -o /dev/null && echo saved`
3. Put `$NEW` into the client's vault and restart the client. Then `unset NEW`.
4. For a service client, re-run the read-only token check in step 1 of
   [Verify](#5-verify), with a uid the building owns.

Tokens issued before the rotation stay valid. On dev, the rotation left the
provider's access tokens in place. For a relay, users keep their sessions: their
refresh tokens are not tied to the secret. That is expected from Authentik's
model but has not been tested end to end.

### After a leak

Rotate as above, then cut off what was already issued:

- **Relay (`<c>`):** delete the provider's refresh and access tokens. Every
  building user signs in again.

  ```bash
  for kind in refresh_tokens access_tokens; do
    ak "http://localhost:9000/api/v3/oauth2/$kind/?provider=$PK&page_size=500" | jq -r '.results[].pk' \
      | while read -r t; do ak -X DELETE "http://localhost:9000/api/v3/oauth2/$kind/$t/" -o /dev/null; done
  done
  ```

  Run it again until both lists are empty: one call returns 500 at most.
- **Service principal (`<svc>`):** this API checks tokens locally against the
  JWKS and never asks Authentik, so deleting them in Authentik does not stop
  them here. A stolen access token works until it expires, at most 15 minutes. To
  stop it sooner, remove `<svc>` from `authentik_service_clients` and
  `authentik_service_client_scopes` and converge: the API restarts and refuses
  its audience. Add it back with the new secret when the client is clean.

### PBX secret

1. `POST /api/settings/ldap/clients/provisioned/safenest-<b>/rotate` returns the
   new secret once. The old bind fails from now on.
2. Enter it in the UED box's SIP-in-LDAP settings. UED reads PJSIP live from
   LDAP, so phones cannot register again until the box has the new secret.
   Registered phones stay registered until their registration expires.

Other credentials are outside this runbook: user passwords (`reset_password`),
the relay-path certificate (a re-converge, ARD-021), and the `authentik-sync` bind
secret ([`deploy/ansible/README.md`](../../deploy/ansible/README.md)).

## Deregister a building

About 1 hour, plus the converge and 3 seconds per user. The order matters: the
API deletes a role group's Authentik copy only while `<c>` is still registered,
and terminates users only while their accounts can still be reached.

Decide first where the building's people go:

- **They leave the service:** terminate them (step 3).
- **They move to another building:** move each owned user out of
  `ou=<c>,ou=people` (`move_org`) and add them to the new building's groups
  before step 3. Then terminate only those who stay behind.

### 1. Restore point

`sudo systemctl start azblink-backup.service`, and note the archive's name.

### 2. Stop the phones and the XMPP server's directory reads

`DELETE /api/settings/ldap/clients/provisioned/safenest-<b>`. This deletes the
PBX identity from LDAP. The UED box can no longer read SIP secrets, so phones
stop registering. If the building also has a profile, remove its assignment:
`DELETE /api/config-templates/{id}/assignments/{assignment_id}`.

A client onboarded through the API (ARD-022) also has an XMPP search identity,
`cn=safenest-<b>-ejabberd,ou=clients,<base>`. Like every `ou=clients` entry it
reads the whole directory except secrets (ACL `{4}`,
`deploy/dev/ldap/ldap-clients-acl.ldif`): every user's name, mail, mobile, groups
and extension, in every building. Revoke it as well:
`DELETE /api/settings/ldap/clients/provisioned/safenest-<b>-ejabberd`. The
building's ejabberd can no longer look users up, so XMPP sign-in stops there.

Check: `GET /api/settings/ldap/clients/provisioned` lists neither `safenest-<b>`
nor `safenest-<b>-ejabberd`.

Removing the assignment does **not** free the extension range. Every profile's
SIP service keeps its range claimed, assigned or not (`db/templates.py:68-79`).
Two calls free it:

- `DELETE /api/config-templates/{id}/services/{service_id}` deletes the SIP service only;
- `DELETE /api/config-templates/{id}` deletes the whole profile.

Free it only when another building needs the range, and once you will not
restore this one. The terminated users keep their extension attributes in LDAP.

### 3. Terminate the building's users

List them: `GET /api/org/users?orgDn=ou=<c>,ou=org,<base>&includeSub=1`. Then,
for each uid:
`POST /api/users/{uid}/terminate {"reason": "building deregistered"}`.

Each termination locks the LDAP entry with the termination sentinel, revokes
the user's provisioning tokens and Authentik sessions, tokens and app passwords,
and deactivates the Authentik user. It answers `partial: true` when an Authentik
step failed. Call it again for those users: every step is idempotent.

There is no bulk terminate. The route allows 20 calls a minute per client IP, so
600 users take 30 minutes. Script the loop with a 3-second pause.

Adopted users (in `ou=people`, outside `ou=<c>`) are not terminated. They lose
the building's groups in the next step and keep everything else.

An onboarded client also owns the XMPP bridge account
`uid=safenest-<b>.xmpp-bridge,ou=safenest-<b>,ou=people`. Check that it is in the
list and terminated with the rest.

### 4. Delete the role groups

While `<c>` is still registered, delete every one of its role groups. That is every
group whose name starts with `safenest-<b>-`: the four defaults (`-admin`, `-staff`,
`-resident`, `-visitor`), or the roles an onboarded client was given (`roles`), plus any
`safenest-<b>-*` group onboarding adopted. List them as the `IT-Admins` member
(`TOKEN` is that admin's access token), then delete each.

`search` only narrows the list: it also matches descriptions and longer names. What is
deleted is chosen by the group's name alone, `cn`, which must start with `safenest-<b>-`,
compared case-insensitively. That is the set the LDAP source's group filter
`(cn=safenest-<b>-*)` syncs, so a mixed-case `Safenest-<b>-X` is deleted too (left behind,
it would keep syncing into Authentik). A group whose description mentions the client,
`safenest-<b>x-…`, or another client's `safenest-<other>-…` is never selected.

1. List them, and read the list:

   ```bash
   DIR=https://<host>/api
   curl -sf -H "Authorization: Bearer $TOKEN" "$DIR/groups?search=safenest-<b>-" \
     | jq -r --arg p "safenest-<b>-" '.groups[] | select(.cn | ascii_downcase | startswith($p)) | .cn' >role-groups.txt
   cat role-groups.txt
   ```

2. When it names only this building's role groups, delete them:

   ```bash
   while read -r cn; do
     curl -sf -X DELETE -H "Authorization: Bearer $TOKEN" "$DIR/groups/$cn" -o /dev/null && echo "deleted $cn"
   done <role-groups.txt
   ```

3. Check: run the list block again. It prints nothing.
4. Check the Authentik copies on the host, selected by the same rule: by `.name`
   alone, prefix `safenest-<b>-` in any case. A few seconds after the deletes,
   this prints nothing:

   ```bash
   ak "http://localhost:9000/api/v3/core/groups/?search=safenest-<b>-&page_size=500" \
     | jq -r --arg p "safenest-<b>-" '.results[] | select(.name | ascii_downcase | startswith($p)) | "\(.pk) \(.name)"' >ak-role-groups.txt
   cat ak-role-groups.txt
   ```

The API deletes each group's Authentik copy too, whatever the case of its name:
the copy is named with the group's `cn` as written. The LDAP source never deletes
groups. If the check in item 4 still lists copies (the client was already gone
from the inventory, or Authentik was down), delete what the list names by hand:

```bash
while read -r pk name; do
  ak -X DELETE "http://localhost:9000/api/v3/core/groups/$pk/" -o /dev/null && echo "deleted $name"
done <ak-role-groups.txt
```

### 5. Inventory and converge

1. Remove all four entries from `main.yml` in one change:
   `safenest-<b>` from `authentik_first_party_clients` and from
   `authentik_relay_ips`, and `safenest-<b>-directory` from both
   `authentik_service_clients` and `authentik_service_client_scopes`. Removing
   the client while leaving its scope stops the API from starting. Leaving its
   relay IP makes `preflight.yml` refuse the converge.

   A client onboarded through the API (ARD-022) is in none of those four lists.
   If it relays, remove `safenest-<b>` from `authentik_onboarded_clients` and from
   `authentik_relay_ips` instead, in one change. Left in both, Authentik keeps
   trusting the old relay address; left in only one, `preflight.yml` refuses the
   converge.
2. **Onboarded client only: delete its registry row.** The converge never touches
   the table `first_party_clients`, where `POST /api/clients/onboard` registered the
   client. While the row is there, the API keeps accepting `safenest-<b>-directory`
   tokens for the building's users, and a later onboard of `safenest-<b>` counts as a
   repeat and skips the Authentik-takeover and "people OU already holds users" checks.
   On the host:

   ```bash
   sudo docker exec -i azblink-postgres sh -c 'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"' <<'SQL'
   DELETE FROM first_party_clients WHERE client_id = 'safenest-<b>' RETURNING client_id, service_client_id;
   SQL
   ```

   It prints the deleted row (`safenest-<b> | safenest-<b>-directory`) and
   `DELETE 1`. `DELETE 0` means the id is wrong or the client is an env client. Every
   API worker drops the client within 10 seconds: each reloads the registry on that
   interval.
3. Converge. For an env client, the API restarts without `<svc>` in its scoped
   principals and refuses its tokens. For an onboarded client the converge changes
   no token rule; step 2 did that. In both cases the LDAP source **keeps** syncing
   `(cn=safenest-<b>-*)`: the seed keeps every term already on the source's group
   filter, so that clients onboarded at runtime survive a reseed. Step 5.4 removes it.
4. **Drop the group-sync term.** The role groups are gone since step 4, so the
   term matches nothing today, but any later group named `safenest-<b>-*` would
   sync into Authentik. On the host, with `ak` loaded:

   ```bash
   SRC=$(ak http://localhost:9000/api/v3/sources/ldap/azblink-ldap/)
   echo "$SRC" | jq --arg t '(cn=safenest-<b>-*)' \
     '{group_object_filter: (.group_object_filter | split($t) | join("")), sync_groups, group_property_mappings}' \
     | ak -X PATCH http://localhost:9000/api/v3/sources/ldap/azblink-ldap/ -d @- | jq -r .group_object_filter
   ```

   It prints the filter without `(cn=safenest-<b>-*)`. When that was the last term,
   it prints `(&(objectClass=groupOfNames)(|))`, which matches no group, and the
   next converge turns group sync off.

### 6. Delete what the seed left in Authentik

The seed never deletes: removing a client from the inventory leaves its
providers, applications, two access policies and service account in Authentik.
Delete them by hand:

```bash
for app in safenest-<b> safenest-<b>-directory; do
  ak -X DELETE "http://localhost:9000/api/v3/core/applications/$app/" -o /dev/null && echo "app $app deleted"
  PK=$(ak "http://localhost:9000/api/v3/providers/oauth2/?client_id=$app" \
    | jq -r --arg id "$app" '.results[] | select(.client_id == $id) | .pk')
  [ -n "$PK" ] && ak -X DELETE "http://localhost:9000/api/v3/providers/oauth2/$PK/" -o /dev/null && echo "provider $app deleted"
done
SA_NAME=ak-safenest-<b>-directory-client_credentials
printf '%s\n' 'safenest-<b>: member of safenest-<b>-*' "safenest-<b>-directory: only $SA_NAME" |
while read -r NAME; do
  POL=$(ak -G "http://localhost:9000/api/v3/policies/expression/" --data-urlencode "name=$NAME" \
    | jq -r --arg n "$NAME" '.results[] | select(.name == $n) | .pk')
  [ -n "$POL" ] && ak -X DELETE "http://localhost:9000/api/v3/policies/expression/$POL/" -o /dev/null && echo "policy '$NAME' deleted"
done
SA=$(ak "http://localhost:9000/api/v3/core/users/?username=$SA_NAME" \
  | jq -r --arg u "$SA_NAME" '.results[] | select(.username == $u) | .pk')
[ -n "$SA" ] && ak -X DELETE "http://localhost:9000/api/v3/core/users/$SA/" -o /dev/null && echo "service account deleted"
```

Deleting a provider also deletes its tokens. The service account, which exists
once the principal has minted a token, is not deleted with its provider. Both
were measured on dev on 2026-10-22. Leave the shared
`headless-first-party-auth` flow: other clients use it.

Check: `ak "http://localhost:9000/api/v3/providers/oauth2/?client_id=safenest-<b>" | jq .pagination.count`
answers `0`, and the same for `safenest-<b>-directory`.

### 7. Leave the org, retire the id

- **Do not delete the org `ou=<c>`.** Its terminated users stay in the tree as
  the record of termination. While they are there, `DELETE /api/org/{dn}`
  answers 409 and changes nothing.
- **Never reuse `<c>` for another building.** A client registered under the same
  id would own every user left under `ou=<c>,ou=people` (ARD-019 invariant 6).
  With the registry row deleted (step 5.2), `POST /api/clients/onboard` refuses that
  id (409) while those users are there. Inventory registration has no such check.
- Mark the building retired in the spec 08 client registry, in a docs PR.
- Tell the building's operator to remove the relay's secret and the `<host>`
  hosts entry from its box.

## Availability for the pilot

The pilot runs **one Authentik**: one `authentik-server`, one `authentik-worker`
and one `authentik-postgres`, on the same single host as LDAP and the API. There
is no standby and no failover. "Authentik down" pages after 2 minutes.

While Authentik is down:

| Who | Effect |
|---|---|
| Residents' phones and XMPP (Plane A) | Keep working: they bind LDAP directly |
| Relay sign-in and refresh | Fail. Issued access tokens keep working at the client until they expire, at most 15 minutes |
| Roster writer | Cannot get a token, so building writes stop after at most 15 minutes |
| Admin UI | Unavailable: there is no fallback sign-in (spec 04 §6) |

If LDAP is down instead, phones and every sign-in fail: Authentik checks
passwords by binding LDAP.

**Restore-time targets for the pilot:**

| Failure | Recovery | Target | Basis |
|---|---|---|---|
| Authentik container crash | `restart: unless-stopped`, else `docker compose restart` | 15 min | Restart only; no migrations on an existing database |
| Data damaged, host fine | [Restore](backup-restore.md#same-host-data-damaged) the latest archive | 1 h | Restore took 35 s in the drill. The rest is finding the archive and checking |
| Host lost | [New host](backup-restore.md#new-host-old-one-lost): converge, then restore | 4 h | Not measured. Fresh Authentik needs 2.5 to 4 min of migrations; host setup and converge are untimed |
| Data loss window (any restore) | Nightly archive | 24 h | Changes since 02:30 are lost and re-applied by hand |

The 4-hour target is an estimate: time the first prod converge and correct it.
Going beyond one Authentik (a second server and worker, a replicated Postgres)
is not planned for the pilot.
