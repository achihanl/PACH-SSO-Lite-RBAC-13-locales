---
title: Onboard a building
description: Tutorial for adding a building as a client on the Add client screen, and how an Azblink PED80 then uses the directory
type: runbook
product: azb-azblink-directory-and-identity-stack
status: current
updated: 2026-10-24
---

# Onboard a building

This tutorial is for the operator who brings a new building onto the directory.
It has two parts:

1. **Add the client.** An admin adds the building on the Add client screen
   (`/configuration/clients/new`, [ARD-022](../architecture/decisions/ARD-022-first-party-client-onboarding.md))
   and stores the five secrets it shows once.
2. **Connect the PED80.** How the building's Azblink PED80 (its UED PBX) uses
   the directory, and which parts of that are verified on real hardware.

[Client lifecycle](client-lifecycle.md) is the full runbook, covering rotation
and deregistration as well. This page walks through the first day only.

> [!NOTE]
> The screenshots come from the E2E journey
> (`src/frontend/e2e/journey/add-client.spec.ts`), run on a disposable test
> stack. The client id there is a random fixture (`e2e…`), the redirect URI
> points at that stack, and every secret value is painted over. A real building
> uses its own id and an https redirect URI. To refresh the images, run the
> journey with `E2E_SHOTS_DIR` set, then `python3 tools/tutorial_shots.py <that dir>`.

## Part 1: Add the client

### Before you start

You need:

- an account in the directory admin group (`IT-Admins` in Authentik). Other
  users can sign in, but the screen shows them no form;
- a fresh backup ([backup and restore](backup-restore.md));
- a place to put five secrets right away, such as the building's vault entry.
  The screen shows them once.

From the building's operator, collect:

| Input | Example | Notes |
|---|---|---|
| Client id | `safenest-ped80` | 2 to 39 characters: lowercase letters and digits, with single hyphens between them. It names the org, the role groups and the login client. No client's id may start with another client's id followed by `-`: beside `ped80`, `ped80-annex` is refused, and so is `ped80` beside `ped80-annex` |
| Redirect URIs | `https://relay.ped80.example/auth/callback` | 1 to 10 exact callback URLs of the building's relay app. https outside dev, no wildcards, no fragments |
| Relay IP (optional) | `10.20.0.5` | The relay box's static IPv4 on the private path, if it relays sign-ins ([ARD-021](../architecture/decisions/ARD-021-prod-issuer-tls-and-relay-path.md)) |
| SIP block size (optional) | `100` | How many extensions the building gets. Default 100, at most 1000 |
| First extension (optional) | `6000` | Leave empty to start the block above every existing range |
| SIP context | **Unchanged** | `default` or `all`. **Unchanged** gives a new building `default` and leaves a repeat's org context as it is. What `all` can reach is up to the PBX dialplan |

### 1. Sign in

Open the admin UI and choose **Sign in with Authentik**.

![The admin UI sign-in page with a Sign in with Authentik button](onboard-a-building/01-sign-in.png)

Enter your username and password on the Authentik page. The first time, Authentik
asks you to consent to the app.

![Authentik's sign-in page with the username filled in](onboard-a-building/02-authentik.png)

### 2. Open Add Client and fill in the form

In the sidebar, under **Configuration**, choose **Add Client**. Fill in the
inputs you collected.

![The Add client form, with a client id, a redirect URI, a relay IP of 10.20.0.5 and a SIP block size of 10](onboard-a-building/03-add-client-form.png)

The screen checks the form before it sends anything. Errors show under each
field after the first **Add client**, and nothing is sent until they are fixed:

![Field errors: the client id ped_80 has an underscore, the redirect URI has a wildcard, and 127.0.0.1 is loopback](onboard-a-building/04-form-checks.png)

### 3. Submit

Choose **Add client**. The call takes a few seconds, longer on a fresh box.
While it runs, the screen keeps you on the page: in-app links are blocked, and a
reload or a tab close asks first. Leaving would drop the response, and with it
the only copy of the secrets.

One call creates everything the building needs, in this order:

1. the registry row for the client and its service principal `<c>-directory`;
2. the org `ou=<c>,ou=org` and the role groups `<c>-admin`, `<c>-staff`,
   `<c>-resident` and `<c>-visitor`;
3. a profile assigned to the org, with its own SIP block and UID block, and the
   org's SIP context;
4. the PBX identity `cn=<c>,ou=pbx,ou=clients` and the XMPP search identity
   `cn=<c>-ejabberd,ou=clients`;
5. the XMPP bridge user `uid=<c>.xmpp-bridge`;
6. last, in Authentik: the login client `<c>`, the service client
   `<c>-directory`, and `(cn=<c>-*)` in the LDAP source's group filter.

### 4. Store the five secrets, now

The result page shows each secret once, with a **Copy** button. Copy each one
into the building's vault before you do anything else.

![The result page: a warning to store the secrets now, five secrets (values painted over) each with a Copy button, what the client has, and the relay step](onboard-a-building/06-secrets-once.png)

| Secret | Belongs to | Who uses it |
|---|---|---|
| Login client secret (OIDC) | `<c>` | The building's relay, to sign its users in through Authentik ([ARD-018](../architecture/decisions/ARD-018-headless-first-party-client-login.md)) |
| Directory service client secret | `<c>-directory` | The building's roster writer, to create its users and set their SIP secrets ([ARD-019](../architecture/decisions/ARD-019-client-scoped-service-principals.md)) |
| PBX bind secret | `cn=<c>,ou=pbx,ou=clients,<base>` | The PED80's SIP-in-LDAP settings (Part 2) |
| XMPP server (ejabberd) bind secret | `cn=<c>-ejabberd,ou=clients,<base>` | The building's ejabberd, to look users up in LDAP |
| XMPP bridge password | `uid=<c>.xmpp-bridge,ou=<c>,ou=people,<base>` | The building's XMPP bridge account |

> [!WARNING]
> **The secrets show once and cannot be recovered.** They are kept only in this
> page's memory: not in the browser's storage, not in the URL, not in a log.
> They are gone when you choose **Done, I stored them**. Until then the page
> holds you on it: a link is blocked with a reminder, and a reload or close asks
> first. Directory admins are not Authentik superusers, so the
> directory cannot read them back either. A lost secret is rotated, never
> recovered ([client lifecycle § Rotate credentials](client-lifecycle.md#rotate-credentials)).

Adding the same client again is safe: the call resumes and changes nothing that
already exists. It returns no secrets, because a secret comes back only from
the call that creates it. Each row says how to rotate its secret, if you do not
hold it (after a `502`, the earlier steps' secrets were never shown):

![The same client added again: no secrets returned, each one marked as not returned with how to rotate it, and Created by this call reads Nothing](onboard-a-building/07-repeat-no-secrets.png)

Below the secrets, **What the client has** lists the org, the role groups, the
building's SIP extensions (here `2000–2009`, a block of 10), its SIP context and
its login issuer path. Note the SIP block: Part 2 uses it.

### 5. Finish the relay step (relay IP only)

The relay IP is stored, not trusted. Trusting a relay's `X-Forwarded-For` is
Authentik startup config, so it takes a converge. The **Relay … one more step**
card names it: add `<c>` to `authentik_onboarded_clients` and `<c>: <ip>` to
`authentik_relay_ips` in the prod inventory, then converge
([client lifecycle § Inventory and converge](client-lifecycle.md#1-inventory-and-converge)).
Until then, Authentik sees the relay box as the source of every sign-in it
relays. A building that does not relay sign-ins has no relay step.

Each relay box needs its own IP: one another client already has is refused
(`409`). The screen cannot clear a relay IP (an empty field leaves it as it
is); that is an API call with `relayIp: null`
([client lifecycle](client-lifecycle.md)).

### What the screen refuses

| Answer | When | What to do |
|---|---|---|
| Field error, nothing sent | The client id, a redirect URI or the relay IP is malformed, or a number is not a whole number of 1 or more | Fix the field |
| `422` | The API's own checks: the SIP block is larger than 1000, an http redirect URI outside dev, or a value the form cannot judge | Fix the value and submit again |
| `409` | The client id nests with another client's, or is taken in Authentik by something this call did not create; the people OU already holds users; a SIP range overlaps another profile's; the client already has a different SIP range; the relay IP is another client's; `<c>-*` groups carry RBAC permissions; the id prefixes the admin group; or a `<c>-*` group (for a repeat, the group of a role it adds) exists that onboarding did not create | Choose another id, or clear the conflict the message names |
| `403` | You are not in the admin group | Ask a directory admin |
| `429` | More than 10 calls a minute from one address | Wait a minute |
| `502` | A step failed. The screen says the client was partly added: the steps before it are kept | Submit again: the call resumes. Secrets those steps issued are not returned; rotate them |
| `503` | Authentik's admin API, the client registry, the authorization state (the group-permission lookup) or the audit log is unavailable. Nothing was changed | Try again later |

The screen shows an API refusal as `<status>: <detail>` under the form. A SIP
block of 5000 is larger than the API allows:

![The SIP block size is 5000, and the screen shows: The client was not added. 422: sipBlockSize is at most 1000](onboard-a-building/05-refused-422.png)

A client id that starts with an existing client's id and a hyphen is refused,
so that one client's `<c>-*` role groups can never cover another's:

![The client id is the existing client's id plus -annex, and the screen shows a 409: the client id nests with the existing one](onboard-a-building/08-refused-409.png)

A signed-in user who is not an admin has no **Add Client** link and gets no
form at the address. The API answers them `403` as well:

![Signed in as a user who is not an admin: the sidebar has no Add Client link, and the page says only directory administrators can add clients](onboard-a-building/09-not-admin.png)

The call writes an `onboard_client` row to the audit log, never with a secret,
when it starts, finishes or fails, and for each `409` refusal.

## Part 2: How the PED80 uses the directory

The Azblink PED80 runs UED, whose Asterisk reads its SIP accounts from LDAP
through realtime (`res_ldap`). It never asks the directory API: it binds to
LDAP as the building's PBX identity and reads the building's residents.

```mermaid
flowchart LR
    phone["SIP phone<br/>user = extension"] -- "REGISTER, digest" --> ued["PED80 / UED<br/>Asterisk res_ldap"]
    ued -- "LDAP :389, plaintext<br/>bind cn=&lt;c&gt;,ou=pbx,ou=clients" --> ldap[("Directory LDAP")]
    writer["Roster writer<br/>&lt;c&gt;-directory"] -- "PUT /api/users/{uid}/sip" --> api["Directory API"]
    api --> ldap
    relay["Relay box<br/>static IP"] -- "TLS :443 Authentik<br/>:8443 API, :636 LDAPS" --> host["Directory host<br/>private IP"]
```

### 1. The residents' SIP accounts come from the block

The roster writer (with the directory service client secret) creates each
resident under `ou=<c>,ou=people` and turns SIP on with
`PUT /api/users/{uid}/sip` ([spec 05](../architecture/spec/05-provisioning.md)).
The directory picks the next free extension in the building's block, or takes
the one the writer names if it is free and in the block. For each resident it
writes ([ARD-020](../architecture/decisions/ARD-020-client-sip-provisioning-and-pbx-read.md)):

- the extension as the account name: `AstAccountName`, `AstEndpointId`,
  `AstAorId`, `AstAuthId`, `AstAuthUsername` and the endpoint's AoR and auth
  references. Phones register with the extension as username;
- `AstAuthType=userpass`, the SIP secret in `AstAuthPassword` (separate from the
  login password), and `AstAuthRealm=asterisk`;
- `AstEndpointContext`, resolved user over group over org, falling back to
  `default`.

### 2. Point UED at the building's PBX identity

In UED, under **Phone » Basic » SIP in LDAP**, set ([spec 08](../architecture/spec/08-integration-points.md#asterisk--sip)):

| UED field | Value |
|---|---|
| Server, port | The directory's LDAP on the private path, `389` (UED cannot do LDAPS) |
| Bind DN | `cn=<c>,ou=pbx,ou=clients,<base>`, the PBX identity from Part 1 |
| Password | The PBX bind secret from Part 1 |
| Base DN | `ou=<c>,ou=people,<base>`, the building's own residents |
| Search filter | The default, `(AstAccountName=*)` |
| Realm | `asterisk`, not UED's default `azblink2` |

The provisioned PBX identity shows up on **Configuration » LDAP Clients**, beside
the building's ejabberd identity:

![LDAP Clients: each onboarded client has a PBX identity under ou=pbx,ou=clients and an ejabberd identity under ou=clients](onboard-a-building/10-ldap-clients.png)

The same settings in plain Asterisk terms, as an excerpt from the simulator that
stands in for a PED80 in tests. The full files, which also map `ps_endpoints`
and `ps_aors`, are [res_ldap.conf](../../deploy/dev/relay-sim/asterisk/res_ldap.conf)
and [extconfig.conf](../../deploy/dev/relay-sim/asterisk/extconfig.conf):

```ini
; res_ldap.conf (excerpt)
[_general]
url = ldap://<directory host>:389
basedn = dc=azblink,dc=com
user = cn=<c>,ou=pbx,ou=clients,dc=azblink,dc=com
pass = <PBX bind secret>

[ps_auths]
additionalFilter = (AstAccountName=*)
id = AstAuthId
auth_type = AstAuthType
password = AstAuthPassword
username = AstAuthUsername
realm = AstAuthRealm

; extconfig.conf (excerpt): search only the building's residents
ps_auths => ldap,"ou=<c>,ou=people,dc=azblink,dc=com",ps_auths
```

What the PBX identity can read is fixed by an LDAP ACL, whatever the box is
configured with: `AstAuthPassword` only for entries directly under its own
`ou=<c>,ou=people`, and only while the resident is not suspended or terminated.
Another building's residents' secrets are never readable to it.

UED reads LDAP on every request, so a new resident registers, and a suspended
one is refused, within about a second, with no VoIP restart. A phone that was
already registered keeps receiving calls until its registration expires.

### 3. Keep the LDAP path private

UED has no TLS field, so the bind and the SIP secrets cross the network in
clear. The production default publishes plaintext LDAP on loopback only. Either
tunnel the PED80 to it (preferred), or set `azblink_allow_plaintext_ldap: true`
and `ldap_publish: "<private ip>:389"`, firewall it to the PED80's `/32`, and
converge ([ARD-021 §4](../architecture/decisions/ARD-021-prod-issuer-tls-and-relay-path.md)).
This is the one written exception to TLS on the private path.

### 4. The relay path

The building's relay box, not the PED80, signs residents in. It reaches the
directory host on the routed private path ([ARD-021 §3](../architecture/decisions/ARD-021-prod-issuer-tls-and-relay-path.md)):
it maps the public host name to the host's private IP, trusts the directory's
CA, and uses Authentik on `:443`, the API on `:8443` and LDAPS on `:636`, so it
gets the same `iss` as a browser. Its static IP is the relay IP from Part 1;
once the converge in Part 1 step 5 has run, Authentik trusts its
`X-Forwarded-For` and sees each resident's own address
([ARD-022](../architecture/decisions/ARD-022-first-party-client-onboarding.md)).

### What is verified, and where

> [!IMPORTANT]
> Not everything in Part 2 has been checked against a real PED80. This tutorial
> describes the design and the simulator; it does not change a live PED80.

| Claim | Simulated stack | Real PED80 (192.168.122.220) |
|---|---|---|
| A resident's phone registers with its extension and SIP secret (`200`), a wrong secret gets `401` | Verified: the E2E journey and `tests/test_relay_path.py`, against Asterisk 20 with the `res_ldap` config above | Verified on 2026-10-20 with `userpass` on a probe user and the LDAP admin bind, before the onboarding screen existed ([ARD-020, verification results](../architecture/decisions/ARD-020-client-sip-provisioning-and-pbx-read.md#2026-10-20-verification-results)) |
| UED binds as a non-admin DN under `ou=clients` with a building-scoped base DN | Verified, with the identity the Add client call returns | Verified on 2026-10-20: UED loaded the endpoint, but REGISTER got `401` because the ACL rule did not exist yet |
| The PBX identity from Add client, behind the ACL rule, serves a real PED80 | Verified | **Not verified.** The ACL rule landed after the 2026-10-20 test |
| Changes apply in about a second; suspend refuses the next REGISTER | Verified | Verified on 2026-10-20 |
| `from-internal` routes nothing; `default` and `all` route | Mirrored: the simulator's dialplan copies UED's contexts | Verified on 2026-10-20 |
| HA1 digest (`AstAuthType=md5`, `AstAuthMd5Cred`) | Not tested | **Not working.** REGISTER answered `500`. It waits for Azblink to map `md5_cred` to `AstAuthMd5Cred` in UED's `res_ldap.conf`. Until then the directory writes `userpass` and no `AstAuthMd5Cred` |
| Relay sign-ins over the private path with TLS and a trusted relay IP | Verified (relay-sim, `tests/test_relay_path.py`) | Not applicable: the PED80 is not the relay. No real relay box is recorded as tested |
| XMPP: ejabberd logs the bridge and a resident in with the onboarded identity | Verified, against a simulated ejabberd | Not verified with UED's ejabberd |

When Azblink confirms the `md5_cred` mapping, ARD-020's verification steps 1 to
3 are re-run on the PED80. Only a pass there moves the directory to HA1, by an
amendment to ARD-020.
