---
title: Backup and restore
description: The nightly backup of LDAP, both Postgres databases and Redis, how to restore it, and how to drill a restore
type: runbook
product: azb-azblink-directory-and-identity-stack
status: current
updated: 2026-10-24
---

# Backup and restore

The `azblink_backup` Ansible role installs `/usr/local/sbin/azblink-backup` and a
systemd timer on the stack's host. Every night the script writes one archive that
holds every store the stack cannot rebuild:

| File in the archive | Source | Holds |
|---|---|---|
| `ldap-config.ldif` | `slapcat -n 0` in `openldap` | `cn=config`: schema, ACLs, overlays (ppolicy, unique, memberof, refint) |
| `ldap-data.ldif` | `slapcat -n 1` in `openldap` | Every directory entry: users, passwords, UC attributes, `ou=clients` |
| `directory.pgdump` | `pg_dump -Fc` in `postgres` | Profiles, profile services, device provisions, audit, settings |
| `authentik.pgdump` | `pg_dump -Fc` in `authentik-postgres` | Authentik: providers, client secrets, signing keys, users, sessions, tokens |
| `redis.rdb` | `redis-cli --rdb` in `redis` | Rate limits, the account-lock mirror; rebuildable, kept so a restore matches its time |
| `MANIFEST`, `SHA256SUMS` | the script | Time, compose project, image of each store, checksums |

Prometheus, Loki and Grafana data are not backed up: they are monitoring
history, and the stack runs without them.

## What runs, and where

- **When:** daily at 02:30 host time (`backup_on_calendar`), up to 10 minutes
  later at random. `Persistent=true` runs a missed backup at the next boot.
- **Where:** `/var/backups/azblink/azblink-<UTC time>.tar.gz.gpg`, root only (mode 0600).
- **Retention:** every archive under 14 days (`backup_retention_days`), then the newest
  archive of each ISO week for 12 weeks (`backup_retention_weeks`). Ages come from the UTC
  date in the file name. That holds on the host, which names its own archives. The
  target applies the same tiers to the day it sealed each upload, never to a name the
  host chose (`seal` and `prune-sealed`, see "Set it up").
- **Off-host copy:** after each run, `rsync` over SSH uploads only the new archive to
  `backup_offhost_target`, with no delete option. The host never removes anything there,
  so the target keeps its own history: clearing `/var/backups/azblink`, a new host's
  first run, or an attacker with root on the host cannot wipe it.
- **Append-only check:** before each upload the script runs a dry-run `rsync --delete`
  against the target. The target's key is restricted to `rrsync -wo -no-del`, which
  refuses it. If the probe succeeds, the target would accept deletes: the run uploads
  nothing, fails, and writes no success metric.
- **Encryption:** archives are encrypted to `backup_encryption_public_key`
  (`gpg --recipient-file`). The private half never touches the host, so the host cannot
  read what it sent. The role refuses an off-host target without the public key: the
  archives hold password hashes, SIP secrets in plaintext and every Authentik client
  secret. It also refuses a private key in that variable.
- **Proof of life:** after the off-host copy succeeds, the run writes
  `azblink_backup_last_success_timestamp_seconds` (Unix time) to
  `/var/lib/azblink/metrics/azblink_backup.prom`, through a temp file and a rename.
  Alloy's textfile collector reads it, and the "Backup too old" alert fires when
  it is more than 26 hours old or missing. A run without an off-host target
  writes no metric, so the alert keeps firing until the target is set.

The script finds the containers by their compose labels
(`com.docker.compose.project`, `com.docker.compose.service`), so it needs no
compose files. Prod's project is `dev`, the basename of `deploy/dev`
(`backup_compose_project`). The script has no default project and refuses to run
without one.

> [!WARNING]
> Keep the private key (and a second copy) off the host, in the owner's password
> manager. Without it no archive restores.

## Set it up

1. **Make the encryption key pair** on a trusted machine, never on the stack's host:

   ```bash
   export GNUPGHOME=$(mktemp -d)
   gpg --batch --passphrase '' --quick-gen-key azblink-backup ed25519 cert never
   FPR=$(gpg --list-keys --with-colons | awk -F: '/^fpr/ {print $10; exit}')
   gpg --batch --passphrase '' --quick-add-key "$FPR" cv25519 encr never
   gpg --armor --export "$FPR" > azblink-backup.pub.asc
   gpg --armor --export-secret-keys "$FPR" > azblink-backup.key.asc
   ```

   Store `azblink-backup.key.asc` in the password manager, plus one more copy off-site,
   then delete the local files and `$GNUPGHOME`.
2. **Prepare the target**, a machine outside the stack's host, with an account of its own
   (`backup` below) and a directory it uploads into:

   ```bash
   sudo install -d -o backup -m 0700 /srv/azblink/incoming
   sudo install -d -o root -m 0700 /srv/azblink/sealed
   ```

3. **Make the SSH key** for the host: `ssh-keygen -t ed25519 -N '' -f azblink-backup`.
   On the target, add `azblink-backup.pub` to `~backup/.ssh/authorized_keys` behind the
   forced command, so the key can only write and never delete:

   ```text
   command="rrsync -wo -no-del /srv/azblink/incoming",restrict ssh-ed25519 AAAA... azblink-backup
   ```

4. **Seal each upload** out of the backup account's reach, and prune by seal date.
   `rrsync -no-del` refuses deletes but not a same-name overwrite, and the host chooses
   every upload's name, so the target must never trust names. Copy
   `deploy/ansible/roles/azblink_backup/files/azblink-backup` to `/usr/local/sbin/` on the
   target, then in root's crontab:

   ```text
   */15 * * * * /usr/local/sbin/azblink-backup seal /srv/azblink/incoming /srv/azblink/sealed
   30 4 * * * /usr/local/sbin/azblink-backup prune-sealed /srv/azblink/sealed
   0 * * * * /usr/local/sbin/azblink-backup check-fresh /srv/azblink/sealed https://hc-ping.com/<target-check-uuid>
   ```

   `seal` moves uploads older than 5 minutes into `sealed/<UTC date>/`, never over an
   existing file, and makes that directory only when something arrives. `prune-sealed`
   counts only day directories that hold an archive: it keeps 14 of them, then the newest
   of each ISO week for 12 weeks, and drops the rest whole. A host that stops mid-week, or
   never runs on a Sunday, keeps its newest archives and its weeklies. Those dates come from the target's clock, so a
   host that uploads junk named for past weeks cannot push a real weekly archive out. Never
   run the name-based `prune` on the target. A ZFS or btrfs snapshot schedule, or an
   object-lock bucket, does the same job.

   `check-fresh` is the target's own dead-man's switch, the owner's healthchecks.io check
   (period 1 hour, grace 2 hours), separate from the alert heartbeat's. It pings only while
   an archive was sealed within the last 26 hours (`FRESH_MAX_HOURS`), judged by the time
   the target sealed it (the file's ctime), which the host cannot set. A dead host, a broken
   push, or an attacker who stops uploading and fakes the host's own metrics stops the pings,
   and healthchecks.io pages.
5. **Set the values.** In `inventories/prod/group_vars/all/vault.yml`:

   ```yaml
   backup_offhost_target: "backup@nas.example:"
   backup_offhost_ssh_key: |-
     -----BEGIN OPENSSH PRIVATE KEY-----
     ...
     -----END OPENSSH PRIVATE KEY-----
   ```

   Nothing after the colon. The key's `rrsync` already puts uploads in
   `/srv/azblink/incoming`, so a path such as `:incoming` would land them in
   `incoming/incoming/`, where `seal` never looks, and nothing would ever be sealed.
   Every run refuses a target with a path, and no success metric is written.

   In `main.yml`, `backup_encryption_public_key` holds the contents of
   `azblink-backup.pub.asc`.
6. **Converge the role only:**

   ```bash
   ansible-vault encrypt inventories/prod/group_vars/all/vault.yml
   ansible-playbook -i inventories/prod site.yml --tags backup --ask-vault-pass -K
   ```

7. Take the first backup and check it reached the target (step 2 of the next section).
   A run that logs `accepts deletes` means step 3's forced command is missing.

The first SSH connection records the target's host key in
`/etc/azblink/backup_known_hosts` (trust on first use). Check the fingerprint the
first run logs against the target's own.

A prod converge refuses to start without the target, its SSH key and
`backup_encryption_public_key`, unless `backup_local_only_accepted` (`main.yml`)
records who accepted backups on the host alone, when and why: `"<who> <date>: <why>"`.
Dev and test inventories skip that check. Without a target the role still installs
the timer. Backups then stay on the host, every run logs
`WARNING: OFFHOST_TARGET is empty`, and no success metric is written.

On the target, never `chown` or `chmod` anything under `sealed/`. Either one sets the
file's ctime to now, and `check-fresh` then counts an old archive as freshly sealed.

## Check, or take a backup now

Run these on the stack's host. Take a backup before every upgrade converge.

1. Take one now (it blocks until done; 8 seconds on the drill stack):
   `sudo systemctl start azblink-backup.service`
2. Read the log of the last run: `sudo journalctl -u azblink-backup.service -n 20`
3. List archives and the last success:
   `sudo ls -l /var/backups/azblink/ && cat /var/lib/azblink/metrics/azblink_backup.prom`
4. See the next scheduled run: `systemctl list-timers azblink-backup.timer`

A run that fails exits non-zero, so the unit shows `failed` in `systemctl status`
and the metric stops moving. After 26 hours "Backup too old" fires.

## Restore

`azblink-backup restore FILE --yes` replaces all four stores in the compose
project from one archive, in this order:

1. Checks `SHA256SUMS`, then stops `directory-api`, `authentik-server` and `authentik-worker`.
2. Drops and recreates both databases, then `pg_restore`s them.
3. Stops `openldap`, wipes both LDAP volumes and `slapadd`s `cn=config`, then the
   directory, in a throwaway container on the same volumes.
4. Stops `redis` and copies `redis.rdb` in as `/data/dump.rdb`.
5. Starts LDAP and Redis, waits for them to be healthy, then starts the API and Authentik.

It took 35 seconds in the drill.

> [!CAUTION]
> A restore rolls everything back to the archive's time. Anyone suspended or
> terminated after it is active again, and a client secret rotated after it is
> the old one again. The audit log rolls back with it. Before you reopen the
> service, list those changes from tickets and email, and apply them again.

### Same host, data damaged

1. Pick the archive: `sudo ls -l /var/backups/azblink/` (or copy one from the target).
2. Put the private key on the host for the restore only, in memory:
   `install -m 0600 /dev/stdin /dev/shm/azblink-backup.key.asc`, then paste it.
3. Restore it:
   `sudo azblink-backup restore /var/backups/azblink/azblink-<time>.tar.gz.gpg --yes --key /dev/shm/azblink-backup.key.asc`.
   The key goes into a throwaway keyring that is deleted when the restore exits. A key
   with a passphrase also needs `KEY_PASSPHRASE_FILE=<file>`.
4. Delete the key: `shred -u /dev/shm/azblink-backup.key.asc`.
5. Run the checks under [Verify a restore](#verify-a-restore).

### New host, old one lost

1. Converge the new host with the same `vault.yml` and the same `azblink_branch`
   (release tag) as the lost host, with the backup timer off so the new host backs up
   nothing before the restore:
   `ansible-playbook -i inventories/prod site.yml --ask-vault-pass -K -e backup_timer_enabled=false`.
   The vault must match: the LDAP admin password, the `authentik-sync` bind secret
   and the Authentik secret key are all in the archive too.
2. Copy the newest archive from the target's sealed directory to `/var/backups/azblink/`
   on the new host.
3. Restore it with the off-host key, as in steps 2-4 above, then verify.
4. Converge once more without `-e backup_timer_enabled=false` to start the timer.

To restore one store only, run that store's commands from `restore()` in
`deploy/ansible/roles/azblink_backup/files/azblink-backup` by hand. Restoring one
store alone leaves it out of step with the others, for example Authentik users
that LDAP no longer has.

## Verify a restore

1. `curl -s http://localhost:8081/api/health/deep` answers `"ok": true`.
2. A known user signs in to the admin UI.
3. `GET /api/users/<uid>` lists a user created shortly before the archive's time.
4. A phone or XMPP client registers with its LDAP credentials (Plane A).

## Drill a restore

Drill on a disposable private stack, never on `dev` or prod. The private stack
must have its own project name. Before you start it, check that none of its
volumes or networks starts with `dev_`.

1. Start a private stack from the CI overlay with its own `name:` and free host
   ports. The defaults of `tools/backup_drill.py` expect API `38000`, Authentik
   `39000` and Redis `36380` with password `drill-redis-pass`, the demo
   `DEV_AUTH_TOKEN`, and the redirect URI `http://localhost:38081/auth/callback`.
   The `DRILL_*` environment variables override each of these.
2. Seed a marker in every store: `python3 tools/backup_drill.py seed`. Note the `TAG`.
3. Back up with a config file whose `COMPOSE_PROJECT` is the private project and whose
   `PUBLIC_KEY_FILE` is a drill key pair's public half (make one as in "Set it up"):
   `AZBLINK_BACKUP_CONFIG=drill.env deploy/ansible/roles/azblink_backup/files/azblink-backup run`
4. Wipe it: `docker compose -p <private project> ... down -v`, then bring it up fresh.
5. `python3 tools/backup_drill.py verify <TAG>` must **fail** on all four checks.
6. Restore from the off-host copy:
   `AZBLINK_BACKUP_CONFIG=drill.env azblink-backup restore <archive> --yes --key <drill private key>`
7. `python3 tools/backup_drill.py verify <TAG>` must print `drill PASSED`.

`verify` checks the LDAP user, the directory-Postgres profile and the Redis key.
Then the drill user signs in through Authentik's password flow, which checks the
password with an LDAP bind. It exchanges a PKCE authorization code on the
`azblink-directory` client, and the API accepts the user's access token.

### Drill record

| Date | Stack | Result |
|---|---|---|
| 2026-10-22 | private `azblink-t37`, Redis with a password, archive encrypted, restored from the off-host copy | Before restore: 4 of 4 checks failed. After: 4 of 4 passed. `cn=config` kept the four overlays and five ACLs. Restore took 35 s |

## Single node

The pilot runs one host: one `authentik-server`, one `authentik-worker`, one
Postgres per database, one OpenLDAP. There is no failover. The worst case is the
loss of the host: rebuild it from the newest archive (up to 24 hours of changes
lost), as in [New host, old one lost](#new-host-old-one-lost). For what keeps
working while one service is down, see
[spec 04 §6](../architecture/spec/04-authentication.md#6-graceful-degradation).
The pilot's restore-time targets are in
[client lifecycle](client-lifecycle.md#availability-for-the-pilot).
