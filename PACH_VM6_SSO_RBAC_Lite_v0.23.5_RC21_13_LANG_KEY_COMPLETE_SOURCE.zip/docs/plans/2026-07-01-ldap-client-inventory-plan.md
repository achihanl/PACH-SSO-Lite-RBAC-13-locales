---
title: LDAP Client Inventory & Acknowledgement — Implementation Plan
description: Implementation plan for detecting, classifying, and acknowledging LDAP clients that bind directly to the platform OpenLDAP
type: design
product: azblink-directory
status: superseded
updated: 2026-08-08
---

# LDAP Client Inventory & Acknowledgement — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: `superpowers:executing-plans` — task-by-task, TDD.

**Goal:** Detect, classify, inventory, and acknowledge LDAP clients binding directly to the platform OpenLDAP, surfaced on `/configuration/settings`.
**Architecture:** approved spec `docs/superpowers/specs/2026-07-01-ldap-client-inventory-design.md` (Approach 1: `olcLogFile` stats-log tailer → Postgres `ldap_clients` → classified inventory + ack). Integration map: session context (Phase 1 explorer).
**Tech Stack:** FastAPI (sync endpoints), SQLAlchemy Core, PostgreSQL, osixia OpenLDAP, React 19 + TanStack Query, `@azblink/ui`.
**Domains:** database, backend, devops, frontend, test.

## Locked decisions (refinements from exploration)
- **D1** `source_ip` = `VARCHAR(45)` (match convention; no `INET`); validate `ipaddress.ip_address()`.
- **D2** `ldap_clients` `Table` in `orgdb.py` `metadata` (created by `create_all()`); CRUD as `OrgDB` methods; `028_ldap_clients.sql` hand-mirror.
- **D3** Collector `src/backend/ldap_activity.py`: pure parser fns + lifespan-managed `asyncio.Task`; all exceptions caught internally.
- **D4** API: 3 sync endpoints in `main.py`, `require_permission("system_configuration")`, `{"ok":True,...}` envelope, Pydantic PATCH body, GET catches I/O → `{"ok":True,"clients":[],"warning":...}` (never 500).
- **D5** `acknowledged_by` = `preferred_username`→`uid`→`sub`→`"system"`; also `ORGDB.record_admin_action(extract_actor(claims),...)`.
- **D6** Frontend: `LdapClientsSection` (9th), registered in `SettingsNav` + `SettingsManagementPage`; own `useQuery`/`useMutation` (NOT save-bar); `refetchInterval ~12s`.
- **D7** Compose: RO mount `azblink_ldap_data:/var/lib/ldap:ro` on `directory-api`; `olcLogFile` bootstrap ldif + mount on `openldap`; default `LDAP_STATS_LOG_PATH=/var/lib/ldap/slapd-stats.log`.
- **D8** Classification: ordered rules in `ldap_activity.py` + env `LDAP_KNOWN_SERVICE_CIDRS`; `localhost + cn=admin` → `healthcheck` (hidden by default via `?include_healthcheck=false`).
- **D9** `connected_now` derived from collector in-memory open-conn map, exposed via module accessor.

## Data model — `ldap_clients`
`id SERIAL PK` · `bind_dn VARCHAR(255) NOT NULL` (`""`=anon) · `source_ip VARCHAR(45) NOT NULL` · `service VARCHAR(20) NOT NULL DEFAULT 'unknown'` · `status VARCHAR(20) NOT NULL DEFAULT 'unknown'` · `label VARCHAR(255)` · `first_seen TIMESTAMPTZ NOT NULL DEFAULT now()` · `last_seen TIMESTAMPTZ NOT NULL DEFAULT now()` · `session_count BIGINT NOT NULL DEFAULT 0` · `last_bind_mech VARCHAR(30)` · `acknowledged_by VARCHAR(100)` · `acknowledged_at TIMESTAMPTZ` · `UNIQUE(bind_dn, source_ip)`.

---

### Task 1: `ldap_clients` schema
**domain:** database · **depends_on:** [] · **parallel_group:** 1 · **capabilities_needed:** [sqlalchemy-core, migrations]
**Files:** Modify `src/backend/orgdb.py` (add `Table` after `app_settings` ~:318); Create `migrations/028_ldap_clients.sql` (hand-mirror, `CREATE TABLE IF NOT EXISTS` + `CREATE UNIQUE INDEX IF NOT EXISTS`).
**Steps:** 1) Add `ldap_clients` Table to `metadata`. 2) Write `028` mirror (style of `021_blocked_ips.sql`). 3) `create_all()` idempotency — no call-site change.

### Task 2: `OrgDB` CRUD methods
**domain:** database · **depends_on:** [1] · **parallel_group:** 2 · **capabilities_needed:** [sqlalchemy-core, on-conflict-upsert]
**Files:** Modify `src/backend/orgdb.py` (new `# --- LDAP Client Inventory ---` section).
**Methods:**
- `upsert_ldap_session(bind_dn, source_ip, mech, service, seen_at)` → `pg_insert(...).on_conflict_do_update(index_elements=["bind_dn","source_ip"], set_={last_seen, session_count=ldap_clients.c.session_count+1, last_bind_mech, service=<keep manual status; refresh service only if still 'unknown'>})`. Preserve admin `status`/`label` on conflict.
- `list_ldap_clients(status=None, service=None, include_healthcheck=False)` → rows ordered `last_seen DESC`.
- `get_ldap_client(id)`, `update_ldap_client(id, status=None, label=None, acked_by=None)` (sets `acknowledged_at=now()` when status→acknowledged), `delete_ldap_client(id)` → bool.

### Task 3: Parser + classifier (pure, Docker-free) — **TDD FIRST**
**domain:** backend · **depends_on:** [] · **parallel_group:** 1 · **capabilities_needed:** [test-driven-development, regex]
**Files:** Create `src/backend/ldap_activity.py` (parser/classifier only in this task); Create `tests/unit/test_ldap_activity_parser.py`.
**Public fns:**
- `parse_line(line) -> LineEvent|None` — regex for `ACCEPT from IP=<ip>:<port>`, `BIND dn="<dn>" method=…`/`mech=<mech>`, `closed`; returns `(conn_id, kind, **fields)`.
- `SessionTracker` — feed events, correlate by `conn_id`; on ACCEPT seed `{ip}`, on BIND fill `{dn,mech}` (keep last non-empty dn for SASL two-step), on `closed` emit a completed `Session(ip,dn,mech)` + drop; expose `open_connections()` (currently-connected tuples).
- `classify(bind_dn, source_ip) -> service` — ordered rules; `localhost + cn=admin` → `healthcheck`; env CIDR map; else `unknown`.
**TDD steps (one assertion group at a time):** write failing test feeding sample lines (ACCEPT / SIMPLE BIND / SASL DIGEST-MD5 / anonymous `dn=""` / closed / interleaved conns / rotation-reset) → run → implement → pass. Mirror `tests/unit/test_ldap_errors_unit.py` structure.

### Task 4: Collector loop + lifespan wiring
**domain:** backend · **depends_on:** [2,3] · **parallel_group:** 3 · **capabilities_needed:** [asyncio, fastapi-lifespan]
**Files:** Modify `src/backend/ldap_activity.py` (add `run_ldap_activity_collector(engine)` async loop + `_open_conns` accessor); Modify `src/backend/main.py` `lifespan()` (create/cancel `asyncio.Task`).
**Steps:** 1) Tail loop: open file, seek to end (or tracked offset), read new lines, feed `SessionTracker`, upsert completed sessions via `ORGDB.upsert_ldap_session(...)`; `asyncio.sleep(1)` between polls; truncation-safe (offset reset if size < offset). 2) Wrap entire loop body in try/except → log warning + continue (file absent/perms). 3) Wire in `lifespan`: `create_task` on enter, `cancel()` + suppress `CancelledError` on exit. 4) Module-level accessor `get_connected_now()` returning open-conn `(dn,ip)` set for the API.

### Task 5: Config env vars
**domain:** backend · **depends_on:** [] · **parallel_group:** 1 · **capabilities_needed:** [pydantic-settings-os-getenv]
**Files:** Modify `src/backend/config.py`.
**Steps:** Add `LDAP_STATS_LOG_PATH=os.getenv(...,"/var/lib/ldap/slapd-stats.log")`, `LDAP_KNOWN_SERVICE_CIDRS=os.getenv(...,"")` (CSV `service:cidr`, parsed like `CORS_ORIGINS`). NO fail-fast guard (degrade gracefully).

### Task 6: API endpoints
**domain:** backend · **depends_on:** [2,4] · **parallel_group:** 4 · **capabilities_needed:** [fastapi, test-driven-development]
**Files:** Modify `src/backend/main.py` (near `/api/settings*` ~:3300); Create `tests/test_ldap_clients.py`.
**Endpoints (sync `def`, `require_permission("system_configuration")`):**
- `GET /api/settings/ldap/clients?status=&service=&include_healthcheck=` → `{"ok":True,"clients":[...],"counts":{...}}`; each client gets `connected_now` from `get_connected_now()`; wrap in try/except → empty list + `warning`, never 500.
- `PATCH /api/settings/ldap/clients/{id}` body `LdapClientPatch(status?, label?)` → update; 404 if missing; stamp `acknowledged_by`; `record_admin_action`.
- `DELETE /api/settings/ldap/clients/{id}` → 404 if missing else `{"ok":True}`.
**TDD:** integration `tests/test_ldap_clients.py` mirroring `tests/test_settings.py` — list, patch→status flip + acked_by populated, delete 404.

### Task 7: DevOps wiring
**domain:** devops · **depends_on:** [] · **parallel_group:** 1 · **capabilities_needed:** [docker-compose, openldap-config]
**Files:** Create `deploy/dev/ldap/logfile-config.ldif`; Modify `deploy/dev/docker-compose.yml` (openldap: mount ldif into bootstrap dir; directory-api: add `azblink_ldap_data:/var/lib/ldap:ro` + optional `LDAP_STATS_LOG_PATH` env).
**Steps:** 1) ldif = `cn=config` modify `replace: olcLogFile` → `/var/lib/ldap/slapd-stats.log`. 2) Compose mounts. 3) Note prod-parity Ansible follow-up (out of v1 scope, flagged).

### Task 8: Frontend types + query hook
**domain:** frontend · **depends_on:** [6] · **parallel_group:** 5 · **capabilities_needed:** [tanstack-query]
**Files:** Create `src/frontend/src/types/ldap-clients.ts`; Create `src/frontend/src/lib/queries/ldap-clients.ts`; Modify `src/frontend/src/lib/queries/keys.ts` (add `ldapClients` key).
**Steps:** Types (`LdapClient`, `LdapClientStatus`, `LdapClientService`, `LdapClientsResponse`, camelCase). `useLdapClients(filters)` (`useQuery`, `refetchInterval:12_000`), `useUpdateLdapClient()` + `useDeleteLdapClient()` (`useMutation` + invalidate). Mirror `settings.ts` + `group-mutations.ts`.

### Task 9: Frontend section component
**domain:** frontend · **depends_on:** [8] · **parallel_group:** 6 · **capabilities_needed:** [react, azblink-ui, interface-design]
**Files:** Create `src/frontend/src/components/features/settings/LdapClientsSection.tsx`; Modify `SettingsNav.tsx` (`SECTION_IDS`+`NAV_ITEMS`, icon e.g. `Network`); Modify `SettingsManagementPage.tsx` (render `<LdapClientsSection/>`).
**Steps:** Table (Service badge · Label/Bind DN · Source IP · Last seen · Sessions · Status badge · `●` connected dot · Acknowledge button). Badge map (unknown→warning, acknowledged→success, blocked→error, healthcheck→muted) mirroring `StatusBadge.tsx`. Acknowledge → `useUpdateLdapClient().mutate({id,status:'acknowledged'})`, `isPending` loading. Empty/loading states (`Skeleton`).

### Task 10: Integration verification
**domain:** test · **depends_on:** [1-9] · **parallel_group:** 7 · **capabilities_needed:** [verification-before-completion]
**Steps:** `just up-bg && just health`; rebuild API for new mount (`just down && just up-bg` — compose change). Generate binds (`ldapwhoami` as `cn=admin`, a `uid` user, anonymous) → `GET /api/settings/ldap/clients` shows rows + classification + `connected_now`. PATCH ack → status flip. Run `just test-quick` (or targeted `tests/test_ldap_clients.py` + `tests/unit/test_ldap_activity_parser.py`). `just ui-lint && just ui-format` for frontend.

## Parallel groups
- G1 (independent): T1, T3, T5, T7
- G2: T2 (after T1)
- G3: T4 (after T2,T3)
- G4: T6 (after T2,T4)
- G5: T8 (after T6) · G6: T9 (after T8) · G7: T10 (after all)

## Out of v1 scope (flagged, not built)
- Log rotation/truncation strategy (logrotate/collector-driven).
- `cn=Monitor` live view.
- Ansible prod-parity `olcLogFile` + volume mount.
