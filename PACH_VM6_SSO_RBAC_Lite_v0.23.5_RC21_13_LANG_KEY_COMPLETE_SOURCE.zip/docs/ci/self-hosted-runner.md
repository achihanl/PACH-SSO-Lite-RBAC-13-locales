---
title: Self-hosted CI runner
description: How every workflow runs on one self-hosted runner, how to install or move it, and how it shares a box with a dev stack
type: runbook
product: azb-azblink-directory-and-identity-stack
status: current
updated: 2026-10-20
---

# Self-hosted CI runner

Every workflow job runs on one self-hosted runner with the label `azb-ad-ci`
(`runs-on: [self-hosted, azb-ad-ci]`). GitHub-hosted jobs stopped on 2026-10-20:
the account's payments failed, and GitHub refuses hosted jobs until they clear.

The runner is installed per user, with no sudo and no system service. It is
supervised by `systemd --user` and runs one job at a time. Nothing is tied to the
host's name, so moving it to another machine means running the setup script
there and removing the old one.

## What the box needs

Install these once, by hand. Jobs install everything else themselves.

| Need | Why |
|---|---|
| Linux x64, systemd ≥ 245, Ubuntu 22.04/24.04 preferred | `setup-python` downloads prebuilt CPython for those releases |
| Docker Engine, with the user in the `docker` group | compose stacks and image builds |
| Docker Compose v2 ≥ 2.24.4 | the CI overlay uses `!reset` / `!override` |
| `git`, `curl`, `tar`, `jq` | checkout, health checks, install |
| Chromium's system libraries | `qa.yml`'s Playwright run. Run `sudo npx playwright install-deps chromium` once; jobs cannot, because they have no sudo |
| `qemu-system-x86_64`, `qemu-img`, `xorriso`, `openssl`, the user in the `kvm` group | `fresh-host.yml` boots a throwaway VM (`deploy/ansible/fresh-host/run.py`); its 600 MB cloud image is cached in `~/.cache/azb/cloud-img` |
| ~30 GB free disk under `$HOME` and Docker's data root | npm and pip caches, tool cache, images, build cache |
| `gh`, authenticated as a repo admin | only to fetch the registration token |

Node, Python and `just` come from `setup-node`, `setup-python` and `setup-just`.
They cache under `~/actions-runner/azb-ad/_work/_tool`.

No workflow uses GitHub's cache service (`setup-node`'s and `setup-python`'s
`cache:`, `actions/cache`, `type=gha`): it does not work on this account. npm
keeps its download cache in `~/.npm` and pip in `~/.cache/pip`, and both persist
between jobs. Each Python job installs into a venv under `$RUNNER_TEMP`, because
the tool-cache interpreter persists between jobs and a hosted VM's did not.
Artifact uploads have a 3-minute limit and never fail the job.

## Install

From a checkout of this repo, on the box that will run the jobs:

```bash
tools/ci-runner/setup.sh
```

It checks the prerequisites above, downloads the runner release named in the
script into `~/actions-runner/azb-ad` and checks its SHA-256, writes the user unit
`~/.config/systemd/user/actions-runner-azb-ad.service`, turns on linger so the
runner starts at boot without a login, registers the runner as `azb-ad-ci-1`
with the label `azb-ad-ci`, and starts it. The runner also gets `self-hosted`,
`Linux` and `X64` by default. Re-running it skips whatever is already done.

The registration token is valid for one hour. The script fetches it inline and
never prints it:

```bash
--token "$(gh api -X POST repos/KeithMoc/azb-azblink-directory-and-identity-stack/actions/runners/registration-token --jq .token)"
```

Check that the runner is online:

```bash
gh api repos/KeithMoc/azb-azblink-directory-and-identity-stack/actions/runners --jq '.runners[]|[.name,.status]'
```

The unit caps the runner and every job step at `MemoryHigh=5G` / `MemoryMax=6G`,
below SafeNest's runner (8G), because both runners and two dev stacks share this
box, which ran out of memory on 2026-10-08. `KillMode=mixed` with
`TimeoutStopSec=5min` lets a running job finish on stop, then kills whatever it
left behind. `MemoryMax` only takes effect if the user manager has the memory
controller; the script warns when it does not.

## Stop, restart, remove

```bash
systemctl --user stop actions-runner-azb-ad             # waits up to 5 min for a running job
systemctl --user disable --now actions-runner-azb-ad    # stop and don't start at boot
journalctl --user -u actions-runner-azb-ad -f           # follow its log
```

To move the runner to another machine, install it there first with
`RUNNER_NAME=azb-ad-ci-2 tools/ci-runner/setup.sh`, then remove it from the old
one:

```bash
systemctl --user disable --now actions-runner-azb-ad
cd ~/actions-runner/azb-ad && ./config.sh remove \
  --token "$(gh api -X POST repos/KeithMoc/azb-azblink-directory-and-identity-stack/actions/runners/remove-token --jq .token)"
rm ~/.config/systemd/user/actions-runner-azb-ad.service
```

While no `azb-ad-ci` runner is online, jobs queue. They wait up to 24 hours, then
fail.

## Sharing the box with a dev stack

The runner may sit next to a running dev stack (and SafeNest's runner and dev
stack). The workflows are written so that the dev stack never notices CI:

- **Compose project.** The compose files live in `deploy/dev`, so without a name
  the project is `dev`, which is the dev stack's project. Every compose call in
  CI therefore goes through `$STACK`, which adds `.github/ci/compose.ci.yml` as
  the last `-f`. That overlay sets the project to `azblink-ci`, drops the fixed
  `azblink-*` container names, and keeps CI off the shared `cloudflare-tunnel`
  network. Without it, a job's `down -v` would delete the dev stack's volumes.
  Never call compose in a workflow without the overlay.
- **Ports.** CI publishes on 2xxxx: API and UI through Traefik on 28081,
  Authentik 29000, Postgres 25433, Redis 26380, LDAP 21390, Grafana 23002. The
  dev stack keeps 8081/9000/5433/6380/1390/3002, SafeNest's dev stack and CI use
  their own ports and 1xxxx. The test steps set `API_URL`, `POSTGRES_PORT`,
  `REDIS_PORT`, `LDAP_PORT`, `LDAP_URI`, `AUTHENTIK_API_URL`, `GRAFANA_URL` and
  the journey client's `UC_*` URLs to the CI ports. They are set per step, not
  per job, because compose interpolates `LDAP_URI` and `AUTHENTIK_API_URL` too.
- **Traefik.** Each stack's Traefik reads the labels of every container on the
  daemon. CI's Traefik has a Docker provider constraint on the
  `com.docker.compose.project=azblink-ci` label, so it ignores dev containers.
  The dev Traefik cannot be constrained from the overlay, so CI's routers bind
  an entrypoint named `ci`, which the dev Traefik does not have: it lists them
  as disabled and never routes to them.
- **Fixed ports in tests.** Tests that open their own listener ask the OS for a
  free port. A fixed one collides with whatever else runs on the box.
- **OIDC.** Authentik stamps `iss` from the host the token endpoint was reached
  on, so CI's API accepts the `localhost:29000` issuers. CI's UI and redirect
  URIs point at CI's own Authentik and Traefik, not the dev tunnel.
- **Logs.** Alloy keeps the logs of every container named `azblink-*`. CI's
  containers are `azblink-ci-*` so that CI's Loki has CI's own logs; the dev
  stack's Loki also collects them while a CI stack is up.
- **Live tests.** Tests marked `external_network` need the 192.168.122.x lab and
  are deselected in CI, as they were on hosted runners. The UC journey client's
  Tier-1 smoke still runs, against the CI stack.
- **Docker objects.** Every job that starts the stack runs
  `down -v --rmi local --remove-orphans` before `up` and again at the end, even
  on failure. `--rmi local` removes the images compose built: left behind, the
  next run's `up` would reuse them instead of building that commit. Docker's
  default build cache persists between runs; reclaim it with
  `docker builder prune`.

## Memory

- The unit: `MemoryHigh=5G`, `MemoryMax=6G` for the runner and every step.
- CI compose containers: `mem_limit` in the overlay. Authentik's server gets
  1.5 GB, its worker, the API and the Vite UI 1 GB, everything else 256 to 512 MB.
  The whole CI stack used about 3 GB in a trial run.
