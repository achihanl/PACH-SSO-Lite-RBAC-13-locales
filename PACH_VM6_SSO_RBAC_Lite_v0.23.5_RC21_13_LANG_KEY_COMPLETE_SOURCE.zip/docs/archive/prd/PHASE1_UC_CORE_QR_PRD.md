# Phase 1: UC Core QR Provisioning (QR#1)

## Product Requirements Document

**Version:** 1.0
**Status:** Ready for Implementation
**Target:** Production-Ready UC-Only Deployment
**Prerequisite:** None (Day 0 deployable)

---

## 1. Executive Summary

### 1.1 Purpose

Phase 1 delivers a **production-ready UC Core QR provisioning system** that enables:
- Mobile/desktop clients to configure XMPP and SIP endpoints via a single QR scan
- Cryptographically signed QR payloads (HMAC-SHA256)
- One-time token enforcement to prevent credential sharing
- Full audit trail for compliance
- Rate limiting for abuse prevention

### 1.2 Key Outcome

> **User scans one QR code → UC (XMPP/SIP) is fully configured and operational**

No Authentik, no SSO, no external dependencies beyond LDAP.

### 1.3 Critical Design Invariant

```
UC MUST work even when:
- Authentik is not installed
- SSO is never configured
- Phase 2 is never deployed
```

### 1.4 Deployment Scenario

| Component | Required | Status |
|-----------|----------|--------|
| OpenLDAP | ✓ | Exists |
| PostgreSQL | ✓ | Exists |
| Redis | ✓ | Exists |
| Directory Portal Backend | ✓ | Exists (needs updates) |
| Authentik | ✗ | Not required |
| UC Server | ✓ | External dependency |

---

## 2. Existing Implementation Analysis

### 2.1 What Already Works

| Feature | File | Status | Notes |
|---------|------|--------|-------|
| User CRUD | `main.py:544-633` | ✅ Complete | Create, read, update, move_org |
| Group CRUD | `main.py:485-542` | ✅ Complete | Create, delete, members |
| Org tree CRUD | `main.py:439-482` | ✅ Complete | Create, rename, delete |
| QR generation (legacy) | `main.py:889-943` | ⚠️ Needs update | Uses old schema |
| HMAC signing | `main.py:89-92` | ✅ Complete | `hmac_sig()` function |
| Rate limiting | `rate_limit.py` | ✅ Complete | Redis-backed slowapi |
| Audit tables | `orgdb.py:117-157` | ✅ Complete | qr_issuance_audit, etc. |
| Token validation | `orgdb.py:342-384` | ✅ Complete | Atomic check-and-update |
| Termination flow | `main.py:636-720` | ⚠️ Partial | LDAP + tokens, no UC client |
| Break-glass | `main.py:126-186` | ✅ Complete | File-based bypass |

### 2.2 What Needs to Change

| Change | Priority | Effort | Impact |
|--------|----------|--------|--------|
| Update QR schema to `azblink.provisioning.v2` | P0 | 2 days | High |
| Add unified QR endpoint with UC block | P0 | 1 day | High |
| Add one-time credential token to UC block | P0 | 1 day | High |
| Add `POST /api/provision/consume` endpoint | P0 | 1 day | High |
| Add UC Server client stub (placeholder) | P1 | 0.5 day | Medium |
| Add account soft-lock on auth failures | P1 | 1 day | Medium |
| Update CLI with QR commands | P2 | 1 day | Low |

---

## 3. Technical Specification

### 3.1 QR Payload Schema (v2)

**Schema:** `azblink.provisioning.v2`

**UC-Only Payload (Phase 1):**
```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": {
      "tenant": "example",
      "xmpp": {
        "domain": "uc.example.com",
        "wsUrl": "wss://uc.example.com/xmpp-websocket"
      },
      "sip": {
        "domain": "sip.example.com",
        "wssUrl": "wss://sip.example.com/ws"
      },
      "credentials": {
        "username": "alice",
        "token": "one-time-provisioning-token-abc123"
      }
    },
    "sso": null
  },
  "iat": 1704067200,
  "exp": 1704070800,
  "nonce": "unique-nonce-xyz789",
  "sig": "hmac-sha256-signature"
}
```

**Key Fields:**

| Field | Type | Description |
|-------|------|-------------|
| `schema` | string | Always `"azblink.provisioning.v2"` |
| `payload.uc` | object | UC configuration (always present) |
| `payload.uc.tenant` | string | Tenant identifier |
| `payload.uc.xmpp.domain` | string | XMPP server domain |
| `payload.uc.xmpp.wsUrl` | string | XMPP WebSocket URL |
| `payload.uc.sip.domain` | string | SIP server domain |
| `payload.uc.sip.wssUrl` | string | SIP WebSocket URL |
| `payload.uc.credentials.username` | string | LDAP uid |
| `payload.uc.credentials.token` | string | One-time provisioning token |
| `payload.sso` | null | Always `null` in Phase 1 |
| `iat` | integer | Issued-at timestamp (Unix epoch) |
| `exp` | integer | Expiration timestamp (Unix epoch) |
| `nonce` | string | Unique per-issuance value |
| `sig` | string | HMAC-SHA256 signature |

### 3.2 Signing Algorithm

```python
import hmac
import hashlib
import json
import time
import secrets

def sign_provisioning_payload(
    payload: dict,
    secret: str,
    ttl_sec: int = 3600
) -> dict:
    """
    Sign a provisioning payload with HMAC-SHA256.

    Args:
        payload: The UC/SSO payload dict
        secret: ORG_QR_SIGNING_SECRET (min 32 bytes)
        ttl_sec: Time-to-live in seconds (default 1 hour)

    Returns:
        Complete signed wrapper with schema, iat, exp, nonce, sig
    """
    now = int(time.time())

    wrapper = {
        "schema": "azblink.provisioning.v2",
        "payload": payload,
        "iat": now,
        "exp": now + ttl_sec,
        "nonce": secrets.token_urlsafe(16)
    }

    # Canonical JSON: sorted keys, no whitespace
    message = json.dumps(wrapper, sort_keys=True, separators=(',', ':'))

    # HMAC-SHA256
    sig = hmac.new(
        secret.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

    wrapper["sig"] = sig
    return wrapper
```

### 3.3 One-Time Token Flow

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ Admin       │     │ Directory   │     │ Mobile App  │     │ UC Server   │
│ Portal      │     │ Backend     │     │             │     │             │
└──────┬──────┘     └──────┬──────┘     └──────┬──────┘     └──────┬──────┘
       │                   │                   │                   │
       │ GET /users/{uid}/qrcode              │                   │
       │──────────────────▶│                   │                   │
       │                   │                   │                   │
       │                   │ Generate one-time token              │
       │                   │ Store hash in provision_tokens       │
       │                   │ Sign payload with HMAC-SHA256        │
       │                   │                   │                   │
       │◀──────────────────│ Return signed QR  │                   │
       │                   │                   │                   │
       │ Display QR        │                   │                   │
       │═══════════════════│═══════════════════│                   │
       │                   │                   │                   │
       │                   │   Scan QR         │                   │
       │                   │◀──────────────────│                   │
       │                   │                   │                   │
       │                   │ POST /provision/consume              │
       │                   │◀──────────────────│                   │
       │                   │                   │                   │
       │                   │ Verify signature  │                   │
       │                   │ Check token_hash exists              │
       │                   │ Check not consumed │                   │
       │                   │ Check not expired  │                   │
       │                   │ Mark consumed (atomic)               │
       │                   │                   │                   │
       │                   │──────────────────▶│ Return session   │
       │                   │                   │ credentials      │
       │                   │                   │                   │
       │                   │                   │ Connect to UC    │
       │                   │                   │─────────────────▶│
       │                   │                   │                   │
       │                   │                   │◀─────────────────│
       │                   │                   │ UC Session Active│
       │                   │                   │                   │
```

### 3.4 API Endpoints

#### 3.4.1 Generate Unified QR Code

```http
GET /api/users/{uid}/qrcode
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "ok": true,
  "uid": "alice",
  "orgDn": "ou=Engineering,ou=org,dc=example,dc=com",
  "qrType": "unified",
  "payload": {
    "schema": "azblink.provisioning.v2",
    "payload": {
      "uc": { ... },
      "sso": null
    },
    "iat": 1704067200,
    "exp": 1704070800,
    "nonce": "...",
    "sig": "..."
  },
  "pngBase64": "iVBORw0KGgo..."
}
```

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `ttlSec` | integer | 3600 | Token TTL in seconds (max 86400) |
| `mode` | string | `unified` | `unified` or `split` (backward compat) |

#### 3.4.2 Consume Provisioning Token

```http
POST /api/provision/consume
Content-Type: application/json

{
  "token": "one-time-provisioning-token-abc123",
  "deviceId": "device-uuid-optional",
  "clientInfo": {
    "platform": "ios",
    "version": "2.1.0"
  }
}
```

**Response (200 OK):**
```json
{
  "ok": true,
  "uid": "alice",
  "consumed_at": "2024-01-01T12:00:00Z",
  "session": {
    "xmpp": {
      "jid": "alice@uc.example.com",
      "password": "session-password-for-xmpp"
    },
    "sip": {
      "uri": "sip:alice@sip.example.com",
      "password": "session-password-for-sip"
    }
  }
}
```

**Error Responses:**

| Status | Error | Description |
|--------|-------|-------------|
| 400 | `INVALID_SIGNATURE` | Signature verification failed |
| 404 | `TOKEN_NOT_FOUND` | Token doesn't exist in database |
| 409 | `TOKEN_ALREADY_CONSUMED` | Token was already used |
| 410 | `TOKEN_EXPIRED` | Token has passed its `exp` time |

#### 3.4.3 Revoke User's Tokens

```http
POST /api/users/{uid}/qrcode/revoke
Authorization: Bearer <admin-token>
```

**Response (200 OK):**
```json
{
  "ok": true,
  "user_uid": "alice",
  "tokens_revoked": 3
}
```

### 3.5 Database Schema Updates

#### 3.5.1 New: `provisioning_tokens` Table Enhancement

```sql
-- Add columns to existing provision_tokens table
ALTER TABLE provision_tokens ADD COLUMN IF NOT EXISTS
    consumed_by_device_id VARCHAR(128);

ALTER TABLE provision_tokens ADD COLUMN IF NOT EXISTS
    consumed_from_ip VARCHAR(45);

ALTER TABLE provision_tokens ADD COLUMN IF NOT EXISTS
    client_platform VARCHAR(32);

ALTER TABLE provision_tokens ADD COLUMN IF NOT EXISTS
    client_version VARCHAR(32);

-- Add index for user token lookup
CREATE INDEX IF NOT EXISTS idx_provision_tokens_uid
    ON provision_tokens(uid, status);
```

#### 3.5.2 Audit Table: `qr_issuance_audit` (Exists)

Already implemented with required fields:
- `user_uid`, `org_dn`, `issued_by`, `issued_at`
- `token_hash`, `expires_at`, `consumed`, `consumed_at`
- `consumed_reason`, `client_ip`, `user_agent`

### 3.6 Configuration

#### 3.6.1 Required Environment Variables

```bash
# LDAP (existing)
LDAP_URI=ldap://openldap:389
LDAP_BASE_DN=dc=example,dc=com
LDAP_TENANT=example
LDAP_BIND_DN=cn=admin,dc=example,dc=com
LDAP_BIND_PW=adminpassword

# PostgreSQL (existing)
DATABASE_URL=postgresql+psycopg2://user:pass@localhost:5432/azblink_directory

# Redis (existing)
REDIS_URL=redis://localhost:6379/0

# QR Signing (CRITICAL - generate with: openssl rand -base64 32)
ORG_QR_SIGNING_SECRET=your-32-byte-minimum-secret-here
ORG_QR_DEFAULT_TTL_SEC=3600
ORG_QR_MAX_TTL_SEC=86400

# UC Configuration
UCCHAT_XMPP_DOMAIN=uc.example.com
UCCHAT_XMPP_WS_URL=wss://uc.example.com/xmpp-websocket
UCCHAT_SIP_DOMAIN=sip.example.com
UCCHAT_SIP_WSS_URL=wss://sip.example.com/ws

# Auth Mode (UC-only = false)
REQUIRE_OIDC_AUTH=false
ALLOW_BOOTSTRAP_WITHOUT_OIDC=true
```

### 3.7 Rate Limiting

| Endpoint | Limit | Window | Existing |
|----------|-------|--------|----------|
| `GET /api/users/{uid}/qrcode` | 10 | 1 min | ✅ Yes |
| `POST /api/provision/consume` | 10 | 1 min | ❌ New |
| `POST /api/users/create` | 20 | 1 min | ✅ Yes |
| `POST /api/bootstrap` | 5 | 1 hour | ✅ Yes |

---

## 4. Implementation Tasks

### 4.1 Backend Changes

#### Task 1: Create QR Signing Module (P0)

**File:** `src/backend/qr_signing.py` (new)

```python
"""
QR Payload Signing Module

Provides HMAC-SHA256 signing and verification for provisioning payloads.
"""

import hmac
import hashlib
import json
import time
import secrets
from typing import Tuple, Optional, Dict, Any

from config import ORG_QR_SIGNING_SECRET, ORG_QR_DEFAULT_TTL_SEC, ORG_QR_MAX_TTL_SEC


def sign_provisioning_payload(
    uc_payload: Dict[str, Any],
    sso_payload: Optional[Dict[str, Any]] = None,
    ttl_sec: Optional[int] = None
) -> Dict[str, Any]:
    """Sign a unified provisioning payload."""
    ttl = min(ttl_sec or ORG_QR_DEFAULT_TTL_SEC, ORG_QR_MAX_TTL_SEC)
    now = int(time.time())

    wrapper = {
        "schema": "azblink.provisioning.v2",
        "payload": {
            "uc": uc_payload,
            "sso": sso_payload  # None in Phase 1
        },
        "iat": now,
        "exp": now + ttl,
        "nonce": secrets.token_urlsafe(16)
    }

    message = json.dumps(wrapper, sort_keys=True, separators=(',', ':'))
    sig = hmac.new(
        ORG_QR_SIGNING_SECRET.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

    wrapper["sig"] = sig
    return wrapper


def verify_provisioning_payload(
    signed_payload: Dict[str, Any]
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Verify a signed provisioning payload.

    Returns: (valid, error_message, payload)
    """
    payload_copy = dict(signed_payload)
    sig = payload_copy.pop("sig", None)

    if not sig:
        return False, "MISSING_SIGNATURE", {}

    message = json.dumps(payload_copy, sort_keys=True, separators=(',', ':'))
    expected = hmac.new(
        ORG_QR_SIGNING_SECRET.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(sig, expected):
        return False, "INVALID_SIGNATURE", {}

    now = int(time.time())
    if payload_copy.get("exp", 0) < now:
        return False, "TOKEN_EXPIRED", {}

    return True, "", payload_copy.get("payload", {})
```

#### Task 2: Update QR Endpoint (P0)

**File:** `src/backend/main.py`

Update `GET /api/users/{uid}/qrcode` to use new schema:

```python
@app.get("/api/users/{uid}/qrcode")
@limiter.limit(LIMIT_QR)
def api_user_qrcode(
    request: Request,
    uid: str,
    ttlSec: Optional[int] = None,
    mode: str = "unified",
    claims: Dict[str, Any] = Depends(require_user)
):
    """
    Generate unified QR code for user provisioning.

    - mode=unified: Single QR with UC config (Phase 1) + SSO (Phase 2)
    - mode=split: Legacy separate QR#1/QR#2 (backward compat)
    """
    user = get_user(uid)
    if not user:
        raise HTTPException(404, "User not found")

    # Generate one-time provisioning token
    provision_token = secrets.token_urlsafe(24)
    token_hash = hashlib.sha256(provision_token.encode()).hexdigest()

    # Store token for validation
    ttl = min(ttlSec or ORG_QR_DEFAULT_TTL_SEC, ORG_QR_MAX_TTL_SEC)
    exp_dt = utcnow() + timedelta(seconds=ttl)

    ORGDB.record_provision_token(
        token_hash=token_hash,
        uid=uid,
        profile_id="uc_core",  # Phase 1 always UC core
        expires_at=exp_dt
    )

    # Build UC payload
    uc_payload = {
        "tenant": LDAP_TENANT,
        "xmpp": {
            "domain": UCCHAT_XMPP_DOMAIN,
            "wsUrl": UCCHAT_XMPP_WS_URL
        },
        "sip": {
            "domain": UCCHAT_SIP_DOMAIN,
            "wssUrl": UCCHAT_SIP_WSS_URL
        },
        "credentials": {
            "username": uid,
            "token": provision_token
        }
    }

    # Sign payload (sso=None in Phase 1)
    signed_payload = sign_provisioning_payload(
        uc_payload=uc_payload,
        sso_payload=None,
        ttl_sec=ttl
    )

    # Record audit
    ORGDB.record_qr_issuance(
        user_uid=uid,
        org_dn=user.get("orgDn", ""),
        issued_by=claims.get("sub", "unknown"),
        token_hash=token_hash,
        expires_at=exp_dt,
        client_ip=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent")
    )

    # Generate QR image
    payload_json = json.dumps(signed_payload, separators=(',', ':'))
    qr_png = make_qr_png_base64(payload_json)

    return {
        "ok": True,
        "uid": uid,
        "orgDn": user.get("orgDn", ""),
        "qrType": mode,
        "payload": signed_payload,
        "pngBase64": qr_png
    }
```

#### Task 3: Add Token Consumption Endpoint (P0)

**File:** `src/backend/main.py`

```python
class ProvisionConsumeReq(BaseModel):
    token: str = Field(..., min_length=1, max_length=256)
    deviceId: Optional[str] = Field(default=None, max_length=128)
    clientInfo: Optional[Dict[str, str]] = None


@app.post("/api/provision/consume")
@limiter.limit(LIMIT_QR)
def api_provision_consume(
    request: Request,
    req: ProvisionConsumeReq
):
    """
    Consume a one-time provisioning token.

    Called by mobile clients after scanning QR code.
    Returns session credentials for UC services.
    """
    # Hash the token
    token_hash = hashlib.sha256(req.token.encode()).hexdigest()

    # Atomic validate-and-consume
    valid, error, token_data = ORGDB.validate_and_consume_token(token_hash)

    if not valid:
        status_code = {
            "TOKEN_NOT_FOUND": 404,
            "TOKEN_EXPIRED": 410,
            "TOKEN_ALREADY_CONSUMED": 409
        }.get(error, 400)
        raise HTTPException(status_code, {"ok": False, "error": error})

    uid = token_data.get("uid")

    # Update token with device info (best-effort)
    try:
        ORGDB.update_provision_token_device(
            token_hash=token_hash,
            device_id=req.deviceId,
            client_ip=request.client.host if request.client else None,
            platform=req.clientInfo.get("platform") if req.clientInfo else None,
            version=req.clientInfo.get("version") if req.clientInfo else None
        )
    except Exception:
        pass

    # Return session credentials
    # NOTE: In production, this would generate actual session credentials
    # via UC Server API. For Phase 1, we return LDAP-bindable credentials.
    return {
        "ok": True,
        "uid": uid,
        "consumed_at": iso(utcnow()),
        "session": {
            "xmpp": {
                "jid": f"{uid}@{UCCHAT_XMPP_DOMAIN}",
                "authMethod": "ldap_bind"
            },
            "sip": {
                "uri": f"sip:{uid}@{UCCHAT_SIP_DOMAIN}",
                "authMethod": "ldap_bind"
            }
        }
    }
```

#### Task 4: Add Device Info to Token Table (P1)

**File:** `src/backend/orgdb.py`

```python
def update_provision_token_device(
    self,
    token_hash: str,
    device_id: str | None = None,
    client_ip: str | None = None,
    platform: str | None = None,
    version: str | None = None
) -> None:
    """Update provision token with device consumption info."""
    eng = self.connect()
    with eng.begin() as conn:
        update_vals = {}
        if device_id:
            update_vals["consumed_by_device_id"] = device_id
        if client_ip:
            update_vals["consumed_from_ip"] = client_ip
        if platform:
            update_vals["client_platform"] = platform
        if version:
            update_vals["client_version"] = version

        if update_vals:
            conn.execute(
                update(provision_tokens)
                .where(provision_tokens.c.token_hash == token_hash)
                .values(**update_vals)
            )
```

### 4.2 Migration Script

**File:** `migrations/004_phase1_uc_qr.sql`

```sql
-- Migration 004: Phase 1 UC Core QR Support
-- Enhances provision_tokens table for device tracking

-- Add device tracking columns
ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS consumed_by_device_id VARCHAR(128);

ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS consumed_from_ip VARCHAR(45);

ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS client_platform VARCHAR(32);

ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS client_version VARCHAR(32);

-- Add index for user-based token lookup
CREATE INDEX IF NOT EXISTS idx_provision_tokens_uid_status
ON provision_tokens(uid, status);

-- Add index for cleanup of expired tokens
CREATE INDEX IF NOT EXISTS idx_provision_tokens_expires
ON provision_tokens(expires_at)
WHERE status = 'active';
```

---

## 5. Testing Requirements

### 5.1 Unit Tests

```python
# tests/test_qr_signing.py

def test_sign_and_verify_payload():
    """Signed payload should verify successfully."""
    uc_payload = {"xmpp": {"domain": "test.com"}}
    signed = sign_provisioning_payload(uc_payload)

    valid, error, payload = verify_provisioning_payload(signed)

    assert valid is True
    assert error == ""
    assert payload["uc"]["xmpp"]["domain"] == "test.com"
    assert payload["sso"] is None


def test_verify_rejects_tampered_payload():
    """Tampered payload should be rejected."""
    signed = sign_provisioning_payload({"test": "data"})
    signed["payload"]["test"] = "tampered"

    valid, error, _ = verify_provisioning_payload(signed)

    assert valid is False
    assert error == "INVALID_SIGNATURE"


def test_verify_rejects_expired_payload():
    """Expired payload should be rejected."""
    signed = sign_provisioning_payload({"test": "data"}, ttl_sec=-1)

    valid, error, _ = verify_provisioning_payload(signed)

    assert valid is False
    assert error == "TOKEN_EXPIRED"
```

### 5.2 Integration Tests

```python
# tests/test_provisioning.py

def test_qrcode_endpoint_returns_v2_schema(client, admin_token, test_user):
    """QR endpoint should return v2 schema with UC block."""
    response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers={"Authorization": f"Bearer {admin_token}"}
    )

    assert response.status_code == 200
    data = response.json()

    assert data["ok"] is True
    assert data["payload"]["schema"] == "azblink.provisioning.v2"
    assert data["payload"]["payload"]["uc"] is not None
    assert data["payload"]["payload"]["sso"] is None


def test_token_consumed_once_only(client, test_qr_token):
    """Token should only be consumable once."""
    # First consumption
    r1 = client.post("/api/provision/consume", json={"token": test_qr_token})
    assert r1.status_code == 200

    # Second consumption should fail
    r2 = client.post("/api/provision/consume", json={"token": test_qr_token})
    assert r2.status_code == 409
    assert r2.json()["error"] == "TOKEN_ALREADY_CONSUMED"


def test_expired_token_rejected(client, expired_qr_token):
    """Expired token should be rejected."""
    response = client.post("/api/provision/consume", json={"token": expired_qr_token})

    assert response.status_code == 410
    assert response.json()["error"] == "TOKEN_EXPIRED"
```

### 5.3 Security Tests

```python
# tests/test_security.py

def test_qr_endpoint_rate_limited(client, admin_token, test_user):
    """QR endpoint should be rate limited."""
    uid = test_user["uid"]

    # Make 12 requests (limit is 10/min)
    for i in range(12):
        response = client.get(
            f"/api/users/{uid}/qrcode",
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        if i >= 10:
            assert response.status_code == 429


def test_consume_endpoint_rate_limited(client):
    """Consume endpoint should be rate limited."""
    for i in range(12):
        response = client.post(
            "/api/provision/consume",
            json={"token": f"fake-token-{i}"}
        )
        if i >= 10:
            assert response.status_code == 429
```

---

## 6. Acceptance Criteria

### 6.1 Functional Requirements

| ID | Requirement | Test |
|----|-------------|------|
| F1 | QR code uses `azblink.provisioning.v2` schema | `test_qrcode_endpoint_returns_v2_schema` |
| F2 | QR payload includes UC block with XMPP/SIP config | `test_qrcode_endpoint_returns_v2_schema` |
| F3 | QR payload includes one-time provisioning token | Inspect payload |
| F4 | SSO block is `null` in Phase 1 | `test_qrcode_endpoint_returns_v2_schema` |
| F5 | Token can only be consumed once | `test_token_consumed_once_only` |
| F6 | Expired tokens are rejected | `test_expired_token_rejected` |
| F7 | Token consumption returns session credentials | Manual verification |
| F8 | All QR issuances are audit logged | Query `qr_issuance_audit` |

### 6.2 Security Requirements

| ID | Requirement | Test |
|----|-------------|------|
| S1 | Payload signed with HMAC-SHA256 | `test_sign_and_verify_payload` |
| S2 | Tampered payloads rejected | `test_verify_rejects_tampered_payload` |
| S3 | QR endpoint rate limited (10/min) | `test_qr_endpoint_rate_limited` |
| S4 | Consume endpoint rate limited (10/min) | `test_consume_endpoint_rate_limited` |
| S5 | Signing secret min 32 bytes | Config validation |

### 6.3 Performance Requirements

| ID | Requirement | Target |
|----|-------------|--------|
| P1 | QR generation latency | < 200ms p95 |
| P2 | Token consumption latency | < 100ms p95 |
| P3 | Concurrent QR generation | 50 req/s sustained |

---

## 7. Deployment Checklist

### 7.1 Pre-Deployment

- [ ] `ORG_QR_SIGNING_SECRET` generated (min 32 bytes)
- [ ] PostgreSQL migration applied
- [ ] Redis running and accessible
- [ ] `REQUIRE_OIDC_AUTH=false` for UC-only
- [ ] UC Server endpoints configured

### 7.2 Post-Deployment Verification

- [ ] `GET /api/health/deep` returns all healthy
- [ ] QR generation works: `GET /api/users/{uid}/qrcode`
- [ ] Token consumption works: `POST /api/provision/consume`
- [ ] Audit logs populated in `qr_issuance_audit`
- [ ] Rate limiting active (test with 11 requests)

### 7.3 Rollback Plan

1. Revert to previous backend image
2. No database rollback needed (columns are additive)
3. Old QR codes remain valid (signature compatible)

---

## 8. Timeline

| Week | Tasks | Deliverables |
|------|-------|--------------|
| 1 | Task 1-2: QR signing module, update endpoint | `qr_signing.py`, updated `/qrcode` |
| 1 | Task 3: Token consumption endpoint | `POST /api/provision/consume` |
| 2 | Task 4: Device tracking, migration | Enhanced `provision_tokens` |
| 2 | Testing: Unit, integration, security | Test suite passing |
| 2 | Documentation, deployment | Phase 1 complete |

**Total Estimated Effort:** 8-10 developer days

---

## 9. Dependencies & Risks

### 9.1 Dependencies

| Dependency | Owner | Status |
|------------|-------|--------|
| OpenLDAP | Ops | ✅ Running |
| PostgreSQL | Ops | ✅ Running |
| Redis | Ops | ✅ Running |
| UC Server (for session) | UC Team | ⚠️ May need API |

### 9.2 Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| UC Server lacks session API | Medium | High | Phase 1 uses LDAP-bind auth |
| Token replay attack | Low | High | One-time enforcement |
| Signing secret leak | Low | Critical | Secrets manager, rotation |

---

## 10. Future Considerations (Phase 2)

Phase 1 is designed to be extended in Phase 2:

- `payload.sso` will contain Authentik OIDC config
- Same signing/verification mechanism
- Same token consumption flow
- Backward compatible with Phase 1 clients
