# Phase 2: SSO Profile QR Provisioning (QR#2)

## Product Requirements Document

**Version:** 1.0
**Status:** Ready for Implementation
**Target:** Production-Ready UC + SSO Deployment
**Prerequisite:** Phase 1 Complete

---

## 1. Executive Summary

### 1.1 Purpose

Phase 2 extends the Phase 1 UC Core QR system to include **SSO configuration**, enabling:
- Single QR code provisioning for both UC and SSO (unified model)
- OIDC configuration delivery (issuer, clientId, scopes, PKCE)
- Authentik integration for session revocation during termination
- Complete user lifecycle management across both authentication planes

### 1.2 Key Outcome

> **User scans one QR code → UC (XMPP/SIP) + SSO (web apps) fully configured**

### 1.3 Critical Design Invariant

```
UC MUST continue to work even when:
- Authentik is down
- SSO configuration is invalid
- User has not completed SSO enrollment

SSO failure ≠ UC failure (Graceful degradation)
```

### 1.4 Deployment Scenario

| Component | Required | Phase 1 | Phase 2 |
|-----------|----------|---------|---------|
| OpenLDAP | ✓ | ✅ | ✅ |
| PostgreSQL | ✓ | ✅ | ✅ |
| Redis | ✓ | ✅ | ✅ |
| Directory Portal | ✓ | ✅ | ✅ (enhanced) |
| UC Server | ✓ | ✅ | ✅ (with API) |
| Authentik | ✓ | ✗ | ✅ Required |

---

## 2. Existing Implementation Analysis

### 2.1 Phase 1 Foundation (Complete)

| Feature | Status | Notes |
|---------|--------|-------|
| Unified QR schema `azblink.provisioning.v2` | ✅ | UC block, sso=null |
| HMAC-SHA256 signing | ✅ | `qr_signing.py` |
| One-time token enforcement | ✅ | Atomic consume |
| Rate limiting | ✅ | Redis-backed |
| Audit logging | ✅ | `qr_issuance_audit` |
| `POST /api/provision/consume` | ✅ | Token validation |
| User termination (partial) | ⚠️ | LDAP + tokens only |

### 2.2 Current SSO-Related Code (Exists but Incomplete)

| Feature | File | Status | Notes |
|---------|------|--------|-------|
| OrgProfile with ssoProfile | `main.py:337-353` | ✅ | Model exists |
| OrgProfile CRUD | `main.py:1076-1213` | ✅ | Complete |
| SSO profile endpoint | `main.py:1288-1410` | ⚠️ | Separate from QR |
| Split QR (QR#1 + QR#2) | `main.py:947-1056` | ⚠️ | Uses old schema |
| Authentik client | N/A | ❌ | Not implemented |
| UC Server client | N/A | ❌ | Not implemented |

### 2.3 What Needs to Change

| Change | Priority | Effort | Impact |
|--------|----------|--------|--------|
| Add SSO block to unified QR when enabled | P0 | 1 day | High |
| Implement `authentik_client.py` | P0 | 2 days | High |
| Implement `uc_client.py` | P0 | 2 days | High |
| Complete termination flow | P0 | 1 day | High |
| Add OrgProfile SSO validation | P1 | 0.5 day | Medium |
| Add Authentik health check | P1 | 0.5 day | Medium |
| Add account soft-lock mechanism | P1 | 1 day | Medium |
| Add CLI commands for SSO management | P2 | 1 day | Low |

---

## 3. Technical Specification

### 3.1 Unified QR Payload with SSO

**Schema:** `azblink.provisioning.v2` (same as Phase 1)

**UC + SSO Payload:**
```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": {
      "tenant": "example",
      "xmpp": {
        "domain": "uc.example.com",
        "wsUrl": "wss://uc.example.com/xmpp-websocket"
      },
      "sip": {
        "domain": "sip.example.com",
        "wssUrl": "wss://sip.example.com/ws"
      },
      "credentials": {
        "username": "alice",
        "token": "one-time-provisioning-token"
      }
    },
    "sso": {
      "issuer": "https://auth.example.com/application/o/mobile/",
      "clientId": "azblink-mobile",
      "scopes": ["openid", "profile", "email", "groups"],
      "pkceRequired": true,
      "tokenEndpoint": "https://auth.example.com/application/o/token/",
      "authorizationEndpoint": "https://auth.example.com/application/o/authorize/",
      "userInfoEndpoint": "https://auth.example.com/application/o/userinfo/"
    }
  },
  "iat": 1704067200,
  "exp": 1704070800,
  "nonce": "unique-nonce-xyz789",
  "sig": "hmac-sha256-signature"
}
```

**SSO Block Fields:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `issuer` | string | ✓ | OIDC issuer URL |
| `clientId` | string | ✓ | OIDC client ID for mobile app |
| `scopes` | array | ✓ | OIDC scopes to request |
| `pkceRequired` | boolean | ✓ | Whether PKCE is required |
| `tokenEndpoint` | string | ○ | Token endpoint (can be discovered) |
| `authorizationEndpoint` | string | ○ | Authorization endpoint |
| `userInfoEndpoint` | string | ○ | UserInfo endpoint |

### 3.2 SSO Availability Decision Logic

```
┌─────────────────────────────────────────────────────────────────────┐
│                GET /api/users/{uid}/qrcode                         │
└─────────────────────────────────────────────────────────────────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │  Fetch user from    │
                    │       LDAP          │
                    └─────────────────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │ Fetch OrgProfile    │
                    │ for user's orgDn    │
                    └─────────────────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │ Build UC block      │◀─── ALWAYS included
                    │ (Phase 1 logic)     │
                    └─────────────────────┘
                               │
                               ▼
              ┌────────────────────────────────┐
              │ OrgProfile has ssoProfile      │
              │ AND ssoProfile.enabled = true  │
              │ AND ssoProfile.oidc.issuer set?│
              └────────────────────────────────┘
                     │                    │
                    YES                   NO
                     │                    │
                     ▼                    ▼
          ┌──────────────────┐  ┌──────────────────┐
          │ Build SSO block  │  │  sso = null      │
          │ from OrgProfile  │  │ (UC-only mode)   │
          └──────────────────┘  └──────────────────┘
                     │                    │
                     └────────┬───────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Sign with HMAC-256  │
                    │ Return QR code      │
                    └─────────────────────┘
```

### 3.3 OrgProfile SSO Configuration

**Updated OrgProfile Model:**

```python
class SsoOidcConfig(BaseModel):
    issuer: str = Field(..., description="OIDC issuer URL")
    clientId: str = Field(..., description="OIDC client ID")
    scopes: List[str] = Field(default=["openid", "profile", "email"])
    pkceRequired: bool = Field(default=True)
    # Optional - can be discovered from issuer
    tokenEndpoint: Optional[str] = None
    authorizationEndpoint: Optional[str] = None
    userInfoEndpoint: Optional[str] = None


class SsoProfileConfig(BaseModel):
    enabled: bool = Field(default=False)
    oidc: Optional[SsoOidcConfig] = None
    # App-specific client IDs (if different per app)
    appClients: Optional[Dict[str, str]] = None
```

**OrgProfile API:**

```http
POST /api/orgprofiles
Content-Type: application/json
Authorization: Bearer <admin-token>

{
  "id": "engineering-sso",
  "tenant": "example",
  "orgDn": "ou=Engineering,ou=org,dc=example,dc=com",
  "orgName": "Engineering",
  "orgKey": "eng",
  "bindRegistration": "self",
  "apps": [
    {"id": "teampulse", "label": "TeamPulse", "webUrl": "https://teampulse.example.com"}
  ],
  "ssoProfile": {
    "enabled": true,
    "oidc": {
      "issuer": "https://auth.example.com/application/o/mobile/",
      "clientId": "azblink-mobile",
      "scopes": ["openid", "profile", "email", "groups"],
      "pkceRequired": true
    }
  }
}
```

### 3.4 Authentik Integration

#### 3.4.1 Authentik Client Module

**File:** `src/backend/authentik_client.py`

```python
"""
Authentik Admin API Client

Provides session management for user termination.
"""

import httpx
from typing import List, Optional
from config import AUTHENTIK_API_URL, AUTHENTIK_API_TOKEN


class AuthentikClient:
    """Client for Authentik Admin API."""

    def __init__(
        self,
        base_url: str = AUTHENTIK_API_URL,
        api_token: str = AUTHENTIK_API_TOKEN,
        timeout: float = 10.0
    ):
        self.base_url = base_url.rstrip('/')
        self.headers = {
            "Authorization": f"Bearer {api_token}",
            "Content-Type": "application/json"
        }
        self.timeout = timeout

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make authenticated request to Authentik API."""
        url = f"{self.base_url}{path}"
        kwargs.setdefault("headers", {}).update(self.headers)
        kwargs.setdefault("timeout", self.timeout)

        with httpx.Client() as client:
            response = client.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json() if response.content else {}

    def health_check(self) -> bool:
        """Check if Authentik is reachable."""
        try:
            # Use the /-/health/ready/ endpoint
            with httpx.Client() as client:
                response = client.get(
                    f"{self.base_url}/-/health/ready/",
                    timeout=5.0
                )
                return response.status_code == 200
        except Exception:
            return False

    def get_user_sessions(self, username: str) -> List[dict]:
        """Get all active sessions for a user."""
        try:
            result = self._request(
                "GET",
                f"/api/v3/core/authenticated_sessions/",
                params={"user__username": username}
            )
            return result.get("results", [])
        except Exception:
            return []

    def revoke_user_sessions(self, username: str) -> int:
        """Revoke all sessions for a user. Returns count revoked."""
        sessions = self.get_user_sessions(username)
        revoked = 0

        for session in sessions:
            try:
                session_uuid = session.get("uuid")
                if session_uuid:
                    self._request(
                        "DELETE",
                        f"/api/v3/core/authenticated_sessions/{session_uuid}/"
                    )
                    revoked += 1
            except Exception:
                continue

        return revoked

    def get_user_tokens(self, username: str) -> List[dict]:
        """Get all tokens for a user."""
        try:
            result = self._request(
                "GET",
                f"/api/v3/core/tokens/",
                params={"user__username": username}
            )
            return result.get("results", [])
        except Exception:
            return []

    def revoke_user_tokens(self, username: str) -> int:
        """Revoke all tokens for a user. Returns count revoked."""
        tokens = self.get_user_tokens(username)
        revoked = 0

        for token in tokens:
            try:
                token_id = token.get("identifier")
                if token_id:
                    self._request(
                        "DELETE",
                        f"/api/v3/core/tokens/{token_id}/"
                    )
                    revoked += 1
            except Exception:
                continue

        return revoked

    def revoke_all_user_access(self, username: str) -> dict:
        """
        Revoke all access for a user (sessions + tokens).
        Returns summary of actions taken.
        """
        sessions_revoked = self.revoke_user_sessions(username)
        tokens_revoked = self.revoke_user_tokens(username)

        return {
            "sessions_revoked": sessions_revoked,
            "tokens_revoked": tokens_revoked,
            "total_revoked": sessions_revoked + tokens_revoked
        }


# Singleton instance
_authentik_client: Optional[AuthentikClient] = None


def get_authentik_client() -> Optional[AuthentikClient]:
    """Get Authentik client (lazy initialization)."""
    global _authentik_client

    if not AUTHENTIK_API_URL or not AUTHENTIK_API_TOKEN:
        return None

    if _authentik_client is None:
        _authentik_client = AuthentikClient()

    return _authentik_client
```

#### 3.4.2 UC Server Client Module

**File:** `src/backend/uc_client.py`

```python
"""
UC Server Admin API Client

Provides session termination for user lifecycle management.
"""

import httpx
from typing import Optional, List
from config import UC_SERVER_API_URL, UC_SERVER_API_KEY


class UCServerClient:
    """Client for UC Server Admin API."""

    def __init__(
        self,
        base_url: str = UC_SERVER_API_URL,
        api_key: str = UC_SERVER_API_KEY,
        timeout: float = 10.0
    ):
        self.base_url = base_url.rstrip('/') if base_url else ""
        self.headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }
        self.timeout = timeout

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make authenticated request to UC Server API."""
        if not self.base_url:
            raise ValueError("UC_SERVER_API_URL not configured")

        url = f"{self.base_url}{path}"
        kwargs.setdefault("headers", {}).update(self.headers)
        kwargs.setdefault("timeout", self.timeout)

        with httpx.Client() as client:
            response = client.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json() if response.content else {}

    def health_check(self) -> bool:
        """Check if UC Server is reachable."""
        if not self.base_url:
            return False

        try:
            with httpx.Client() as client:
                response = client.get(
                    f"{self.base_url}/health",
                    headers=self.headers,
                    timeout=5.0
                )
                return response.status_code == 200
        except Exception:
            return False

    def get_user_sessions(self, username: str) -> List[dict]:
        """Get active sessions for a user."""
        try:
            result = self._request(
                "GET",
                f"/api/admin/sessions",
                params={"username": username}
            )
            return result.get("sessions", [])
        except Exception:
            return []

    def terminate_user_sessions(self, username: str) -> int:
        """
        Terminate all UC sessions for a user.
        Returns count of sessions terminated.
        """
        try:
            result = self._request(
                "POST",
                f"/api/admin/sessions/terminate",
                json={"username": username}
            )
            return result.get("terminated_count", 0)
        except Exception:
            return 0

    def send_termination_notice(self, username: str, message: str = None) -> bool:
        """
        Send termination notice to connected clients.
        Uses XMPP headline message.
        """
        try:
            self._request(
                "POST",
                f"/api/admin/notify",
                json={
                    "username": username,
                    "type": "session_terminated",
                    "message": message or "Your session has been terminated by administrator."
                }
            )
            return True
        except Exception:
            return False


# Singleton instance
_uc_client: Optional[UCServerClient] = None


def get_uc_client() -> Optional[UCServerClient]:
    """Get UC Server client (lazy initialization)."""
    global _uc_client

    if not UC_SERVER_API_URL:
        return None

    if _uc_client is None:
        _uc_client = UCServerClient()

    return _uc_client
```

### 3.5 Complete Termination Flow

**Updated Termination Endpoint:**

```python
@app.post("/api/users/{uid}/terminate")
@limiter.limit(LIMIT_USER_CREATE)
def api_user_terminate(
    request: Request,
    uid: str,
    req: UserTerminateReq,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """
    Terminate a user account (Spec §6.2).

    Actions performed atomically:
    1. Disable LDAP account (CRITICAL - abort if fails)
    2. Invalidate all provisioning tokens
    3. Revoke Authentik sessions (if configured)
    4. Terminate UC Server sessions (if configured)
    5. Log termination event

    Returns summary of all actions taken.
    """
    from authentik_client import get_authentik_client
    from uc_client import get_uc_client

    user = get_user(uid)
    if not user:
        raise HTTPException(404, "User not found")

    user_dn = user.get("dn")
    org_dn = user.get("orgDn")
    terminated_by = claims.get("sub", "unknown")
    actions = {}

    # 1. Disable LDAP account (CRITICAL)
    try:
        disable_user(uid)
        actions["ldap_disabled"] = True
        ldap_disabled = True
    except Exception as e:
        raise HTTPException(
            500,
            f"Critical: Failed to disable LDAP account: {e}. Termination aborted."
        )

    # 2. Invalidate provisioning tokens
    try:
        tokens_revoked = ORGDB.revoke_tokens_for_user(uid)
        qr_revoked = ORGDB.revoke_qr_issuance_for_user(uid)
        actions["tokens_revoked"] = tokens_revoked + qr_revoked
    except Exception as e:
        tokens_revoked = 0
        actions["tokens_revoked_error"] = str(e)

    # 3. Revoke Authentik sessions (Phase 2)
    authentik_client = get_authentik_client()
    authentik_result = None
    if authentik_client and authentik_client.health_check():
        try:
            authentik_result = authentik_client.revoke_all_user_access(uid)
            actions["authentik"] = authentik_result
        except Exception as e:
            actions["authentik_error"] = str(e)
    else:
        actions["authentik"] = "not_configured_or_unavailable"

    # 4. Terminate UC Server sessions (Phase 2)
    uc_client = get_uc_client()
    uc_terminated = None
    if uc_client and uc_client.health_check():
        try:
            # Send notice first (best effort)
            uc_client.send_termination_notice(
                uid,
                f"Your account has been terminated. Reason: {req.reason}"
            )
            # Then terminate sessions
            uc_terminated = uc_client.terminate_user_sessions(uid)
            actions["uc_sessions"] = uc_terminated
        except Exception as e:
            actions["uc_sessions_error"] = str(e)
    else:
        actions["uc_sessions"] = "not_configured_or_unavailable"

    # 5. Log termination event
    event_id = ORGDB.record_termination(
        user_uid=uid,
        user_dn=user_dn,
        org_dn=org_dn,
        terminated_by=terminated_by,
        reason=req.reason,
        actions_taken=actions,
        ldap_disabled=ldap_disabled,
        tokens_revoked=tokens_revoked,
        authentik_sessions_revoked=(
            authentik_result.get("sessions_revoked") if authentik_result else None
        ),
        uc_sessions_terminated=uc_terminated
    )

    return {
        "ok": True,
        "status": "terminated",
        "user_uid": uid,
        "event_id": event_id,
        "actions": actions,
        "timestamp": iso(utcnow())
    }
```

### 3.6 Updated QR Endpoint with SSO

```python
@app.get("/api/users/{uid}/qrcode")
@limiter.limit(LIMIT_QR)
def api_user_qrcode(
    request: Request,
    uid: str,
    ttlSec: Optional[int] = None,
    mode: str = "unified",
    claims: Dict[str, Any] = Depends(require_user)
):
    """
    Generate unified QR code for user provisioning.

    Includes:
    - UC block (always)
    - SSO block (when OrgProfile.ssoProfile.enabled = true)
    """
    user = get_user(uid)
    if not user:
        raise HTTPException(404, "User not found")

    org_dn = user.get("orgDn", OU_ORG)

    # Generate one-time token
    provision_token = secrets.token_urlsafe(24)
    token_hash = hashlib.sha256(provision_token.encode()).hexdigest()

    ttl = min(ttlSec or ORG_QR_DEFAULT_TTL_SEC, ORG_QR_MAX_TTL_SEC)
    exp_dt = utcnow() + timedelta(seconds=ttl)

    # Store token
    ORGDB.record_provision_token(
        token_hash=token_hash,
        uid=uid,
        profile_id="unified",
        expires_at=exp_dt
    )

    # Build UC payload (always included)
    uc_payload = {
        "tenant": LDAP_TENANT,
        "xmpp": {
            "domain": UCCHAT_XMPP_DOMAIN,
            "wsUrl": UCCHAT_XMPP_WS_URL
        },
        "sip": {
            "domain": UCCHAT_SIP_DOMAIN,
            "wssUrl": UCCHAT_SIP_WSS_URL
        },
        "credentials": {
            "username": uid,
            "token": provision_token
        }
    }

    # Build SSO payload (conditional - Phase 2)
    sso_payload = None
    sso_note = None

    # Find OrgProfile for user's org
    org_profile = _find_org_profile_for_dn(org_dn)

    if org_profile:
        profile_obj = json.loads(org_profile.get("profile_json", "{}"))
        sso_cfg = profile_obj.get("ssoProfile", {})

        if sso_cfg.get("enabled") and sso_cfg.get("oidc", {}).get("issuer"):
            oidc = sso_cfg["oidc"]
            sso_payload = {
                "issuer": oidc.get("issuer"),
                "clientId": oidc.get("clientId") or oidc.get("clients", {}).get("mobile"),
                "scopes": (oidc.get("scopes") or "openid profile email").split()
                          if isinstance(oidc.get("scopes"), str)
                          else oidc.get("scopes", ["openid", "profile", "email"]),
                "pkceRequired": oidc.get("pkceRequired", True)
            }
        else:
            sso_note = "SSO not enabled for this organization. UC-only provisioning."

    # Sign payload
    signed_payload = sign_provisioning_payload(
        uc_payload=uc_payload,
        sso_payload=sso_payload,
        ttl_sec=ttl
    )

    # Audit
    ORGDB.record_qr_issuance(
        user_uid=uid,
        org_dn=org_dn,
        issued_by=claims.get("sub", "unknown"),
        token_hash=token_hash,
        expires_at=exp_dt,
        client_ip=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent")
    )

    payload_json = json.dumps(signed_payload, separators=(',', ':'))
    qr_png = make_qr_png_base64(payload_json)

    response = {
        "ok": True,
        "uid": uid,
        "orgDn": org_dn,
        "qrType": mode,
        "ssoEnabled": sso_payload is not None,
        "payload": signed_payload,
        "pngBase64": qr_png
    }

    if sso_note:
        response["ssoNote"] = sso_note

    return response


def _find_org_profile_for_dn(org_dn: str) -> Optional[dict]:
    """Find OrgProfile matching org DN (exact or ancestor)."""
    profiles = ORGDB.list_profiles(tenant=None)

    # Exact match first
    for p in profiles:
        if p.get("org_dn") == org_dn:
            return p

    # Ancestor match (walk up the tree)
    parts = org_dn.split(",")
    for i in range(1, len(parts)):
        ancestor_dn = ",".join(parts[i:])
        for p in profiles:
            if p.get("org_dn") == ancestor_dn:
                return p

    return None
```

### 3.7 Configuration Updates

**New Environment Variables (Phase 2):**

```bash
# Authentik Integration
AUTHENTIK_API_URL=https://auth.example.com
AUTHENTIK_API_TOKEN=your-authentik-admin-token

# UC Server Integration
UC_SERVER_API_URL=http://uc-server:5280/api
UC_SERVER_API_KEY=your-uc-server-api-key

# Auth Mode (UC+SSO = true)
REQUIRE_OIDC_AUTH=true
ALLOW_BOOTSTRAP_WITHOUT_OIDC=false  # Disable after setup

# OIDC Configuration
OIDC_ISSUER=https://auth.example.com/application/o/directory/
OIDC_AUDIENCE=azblink-directory
OIDC_GROUPS_CLAIM=groups
OIDC_ADMIN_GROUP=IT-Admins
```

### 3.8 Deep Health Check Update

```python
@app.get("/api/health/deep")
def api_health_deep(claims: Dict[str, Any] = Depends(require_user)):
    """Deep health check - verifies all backend services."""
    from authentik_client import get_authentik_client
    from uc_client import get_uc_client

    checks = {}

    # PostgreSQL
    try:
        with ORGDB.connect().begin() as conn:
            conn.execute(text("SELECT 1"))
        checks["postgresql"] = {"status": "healthy"}
    except Exception as e:
        checks["postgresql"] = {"status": "unhealthy", "error": str(e)}

    # LDAP
    try:
        conn = get_conn()
        conn.unbind()
        checks["ldap"] = {"status": "healthy"}
    except Exception as e:
        checks["ldap"] = {"status": "unhealthy", "error": str(e)}

    # Redis
    try:
        import redis as redis_client
        r = redis_client.from_url(REDIS_URL)
        r.ping()
        checks["redis"] = {"status": "healthy"}
    except Exception as e:
        checks["redis"] = {"status": "unhealthy", "error": str(e)}

    # Authentik (Phase 2 - optional)
    authentik_client = get_authentik_client()
    if authentik_client:
        if authentik_client.health_check():
            checks["authentik"] = {"status": "healthy"}
        else:
            checks["authentik"] = {"status": "unhealthy", "error": "unreachable"}
    else:
        checks["authentik"] = {"status": "not_configured"}

    # UC Server (Phase 2 - optional)
    uc_client = get_uc_client()
    if uc_client:
        if uc_client.health_check():
            checks["uc_server"] = {"status": "healthy"}
        else:
            checks["uc_server"] = {"status": "unhealthy", "error": "unreachable"}
    else:
        checks["uc_server"] = {"status": "not_configured"}

    # Determine overall status
    critical_services = ["postgresql", "ldap", "redis"]
    critical_healthy = all(
        checks.get(s, {}).get("status") == "healthy"
        for s in critical_services
    )

    all_healthy = all(
        c.get("status") in ("healthy", "not_configured")
        for c in checks.values()
    )

    if critical_healthy and all_healthy:
        status = "healthy"
        status_code = 200
    elif critical_healthy:
        status = "degraded"  # Optional services down
        status_code = 200
    else:
        status = "unhealthy"
        status_code = 503

    return JSONResponse(
        status_code=status_code,
        content={
            "ok": critical_healthy,
            "status": status,
            "checks": checks
        }
    )
```

---

## 4. Implementation Tasks

### 4.1 Backend Changes

| Task | File | Priority | Effort |
|------|------|----------|--------|
| Create `authentik_client.py` | New | P0 | 2 days |
| Create `uc_client.py` | New | P0 | 2 days |
| Update termination endpoint | `main.py` | P0 | 1 day |
| Add SSO block to QR endpoint | `main.py` | P0 | 1 day |
| Update deep health check | `main.py` | P1 | 0.5 day |
| Add OrgProfile SSO validation | `main.py` | P1 | 0.5 day |
| Add config variables | `config.py` | P1 | 0.5 day |

### 4.2 Database Migrations

**File:** `migrations/005_phase2_sso.sql`

```sql
-- Migration 005: Phase 2 SSO Support
-- Adds audit columns for SSO-related events

-- Add Authentik-specific columns to termination_events
ALTER TABLE termination_events
ADD COLUMN IF NOT EXISTS authentik_tokens_revoked INTEGER;

-- Add breakglass audit table
CREATE TABLE IF NOT EXISTS breakglass_audit (
    id SERIAL PRIMARY KEY,
    activated_by VARCHAR(255) NOT NULL,
    mode VARCHAR(50) NOT NULL,
    activated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    deactivated_at TIMESTAMP WITH TIME ZONE,
    reason TEXT
);

-- Add index for breakglass audit
CREATE INDEX IF NOT EXISTS idx_breakglass_audit_activated
ON breakglass_audit(activated_at DESC);
```

---

## 5. Testing Requirements

### 5.1 Unit Tests

```python
# tests/test_authentik_client.py

def test_authentik_client_revokes_sessions(mock_authentik):
    """Authentik client should revoke user sessions."""
    client = AuthentikClient()

    result = client.revoke_all_user_access("alice")

    assert result["sessions_revoked"] >= 0
    assert result["tokens_revoked"] >= 0


def test_authentik_client_handles_unavailable(mock_authentik_down):
    """Authentik client should handle server unavailability."""
    client = AuthentikClient()

    assert client.health_check() is False
    assert client.get_user_sessions("alice") == []


# tests/test_uc_client.py

def test_uc_client_terminates_sessions(mock_uc_server):
    """UC client should terminate user sessions."""
    client = UCServerClient()

    count = client.terminate_user_sessions("alice")

    assert isinstance(count, int)


def test_uc_client_handles_unavailable(mock_uc_server_down):
    """UC client should handle server unavailability."""
    client = UCServerClient()

    assert client.health_check() is False
    assert client.terminate_user_sessions("alice") == 0
```

### 5.2 Integration Tests

```python
# tests/test_termination.py

def test_termination_revokes_authentik_sessions(
    client, admin_token, test_user, mock_authentik
):
    """Termination should revoke Authentik sessions."""
    response = client.post(
        f"/api/users/{test_user['uid']}/terminate",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={"reason": "test_termination"}
    )

    assert response.status_code == 200
    data = response.json()

    assert data["ok"] is True
    assert data["actions"]["ldap_disabled"] is True
    assert "authentik" in data["actions"]


def test_termination_succeeds_without_authentik(
    client, admin_token, test_user
):
    """Termination should succeed even when Authentik unavailable."""
    # No mock = Authentik not configured

    response = client.post(
        f"/api/users/{test_user['uid']}/terminate",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={"reason": "test_termination"}
    )

    assert response.status_code == 200
    data = response.json()

    assert data["ok"] is True
    assert data["actions"]["ldap_disabled"] is True
    assert data["actions"]["authentik"] == "not_configured_or_unavailable"


# tests/test_qr_sso.py

def test_qr_includes_sso_when_enabled(
    client, admin_token, test_user, sso_enabled_org_profile
):
    """QR should include SSO block when OrgProfile has SSO enabled."""
    response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers={"Authorization": f"Bearer {admin_token}"}
    )

    assert response.status_code == 200
    data = response.json()

    assert data["ssoEnabled"] is True
    assert data["payload"]["payload"]["sso"] is not None
    assert "issuer" in data["payload"]["payload"]["sso"]


def test_qr_sso_null_when_disabled(
    client, admin_token, test_user
):
    """QR should have sso=null when SSO not enabled."""
    response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers={"Authorization": f"Bearer {admin_token}"}
    )

    assert response.status_code == 200
    data = response.json()

    assert data["ssoEnabled"] is False
    assert data["payload"]["payload"]["sso"] is None
```

### 5.3 End-to-End Tests

```python
# tests/test_e2e_provisioning.py

def test_full_provisioning_flow_with_sso(
    client, admin_token, test_user, sso_enabled_org_profile
):
    """Full flow: generate QR → consume → verify credentials."""
    # 1. Generate QR
    qr_response = client.get(
        f"/api/users/{test_user['uid']}/qrcode",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert qr_response.status_code == 200
    qr_data = qr_response.json()

    # 2. Extract token from payload
    token = qr_data["payload"]["payload"]["uc"]["credentials"]["token"]

    # 3. Consume token
    consume_response = client.post(
        "/api/provision/consume",
        json={"token": token}
    )
    assert consume_response.status_code == 200

    # 4. Verify session returned
    session = consume_response.json()["session"]
    assert "xmpp" in session
    assert "sip" in session

    # 5. Verify SSO config was in QR
    assert qr_data["payload"]["payload"]["sso"]["issuer"] is not None
```

---

## 6. Acceptance Criteria

### 6.1 Functional Requirements

| ID | Requirement | Test |
|----|-------------|------|
| F1 | QR includes SSO block when OrgProfile.ssoProfile.enabled | `test_qr_includes_sso_when_enabled` |
| F2 | SSO block is null when not enabled | `test_qr_sso_null_when_disabled` |
| F3 | Termination revokes Authentik sessions | `test_termination_revokes_authentik_sessions` |
| F4 | Termination terminates UC sessions | `test_termination_terminates_uc_sessions` |
| F5 | Termination succeeds when Authentik unavailable | `test_termination_succeeds_without_authentik` |
| F6 | Deep health check includes Authentik status | Manual |
| F7 | Deep health check includes UC Server status | Manual |

### 6.2 Security Requirements

| ID | Requirement | Test |
|----|-------------|------|
| S1 | Authentik API token stored securely | Config validation |
| S2 | UC Server API key stored securely | Config validation |
| S3 | SSO config only from trusted OrgProfile | Code review |
| S4 | Termination is atomic (LDAP first) | `test_termination_aborts_on_ldap_failure` |

### 6.3 Resilience Requirements

| ID | Requirement | Test |
|----|-------------|------|
| R1 | UC continues when Authentik down | `test_qr_generates_when_authentik_down` |
| R2 | Termination completes when Authentik down | `test_termination_succeeds_without_authentik` |
| R3 | Health check shows degraded (not failed) when Authentik down | Manual |

---

## 7. Deployment Checklist

### 7.1 Pre-Deployment

- [ ] Phase 1 complete and verified
- [ ] Authentik deployed and configured
- [ ] UC Server session API available
- [ ] `AUTHENTIK_API_URL` configured
- [ ] `AUTHENTIK_API_TOKEN` generated with minimal permissions
- [ ] `UC_SERVER_API_URL` configured
- [ ] `UC_SERVER_API_KEY` configured
- [ ] OrgProfile(s) created with `ssoProfile.enabled = true`
- [ ] Database migration applied

### 7.2 Post-Deployment Verification

- [ ] `GET /api/health/deep` shows Authentik healthy
- [ ] `GET /api/health/deep` shows UC Server healthy
- [ ] QR generation includes SSO block for SSO-enabled org
- [ ] Token consumption returns session credentials
- [ ] User termination revokes Authentik sessions
- [ ] User termination terminates UC sessions
- [ ] Graceful degradation: QR works when Authentik down

### 7.3 Day 1 Configuration Hardening

After verifying SSO works:

```bash
# Lock down configuration
export REQUIRE_OIDC_AUTH=true
export ALLOW_BOOTSTRAP_WITHOUT_OIDC=false

# Restart backend
systemctl restart azblink-directory
```

---

## 8. Timeline

| Week | Tasks | Deliverables |
|------|-------|--------------|
| 1 | `authentik_client.py`, `uc_client.py` | Client modules |
| 1 | Update termination endpoint | Complete termination flow |
| 2 | Add SSO to QR endpoint | Unified QR with SSO |
| 2 | Update health check | Authentik/UC status |
| 2 | Testing, documentation | Phase 2 complete |

**Total Estimated Effort:** 10-12 developer days

---

## 9. Dependencies & Risks

### 9.1 Dependencies

| Dependency | Owner | Status |
|------------|-------|--------|
| Phase 1 Complete | Internal | Required |
| Authentik Deployed | Ops | Required |
| Authentik Admin API | External | Stable |
| UC Server Session API | UC Team | ⚠️ Verify |
| OIDC Provider Config | Ops | Required |

### 9.2 Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Authentik API changes | Low | Medium | Pin API version |
| UC Server lacks session API | Medium | High | Define API contract |
| OIDC misconfiguration | Medium | Medium | Validation + break-glass |
| Network partition to Authentik | Low | Medium | Graceful degradation |

---

## 10. Graceful Degradation Matrix

| Scenario | UC (Plane A) | SSO (Plane B) | QR Generation |
|----------|--------------|---------------|---------------|
| All healthy | ✅ Working | ✅ Working | ✅ UC + SSO |
| Authentik down | ✅ Working | ❌ Down | ✅ UC only (sso=null) |
| UC Server down | ❌ Down | ✅ Working | ✅ UC + SSO |
| OIDC misconfigured | ✅ Working | ⚠️ Errors | ✅ UC only |
| OrgProfile missing | ✅ Working | ❌ No config | ✅ UC only |
| Redis down | ⚠️ Degraded | ⚠️ Degraded | ⚠️ No rate limit |
| PostgreSQL down | ❌ Down | ❌ Down | ❌ Cannot issue |
| LDAP down | ❌ Down | ❌ Down | ❌ Cannot issue |

---

## 11. Mobile Client Requirements (Phase 2)

### 11.1 SSO Block Handling

```
1. Parse QR payload
2. Verify signature
3. Check expiration
4. Configure UC (always)
5. If sso block present:
   a. Store OIDC configuration
   b. Initiate PKCE authorization flow
   c. Exchange code for tokens
   d. Store tokens securely
6. Mark provisioning complete
```

### 11.2 PKCE Flow

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ Mobile App  │     │  Browser    │     │  Authentik  │
└──────┬──────┘     └──────┬──────┘     └──────┬──────┘
       │                   │                   │
       │ Generate code_verifier (random)       │
       │ Compute code_challenge (SHA256)       │
       │                   │                   │
       │ Open auth URL with code_challenge     │
       │──────────────────────────────────────▶│
       │                   │                   │
       │                   │  User logs in     │
       │                   │◀─────────────────▶│
       │                   │                   │
       │◀──────────────────│ Redirect with code│
       │                   │                   │
       │ Exchange code + code_verifier         │
       │──────────────────────────────────────▶│
       │                   │                   │
       │◀──────────────────────────────────────│
       │              Tokens (access, refresh) │
       │                   │                   │
       │ Store tokens in Keychain/Keystore     │
       │                   │                   │
```

### 11.3 Session Termination Handling

When server terminates session:

1. Receive termination signal (XMPP headline / HTTP 401)
2. Clear all stored credentials:
   - UC session tokens
   - OIDC tokens (access, refresh, ID)
   - Cached user info
3. Display "Session terminated by administrator"
4. Return to QR scan screen

---

## 12. Summary

Phase 2 extends the Phase 1 UC-only QR system to include SSO configuration while maintaining the critical invariant that **UC always works independently of SSO**. The unified QR model provides a single provisioning experience while gracefully degrading when SSO components are unavailable.

Key deliverables:
- `authentik_client.py` - Authentik Admin API client
- `uc_client.py` - UC Server session management client
- Updated QR endpoint with conditional SSO block
- Complete termination flow across all planes
- Comprehensive health checking
- Graceful degradation for all failure modes
