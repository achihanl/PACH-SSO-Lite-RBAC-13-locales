# QR Code Preview Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add a fullstack shareable QR code preview feature with expiring links
**Architecture:** Separate preview token → DB snapshot → public API → public frontend page
**Tech Stack:** FastAPI, SQLAlchemy Core, PostgreSQL, React 19, TanStack Router, @azblink/ui, Tailwind CSS 4
**Domains:** backend, frontend, database

---

### Task 1: Database Migration — qr_preview_links table
**domain:** database
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [postgresql, sqlalchemy-core]

**Files:**
- Create: `migrations/016_qr_preview_links.sql`
- Modify: `src/backend/orgdb.py` — add table definition + CRUD methods

**Step 1: Create migration file**
```sql
-- migrations/016_qr_preview_links.sql
CREATE TABLE IF NOT EXISTS qr_preview_links (
    id                  SERIAL PRIMARY KEY,
    preview_token_hash  VARCHAR(64) NOT NULL UNIQUE,
    uid                 VARCHAR(128) NOT NULL,
    display_name        VARCHAR(255),
    org_dn              TEXT,
    qr_png_base64       TEXT NOT NULL,
    qr_payload          JSONB NOT NULL,
    qr_expires_at       TIMESTAMPTZ NOT NULL,
    preview_expires_at  TIMESTAMPTZ NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          VARCHAR(255) NOT NULL,
    access_count        INTEGER NOT NULL DEFAULT 0,
    last_accessed_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_qr_preview_links_expires ON qr_preview_links(preview_expires_at);
CREATE INDEX IF NOT EXISTS idx_qr_preview_links_uid ON qr_preview_links(uid);
```

**Step 2: Add SQLAlchemy table definition in orgdb.py**
Add `qr_preview_links` Table alongside existing tables (after `sync_events`).

**Step 3: Add OrgDB methods**
- `create_preview_link(preview_token_hash, uid, display_name, org_dn, qr_png_base64, qr_payload, qr_expires_at, preview_expires_at, created_by) -> dict`
- `get_preview_link(preview_token_hash) -> dict | None`
- `increment_preview_access(preview_token_hash) -> None`

**Step 4: Verify** — Run `just psql < ../../migrations/016_qr_preview_links.sql` to apply migration.

---

### Task 2: Backend — Create preview link endpoint
**domain:** backend
**depends_on:** [1]
**parallel_group:** 2
**capabilities_needed:** [fastapi, pydantic, security]

**Files:**
- Modify: `src/backend/main.py` — add `POST /api/users/{uid}/qrcode/share`
- Modify: `src/backend/config.py` — add `ORG_QR_PREVIEW_DEFAULT_TTL_SEC`, `ORG_QR_PREVIEW_MAX_TTL_SEC`

**Step 1: Add config constants**
```python
# config.py
ORG_QR_PREVIEW_DEFAULT_TTL_SEC = int(os.getenv("ORG_QR_PREVIEW_DEFAULT_TTL_SEC", "3600"))
ORG_QR_PREVIEW_MAX_TTL_SEC = int(os.getenv("ORG_QR_PREVIEW_MAX_TTL_SEC", "86400"))
```

**Step 2: Add Pydantic models**
```python
class QrPreviewCreateReq(BaseModel):
    pngBase64: str = Field(..., min_length=1)
    payload: dict  # The signed QR payload
    qrExpiresAt: int  # Unix timestamp
    previewTtlSec: Optional[int] = None
    displayName: Optional[str] = None
    orgDn: Optional[str] = None
```

**Step 3: Add endpoint**
```python
@app.post("/api/users/{uid}/qrcode/share")
@limiter.limit(LIMIT_QR)
def api_create_qr_preview(request: Request, uid: str, req: QrPreviewCreateReq, claims: Dict = Depends(require_user)):
    # Generate preview token
    preview_token = secrets.token_urlsafe(32)
    preview_token_hash = hashlib.sha256(preview_token.encode()).hexdigest()

    # Calculate expiry
    ttl = min(req.previewTtlSec or ORG_QR_PREVIEW_DEFAULT_TTL_SEC, ORG_QR_PREVIEW_MAX_TTL_SEC)
    preview_expires_at = utcnow() + timedelta(seconds=ttl)
    qr_expires_at = datetime.fromtimestamp(req.qrExpiresAt, tz=timezone.utc)

    # Strip credentials from payload before storing
    safe_payload = _strip_credentials(req.payload)

    # Store
    ORGDB.create_preview_link(
        preview_token_hash=preview_token_hash,
        uid=uid,
        display_name=req.displayName,
        org_dn=req.orgDn,
        qr_png_base64=req.pngBase64,
        qr_payload=safe_payload,
        qr_expires_at=qr_expires_at,
        preview_expires_at=preview_expires_at,
        created_by=claims.get("sub", "unknown"),
    )

    return {
        "ok": True,
        "previewToken": preview_token,  # Raw token for URL construction
        "previewExpiresAt": preview_expires_at.isoformat(),
    }
```

**Step 4: Add `_strip_credentials` helper**
Removes `payload.uc.credentials` from the stored payload so preview never exposes tokens/passwords.

---

### Task 3: Backend — Public preview fetch endpoint
**domain:** backend
**depends_on:** [1]
**parallel_group:** 2
**capabilities_needed:** [fastapi, security]

**Files:**
- Modify: `src/backend/main.py` — add `GET /api/qr/preview/{token}`

**Step 1: Add endpoint (no auth)**
```python
@app.get("/api/qr/preview/{token}")
@limiter.limit(LIMIT_QR)
def api_get_qr_preview(request: Request, token: str):
    # Hash the token
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    link = ORGDB.get_preview_link(token_hash)

    if not link:
        raise HTTPException(404, detail={"ok": False, "error": "PREVIEW_NOT_FOUND"})

    # Check expiry
    if link["preview_expires_at"] <= utcnow():
        raise HTTPException(410, detail={"ok": False, "error": "PREVIEW_EXPIRED"})

    # Increment access counter
    ORGDB.increment_preview_access(token_hash)

    # Extract service info from payload
    payload = link.get("qr_payload") or {}
    uc = payload.get("payload", {}).get("uc", {})
    services = []
    if uc.get("xmpp", {}).get("domain"):
        services.append({"type": "xmpp", "domain": uc["xmpp"]["domain"]})
    if uc.get("sip", {}).get("domain"):
        services.append({"type": "sip", "domain": uc["sip"]["domain"]})

    return {
        "ok": True,
        "uid": link["uid"],
        "displayName": link.get("display_name"),
        "orgDn": link.get("org_dn"),
        "pngBase64": link["qr_png_base64"],
        "qrExpiresAt": link["qr_expires_at"].isoformat(),
        "previewExpiresAt": link["preview_expires_at"].isoformat(),
        "services": services,
        "schema": payload.get("schema", "unknown"),
    }
```

**Step 2: Verify** — Test with curl: `curl localhost:8081/api/qr/preview/invalid-token` → 404

---

### Task 4: Frontend — QR preview types
**domain:** frontend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [typescript]

**Files:**
- Modify: `src/frontend/src/types/qr.ts` — add QRPreviewResponse type

**Step 1: Add types**
```typescript
/** GET /api/qr/preview/{token} response */
export interface QRPreviewResponse {
  ok: true;
  uid: string;
  displayName: string | null;
  orgDn: string | null;
  pngBase64: string;
  qrExpiresAt: string;       // ISO 8601
  previewExpiresAt: string;   // ISO 8601
  services: QRPreviewService[];
  schema: string;
}

export interface QRPreviewService {
  type: 'xmpp' | 'sip';
  domain: string;
}

/** POST /api/users/{uid}/qrcode/share response */
export interface QRShareResponse {
  ok: true;
  previewToken: string;
  previewExpiresAt: string;
}

/** POST /api/users/{uid}/qrcode/share request */
export interface QRShareRequest {
  pngBase64: string;
  payload: Record<string, unknown>;
  qrExpiresAt: number;
  previewTtlSec?: number;
  displayName?: string;
  orgDn?: string;
}

/** Error response for preview endpoints */
export interface QRPreviewError {
  ok: false;
  error: 'PREVIEW_NOT_FOUND' | 'PREVIEW_EXPIRED' | 'rate_limit_exceeded';
}
```

---

### Task 5: Frontend — Public preview route + page
**domain:** frontend
**depends_on:** [3, 4]
**parallel_group:** 3
**capabilities_needed:** [react, tanstack-router, tailwind]

**Files:**
- Create: `src/frontend/src/routes/qr/preview.$token.tsx`
- Create: `src/frontend/src/components/features/qr-preview/QRPreviewPage.tsx`
- Modify: `src/frontend/src/routes/__root.tsx` — add `/qr/` to PUBLIC_ROUTES

**Step 1: Update PUBLIC_ROUTES in __root.tsx**
Change `PUBLIC_ROUTES` check to also match paths starting with `/qr/`:
```typescript
const PUBLIC_ROUTES = ['/login'];
const isPublicRoute = PUBLIC_ROUTES.includes(location.pathname) || location.pathname.startsWith('/qr/');
```

**Step 2: Create route file**
```typescript
// src/frontend/src/routes/qr/preview.$token.tsx
import { createFileRoute } from '@tanstack/react-router';
import { QRPreviewPage } from '@/components/features/qr-preview/QRPreviewPage';

export const Route = createFileRoute('/qr/preview/$token')({
  component: QRPreviewPageRoute,
});

function QRPreviewPageRoute() {
  const { token } = Route.useParams();
  return <QRPreviewPage token={token} />;
}
```

**Step 3: Create QRPreviewPage component**
Full-screen centered layout with:
- AZBlink branding
- QR image (large, white background)
- User info: display name, org
- Services: XMPP/SIP domains
- Live countdown to preview link expiry
- Download button
- Expired state: friendly message
- Not found state: error message
- Loading state: skeleton

**Step 4: Run route generation** — `just ui-routes`

---

### Task 6: Frontend — Share QR mutation + integration
**domain:** frontend
**depends_on:** [2, 4]
**parallel_group:** 3
**capabilities_needed:** [react, tanstack-query]

**Files:**
- Create: `src/frontend/src/lib/queries/qr-share.ts`
- Modify: `src/frontend/src/components/features/qr-display.tsx` — update "Copy Link" to share

**Step 1: Create share mutation hook**
```typescript
// src/frontend/src/lib/queries/qr-share.ts
export function useShareQR() {
  return useMutation({
    mutationFn: ({ uid, ...data }: QRShareRequest & { uid: string }) =>
      getApi().post<QRShareResponse>(`/users/${uid}/qrcode/share`, data),
    onError: () => toast.error('Failed to create share link'),
  });
}
```

**Step 2: Update qr-display.tsx**
Replace `handleCopyLink` to:
1. Call share mutation with QR data
2. Construct preview URL: `${window.location.origin}/qr/preview/${response.previewToken}`
3. Copy URL to clipboard
4. Show toast with success message

---

### Task 7: Backend integration test
**domain:** backend
**depends_on:** [2, 3]
**parallel_group:** 4
**capabilities_needed:** [testing, fastapi]

**Files:**
- Modify: `tests/test_provisioning.py` — add QR preview tests

**Step 1: Test create preview link**
- Generate QR for a user
- POST to share endpoint
- Verify 200, response has previewToken

**Step 2: Test fetch valid preview**
- Create preview link
- GET the preview endpoint with token
- Verify response has QR data, no credentials

**Step 3: Test expired preview**
- Create preview link with very short TTL
- Wait/mock expiry
- GET → verify 410

**Step 4: Test invalid token**
- GET with random token → verify 404

---

### Task 8: Frontend countdown timer hook
**domain:** frontend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [react]

**Files:**
- Create: `src/frontend/src/hooks/use-countdown.ts`

**Step 1: Create hook**
```typescript
/** Countdown timer that ticks every second */
export function useCountdown(expiresAt: string | null) {
  const [remaining, setRemaining] = useState<CountdownState>({ ...initial });

  useEffect(() => {
    if (!expiresAt) return;
    const tick = () => {
      const ms = new Date(expiresAt).getTime() - Date.now();
      if (ms <= 0) { setRemaining({ expired: true, ... }); return; }
      // Calculate h, m, s from ms
      setRemaining({ ... });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [expiresAt]);

  return remaining;
}
```
