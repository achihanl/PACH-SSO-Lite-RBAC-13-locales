# Authentik Dev Stack Integration Design

**Goal:** Add Authentik as a local dev IdP to the docker-compose stack so OIDC login works end-to-end without external infrastructure.

**Date:** 2026-03-04

## Architecture

Three new services join the existing dev stack:

```
Existing:                           New:
  postgres (azblink DB :5433)         authentik-postgres (authentik DB, internal)
  redis (:6380)                       authentik-server (:9000, OIDC IdP)
  openldap (:1390)                    authentik-worker (background tasks)
  directory-api (:8000)
  directory-ui (:5173)
  traefik (:8081)
```

All on `azblink-net`. Authentik server also joins `cloudflare-tunnel` for external access.

## Access URLs

| Service | LAN | Cloudflare |
|---|---|---|
| AZBlink UI | `http://192.168.4.111:8081` | `https://azblink-ad.keithmoc.dev` |
| Authentik | `http://192.168.4.111:9000` | `https://authentik.keithmoc.dev` |

## OAuth2 Provider Configuration

- **Client type:** `public` (SPA with PKCE, no client secret)
- **Client ID:** `azblink-directory`
- **Redirect URIs:**
  - `http://192.168.4.111:8081/auth/callback`
  - `https://azblink-ad.keithmoc.dev/auth/callback`
  - `http://localhost:8081/auth/callback`
- **Scopes:** `openid profile email`
- **Token validity:** 8 hours access, 7 days refresh
- **Authorization flow:** `default-provider-authorization-explicit-consent`

## Bootstrap Strategy

Zero-touch via environment variables (read on first startup only):

| Variable | Value | Purpose |
|---|---|---|
| `AUTHENTIK_BOOTSTRAP_PASSWORD` | `adminpassword` | Creates `akadmin` user |
| `AUTHENTIK_BOOTSTRAP_EMAIL` | `admin@azblink.local` | Admin email |
| `AUTHENTIK_BOOTSTRAP_TOKEN` | generated token | API access for seed script |
| `AUTHENTIK_SECRET_KEY` | generated key | Session/crypto key |

## Seed Script

A one-shot container (`authentik-seed`) runs after `authentik-server` is healthy:
1. Waits for Authentik API to respond
2. Creates OAuth2 provider via `POST /api/v3/providers/oauth2/`
3. Creates application via `POST /api/v3/core/applications/`
4. Creates IT-Admins group and assigns akadmin to it

## Environment Variable Mapping

### Backend (directory-api)

| Variable | Value |
|---|---|
| `OIDC_ISSUER` | `http://authentik-server:9000/application/o/azblink-directory/` |
| `OIDC_AUDIENCE` | `azblink-directory` |
| `OIDC_ADMIN_GROUP` | `IT-Admins` |
| `OIDC_GROUPS_CLAIM` | `groups` |
| `AUTHENTIK_API_URL` | `http://authentik-server:9000` |
| `AUTHENTIK_API_TOKEN` | `(bootstrap token)` |

### Frontend (directory-ui, build-time)

| Variable | Value |
|---|---|
| `VITE_OIDC_ISSUER` | `https://authentik.keithmoc.dev/application/o/azblink-directory/` |
| `VITE_OIDC_CLIENT_ID` | `azblink-directory` |
| `VITE_OIDC_REDIRECT_URI` | `https://azblink-ad.keithmoc.dev/auth/callback` |
| `VITE_OIDC_ADMIN_GROUP` | `IT-Admins` |

**Note:** Frontend uses the Cloudflare URL because OIDC discovery + authorize happen in the browser. Backend uses Docker-internal hostnames for token verification.

## Cloudflare Tunnel

New ingress file `ingress.d/authentik.yml`:

```yaml
ingress:
  - hostname: authentik.keithmoc.dev
    service: http://authentik-server:9000
    originRequest:
      connectTimeout: 30s
      noTLSVerify: true
```

## Considerations

- **Separate Postgres:** Authentik manages its own schema — sharing AZBlink's Postgres would risk migration conflicts.
- **DEV_AUTH_TOKEN preserved:** For test suite (no Authentik needed in CI). OIDC is for interactive dev use.
- **Public client (no secret):** SPA can't keep secrets. PKCE S256 provides security.
- **Authentik version:** `2025.8` (stable LTS). 2025.10+ removed Redis but may have breaking changes.
