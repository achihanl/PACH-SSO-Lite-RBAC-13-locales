# Single-LDAP Architecture Migration — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Collapse the two-LDAP architecture (AD LDAP + UED LDAP) into a single LDAP that holds identity + UC service attributes, eliminating the UED Sync microservice entirely.

**Architecture:** Single atomic LDAP ADD writes inetOrgPerson + posixAccount + AsteriskPjsip* attributes on the same entry. Profiles gain `xmpp_enabled`/`sip_enabled` flags and direct service endpoint fields. All async sync infrastructure (event queue, background worker, HTTP relay) is removed.

**Tech Stack:** Python 3.12, FastAPI, python-ldap3, PostgreSQL, OpenLDAP (with Asterisk PJSIP schema), Docker Compose

**Design Doc:** `docs/plans/2026-03-02-single-ldap-architecture-design.md`

---

## Phase 1: Database Migration + Backend UC Schema

### Task 1: Create the database migration

**Files:**
- Create: `migrations/017_single_ldap.sql`

**Step 1: Write the migration SQL**

```sql
-- migrations/017_single_ldap.sql
-- Single-LDAP architecture: remove UED Sync infrastructure, add direct UC provisioning fields
BEGIN;

-- 1. Drop UED sync event queue
DROP TABLE IF EXISTS sync_events CASCADE;

-- 2. Add direct UC provisioning fields to config_templates
ALTER TABLE config_templates
    ADD COLUMN IF NOT EXISTS xmpp_enabled BOOLEAN NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS sip_enabled BOOLEAN NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS xmpp_domain TEXT,
    ADD COLUMN IF NOT EXISTS xmpp_ws_url TEXT,
    ADD COLUMN IF NOT EXISTS sip_domain TEXT,
    ADD COLUMN IF NOT EXISTS sip_wss_url TEXT;

-- 3. Remove UED connector fields
ALTER TABLE config_templates
    DROP COLUMN IF EXISTS ued_api_url,
    DROP COLUMN IF EXISTS ued_api_key_enc,
    DROP COLUMN IF EXISTS ued_enabled,
    DROP COLUMN IF EXISTS discovered_schema_name,
    DROP COLUMN IF EXISTS discovered_at,
    DROP COLUMN IF EXISTS discovered_capabilities,
    DROP COLUMN IF EXISTS discovered_service_endpoints,
    DROP COLUMN IF EXISTS last_sync_at,
    DROP COLUMN IF EXISTS last_error;

COMMIT;
```

**Step 2: Verify migration applies cleanly**

Run: `just psql < ../../migrations/017_single_ldap.sql`

Expected: `DROP TABLE`, `ALTER TABLE` (multiple), no errors.

**Step 3: Commit**

```bash
git add migrations/017_single_ldap.sql
git commit -m "feat: migration 017 — single-LDAP schema (drop sync_events, add UC fields)"
```

---

### Task 2: Add UC attribute builder to ldap_client.py

This inlines the schema logic from `src/ued-sync/src/ued_sync/schemas/pjsip.py` into the backend.

**Files:**
- Modify: `src/backend/ldap_client.py` (add new function after `ssha_password` at line 20)

**Step 1: Write test for UC attribute builder**

Create test in `tests/test_uc_attrs.py`:

```python
"""Tests for UC (XMPP/SIP) LDAP attribute building."""

import pytest
import requests

BASE = "http://localhost:8081/api"


def test_build_xmpp_attrs_returns_posix_objectclasses():
    """XMPP-only should add posixAccount objectClasses + attrs."""
    from ldap_client import build_uc_attrs
    attrs, ocs = build_uc_attrs(
        xmpp_enabled=True, sip_enabled=False,
        uid_number=10001, extension=None, sip_password=None,
        username="alice",
    )
    assert "posixAccount" in ocs
    assert "account" in ocs
    assert attrs["uidNumber"] == "10001"
    assert attrs["gidNumber"] == "1000"
    assert attrs["homeDirectory"] == "/home/alice"
    assert attrs["loginShell"] == "/bin/bash"
    # No SIP attrs
    assert "AstAuthPassword" not in attrs


def test_build_sip_attrs_returns_pjsip_objectclasses():
    """SIP enabled should add AsteriskPjsip* objectClasses + SIP attrs."""
    from ldap_client import build_uc_attrs
    attrs, ocs = build_uc_attrs(
        xmpp_enabled=True, sip_enabled=True,
        uid_number=10001, extension=1001, sip_password="testpw123",
        username="alice",
    )
    assert "AsteriskPjsipEndpoint" in ocs
    assert "AsteriskPjsipAuth" in ocs
    assert "AsteriskPjsipAor" in ocs
    assert attrs["AstAuthUsername"] == "alice"
    assert attrs["AstAuthPassword"] == "testpw123"
    assert attrs["AstEndpointContext"] == "from-internal"
    assert attrs["AstAorMaxContacts"] == "1"


def test_build_uc_attrs_no_flags_returns_empty():
    """Neither xmpp nor sip enabled should return empty attrs/ocs."""
    from ldap_client import build_uc_attrs
    attrs, ocs = build_uc_attrs(
        xmpp_enabled=False, sip_enabled=False,
        uid_number=None, extension=None, sip_password=None,
        username="alice",
    )
    assert attrs == {}
    assert ocs == []
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_uc_attrs.py -v`

Expected: FAIL with `ImportError: cannot import name 'build_uc_attrs' from 'ldap_client'`

**Step 3: Implement build_uc_attrs in ldap_client.py**

Add after the `ssha_password` function (line 20 of `src/backend/ldap_client.py`):

```python
# ----------------------------
# UC attribute builder (single-LDAP: identity + XMPP/SIP on same entry)
# ----------------------------
_SIP_AUTH_REALM = os.getenv("SIP_AUTH_REALM", "asterisk")

def build_uc_attrs(
    *,
    xmpp_enabled: bool,
    sip_enabled: bool,
    uid_number: int | None,
    extension: int | None,
    sip_password: str | None,
    username: str,
) -> tuple[dict[str, str], list[str]]:
    """Build UC LDAP attributes and objectClasses for a user entry.

    - xmpp_enabled → adds posixAccount (XMPP LDAP bind auth uses userPassword)
    - sip_enabled → adds posixAccount + AsteriskPjsip{Endpoint,Auth,Aor}
    - Returns (attrs_dict, extra_objectClasses) to merge into create_user
    """
    if not xmpp_enabled and not sip_enabled:
        return {}, []

    ocs: list[str] = ["account", "posixAccount"]
    attrs: dict[str, str] = {
        "uidNumber": str(uid_number),
        "gidNumber": "1000",
        "homeDirectory": f"/home/{username}",
        "loginShell": "/bin/bash",
    }

    if sip_enabled:
        ocs.extend(["AsteriskPjsipEndpoint", "AsteriskPjsipAuth", "AsteriskPjsipAor"])
        attrs.update({
            # Endpoint
            "AstEndpointContext": "from-internal",
            "AstEndpointAllow": "!all,ulaw,alaw,opus",
            "AstEndpointDisallow": "all",
            "AstEndpointTransport": "transport-udp",
            "AstEndpointAors": username,
            "AstEndpointAuth": username,
            # Auth
            "AstAuthType": "userpass",
            "AstAuthUsername": username,
            "AstAuthPassword": sip_password or "",
            "AstAuthRealm": _SIP_AUTH_REALM,
            # AoR
            "AstAorMaxContacts": "1",
            "AstAorRemoveExisting": "yes",
            "AstAorQualifyFrequency": "60",
        })

    return attrs, ocs
```

Also export `build_uc_attrs` so tests can import it.

**Step 4: Run test to verify it passes**

Run: `just test-quick -- tests/test_uc_attrs.py -v`

Expected: 3 tests PASS.

**Step 5: Commit**

```bash
git add src/backend/ldap_client.py tests/test_uc_attrs.py
git commit -m "feat: build_uc_attrs — UC LDAP attribute builder for single-LDAP provisioning"
```

---

### Task 3: Extend create_user to accept UC attributes

**Files:**
- Modify: `src/backend/ldap_client.py:719-761` (the `create_user` function)

**Step 1: Write integration test for UC-enriched user creation**

Add to `tests/test_uc_attrs.py`:

```python
def test_create_user_with_sip_attrs_integration(admin_token, unique_uid):
    """Create user via API with SIP profile and verify LDAP entry has pjsip attrs."""
    # This test requires a profile with sip_enabled=true to exist
    # For now, test the ldap_client function directly
    from ldap_client import create_user, get_user, delete_user

    uid = unique_uid("uc-sip")
    result = create_user(
        uid=uid,
        display_name="UC Test User",
        mail="uc@test.com",
        mobile="",
        org_dn="ou=org,dc=azblink,dc=com",
        password="testpassword",
        uc_attrs={"uidNumber": "99001", "gidNumber": "1000",
                  "homeDirectory": f"/home/{uid}", "loginShell": "/bin/bash",
                  "AstAuthType": "userpass", "AstAuthUsername": uid,
                  "AstAuthPassword": "sippass123", "AstAuthRealm": "asterisk",
                  "AstEndpointContext": "from-internal", "AstEndpointAllow": "!all,ulaw,alaw,opus",
                  "AstEndpointDisallow": "all", "AstEndpointTransport": "transport-udp",
                  "AstEndpointAors": uid, "AstEndpointAuth": uid,
                  "AstAorMaxContacts": "1", "AstAorRemoveExisting": "yes",
                  "AstAorQualifyFrequency": "60"},
        uc_object_classes=["account", "posixAccount",
                          "AsteriskPjsipEndpoint", "AsteriskPjsipAuth", "AsteriskPjsipAor"],
    )
    assert result["status"] == "created"

    # Verify LDAP entry has the SIP attributes
    user = get_user(uid)
    assert user is not None
    assert uid in user.get("dn", "")

    # Cleanup
    delete_user(uid)
```

**Step 2: Run test to verify it fails**

Run: `just test-quick -- tests/test_uc_attrs.py::test_create_user_with_sip_attrs_integration -v`

Expected: FAIL with `TypeError: create_user() got an unexpected keyword argument 'uc_attrs'`

**Step 3: Modify create_user to accept optional UC attributes**

In `src/backend/ldap_client.py`, update the `create_user` function signature and body:

```python
def create_user(uid: str, display_name: str, mail: str, mobile: str, org_dn: str, password: str,
                 title: str = "", employee_number: str = "", manager_dn: str = "",
                 uc_attrs: dict[str, str] | None = None,
                 uc_object_classes: list[str] | None = None) -> Dict[str, Any]:
    """Create an inetOrgPerson in LDAP under the mirrored people OU.

    - title, employeeNumber, manager are standard inetOrgPerson attrs (optional)
    - uc_attrs: extra UC attributes (posixAccount, AsteriskPjsip*) to merge
    - uc_object_classes: extra objectClasses for UC (merged with inetOrgPerson chain)
    - Returns status: "created" | "exists"
    """
    def _op():
        conn = get_conn()
        ensure_ou(conn, OU_PEOPLE)
        people_dn = _ensure_people_ou_for_org(conn, org_dn)
        user_dn = f"uid={dn_escape_ou(uid)},{people_dn}"
        if entry_exists(conn, user_dn):
            conn.unbind()
            return {"dn": user_dn, "uid": uid, "status": "exists"}

        # Minimal inetOrgPerson attributes
        sn = display_name.split(" ")[-1] if display_name else uid
        given = display_name.split(" ")[0] if display_name else uid
        attrs = {
            "uid": uid,
            "cn": display_name or uid,
            "sn": sn,
            "givenName": given,
            "userPassword": ssha_password(password),
        }
        # Only set optional attrs when non-empty (LDAP rejects empty strings)
        if mail:
            attrs["mail"] = mail
        if mobile:
            attrs["mobile"] = mobile
        if title:
            attrs["title"] = title
        if employee_number:
            attrs["employeeNumber"] = employee_number
        if manager_dn:
            attrs["manager"] = manager_dn

        # Merge UC attributes (SIP/XMPP)
        if uc_attrs:
            attrs.update(uc_attrs)

        object_classes = ["top", "person", "organizationalPerson", "inetOrgPerson"]
        if uc_object_classes:
            object_classes.extend(uc_object_classes)

        conn.add(user_dn, object_classes, attrs)
        if conn.result.get("description") != "success":
            raise RuntimeError(f"LDAP user create failed: {conn.result}")
        conn.unbind()
        return {"dn": user_dn, "uid": uid, "status": "created"}
    return safe_ldap(_op)
```

**Step 4: Run test to verify it passes**

Run: `just test-quick -- tests/test_uc_attrs.py -v`

Expected: All tests PASS.

**Step 5: Commit**

```bash
git add src/backend/ldap_client.py tests/test_uc_attrs.py
git commit -m "feat: create_user accepts UC attrs — single atomic LDAP ADD with SIP/XMPP"
```

---

## Phase 2: Refactor Provisioning Flow

### Task 4: Refactor provisioning.py — remove UED payload, keep allocation

**Files:**
- Modify: `src/backend/provisioning.py` (full rewrite — 124 lines → ~80 lines)

**Step 1: Write test for refactored provisioning**

Add to `tests/test_uc_attrs.py`:

```python
def test_allocate_uc_resources_sip_profile(admin_token):
    """Allocate UID + extension + SIP password for a SIP-enabled profile."""
    from provisioning import allocate_uc_resources
    # This test uses the real ORGDB — needs a profile with UID range configured
    # Tested indirectly through the full provisioning integration test (Task 7)
    pass  # Placeholder — full integration tested in Task 7
```

**Step 2: Rewrite provisioning.py**

```python
"""UC resource allocation for single-LDAP provisioning.

- Allocates POSIX uidNumber from profile counter (all UC schemas)
- Allocates SIP extension from profile counter (when sip_enabled)
- Generates SIP password (when sip_enabled)
- Returns ProvisioningResult for API response + LDAP write
"""

import logging
import secrets
import string
from dataclasses import dataclass

logger = logging.getLogger(__name__)

_SIP_PW_ALPHABET = string.ascii_letters + string.digits + "!@#%^&*-_=+"
_SIP_PW_LENGTH = 24


def generate_sip_password() -> str:
    """Generate a cryptographically random SIP password."""
    return "".join(secrets.choice(_SIP_PW_ALPHABET) for _ in range(_SIP_PW_LENGTH))


@dataclass
class ProvisioningResult:
    """Allocated UC resources for API response."""
    uid_number: int
    extension: int | None = None
    sip_password: str | None = None


def allocate_uc_resources(
    orgdb,
    profile_id: str,
    xmpp_enabled: bool,
    sip_enabled: bool,
) -> ProvisioningResult | None:
    """Allocate UC resources (UID number, extension, SIP password) from profile counters.

    - Called when xmpp_enabled or sip_enabled is true on the profile
    - Returns ProvisioningResult with allocated values, or None if neither is enabled
    """
    if not xmpp_enabled and not sip_enabled:
        return None

    uid_number = orgdb.allocate_uid_number(profile_id)

    extension = None
    sip_password = None
    if sip_enabled:
        extension = orgdb.allocate_extension(profile_id)
        sip_password = generate_sip_password()

    logger.info(
        "Allocated UC resources for profile %s: uid_number=%d extension=%s",
        profile_id, uid_number, extension,
    )

    return ProvisioningResult(
        uid_number=uid_number,
        extension=extension,
        sip_password=sip_password,
    )
```

**Step 3: Run all tests to verify nothing is broken yet**

Run: `just test-quick -- tests/test_uc_attrs.py -v`

Expected: PASS (provisioning.py is not yet called from main.py with new signature).

**Step 4: Commit**

```bash
git add src/backend/provisioning.py
git commit -m "refactor: provisioning.py — remove UED payload, keep allocation logic"
```

---

### Task 5: Refactor main.py — user creation with direct LDAP write

**Files:**
- Modify: `src/backend/main.py` (lines 1-26, 75-93, 147-169, 1347-1406)

**Step 1: Update imports (line 25-26)**

Replace:
```python
from ued_crypto import encrypt_value, encrypt_payload_password
from provisioning import enrich_sync_payload
```

With:
```python
from provisioning import allocate_uc_resources
from ldap_client import build_uc_attrs
```

**Step 2: Simplify lifespan (lines 75-93)**

Replace the entire lifespan with:
```python
@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    """Application lifespan manager."""
    yield
```

**Step 3: Remove emit_sync_event function (lines 147-169)**

Delete the entire `emit_sync_event` function and its comment header.

**Step 4: Refactor user creation endpoint (lines 1365-1401)**

Replace the provisioning block (after lifecycle event recording) with:

```python
        if req.profileId:
            try:
                profile = ORGDB.get_config_template(req.profileId)
                if profile:
                    xmpp_on = profile.get("xmpp_enabled", False)
                    sip_on = profile.get("sip_enabled", False)
                    if xmpp_on or sip_on:
                        prov = allocate_uc_resources(ORGDB, req.profileId, xmpp_on, sip_on)
                        if prov:
                            uc_attrs, uc_ocs = build_uc_attrs(
                                xmpp_enabled=xmpp_on,
                                sip_enabled=sip_on,
                                uid_number=prov.uid_number,
                                extension=prov.extension,
                                sip_password=prov.sip_password,
                                username=req.uid,
                            )
                            # Add UC attrs to existing LDAP entry via modify
                            if uc_attrs:
                                from ldap_client import add_uc_attrs_to_user
                                add_uc_attrs_to_user(res["dn"], uc_attrs, uc_ocs)
                            provisioning_info = {
                                "xmpp_enabled": xmpp_on,
                                "sip_enabled": sip_on,
                                "uidNumber": prov.uid_number,
                                "extension": prov.extension,
                                "sipPassword": prov.sip_password,
                                "xmpp_domain": profile.get("xmpp_domain", ""),
                                "sip_domain": profile.get("sip_domain", ""),
                            }
            except Exception as e:
                logger.error("UC provisioning failed for %s: %s", req.uid, e)
```

> **Note:** We use a two-step approach here (create identity first, then modify to add UC) because `create_user` is called before we know if UC enrichment succeeds. This keeps identity creation non-blocking. Alternatively, we could pass UC attrs into `create_user` — decide at implementation time which is cleaner.

**Step 5: Remove all remaining emit_sync_event calls**

- Line 1329 (user update): Remove the `emit_sync_event` call entirely. User attribute updates on identity fields (cn, mail) don't need UC sync anymore since it's the same LDAP entry — the XMPP/SIP server sees the same entry.
- Line 1421 (password reset): Replace `emit_sync_event` with direct LDAP modify of `userPassword` (already done by `reset_user_password` — the single LDAP entry means the XMPP bind password is automatically updated).
- Line 1510 (termination): Remove `emit_sync_event`. User termination already disables the LDAP entry which prevents both AD login and XMPP/SIP bind.
- Lines 1547, 1570 (suspend/unsuspend): Remove `emit_sync_event`. Same logic — LDAP account disable/enable affects all services.

**Step 6: Remove UED Sync Admin API endpoints (lines 3290-3371)**

Delete the entire section:
- `POST /api/config-templates/{template_id}/discover`
- `GET /api/ued/sync-events`
- `POST /api/ued/sync-events/{event_id}/retry`
- `POST /api/ued/sync-events/retry-all-failed`

**Step 7: Update _resolve_service_endpoints (lines 172-194)**

Replace the function to read from new profile fields:

```python
def _resolve_service_endpoints(org_dn: str) -> dict[str, str]:
    """Resolve XMPP/SIP service endpoints for an org via profile.

    - Returns dict with keys: xmpp_domain, xmpp_ws_url, sip_domain, sip_wss_url
    - Falls back to UCCHAT_* env vars if no profile assigned or no endpoints configured
    """
    template = ORGDB.resolve_template_for_org(org_dn)
    if template:
        xmpp_domain = template.get("xmpp_domain", "")
        sip_domain = template.get("sip_domain", "")
        if xmpp_domain or sip_domain:
            return {
                "xmpp_domain": xmpp_domain,
                "xmpp_ws_url": template.get("xmpp_ws_url", ""),
                "sip_domain": sip_domain,
                "sip_wss_url": template.get("sip_wss_url", ""),
            }
    # Fallback to env vars
    return {
        "xmpp_domain": UCCHAT_XMPP_DOMAIN,
        "xmpp_ws_url": UCCHAT_XMPP_WS_URL,
        "sip_domain": UCCHAT_SIP_DOMAIN,
        "sip_wss_url": UCCHAT_SIP_WSS_URL,
    }
```

**Step 8: Add add_uc_attrs_to_user to ldap_client.py**

Add a function to modify an existing entry to add UC attributes:

```python
def add_uc_attrs_to_user(user_dn: str, uc_attrs: dict[str, str], uc_object_classes: list[str]) -> None:
    """Add UC objectClasses and attributes to an existing LDAP entry.

    - Used after create_user when UC provisioning is profile-linked
    - Modifies entry in-place via LDAP modify (add objectClass + attrs)
    """
    def _op():
        conn = get_conn()
        from ldap3 import MODIFY_ADD
        changes = {}
        changes["objectClass"] = [(MODIFY_ADD, uc_object_classes)]
        for k, v in uc_attrs.items():
            changes[k] = [(MODIFY_ADD, [v])]
        conn.modify(user_dn, changes)
        if conn.result.get("description") != "success":
            raise RuntimeError(f"LDAP UC attr add failed: {conn.result}")
        conn.unbind()
    safe_ldap(_op)
```

**Step 9: Run tests**

Run: `just test-quick -v`

Expected: Existing tests that called UED endpoints will fail (removed). UC tests should pass.

**Step 10: Commit**

```bash
git add src/backend/main.py src/backend/ldap_client.py
git commit -m "feat: direct LDAP UC provisioning — remove emit_sync_event, UED endpoints"
```

---

## Phase 3: Backend Cleanup

### Task 6: Update orgdb.py — remove sync_events operations

**Files:**
- Modify: `src/backend/orgdb.py`

**Step 1: Remove sync_events table definition and all sync_events methods**

In `orgdb.py`:
- Remove the `sync_events` table definition (~line 277-299)
- Remove these methods:
  - `insert_sync_event()`
  - `get_sync_event()`
  - `list_pending_sync_events()`
  - `mark_sync_event_in_progress()`
  - `mark_sync_event_completed()`
  - `mark_sync_event_retry()`
  - `list_sync_events()`
  - `prune_completed_sync_events()`
  - `update_profile_last_sync()`
  - `update_profile_last_error()`

**Step 2: Update config_templates column definitions**

In the config_templates table definition:
- Remove: `ued_api_url`, `ued_api_key_enc`, `ued_enabled`, `discovered_schema_name`, `discovered_at`, `discovered_capabilities`, `discovered_service_endpoints`, `last_sync_at`, `last_error`
- Add: `xmpp_enabled BOOLEAN DEFAULT false`, `sip_enabled BOOLEAN DEFAULT false`, `xmpp_domain TEXT`, `xmpp_ws_url TEXT`, `sip_domain TEXT`, `sip_wss_url TEXT`

**Step 3: Update any config_templates CRUD methods that reference removed columns**

Search for `ued_api_url`, `ued_enabled`, `discovered_`, `last_sync`, `last_error` in orgdb.py and update/remove.

**Step 4: Run tests**

Run: `just test-quick -v`

Expected: Tests that reference sync_events or UED fields will fail.

**Step 5: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "refactor: orgdb — remove sync_events table and UED profile fields"
```

---

### Task 7: Update config.py — remove UED encryption key

**Files:**
- Modify: `src/backend/config.py` (lines 92-98)

**Step 1: Remove UED section**

Remove:
```python
# ----------------------------
# UED Sync Integration (optional)
# ----------------------------
UED_ENCRYPTION_KEY = os.getenv("UED_ENCRYPTION_KEY", "")
```

Add SIP_AUTH_REALM if not already accessible:
```python
# ----------------------------
# SIP Auth (for Asterisk PJSIP digest auth)
# ----------------------------
SIP_AUTH_REALM = os.getenv("SIP_AUTH_REALM", "asterisk")
```

**Step 2: Update test_breakglass.py mock config**

Remove `UED_ENCRYPTION_KEY` from the mock `_config` dict and add `SIP_AUTH_REALM`.

**Step 3: Run tests**

Run: `just test-quick -- tests/test_breakglass.py -v`

Expected: PASS.

**Step 4: Commit**

```bash
git add src/backend/config.py tests/test_breakglass.py
git commit -m "refactor: config.py — remove UED_ENCRYPTION_KEY, add SIP_AUTH_REALM"
```

---

### Task 8: Delete UED backend client files

**Files:**
- Delete: `src/backend/sync_worker.py`
- Delete: `src/backend/ued_sync_client.py`
- Delete: `src/backend/ued_discovery.py`
- Delete: `src/backend/ued_crypto.py`

**Step 1: Verify no remaining imports**

Run: `grep -r "from sync_worker\|from ued_sync_client\|from ued_discovery\|from ued_crypto\|import sync_worker\|import ued_sync_client\|import ued_discovery\|import ued_crypto" src/backend/`

Expected: No matches (all imports were removed in Task 5).

**Step 2: Delete files**

```bash
rm src/backend/sync_worker.py src/backend/ued_sync_client.py src/backend/ued_discovery.py src/backend/ued_crypto.py
```

**Step 3: Run tests**

Run: `just test-quick -v`

Expected: PASS (no code references these files anymore).

**Step 4: Commit**

```bash
git add -A
git commit -m "chore: delete UED client files (sync_worker, ued_sync_client, ued_discovery, ued_crypto)"
```

---

### Task 9: Delete UED-specific test files

**Files:**
- Delete: `tests/test_sync_worker.py` (if exists)
- Delete: `tests/test_ued_api.py` (if exists)
- Delete: `tests/test_ued_orgdb.py` (if exists)
- Delete: `tests/test_ued_sync_client.py` (if exists)
- Delete: `tests/test_ued_discovery.py` (if exists)
- Delete: `tests/test_ued_crypto.py` (if exists)

**Step 1: Find and delete UED test files**

```bash
ls tests/test_ued_* tests/test_sync_worker* 2>/dev/null
# Delete what exists
rm -f tests/test_ued_*.py tests/test_sync_worker*.py
```

**Step 2: Run full test suite**

Run: `just test-quick -v`

Expected: Full suite PASS.

**Step 3: Commit**

```bash
git add -A
git commit -m "chore: delete UED-specific test files"
```

---

## Phase 4: Docker & Deploy Cleanup

### Task 10: Remove ued-sync from Docker Compose

**Files:**
- Modify: `deploy/dev/docker-compose.yml` — remove `ued-sync` service block
- Delete: `deploy/dev/Dockerfile.ued-sync`
- Modify: `deploy/dev/.env.example` — remove UED env vars

**Step 1: Remove ued-sync service from docker-compose.yml**

Remove the entire `ued-sync:` service block. Also remove `UED_ENCRYPTION_KEY` from the `directory-api` service environment.

**Step 2: Delete Dockerfile.ued-sync**

```bash
rm deploy/dev/Dockerfile.ued-sync
```

**Step 3: Update .env.example**

Remove all `UED_*` env vars. Add:
```bash
# SIP auth realm (for Asterisk PJSIP digest)
SIP_AUTH_REALM=asterisk
```

**Step 4: Verify stack starts cleanly**

Run: `just down && just up-bg`

Wait for containers, then: `just ps`

Expected: No `azblink-ued-sync` container. API healthy.

**Step 5: Run tests against clean stack**

Run: `just test`

Expected: PASS.

**Step 6: Commit**

```bash
git add deploy/dev/docker-compose.yml deploy/dev/.env.example
git add -A  # picks up Dockerfile.ued-sync deletion
git commit -m "chore: remove ued-sync from Docker Compose and deploy config"
```

---

### Task 11: Update Justfile — remove UED recipes

**Files:**
- Modify: `Justfile`

**Step 1: Remove UED-related recipes**

Remove:
- `ued-logs`
- `ued-restart`
- `ued-rebuild`
- `ued-test`
- `ued-test-integration`
- `ued-test-cov`

Remove `azblink-ued-sync` from `stats` recipe container list.
Update `test-all` to remove `ued-test` dependency.

**Step 2: Verify**

Run: `just --list`

Expected: No `ued-*` recipes.

**Step 3: Commit**

```bash
git add Justfile
git commit -m "chore: remove UED recipes from Justfile"
```

---

## Phase 5: Archive UED Sync & Update Tests

### Task 12: Archive src/ued-sync/ to branch

**Step 1: Create archive branch**

```bash
git checkout -b archive/ued-sync-v1
git checkout main
```

**Step 2: Remove src/ued-sync/ from main**

```bash
rm -rf src/ued-sync/
```

**Step 3: Update any remaining references**

Search for `ued-sync` or `ued_sync` across the codebase and remove/update.

**Step 4: Commit**

```bash
git add -A
git commit -m "chore: archive ued-sync to branch, remove from main"
```

---

### Task 13: Update existing integration tests

**Files:**
- Modify: `tests/test_config_templates.py` — remove UED config/discovery tests, add xmpp_enabled/sip_enabled tests
- Modify: `tests/test_provisioning.py` — update for new `allocate_uc_resources` API
- Modify: `tests/test_provisioning_ops.py` — remove sync_events tests
- Modify: `tests/conftest.py` — remove UED fixtures if any

**Step 1: Update test_config_templates.py**

Remove tests for:
- `POST /api/config-templates/{id}/discover`
- UED API URL/key validation
- Discovery cache fields

Add tests for:
- `xmpp_enabled` / `sip_enabled` toggle
- `xmpp_domain` / `sip_domain` endpoint fields

**Step 2: Update test_provisioning.py**

Replace `enrich_sync_payload` tests with `allocate_uc_resources` tests.

**Step 3: Remove sync_events tests from test_provisioning_ops.py**

Remove any tests that reference `sync_events`, `retry-all-failed`, etc.

**Step 4: Run full suite**

Run: `just test`

Expected: PASS.

**Step 5: Commit**

```bash
git add tests/
git commit -m "test: update integration tests for single-LDAP architecture"
```

---

## Phase 6: Frontend Updates

### Task 14: Update TypeScript types

**Files:**
- Modify: `src/frontend/src/types/org-profiles.ts`

**Step 1: Update ProfileListItem and ProfileDetail types**

Remove UED fields from both interfaces:
- `uedApiUrl`, `uedEnabled`, `uedApiKeyEnc`
- `discoveredSchemaName`, `discoveredAt`, `discoveredCapabilities`, `discoveredServiceEndpoints`
- `lastSyncAt`, `lastError`

Add to both interfaces:
- `xmppEnabled: boolean`
- `sipEnabled: boolean`
- `xmppDomain?: string`
- `xmppWsUrl?: string`
- `sipDomain?: string`
- `sipWssUrl?: string`

**Step 2: Delete ConfigTemplateDiscoverResponse type**

Remove the entire `ConfigTemplateDiscoverResponse` interface (~lines 155-160) — no discovery endpoint exists.

**Step 3: Update Create/Update payload types**

In `ConfigTemplateCreatePayload` and `ConfigTemplateUpdatePayload`:
- Remove `uedApiUrl`, `uedApiKey`, `uedEnabled`
- Add `xmppEnabled`, `sipEnabled`, `xmppDomain`, `xmppWsUrl`, `sipDomain`, `sipWssUrl`
- Keep UID/extension range fields (still needed)

**Step 4: Commit**

```bash
git add src/frontend/src/types/
git commit -m "feat(frontend): update profile types for single-LDAP"
```

---

### Task 15: Update profile config UI + card + section config

**Files:**
- Modify: `src/frontend/src/components/features/org-profiles/ConfigTab.tsx`
- Modify: `src/frontend/src/components/features/org-profiles/ProfileCard.tsx`
- Modify: `src/frontend/src/components/features/org-profiles/profile-type-config.ts`
- Modify: `src/frontend/src/lib/queries/org-profiles-mutations.ts`

**Step 1: Replace UED config sections in ConfigTab**

ConfigTab has TWO UED-related sections to update:

a) **Service Capabilities section (~lines 20-44):**
- Remove `profile.discoveredCapabilities` → use new field derived from `xmppEnabled`/`sipEnabled`
- Change `profile.discoveredServiceEndpoints.xmpp_domain` → `profile.xmppDomain`
- Same for `xmppWsUrl`, `sipDomain`, `sipWssUrl`

b) **UED Provisioning section (~lines 84-106):**
- Rename to "UC Provisioning"
- Remove conditional on `profile.uedApiUrl` — show when `xmppEnabled || sipEnabled`
- Remove rows: "API URL", "Enabled", "Discovered At", "Last Sync", "Last Error"
- Keep rows: "Schema" (now static `pjsip-combined`), UID/extension ranges
- Add: XMPP/SIP enable toggles, service endpoint inputs

**Step 2: Update ProfileCard.tsx (~line 24)**

Change `profile.discoveredCapabilities` → derive from profile flags:
```tsx
const caps: string[] = [];
if (profile.xmppEnabled) caps.push('xmpp');
if (profile.sipEnabled) caps.push('sip');
```

**Step 3: Update profile-type-config.ts (~line 59)**

Rename section key and label:
- `ued:` → `uc:`
- `'UED Provisioning'` → `'UC Provisioning'`

**Step 4: Update mutations**

Remove `useDiscoverProfile` hook from `org-profiles-mutations.ts`. Update profile save mutation for new fields.

**Step 5: Verify in browser**

Open profile editor and profile list, confirm new fields render and UED references are gone.

**Step 6: Commit**

```bash
git add src/frontend/src/components/features/org-profiles/
git add src/frontend/src/lib/queries/
git commit -m "feat(frontend): profile editor — XMPP/SIP toggles replace UED config"
```

---

### Task 16: Remove sync events UI

**Files:**
- Modify: `src/frontend/src/components/features/provisioning-ops/ProvisioningOpsPage.tsx` — remove sync events table
- Remove sync event related API queries from `src/frontend/src/lib/queries/`

**Step 1: Remove sync events table and retry actions**

Remove the sync events section from the provisioning ops page. If the entire page becomes empty after removal, consider what's left and whether it should remain or be removed.

**Step 2: Remove sync event query hooks**

Search for and remove any `useSyncEvents`, `useRetrySyncEvent` hooks.

**Step 3: Commit**

```bash
git add src/frontend/
git commit -m "feat(frontend): remove sync events UI"
```

---

### Task 17: Update user creation flow (onboarding wizard)

**Files:**
- Modify: `src/frontend/src/components/features/user-management/onboarding/StepProfile.tsx`
- Modify: `src/frontend/src/components/features/user-management/onboarding/StepComplete.tsx`
- Modify: `src/frontend/src/lib/queries/user-create.ts`

**Step 1: Update StepProfile.tsx — SelectedProfileDetail component (~lines 107-128)**

- Change `profile.discoveredCapabilities` → derive from `profile.xmppEnabled`/`profile.sipEnabled`:
```tsx
const caps: string[] = [];
if (profile.xmppEnabled) caps.push('xmpp');
if (profile.sipEnabled) caps.push('sip');
```
- Change `profile.discoveredSchemaName` → remove or hardcode to `'pjsip-combined'` (single schema)
- Update component prop type signature to match new profile shape
- Keep `SCHEMA_SHORT_LABELS` constant (still valid)

**Step 2: Update StepComplete.tsx provisioning result display**

The API response now includes `xmpp_enabled`, `sip_enabled`, `xmpp_domain`, `sip_domain` instead of `schemaName` + UED discovery fields. Update the completion step to display these new fields. Keep `SCHEMA_LABELS` constant (still valid for display).

**Step 3: Update user create mutation response type**

In `user-create.ts`, update `ProvisioningInfo` interface comment (remove "UED link" wording). The interface fields themselves (`schemaName`, `uidNumber`, `extension`, `sipPassword`) are still correct.

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/user-management/
git add src/frontend/src/lib/queries/
git commit -m "feat(frontend): user creation shows direct UC provisioning result"
```

---

## Phase 7: Documentation & Final Validation

### Task 18: Update CLAUDE.md

**Files:**
- Modify: `CLAUDE.md`

**Step 1: Update architecture sections**

- Replace "Two-LDAP Architecture" with "Single-LDAP Architecture"
- Remove all UED Sync references from architecture, endpoints, patterns
- Update profile field documentation
- Update provisioning flow documentation
- Remove UED-related dev commands
- Remove UED from repository structure
- Update migration list

**Step 2: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: update CLAUDE.md for single-LDAP architecture"
```

---

### Task 19: Final integration test run

**Step 1: Reset and rebuild stack**

```bash
just reset && just up-bg
```

Wait for healthy containers.

**Step 2: Run full test suite**

```bash
just test
```

Expected: All PASS. Zero UED references in test output.

**Step 3: Manual smoke test**

- Login to UI
- Create a profile with xmpp_enabled=true, sip_enabled=true
- Create a user with that profile
- Verify LDAP entry has AsteriskPjsip* attributes
- Verify provisioning result shows in UI

---

## Summary

| Phase | Tasks | What Changes |
|-------|-------|--------------|
| 1 | 1-3 | DB migration + UC attr builder + create_user extension |
| 2 | 4-5 | Refactor provisioning flow — direct LDAP write |
| 3 | 6-9 | Backend cleanup — orgdb, config, delete UED files/tests |
| 4 | 10-11 | Docker/deploy cleanup |
| 5 | 12-13 | Archive UED, update integration tests |
| 6 | 14-17 | Frontend type/UI updates |
| 7 | 18-19 | Documentation + final validation |

**Total: 19 tasks across 7 phases**

**Critical path:** Tasks 1-5 are sequential (each builds on the previous). Tasks 6-9 can be partially parallelized. Phase 4-7 can proceed once Phase 3 is complete.
