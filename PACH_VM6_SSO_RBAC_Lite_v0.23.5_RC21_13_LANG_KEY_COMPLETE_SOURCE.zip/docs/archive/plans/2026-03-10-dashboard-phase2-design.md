# Dashboard Phase 2 — Left Column Design

## Architecture

Single domain: **frontend only**. No backend changes. 5 new feature components + 1 dependency addition + 1 existing component modification.

### Component Tree (Phase 2 additions)

```
DashboardMain (MODIFY)
├── ProvisioningChartCard (NEW)
│   ├── Card + CardHeader + CardTitle + CardAction
│   ├── SegmentedControl (inline, 3 buttons)
│   ├── ChartLegend (NEW)
│   └── recharts AreaChart (2 series)
└── RecentQRCard (NEW)
    ├── Card + CardHeader + CardTitle + CardAction
    └── QRTable (NEW)
        └── QRTableRow × 5 (NEW)
            ├── Avatar (@azblink/ui)
            ├── StatusBadge (@azblink/ui)
            └── mono timestamp
```

### Data Flow

All data is **hardcoded mock** in Phase 2. Types already exist in `types/dashboard.ts`:
- `ChartDataPoint` — `{ day: string, generated: number, consumed: number }`
- `ChartPeriod` — `'24h' | '7d' | '30d'`
- `QRCodeRow` — `{ id, user: UserRef, status, device, time, issuedAt }`
- `UserRef` — `{ name, initials, gradient: [string, string] }`
- `DashboardQRStatus` — `'consumed' | 'pending' | 'expired'`

### Design Decisions

| Decision | Rationale |
|----------|-----------|
| Period toggle as inline buttons, not a primitive | Only used in this one card; too specific for @azblink/ui |
| ChartLegend as separate component | Reusable across chart types in future phases |
| QRTable uses CSS Grid (div), not DataTable | Matches HTML spec; only 5 static rows, no sort/paginate |
| recharts v3 (latest) | React 19 compatible, stable API |
| CardAction for "View All" link | Uses existing Card compound component slot |

### File Map

| File | Action | Purpose |
|------|--------|---------|
| `package.json` | MODIFY | Add `recharts` dependency |
| `ProvisioningChartCard.tsx` | CREATE | Chart card with period toggle + recharts AreaChart |
| `ChartLegend.tsx` | CREATE | Legend dots + labels (Generated/Consumed) |
| `RecentQRCard.tsx` | CREATE | QR table card with "View All" header action |
| `QRTable.tsx` | CREATE | CSS Grid table container + header |
| `QRTableRow.tsx` | CREATE | Single row: Avatar + name, StatusBadge, device, time |
| `DashboardMain.tsx` | MODIFY | Replace placeholders with real components |
