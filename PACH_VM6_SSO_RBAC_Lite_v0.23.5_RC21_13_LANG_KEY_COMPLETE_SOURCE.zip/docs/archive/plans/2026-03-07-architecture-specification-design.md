# Architecture Specification Design

**Date:** 2026-03-07
**Status:** Approved
**Scope:** Create a comprehensive architecture specification as the single source of truth for the AZBlink Directory platform, with versioned ARD (Architecture Record of Decision) tracking.

## Problem Statement

Architecture knowledge is currently scattered across:
- `specs/v2.0/Directory_Portal_Specification_v4.1.md` (product/API spec — target state)
- `docs/plans/` (implementation design docs — per-feature, not holistic)
- `docs/knowledge/patterns/` (integration patterns — narrow scope)
- `CLAUDE.md` (agent quick-reference — operational, not comprehensive)

No formal ADR/ARD system exists. Decisions are tracked informally in design docs, commit messages, and CLAUDE.md. No versioning SOP governs how architecture documentation evolves.

## Design Decisions

### Audience: AI agents + humans
- Structured sections with clear headings and metadata for machine parsing
- Readable prose for human context
- Each section self-contained with cross-references

### Scope: As-built + target gaps
- Documents current implemented state as baseline
- `[AS-BUILT]` and `[TARGET v2.0]` markers distinguish implemented from planned
- References `V1_TO_V2_GAP_ANALYSIS.md` for detailed gap tracking

### Relationship to existing docs: Coexist
- New `docs/architecture/` is the architecture-focused specification
- `specs/v2.0/` remains as the product/API specification
- No duplication — architecture spec references v2.0 spec for API details
- CLAUDE.md stays as operational quick-reference, slimmed to avoid duplication

## Directory Structure

```
docs/architecture/
├── README.md                         # Index, version badge, navigation, how-to-read guide
├── CHANGELOG.md                      # Semver history of spec changes
├── SOP.md                            # Versioning rules, ARD process, update triggers
├── spec/
│   ├── 01-system-overview.md         # Mission, scope, actors, design invariants, tech stack
│   ├── 02-component-architecture.md  # Backend, Frontend, LDAP, PostgreSQL, Authentik
│   ├── 03-data-architecture.md       # LDAP schema, DB schema, data ownership, entity relationships
│   ├── 04-authentication.md          # Dual auth planes, OIDC flow, dev bypass, token lifecycle
│   ├── 05-provisioning.md            # Profile-linked provisioning, QR flow, UC resource allocation
│   ├── 06-deployment.md              # Docker Compose topology, service map, networking, dev stack
│   ├── 07-security.md                # Rate limiting, QR signing, audit trails, hardening checklist
│   └── 08-integration-points.md      # Authentik Admin API, LDAP bind, external service contracts
├── decisions/
│   ├── _TEMPLATE.md                  # ARD template (copy for new decisions)
│   ├── ARD-001-single-ldap-architecture.md
│   ├── ARD-002-authentik-only-auth.md
│   └── ARD-003-authentik-dev-stack.md
└── diagrams/                         # (future) Mermaid source files for complex visuals
```

## SOP (Standard Operating Procedure)

### Versioning: Semantic Versioning (SemVer)

| Component | Trigger | Example |
|-----------|---------|---------|
| **MAJOR** (X.0.0) | Breaking architectural change — new auth model, LDAP restructure, component removal | 1.0.0 → 2.0.0 |
| **MINOR** (0.X.0) | New capability without breaking existing architecture | 1.0.0 → 1.1.0 |
| **PATCH** (0.0.X) | Clarification, typo fix, diagram update | 1.1.0 → 1.1.1 |

### Update Triggers

The spec MUST be updated when:
1. Any PR changes system architecture (new service, removed component, changed data flow)
2. Any new ARD is created
3. Any existing ARD status changes (e.g., `accepted` → `superseded`)
4. CLAUDE.md architecture section changes (spec and CLAUDE.md must stay in sync)

### CHANGELOG Format

```markdown
## [1.1.0] - 2026-03-07
### Added
- ARD-003: Authentik dev stack for local OIDC testing
### Changed
- 06-deployment.md: Added Authentik services to Docker Compose topology
### References
- PR #14, ARD-003
```

## ARD Template

```markdown
# ARD-NNN: Title

| Field | Value |
|-------|-------|
| **Status** | `proposed` / `accepted` / `superseded` / `deprecated` |
| **Date** | YYYY-MM-DD |
| **Supersedes** | ARD-XXX (if replacing a previous decision) |
| **Superseded by** | ARD-YYY (if this decision was later replaced) |
| **PR** | #NN |
| **Spec sections affected** | 02-component-architecture, 04-authentication, ... |

## Context
Why did this decision need to be made?

## Decision
What was decided?

## Alternatives Considered
What other options were evaluated?

## Consequences
- **Positive:** ...
- **Negative / trade-offs:** ...
- **Risks:** ...

## References
- Links to design docs, PRDs, specs
```

### ARD Lifecycle

`proposed` → `accepted` → (optionally) `superseded` or `deprecated`

## Spec Section Outlines

### 01 — System Overview (~2K tokens)
- Mission statement and product scope
- Actor model (IT Admin, End User, UC Client, AI Agent)
- Design invariants (6 critical rules from PRDs)
- Technology stack summary
- Relationship to other spec documents

### 02 — Component Architecture (~3K tokens)
- Component inventory with ownership and responsibility
- Backend: FastAPI app structure
- Frontend: Two-layer architecture (primitives ↔ features)
- Infrastructure: OpenLDAP, PostgreSQL, Authentik, Docker
- Component dependency graph (Mermaid)

### 03 — Data Architecture (~3K tokens)
- LDAP entry structure (single DN with identity + UC)
- PostgreSQL schema (config_templates, audit tables)
- Data ownership rules
- Entity relationship diagram (Mermaid)
- Schema versioning (migrations)

### 04 — Authentication (~2.5K tokens)
- Dual auth planes: Plane A (UC/LDAP) and Plane B (OIDC)
- OIDC flow with multi-issuer handling
- Dev bypass mechanism
- Token lifecycle and session revocation
- Graceful degradation

### 05 — Provisioning (~2.5K tokens)
- Profile = Connector pattern
- User creation flow (inetOrgPerson → MODIFY_ADD UC)
- UC resource allocation
- QR code assembly and signing
- QR preview links

### 06 — Deployment (~2K tokens)
- Docker Compose service topology
- Port mappings and networking
- Dev environment setup
- Authentik seed script
- Hot reload rules

### 07 — Security (~2K tokens)
- Rate limiting
- QR signing and verification
- Audit trail tables
- Hardening checklist
- Known security boundaries

### 08 — Integration Points (~2K tokens)
- Authentik Admin API v3
- LDAP bind contract
- External service contracts (XMPP, SIP)
- API contract summary

## CLAUDE.md Update Plan

After spec is written:
1. Add reference to `docs/architecture/` as canonical architecture specification
2. Slim architecture section — keep quick-reference, remove detailed schemas/flows
3. Add ARD process reference for AI agents
4. Add spec version note

### What stays in CLAUDE.md (operational quick-ref)
- Design invariants (6 rules)
- Component file list (for code navigation)
- Hot reload rules
- Authentik API gotchas

### What moves to docs/architecture/ (full detail)
- LDAP schema details → 03-data-architecture
- Auth flow details → 04-authentication
- Provisioning flow details → 05-provisioning

## Initial ARDs (Retroactive)

| ARD | Title | Status | Date | Source |
|-----|-------|--------|------|--------|
| ARD-001 | Single-LDAP Architecture | `accepted` | 2026-03-02 | docs/plans/2026-03-02-single-ldap-architecture-design.md |
| ARD-002 | Authentik-Only OIDC Authentication | `accepted` | 2026-03-04 | docs/plans/2026-03-04-authentik-only-auth-design.md |
| ARD-003 | Authentik Dev Stack | `accepted` | 2026-03-04 | docs/plans/2026-03-04-authentik-dev-stack-design.md |

## Execution Approach

Spawn an agent team with parallel ownership:
- Agent 1: README.md, CHANGELOG.md, SOP.md
- Agent 2: 01-system-overview, 02-component-architecture
- Agent 3: 03-data-architecture, 04-authentication
- Agent 4: 05-provisioning, 06-deployment
- Agent 5: 07-security, 08-integration-points
- Agent 6: ARD template + 3 retroactive ARDs
- Agent 7: CLAUDE.md update

Estimated total output: ~19K tokens across spec sections + ~3K for ARDs + ~2K for meta files.
