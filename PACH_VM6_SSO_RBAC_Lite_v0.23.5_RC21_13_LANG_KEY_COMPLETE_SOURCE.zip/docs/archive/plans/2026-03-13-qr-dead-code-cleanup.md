# QR Dead Code Cleanup — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Remove 6 dead code items and fix 3 DRY/naming violations in the QR provisioning subsystem (Epic #66, issues #67–#75).

**Architecture:** Three waves ordered by risk and dependency. Wave 1 is pure deletion (zero risk). Wave 2 is surgical edits (low risk, type changes). Wave 3 is backend renames requiring grep-verify-rename cycles across call sites.

**Tech Stack:** TypeScript/React (frontend), Python/FastAPI (backend), PostgreSQL (DB)

**Test commands:**
- Frontend: `just ui-build` (type-checks + builds)
- Backend: `just test-quick` (assumes stack is up)
- Full: `just test`

---

## Wave 1: Safe Deletions (Issues #67, #72)

Zero-dependency file removals. No other code imports these. Commit after each.

---

### Task 1: Delete QRHistory.tsx (#67)

**Files:**
- Delete: `src/frontend/src/components/features/user-management/QRHistory.tsx`

**Step 1: Verify zero imports**

Run: `rg "QRHistory" src/frontend/src/ --type ts --type tsx`
Expected: Only hits inside `QRHistory.tsx` itself (the file we're deleting)

**Step 2: Delete the file**

```bash
rm src/frontend/src/components/features/user-management/QRHistory.tsx
```

**Step 3: Verify frontend builds**

Run: `just ui-build`
Expected: PASS — no import references to break

**Step 4: Commit**

```bash
git add -u src/frontend/src/components/features/user-management/QRHistory.tsx
git commit -m "fix(frontend): remove deprecated QRHistory.tsx component (#67)"
```

---

### Task 2: Delete qr-generator.tsx redirect route (#72)

**Files:**
- Delete: `src/frontend/src/routes/provisioning/qr-generator.tsx`
- Regenerate: `src/frontend/src/routeTree.gen.ts` (auto)

**Step 1: Verify no links to /provisioning/qr-generator**

Run: `rg "qr-generator" src/frontend/src/ --type ts --type tsx`
Expected: Only hits inside the route file itself

**Step 2: Delete the file**

```bash
rm src/frontend/src/routes/provisioning/qr-generator.tsx
```

**Step 3: Regenerate route tree**

Run: `just ui-routes`
Expected: Route tree regenerated without qr-generator entry

**Step 4: Verify frontend builds**

Run: `just ui-build`
Expected: PASS

**Step 5: Commit**

```bash
git add src/frontend/src/routes/provisioning/qr-generator.tsx src/frontend/src/routeTree.gen.ts
git commit -m "fix(frontend): remove legacy qr-generator redirect route (#72)"
```

---

## Wave 2: Surgical Frontend Edits (Issues #68, #69, #70, #73)

Type-safe edits — TypeScript compiler catches any mistakes. One commit per issue.

---

### Task 3: Fix PendingProvisionsCard phantom endpoints (#68, #69)

Both phantom mutations live in the same file. Fix together, reference both issues.

**Files:**
- Modify: `src/frontend/src/components/features/dashboard/PendingProvisionsCard.tsx`

**Context:** The card IS live — imported by `DashboardSidebar.tsx`. The "Resend" and "Generate" action buttons call `POST /qrcode/resend` and `POST /qrcode/generate` which don't exist. The backend endpoint for QR generation is `GET /api/users/{uid}/qrcode`.

**Step 1: Understand the current action flow**

The `PendingItem` component renders an action button whose `handler` comes from `bindActions()` (lines 70–84). The handler dispatches either `resendMutation` or `generateMutation` based on `item.action.label`.

**Step 2: Replace phantom mutations with the real QR generation endpoint**

Replace the two mutation definitions (lines 40–67) with a single working mutation:

```typescript
const regenerateMutation = useMutation({
  mutationFn: async (uid: string) => {
    return getApi().get<{ ok: boolean }>(`/users/${uid}/qrcode`);
  },
  onSuccess: (_data, uid) => {
    queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.pending });
    queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.stats });
    queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.recentQR(5) });
    toast.success(`QR regenerated for ${uid}`);
  },
  onError: (_error, uid) => {
    toast.error(`Failed to regenerate QR for ${uid}`);
  },
});
```

**Step 3: Update bindActions to use the single mutation**

Replace the bindActions function (lines 70–84):

```typescript
function bindActions(items: PendingProvision[]): PendingProvision[] {
  return items.map((item) => ({
    ...item,
    action: {
      ...item.action,
      handler: () => {
        regenerateMutation.mutate(item.id);
      },
    },
  }));
}
```

**Step 4: Verify frontend builds**

Run: `just ui-build`
Expected: PASS

**Step 5: Verify backend endpoint exists**

Run: `rg "api/users/.*qrcode" src/backend/main.py | head -3`
Expected: Shows `GET /api/users/{uid}/qrcode` route definition

**Step 6: Commit**

```bash
git add src/frontend/src/components/features/dashboard/PendingProvisionsCard.tsx
git commit -m "fix(frontend): replace phantom /qrcode/resend and /qrcode/generate with real endpoint (#68, #69)"
```

---

### Task 4: Add disabled state to DeliveryOptions email/SMS buttons (#70)

**Files:**
- Modify: `src/frontend/src/components/features/user-management/modals/DeliveryOptions.tsx`

**Context:** Email/SMS already show `toast.info('... coming soon')` — not a 404. The fix is visual: make them look disabled so users don't expect them to work.

**Step 1: Add a `comingSoon` prop to DeliveryButton**

Add `comingSoon?: boolean` to the DeliveryButton props. When true, render with reduced opacity and a "Coming soon" tooltip or subtitle.

Replace the Email and SMS `<DeliveryButton>` usages (lines 55–66) to add `comingSoon`:

```tsx
<DeliveryButton
  icon={<Mail className="h-4 w-4" />}
  label="Email"
  onClick={handleEmail}
  disabled={disabled}
  comingSoon
/>
<DeliveryButton
  icon={<Smartphone className="h-4 w-4" />}
  label="SMS"
  onClick={handleSMS}
  disabled={disabled}
  comingSoon
/>
```

**Step 2: Update DeliveryButton to show "Coming soon" visual state**

Add `comingSoon` to the destructured props (line 88). When `comingSoon` is true:
- Add `opacity-50` class
- Replace the label text with a stacked label + subtitle:

```tsx
{comingSoon ? (
  <>
    <span className="text-[var(--text-2xs)] font-medium">{label}</span>
    <span className="text-[9px] text-[var(--color-text-muted)]">Coming soon</span>
  </>
) : (
  <span className="text-[var(--text-2xs)] font-medium">{label}</span>
)}
```

**Step 3: Verify frontend builds**

Run: `just ui-build`
Expected: PASS

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/user-management/modals/DeliveryOptions.tsx
git commit -m "fix(frontend): add visual 'coming soon' state to email/SMS delivery buttons (#70)"
```

---

### Task 5: Deduplicate QRHistoryEntry type (#73)

**Files:**
- Modify: `src/frontend/src/components/features/provisioning-ops/LifecycleDetailPanel.tsx`
- Modify: `src/frontend/src/components/features/qr-management/QRDetailPanel.tsx`

**Context — type differences to resolve:**

| Field | Canonical (`users.ts`) | Local copies |
|-------|----------------------|--------------|
| `issued_at` | `string \| null` | `string` |
| `expires_at` | `string \| null` | `string` |
| `status` | `'consumed' \| 'expired' \| 'pending' \| 'revoked'` | `string` |
| `issued_by` | `string \| null` | missing |

The canonical type is **more strict** (nullable fields, union status). The local copies are looser. Using the canonical type is correct — the API can return nulls.

**Step 1: In LifecycleDetailPanel.tsx, remove local type and import canonical**

Remove the local `interface QRHistoryEntry` block (lines 35–42). Add import:

```typescript
import { type QRHistoryEntry } from '@/lib/queries/users';
```

Fix any type errors from the stricter type (nullable `issued_at`/`expires_at` may need optional chaining where used).

**Step 2: In QRDetailPanel.tsx, remove local type and import canonical**

Remove the local `interface QRHistoryEntry` block (lines 26–33). Add import:

```typescript
import { type QRHistoryEntry } from '@/lib/queries/users';
```

Fix any type errors from the stricter type.

**Step 3: Verify TypeScript compiles cleanly**

Run: `just ui-build`
Expected: PASS — if there are type errors, add optional chaining (`item.issued_at ?? '—'`) where needed

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/provisioning-ops/LifecycleDetailPanel.tsx \
        src/frontend/src/components/features/qr-management/QRDetailPanel.tsx
git commit -m "refactor(frontend): deduplicate QRHistoryEntry type to single canonical definition (#73)"
```

---

## Wave 3: Backend Renames and Documentation (Issues #71, #74, #75)

Backend changes with test verification. Run `just test-quick` after each.

---

### Task 6: Move verify_provisioning_payload() to test utilities (#71)

**Files:**
- Modify: `src/backend/qr_signing.py` — remove function
- Create: `tests/helpers/__init__.py` (if not exists)
- Create: `tests/helpers/qr_helpers.py` — relocated function
- Modify: `tests/test_qr_signing_unit.py` — update imports

**Step 1: Check if tests/helpers/ exists**

Run: `ls tests/helpers/ 2>/dev/null || echo "needs creation"`

**Step 2: Create test helper module with the relocated function**

Create `tests/helpers/qr_helpers.py`:

```python
"""QR signing test utilities.

Relocated from src/backend/qr_signing.py — verify_provisioning_payload()
is not used in production code (main.py does inline HMAC verification).
Kept here for test assertions.
"""

import hmac
import hashlib
import json
import time
from typing import Tuple, Dict, Any

from config import ORG_QR_SIGNING_SECRET


def verify_provisioning_payload(
    signed_payload: Dict[str, Any]
) -> Tuple[bool, str, Dict[str, Any]]:
    """Verify a signed provisioning payload (test utility only).

    - Checks signature presence, HMAC match, and expiration
    - Uses constant-time comparison for timing attack prevention

    Returns:
        (valid, error_message, payload_content)
    """
    payload_copy = dict(signed_payload)
    sig = payload_copy.pop("sig", None)

    if not sig:
        return False, "MISSING_SIGNATURE", {}

    message = json.dumps(payload_copy, sort_keys=True, separators=(',', ':'))
    expected = hmac.new(
        ORG_QR_SIGNING_SECRET.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(sig, expected):
        return False, "INVALID_SIGNATURE", {}

    now = int(time.time())
    exp = payload_copy.get("exp", 0)
    if exp <= now:
        return False, "TOKEN_EXPIRED", {}

    return True, "", payload_copy.get("payload", {})
```

**Step 3: Remove verify_provisioning_payload from qr_signing.py**

Remove lines 86–143 from `src/backend/qr_signing.py`. Also remove the references to it in the module docstring (lines 7, 13).

**Step 4: Update test imports in test_qr_signing_unit.py**

Find all `from qr_signing import ... verify_provisioning_payload` and change to:
```python
from helpers.qr_helpers import verify_provisioning_payload
```

Keep `from qr_signing import sign_provisioning_payload` unchanged.

Run: `rg "verify_provisioning_payload" tests/` to find all references.

**Step 5: Run tests**

Run: `just test-quick`
Expected: All 8 verify tests still pass, all other tests pass

**Step 6: Commit**

```bash
git add src/backend/qr_signing.py tests/helpers/ tests/test_qr_signing_unit.py
git commit -m "refactor(backend): move verify_provisioning_payload to test utilities (#71)"
```

---

### Task 7: Rename record_issue() and record_qr_issuance() (#75)

**Files:**
- Modify: `src/backend/orgdb.py` — rename both methods
- Modify: `src/backend/main.py` — update 5 call sites

**Step 1: Rename record_issue → record_org_qr_issue in orgdb.py**

Find `def record_issue(` (line 529) and rename to `def record_org_qr_issue(`.

**Step 2: Update call sites in main.py**

Run: `rg -n "ORGDB\.record_issue\b" src/backend/main.py`

Replace all 4 occurrences:
- Line 2419: `ORGDB.record_issue(` → `ORGDB.record_org_qr_issue(`
- Line 2766: `ORGDB.record_issue(` → `ORGDB.record_org_qr_issue(`
- Line 2795: `ORGDB.record_issue(` → `ORGDB.record_org_qr_issue(`
- Line 2923: `ORGDB.record_issue(` → `ORGDB.record_org_qr_issue(`

**Step 3: Rename record_qr_issuance → record_user_qr_issuance in orgdb.py**

Find `def record_qr_issuance(` (line 1655) and rename to `def record_user_qr_issuance(`.

**Step 4: Update call site in main.py**

Run: `rg -n "ORGDB\.record_qr_issuance\b" src/backend/main.py`

Replace 1 occurrence:
- Line 2295: `ORGDB.record_qr_issuance(` → `ORGDB.record_user_qr_issuance(`

**Step 5: Verify no remaining old references**

Run: `rg "record_issue\b|record_qr_issuance\b" src/backend/`
Expected: Zero matches (only the new names should appear)

**Step 6: Run tests**

Run: `just test-quick`
Expected: All pass — no tests call these methods directly

**Step 7: Commit**

```bash
git add src/backend/orgdb.py src/backend/main.py
git commit -m "refactor(backend): rename record_issue/record_qr_issuance for scope clarity (#75)"
```

---

### Task 8: Document qr_issues vs qr_issuance_audit table purposes (#74)

**Files:**
- Modify: `src/backend/orgdb.py` — add docstrings to table definitions and methods

**Step 1: Add table-level docstring to qr_issues**

Above the `qr_issues = Table(` definition (line 104), add:

```python
# qr_issues — ORG-LEVEL QR tracking
# Scope: profile_id (one row per QR issued from an OrgProfile)
# Purpose: Rotation tracking, profile-scoped bulk revocation, nonce uniqueness
# Written by: record_org_qr_issue() via rotate_qr, get_orgprofile_qrcode, sso_profile_qrcode
# Read by: revoke_org_issues() cascade during profile deletion
```

**Step 2: Add table-level docstring to qr_issuance_audit**

Above the `qr_issuance_audit = Table(` definition (line 157), add:

```python
# qr_issuance_audit — PER-USER QR audit trail
# Scope: user_uid (one row per QR generated for a specific user)
# Purpose: QR Management page, per-user history, compliance audit, dashboard stats
# Written by: record_user_qr_issuance() via /api/users/{uid}/qrcode
# Read by: list_qr_codes(), list_qr_issuance(), list_qr_issuance_for_user(), get_qr_stats()
```

**Step 3: Add method docstring clarifications**

Update `record_org_qr_issue()` docstring (already renamed in Task 7):
```python
"""Record an org-level QR issue event (qr_issues table).

Called when a QR code is generated from an OrgProfile (rotate_qr, get_orgprofile_qrcode).
NOT for per-user QR generation — use record_user_qr_issuance() for that.
"""
```

Update `record_user_qr_issuance()` docstring:
```python
"""Record a per-user QR issuance event to the audit table (qr_issuance_audit).

Called when a QR code is generated for a specific user via /api/users/{uid}/qrcode.
NOT for org-level rotation — use record_org_qr_issue() for that.
"""
```

**Step 4: Verify no code changes (documentation only)**

Run: `just test-quick`
Expected: All pass

**Step 5: Commit**

```bash
git add src/backend/orgdb.py
git commit -m "docs(backend): document qr_issues vs qr_issuance_audit table purposes (#74)"
```

---

## Execution Order & Dependencies

```
Wave 1 (no deps, parallel-safe):
  Task 1: Delete QRHistory.tsx .............. #67
  Task 2: Delete qr-generator.tsx ........... #72

Wave 2 (frontend edits, parallel-safe):
  Task 3: Fix PendingProvisionsCard ......... #68, #69
  Task 4: DeliveryOptions coming-soon ....... #70
  Task 5: Deduplicate QRHistoryEntry ........ #73

Wave 3 (backend, sequential — Task 7 before Task 8):
  Task 6: Move verify_provisioning_payload .. #71
  Task 7: Rename record methods ............. #75
  Task 8: Document table purposes ........... #74  (depends on Task 7 names)
```

**Total: 8 tasks, 8 commits, 3 waves**

Wave 1 + Wave 2 can run in parallel (frontend-only, no overlap).
Wave 3 must be sequential (Task 7 renames → Task 8 documents the new names).

---

## Verification Checklist (run after all waves)

```bash
# Full build + type check
just ui-build

# Full test suite
just test

# Verify no phantom endpoints remain
rg "qrcode/resend|qrcode/generate|qrcode/deliver" src/frontend/src/

# Verify no duplicate QRHistoryEntry
rg "interface QRHistoryEntry" src/frontend/src/
# Expected: exactly 1 hit (in users.ts)

# Verify old method names are gone
rg "record_issue\b" src/backend/
rg "\.record_qr_issuance\b" src/backend/
# Expected: zero matches

# Verify verify_provisioning_payload moved
rg "verify_provisioning_payload" src/backend/
# Expected: zero matches
rg "verify_provisioning_payload" tests/
# Expected: hits in tests/helpers/qr_helpers.py and test_qr_signing_unit.py only
```
