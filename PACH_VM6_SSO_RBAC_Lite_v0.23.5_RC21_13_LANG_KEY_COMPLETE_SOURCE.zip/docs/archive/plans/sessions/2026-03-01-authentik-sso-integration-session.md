---
feature: authentik-sso-integration
date: 2026-03-01
branch: authentik-sso-integration
mode: level-3
team: []
status: in-progress
---

# Session Ledger: Authentik SSO Integration for AZBlink Directory Platform

## Scope
Research, decision-making, architecture design, and detailed implementation planning for integrating Authentik as the SSO provider across all auth services — including the AZBlink admin UI, XMPP (via UED Sync), and SIP (via UED Sync). **No code will be written in this session.**

---

## Phase 1: Codebase Exploration (COMPLETE)

**Report:** `docs/plans/sessions/2026-03-01-authentik-sso-integration-exploration.md`

Key findings:
- Dual auth planes already designed (Plane A = UC/LDAP, Plane B = SSO/OIDC)
- `oidc_verify.py` — already complete, handles JWKS-based Bearer token verification
- `config.py` — OIDC vars defined (`OIDC_ISSUER`, `OIDC_AUDIENCE`, etc.) but unused
- `main.py` — auth middleware routes between OIDC/break-glass/bootstrap modes
- Frontend has NO OIDC login flow — only LDAP username/password
- SSO infrastructure scaffolded but not connected: `sso_config` column, Pydantic models, `authentik_sessions_revoked` column

---

## Phase 2: Knowledge Research (COMPLETE)

### Critical Finding: Option 3 Needs Revision

**Original Option 3:** Authentik as identity provider → SCIM sync to LDAP → admin UI SSO
**Problem:** Authentik has NO outbound LDAP sync capability.

| Authentik Feature | Direction | Can Push to LDAP? |
|---|---|---|
| SCIM Provider | Authentik → SCIM endpoint | No — OpenLDAP has no SCIM API |
| LDAP Provider/Outpost | Authentik → Virtual LDAP | No — read-only exposure, wrong objectClasses |
| LDAP Source | External LDAP → Authentik | Inbound only (password writeback is sole exception) |

### Revised Architecture: LDAP-Authoritative + Authentik Import

**The data flow reverses:** LDAP stays authoritative, Authentik imports via LDAP Source.

- AD LDAP remains the single source of truth for identity
- Authentik imports users via LDAP Source (periodic sync, ~5min)
- Authentik provides OIDC for admin UI SSO
- UED LDAP (XMPP/SIP) provisioned independently via UED Sync — no Authentik dependency
- Net user experience is identical to original Option 3

### OIDC Integration Details

- **Flow:** Authorization Code + PKCE (S256) for SPA
- **Client type:** Public (no client_secret)
- **Scopes:** `openid`, `profile`, `email`, `entitlements` (groups)
- **Signing:** RS256 via JWKS (already supported by `oidc_verify.py`)
- **Groups:** `groups` claim in `entitlements` scope → maps to `OIDC_GROUPS_CLAIM`

### Session/Token Revocation (Termination Flow)

- Authentik Admin API v3: `/api/v3/oauth2/access_tokens/`, `/api/v3/oauth2/refresh_tokens/`
- End-session endpoint does NOT revoke tokens — must use Admin API
- Termination sequence: Disable LDAP → Revoke Authentik tokens (API) → UC sessions

### Knowledge Files Created

- `docs/knowledge/libraries/authentik-oidc-provider.md`
- `docs/knowledge/libraries/authentik-ldap-scim-sync.md`
- `docs/knowledge/patterns/dual-auth-plane-sso-overlay.md`

---

## Phase 3: Architecture Design (COMPLETE)

**Document:** `docs/plans/sessions/2026-03-01-authentik-sso-architecture.md`

### Architecture Decision

**LDAP-Authoritative + Authentik Import** — reversal of original Option 3 data flow.
- AD LDAP remains authoritative (no change to existing user lifecycle)
- Authentik imports via LDAP Source (periodic ~5min sync)
- OIDC Authorization Code + PKCE for admin UI SSO
- UED Sync provisioning unchanged — zero Authentik dependency

### C4 Diagrams Created

1. **Level 1 — System Context:** Shows AZBlink, Authentik, ejabberd, Asterisk, and both LDAP stores
2. **Level 2 — Container:** Shows SPA, API, Sync Worker, PostgreSQL, Authentik components, UED Sync
3. **Level 3 — Auth Component:** Shows auth-store, PKCE utils, callback route, auth middleware, OIDC verify, break-glass, Authentik client
4. **Sequence — OIDC Login:** Full Authorization Code + PKCE flow with LDAP fallback
5. **Sequence — Termination:** Parallel LDAP disable + Authentik revocation + UC deletion

### Design Invariants Preserved

- UC works without Authentik (XMPP/SIP bind against UED LDAP, no SSO dependency)
- Break-glass unchanged (file-based, localhost-only, time-limited)
- LDAP authoritative (Authentik is consumer, not producer)
- Dual login paths (LDAP form fallback + OIDC SSO preferred)

### New Components Identified

- **Backend:** `authentik_client.py` (Admin API v3 client for session/token revocation)
- **Frontend:** `oidc.ts` (PKCE utilities), `/auth/callback` (TanStack route)
- **Config:** `AUTHENTIK_API_URL`, `AUTHENTIK_API_TOKEN`, `OIDC_CLIENT_ID`, `OIDC_REDIRECT_URI`
- **DevOps:** Authentik container in docker-compose (or external reference)

---

## Phase 4: Implementation Planning (COMPLETE)

**Document:** `docs/plans/sessions/2026-03-01-authentik-sso-implementation-plan.md`

### Summary

- **5 work streams:** DevOps, Backend, Frontend, Database, Testing
- **20 tasks** with explicit dependencies and build order
- **6 new files**, **8 modified files**, **4 confirmed-unchanged files**
- **~9.5 developer days** estimated effort
- **Critical path:** Docker Compose → OIDC Provider config → Authentik client → Termination flow → Integration tests

### Deferred Items

- `uc_client.py` — No UC Server admin API exists yet
- OIDC token refresh — Enhancement for later iteration
- Per-profile SSO policy enforcement — Needs Authentik↔profile mapping design
- Authentik Blueprint automation — Manual setup documented for now

---

## Phase 5: Plan Review Gate

### Completeness Checklist

| Criterion | Status | Notes |
|---|---|---|
| Architecture documented with diagrams | Done | 5 Mermaid diagrams (3 C4 + 2 sequence) |
| All files to modify identified | Done | 6 new + 8 modified + 4 unchanged |
| Build sequence with dependencies | Done | 20 steps, critical path identified |
| Risk assessment | Done | 5 risks with mitigations |
| Testing plan | Done | Unit + integration + E2E across 4 tasks |
| Design invariants verified | Done | UC independence, break-glass, LDAP authority |
| Out-of-scope items documented | Done | 5 deferred items with rationale |
| Knowledge files created | Done | 3 knowledge docs |
| PRD alignment verified | Done | Matches Phase 2 PRD requirements |

### Alignment with PRD

| PRD Requirement | Plan Coverage |
|---|---|
| `authentik_client.py` | WS2-T2.2 |
| Updated termination flow | WS2-T2.3 |
| Deep health check | WS2-T2.4 |
| SSO block in QR | Out of scope — QR content unchanged until per-profile SSO policy is designed |
| `uc_client.py` | Deferred — no UC Server admin API exists |
| `breakglass_audit` table | WS4-T4.1 |
| Frontend OIDC login | WS3 (5 tasks) |

### Architecture Confidence: HIGH

The integration is straightforward because:
1. `oidc_verify.py` already handles JWKS-based Bearer token verification — no backend auth changes needed
2. Auth middleware (`_claims_from_auth_header`) already supports OIDC Bearer tokens
3. Termination flow has placeholder hooks for Authentik — just need to implement the client
4. OIDC config vars are already defined in `config.py` — just need to add Authentik API vars
5. Frontend is the main area of new work (PKCE + callback + dual login)
