---
feature: authentik-dev-stack
date: 2026-03-04
branch: authentik-dev-stack
mode: level-3
team: [devops]
status: completed
confidence: 90%
---

# Session Ledger: Authentik Dev Stack Integration

## Phases 1-5: Skipped (Pre-Written Plan)
- Plan provided: `docs/plans/2026-03-04-authentik-dev-stack-plan.md`
- Design doc: `docs/plans/2026-03-04-authentik-dev-stack-design.md`
- Mode: Level 3 autonomous — executing plan directly

## Phase 6: Implementation
| Task | Domain | Status | Notes |
|------|--------|--------|-------|
| 1 — Add Authentik services to docker-compose | devops | completed | authentik-postgres, server, worker |
| 2 — Create Authentik seed script | devops | completed | idempotent, stdlib-only |
| 3 — Add seed service to docker-compose | devops | completed | one-shot python:3.11-slim |
| 4 — Configure environment variables | devops | completed | .env (local) + .env.example (committed) |
| 5 — Add Cloudflare tunnel ingress | devops | completed | authentik.keithmoc.dev route active |
| 6 — Bring up stack and verify | devops | completed | 10 services healthy, seed OK, 299 tests pass |
| 7 — E2E OIDC login test | manual | deferred | requires browser verification |
| 8 — Final docs and commit | docs | completed | CLAUDE.md updated |

## Issues & Resolutions
| # | Issue | Root Cause | Resolution |
|---|-------|-----------|------------|
| 1 | Seed 400: `invalidation_flow` required | Authentik 2025.8 API change | Added `get_invalidation_flow_pk()` |
| 2 | Seed 400: `redirect_uris` expected dicts | Authentik 2025.8 API change (was string, now `[{matching_mode, url}]`) | Changed to list of dicts with `matching_mode: strict` |

## Phase 7: Integration & Verification
- Test suite: 299/299 passing, 6 skipped (exit code 0)
- Docker compose validation: VALID
- OIDC discovery: returns valid JSON at `/application/o/azblink-directory/.well-known/openid-configuration`
- Deep health: all services healthy (postgresql, ldap, redis)
- Cloudflare tunnel: both `azblink-ad` and `authentik` hostnames active

## Phase 8: Finish
- Branch: authentik-dev-stack
- Commits: dfc33e9, de34efb, c38877c, b9309a0, 9c3a368, c573da7, 8061741
- PR: https://github.com/KeithMoc/azb-azblink-directory-and-identity-stack/pull/14

## Knowledge Learned
- Authentik 2025.8 OAuth2 provider API requires `invalidation_flow` (was optional in older versions)
- Authentik 2025.8 `redirect_uris` format changed from strings to `[{matching_mode, url}]` dicts
- Authentik first-time startup takes ~60s for database migrations before API is reachable
- Authentik bootstrap token (`AUTHENTIK_BOOTSTRAP_TOKEN`) is created on first startup only
