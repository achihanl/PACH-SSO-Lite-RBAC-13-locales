# Exploration Report: Fix Runtime Bugs #38 #39 #40

## Codebase Architecture

All three bugs are frontend-only. The frontend uses React 19, TanStack Query v5, TanStack Router, Zustand for auth state.

### Key Integration Points
- **Auth Store** (`stores/auth-store.ts`): Stores `AuthUser` with OIDC claims (`sub`, `uid`, `displayName`, `email`, `isAdmin`, `groups`)
- **API Client** (`lib/api-client.ts`): Throws on non-ok responses (including 404)
- **Audit Event System**: Backend generates `admin-action` events, frontend config map missing entry
- **PendingChangesDrawer**: Uses `inert` attribute with pre-React 19 empty string pattern

## Files to Modify

### Bug #38 — Missing admin-action config
1. `src/frontend/src/types/audit.ts` (L52-61) — Add `'admin-action'` to `AuditEventType` union
2. `src/frontend/src/components/features/audit-management/audit-event-config.ts` (L25-80) — Add `'admin-action'` entry
3. `src/frontend/src/components/features/audit-management/AuditRow.tsx` (L21-22) — Add defensive null check
4. `src/frontend/src/components/features/audit-management/AuditDetailPanel.tsx` (L20-21) — Add defensive null check

### Bug #39 — React 19 inert boolean
1. `src/frontend/src/components/features/settings/PendingChangesDrawer.tsx` (L128-129) — Change `inert={!isOpen ? '' : undefined}` to `inert={!isOpen || undefined}`

### Bug #40 — My Profile 404 crash
1. `src/frontend/src/routes/my-profile.tsx` (L39-41) — Replace `useSuspenseQuery` with `useQuery`, add fallback UI for OIDC-only users

## Patterns & Conventions
- Two-layer component architecture (primitives vs features)
- TanStack Query: `useSuspenseQuery` for guaranteed data, `useQuery` for graceful degradation
- Auth store provides OIDC claims as fallback when LDAP lookup fails
- Badge variants: `success | warning | error | info | muted | purple | outline`

## Knowledge Gaps
1. React 19 boolean attribute semantics (helpful, not critical)
2. TanStack Query error boundary vs useQuery pattern (helpful)

## Team Recommended
- **frontend** (React/TypeScript) — all three bugs are frontend-only

## Key Files
1. `audit-event-config.ts` — Bug #38 config map
2. `types/audit.ts` — Bug #38 type definition
3. `AuditRow.tsx` — Bug #38 crash point
4. `AuditDetailPanel.tsx` — Bug #38 crash point
5. `PendingChangesDrawer.tsx` — Bug #39 warning
6. `my-profile.tsx` — Bug #40 crash
7. `stores/auth-store.ts` — Bug #40 OIDC claims fallback
8. `lib/queries/users.ts` — Bug #40 query options
9. `lib/api-client.ts` — Bug #40 error handling
