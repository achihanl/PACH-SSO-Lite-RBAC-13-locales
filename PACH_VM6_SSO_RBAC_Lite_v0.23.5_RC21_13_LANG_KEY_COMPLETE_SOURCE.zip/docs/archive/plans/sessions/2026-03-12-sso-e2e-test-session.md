---
feature: sso-e2e-test
date: 2026-03-12
branch: sso-e2e-test
mode: level-3
team: [backend, test]
status: in-progress
---

# Session Ledger: SSO Device Provisioning E2E Test

Design doc: `docs/plans/2026-03-12-sso-e2e-test-design.md`

## Phase 1: Exploration
- Explorer found: 3 files to modify (seed_authentik.py, conftest.py, test_xmpp_e2e.py)
- Critical gap: audience mismatch — OIDC_AUDIENCE=azblink-directory but test provider tokens will have aud=azblink-directory-test
- Knowledge gaps: Authentik M2M grant behavior, PyJWT multi-audience support, token endpoint URL
- Team recommended: backend + test (no frontend, no database, no devops)
- Key files: oidc_verify.py, config.py, conftest.py, test_xmpp_e2e.py, test_device_provisioning.py, seed_authentik.py, main.py
- Status: completed

## Phase 2: Knowledge Research
- Recalled from memory: Authentik branding/seed patterns, OIDC multi-issuer pattern, FIRA audit remediation
- Recalled from files: none (first time researching M2M grants)
- Researched new:
  - Authentik M2M client_credentials grant (web search) — app passwords as password, global token endpoint
  - PyJWT audience list validation (Context7 + source) — "any match" semantics confirmed
- Knowledge files written:
  - docs/knowledge/libraries/authentik-m2m-client-credentials.md
  - docs/knowledge/libraries/pyjwt-audience-validation.md
- **DESIGN CHANGE**: Use existing public provider (client_id=azblink-directory) instead of new test provider
  - Reason: client_credentials works on public providers, tokens get aud=azblink-directory (no mismatch)
  - Eliminates: ensure_test_oauth2_provider(), ensure_test_application(), multi-audience config changes
- Status: completed

## Phase 3-5: Architecture, Planning, Review
- Design approach: Reuse existing public provider, add conftest fixtures, replace QR test with SSO variants
- Plan: 4 tasks (conftest fixtures, local test, E2E test, regression suite)
- Spec review: PASS (auto-proceed Level 3)
- Status: completed

## Phase 6: Implementation
| Task | Domain | Status |
|------|--------|--------|
| 1 - Conftest fixtures | test | completed |
| 2 - TestSsoProvisioningLocal | test | completed |
| 3 - TestSsoProvisioningE2E + remove old test | test | completed |
| 4 - .env.example update (localhost issuer) | devops | completed |

## Phase 7: Integration & Verification
- Test suite: 436/438 passing, 8 skipped (2 pre-existing failures, 0 regressions)
- TestSsoProvisioningLocal: PASSED
- TestSsoProvisioningE2E: SKIPPED (no external LDAP — expected)
- Issue found: localhost:9000 issuer missing from OIDC_ACCEPTED_ISSUERS — fixed in .env.example
- Status: completed
