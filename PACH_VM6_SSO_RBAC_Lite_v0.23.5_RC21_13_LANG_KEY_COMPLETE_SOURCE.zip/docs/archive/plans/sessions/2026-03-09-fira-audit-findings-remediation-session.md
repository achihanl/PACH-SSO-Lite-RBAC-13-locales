---
feature: fira-audit-findings-remediation
date: 2026-03-09
branch: fira-audit-findings-remediation
mode: level-3
team: []
status: in-progress
confidence: null
---

# Session Ledger: FIRA Audit Findings Remediation

Resolving top 10 findings from the Final Implementation Reconciliation Audit:

| # | ID | Sev | Finding |
|---|-----|------|---------|
| 1 | CFG-01 | Med | memberof/refint LDAP overlays promised but not delivered (only ppolicy) |
| 2 | FUNC-01 | Med | OIDC sub ↔ LDAP uid mapping TODO unresolved at main.py:365 |
| 3 | SEC-03 | Low | auditApiRequests toggle stored but never enforced |
| 4 | TEST-01 | Low | 4 duplicate test function names in test_export.py — tests shadowed |
| 5 | TEST-02 | Low | Migration 019 number collision (two files share prefix) |
| 6 | FUNC-02 | Low | SSO template → QR payload integration path unverified |
| 7 | FUNC-03 | Low | Content-Disposition header on audit export untested |
| 8 | SEC-04 | Low | Refresh token auto-refresh behavior unverified |
| 9 | SEC-02 | Low | IP blocking uses PostgreSQL not Redis (intentional deviation) |
| 10 | ARCH-01 | Info | 2 require_admin calls remaining (intentional for bootstrap) |
