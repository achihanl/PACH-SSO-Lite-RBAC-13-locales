# QR Code Preview — Exploration Report

## Codebase Architecture

### Backend (FastAPI)
- **`src/backend/main.py`** — All API routes. QR endpoints at lines 1949-2050 (`GET /api/users/{uid}/qrcode`), 2054-2165 (`GET /api/users/{uid}/qrcodes`), 1564-1606 (`POST /api/provision/validate`), 1608-1667 (`POST /api/provision/consume`)
- **`src/backend/qr_signing.py`** — HMAC-SHA256 signing/verification with `azblink.provisioning.v2` schema. Signs with iat/exp/nonce/sig fields. `verify_provisioning_payload()` validates signature and expiry.
- **`src/backend/config.py`** — `ORG_QR_SIGNING_SECRET`, `ORG_QR_DEFAULT_TTL_SEC` (3600), `ORG_QR_MAX_TTL_SEC` (86400)
- **`src/backend/orgdb.py`** — PostgreSQL access. Key methods: `record_provision_token()`, `validate_and_consume_token()`, `get_provision_token()`, `record_qr_issuance()`
- **`src/backend/rate_limit.py`** — `LIMIT_QR = "10/minute"` for QR endpoints

### Frontend (React)
- **`src/frontend/src/routes/__root.tsx`** — `PUBLIC_ROUTES = ['/login']` — need to add QR preview route here
- **`src/frontend/src/routes/login.tsx`** — Reference pattern for a public (no-auth) page
- **`src/frontend/src/components/features/qr-display.tsx`** — Existing QR display component (shows QR image, expiry badge, copy/download/email actions)
- **`src/frontend/src/lib/api-client.ts`** — Always attaches auth token. Need public fetch for preview endpoint.
- **`src/frontend/src/lib/queries/qr-generation.ts`** — `useGenerateQR()` mutation (calls `GET /users/{uid}/qrcode`)
- **`src/frontend/src/types/qr.ts`** — `QRCodeResponse`, `ProvisioningPayloadV2` types
- **`src/frontend/src/lib/utils/qr-helpers.ts`** — `downloadQRImage()`, `getQRTimeRemaining()` utilities

### Database
- **`provision_tokens`** table: `token_hash` (PK), `uid`, `profile_id`, `issued_at`, `expires_at`, `used_at`, `status`, device tracking cols
- **`qr_issuance_audit`** table: `id`, `user_uid`, `org_dn`, `issued_by`, `issued_at`, `token_hash`, `expires_at`, `consumed`, `consumed_at`, etc.
- No existing "shareable link" or "preview token" concept in DB

## Files to Modify

### Backend
1. **`src/backend/main.py`** — Add new public endpoint `GET /api/qr/preview/{preview_token}` (no auth required)
2. **`src/backend/main.py`** — Modify `api_user_qrcode` to return a `previewUrl` field after generating the QR
3. **`src/backend/orgdb.py`** — Add new table `qr_preview_links` and methods: `create_preview_link()`, `get_preview_link()`
4. **`src/backend/config.py`** — Add `ORG_QR_PREVIEW_TTL_SEC` default

### Database
5. **`migrations/016_qr_preview_links.sql`** — New table for shareable preview links with expiry

### Frontend
6. **`src/frontend/src/routes/__root.tsx`** — Add `/qr/` to `PUBLIC_ROUTES`
7. **`src/frontend/src/routes/qr/$previewToken.tsx`** — New public route for QR preview page
8. **`src/frontend/src/components/features/qr-preview/QRPreviewPage.tsx`** — Public QR preview component
9. **`src/frontend/src/types/qr.ts`** — Add `QRPreviewResponse` type
10. **`src/frontend/src/components/features/qr-display.tsx`** — Add "Share Link" action that generates preview URL

## Patterns & Conventions

- **Public routes:** Login page pattern — renders without sidebar/header shell, full-screen centered layout
- **API patterns:** JSON responses with `ok: true/false`, proper HTTP status codes, Pydantic validation
- **QR data flow:** Admin generates QR → signed payload stored → PNG rendered → token stored in DB
- **Component architecture:** Feature components in `src/components/features/`, import primitives from `@azblink/ui`
- **Route conventions:** TanStack Router file-based, `createFileRoute()`, search params validated

## Tech Stack & Libraries

- **Backend:** FastAPI, SQLAlchemy (core, not ORM), `qrcode` Python library, HMAC-SHA256
- **Frontend:** React 19, TanStack Router, TanStack Query, @azblink/ui, Tailwind CSS 4, lucide-react
- **QR generation:** `python-qrcode` server-side (PNG base64)

## Knowledge Gaps Identified

1. **Topic:** TanStack Router — creating pathless/public routes outside the auth shell
   - **Why:** Need to create a route that bypasses the auth check and renders without sidebar
   - **Suggested source:** `/tanstack/router` on Context7
   - **Priority:** helpful (pattern already visible in login.tsx)

2. **Topic:** Secure shareable link token design — short URL-safe tokens with expiry
   - **Why:** Need to design a token that can be shared via email/SMS safely
   - **Suggested source:** Web search "secure shareable link token best practices"
   - **Priority:** critical (security-sensitive design decision)

3. **Topic:** QR code countdown timer UI — live expiry display on React
   - **Why:** Preview page needs to show live countdown to expiry
   - **Suggested source:** Web search "react countdown timer hook"
   - **Priority:** helpful

## Recommended Team Composition

- **backend** — New public API endpoint, new DB table, preview token generation/validation logic
- **frontend** — New public route, preview page component, share link integration
- **database** — New migration for `qr_preview_links` table
- **NOT needed: devops** — No Docker/CI changes required
- **NOT needed: test** — Tests will be written inline by backend/frontend engineers (TDD)

## Key Files to Read

1. `src/backend/main.py` (lines 1949-2050) — QR generation endpoint
2. `src/backend/qr_signing.py` — Signing/verification logic
3. `src/backend/orgdb.py` — DB schema and token methods
4. `src/backend/config.py` — QR config constants
5. `src/frontend/src/routes/__root.tsx` — Auth/public route handling
6. `src/frontend/src/routes/login.tsx` — Public page pattern
7. `src/frontend/src/components/features/qr-display.tsx` — Existing QR display component
8. `src/frontend/src/lib/api-client.ts` — API client (auth token handling)
9. `src/frontend/src/types/qr.ts` — QR-related TypeScript types
10. `src/frontend/src/lib/utils/qr-helpers.ts` — QR helper utilities
