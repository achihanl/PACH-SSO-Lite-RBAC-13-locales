---
feature: fix-runtime-bugs-38-39-40
date: 2026-03-10
branch: fix-runtime-bugs-38-39-40
mode: level-3r
team: [frontend]
status: in-progress
---

# Session Ledger: Fix Runtime Bugs #38 #39 #40

## Issues
- #38 — AuditRow crashes on missing 'admin-action' event config
- #39 — React warning: empty string for `inert` boolean attribute
- #40 — My Profile crashes for OIDC users without LDAP entry
