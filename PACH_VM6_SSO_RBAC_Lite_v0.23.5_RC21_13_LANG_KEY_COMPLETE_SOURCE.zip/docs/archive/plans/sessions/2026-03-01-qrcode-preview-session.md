---
feature: qrcode-preview
date: 2026-03-01
branch: qrcode-preview
mode: level-3
team: []
status: in-progress
---

# Session Ledger: QR Code Preview — Shareable Link with Expiry
