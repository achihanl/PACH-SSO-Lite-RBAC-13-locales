# Exploration Report: Authentik SSO Integration

**Date:** 2026-03-01
**Scope:** Option 3 — Authentik as identity provider (SCIM sync to LDAP) + Admin UI SSO. XMPP/SIP remain LDAP bind auth.

---

## Codebase Architecture

### Current Authentication System

**Dual Auth Planes (designed, partially implemented):**
- **Plane A (UC/LDAP):** XMPP/SIP authenticate via LDAP bind against UED's LDAP. No IdP dependency. **Fully working.**
- **Plane B (SSO/Authentik):** Web apps use OIDC. **Scaffolded but not connected.**

**Backend Auth Flow:**
1. `auth.py` — LDAP bind authentication → issues JWT (HS256, local secret)
2. `oidc_verify.py` — Verifies Bearer access tokens from OIDC provider (RS256/ES256 via JWKS)
3. `main.py:_claims_from_auth_header()` — Routes between:
   - Non-OIDC mode (`REQUIRE_OIDC_AUTH=false`): anonymous claims, no token needed
   - OIDC mode (`REQUIRE_OIDC_AUTH=true`): requires Bearer token → `verify_bearer_token()`
   - Break-glass bypass: localhost-only, time-limited emergency access
   - Bootstrap mode: Day-0 endpoints open without auth

**Frontend Auth Flow:**
- `auth-store.ts` — Zustand store with `login()` action → `POST /api/auth/login` → receives JWT
- `__root.tsx` — Route guard: redirects to `/login` if not authenticated
- **No OIDC login flow exists** — only LDAP username/password

**Config Variables (already defined):**
- `REQUIRE_OIDC_AUTH` — boolean toggle for OIDC enforcement
- `OIDC_ISSUER`, `OIDC_DISCOVERY_URL`, `OIDC_AUDIENCE` — for token verification
- `OIDC_GROUPS_CLAIM`, `OIDC_ADMIN_GROUP` — for RBAC
- `JWT_SECRET` — for local LDAP-login JWTs

### UED Sync Auth Model
- UED Sync API uses `X-API-Key` header auth (shared secret between AD Directory and UED)
- UED creates LDAP entries with `userPassword` (SSHA hash) for XMPP/SIP LDAP bind auth
- **No OIDC involvement in UC provisioning** — by design (Plane A independence)

### SSO-Ready Infrastructure (exists but unused)
- `sso_config` JSON column on `config_templates` table
- `SsoProfileConfig`, `SsoOidc`, `SsoOidcClients` Pydantic models in `main.py`
- `OrgProfileUpsert.ssoProfile` field — SSO config per org profile
- `authentik_sessions_revoked` column on `termination_events` table

---

## Files to Modify (for Option 3)

### Backend
| File | Change | Why |
|------|--------|-----|
| `config.py` | Add `AUTHENTIK_API_URL`, `AUTHENTIK_API_TOKEN` | Authentik Admin API connection |
| `main.py` | Add `/api/auth/oidc/callback`, update termination endpoint | OIDC auth code exchange, session revocation |
| `auth.py` | Add OIDC-based login alternative | Support both LDAP and OIDC login paths |
| `oidc_verify.py` | Already complete | No changes needed |
| NEW: `authentik_client.py` | Authentik Admin API client | Session/token revocation, user lookup, SCIM |
| `orgdb.py` | Minor: update sso_config defaults | Align with actual Authentik schema |

### Frontend
| File | Change | Why |
|------|--------|-----|
| `auth-store.ts` | Add OIDC login flow (authorization code + PKCE) | Support SSO login alongside LDAP |
| `__root.tsx` | Handle OIDC callback route | Process authorization code |
| NEW: `routes/auth/callback.tsx` | OIDC callback page | Handle redirect from Authentik |
| `routes/login.tsx` | Add "Login with SSO" button | Dual login option |
| NEW: `lib/queries/oidc.ts` | OIDC utilities (PKCE, token exchange) | Frontend OIDC logic |

### DevOps
| File | Change | Why |
|------|--------|-----|
| `deploy/dev/docker-compose.yml` | Add Authentik container (or reference external) | Dev environment |
| `deploy/dev/.env.example` | Add Authentik env vars | Documentation |

### Database
| File | Change | Why |
|------|--------|-----|
| NEW: `migrations/017_authentik_sso.sql` | Breakglass audit table, sso_config schema update | PRD requirement |

---

## Patterns & Conventions

- Auth middleware pattern: `Depends(require_user)` / `Depends(require_admin)` / `require_permission()`
- Config: environment variables loaded at module import time in `config.py`
- API clients: singleton pattern with lazy init (see `ued_sync_client.py` for reference)
- Frontend data fetching: TanStack Query hooks in `lib/queries/`
- Frontend state: Zustand stores in `stores/`

---

## Knowledge Gaps

| # | Topic | Why Needed | Suggested Source | Priority |
|---|-------|-----------|-----------------|----------|
| 1 | Authentik OIDC Provider Configuration | Need to configure Authentik as OIDC provider for admin UI | Web search: "Authentik OIDC provider setup 2026" | Critical |
| 2 | Authentik Admin API v3 | Need API spec for session/token revocation, user management | Web search: "Authentik Admin API v3 documentation" | Critical |
| 3 | Authentik SCIM Provider | Need to understand how Authentik pushes users to external systems | Web search: "Authentik SCIM provider outbound sync" | Critical |
| 4 | Authentik LDAP Provider/Outpost | Can Authentik sync identities TO an LDAP directory? | Web search: "Authentik LDAP outpost provider sync to LDAP" | Critical |
| 5 | PKCE Authorization Code Flow (frontend) | Need to implement browser-based OIDC login | Context7: react OIDC PKCE | Helpful |
| 6 | FastAPI OIDC Integration Patterns | Backend authorization code exchange patterns | Context7: fastapi oauth2 | Helpful |

---

## Recommended Team Composition

For **research and planning only** (no code):
- **Backend** — Needed: OIDC integration, Authentik API client design, auth flow
- **Frontend** — Needed: OIDC login flow, callback handling, auth store changes
- **DevOps** — Needed: Authentik container setup in dev stack, env configuration
- **Database** — Low need: minimal schema changes (breakglass audit, sso_config tweaks)
- **Test** — Not needed yet (research phase)

---

## Key Files

1. `src/backend/auth.py` — Current LDAP auth + JWT
2. `src/backend/oidc_verify.py` — OIDC token verification (complete)
3. `src/backend/config.py` — Auth configuration variables
4. `src/backend/main.py:219-362` — Auth middleware, break-glass, RBAC
5. `src/frontend/src/stores/auth-store.ts` — Frontend auth state
6. `src/frontend/src/routes/__root.tsx` — Route guards
7. `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md` — Full Phase 2 spec
8. `src/backend/orgdb.py:199-230` — config_templates table with sso_config
9. `src/ued-sync/src/ued_sync/auth.py` — UED Sync API key auth (unchanged by SSO)
10. `src/ued-sync/src/ued_sync/schemas/xmpp.py` — XMPP LDAP bind auth schema
