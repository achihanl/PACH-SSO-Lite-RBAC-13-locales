# Architecture Design: Authentik SSO Integration

**Date:** 2026-03-01
**Status:** Proposed
**Supersedes:** Original "Option 3" (Authentik-authoritative with SCIM-to-LDAP sync)

---

## Architecture Decision: LDAP-Authoritative + Authentik Import

### Why Not the Original Option 3?

The user's original request was "Authentik as identity provider → SCIM sync to LDAP → Admin UI SSO."
Research revealed this is **not natively supported by Authentik**:

| Authentik Feature | Can Push Users TO LDAP? | Why Not |
|---|---|---|
| SCIM Provider | No | OpenLDAP has no SCIM API |
| LDAP Provider/Outpost | No | Read-only virtual LDAP, wrong objectClasses |
| LDAP Source | Inbound only | Imports FROM LDAP, doesn't write to it |

### Recommended Architecture: Reverse the Data Flow

**LDAP stays authoritative. Authentik becomes an SSO overlay.**

From the user's perspective, the experience is identical:
- Admins log into the web UI via Authentik SSO
- XMPP/SIP users authenticate via LDAP bind (no SSO dependency)
- User termination revokes SSO sessions + UC sessions in parallel

The difference is internal: LDAP is the source of truth, Authentik imports from it.

---

## C4 Diagrams

### Level 1 — System Context

```mermaid
C4Context
    title System Context — AZBlink Directory + Authentik SSO

    Person(admin, "IT Admin", "Manages users, orgs, profiles via web UI")
    Person(ucUser, "UC User", "XMPP/SIP end user (phone, chat client)")

    System(azblink, "AZBlink Directory", "Identity management platform with QR provisioning")
    System(authentik, "Authentik", "SSO identity provider — imports from LDAP, issues OIDC tokens")
    System(ejabberd, "ejabberd", "XMPP server — authenticates via LDAP bind")
    System(asterisk, "Asterisk", "SIP/VoIP PBX — authenticates via LDAP bind")

    System_Ext(adLdap, "AD LDAP (OpenLDAP)", "Authoritative identity store — inetOrgPerson")
    System_Ext(uedLdap, "UED LDAP(s)", "UC service stores — posixAccount + SIP/XMPP attrs")

    Rel(admin, azblink, "Manages users/orgs", "HTTPS + OIDC or LDAP login")
    Rel(admin, authentik, "SSO login redirect", "OIDC Authorization Code + PKCE")
    Rel(ucUser, ejabberd, "Chat", "XMPP over WebSocket")
    Rel(ucUser, asterisk, "Voice/Video", "SIP over WebSocket")

    Rel(azblink, adLdap, "CRUD identity", "LDAP")
    Rel(azblink, uedLdap, "Provision UC accounts", "HTTP via UED Sync")
    Rel(authentik, adLdap, "Import users (LDAP Source)", "LDAP read, periodic sync")
    Rel(ejabberd, uedLdap, "Auth bind", "LDAP bind")
    Rel(asterisk, uedLdap, "Auth bind", "LDAP bind")

    UpdateLayoutConfig($c4ShapeInRow="3", $c4BoundaryInRow="1")
```

**Key relationships:**
- AZBlink Directory owns AD LDAP (authoritative CRUD)
- Authentik **imports from** AD LDAP via LDAP Source (periodic, ~5min)
- UED Sync provisions UC accounts into separate UED LDAP(s)
- ejabberd/Asterisk bind-auth against UED LDAP (no Authentik dependency)

### Level 2 — Container

```mermaid
C4Container
    title Container Diagram — AZBlink Directory + Authentik SSO

    Person(admin, "IT Admin", "Web browser")

    System_Boundary(azblink, "AZBlink Directory Platform") {
        Container(spa, "Admin UI", "React 19 SPA", "TanStack Router, Zustand, @azblink/ui")
        Container(api, "Directory API", "FastAPI", "User/Org CRUD, QR provisioning, auth middleware")
        Container(syncWorker, "Sync Worker", "Python async", "Background sync event processor")
        ContainerDb(postgres, "PostgreSQL", "DB", "orgprofiles, config_templates, sync_events, audit")
        Container(cli, "directoryctl", "Python CLI", "Break-glass, status checks")
    }

    System_Boundary(ued, "UED Sync (per-instance)") {
        Container(uedApi, "UED Sync API", "FastAPI", "Stateless LDAP provisioner")
    }

    System_Boundary(sso, "Authentik SSO") {
        Container(authCore, "Authentik Core", "Django", "User mgmt, flows, policies")
        Container(authLdapSrc, "LDAP Source", "Sync task", "Periodic import from AD LDAP")
        Container(authOidc, "OIDC Provider", "OAuth2", "Authorization Code + PKCE, JWKS")
        Container(authAdminApi, "Admin API v3", "REST", "Session/token revocation")
    }

    ContainerDb(adLdap, "AD LDAP", "OpenLDAP", "Authoritative identity store")
    ContainerDb(uedLdap, "UED LDAP", "OpenLDAP", "UC service store (XMPP/SIP)")

    Rel(admin, spa, "Browse", "HTTPS")
    Rel(spa, authOidc, "OIDC login redirect", "Auth Code + PKCE")
    Rel(spa, api, "API calls", "HTTPS + Bearer JWT")
    Rel(api, postgres, "Read/Write", "SQL")
    Rel(api, adLdap, "CRUD users", "LDAP")
    Rel(api, authAdminApi, "Revoke sessions on termination", "HTTPS + Bearer")
    Rel(syncWorker, uedApi, "Sync events", "HTTPS + X-API-Key")
    Rel(uedApi, uedLdap, "Provision UC accounts", "LDAP")
    Rel(authLdapSrc, adLdap, "Import users periodically", "LDAP read")
    Rel(authOidc, spa, "Tokens (access, id, refresh)", "HTTPS redirect")
    Rel(cli, api, "Break-glass file", "Filesystem")

    UpdateLayoutConfig($c4ShapeInRow="4", $c4BoundaryInRow="2")
```

**New interactions (vs current):**
- SPA → Authentik OIDC Provider (login redirect)
- API → Authentik Admin API v3 (session revocation on termination)
- Authentik LDAP Source → AD LDAP (periodic user import)

### Level 3 — Auth Component

```mermaid
C4Component
    title Component Diagram — Authentication Subsystem

    Container_Boundary(frontend, "Admin UI (SPA)") {
        Component(authStore, "auth-store.ts", "Zustand", "Auth state, login(), oidcLogin(), logout()")
        Component(oidcLib, "oidc.ts", "PKCE utils", "code_verifier, code_challenge, token exchange")
        Component(callbackRoute, "/auth/callback", "TanStack Route", "Handles OIDC redirect with auth code")
        Component(loginPage, "/login", "TanStack Route", "LDAP login form + SSO button")
    }

    Container_Boundary(backend, "Directory API (FastAPI)") {
        Component(authMiddleware, "_claims_from_auth_header", "Python", "Routes: OIDC Bearer / break-glass / bootstrap / anon")
        Component(ldapAuth, "auth.py", "Python", "LDAP bind → JWT (HS256)")
        Component(oidcVerify, "oidc_verify.py", "Python", "Bearer token verify via JWKS (RS256)")
        Component(breakglass, "break-glass", "Python", "File-based emergency bypass")
        Component(authentikClient, "authentik_client.py", "Python (NEW)", "Admin API v3: session/token revocation")
        Component(rbac, "require_permission", "Python", "Group-based RBAC with admin fallback")
    }

    Container_Ext(authentik, "Authentik OIDC Provider", "OAuth2 + PKCE")
    Container_Ext(adLdap, "AD LDAP", "OpenLDAP")

    Rel(loginPage, authStore, "LDAP login()", "username + password")
    Rel(loginPage, oidcLib, "SSO login click", "Generate PKCE challenge")
    Rel(oidcLib, authentik, "Redirect to /authorize", "Auth Code + PKCE")
    Rel(authentik, callbackRoute, "Redirect with code", "?code=...&state=...")
    Rel(callbackRoute, authStore, "Exchange code for tokens", "")
    Rel(authStore, ldapAuth, "POST /api/auth/login", "HTTPS")
    Rel(authStore, authentik, "POST /token", "code + code_verifier")

    Rel(authMiddleware, oidcVerify, "Bearer token", "RS256 JWT")
    Rel(authMiddleware, breakglass, "No token, localhost", "File check")
    Rel(oidcVerify, authentik, "Fetch JWKS", "HTTPS, cached 10min")
    Rel(ldapAuth, adLdap, "LDAP bind", "LDAP")
    Rel(authentikClient, authentik, "Revoke tokens", "Admin API v3")
    Rel(authMiddleware, rbac, "Claims", "groups claim")
```

**New components (not yet created):**
- `oidc.ts` — Frontend PKCE utilities (code_verifier, code_challenge, token exchange)
- `/auth/callback` — TanStack Router route for OIDC redirect handling
- `authentik_client.py` — Backend Authentik Admin API client (session/token revocation)

**Modified components:**
- `auth-store.ts` — Add `oidcLogin()`, `oidcLogout()`, OIDC token storage
- `/login` — Add "Login with SSO" button alongside LDAP form
- `_claims_from_auth_header()` — Already supports OIDC Bearer (no change needed)

---

## Sequence Diagrams

### OIDC Login Flow

```mermaid
sequenceDiagram
    actor Admin as IT Admin
    participant SPA as Admin UI (SPA)
    participant Auth as Authentik
    participant API as Directory API
    participant LDAP as AD LDAP

    Note over Admin,LDAP: OIDC Login Flow (Authorization Code + PKCE)

    Admin->>SPA: Click "Login with SSO"
    SPA->>SPA: Generate code_verifier + code_challenge (S256)
    SPA->>SPA: Store state + code_verifier in sessionStorage
    SPA->>Auth: Redirect to /authorize?<br/>response_type=code&client_id=azblink-directory<br/>&code_challenge={hash}&code_challenge_method=S256
    Auth->>Admin: Show Authentik login page
    Admin->>Auth: Enter credentials
    Auth->>LDAP: Validate (LDAP Source sync means<br/>Authentik has imported user + password)
    LDAP-->>Auth: Bind success
    Auth->>SPA: Redirect to /auth/callback?code={code}&state={state}
    SPA->>SPA: Verify state matches sessionStorage
    SPA->>Auth: POST /token {code, code_verifier, client_id, redirect_uri}
    Auth-->>SPA: {access_token, id_token, refresh_token, expires_in}
    SPA->>SPA: Store tokens in auth-store (Zustand)
    SPA->>API: API requests with Bearer {access_token}
    API->>API: oidc_verify.py: verify JWT via JWKS (RS256)
    API-->>SPA: Response with user data

    Note over Admin,LDAP: Fallback: LDAP Login (when Authentik unavailable)

    Admin->>SPA: Enter username + password on login form
    SPA->>API: POST /api/auth/login {username, password}
    API->>LDAP: LDAP bind (username, password)
    LDAP-->>API: Bind success + user attributes
    API->>API: Generate JWT (HS256, local secret)
    API-->>SPA: {token, user}
    SPA->>SPA: Store JWT in auth-store
```

### User Termination with SSO Revocation

```mermaid
sequenceDiagram
    actor Admin as IT Admin
    participant API as Directory API
    participant LDAP as AD LDAP
    participant Auth as Authentik Admin API
    participant UED as UED Sync API
    participant ULDAP as UED LDAP

    Note over Admin,ULDAP: User Termination Flow (with Authentik SSO)

    Admin->>API: POST /api/users/{uid}/terminate
    API->>API: Record termination_event in PostgreSQL

    par Step 1: Disable LDAP identity
        API->>LDAP: Modify userPassword (disable)
        LDAP-->>API: Success
    and Step 2: Revoke Authentik sessions
        API->>Auth: GET /api/v3/core/users/?search={uid}
        Auth-->>API: {user_id, ...}
        API->>Auth: GET /api/v3/oauth2/access_tokens/?user__username={uid}
        Auth-->>API: [{id: tok1}, {id: tok2}]
        API->>Auth: DELETE /api/v3/oauth2/access_tokens/{tok1}/
        API->>Auth: DELETE /api/v3/oauth2/refresh_tokens/...
        Auth-->>API: 204 No Content
        API->>API: Update termination_event.authentik_sessions_revoked = true
    and Step 3: Terminate UC sessions
        API->>UED: POST /api/v1/sync/user {operation: delete, user: {uid}}
        UED->>ULDAP: Delete LDAP entry
        ULDAP-->>UED: Success
        UED-->>API: {status: success}
    end

    API-->>Admin: {terminated: true, ldap: ok, authentik: ok, uc: ok}
```

---

## Design Invariants Preserved

| Invariant | How It's Preserved |
|---|---|
| UC works without Authentik | XMPP/SIP auth via UED LDAP bind — zero Authentik dependency |
| Break-glass works | `_breakglass_allows()` unchanged — file-based, localhost-only |
| LDAP is authoritative | AD LDAP owns all identity CRUD; Authentik only imports |
| Dual login paths | LDAP form (fallback) + OIDC SSO (preferred) on same login page |
| Termination is comprehensive | LDAP disable + Authentik revocation + UC deletion in parallel |

## New Config Variables

| Variable | Default | Purpose |
|---|---|---|
| `AUTHENTIK_API_URL` | `""` | Authentik Admin API base URL |
| `AUTHENTIK_API_TOKEN` | `""` | Bearer token for Admin API v3 |
| `OIDC_CLIENT_ID` | `"azblink-directory"` | Public client ID for frontend OIDC (same as OIDC_AUDIENCE) |
| `OIDC_REDIRECT_URI` | `""` | Callback URL (e.g., `http://localhost:8081/auth/callback`) |

## Risk Assessment

| Risk | Mitigation | Probability |
|---|---|---|
| Authentik LDAP Source sync delay (~5min) | New users can LDAP-login immediately; SSO login works after sync | Low impact |
| Authentik down → no SSO login | LDAP login fallback always available; break-glass for emergencies | Covered |
| JWKS fetch failure | 10-minute cache in oidc_verify.py; cached keys serve during outage | Covered |
| Password change race condition | Authentik password writeback optional; AZBlink always writes to AD LDAP first | Low |
| Token revocation API failure | Termination records partial status; retry mechanism for failed revocations | Medium — needs retry |
