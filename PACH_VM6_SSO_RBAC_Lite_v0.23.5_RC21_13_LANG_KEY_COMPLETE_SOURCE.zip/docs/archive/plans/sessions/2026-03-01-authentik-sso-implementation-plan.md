# Implementation Plan: Authentik SSO Integration

**Date:** 2026-03-01
**Architecture:** LDAP-Authoritative + Authentik Import (see architecture doc)
**Branch:** `authentik-sso-integration`
**Estimated effort:** 8-10 developer days across 4 work streams

---

## Work Streams Overview

| # | Stream | Scope | Dependencies |
|---|--------|-------|-------------|
| WS1 | DevOps — Authentik Dev Environment | Docker Compose + Authentik config | None (start first) |
| WS2 | Backend — Authentik Client + Auth Updates | New client, config vars, termination flow | WS1 (needs running Authentik) |
| WS3 | Frontend — OIDC Login Flow | PKCE utils, callback route, login page, auth store | WS1 (needs OIDC provider configured) |
| WS4 | Database — Migration + Audit | breakglass_audit table, sso_config schema update | None |
| WS5 | Testing — Integration + E2E | Tests against real Authentik | WS1+WS2+WS3 |

**Build order:** WS4 → WS1 → WS2+WS3 (parallel) → WS5

---

## WS1: DevOps — Authentik Dev Environment

### Task 1.1: Add Authentik to Docker Compose

**File:** `deploy/dev/docker-compose.yml`

Add Authentik server + worker containers. Authentik requires:
- PostgreSQL database (use existing `azblink-postgres` with separate database `authentik`)
- Redis (use existing `azblink-redis` with separate DB index)
- Shared Docker network

**Containers to add:**
```yaml
authentik-server:
  image: ghcr.io/goauthentik/server:2024.12
  command: server
  environment:
    AUTHENTIK_REDIS__HOST: redis
    AUTHENTIK_POSTGRESQL__HOST: postgres
    AUTHENTIK_POSTGRESQL__NAME: authentik
    AUTHENTIK_POSTGRESQL__USER: authentik
    AUTHENTIK_POSTGRESQL__PASSWORD: authentik
    AUTHENTIK_SECRET_KEY: dev-authentik-secret-change-in-prod
    AUTHENTIK_BOOTSTRAP_PASSWORD: akadmin
    AUTHENTIK_BOOTSTRAP_TOKEN: dev-authentik-api-token
  ports:
    - "9000:9000"   # Authentik UI
    - "9443:9443"   # Authentik HTTPS
  depends_on:
    - postgres
    - redis

authentik-worker:
  image: ghcr.io/goauthentik/server:2024.12
  command: worker
  environment: # same as server
  depends_on:
    - authentik-server
```

**Seed data needed:**
- Create `authentik` database in PostgreSQL init script
- Authentik auto-bootstraps admin user (`akadmin`) on first start

### Task 1.2: Authentik OIDC Provider Configuration

**Manual setup via Authentik Admin UI (document in README):**

1. Create Application: `azblink-directory`
2. Create OAuth2 Provider:
   - Name: `azblink-directory-oidc`
   - Client type: Public
   - Client ID: `azblink-directory`
   - Redirect URIs: `http://localhost:8081/auth/callback`
   - Signing key: auto-generated RS256
   - Scopes: `openid`, `profile`, `email`, `entitlements`
   - Subject mode: Based on User's username
   - Access token type: JWT
   - Token validity: access=300s, refresh=28800s

**Alternatively:** Create a Blueprint YAML file at `deploy/dev/authentik-blueprints/azblink-oidc.yaml` for automated provisioning.

### Task 1.3: Authentik LDAP Source Configuration

1. Create LDAP Source pointing to AD LDAP:
   - Server URI: `ldap://openldap:389` (Docker network)
   - Bind DN: `cn=admin,dc=azblink,dc=com`
   - Bind password: `adminpassword`
   - Base DN: `dc=azblink,dc=com`
   - User object filter: `(objectClass=inetOrgPerson)`
   - Group object filter: `(objectClass=groupOfNames)`
   - Sync interval: 60 seconds (faster for dev)
   - Property mappings: default LDAP-to-Authentik mappings

### Task 1.4: Update .env.example

**File:** `deploy/dev/.env.example`

Add:
```env
# Authentik SSO (optional — set to enable OIDC login)
AUTHENTIK_API_URL=http://authentik-server:9000
AUTHENTIK_API_TOKEN=dev-authentik-api-token
OIDC_ISSUER=http://localhost:9000/application/o/azblink-directory/
OIDC_CLIENT_ID=azblink-directory
OIDC_REDIRECT_URI=http://localhost:8081/auth/callback
REQUIRE_OIDC_AUTH=false
```

---

## WS2: Backend — Authentik Client + Auth Updates

### Task 2.1: Add Config Variables

**File:** `src/backend/config.py`

Add after the existing OIDC section:
```python
# Authentik Admin API (for session/token revocation)
AUTHENTIK_API_URL = os.getenv("AUTHENTIK_API_URL", "")
AUTHENTIK_API_TOKEN = os.getenv("AUTHENTIK_API_TOKEN", "")

# OIDC client config (for frontend redirect)
OIDC_CLIENT_ID = os.getenv("OIDC_CLIENT_ID", OIDC_AUDIENCE)
OIDC_REDIRECT_URI = os.getenv("OIDC_REDIRECT_URI", "")
```

**Also update `test_breakglass.py` mock config** — critical gotcha (see MEMORY.md).

### Task 2.2: Create Authentik Client Module

**New file:** `src/backend/authentik_client.py`

Follow the pattern from `ued_sync_client.py` (singleton with lazy init):

```python
"""Authentik Admin API v3 client for session/token management.

- Revokes OAuth2 access + refresh tokens on user termination
- Health check for deep health endpoint
- User lookup by username
"""
```

**Methods:**
- `health_check() -> bool` — `GET /api/v3/core/users/?page_size=1` (lightweight)
- `get_user(username: str) -> Optional[dict]` — `GET /api/v3/core/users/?search={username}`
- `revoke_user_tokens(username: str) -> dict` — Delete all access + refresh tokens
- `deactivate_user(username: str) -> bool` — `PATCH /api/v3/core/users/{id}/ {"is_active": false}`
- `revoke_all_user_access(username: str) -> dict` — Composite: deactivate + revoke tokens

**HTTP client:** `httpx` (already in requirements for `ued_sync_client.py`)
**Auth:** Bearer token via `AUTHENTIK_API_TOKEN`
**Error handling:** Never raise — return structured results, log errors

### Task 2.3: Wire Authentik Client into Termination Flow

**File:** `src/backend/main.py` (lines ~1485-1493)

Replace the placeholder:
```python
# 3. Revoke Authentik sessions (placeholder - not implemented yet)
# TODO: Implement when Authentik integration is added
authentik_sessions_revoked = None
actions["authentik_sessions"] = "not_configured"
```

With:
```python
# 3. Revoke Authentik sessions
from authentik_client import get_authentik_client
authentik = get_authentik_client()
if authentik and authentik.health_check():
    try:
        result = authentik.revoke_all_user_access(uid)
        authentik_sessions_revoked = result.get("tokens_revoked", 0)
        actions["authentik_sessions"] = result
    except Exception as e:
        actions["authentik_sessions_error"] = str(e)
else:
    actions["authentik_sessions"] = "not_configured_or_unavailable"
```

### Task 2.4: Wire Authentik Client into Deep Health Check

**File:** `src/backend/main.py` — find deep health endpoint

Add Authentik health check section (similar to LDAP/Redis checks).

### Task 2.5: Add OIDC Discovery Endpoint for Frontend

**File:** `src/backend/main.py`

Add a new endpoint that exposes OIDC config to the frontend:
```python
@app.get("/api/auth/oidc-config")
def api_auth_oidc_config():
    """Return OIDC configuration for frontend SSO login.

    - Only returns data when OIDC is configured
    - Frontend uses this to know whether to show SSO login button
    """
    if not OIDC_ISSUER or not OIDC_CLIENT_ID:
        return {"enabled": False}
    return {
        "enabled": True,
        "issuer": OIDC_ISSUER,
        "clientId": OIDC_CLIENT_ID,
        "redirectUri": OIDC_REDIRECT_URI,
        "scopes": "openid profile email entitlements",
    }
```

This keeps all OIDC config server-side — the frontend discovers it dynamically.

---

## WS3: Frontend — OIDC Login Flow

### Task 3.1: Create OIDC Utility Module

**New file:** `src/frontend/src/lib/oidc.ts`

```typescript
/**
 * OIDC Authorization Code + PKCE utilities.
 *
 * - Generates code_verifier and code_challenge (S256)
 * - Builds authorization URL
 * - Exchanges authorization code for tokens
 */
```

**Functions:**
- `generateCodeVerifier(): string` — 43-128 char random string
- `generateCodeChallenge(verifier: string): Promise<string>` — SHA256 + base64url
- `buildAuthorizationUrl(config: OidcConfig): string` — Full authorize URL with PKCE
- `exchangeCodeForTokens(config, code, verifier): Promise<TokenResponse>` — POST to token endpoint
- `generateState(): string` — Random state parameter

### Task 3.2: Add OIDC Config Query Hook

**New file:** `src/frontend/src/lib/queries/oidc.ts`

TanStack Query hook:
```typescript
/** Fetches OIDC configuration from backend. */
export function useOidcConfig() {
  return useQuery({
    queryKey: ['auth', 'oidc-config'],
    queryFn: () => fetch('/api/auth/oidc-config').then(r => r.json()),
    staleTime: 5 * 60 * 1000, // 5 min
  });
}
```

### Task 3.3: Update Auth Store

**File:** `src/frontend/src/stores/auth-store.ts`

Add alongside existing `login()`:
- `oidcLogin()` — Generates PKCE params, stores in sessionStorage, redirects to Authentik
- `handleOidcCallback(code, state)` — Validates state, exchanges code, stores tokens
- `oidcLogout()` — Clears tokens, optionally redirects to Authentik end-session
- `isOidcSession: boolean` — Distinguish OIDC vs LDAP tokens for correct logout behavior
- Token refresh logic using refresh_token (OIDC sessions only)

### Task 3.4: Create OIDC Callback Route

**New file:** `src/frontend/src/routes/auth/callback.tsx`

TanStack Router route:
```typescript
/**
 * OIDC callback handler.
 *
 * - Receives ?code=...&state=... from Authentik redirect
 * - Validates state against sessionStorage
 * - Exchanges code for tokens via PKCE
 * - Stores tokens in auth store
 * - Redirects to originally requested page (or /)
 */
```

After creating this file, run `just ui-routes` to regenerate the route tree.

### Task 3.5: Update Login Page

**File:** `src/frontend/src/routes/login.tsx`

Add below the existing LDAP login form:
- "Login with SSO" button (only shown when `useOidcConfig()` returns `enabled: true`)
- Divider between LDAP form and SSO button ("or")
- SSO button calls `authStore.oidcLogin()`

### Task 3.6: Update Route Guards

**File:** `src/frontend/src/routes/__root.tsx`

Add `/auth/callback` to `PUBLIC_ROUTES` or `PUBLIC_PREFIXES` so the callback route is accessible without auth.

---

## WS4: Database — Migration + Audit

### Task 4.1: Create Migration

**New file:** `migrations/017_authentik_sso.sql`

```sql
-- Migration 017: Authentik SSO Support
-- Adds breakglass audit table and SSO-related columns

-- Breakglass audit table (tracks emergency bypass usage)
CREATE TABLE IF NOT EXISTS breakglass_audit (
    id SERIAL PRIMARY KEY,
    activated_by VARCHAR(255) NOT NULL,
    mode VARCHAR(50) NOT NULL,
    activated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    deactivated_at TIMESTAMP WITH TIME ZONE,
    reason TEXT
);

CREATE INDEX IF NOT EXISTS idx_breakglass_audit_activated
ON breakglass_audit(activated_at DESC);

-- Add Authentik-specific columns to termination_events (if not already present)
ALTER TABLE termination_events
ADD COLUMN IF NOT EXISTS authentik_tokens_revoked INTEGER;
```

Note: `authentik_sessions_revoked` already exists on `termination_events` (found during exploration).

---

## WS5: Testing

### Task 5.1: Unit Tests — Authentik Client

**New file:** `tests/test_authentik_client.py`

- Test `health_check()` with mocked httpx responses
- Test `revoke_user_tokens()` with mocked Admin API v3 responses
- Test graceful handling when Authentik is unavailable
- Test `get_authentik_client()` returns None when config vars empty

### Task 5.2: Unit Tests — OIDC Config Endpoint

**File:** `tests/test_health.py` (or new file)

- Test `/api/auth/oidc-config` returns `enabled: false` when OIDC not configured
- Test returns correct config when OIDC vars are set

### Task 5.3: Integration Tests — Termination with Authentik

**File:** `tests/test_security.py`

- Test termination flow calls Authentik client when configured
- Test termination flow gracefully skips when Authentik unavailable
- Test `authentik_sessions_revoked` column updated in `termination_events`

### Task 5.4: E2E Test — OIDC Login Flow

**New file or addition to existing:** Manual/semi-automated test against running Authentik

- Verify OIDC login redirects to Authentik
- Verify callback exchanges code for tokens
- Verify Bearer token accepted by backend
- Verify LDAP fallback still works

---

## Implementation Order (Build Sequence)

| Step | Task | Est. | Depends On |
|------|------|------|------------|
| 1 | WS4-T4.1: Database migration | 0.5d | — |
| 2 | WS1-T1.1: Docker Compose + Authentik containers | 1d | — |
| 3 | WS1-T1.2: OIDC Provider config (+ Blueprint) | 0.5d | Step 2 |
| 4 | WS1-T1.3: LDAP Source config | 0.5d | Step 2 |
| 5 | WS1-T1.4: .env.example update | 0.25d | Step 2 |
| 6 | WS2-T2.1: Config variables | 0.25d | — |
| 7 | WS2-T2.2: Authentik client module | 1.5d | Step 6 |
| 8 | WS2-T2.3: Wire into termination flow | 0.5d | Step 7 |
| 9 | WS2-T2.4: Wire into deep health check | 0.25d | Step 7 |
| 10 | WS2-T2.5: OIDC discovery endpoint | 0.25d | Step 6 |
| 11 | WS3-T3.1: OIDC utility module | 0.5d | — |
| 12 | WS3-T3.2: OIDC config query hook | 0.25d | Step 10 |
| 13 | WS3-T3.3: Auth store updates | 1d | Steps 11, 12 |
| 14 | WS3-T3.4: Callback route | 0.5d | Step 13 |
| 15 | WS3-T3.5: Login page update | 0.5d | Steps 12, 13 |
| 16 | WS3-T3.6: Route guards update | 0.25d | Step 14 |
| 17 | WS5-T5.1: Authentik client unit tests | 0.5d | Step 7 |
| 18 | WS5-T5.2: OIDC config endpoint tests | 0.25d | Step 10 |
| 19 | WS5-T5.3: Termination integration tests | 0.5d | Steps 3, 8 |
| 20 | WS5-T5.4: E2E OIDC login test | 0.5d | Steps 3, 16 |

**Critical path:** Steps 2 → 3 → 7 → 8 → 19 (DevOps → Backend Client → Termination → Integration Test)

**Total:** ~9.5 developer days

---

## Files Changed Summary

### New Files (6)
| File | Purpose |
|------|---------|
| `src/backend/authentik_client.py` | Authentik Admin API v3 client |
| `src/frontend/src/lib/oidc.ts` | PKCE utilities for OIDC login |
| `src/frontend/src/lib/queries/oidc.ts` | TanStack Query hook for OIDC config |
| `src/frontend/src/routes/auth/callback.tsx` | OIDC callback route |
| `migrations/017_authentik_sso.sql` | Breakglass audit + termination columns |
| `tests/test_authentik_client.py` | Authentik client unit tests |

### Modified Files (8)
| File | Change |
|------|--------|
| `src/backend/config.py` | Add `AUTHENTIK_API_URL`, `AUTHENTIK_API_TOKEN`, `OIDC_CLIENT_ID`, `OIDC_REDIRECT_URI` |
| `src/backend/main.py` | Wire Authentik client into termination + health; add `/api/auth/oidc-config` |
| `src/frontend/src/stores/auth-store.ts` | Add `oidcLogin()`, `handleOidcCallback()`, `oidcLogout()`, OIDC token storage |
| `src/frontend/src/routes/login.tsx` | Add "Login with SSO" button |
| `src/frontend/src/routes/__root.tsx` | Add `/auth/callback` to public routes |
| `deploy/dev/docker-compose.yml` | Add Authentik server + worker containers |
| `deploy/dev/.env.example` | Add Authentik env vars |
| `tests/test_breakglass.py` | Add new config vars to mock config |

### Not Modified (confirmed)
| File | Reason |
|------|--------|
| `src/backend/oidc_verify.py` | Already complete — handles RS256 JWKS verification |
| `src/backend/auth.py` | LDAP bind login unchanged — OIDC login is frontend-only flow |
| `src/ued-sync/*` | No UED Sync changes — UC auth stays on LDAP Plane A |
| `src/backend/orgdb.py` | `sso_config` column already exists, schema adequate |

---

## Risks & Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Authentik LDAP Source sync delay | New users can't SSO-login for ~5min | LDAP login always available as fallback |
| Authentik container adds resource overhead | Dev environment heavier | Authentik is optional — disabled by default in compose |
| Token revocation API may change between Authentik versions | Build breaks | Pin Authentik image version; add API version check in client |
| PKCE implementation edge cases in browsers | Login fails silently | Use well-tested Web Crypto API; add error handling + logging |
| `test_breakglass.py` mock config not updated | Tests fail on import | Add to task checklist — documented in MEMORY.md |

---

## Out of Scope (Deferred)

| Item | Why Deferred |
|------|-------------|
| `uc_client.py` (UC Server session management) | No UC Server admin API exists yet — ejabberd/Asterisk admin APIs need separate research |
| Authentik Blueprint automation | Nice-to-have for dev; manual setup documented for now |
| OIDC token refresh in frontend | Phase 2 enhancement — initial implementation uses short-lived access tokens + re-login |
| Per-profile SSO policy enforcement | Requires profile↔Authentik policy mapping design |
| Password writeback configuration | Optional Authentik feature; AZBlink always writes to LDAP first |
