---
feature: single-ldap-migration
date: 2026-03-02
branch: single-ldap-migration
mode: level-3
team: []
status: in-progress
confidence: null
---

# Session Ledger: Single-LDAP Architecture Migration

> Collapse two-LDAP architecture into single LDAP with identity + UC attrs. Remove UED Sync microservice entirely.
