# WebSocket/SSE Real-Time Activity Feed — Exploration Report

## Codebase Architecture

### Backend (single-file pattern)
- `main.py` (~3200 lines) — all 82+ API endpoints, lifespan manager, auth middleware
- `orgdb.py` (~2420 lines) — SQLAlchemy Core DB operations, 63 methods
- `oidc_verify.py` (109 lines) — JWT/OIDC token verification
- `config.py` (144 lines) — env var configuration

### Key Integration Points
- **Auth:** `_claims_from_auth_header()` (main.py:245) — DEV_AUTH_TOKEN bypass + OIDC verify
- **Audit recording:** orgdb.py — `record_qr_issuance()` (L1519), `record_lifecycle_event()` (L1546), `record_admin_action()` (L1588), `record_auth_failure()` (L1938), `record_suspension_event()` (L1566)
- **Existing activity endpoint:** `GET /api/activity/recent` (main.py:3152) — transforms unified audit → ActivityEvent[]
- **Lifespan:** main.py:84 — empty `lifespan()` — needs event bus init/cleanup

### ActivityEvent Format (frontend type contract)
```ts
interface ActivityEvent {
  id: string;        // audit row ID
  type: string;      // qr-consumed | qr-generated | user-created | user-terminated | sso-enrolled | qr-expired
  text: string;      // title/summary
  meta: string;      // description
  time: string;      // relative time (e.g., "5m ago")
  timestamp: string; // ISO 8601
}
```

## Files to Modify

1. **NEW: `src/backend/event_bus.py`** — In-process asyncio event bus (Queue per subscriber)
2. **MODIFY: `src/backend/main.py`** — WS endpoint, SSE endpoint, event bus init in lifespan, import WebSocket
3. **MODIFY: `src/backend/orgdb.py`** — Add optional callback to audit recording methods
4. **MODIFY: `src/backend/config.py`** — MAX_WS_CONNECTIONS config
5. **NEW: `tests/test_activity_websocket.py`** — Integration tests for WS/SSE

## Patterns

- Auth uses `Depends(require_user/require_admin)` — NOT available for WebSocket (must extract manually)
- DEV_AUTH_TOKEN bypass: if token == DEV_AUTH_TOKEN → admin claims (critical for test fixture)
- Database: SQLAlchemy Core, `with eng.begin() as conn:` pattern
- Existing websockets 12.0+ in requirements.txt
- StreamingResponse already imported in main.py

## Team Composition
- **Backend only** — no frontend, no DB schema changes, no DevOps changes needed
