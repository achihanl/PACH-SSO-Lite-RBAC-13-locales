# Authentik-Only Auth Architecture Design

**Date:** 2026-03-04
**Status:** Approved
**Supersedes:** `2026-03-01-authentik-sso-architecture.md` (which assumed dual auth paths)

## Summary

AZBlink Directory admin UI moves to Authentik OIDC as the **sole** authentication path.
No LDAP JWT fallback. No breakglass. UC services (SIP/XMPP/VPN/MQTT) remain on direct LDAP bind.

## Architecture — Two Auth Planes

### Plane A — UC / LDAP Bind (unchanged)

```
ucChat / SIP Phones ──SIP/XMPP──▶ UC Server ──LDAP bind──▶ LDAP
VPN Clients ──VPN──▶ UC Server ──LDAP bind──▶ LDAP
MQTT Clients ──MQTT──▶ UC Server ──LDAP bind──▶ LDAP
```

- Single VM runs SIP (Asterisk), XMPP (ejabberd), VPN, MQTT
- All services share the same LDAP username/password (except SIP digest: `AstAuthPassword`)
- Zero Authentik dependency — if Authentik is down, UC services are unaffected
- No new LDAP attributes needed for VPN/MQTT

### Plane B — SSO / Authentik (sole path for all web UIs)

```
Browser ──OIDC──▶ Authentik ──LDAP Source (periodic import)──▶ LDAP
                     │
                     ├──▶ AZBlink Directory admin UI
                     ├──▶ Nextcloud → OnlyOffice
                     └──▶ SafeNest
```

- Authentik is the sole SSO gateway for all web applications
- AZBlink Directory admin UI is just another OIDC client
- OnlyOffice sits behind Nextcloud (not a direct Authentik client)
- LDAP groups map to OIDC claims for role-based access

### Bootstrap (Day-0)

- Authentik is configured via its own admin UI (port 9000) independently
- AZBlink OIDC settings are environment variables, set before first start
- `directoryctl` CLI remains for emergency LDAP/Postgres operations (no web UI needed)

## What Gets Removed

| Component | File(s) | Action |
|---|---|---|
| JWT login endpoint | `main.py` — `POST /api/auth/login` | Remove |
| JWT token generation/validation | `auth.py` | Remove |
| JWT auth middleware | `auth.py` — `get_current_user()` | Replace with OIDC-only |
| Breakglass mechanism | `main.py`, `directoryctl.py`, breakglass.json | Remove |
| `REQUIRE_OIDC_AUTH` toggle | `config.py` | Remove (OIDC always required) |
| `ALLOW_BOOTSTRAP_WITHOUT_OIDC` | `config.py` | Remove |
| Breakglass tests | `tests/test_breakglass.py` | Remove |
| LDAP bind-for-web-auth | `ldap_client.py` auth methods | Remove (keep CRUD/provisioning) |

## What Gets Added / Modified

### Backend

| Component | File | Description |
|---|---|---|
| OIDC-only middleware | `auth.py` (rewrite) | Validate Authentik OIDC Bearer tokens. Use existing `oidc_verify.py`. No fallback. |
| Authentik admin client | `authentik_client.py` (new) | API v3 client for session/token revocation on user termination |
| Termination hooks | `main.py` | Wire existing placeholder hooks to `authentik_client.py` |
| Config cleanup | `config.py` | Remove dual-mode flags. Add `AUTHENTIK_API_URL`, `AUTHENTIK_API_TOKEN`. |

### Frontend

| Component | File | Description |
|---|---|---|
| OIDC login flow | `lib/oidc.ts` (new) | PKCE code challenge, redirect to Authentik authorize endpoint |
| Auth callback route | `routes/auth/callback.tsx` (new) | Handle OIDC callback, exchange code for tokens |
| Auth store update | `stores/auth-store.ts` | Store OIDC access token instead of JWT. Refresh handling. |
| Login page | Existing login route | Replace LDAP form with "Sign in" redirect to Authentik |

### Unchanged

- LDAP provisioning (`ldap_client.py` CRUD, `provisioning.py`)
- QR code system
- Profile/template system
- UC LDAP schema and attributes
- `directoryctl` CLI (except removing breakglass commands)

## User Lifecycle — Termination

1. Admin terminates user in AZBlink UI
2. AZBlink deletes/disables LDAP entry → UC services lose auth immediately (Plane A)
3. AZBlink calls `authentik_client.py` → revoke Authentik tokens/sessions → web apps lose auth immediately (Plane B)
4. Without step 3, web sessions persist until next LDAP Source sync (~5 min)

## Scope Boundary

AZBlink Directory's implementation scope is limited to:
- Auth changes (remove JWT, add OIDC-only)
- Authentik client for termination
- Config cleanup

Everything outside AZBlink's codebase is deployment/infrastructure:
- Authentik setup and configuration
- Nextcloud / SafeNest / OnlyOffice deployment
- UC Server (SIP/XMPP/VPN/MQTT) — pre-existing VM
- LDAP server operations

## Key Environment Variables (Target State)

```bash
# OIDC (Authentik) — required
OIDC_ISSUER=https://authentik.example.com/application/o/azblink-directory/
OIDC_DISCOVERY_URL=https://authentik.example.com/application/o/azblink-directory/.well-known/openid-configuration
OIDC_CLIENT_ID=azblink-directory
OIDC_REDIRECT_URI=http://localhost:8081/auth/callback
OIDC_AUDIENCE=azblink-directory
OIDC_ADMIN_GROUP=IT-Admins

# Authentik Admin API — for termination session revocation
AUTHENTIK_API_URL=http://authentik-server:9000
AUTHENTIK_API_TOKEN=<api-token>

# Removed
# REQUIRE_OIDC_AUTH (always true now)
# ALLOW_BOOTSTRAP_WITHOUT_OIDC (removed)
```
