---
feature: xmpp-provision-e2e-verification
date: 2026-04-13
branch: xmpp-provision-e2e-verification
mode: level-3
team: []
status: in-progress
---

# Session Ledger: XMPP Provisioning E2E Verification

## Context
- AzBlink Server (PED80 VM at 192.168.122.220:8082) configured as LDAP client pointing to platform OpenLDAP (192.168.4.111:1390)
- Playbook: `playbooks/web-configure/azblink-server-ldap-client.yml` — verified 2026-04-10, 55 users found
- Goal: Verify full XMPP provisioning flow end-to-end, clean stale profiles, fix account-lock error boundary bug
- Bug: "Account locked until..." API error crashes UserListPanel via unhandled error boundary

## Scope
1. E2E test: SSO login → provision XMPP credentials → XMPP client login
2. Audit trail verification: provisioning events, activity log entries
3. Profile cleanup: remove stale/incorrect config templates, keep valid ones
4. Frontend fix: Account-lock API errors must be handled gracefully, not crash the error boundary

## Validation (2026-04-15)

### Result: ✅ SSO provisioning → UED XMPP auth chain validated end-to-end

- VM IP: `192.168.122.220` (libvirt NAT). XMPP stream advertises `from='private.z'`, SASL mechs `PLAIN, X-OAUTH2`. No STARTTLS in this dev build.
- Platform OpenLDAP exposed on `0.0.0.0:1390` — UED reaches it via LAN host IP `192.168.4.111:1390` (playbook default) or libvirt gateway `192.168.122.1:1390` (also confirmed working).
- **Pre-flight** (existing user): `alanl@private.z` / `alanl123!` SASL-PLAIN against `192.168.122.220:5222` → **AUTH OK**.
- **Fresh provision** via `just seed-uc-test-user UC_TEST_USER=xmpptest01 UC_TEST_PASSWORD='UEDprobe!23'`:
  - LDAP entry created with `userPassword:: {SSHA}…`, uid=5001, objectClasses `AsteriskPjsipEndpoint/Auth/Aor + posixAccount + azblinkUser`.
  - SASL-PLAIN bind to UED XMPP → **AUTH OK**.

### What this proves
- Dual-purpose `userPassword` (ARD-001) works for both AD login and XMPP SASL-PLAIN as designed.
- UED LDAP-client configuration (playbook `azblink-server-ldap-client.yml`) is correctly pointed at the dev LDAP.
- Fresh-user creation via platform API is immediately usable for XMPP auth without any additional sync.

### Findings worth flagging
- `tools/dev-seed-uc-user.py:177` prints `hasXmpp: False / hasSip: False` even when UC attrs are correctly written to LDAP — cosmetic false negative, filed as GitHub issue. LDAP probe or updated API field names would fix.
- `tests/test_xmpp_e2e.py` hardcodes `192.168.122.89`; the `EXTERNAL_LDAP_HOST` env var is the supported override. LDAP-based provisioning block in that test is not applicable to this UED variant (UED has no LDAP of its own — 389/636 refused).
- `vm-port-forward` is not active by default; 5222 on host is refused unless the forwarding rules are installed.

### Additional validation (2026-04-15 continued)

**Messaging between two users — ✅ PASS**
- Two slixmpp clients (`alanl`, `xmpptest01`) connected + auth'd against UED `192.168.122.220:5222`.
- Bidirectional chat stanzas delivered end-to-end. Resource strings auto-assigned by server (full JIDs like `alanl@private.z/159630086625176…`).
- Validates not just bind auth but XMPP session establishment, presence, and stanza routing.

**X-OAUTH2 SASL — ❌ FAIL (mechanism advertised but not wired to our Authentik)**
- Obtained Authentik access_token for `alanl` via M2M `client_credentials` grant (app_password intent token).
- Raw-socket XMPP stream + `<auth mechanism='X-OAUTH2'>` with 4 payload variants (localpart+JWT, bareJID+JWT, empty-user+JWT, localpart+`Bearer `+JWT) — all returned:
  ```xml
  <failure xmlns='urn:ietf:params:xml:ns:xmpp-sasl'>
    <not-authorized/><text>Invalid token</text>
  </failure>
  ```
- Identical failure across variants → not a payload-format issue. UED's OAuth2 resource-server config doesn't trust our Authentik's signing keys / issuer / audience.
- **Server identified as ejabberd (2026-04-16):** the X-OAUTH2 path routes to `ejabberd_oauth` which validates tokens against its **internal token store** by default. Authentik-issued JWTs are unknown to it. Enabling external IdP validation requires ejabberd-side config (`/etc/ejabberd/ejabberd.yml`): either an `extauth_program` calling Authentik's introspection/userinfo endpoint, or a custom/community module that validates JWTs against our JWKS (`http://authentik-server:9000/application/o/azblink-directory/jwks/`) with audience `azblink-directory`. Out of scope for this session.

### Gotchas surfaced this session

- **Seed script doesn't create Authentik users** — `tools/dev-seed-uc-user.py` with `UC_TEST_USER=<new>` creates the LDAP entry + UC attrs + profile services, but does NOT create the user in Authentik. Its docstring states the Authentik user is "assumed seeded separately by deploy/dev/authentik-seed (default: alanl)". For any username other than `alanl`, you must seed Authentik separately or SSO login will fail. SASL-PLAIN (LDAP-only) works regardless.
- **Seed script final status is a false negative** — `hasXmpp/hasSip: False` even when UC attrs are present in LDAP. Filed as issue #92.
- **X-OAUTH2 advertised ≠ X-OAUTH2 configured** — UED lists `X-OAUTH2` in SASL mechs, but it's not wired to our Authentik. Don't assume advertised = usable.

### Still open from this session's scope
- [x] XMPP auth via SASL-PLAIN — done, both existing + fresh user.
- [x] Messaging send/receive — done, bidirectional PASS.
- [ ] X-OAUTH2 SASL — mechanism advertised but not configured against our Authentik; needs UED XMPP server config (JWKS + iss + aud) to enable.
- [ ] SIP digest auth using `AstAuthPassword` — not yet tested.
- [ ] Audit-trail verification (audit events for provisioning).
- [ ] Account-lock error boundary fix (separate from XMPP validation).
