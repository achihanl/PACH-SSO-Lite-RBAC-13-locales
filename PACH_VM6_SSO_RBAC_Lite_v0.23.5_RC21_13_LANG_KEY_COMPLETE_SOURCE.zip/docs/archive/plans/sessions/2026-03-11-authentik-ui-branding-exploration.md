# Exploration Report: Authentik UI Branding

## Architecture
- Authentik 2025.8 deployed via docker-compose (server, worker, postgres, seed)
- Seed script (`deploy/dev/authentik-seed/seed_authentik.py`) handles idempotent OIDC config
- No branding currently configured — runs default Authentik theme
- AZBlink design tokens in `src/frontend/packages/azblink-ui/tokens/tokens.css`

## Files to Modify
1. `deploy/dev/authentik-seed/seed_authentik.py` — add `ensure_brand()` function
2. `deploy/dev/docker-compose.yml` — add volume mount for brand assets
3. `deploy/dev/authentik-seed/brand-assets/` — new dir for logo SVG + custom CSS
4. `deploy/dev/.env.example` — document brand-related env vars (optional)

## Key Design Tokens (AZBlink)
- Primary: `#3b82f6` (blue-500)
- Background: `#0a0a0b` (primary), `#111113` (secondary), `#18181b` (tertiary)
- Text: `#fafafa` (primary), `#a1a1aa` (secondary), `#71717a` (muted)
- Border: `#27272a` (subtle), `#3f3f46` (default)
- Font: Inter (sans), JetBrains Mono (mono)
- Dark-first theme

## Knowledge Gaps
1. **CRITICAL**: Authentik Brand API v3 schema — exact fields for PATCH `/api/v3/core/brands/{uuid}/`
2. **CRITICAL**: Authentik Custom CSS selectors — DOM structure for login flows + user interface
3. **HELPFUL**: Logo hosting strategy — data URI vs file upload vs external URL
4. **HELPFUL**: Default brand existence — always present or must create?

## Team Composition
- Backend (seed script, API calls)
- Frontend (CSS, SVG logo)
- DevOps (docker-compose volume mount — minor)

## Patterns
- Seed functions: check-if-exists → PATCH or POST (idempotent)
- `api_request()` helper: method, path, data → JSON response
- Error handling: `HTTPError` catch with body logging
