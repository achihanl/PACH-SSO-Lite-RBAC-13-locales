---
feature: fix-auth-lock-on-oidc-infra-failure
date: 2026-04-13
branch: fix-auth-lock-on-oidc-infra-failure
mode: level-3
team: [backend, test]
status: in-progress
---

# Session Ledger: Fix Auth Lock on OIDC Infrastructure Failure

## Problem Statement
When the Docker stack restarts, Authentik takes ~60s for DB migrations before its API is reachable.
During that window, OIDC token verification fails because the JWKS endpoint is unreachable.
The backend counts these as auth failures against the user, triggering the DS-1 auto-lock
(5 failures = 30-minute lockout). This means a simple stack restart can lock out all active users.

The fix: distinguish "OIDC infrastructure unavailable" (JWKS fetch failure, Authentik down) from
"genuinely bad token" (expired, tampered, wrong issuer). Only the latter should count toward
the auto-lock threshold.
