# Wave 2 Exploration Report — DS-5, DS-4, DS-7

## Scope Adjustment

Scoped to 3 issues (down from 4) for focused, safe delivery:
- **#20 DS-5**: Enforce security settings (wire stubs to logic)
- **#19 DS-4**: Self-service /api/me endpoints
- **#22 DS-7**: Admin actions audit table with decorator pattern

**Deferred:** #21 DS-6 (RBAC migration) — 65+ endpoint changes, high blast radius, deserves own PR.

## Codebase Architecture

### Auth Chain (main.py:199-336)
- `_claims_from_auth_header()` — core auth, DS-1/DS-2 auto-lock/auto-block already wired
- `require_user()` (line 297) — exists, returns any valid OIDC user claims
- `require_admin()` (line 302) — requires IT-Admins group
- `require_permission()` (line 313) — RBAC with admin fallback, TODO on uid mapping

### Settings (settingsdb.py)
- `SettingsDB` class with `get_all_settings()` / `update_settings()`
- 5 security settings defined in `SETTINGS_DEFAULTS`
- `lockoutDurationMinutes` already added in Wave 1
- **No caching** — hits DB every call
- DS-1 already reads `maxLoginAttempts` and `lockoutDurationMinutes` from settings

### Rate Limit / IP Blocking (rate_limit.py)
- `IPBlockingMiddleware` with Redis cache, already wired
- `get_client_ip()` extracts from X-Forwarded-For
- **No ipAllowlist enforcement** yet

### Frontend Auth (auth-store.ts)
- `expiresAt` field exists — set from OIDC token `exp`
- `isAuthenticated()` already checks `Date.now() < expiresAt`
- **No server-side session timeout enforcement** — only uses token expiry

### Frontend Settings Query (settings.ts)
- `settingsQueryOptions` fetches `GET /api/settings` (admin-only)
- No public settings endpoint exists

## Files to Modify

### DS-5: Enforce Security Settings
- `src/backend/settingsdb.py` — add in-memory cache with 60s TTL
- `src/backend/main.py` — add `GET /api/settings/security` (public), wire `auditApiRequests`
- `src/backend/rate_limit.py` — wire `ipAllowlist` bypass in IPBlockingMiddleware
- `src/frontend/src/stores/auth-store.ts` — fetch session timeout, enforce locally
- `src/frontend/src/lib/queries/settings.ts` — add public security settings query

### DS-4: Self-Service /api/me
- `src/backend/main.py` — 5 new endpoints under /api/me
- `src/backend/ldap_client.py` — self-lookup by uid (already exists via get_user)
- `src/backend/orgdb.py` — device/QR listing by user uid

### DS-7: Admin Actions Audit
- `src/backend/orgdb.py` — new table, `record_admin_action()` method
- `src/backend/main.py` — `@audit_action()` decorator on admin CRUD endpoints
- `migrations/` — new migration for admin_action_audit table
- Update `list_unified_audit()` UNION ALL

## Patterns & Conventions

- Backend: FastAPI + Depends() for auth, Pydantic for validation
- DB: SQLAlchemy Core text() queries
- Audit: Append-only tables, UNION ALL in `list_unified_audit()`
- External clients: `authentik_client.py` pattern (async HTTP, graceful degradation)
- Settings: Section/key/value pattern in `app_settings` table
- Frontend: TanStack Query for data fetching, Zustand for state

## Knowledge Gaps

1. **FastAPI middleware ordering** — need to understand LIFO order for request logging
   - Priority: helpful (not blocking)
   - Source: FastAPI docs

2. **Zustand + periodic fetching** — how to poll server settings periodically
   - Priority: helpful
   - Solution: TanStack Query `refetchInterval` already handles this

## Team Composition

- **Backend**: Yes — all 3 issues are primarily backend
- **Frontend**: Limited — only DS-5 session timeout enforcement
- **Database**: Yes — new migration for DS-7
- **DevOps**: No
- **Test**: Yes — integration tests for all features
