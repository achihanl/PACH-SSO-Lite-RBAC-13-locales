# Exploration Report: Authentik-Only Auth — Fullstack OIDC Migration

**Date:** 2026-03-04
**Explorer:** feature-dev:code-explorer

## Key Findings

### Backend Auth Flow (Current State)
- `auth.py` (207 lines): LDAP bind auth + JWT generation — **DELETE entirely**
- `oidc_verify.py` (101 lines): OIDC token verification — **KEEP, already works**
- `main.py:163-304`: Breakglass + dual-mode auth middleware — **SIMPLIFY to OIDC-only**
- `main.py:370-393`: `POST /api/auth/login` endpoint — **REMOVE**
- `main.py:1417-1425`: Termination Authentik placeholders — **WIRE to real client**
- `config.py:43-76,85`: JWT/breakglass/toggle config vars — **REMOVE**

### Frontend Auth Flow (Current State)
- `auth-store.ts` (127 lines): JWT `login()` calls `/api/auth/login`, `rememberMe` storage switching — **REWRITE for OIDC**
- `api-client.ts` (102 lines): `getAuthToken()` injects Bearer token — **MINIMAL changes** (already works with Bearer)
- `login.tsx` (145 lines): Full LDAP credential form — **REPLACE with SSO redirect button**
- `__root.tsx:20-21`: PUBLIC_ROUTES/PREFIXES — **ADD `/auth/callback`**
- `main.tsx:27-34`: onUnauthorized handler — **MINOR update**
- `session-expired-modal.tsx` (57 lines): Redirects to /login — **UPDATE to use OIDC redirect**
- `profile-dropdown.tsx:43-45`: `logout()` + navigate — **Works as-is after store rewrite**

### Test Infrastructure (Critical Path)
- `conftest.py:104-110`: `auth_headers` fixture calls `/api/auth/login` for JWT — **REWRITE to mock OIDC**
- `test_auth.py` (77 lines): All 5 tests test JWT login — **DELETE entirely**
- `test_breakglass.py`: Tests breakglass — **DELETE entirely**
- **~120+ test references** to `auth_headers` across 6 test files — all depend on the fixture

### Primitives Available in @azblink/ui
- Card, CardHeader, CardContent, CardTitle, CardDescription ✓
- Button, Input, Label, Checkbox ✓
- AlertDialog, AlertDialogAction, AlertDialogContent, etc. ✓
- All primitives already used by current login.tsx

## Team Composition
- **backend** — auth middleware rewrite, Authentik client, config cleanup
- **frontend** — OIDC PKCE flow, auth store, login page, callback route
- **test** — conftest fixture rewrite, auth test migration

## Knowledge Gaps
1. OIDC PKCE flow in browser (Web Crypto API) — Critical
2. Authentik Admin API v3 exact endpoints — Critical
3. TanStack Router callback route setup — Helpful
4. Zustand persist after storage simplification — Helpful

## Files Summary
- **Delete:** `auth.py`, `test_breakglass.py`, `test_auth.py`
- **Create:** `authentik_client.py`, `test_authentik_client.py`, `lib/oidc.ts`, `routes/auth/callback.tsx`
- **Rewrite:** `auth-store.ts`, `login.tsx`
- **Major modify:** `main.py`, `config.py`, `conftest.py`, `directoryctl.py`
- **Minor modify:** `__root.tsx`, `main.tsx`, `session-expired-modal.tsx`, `.env.example`, `docker-compose.yml`
