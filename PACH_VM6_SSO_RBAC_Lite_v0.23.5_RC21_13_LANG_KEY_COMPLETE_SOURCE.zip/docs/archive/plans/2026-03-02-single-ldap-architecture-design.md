# Single-LDAP Architecture Design

**Date:** 2026-03-02
**Status:** Approved
**Supersedes:** Two-LDAP architecture (AD LDAP + UED LDAP), UED Sync microservice

## Problem Statement

The original architecture assumed XMPP/SIP services would each have their own dedicated LDAP server, requiring a UED Sync microservice to relay user events from AD Directory to those separate LDAPs. This introduced:

- An entire microservice (`src/ued-sync/`) with its own container, 215+ tests, and HTTP API
- An async event queue (`sync_events` table) with background worker, retry logic, and encryption
- Discovery protocol, API key management, and Fernet encryption for service-to-service auth
- Eventually consistent provisioning (UC credentials not available until worker processed the event)

**The realization:** We don't need separate LDAP servers. The XMPP/SIP schemas can be loaded directly into AD's OpenLDAP, and UC attributes can be written onto the same `inetOrgPerson` entry at user creation time.

## Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| LDAP topology | Single LDAP (AD owns all) | Eliminates sync layer entirely |
| UC schema | `pjsip-combined` only | Modern Asterisk + XMPP; drop legacy `sip-legacy` and standalone `xmpp-only` |
| Provisioning model | Always provision UC at creation | If profile has xmpp/sip enabled, attrs added at creation — no second step |
| Write strategy | Single atomic LDAP ADD | One operation writes identity + UC attrs; if LDAP down, creation fails (correct) |
| Profile evolution | Keep profiles, strip UED fields | Profiles still group orgs, manage allocation, hold service endpoints |
| Service toggles | `xmpp_enabled` + `sip_enabled` per profile | Finer control than single `uc_enabled`; no "UED" concept |
| LDAP schema loading | Ship LDIF files, load at container init | Identical between dev and prod |
| UED Sync codebase | Archive to branch, delete from main | Preserve for reference, clean break |

## Architecture: Before vs After

### Before (Two-LDAP)
```
AD Directory ──owns──▶ LDAP-A (inetOrgPerson identity)
     │
     │ async event queue → sync_worker → HTTP → UED Sync API
     ▼
UED Sync ────owns──▶ LDAP-B (posixAccount + SIP/XMPP)
```

### After (Single-LDAP)
```
AD Directory ──owns──▶ LDAP (inetOrgPerson + posixAccount + AsteriskPjsip*)
     │                       ▲                    ▲
     │                       │                    │
     │               ejabberd binds here   Asterisk binds here
     │               (XMPP auth)          (SIP realtime)
     │
     └── Direct LDAP write at user creation (synchronous, atomic)
```

## Merged LDAP Entry Structure

When a user is created with `xmpp_enabled=true` and/or `sip_enabled=true`:

**DN:** `uid={username},ou=<org-path>,ou=people,dc=azblink,dc=com`

**ObjectClasses:**
```
# Identity (always)
top, person, organizationalPerson, inetOrgPerson

# POSIX (when xmpp_enabled OR sip_enabled)
account, posixAccount

# SIP (when sip_enabled)
AsteriskPjsipEndpoint, AsteriskPjsipAuth, AsteriskPjsipAor
```

### Identity Attributes (always present)

| Attribute | Source |
|-----------|--------|
| `uid` | Username from creation request |
| `cn` | Display name |
| `sn` | Surname (extracted) |
| `givenName` | First name (extracted) |
| `userPassword` | SSHA hash — serves as AD login AND XMPP bind credential |
| `mail` | Optional |
| `mobile` | Optional |
| `title`, `employeeNumber`, `manager` | Optional identity fields |

### POSIX Attributes (when xmpp OR sip enabled)

| Attribute | Value |
|-----------|-------|
| `uidNumber` | Allocated from profile counter (atomic `UPDATE...RETURNING`) |
| `gidNumber` | Static: `1000` |
| `homeDirectory` | `/home/{username}` |
| `loginShell` | `/bin/bash` |

### SIP Attributes (when sip_enabled)

| Attribute | Value |
|-----------|-------|
| `AstEndpointContext` | `from-internal` |
| `AstEndpointAllow` | `!all,ulaw,alaw,opus` |
| `AstEndpointDisallow` | `all` |
| `AstEndpointTransport` | `transport-udp` |
| `AstEndpointAors` | `{username}` |
| `AstEndpointAuth` | `{username}` |
| `AstAuthType` | `userpass` |
| `AstAuthUsername` | `{username}` |
| `AstAuthPassword` | Generated 24-char random SIP password |
| `AstAuthRealm` | Configurable (default: `asterisk`) |
| `AstAorMaxContacts` | `1` |
| `AstAorRemoveExisting` | `yes` |
| `AstAorQualifyFrequency` | `60` |

### Credential Model

| Credential | Storage | Purpose |
|------------|---------|---------|
| Login password | `userPassword` (SSHA) | AD Directory login + XMPP LDAP bind auth |
| SIP password | `AstAuthPassword` (plaintext) | Asterisk PJSIP digest auth (separate from login) |
| SIP extension | Allocated from profile range | SIP registration identity |

## Profile (config_templates) Schema Changes

### New Fields

| Field | Type | Purpose |
|-------|------|---------|
| `xmpp_enabled` | `BOOLEAN DEFAULT false` | Add XMPP-capable attrs on user creation |
| `sip_enabled` | `BOOLEAN DEFAULT false` | Add SIP attrs on user creation |
| `xmpp_domain` | `TEXT` | Client-facing XMPP domain (for QR codes) |
| `xmpp_ws_url` | `TEXT` | XMPP WebSocket URL (for QR codes) |
| `sip_domain` | `TEXT` | Client-facing SIP domain (for QR codes) |
| `sip_wss_url` | `TEXT` | SIP WebSocket URL (for QR codes) |

### Removed Fields (UED connector)

- `ued_api_url`, `ued_api_key_enc`, `ued_enabled`
- `discovered_schema_name`, `discovered_at`, `discovered_capabilities`, `discovered_service_endpoints`
- `last_sync_at`, `last_error`

### Retained Fields

- `next_uid_number`, `uid_range_start`, `uid_range_end` — POSIX UID allocation
- `next_extension`, `ext_range_start`, `ext_range_end` — SIP extension allocation
- `qr_settings` — QR code generation config
- `sso_config` — Authentik/OIDC policy
- `name`, `description`, `template_type`, `status` — identity

### Dropped Tables

- `sync_events` — no more async event queue

### Migration

`migrations/017_single_ldap.sql` — adds new fields, drops UED fields, drops `sync_events`.

## Provisioning Flow

```
POST /api/users/create { username, password, org, profileId, ... }
  │
  ├─ 1. Load profile from config_templates
  │     → Get xmpp_enabled, sip_enabled, service endpoints, allocation ranges
  │
  ├─ 2. If xmpp_enabled OR sip_enabled:
  │     a. Allocate uid_number (atomic UPDATE...RETURNING)
  │     b. If sip_enabled: allocate extension, generate sip_password (24-char random)
  │
  ├─ 3. Build merged LDAP attribute set:
  │     objectClasses = [inetOrgPerson chain]
  │     attrs = { uid, cn, sn, givenName, userPassword, ... }
  │     if xmpp_enabled or sip_enabled:
  │       objectClasses += [account, posixAccount]
  │       attrs += { uidNumber, gidNumber, homeDirectory, loginShell }
  │     if sip_enabled:
  │       objectClasses += [AsteriskPjsipEndpoint, AsteriskPjsipAuth, AsteriskPjsipAor]
  │       attrs += { AstEndpoint*, AstAuth*, AstAor* }
  │
  ├─ 4. ldap_client.create_user(dn, objectClasses, attrs)
  │     → Single atomic LDAP ADD operation
  │
  ├─ 5. orgdb.record_lifecycle_event()
  │
  └─ 6. Return response with provisioning result:
        {
          "ok": true, "dn": "...", "uid": "alice",
          "provisioning": {
            "xmpp_enabled": true,
            "sip_enabled": true,
            "uid_number": 10001,
            "extension": 1001,
            "sip_password": "xF7k!m@nP9zA...",
            "xmpp_domain": "xmpp.example.com",
            "sip_domain": "sip.example.com"
          }
        }
```

## Code Changes

### Backend — Delete

| File | Reason |
|------|--------|
| `src/backend/sync_worker.py` | No async sync needed |
| `src/backend/ued_sync_client.py` | No UED HTTP calls |
| `src/backend/ued_discovery.py` | No UED discovery |
| `src/backend/ued_crypto.py` | No API key encryption |

### Backend — Refactor

| File | Changes |
|------|---------|
| `src/backend/ldap_client.py` | Add UC attribute building logic (from pjsip.py schema factory) |
| `src/backend/provisioning.py` | Keep allocation logic; remove sync payload building and UED references |
| `src/backend/main.py` | Remove: sync endpoints, UED discovery endpoints, emit_sync_event. Refactor: user creation to use direct LDAP write with UC attrs |
| `src/backend/orgdb.py` | Remove sync_events ops; update profile queries for new fields |
| `src/backend/config.py` | Remove UED env vars; add SIP_AUTH_REALM (if not already present) |

### Archive to Branch

| Item | Target |
|------|--------|
| `src/ued-sync/` (entire directory) | Branch `archive/ued-sync-v1` |
| `deploy/dev/Dockerfile.ued-sync` | Archived with UED |

### Docker Cleanup

| Item | Action |
|------|--------|
| `ued-sync` service in `docker-compose.yml` | Remove |
| UED env vars in `.env.example` | Remove |
| UED-related `just` recipes | Remove |
| Asterisk PJSIP LDIF schema | Add to `deploy/ldap-schemas/` and mount in OpenLDAP init |

### Frontend

| Area | Action |
|------|--------|
| Profile form | Remove UED connector fields; add `xmpp_enabled`/`sip_enabled` toggles + service endpoint inputs |
| Sync events page/panel | Remove entirely |
| UED discovery UI | Remove entirely |
| API types | Remove UED types; add new profile fields |

### Tests

| Area | Action |
|------|--------|
| Backend integration tests | Update provisioning tests for direct LDAP write |
| UED Sync tests | Archived with module |
| New e2e test | Verify XMPP bind + SIP registration against real servers using pjsip-combined attrs on AD's LDAP |

## LDAP Schema Loading

Ship Asterisk PJSIP LDIF schema files with the project:
- `deploy/ldap-schemas/asterisk-pjsip.ldif` — defines `AsteriskPjsipEndpoint`, `AsteriskPjsipAuth`, `AsteriskPjsipAor` objectClasses and attributes
- Loaded during OpenLDAP container initialization (volume mount to `/etc/ldap/schema/` or custom entrypoint)
- Identical mechanism in dev and prod — no manual admin step

## QR Code Impact

QR code content assembly changes:
- **Before:** Service endpoints pulled from UED discovery cache on profile (`discovered_service_endpoints` JSONB)
- **After:** Service endpoints read directly from profile fields (`xmpp_domain`, `sip_domain`, etc.)
- QR JSON structure unchanged — just the source of the values changes

## CLAUDE.md Updates Required

After implementation:
- Update "Two-LDAP Architecture" section → "Single-LDAP Architecture"
- Remove all UED Sync references from architecture, endpoints, patterns
- Update profile field documentation
- Update provisioning flow documentation
- Remove UED-related commands from dev commands section
