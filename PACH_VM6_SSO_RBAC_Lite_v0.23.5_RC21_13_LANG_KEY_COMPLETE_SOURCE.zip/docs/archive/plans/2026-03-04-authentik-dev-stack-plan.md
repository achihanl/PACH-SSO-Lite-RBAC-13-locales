# Authentik Dev Stack Integration — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add Authentik as a local dev IdP to the docker-compose stack so OIDC login works end-to-end.

**Architecture:** Three new Docker services (authentik-postgres, authentik-server, authentik-worker) join the existing dev stack. A Python seed script runs once to create the OAuth2 provider + application + admin group via the Authentik Admin API. Cloudflare tunnel exposes Authentik at `authentik.keithmoc.dev`.

**Tech Stack:** Docker Compose, Authentik 2025.8, Python 3 (urllib), Cloudflare Tunnel

**Design doc:** `docs/plans/2026-03-04-authentik-dev-stack-design.md`

---

### Task 1: Add Authentik Services to Docker Compose

**Files:**
- Modify: `deploy/dev/docker-compose.yml`

**Step 1: Add authentik-postgres service**

Insert before the `volumes:` section at line 223:

```yaml
  # Authentik IdP — PostgreSQL (separate from AZBlink's to avoid migration conflicts)
  authentik-postgres:
    networks:
      - azblink-net
    image: postgres:16-alpine
    container_name: azblink-authentik-postgres
    environment:
      POSTGRES_DB: authentik
      POSTGRES_USER: authentik
      POSTGRES_PASSWORD: ${AUTHENTIK_PG_PASS:-authentik-dev-password}
    volumes:
      - authentik_pg_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -d authentik -U authentik"]
      interval: 5s
      timeout: 5s
      retries: 5
    restart: unless-stopped
```

**Step 2: Add authentik-server service**

Insert after authentik-postgres:

```yaml
  # Authentik IdP — Server (OIDC provider, admin UI)
  authentik-server:
    networks:
      - azblink-net
      - cloudflare-tunnel
    image: ghcr.io/goauthentik/server:2025.8
    container_name: azblink-authentik-server
    command: server
    environment:
      AUTHENTIK_SECRET_KEY: ${AUTHENTIK_SECRET_KEY:-dev-authentik-secret-key-change-in-prod-minimum-50-chars!!}
      AUTHENTIK_POSTGRESQL__HOST: authentik-postgres
      AUTHENTIK_POSTGRESQL__NAME: authentik
      AUTHENTIK_POSTGRESQL__USER: authentik
      AUTHENTIK_POSTGRESQL__PASSWORD: ${AUTHENTIK_PG_PASS:-authentik-dev-password}
      AUTHENTIK_REDIS__HOST: redis
      AUTHENTIK_BOOTSTRAP_PASSWORD: ${AUTHENTIK_BOOTSTRAP_PASSWORD:-adminpassword}
      AUTHENTIK_BOOTSTRAP_EMAIL: ${AUTHENTIK_BOOTSTRAP_EMAIL:-admin@azblink.local}
      AUTHENTIK_BOOTSTRAP_TOKEN: ${AUTHENTIK_BOOTSTRAP_TOKEN:-dev-authentik-api-token}
      AUTHENTIK_ERROR_REPORTING__ENABLED: "false"
      AUTHENTIK_LOG_LEVEL: info
    ports:
      - "9000:9000"
      - "9443:9443"
    depends_on:
      authentik-postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    restart: unless-stopped
```

Note: Authentik 2025.8 still requires Redis — we reuse AZBlink's existing Redis service.

**Step 3: Add authentik-worker service**

Insert after authentik-server:

```yaml
  # Authentik IdP — Worker (background tasks)
  authentik-worker:
    networks:
      - azblink-net
    image: ghcr.io/goauthentik/server:2025.8
    container_name: azblink-authentik-worker
    command: worker
    environment:
      AUTHENTIK_SECRET_KEY: ${AUTHENTIK_SECRET_KEY:-dev-authentik-secret-key-change-in-prod-minimum-50-chars!!}
      AUTHENTIK_POSTGRESQL__HOST: authentik-postgres
      AUTHENTIK_POSTGRESQL__NAME: authentik
      AUTHENTIK_POSTGRESQL__USER: authentik
      AUTHENTIK_POSTGRESQL__PASSWORD: ${AUTHENTIK_PG_PASS:-authentik-dev-password}
      AUTHENTIK_REDIS__HOST: redis
      AUTHENTIK_BOOTSTRAP_PASSWORD: ${AUTHENTIK_BOOTSTRAP_PASSWORD:-adminpassword}
      AUTHENTIK_BOOTSTRAP_EMAIL: ${AUTHENTIK_BOOTSTRAP_EMAIL:-admin@azblink.local}
      AUTHENTIK_BOOTSTRAP_TOKEN: ${AUTHENTIK_BOOTSTRAP_TOKEN:-dev-authentik-api-token}
      AUTHENTIK_ERROR_REPORTING__ENABLED: "false"
    depends_on:
      authentik-postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    restart: unless-stopped
```

**Step 4: Add authentik_pg_data volume**

Add to the `volumes:` section:

```yaml
  authentik_pg_data:
```

**Step 5: Verify compose file is valid**

Run: `cd deploy/dev && docker compose config --quiet && echo "VALID"`
Expected: `VALID` (no errors)

**Step 6: Commit**

```bash
git add deploy/dev/docker-compose.yml
git commit -m "feat: add Authentik IdP services to dev docker-compose"
```

---

### Task 2: Create Authentik Seed Script

**Files:**
- Create: `deploy/dev/authentik-seed/seed_authentik.py`

**Step 1: Write the seed script**

This script waits for Authentik to be healthy, then creates:
1. OAuth2 provider (public client, PKCE)
2. Application linked to provider
3. IT-Admins group with akadmin assigned

```python
#!/usr/bin/env python3
"""
Seed Authentik with AZBlink OIDC application config.

Idempotent — safe to run multiple times.
Runs once after Authentik server is healthy.
"""

import json
import os
import sys
import time
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

API_URL = os.getenv("AUTHENTIK_API_URL", "http://authentik-server:9000")
API_TOKEN = os.getenv("AUTHENTIK_BOOTSTRAP_TOKEN", "dev-authentik-api-token")
MAX_RETRIES = 30
RETRY_DELAY = 5

# OAuth2 provider config
CLIENT_ID = "azblink-directory"
REDIRECT_URIS = "\n".join([
    "http://192.168.4.111:8081/auth/callback",
    "https://azblink-ad.keithmoc.dev/auth/callback",
    "http://localhost:8081/auth/callback",
])
APP_SLUG = "azblink-directory"
APP_NAME = "AZBlink Directory"
ADMIN_GROUP_NAME = "IT-Admins"


def api_request(method: str, path: str, data: dict | None = None) -> dict | None:
    """Make an authenticated request to Authentik Admin API v3."""
    url = f"{API_URL}/api/v3{path}"
    headers = {
        "Authorization": f"Bearer {API_TOKEN}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    body = json.dumps(data).encode() if data else None
    req = Request(url, data=body, headers=headers, method=method)
    try:
        with urlopen(req, timeout=30) as resp:
            if resp.status == 204:
                return None
            return json.loads(resp.read().decode())
    except HTTPError as e:
        body = e.read().decode() if e.fp else ""
        print(f"  API error {e.code}: {body[:500]}", file=sys.stderr)
        raise


def wait_for_authentik():
    """Wait for Authentik API to be reachable."""
    print(f"Waiting for Authentik at {API_URL}...")
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            req = Request(
                f"{API_URL}/api/v3/root/config/",
                headers={"Authorization": f"Bearer {API_TOKEN}"},
            )
            with urlopen(req, timeout=5) as resp:
                if resp.status == 200:
                    print(f"  Authentik ready (attempt {attempt})")
                    return
        except (URLError, OSError) as e:
            print(f"  Attempt {attempt}/{MAX_RETRIES}: {e}")
        time.sleep(RETRY_DELAY)
    print("ERROR: Authentik did not become ready", file=sys.stderr)
    sys.exit(1)


def get_authorization_flow_pk() -> str:
    """Find the default authorization flow."""
    resp = api_request("GET", "/flows/instances/?designation=authorization")
    results = resp.get("results", [])
    for flow in results:
        if "default-provider-authorization" in flow.get("slug", ""):
            print(f"  Found authorization flow: {flow['slug']} (pk={flow['pk']})")
            return flow["pk"]
    if results:
        print(f"  Using first authorization flow: {results[0]['slug']}")
        return results[0]["pk"]
    raise RuntimeError("No authorization flow found — is Authentik properly initialized?")


def ensure_oauth2_provider() -> int:
    """Create or find the OAuth2 provider. Returns provider pk."""
    # Check if already exists
    resp = api_request("GET", f"/providers/oauth2/?client_id={CLIENT_ID}")
    results = resp.get("results", [])
    if results:
        pk = results[0]["pk"]
        print(f"  OAuth2 provider already exists (pk={pk})")
        return pk

    # Create new
    flow_pk = get_authorization_flow_pk()
    data = {
        "name": f"{APP_NAME} OIDC",
        "authorization_flow": flow_pk,
        "client_type": "public",
        "client_id": CLIENT_ID,
        "redirect_uris": REDIRECT_URIS,
        "access_token_validity": "hours=8",
        "refresh_token_validity": "days=7",
        "property_mappings": [],
        "sub_mode": "hashed_user_id",
        "include_claims_in_id_token": True,
    }
    resp = api_request("POST", "/providers/oauth2/", data)
    pk = resp["pk"]
    print(f"  Created OAuth2 provider (pk={pk})")
    return pk


def ensure_application(provider_pk: int):
    """Create or find the application linked to the provider."""
    resp = api_request("GET", f"/core/applications/?slug={APP_SLUG}")
    results = resp.get("results", [])
    if results:
        print(f"  Application '{APP_SLUG}' already exists")
        return

    data = {
        "name": APP_NAME,
        "slug": APP_SLUG,
        "provider": provider_pk,
        "meta_launch_url": "https://azblink-ad.keithmoc.dev/",
    }
    api_request("POST", "/core/applications/", data)
    print(f"  Created application '{APP_SLUG}'")


def ensure_admin_group():
    """Create IT-Admins group and assign akadmin user."""
    # Check if group exists
    resp = api_request("GET", f"/core/groups/?name={ADMIN_GROUP_NAME}")
    results = resp.get("results", [])
    if results:
        group_pk = results[0]["pk"]
        print(f"  Group '{ADMIN_GROUP_NAME}' already exists (pk={group_pk})")
    else:
        resp = api_request("POST", "/core/groups/", {
            "name": ADMIN_GROUP_NAME,
            "is_superuser": False,
        })
        group_pk = resp["pk"]
        print(f"  Created group '{ADMIN_GROUP_NAME}' (pk={group_pk})")

    # Find akadmin user
    resp = api_request("GET", "/core/users/?username=akadmin")
    users = resp.get("results", [])
    if not users:
        print("  WARNING: akadmin user not found — skipping group assignment")
        return

    user_pk = users[0]["pk"]
    user_groups = [g["pk"] for g in users[0].get("groups_obj", [])]

    if group_pk in user_groups:
        print(f"  akadmin already in '{ADMIN_GROUP_NAME}'")
        return

    # Add user to group
    user_groups.append(group_pk)
    api_request("PATCH", f"/core/users/{user_pk}/", {"groups": user_groups})
    print(f"  Added akadmin to '{ADMIN_GROUP_NAME}'")


def main():
    print("=" * 60)
    print("Authentik Seed: AZBlink OIDC Application Setup")
    print("=" * 60)

    wait_for_authentik()

    print("\n1. Ensuring OAuth2 provider...")
    provider_pk = ensure_oauth2_provider()

    print("\n2. Ensuring application...")
    ensure_application(provider_pk)

    print("\n3. Ensuring admin group...")
    ensure_admin_group()

    print("\n" + "=" * 60)
    print("Authentik seed complete!")
    print(f"  OIDC Issuer: {API_URL}/application/o/{APP_SLUG}/")
    print(f"  Client ID:   {CLIENT_ID}")
    print(f"  Admin group: {ADMIN_GROUP_NAME}")
    print("=" * 60)


if __name__ == "__main__":
    main()
```

**Step 2: Commit**

```bash
git add deploy/dev/authentik-seed/seed_authentik.py
git commit -m "feat: Authentik OIDC seed script — creates provider, app, admin group"
```

---

### Task 3: Add Authentik Seed Service to Docker Compose

**Files:**
- Modify: `deploy/dev/docker-compose.yml`

**Step 1: Add authentik-seed service**

Insert after the `authentik-worker` service:

```yaml
  # One-time Authentik OIDC app setup
  authentik-seed:
    networks:
      - azblink-net
    image: python:3.11-slim
    container_name: azblink-authentik-seed
    volumes:
      - ./authentik-seed:/seed:ro
    working_dir: /seed
    command: ["python3", "seed_authentik.py"]
    environment:
      AUTHENTIK_API_URL: http://authentik-server:9000
      AUTHENTIK_BOOTSTRAP_TOKEN: ${AUTHENTIK_BOOTSTRAP_TOKEN:-dev-authentik-api-token}
    depends_on:
      authentik-server:
        condition: service_started
    restart: "no"
```

**Step 2: Verify compose file**

Run: `cd deploy/dev && docker compose config --quiet && echo "VALID"`
Expected: `VALID`

**Step 3: Commit**

```bash
git add deploy/dev/docker-compose.yml
git commit -m "feat: add Authentik seed container to docker-compose"
```

---

### Task 4: Configure Environment Variables

**Files:**
- Modify: `deploy/dev/.env`
- Modify: `deploy/dev/.env.example`

**Step 1: Add Authentik + OIDC vars to `.env`**

Append to `deploy/dev/.env`:

```bash
# Authentik IdP (dev instance)
AUTHENTIK_PG_PASS=authentik-dev-password
AUTHENTIK_SECRET_KEY=dev-authentik-secret-key-change-in-prod-minimum-50-chars!!
AUTHENTIK_BOOTSTRAP_PASSWORD=adminpassword
AUTHENTIK_BOOTSTRAP_EMAIL=admin@azblink.local
AUTHENTIK_BOOTSTRAP_TOKEN=dev-authentik-api-token

# Backend OIDC (Docker-internal URLs — for token verification)
OIDC_ISSUER=http://authentik-server:9000/application/o/azblink-directory/
OIDC_AUDIENCE=azblink-directory
OIDC_ADMIN_GROUP=IT-Admins
OIDC_GROUPS_CLAIM=groups
AUTHENTIK_API_URL=http://authentik-server:9000
AUTHENTIK_API_TOKEN=dev-authentik-api-token

# Frontend OIDC (browser-accessible URLs — Cloudflare tunnel)
VITE_OIDC_ISSUER=https://authentik.keithmoc.dev/application/o/azblink-directory/
VITE_OIDC_CLIENT_ID=azblink-directory
VITE_OIDC_REDIRECT_URI=https://azblink-ad.keithmoc.dev/auth/callback
VITE_OIDC_ADMIN_GROUP=IT-Admins
```

**Step 2: Update `.env.example` with Authentik section**

Add a corresponding section to `deploy/dev/.env.example` with the Authentik variables (using placeholder values and comments).

**Step 3: Commit**

```bash
git add deploy/dev/.env deploy/dev/.env.example
git commit -m "feat: populate Authentik and OIDC environment variables"
```

---

### Task 5: Add Cloudflare Tunnel Ingress for Authentik

**Files:**
- Modify: `~/_WORKSPACES_/cloudflare-tunnel/ingress.d/azblink.yml`

Note: This file is outside the AZBlink repo. It lives in the Cloudflare tunnel repo.

**Step 1: Add Authentik hostname to the existing azblink.yml**

The existing file routes `azblink-ad.keithmoc.dev` → Traefik. Add a second rule for Authentik:

```yaml
# Stack: azblink
# Maintainer: Keith
# Last updated: 2026-03-04
#
# AZBlink Directory Service + Authentik IdP
# Repository: ~/_WORKSPACES_/azb-azblink-directory-and-identity-stack

ingress:
  # AZBlink Directory UI/API (via Traefik proxy)
  - hostname: azblink-ad.keithmoc.dev
    service: http://azblink-traefik:80
    originRequest:
      connectTimeout: 30s
      noTLSVerify: true
  # Authentik IdP (direct, no Traefik)
  - hostname: authentik.keithmoc.dev
    service: http://azblink-authentik-server:9000
    originRequest:
      connectTimeout: 30s
      noTLSVerify: true
```

**Step 2: Regenerate tunnel config and reload**

Run: `cd ~/_WORKSPACES_/cloudflare-tunnel && just reload`
Expected: Generated config includes the new `authentik.keithmoc.dev` route.

**Step 3: Verify DNS**

The Cloudflare tunnel should auto-create the DNS record. Verify:

Run: `curl -s -o /dev/null -w "%{http_code}" --connect-timeout 10 https://authentik.keithmoc.dev/`
Expected: `200` or `302` (Authentik redirect to setup/login)

Note: If DNS propagation hasn't completed, this may initially return `000`. Wait 1-2 minutes.

**Step 4: Commit the Cloudflare tunnel changes**

```bash
cd ~/_WORKSPACES_/cloudflare-tunnel
git add ingress.d/azblink.yml
git commit -m "feat: add authentik.keithmoc.dev ingress for AZBlink IdP"
```

---

### Task 6: Bring Up the Stack and Verify

**Step 1: Stop the existing stack**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack && just down`

**Step 2: Start with full rebuild**

Run: `just up`
Expected: All services start. Watch for:
- `azblink-authentik-postgres` healthy
- `azblink-authentik-server` starts (may take 30-60s for first migration)
- `azblink-authentik-worker` starts
- `azblink-authentik-seed` runs and exits with success

**Step 3: Watch seed script output**

Run: `docker logs -f azblink-authentik-seed`
Expected output:
```
============================================================
Authentik Seed: AZBlink OIDC Application Setup
============================================================
Waiting for Authentik at http://authentik-server:9000...
  Authentik ready (attempt N)

1. Ensuring OAuth2 provider...
  Found authorization flow: ...
  Created OAuth2 provider (pk=...)

2. Ensuring application...
  Created application 'azblink-directory'

3. Ensuring admin group...
  Created group 'IT-Admins' (pk=...)
  Added akadmin to 'IT-Admins'

============================================================
Authentik seed complete!
  OIDC Issuer: http://authentik-server:9000/application/o/azblink-directory/
  Client ID:   azblink-directory
  Admin group: IT-Admins
============================================================
```

**Step 4: Verify Authentik OIDC discovery**

Run: `curl -s http://localhost:9000/application/o/azblink-directory/.well-known/openid-configuration | python3 -m json.tool | head -10`
Expected: JSON with `issuer`, `authorization_endpoint`, `token_endpoint`, `jwks_uri`, etc.

**Step 5: Verify backend can reach Authentik**

Run: `curl -s -H "Authorization: Bearer dev-test-token" http://localhost:8081/api/health/deep | python3 -m json.tool`
Expected: All services healthy.

**Step 6: Run test suite**

Run: `python -m pytest tests/ -q`
Expected: 299 passed, 6 skipped (tests use DEV_AUTH_TOKEN, unaffected by Authentik)

**Step 7: Commit**

No code changes in this task — this is verification only.

---

### Task 7: End-to-End OIDC Login Test (Manual)

This is a manual browser verification. No code changes.

**Step 1: Open the login page**

Navigate to: `https://azblink-ad.keithmoc.dev/login` (or `http://192.168.4.111:8081/login`)

Expected: Login page with "Sign in with Authentik" button (no error messages).

**Step 2: Click "Sign in with Authentik"**

Expected: Browser redirects to `https://authentik.keithmoc.dev/application/o/authorize/...` with PKCE parameters.

**Step 3: Log in as akadmin**

Username: `akadmin`
Password: `adminpassword` (from `AUTHENTIK_BOOTSTRAP_PASSWORD`)

Expected: Authentik shows consent screen for "AZBlink Directory".

**Step 4: Approve and verify callback**

Click "Continue" on consent.

Expected: Redirects back to `https://azblink-ad.keithmoc.dev/auth/callback?code=...`, then to the dashboard.

**Step 5: Verify authenticated state**

Expected:
- Dashboard loads with real data
- Profile dropdown shows "akadmin" user
- No "session expired" modal

**Step 6: Test logout**

Click profile dropdown → "Sign out"

Expected: Redirects to Authentik end-session, then back to `/login`.

---

### Task 8: Final Commit and Documentation

**Files:**
- Modify: `CLAUDE.md` (update services table and OIDC section)

**Step 1: Update CLAUDE.md services section**

Add Authentik to the services table:

```markdown
- Authentik IdP: http://localhost:9000/ (akadmin / adminpassword)
- Authentik Admin API: http://localhost:9000/api/v3/ (Bearer dev-authentik-api-token)
```

**Step 2: Update CLAUDE.md Key Environment Variables**

Add the new Authentik vars to the env vars section:

```bash
# Authentik IdP
AUTHENTIK_BOOTSTRAP_PASSWORD=adminpassword
AUTHENTIK_BOOTSTRAP_TOKEN=dev-authentik-api-token

# OIDC (backend — Docker-internal)
OIDC_ISSUER=http://authentik-server:9000/application/o/azblink-directory/

# OIDC (frontend — browser-accessible)
VITE_OIDC_ISSUER=https://authentik.keithmoc.dev/application/o/azblink-directory/
```

**Step 3: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: update CLAUDE.md with Authentik dev stack details"
```

---

## Verification Checklist

- [ ] `docker compose config --quiet` passes (no YAML errors)
- [ ] All 10 services start and reach healthy state
- [ ] `authentik-seed` exits 0 with "seed complete" message
- [ ] OIDC discovery endpoint returns valid JSON
- [ ] 299 tests pass (DEV_AUTH_TOKEN unaffected)
- [ ] Browser OIDC login works end-to-end (akadmin)
- [ ] Logout redirects through Authentik end-session
- [ ] Cloudflare tunnel serves both `azblink-ad` and `authentik` hostnames
