# Architecture Specification Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Create `docs/architecture/` with 8 spec sections, SOP, CHANGELOG, ARD template, 3 retroactive ARDs, and update CLAUDE.md — establishing the single source of truth for AZBlink Directory platform architecture.

**Architecture:** Modular spec — each section is independently readable (~2-4K tokens). ARD system uses `ARD-NNN-slug.md` naming with lightweight lifecycle. SemVer versioning with explicit update triggers in SOP.

**Tech Stack:** Markdown with `<!-- spec-meta -->` HTML comments for machine parsing. Mermaid diagrams inline. No build tooling.

**Design doc:** `docs/plans/2026-03-07-architecture-specification-design.md`

---

## Task 1: Create Directory Scaffold

**Files:**
- Create: `docs/architecture/README.md`
- Create: `docs/architecture/CHANGELOG.md`
- Create: `docs/architecture/SOP.md`
- Create: `docs/architecture/decisions/_TEMPLATE.md`
- Create: `docs/architecture/spec/.gitkeep` (placeholder, removed after spec files added)
- Create: `docs/architecture/diagrams/.gitkeep` (placeholder for future use)

**Step 1: Create directory structure**

```bash
mkdir -p docs/architecture/spec docs/architecture/decisions docs/architecture/diagrams
```

**Step 2: Write README.md**

The index/navigation file. Must include:
- Version badge (start at `1.0.0`)
- Audience statement (AI agents + human engineers)
- Table of contents linking all 8 spec sections
- Quick-reference for ARD process
- Cross-references to related docs (`specs/v2.0/`, `docs/prd/`, `CLAUDE.md`)

Structure:
```markdown
# AZBlink Directory — Architecture Specification

<!-- spec-meta: { version: "1.0.0", last_updated: "2026-03-07" } -->

**Version:** 1.0.0 | **Last Updated:** 2026-03-07 | **Status:** Current

## Audience
...

## How to Read This Spec
...

## Table of Contents
| # | Section | Scope | Tokens |
|---|---------|-------|--------|
| 01 | [System Overview](spec/01-system-overview.md) | Mission, actors, invariants, tech stack | ~2K |
| ... | ... | ... | ... |

## Architecture Decisions (ARDs)
| ARD | Title | Status | Date |
|-----|-------|--------|------|
| ... | ... | ... | ... |

## Related Documents
...

## Versioning
See [SOP.md](SOP.md) for versioning rules and ARD process.
```

**Step 3: Write SOP.md**

Full content from approved design. Sections:
1. Versioning Scheme (SemVer table)
2. Update Triggers (4 mandatory triggers)
3. CHANGELOG Format (Keep a Changelog style)
4. ARD Process (lifecycle, template reference, naming convention)
5. Maintenance Checklist (for AI agents: what to check after architectural PRs)

**Step 4: Write CHANGELOG.md**

Initial entry:
```markdown
# Architecture Specification Changelog

All notable changes to the architecture specification are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/).

## [1.0.0] - 2026-03-07

### Added
- Initial architecture specification (8 sections)
- SOP for versioning and ARD process
- ARD-001: Single-LDAP Architecture
- ARD-002: Authentik-Only OIDC Authentication
- ARD-003: Authentik Dev Stack

### References
- Design: docs/plans/2026-03-07-architecture-specification-design.md
- PR #12 (single-LDAP), PR #13 (authentik-only auth), PR #14 (authentik dev stack)
```

**Step 5: Write decisions/_TEMPLATE.md**

Copy the ARD template from the approved design doc verbatim. Include instructional comments:
```markdown
<!-- Copy this file to ARD-NNN-descriptive-slug.md -->
<!-- NNN = next available number (monotonically increasing, never reused) -->
<!-- Update README.md ARD table and CHANGELOG.md after creating -->
```

**Step 6: Commit scaffold**

```bash
git add docs/architecture/
git commit -m "docs(architecture): create directory scaffold with README, SOP, CHANGELOG, ARD template"
```

---

## Task 2: Write 01-system-overview.md

**Files:**
- Create: `docs/architecture/spec/01-system-overview.md`

**Reference sources:**
- `CLAUDE.md` lines 5-12 (project overview, design rules)
- `docs/prd/PHASE1_UC_CORE_QR_PRD.md` (mission, business drivers)
- `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md` (SSO extension scope)
- `specs/v2.0/Directory_Portal_Specification_v4.1.md` (formal spec)

**Content outline (~2K tokens):**

```markdown
<!-- spec-meta: { section: "01", version: "1.0.0", last_updated: "2026-03-07" } -->
# 01 — System Overview
```

Sections:
1. **Mission** — LDAP-backed identity directory with QR provisioning and optional SSO. One paragraph.
2. **Product Scope** — What the platform does and does not do. Bullet list.
3. **Actor Model** — Table with 4 actors (IT Admin, End User, UC Client App, AI Agent) and their interactions.
4. **Design Invariants** — The 6 critical rules from CLAUDE.md/PRDs, numbered and explained:
   1. UC must work without Authentik installed
   2. UC must work when Authentik is down
   3. Single LDAP holds identity + UC on same DN
   4. Provisioning is synchronous (atomic LDAP writes)
   5. Two authentication planes (Plane A: UC/LDAP, Plane B: OIDC)
   6. Graceful degradation: SSO failure ≠ UC failure
5. **Technology Stack** — Table: component → technology → version → role
6. **Spec Document Map** — Table linking this spec to v2.0 spec, PRDs, gap analysis, knowledge base. Clarify what each doc covers and what this architecture spec adds.

**After writing:**
```bash
git add docs/architecture/spec/01-system-overview.md
git commit -m "docs(architecture): add 01-system-overview — mission, actors, invariants, tech stack"
```

---

## Task 3: Write 02-component-architecture.md

**Files:**
- Create: `docs/architecture/spec/02-component-architecture.md`

**Reference sources:**
- `src/backend/` — all 9 Python modules (main.py, ldap_client.py, orgdb.py, config.py, provisioning.py, oidc_verify.py, authentik_client.py, qr_signing.py, rate_limit.py)
- `src/frontend/src/` — routes, components/features, lib/queries, stores, types
- `src/frontend/packages/azblink-ui/` — primitives layer
- `deploy/dev/docker-compose.yml` — service definitions

**Content outline (~3K tokens):**

```markdown
<!-- spec-meta: { section: "02", version: "1.0.0", last_updated: "2026-03-07" } -->
# 02 — Component Architecture
```

Sections:
1. **Component Inventory** — Table: component name → type → source path → responsibility. Cover all backend modules, frontend layers, infrastructure services.
2. **Backend (FastAPI)** — Module dependency diagram showing `main.py` as orchestrator calling into `ldap_client`, `orgdb`, `oidc_verify`, `authentik_client`, `provisioning`, `qr_signing`, `rate_limit`, with `config` as shared dependency. Include Mermaid flowchart.
3. **Frontend (React 19)** — Two-layer architecture:
   - Primitives (`@azblink/ui`) — 21 components, CSS Modules + tokens, domain-agnostic
   - Features (`src/components/features/`) — 8 domain directories, Tailwind utilities, domain-specific
   - State: Zustand stores (auth-store, ui-store)
   - Data: TanStack Query hooks (lib/queries/)
   - Routing: TanStack Router file-based routes
4. **Infrastructure** — Service role table: OpenLDAP, PostgreSQL, Redis, Authentik, Traefik
5. **Component Dependency Graph** — Mermaid diagram showing runtime dependencies between all components

**AS-BUILT vs TARGET markers:**
- `[AS-BUILT]` for all current components
- `[TARGET v2.0]` for any components mentioned in gap analysis but not yet implemented

**After writing:**
```bash
git add docs/architecture/spec/02-component-architecture.md
git commit -m "docs(architecture): add 02-component-architecture — backend, frontend, infrastructure"
```

---

## Task 4: Write 03-data-architecture.md

**Files:**
- Create: `docs/architecture/spec/03-data-architecture.md`

**Reference sources:**
- `src/backend/ldap_client.py` — LDAP schema (objectClasses, attributes in `build_uc_attrs`)
- `src/backend/orgdb.py` — PostgreSQL tables (inspect `Table()` definitions)
- `specs/v2.0/Directory_Portal_Schema_v4.2.sql` — full DB schema
- `specs/v2.0/Directory_Portal_LDAP_Schema_v4.2.ldif` — LDAP schema
- `migrations/017_single_ldap.sql` — latest migration
- `CLAUDE.md` lines 246-277 (LDAP architecture, UC schema)

**Content outline (~3K tokens):**

```markdown
<!-- spec-meta: { section: "03", version: "1.0.0", last_updated: "2026-03-07" } -->
# 03 — Data Architecture
```

Sections:
1. **Data Ownership Matrix** — Table: data domain → storage → owner component → access pattern
   - Identity data → LDAP → ldap_client.py → CRUD
   - UC attributes → LDAP (same entry) → ldap_client.py → MODIFY_ADD at creation
   - Profiles/templates → PostgreSQL → orgdb.py → CRUD
   - Audit trails → PostgreSQL → orgdb.py → append-only
   - Tokens → PostgreSQL → orgdb.py → issue/consume/revoke
   - Session state → Redis → rate_limit.py → TTL-based
2. **LDAP Entry Structure** — Single DN anatomy:
   - Base objectClasses: `inetOrgPerson`
   - UC objectClasses: `posixAccount`, `AsteriskPjsipEndpoint`, `AsteriskPjsipAuth`, `AsteriskPjsipAor`
   - Attribute table: objectClass → attribute → purpose → example value
   - Tree structure: `dc=azblink,dc=com` → `ou=org` / `ou=people` / `ou=groups`
3. **PostgreSQL Schema** — Table inventory with columns and purpose:
   - `config_templates` (profiles with UC toggles, SSO config, QR settings, allocation counters)
   - `provision_tokens` (QR token lifecycle)
   - `qr_issuance_audit` (QR issuance tracking)
   - `user_lifecycle_audit` (create/suspend/terminate events)
   - `termination_events` (termination details)
   - `qr_preview_links` (shareable preview tokens)
   - ER diagram (Mermaid)
4. **Schema Versioning** — Migration history table (004→017), current state, how to apply
5. **Data Consistency Rules** — Which data is authoritative where:
   - User existence: LDAP is source of truth
   - User metadata: LDAP (identity attrs) + PostgreSQL (audit/lifecycle)
   - Profile config: PostgreSQL (config_templates) is source of truth
   - Provisioning state: PostgreSQL (provision_tokens) tracks token lifecycle

**After writing:**
```bash
git add docs/architecture/spec/03-data-architecture.md
git commit -m "docs(architecture): add 03-data-architecture — LDAP schema, PostgreSQL tables, ownership"
```

---

## Task 5: Write 04-authentication.md

**Files:**
- Create: `docs/architecture/spec/04-authentication.md`

**Reference sources:**
- `src/backend/oidc_verify.py` — JWT verification logic
- `src/backend/authentik_client.py` — session/token revocation
- `src/backend/config.py` — OIDC config vars (OIDC_ISSUER, OIDC_ACCEPTED_ISSUERS)
- `src/frontend/src/lib/oidc.ts` — PKCE browser flow
- `src/frontend/src/routes/auth/callback.tsx` — OIDC callback
- `src/frontend/src/stores/auth-store.ts` — token storage
- `docs/knowledge/patterns/dual-auth-plane-sso-overlay.md` — pattern doc
- `docs/knowledge/libraries/oidc-pkce-browser.md` — PKCE implementation
- `CLAUDE.md` lines 94-106 (auth architecture)
- `docs/plans/2026-03-04-authentik-only-auth-design.md` — auth design

**Content outline (~2.5K tokens):**

```markdown
<!-- spec-meta: { section: "04", version: "1.0.0", last_updated: "2026-03-07" } -->
# 04 — Authentication
```

Sections:
1. **Dual Auth Planes** — Core architectural pattern:
   - Plane A (UC/LDAP): XMPP/SIP services authenticate via LDAP bind against single LDAP. Always available. No IdP dependency.
   - Plane B (SSO/Authentik): Web admin UI behind OIDC. Optional. Graceful degradation.
   - Diagram showing both planes (Mermaid)
2. **OIDC Flow** — End-to-end:
   - Browser → PKCE S256 authorization request → Authentik → callback → code exchange → access token + ID token
   - Backend verifies: signature (JWKS), audience, issuer (multi-issuer list)
   - Sequence diagram (Mermaid)
3. **Multi-Issuer Handling** — Problem + solution:
   - Authentik stamps `iss` based on access URL (Docker-internal vs Cloudflare tunnel)
   - `OIDC_ACCEPTED_ISSUERS` comma-separated, trailing slash normalization
   - `OIDC_ISSUER` for JWKS/discovery fetching only
4. **Dev Bypass** — `DEV_AUTH_TOKEN` mechanism:
   - When set, `Bearer <token>` bypasses OIDC, returns synthetic admin claims
   - Never in production
   - Test fixtures: `client` (authenticated), `anon_client` (unauthenticated)
5. **Token Lifecycle** — Access token validity, session management:
   - Token validation: RS256/RS384/RS512/ES256/ES384/ES512
   - Session revocation: `authentik_client.revoke_user_sessions()`
   - Token revocation: `authentik_client.revoke_user_tokens()` (DELETE to API, not end-session)
   - Gotcha: Authentik end-session does NOT revoke tokens
6. **Graceful Degradation** — What happens when Authentik is down:
   - Plane A (UC): Unaffected — LDAP bind continues
   - Plane B (Web): Login unavailable, existing sessions may continue if tokens cached
   - No fallback auth (breakglass removed in ARD-002)

**After writing:**
```bash
git add docs/architecture/spec/04-authentication.md
git commit -m "docs(architecture): add 04-authentication — dual planes, OIDC, multi-issuer, dev bypass"
```

---

## Task 6: Write 05-provisioning.md

**Files:**
- Create: `docs/architecture/spec/05-provisioning.md`

**Reference sources:**
- `src/backend/provisioning.py` — resource allocation (generate_sip_password, allocate_uc_resources)
- `src/backend/ldap_client.py` — build_uc_attrs, add_uc_attrs_to_user, create_user
- `src/backend/qr_signing.py` — sign_provisioning_payload, verify_provisioning_payload
- `src/backend/main.py` — api_user_create, _resolve_service_endpoints
- `src/backend/orgdb.py` — config_templates (profiles), provision_tokens, qr_preview_links
- `CLAUDE.md` lines 269-302 (profile pattern, provisioning enrichment)

**Content outline (~2.5K tokens):**

```markdown
<!-- spec-meta: { section: "05", version: "1.0.0", last_updated: "2026-03-07" } -->
# 05 — Provisioning
```

Sections:
1. **Profile = Connector Pattern** — How profiles configure UC for orgs:
   - Profile fields table: identity, SSO, QR, UC toggles, UC endpoints, allocation counters
   - Without UC: plain inetOrgPerson in LDAP
   - With UC: inetOrgPerson + posixAccount + AsteriskPjsip* (UC attrs added atomically)
2. **User Creation Flow** — Step-by-step sequence:
   1. `api_user_create()` validates request + resolves profile
   2. `create_user()` → LDAP ADD inetOrgPerson
   3. If UC enabled: `allocate_uc_resources()` → UID number + extension from profile counters
   4. `build_uc_attrs()` → objectClasses + attributes dict
   5. `add_uc_attrs_to_user()` → LDAP MODIFY_ADD on same DN
   6. `sign_provisioning_payload()` → HMAC-SHA256 signed QR content
   7. `record_provision_token()` → PostgreSQL token record
   8. Return provisioning info in API response
   - Sequence diagram (Mermaid)
3. **UC Resource Allocation** — How UID numbers and extensions are assigned:
   - Profile has `uid_range_start/end`, `next_uid_number`
   - Profile has `ext_range_start/end`, `next_extension`
   - Atomic counter increment via `orgdb.allocate_uid_number()` / `allocate_extension()`
4. **QR Code Assembly** — What goes into the QR payload:
   - Schema: `azblink.provisioning.v2`
   - UC payload: username, password, extension, XMPP domain/WS URL, SIP domain/WSS URL
   - SSO payload: optional Authentik OIDC config
   - Wrapper: `iat`, `exp`, `nonce`, `sig` (HMAC-SHA256)
5. **QR Preview Links** — Shareable preview tokens:
   - `orgdb.create_preview_link()` → hashed token with TTL and max accesses
   - Public endpoint: `GET /api/qr/preview/{token}` (no auth required)
   - Access tracking: `increment_preview_access()`

**After writing:**
```bash
git add docs/architecture/spec/05-provisioning.md
git commit -m "docs(architecture): add 05-provisioning — profile connector, creation flow, QR assembly"
```

---

## Task 7: Write 06-deployment.md

**Files:**
- Create: `docs/architecture/spec/06-deployment.md`

**Reference sources:**
- `deploy/dev/docker-compose.yml` — full service topology
- `deploy/dev/.env.example` — environment variables
- `deploy/dev/authentik-seed/seed_authentik.py` — Authentik bootstrap
- `CLAUDE.md` lines 14-46 (dev commands, services), lines 108-131 (hot reload)

**Content outline (~2K tokens):**

```markdown
<!-- spec-meta: { section: "06", version: "1.0.0", last_updated: "2026-03-07" } -->
# 06 — Deployment
```

Sections:
1. **Service Topology** — All Docker Compose services:
   - Table: service → image → ports → role → depends_on
   - AZBlink core: postgres, redis, openldap, directory-api, directory-ui, traefik, seed
   - Authentik IdP: authentik-postgres, authentik-server, authentik-worker, authentik-seed
2. **Network Topology** — Two Docker networks:
   - `azblink-net` (internal bridge) — all services
   - `cloudflare-tunnel` (external) — traefik + authentik-server only
   - Mermaid diagram showing service-to-network mapping
3. **Port Mappings** — Table: host port → container → service
   - 8081 → traefik (UI + API proxy)
   - 5433 → postgres
   - 1390 → openldap
   - 6380 → redis
   - 9000 → authentik-server
4. **Volume Mounts** — Persistent storage:
   - Named volumes for data (pg_data, redis_data, ldap_data, ldap_config, authentik_pg_data)
   - Bind mounts for hot reload (src/backend → /app, src/frontend → /app)
5. **Authentik Bootstrap** — Seed script behavior:
   - Creates OAuth2 provider + application + IT-Admins group + test users
   - Polls 30×5s for Authentik readiness
   - Idempotent (safe to re-run)
6. **Hot Reload Rules** — Decision table from CLAUDE.md (what triggers rebuild vs HMR)
7. **Environment Variable Groups** — Categorized reference:
   - LDAP, Database, OIDC (backend), OIDC (frontend), Authentik, QR, SIP, CORS

**After writing:**
```bash
git add docs/architecture/spec/06-deployment.md
git commit -m "docs(architecture): add 06-deployment — Docker topology, networking, bootstrap, hot reload"
```

---

## Task 8: Write 07-security.md

**Files:**
- Create: `docs/architecture/spec/07-security.md`

**Reference sources:**
- `src/backend/rate_limit.py` — rate limiting implementation
- `src/backend/qr_signing.py` — HMAC-SHA256 signing
- `src/backend/orgdb.py` — audit tables (qr_issuance_audit, user_lifecycle_audit, termination_events)
- `src/backend/main.py` — require_admin, require_permission decorators
- `specs/v2.0/Directory_Portal_Technical_Audit_v4.1.md` — security audit
- `specs/v2.0/V1_TO_V2_GAP_ANALYSIS.md` — security gaps

**Content outline (~2K tokens):**

```markdown
<!-- spec-meta: { section: "07", version: "1.0.0", last_updated: "2026-03-07" } -->
# 07 — Security
```

Sections:
1. **Rate Limiting** — Implementation details:
   - Redis-backed (slowapi), fixed-window strategy
   - Rate constants: bootstrap (5/hr), user_create (20/min), QR (10/min), default (100/min)
   - Client IP extraction (X-Forwarded-For for proxied requests)
2. **QR Code Signing** — HMAC-SHA256:
   - Canonical JSON signing (sorted keys, no whitespace)
   - Wrapper: schema, payload, iat, exp, nonce, sig
   - Verification: constant-time comparison, expiration check
   - TTL cap: `ORG_QR_MAX_TTL_SEC`
3. **Authorization Model** — `[AS-BUILT]`
   - `require_user()` — any authenticated user
   - `require_admin()` — OIDC groups claim must include admin group
   - `require_permission()` — fine-grained permission checks
   - Role model: admin vs user (from OIDC groups)
4. **Audit Trail** — Tables and what they track:
   - `qr_issuance_audit` — QR token issuance and consumption
   - `user_lifecycle_audit` — create, suspend, unsuspend, terminate events
   - `termination_events` — detailed termination records (actions, revocation counts)
   - `provision_tokens` — token lifecycle (issued, consumed, revoked, expired)
5. **Security Boundaries** — What's in scope vs deferred:
   - `[AS-BUILT]`: rate limiting, QR signing, audit logging, OIDC auth, LDAP bind auth
   - `[TARGET v2.0]`: LDAP federation hardening, advanced compliance, encrypted audit storage
   - Reference: `V1_TO_V2_GAP_ANALYSIS.md` § Security (30% gap)

**After writing:**
```bash
git add docs/architecture/spec/07-security.md
git commit -m "docs(architecture): add 07-security — rate limiting, QR signing, audit, authorization"
```

---

## Task 9: Write 08-integration-points.md

**Files:**
- Create: `docs/architecture/spec/08-integration-points.md`

**Reference sources:**
- `src/backend/authentik_client.py` — Authentik Admin API v3 contract
- `src/backend/ldap_client.py` — LDAP bind patterns
- `src/backend/oidc_verify.py` — OIDC/JWKS endpoints
- `deploy/dev/authentik-seed/seed_authentik.py` — OAuth2 provider config
- `docs/knowledge/libraries/authentik-admin-api-v3.md` — API gotchas
- `CLAUDE.md` lines 341-349 (Authentik API gotchas)
- `specs/v2.0/Directory_Portal_OpenAPI_v4.2.yaml` — API specification

**Content outline (~2K tokens):**

```markdown
<!-- spec-meta: { section: "08", version: "1.0.0", last_updated: "2026-03-07" } -->
# 08 — Integration Points
```

Sections:
1. **Authentik Admin API v3** — Contract and gotchas:
   - Base URL: `AUTHENTIK_API_URL` (internal Docker network)
   - Auth: Bearer token (`AUTHENTIK_API_TOKEN`)
   - Operations: user lookup, session revocation, token revocation
   - Gotchas table (from CLAUDE.md): redirect_uris format, invalidation_flow required, signing_key required, end-session doesn't revoke, first startup delay
2. **LDAP Bind Contract** — Who binds and how:
   - Admin bind: `cn=admin,dc=azblink,dc=com` (directory-api for CRUD)
   - Service bind: XMPP/SIP servers for user authentication (Plane A)
   - User bind: `uid=<username>,ou=people,...` with `userPassword` (SSHA)
   - Protocol: LDAP v3, optional TLS
3. **External Service Integration** — UC services that consume LDAP:
   - XMPP server → LDAP bind auth → `userPassword`
   - Asterisk/SIP → LDAP auth → `AstAuthPassword` (separate SIP digest password)
   - Both use same LDAP entry, different password attributes
4. **API Contract Summary** — High-level API surface:
   - 40+ REST endpoints organized by domain (health, org, group, user, provisioning, QR, config)
   - Full specification: `specs/v2.0/Directory_Portal_OpenAPI_v4.2.yaml`
   - Auth: Bearer token (OIDC) on all non-public endpoints
   - Public endpoints: `GET /api/health`, `GET /api/qr/preview/{token}`
5. **OIDC Discovery Endpoints** — What the backend fetches:
   - Discovery: `{OIDC_ISSUER}/.well-known/openid-configuration`
   - JWKS: from discovery `jwks_uri` field
   - Cached: 10-min TTL on JWKS client

**After writing:**
```bash
git add docs/architecture/spec/08-integration-points.md
git commit -m "docs(architecture): add 08-integration-points — Authentik API, LDAP bind, external services"
```

---

## Task 10: Write ARD-001 — Single-LDAP Architecture

**Files:**
- Create: `docs/architecture/decisions/ARD-001-single-ldap-architecture.md`

**Reference source:** `docs/plans/2026-03-02-single-ldap-architecture-design.md`

**Content:** Distill the design doc into ARD format:

| Field | Value |
|-------|-------|
| Status | `accepted` |
| Date | 2026-03-02 |
| Supersedes | — (original architecture) |
| PR | #12 |
| Spec sections affected | 02-component-architecture, 03-data-architecture, 05-provisioning |

- **Context:** Two-LDAP design (AD LDAP + UED Sync microservice + separate UC LDAP) was overcomplicated. Async sync via `sync_events` queue added latency, failure modes, and operational burden.
- **Decision:** Collapse to single LDAP. Identity (inetOrgPerson) and UC (posixAccount + AsteriskPjsip*) on same DN. Synchronous two-step LDAP writes at user creation. Remove UED Sync microservice entirely.
- **Alternatives:** (1) Keep two-LDAP with simplified sync — rejected: still requires microservice maintenance. (2) Event-driven UC provisioning — rejected: adds latency and failure modes for no benefit at current scale.
- **Consequences:** Positive: simpler deployment, atomic provisioning, no sync failures. Negative: tight coupling between identity and UC (acceptable trade-off). Risk: LDAP entry size grows with UC attrs (mitigated: attrs are small).

**After writing:**
```bash
git add docs/architecture/decisions/ARD-001-single-ldap-architecture.md
git commit -m "docs(architecture): add ARD-001 — single-LDAP architecture decision"
```

---

## Task 11: Write ARD-002 — Authentik-Only Auth

**Files:**
- Create: `docs/architecture/decisions/ARD-002-authentik-only-auth.md`

**Reference source:** `docs/plans/2026-03-04-authentik-only-auth-design.md`

**Content:** Distill into ARD format:

| Field | Value |
|-------|-------|
| Status | `accepted` |
| Date | 2026-03-04 |
| Supersedes | — (dual-auth with LDAP JWT + breakglass) |
| PR | #13 |
| Spec sections affected | 02-component-architecture, 04-authentication, 07-security |

- **Context:** Dual-auth (LDAP JWT + OIDC + breakglass fallback) was complex. Three auth modes to maintain, test, and reason about. Breakglass had no audit trail.
- **Decision:** Authentik OIDC is sole auth path. Two clean planes: Plane A (UC/LDAP bind, unchanged), Plane B (web UI/OIDC). No fallback. No breakglass. Dev bypass via `DEV_AUTH_TOKEN` for testing only.
- **Alternatives:** (1) Keep breakglass as emergency fallback — rejected: no audit trail, security risk. (2) LDAP JWT as primary, OIDC optional — rejected: diverges from SSO-first strategy.
- **Consequences:** Positive: single auth path, cleaner codebase (~300 lines removed), Authentik handles session management. Negative: web UI unavailable when Authentik is down (acceptable: UC continues via Plane A). Risk: single point of failure for admin access.

**After writing:**
```bash
git add docs/architecture/decisions/ARD-002-authentik-only-auth.md
git commit -m "docs(architecture): add ARD-002 — authentik-only OIDC authentication decision"
```

---

## Task 12: Write ARD-003 — Authentik Dev Stack

**Files:**
- Create: `docs/architecture/decisions/ARD-003-authentik-dev-stack.md`

**Reference source:** `docs/plans/2026-03-04-authentik-dev-stack-design.md`

**Content:** Distill into ARD format:

| Field | Value |
|-------|-------|
| Status | `accepted` |
| Date | 2026-03-04 |
| Supersedes | — |
| PR | #14 |
| Spec sections affected | 06-deployment, 08-integration-points |

- **Context:** After ARD-002 (Authentik-only auth), dev/test environment needed a local OIDC IdP for end-to-end login flow without external infrastructure.
- **Decision:** Add Authentik to Docker Compose dev stack. Three services (authentik-postgres, authentik-server, authentik-worker) + one-shot seed script. Seed creates OAuth2 provider, application, IT-Admins group, and test users.
- **Alternatives:** (1) Mock OIDC provider (e.g., Keycloak dev mode) — rejected: need to test against real Authentik API behaviors and gotchas. (2) Shared remote Authentik instance — rejected: dev environment should be self-contained.
- **Consequences:** Positive: full end-to-end OIDC testing locally, discovered 5+ Authentik API gotchas. Negative: dev stack heavier (~60s Authentik startup), separate PostgreSQL for Authentik. Risk: Authentik version updates may break seed script (mitigated: pinned to 2025.8).

**After writing:**
```bash
git add docs/architecture/decisions/ARD-003-authentik-dev-stack.md
git commit -m "docs(architecture): add ARD-003 — authentik dev stack decision"
```

---

## Task 13: Update CLAUDE.md

**Files:**
- Modify: `CLAUDE.md`

**Changes:**

1. **Add Architecture Spec reference** — After the "Project Overview" section (line ~12), add:
```markdown
## Architecture Specification

The canonical architecture specification lives in [`docs/architecture/`](docs/architecture/README.md) (v1.0.0). It covers system overview, component architecture, data architecture, authentication, provisioning, deployment, security, and integration points.

**For AI agents:** Read `docs/architecture/README.md` for the table of contents, then read individual sections as needed. Each section is ~2-3K tokens.

**Architecture decisions:** Tracked as ARDs in `docs/architecture/decisions/`. See `docs/architecture/SOP.md` for the versioning process.
```

2. **Slim the Architecture section** (lines ~247-302) — Remove detailed LDAP schema table and provisioning enrichment steps (now in 03-data-architecture and 05-provisioning). Keep:
   - Single-LDAP Architecture summary (3-4 lines)
   - Dual Auth Planes summary (2-3 lines)
   - Profile = Connector Pattern summary (2-3 lines)
   - Add cross-references: "Full details: `docs/architecture/spec/03-data-architecture.md`" etc.

3. **Add ARD reference to Code Patterns section** — After line ~416:
```markdown
**Architecture Decisions:** See `docs/architecture/decisions/` for ARDs. Create new ARDs using `docs/architecture/decisions/_TEMPLATE.md`.
```

**After updating:**
```bash
git add CLAUDE.md
git commit -m "docs: update CLAUDE.md with architecture spec references, slim duplicated details"
```

---

## Task 14: Update README.md ARD Table and Final Review

**Files:**
- Modify: `docs/architecture/README.md` (update ARD table with actual ARD dates/titles)

**Steps:**

1. Verify all 8 spec sections exist and have correct `<!-- spec-meta -->` headers
2. Verify all 3 ARDs exist and have correct metadata tables
3. Update README.md ARD table with actual content
4. Remove any `.gitkeep` files from `spec/` and `diagrams/` directories (spec files now exist)
5. Run a final consistency check:
   - Every section referenced in README.md TOC exists as a file
   - Every ARD referenced in README.md ARD table exists as a file
   - CHANGELOG.md references match actual deliverables
   - SOP.md is internally consistent

**After review:**
```bash
git add docs/architecture/
git commit -m "docs(architecture): finalize README, verify consistency across all spec files"
```

---

## Execution Notes

**Parallelization:** Tasks 2-9 (spec sections) and Tasks 10-12 (ARDs) can be executed in parallel by separate agents. Task 1 (scaffold) must complete first. Tasks 13-14 (CLAUDE.md update, final review) must run last.

**Dependency chain:**
```
Task 1 (scaffold) → [Tasks 2-12 in parallel] → Task 13 (CLAUDE.md) → Task 14 (final review)
```

**Token budget per section:**
| Section | Target | Max |
|---------|--------|-----|
| 01-system-overview | ~2K | 3K |
| 02-component-architecture | ~3K | 4K |
| 03-data-architecture | ~3K | 4K |
| 04-authentication | ~2.5K | 3.5K |
| 05-provisioning | ~2.5K | 3.5K |
| 06-deployment | ~2K | 3K |
| 07-security | ~2K | 3K |
| 08-integration-points | ~2K | 3K |
| Each ARD | ~1K | 1.5K |

**Quality gates per section:**
- `<!-- spec-meta -->` header present with section number and version
- `[AS-BUILT]` / `[TARGET v2.0]` markers used where applicable
- Cross-references use relative paths (e.g., `../decisions/ARD-001-single-ldap-architecture.md`)
- Mermaid diagrams render correctly (test by previewing in VS Code or GitHub)
- No duplication with CLAUDE.md (architecture spec has detail, CLAUDE.md has summary)
