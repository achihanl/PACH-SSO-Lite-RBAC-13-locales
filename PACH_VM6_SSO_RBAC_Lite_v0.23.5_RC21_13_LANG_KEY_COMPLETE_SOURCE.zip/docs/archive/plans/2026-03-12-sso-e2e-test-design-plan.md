# SSO E2E Test — Architecture & Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Replace QR-centric e2e test with SSO device provisioning flow using real Authentik OIDC tokens
**Architecture:** Reuse existing public OAuth2 provider for M2M token acquisition via client_credentials grant; add conftest fixtures for Authentik user + token lifecycle; replace test_full_platform_flow with two SSO variants
**Tech Stack:** Python, pytest, httpx, PyNaCl, slixmpp, Authentik Admin API v3
**Domains:** backend, test

---

## Architecture Decisions

### AD-1: Reuse existing public provider (not new confidential provider)
- **Design doc proposed:** New confidential provider `azblink-directory-test`
- **Research found:** `client_credentials` + `username` + app_password works on public providers
- **Decision:** Use existing `client_id=azblink-directory` provider
- **Rationale:** Tokens get `aud=azblink-directory` matching `OIDC_AUDIENCE` — no audience mismatch, no config changes, no seed script changes
- **Trade-off:** Less isolation (test tokens use same provider as production), but acceptable for dev stack

### AD-2: Token endpoint is global
- **Design doc stated:** `/application/o/token/` (correct but incomplete context)
- **Research confirmed:** Token endpoint is always `/application/o/token/` regardless of application slug
- **Impact:** `oidc_token_factory` uses `http://localhost:9000/application/o/token/`

### AD-3: Use httpx for Authentik API calls in conftest
- **Design doc proposed:** `requests` library
- **Codebase uses:** `httpx` already imported in conftest.py
- **Decision:** Use `httpx` to avoid new dependency
- **Impact:** `_authentik_api()` uses `httpx.Client` instead of `requests.Session`

### AD-4: No changes to backend code
- With AD-1, no changes needed to `config.py`, `oidc_verify.py`, or `main.py`
- The existing OIDC verification chain handles tokens from the existing provider naturally

---

## File Changes (Revised from Design Doc)

| File | Change |
|------|--------|
| `deploy/dev/authentik-seed/seed_authentik.py` | **NO CHANGES** (reuse existing provider) |
| `src/backend/config.py` | **NO CHANGES** (no multi-audience needed) |
| `src/backend/oidc_verify.py` | **NO CHANGES** |
| `tests/conftest.py` | Add `_authentik_api()`, `authentik_user_factory`, `oidc_token_factory` |
| `tests/test_xmpp_e2e.py` | Replace `test_full_platform_flow`, add `TestSsoProvisioningLocal`, update `_cleanup_ad_user()` |

---

## Task 1: Add Authentik Conftest Fixtures

**domain:** test
**depends_on:** []
**parallel_group:** 1

**Files:**
- Modify: `tests/conftest.py`

**Step 1: Add constants after existing constants (after line 22)**
```python
# Authentik API constants (for real OIDC token acquisition in e2e tests)
AUTHENTIK_API_URL = "http://localhost:9000"
AUTHENTIK_API_TOKEN = "dev-authentik-api-token"
AUTHENTIK_CLIENT_ID = "azblink-directory"
```

**Step 2: Add `_authentik_api()` helper**
- Uses `httpx` (already imported)
- `method`, `path`, `data=None` params
- Bearer auth with `AUTHENTIK_API_TOKEN`
- Returns response JSON or raises on error
- Similar pattern to seed script's `api_request()`

**Step 3: Add `authentik_user_factory` fixture**
- Function-scoped, factory pattern (returns callable)
- Creates Authentik user via `POST /api/v3/core/users/`
- Sets password via `POST /api/v3/core/users/{pk}/set_password/`
- Creates app password token via `POST /api/v3/core/tokens/`
- Retrieves token key via `GET /api/v3/core/tokens/{identifier}/view_key/`
- Returns `(user_pk, username, app_token_key)`
- Teardown: deletes all created tokens and users (reverse order, best-effort)

**Step 4: Add `oidc_token_factory` fixture**
- Function-scoped, factory pattern (returns callable)
- POSTs to `AUTHENTIK_API_URL/application/o/token/` with:
  - `grant_type=client_credentials`
  - `client_id=azblink-directory` (existing provider)
  - `username=<username>`
  - `password=<app_token_key>`
  - `scope=openid profile email`
- Returns the `access_token` string from response JSON
- No cleanup needed (tokens are short-lived)

**Step 5: Verify fixtures work**
- Run: `pytest tests/conftest.py --co -q` (collection check)
- Manually test fixture with a simple test (will be done in Task 2)

---

## Task 2: Add TestSsoProvisioningLocal

**domain:** test
**depends_on:** [1]
**parallel_group:** 2

**Files:**
- Modify: `tests/test_xmpp_e2e.py`

**Step 1: Add imports**
- Add `import uuid` (if not present)
- Add `from conftest import AUTHENTIK_API_URL, AUTHENTIK_API_TOKEN` (for cleanup helper)

**Step 2: Add `_cleanup_ad_user_with_authentik()` or extend `_cleanup_ad_user()`**
- Extend existing `_cleanup_ad_user(uid, db_conn)` to accept optional `authentik_pk=None`
- When `authentik_pk` is provided, DELETE the Authentik user via Admin API
- Best-effort (try/except around Authentik cleanup)

**Step 3: Add `TestSsoProvisioningLocal` class**
- No external_network marker
- `@pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")` guard (import HAS_NACL check)
- Add `HAS_NACL` import or define locally using same try/except pattern as test_device_provisioning.py

**Step 4: Implement `test_local_sso_provisioning` method**
Flow:
1. Create Authentik test user via `authentik_user_factory`
2. Create same user in AD Directory via API (`client` fixture) with UC-enabled profile
3. Acquire real OIDC token via `oidc_token_factory`
4. Create httpx client with real Bearer token (not DEV_AUTH_TOKEN)
5. POST `/api/provision/device` with real token + Curve25519 pubkey
6. Decrypt sealed box → extract xmppPassword, sipPassword
7. Read LDAP directly → verify credentials match `azbXmppBindPassword`, `AstAuthPassword`
8. Verify audit trail: `provision_tokens` row with `auth_method='sso_token'`
9. Re-provision same device → 200 (upsert semantics)
10. Cleanup: revoke device, delete AD user, delete Authentik user

**Step 5: Run test**
```bash
pytest tests/test_xmpp_e2e.py::TestSsoProvisioningLocal -xvs
```

---

## Task 3: Replace test_full_platform_flow with TestSsoProvisioningE2E

**domain:** test
**depends_on:** [2]
**parallel_group:** 3

**Files:**
- Modify: `tests/test_xmpp_e2e.py`

**Step 1: Remove `test_full_platform_flow` method from `TestXmppE2EProvisioning`**
- Lines 280-398 of current file
- Class itself (`TestXmppE2EProvisioning`) stays — it still has `test_provision_users_to_external_ldap` and `test_xmpp_auth_and_messaging`

**Step 2: Add `TestSsoProvisioningE2E` class**
- `@pytest.mark.external_network` marker
- `@pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")` guard

**Step 3: Implement `test_full_sso_platform_flow` method**
Flow (two users):
1. Create user1 + user2 in Authentik
2. Create user1 + user2 in external XMPP LDAP (reuse `_provision_xmpp_user()`)
3. Create user1 + user2 in AD Directory via API with UC-enabled profile (same password as XMPP LDAP)
4. Acquire OIDC tokens for both users
5. POST `/api/provision/device` for each user with real tokens
6. Decrypt sealed boxes → extract xmppPassword for each
7. Connect both users to external XMPP server with unsealed passwords
8. Exchange messages (user1→user2, user2→user1)
9. Verify `provision_tokens` rows (`auth_method='sso_token'`)
10. Cleanup: revoke devices, delete AD users, delete XMPP users, delete Authentik users

**Step 4: Run test (if external XMPP available)**
```bash
EXTERNAL_LDAP_ADMIN_PASSWORD=... pytest tests/test_xmpp_e2e.py::TestSsoProvisioningE2E -xvs
```

---

## Task 4: Run Full Test Suite

**domain:** test
**depends_on:** [3]
**parallel_group:** 4

**Step 1: Run full suite**
```bash
just test
```

**Step 2: Verify no regressions**
- All existing tests must pass
- New `TestSsoProvisioningLocal` must pass
- `TestSsoProvisioningE2E` skipped (no external LDAP in CI)
