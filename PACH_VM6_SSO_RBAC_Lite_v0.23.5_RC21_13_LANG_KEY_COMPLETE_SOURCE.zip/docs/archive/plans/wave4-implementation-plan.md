# Wave 4 Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans

**Goal:** Implement issues #25, #26, #27, #28, #29
**Domains:** backend, devops, frontend
**Branch:** `wave4-schema-overlays-refresh-sso-qr-validation`

## Dependency Graph

```
#25 (LDAP schema)  ──┐
                     ├──> #26 (ppolicy overlay)
#28 (SSO in QR)      │
#29 (UC validation)   │   (independent, parallelizable)
#27 (Refresh tokens)  │   (independent)
```

## Execution Order

1. Task 1-2: #25 (LDAP schema) -- foundation, no deps
2. Task 3-4: #28 (SSO in QR) -- independent
3. Task 5-7: #29 (UC validation) -- independent, parallelizable with #28
4. Task 8-9: #26 (ppolicy overlay) -- after #25
5. Task 10-13: #27 (Refresh tokens) -- independent, most complex

---

### Task 1: Create azblink.schema file with custom objectClasses
**domain:** devops
**issue:** #25
**depends_on:** []
**files:**
- `deploy/dev/ldap/azblink.schema` (CREATE)

**Step 1:** Create `deploy/dev/ldap/azblink.schema` with experimental OID arc `1.3.6.1.3` following the pattern from `asterisk-pjsip.schema`. Define three AUXILIARY objectClasses:

```schema
# AZBlink Directory Custom LDAP Schema
#
# OID base: 1.3.6.1.3.99.1 (experimental arc for dev/test)
# Structure: .1 = attributes, .2 = objectClasses
#
# All objectClasses are AUXILIARY — they overlay inetOrgPerson entries.

objectIdentifier AZBlinkRoot 1.3.6.1.3.99.1
objectIdentifier AZBlinkAttr AZBlinkRoot:1
objectIdentifier AZBlinkOC   AZBlinkRoot:2

# ============================================================
# Attributes
# ============================================================

# azblinkUser attributes
attributetype ( AZBlinkAttr:1
    NAME 'azblinkAccountStatus'
    DESC 'Account lifecycle status: active, suspended, terminated'
    EQUALITY caseIgnoreMatch
    SUBSTR caseIgnoreSubstringsMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15
    SINGLE-VALUE )

attributetype ( AZBlinkAttr:2
    NAME 'azblinkProfileId'
    DESC 'Config template ID assigned to this user'
    EQUALITY caseIgnoreMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15
    SINGLE-VALUE )

attributetype ( AZBlinkAttr:3
    NAME 'azblinkProvisionedAt'
    DESC 'ISO-8601 timestamp of last UC provisioning'
    EQUALITY caseIgnoreMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15
    SINGLE-VALUE )

# azblinkOrganization attributes
attributetype ( AZBlinkAttr:4
    NAME 'azblinkOrgType'
    DESC 'Organization type: department, team, division'
    EQUALITY caseIgnoreMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15
    SINGLE-VALUE )

attributetype ( AZBlinkAttr:5
    NAME 'azblinkOrgProfileId'
    DESC 'Config template ID assigned to this org unit'
    EQUALITY caseIgnoreMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15
    SINGLE-VALUE )

# azblinkGroup attributes
attributetype ( AZBlinkAttr:6
    NAME 'azblinkGroupType'
    DESC 'Group classification: security, distribution, role'
    EQUALITY caseIgnoreMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15
    SINGLE-VALUE )

# ============================================================
# ObjectClasses (all AUXILIARY)
# ============================================================

objectclass ( AZBlinkOC:1
    NAME 'azblinkUser'
    DESC 'AZBlink user extensions for provisioning and lifecycle'
    SUP top AUXILIARY
    MAY ( azblinkAccountStatus $ azblinkProfileId $
          azblinkProvisionedAt ) )

objectclass ( AZBlinkOC:2
    NAME 'azblinkOrganization'
    DESC 'AZBlink organization unit extensions'
    SUP top AUXILIARY
    MAY ( azblinkOrgType $ azblinkOrgProfileId ) )

objectclass ( AZBlinkOC:3
    NAME 'azblinkGroup'
    DESC 'AZBlink group extensions'
    SUP top AUXILIARY
    MAY ( azblinkGroupType ) )
```

**Verify:** File exists and is valid schema syntax (visual inspection -- OID structure, AUXILIARY keyword, attribute references).

---

### Task 2: Mount azblink.schema in Docker and verify LDAP loads it
**domain:** devops
**issue:** #25
**depends_on:** [Task 1]
**files:**
- `deploy/dev/docker-compose.yml` (MODIFY)

**Step 1:** Add a volume mount for the new schema file in the `openldap` service, right after the asterisk-pjsip.schema mount (line 57):

```yaml
      - ./ldap/azblink.schema:/container/service/slapd/assets/config/bootstrap/schema/azblink.schema:ro
```

The full volumes section for openldap becomes:
```yaml
    volumes:
      - azblink_ldap_data:/var/lib/ldap
      - azblink_ldap_config:/etc/ldap/slapd.d
      - ./ldap/asterisk-pjsip.schema:/container/service/slapd/assets/config/bootstrap/schema/asterisk-pjsip.schema:ro
      - ./ldap/azblink.schema:/container/service/slapd/assets/config/bootstrap/schema/azblink.schema:ro
      - ./ldap/bootstrap.ldif:/container/service/slapd/assets/config/bootstrap/ldif/custom/bootstrap.ldif:ro
```

**Step 2:** Reset LDAP data and restart (schemas load only on first boot):

```bash
just reset && just up-bg
```

**Verify:**
```bash
# Wait for stack to be healthy, then check schema is loaded
docker exec azblink-openldap ldapsearch -Q -Y EXTERNAL -H ldapi:/// -b cn=schema,cn=config '(cn=*azblink*)' cn 2>/dev/null | grep -i azblink
# Expected: cn={N}azblink  (where N is the schema index number)

# Verify objectClass is usable by searching for it
docker exec azblink-openldap ldapsearch -x -H ldap://localhost:389 -D "cn=admin,dc=azblink,dc=com" -w adminpassword -b "cn=subschema" -s base "(objectClass=subschema)" objectClasses 2>/dev/null | grep azblinkUser
# Expected: line containing "NAME 'azblinkUser'"
```

---

### Task 3: Build SSO payload from config template sso_config
**domain:** backend
**issue:** #28
**depends_on:** []
**files:**
- `src/backend/main.py` (MODIFY)

**Step 1:** In `main.py`, create a helper function `_resolve_sso_payload` near `_resolve_service_endpoints` (after line ~200). This function reads the config template's `sso_config` for the org and builds the SSO block for the v2 QR schema:

```python
def _resolve_sso_payload(org_dn: str) -> Optional[Dict[str, Any]]:
    """Resolve SSO config from the config template assigned to an org.

    Returns an SSO payload dict for the QR v2 schema, or None if SSO
    is not enabled or no template is assigned.
    """
    template = ORGDB.resolve_template_for_org(org_dn)
    if not template:
        return None

    # sso_config is stored as JSON string or dict
    sso_config = template.get("sso_config", {})
    if isinstance(sso_config, str):
        import json as _json
        try:
            sso_config = _json.loads(sso_config)
        except (ValueError, TypeError):
            return None

    if not sso_config.get("enabled"):
        return None

    issuer_url = sso_config.get("issuerUrl", "")
    if not issuer_url:
        return None

    return {
        "provider": sso_config.get("provider", "oidc"),
        "issuerUrl": issuer_url,
        "clientId": sso_config.get("clientId", ""),
        "scopes": sso_config.get("scopes", "openid profile email"),
        "pkceRequired": sso_config.get("pkceRequired", True),
    }
```

**Step 2:** In `api_user_qrcode` (line ~2212), replace `sso_payload=None` with the resolved SSO config:

Change:
```python
    # Sign with v2 schema wrapper (sso_payload is None in Phase 1)
    signed_payload = sign_provisioning_payload(uc_payload, sso_payload=None, ttl_sec=requested_ttl)
```

To:
```python
    # Resolve SSO config from profile (None if SSO not enabled)
    sso_payload = _resolve_sso_payload(org_dn)

    # Sign with v2 schema wrapper
    signed_payload = sign_provisioning_payload(uc_payload, sso_payload=sso_payload, ttl_sec=requested_ttl)
```

**Verify:**
```bash
just test-quick -k "test_qr_payload_has_v2_schema"
# Expected: PASSED — sso field is still present (now populated when template has SSO config, None otherwise)

just test-quick -k "test_qr"
# Expected: All QR tests pass (existing behavior preserved for orgs without SSO config)
```

---

### Task 4: Add test for SSO block in QR payload
**domain:** backend
**issue:** #28
**depends_on:** [Task 3]
**files:**
- `tests/test_qr_format.py` (MODIFY)

**Step 1:** Add a new test to `TestQRUnifiedFormat` class that verifies SSO is None when no SSO config is set (the default case), confirming backward compatibility:

```python
    def test_qr_sso_none_when_not_configured(self, client, created_users):
        """SSO block is None when org has no SSO-enabled profile."""
        uid = "qrfmt_sso_none"
        resp = create_test_user(client, uid, created_users)
        assert resp.status_code == 201, f"Setup failed: {resp.text}"

        resp = client.get(f"/api/users/{uid}/qrcode")
        assert resp.status_code == 200
        payload = resp.json()["payload"]
        inner = payload["payload"]

        # Default dev environment has no SSO-enabled config template
        assert inner["sso"] is None, "SSO should be None when no template has SSO enabled"
```

**Step 2:** Add a test to the `TestSignProvisioningPayload` class in `tests/test_qr_signing_unit.py` verifying the SSO dict round-trips correctly through sign/verify:

```python
    def test_sso_payload_roundtrip(self):
        """SSO payload should survive sign-verify roundtrip."""
        from qr_signing import sign_provisioning_payload, verify_provisioning_payload

        uc_payload = {"xmpp": {"domain": "test.com"}}
        sso_payload = {
            "provider": "oidc",
            "issuerUrl": "https://auth.example.com/application/o/app/",
            "clientId": "mobile-client",
            "scopes": "openid profile email offline_access",
            "pkceRequired": True,
        }

        signed = sign_provisioning_payload(uc_payload, sso_payload=sso_payload)
        valid, error, payload = verify_provisioning_payload(signed)

        assert valid is True
        assert error == ""
        assert payload["sso"] == sso_payload
```

**Verify:**
```bash
just test-quick -k "test_qr_sso_none_when_not_configured or test_sso_payload_roundtrip"
# Expected: Both PASSED
```

---

### Task 5: Add dnspython and websockets to requirements.txt
**domain:** backend
**issue:** #29
**depends_on:** []
**files:**
- `src/backend/requirements.txt` (MODIFY)

**Step 1:** Add two new dependencies at the end of `requirements.txt`:

```
dnspython>=2.6
websockets>=12.0
```

**Step 2:** Rebuild the API container to install the new deps:

```bash
just api-rebuild
```

**Verify:**
```bash
docker exec azblink-directory-api pip show dnspython websockets 2>/dev/null | grep -E "^Name:|^Version:"
# Expected: Shows dnspython and websockets with version numbers
```

---

### Task 6: Create UC endpoint validation module
**domain:** backend
**issue:** #29
**depends_on:** [Task 5]
**files:**
- `src/backend/uc_validation.py` (CREATE)

**Step 1:** Create `src/backend/uc_validation.py` with synchronous validation functions for DNS SRV and WebSocket endpoints. Use sync code since this is a one-off admin action, not a hot path:

```python
"""UC Endpoint Validation Module.

Validates DNS SRV records and WebSocket (WS/WSS) handshake connectivity
for XMPP and SIP service endpoints used in config templates.

Usage:
    from uc_validation import validate_endpoints

    results = validate_endpoints(
        xmpp_domain="xmpp.example.com",
        xmpp_ws_url="wss://xmpp.example.com/ws",
        sip_domain="sip.example.com",
        sip_wss_url="wss://sip.example.com/ws",
    )
"""

import time
import socket
import logging
from typing import Any
from dataclasses import dataclass, asdict

import dns.resolver

logger = logging.getLogger(__name__)

# Timeout for individual checks (seconds)
DNS_TIMEOUT = 5.0
WS_CONNECT_TIMEOUT = 5.0


@dataclass
class CheckResult:
    """Result of a single endpoint validation check."""
    name: str
    passed: bool
    latency_ms: float
    detail: str
    error: str | None = None


def _check_dns_srv(service: str, protocol: str, domain: str) -> CheckResult:
    """Check DNS SRV record for _service._protocol.domain."""
    name = f"SRV _{service}._{protocol}.{domain}"
    start = time.monotonic()
    try:
        resolver = dns.resolver.Resolver()
        resolver.lifetime = DNS_TIMEOUT
        qname = f"_{service}._{protocol}.{domain}"
        answers = resolver.resolve(qname, "SRV")
        elapsed = (time.monotonic() - start) * 1000
        targets = [f"{r.target}:{r.port} (pri={r.priority})" for r in answers]
        return CheckResult(
            name=name,
            passed=True,
            latency_ms=round(elapsed, 1),
            detail=f"Found {len(targets)} record(s): {', '.join(targets)}",
        )
    except dns.resolver.NXDOMAIN:
        elapsed = (time.monotonic() - start) * 1000
        return CheckResult(name=name, passed=False, latency_ms=round(elapsed, 1),
                           detail="", error="NXDOMAIN — no SRV record found")
    except dns.resolver.NoAnswer:
        elapsed = (time.monotonic() - start) * 1000
        return CheckResult(name=name, passed=False, latency_ms=round(elapsed, 1),
                           detail="", error="No SRV records in answer")
    except dns.resolver.LifetimeTimeout:
        elapsed = (time.monotonic() - start) * 1000
        return CheckResult(name=name, passed=False, latency_ms=round(elapsed, 1),
                           detail="", error=f"DNS timeout ({DNS_TIMEOUT}s)")
    except Exception as e:
        elapsed = (time.monotonic() - start) * 1000
        return CheckResult(name=name, passed=False, latency_ms=round(elapsed, 1),
                           detail="", error=str(e))


def _check_ws_handshake(url: str, label: str) -> CheckResult:
    """Attempt a WebSocket connection handshake (connect + close).

    Uses the synchronous websockets library. We don't send/receive data --
    just verify the server accepts a WS upgrade.
    """
    name = f"WS {label} ({url})"
    if not url:
        return CheckResult(name=name, passed=False, latency_ms=0,
                           detail="", error="URL is empty")
    start = time.monotonic()
    try:
        from websockets.sync.client import connect
        with connect(url, open_timeout=WS_CONNECT_TIMEOUT, close_timeout=2) as ws:
            ws.close()
        elapsed = (time.monotonic() - start) * 1000
        return CheckResult(name=name, passed=True, latency_ms=round(elapsed, 1),
                           detail="Handshake successful")
    except Exception as e:
        elapsed = (time.monotonic() - start) * 1000
        err_msg = str(e)
        # Truncate long error messages
        if len(err_msg) > 200:
            err_msg = err_msg[:200] + "..."
        return CheckResult(name=name, passed=False, latency_ms=round(elapsed, 1),
                           detail="", error=err_msg)


def validate_endpoints(
    xmpp_domain: str = "",
    xmpp_ws_url: str = "",
    sip_domain: str = "",
    sip_wss_url: str = "",
) -> dict[str, Any]:
    """Validate UC service endpoints with DNS SRV and WebSocket checks.

    Returns:
        {
            "checks": [...CheckResult as dicts...],
            "passed": int,
            "failed": int,
            "total": int,
        }
    """
    checks: list[CheckResult] = []

    # DNS SRV checks (XMPP: _xmpp-client._tcp, SIP: _sip._tcp + _sips._tcp)
    if xmpp_domain:
        checks.append(_check_dns_srv("xmpp-client", "tcp", xmpp_domain))
    if sip_domain:
        checks.append(_check_dns_srv("sip", "tcp", sip_domain))
        checks.append(_check_dns_srv("sips", "tcp", sip_domain))

    # WebSocket handshake checks
    if xmpp_ws_url:
        checks.append(_check_ws_handshake(xmpp_ws_url, "XMPP WS"))
    if sip_wss_url:
        checks.append(_check_ws_handshake(sip_wss_url, "SIP WSS"))

    passed = sum(1 for c in checks if c.passed)
    return {
        "checks": [asdict(c) for c in checks],
        "passed": passed,
        "failed": len(checks) - passed,
        "total": len(checks),
    }
```

**Verify:** File created, syntax check:
```bash
docker exec azblink-directory-api python -c "from uc_validation import validate_endpoints; print('OK')"
# Expected: OK
```

---

### Task 7: Add validation API endpoint and test
**domain:** backend
**issue:** #29
**depends_on:** [Task 6]
**files:**
- `src/backend/main.py` (MODIFY)
- `tests/test_uc_validation.py` (CREATE)

**Step 1:** Add import at the top of `main.py` (near other imports):

```python
from uc_validation import validate_endpoints
```

**Step 2:** Add the validation endpoint in `main.py` after the config template CRUD routes (find the config template section). Place near the existing template endpoints:

```python
@app.post("/api/config-templates/{template_id}/validate-endpoints")
@limiter.limit("5/minute")
def api_validate_template_endpoints(
    request: Request,
    template_id: str,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Validate UC service endpoints configured in a template.

    Runs DNS SRV lookups and WebSocket handshake tests for XMPP/SIP
    endpoints. Admin-only, rate-limited (5/min) since it makes
    outbound network requests.
    """
    template = ORGDB.get_config_template(template_id)
    if not template:
        raise HTTPException(404, "Template not found")

    results = validate_endpoints(
        xmpp_domain=template.get("xmpp_domain") or "",
        xmpp_ws_url=template.get("xmpp_ws_url") or "",
        sip_domain=template.get("sip_domain") or "",
        sip_wss_url=template.get("sip_wss_url") or "",
    )

    return {"ok": True, "templateId": template_id, **results}
```

**Step 3:** Create `tests/test_uc_validation.py`:

```python
"""Tests for UC endpoint validation API."""

import pytest


class TestUCValidation:
    """Test /api/config-templates/{id}/validate-endpoints."""

    def test_validate_nonexistent_template_404(self, client):
        """Returns 404 for nonexistent template."""
        resp = client.post("/api/config-templates/nonexistent-id/validate-endpoints")
        assert resp.status_code == 404

    def test_validate_returns_check_structure(self, client):
        """Validation response has checks array with pass/fail counts."""
        # Get the default template
        resp = client.get("/api/config-templates")
        assert resp.status_code == 200
        templates = resp.json()
        assert len(templates) > 0, "No config templates found"
        template_id = templates[0]["id"]

        resp = client.post(f"/api/config-templates/{template_id}/validate-endpoints")
        assert resp.status_code == 200
        data = resp.json()

        assert data["ok"] is True
        assert "checks" in data
        assert isinstance(data["checks"], list)
        assert "passed" in data
        assert "failed" in data
        assert "total" in data
        assert data["total"] == data["passed"] + data["failed"]

    def test_validate_check_has_required_fields(self, client):
        """Each check result has name, passed, latency_ms, detail fields."""
        resp = client.get("/api/config-templates")
        templates = resp.json()
        template_id = templates[0]["id"]

        resp = client.post(f"/api/config-templates/{template_id}/validate-endpoints")
        assert resp.status_code == 200
        data = resp.json()

        # Default template may have empty endpoints, but structure should be valid
        for check in data["checks"]:
            assert "name" in check
            assert "passed" in check
            assert isinstance(check["passed"], bool)
            assert "latency_ms" in check
            assert isinstance(check["latency_ms"], (int, float))
            assert "detail" in check

    def test_validate_requires_admin(self, anon_client):
        """Validation requires admin auth."""
        resp = anon_client.post("/api/config-templates/any-id/validate-endpoints")
        assert resp.status_code == 401
```

**Verify:**
```bash
just test-quick -k "test_uc_validation"
# Expected: All 4 tests PASSED
```

---

### Task 8: Create ppolicy overlay LDIF files
**domain:** devops
**issue:** #26
**depends_on:** [Task 2]
**files:**
- `deploy/dev/ldap/ppolicy-module.ldif` (CREATE)
- `deploy/dev/ldap/ppolicy-overlay.ldif` (CREATE)
- `deploy/dev/ldap/ppolicy-default.ldif` (CREATE)

**Step 1:** Create `deploy/dev/ldap/ppolicy-module.ldif` to load the ppolicy module:

```ldif
# Load ppolicy overlay module
dn: cn=module{0},cn=config
changetype: modify
add: olcModuleLoad
olcModuleLoad: ppolicy
```

**Step 2:** Create `deploy/dev/ldap/ppolicy-overlay.ldif` to configure the overlay on the main database:

```ldif
# Configure ppolicy overlay on main database
dn: olcOverlay=ppolicy,olcDatabase={1}mdb,cn=config
objectClass: olcOverlayConfig
objectClass: olcPPolicyConfig
olcOverlay: ppolicy
olcPPolicyDefault: cn=default,ou=policies,dc=azblink,dc=com
olcPPolicyHashCleartext: TRUE
olcPPolicyUseLockout: TRUE
```

**Step 3:** Create `deploy/dev/ldap/ppolicy-default.ldif` with a default password policy. This is a data LDIF (not config) that creates the policy entry:

```ldif
# Create policies OU and default password policy
dn: ou=policies,dc=azblink,dc=com
objectClass: organizationalUnit
ou: policies
description: Password and access policies

dn: cn=default,ou=policies,dc=azblink,dc=com
objectClass: pwdPolicy
objectClass: person
objectClass: top
cn: default
sn: default
pwdAttribute: userPassword
pwdMaxAge: 0
pwdExpireWarning: 0
pwdInHistory: 3
pwdCheckQuality: 1
pwdMinLength: 8
pwdMaxFailure: 5
pwdLockout: TRUE
pwdLockoutDuration: 300
pwdGraceAuthNLimit: 0
pwdFailureCountInterval: 0
pwdMustChange: FALSE
pwdAllowUserChange: TRUE
pwdSafeModify: FALSE
```

**Verify:** Files created. Syntax validation is done in Task 9 after mounting.

---

### Task 9: Mount ppolicy LDIFs and verify overlay loads
**domain:** devops
**issue:** #26
**depends_on:** [Task 8]
**files:**
- `deploy/dev/docker-compose.yml` (MODIFY)
- `deploy/dev/ldap/bootstrap.ldif` (MODIFY)

**Step 1:** Add the ppolicy config LDIFs as volume mounts to the openldap service. The osixia/openldap image processes LDIF files in `/container/service/slapd/assets/config/bootstrap/ldif/` on first boot.

However, the ppolicy module and overlay are **config-level** (cn=config) modifications, not data LDIFs. The osixia/openldap image loads module overlays from env vars. Instead, use environment variables that osixia supports:

Update the openldap service environment in `docker-compose.yml`:

```yaml
    environment:
      LDAP_ORGANISATION: ${LDAP_ORGANISATION:-AZBlink}
      LDAP_DOMAIN: ${LDAP_DOMAIN:-azblink.com}
      LDAP_ADMIN_PASSWORD: ${LDAP_ADMIN_PASSWORD:-adminpassword}
      LDAP_CONFIG_PASSWORD: ${LDAP_ADMIN_PASSWORD:-adminpassword}
      LDAP_READONLY_USER: "false"
      LDAP_TLS: "false"
```

Since osixia/openldap:1.5.0 does NOT have a simple env var for ppolicy, we need to use the custom LDIF approach. Add the ppolicy default policy to the bootstrap.ldif (which is already mounted) since it contains data entries:

**Step 2:** Append to `deploy/dev/ldap/bootstrap.ldif` (after the Managers group, at the end of the file):

```ldif

# ============================================================
# Password Policies (ppolicy overlay)
# ============================================================

dn: ou=policies,dc=azblink,dc=com
objectClass: organizationalUnit
ou: policies
description: Password and access policies

dn: cn=default,ou=policies,dc=azblink,dc=com
objectClass: pwdPolicy
objectClass: person
objectClass: top
cn: default
sn: default
pwdAttribute: userPassword
pwdMaxAge: 0
pwdExpireWarning: 0
pwdInHistory: 3
pwdCheckQuality: 1
pwdMinLength: 8
pwdMaxFailure: 5
pwdLockout: TRUE
pwdLockoutDuration: 300
pwdGraceAuthNLimit: 0
pwdFailureCountInterval: 0
pwdMustChange: FALSE
pwdAllowUserChange: TRUE
pwdSafeModify: FALSE
```

**Step 3:** Mount the ppolicy module and overlay config LDIFs. These need to be applied via the container's config bootstrap mechanism. Add volume mounts:

```yaml
      - ./ldap/ppolicy-module.ldif:/container/service/slapd/assets/config/bootstrap/ldif/03-ppolicy-module.ldif:ro
      - ./ldap/ppolicy-overlay.ldif:/container/service/slapd/assets/config/bootstrap/ldif/04-ppolicy-overlay.ldif:ro
```

**IMPORTANT NOTE:** The osixia/openldap image processes config LDIFs in `/container/service/slapd/assets/config/bootstrap/ldif/` (NOT the `custom/` subdirectory) as `ldapmodify` operations against cn=config. The `custom/` subdirectory is for data LDIFs applied with `ldapadd`. The ppolicy module and overlay LDIFs are config modifications, so they go in the parent directory.

However, there is a subtlety: osixia's `custom/` directory LDIFs are applied with `ldapadd` to the main DB, while LDIFs in the parent directory may be processed differently. The safest approach for ppolicy is:

**Alternative Step 3 (safer):** Instead of separate LDIF mounts for config-level changes, add ppolicy via the osixia-supported `LDAP_OPENLDAP_GID` mechanism. Actually, the most reliable method for osixia is to set:

```yaml
    environment:
      # ... existing env ...
      LDAP_BACKEND: mdb
```

And then, for the ppolicy overlay specifically, we should handle this in a one-time init script. However, for simplicity in dev, we can test without the ppolicy overlay config and just add the policy data entries. The ppolicy overlay module loading can be deferred to a post-startup script.

**Revised approach:** Remove the separate ppolicy-module.ldif and ppolicy-overlay.ldif mounts. Instead, just add the policies OU and default policy to bootstrap.ldif (Step 2 above). The ppolicy overlay activation will be handled by a small init script:

Add one more volume mount for a post-start init script:

```yaml
      - ./ldap/init-ppolicy.sh:/container/service/slapd/assets/config/bootstrap/ldif/03-ppolicy.ldif:ro
```

Actually, let's keep it simpler. The cleanest approach for osixia:

Delete `ppolicy-module.ldif` and `ppolicy-overlay.ldif` (created in Task 8). Instead create a single combined config LDIF:

Create `deploy/dev/ldap/ppolicy-config.ldif`:
```ldif
dn: cn=module{0},cn=config
changetype: modify
add: olcModuleLoad
olcModuleLoad: ppolicy

dn: olcOverlay=ppolicy,olcDatabase={1}mdb,cn=config
changetype: add
objectClass: olcOverlayConfig
objectClass: olcPPolicyConfig
olcOverlay: ppolicy
olcPPolicyDefault: cn=default,ou=policies,dc=azblink,dc=com
olcPPolicyHashCleartext: TRUE
olcPPolicyUseLockout: TRUE
```

Mount it as a config-level LDIF (non-custom directory):
```yaml
      - ./ldap/ppolicy-config.ldif:/container/service/slapd/assets/config/bootstrap/ldif/ppolicy-config.ldif:ro
```

**Step 4:** Reset and restart:
```bash
just reset && just up-bg
```

**Verify:**
```bash
# Wait for healthy, then check ppolicy overlay is active
docker exec azblink-openldap ldapsearch -Q -Y EXTERNAL -H ldapi:/// -b "olcDatabase={1}mdb,cn=config" "(olcOverlay=ppolicy)" olcOverlay 2>/dev/null
# Expected: olcOverlay: ppolicy

# Check default policy entry exists
docker exec azblink-openldap ldapsearch -x -H ldap://localhost:389 -D "cn=admin,dc=azblink,dc=com" -w adminpassword -b "cn=default,ou=policies,dc=azblink,dc=com" pwdMinLength 2>/dev/null
# Expected: pwdMinLength: 8

# Run full test suite to verify nothing broke
just test-quick
# Expected: All existing tests pass
```

**CRITICAL NOTE:** If ppolicy config LDIF loading fails on first boot (osixia can be finicky about config LDIFs), the fallback is to remove the ppolicy-config.ldif mount and apply it manually post-start. Document this in a comment in docker-compose.yml. The policy data in bootstrap.ldif is harmless even without the overlay.

---

### Task 10: Add offline_access scope mapping to Authentik seed
**domain:** devops
**issue:** #27
**depends_on:** []
**files:**
- `deploy/dev/authentik-seed/seed_authentik.py` (MODIFY)

**Step 1:** In `get_scope_mapping_pks()`, add the `offline_access` scope mapping to the `wanted` set (line ~133):

Change:
```python
    wanted = {
        "goauthentik.io/providers/oauth2/scope-openid",
        "goauthentik.io/providers/oauth2/scope-profile",
        "goauthentik.io/providers/oauth2/scope-email",
    }
```

To:
```python
    wanted = {
        "goauthentik.io/providers/oauth2/scope-openid",
        "goauthentik.io/providers/oauth2/scope-profile",
        "goauthentik.io/providers/oauth2/scope-email",
        "goauthentik.io/providers/oauth2/scope-offline_access",
    }
```

**Step 2:** Update the warning check on line ~144 from `len(pks) != 3` to `len(pks) != 4`:

Change:
```python
    if len(pks) != 3:
        print(f"  WARNING: expected 3 scope mappings, found {len(pks)}")
```

To:
```python
    if len(pks) != 4:
        print(f"  WARNING: expected 4 scope mappings, found {len(pks)}")
```

**Verify:**
```bash
# Restart the seed container to re-run
docker restart azblink-authentik-seed && sleep 10 && docker logs azblink-authentik-seed 2>&1 | tail -20
# Expected: "Found scope mapping: offline_access ..." in output, or "Patched provider: property_mappings"
```

---

### Task 11: Add offline_access scope and refresh token storage to frontend OIDC
**domain:** frontend
**issue:** #27
**depends_on:** [Task 10]
**files:**
- `src/frontend/src/lib/oidc.ts` (MODIFY)
- `src/frontend/src/stores/auth-store.ts` (MODIFY)

**Step 1:** In `oidc.ts`, add `offline_access` to the scope request in `startOidcLogin()` (line 175):

Change:
```typescript
  authUrl.searchParams.set('scope', 'openid profile email');
```

To:
```typescript
  authUrl.searchParams.set('scope', 'openid profile email offline_access');
```

**Step 2:** Add a `refreshTokens` function to `oidc.ts` that exchanges a refresh token for a new access token. Add this after `exchangeCodeForTokens`:

```typescript
/** Exchange refresh token for new access + refresh tokens. */
export async function refreshTokens(refreshToken: string): Promise<OidcTokenResponse> {
  const discovery = await getDiscovery();
  const resp = await fetch(discovery.token_endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      client_id: OIDC_CLIENT_ID,
      refresh_token: refreshToken,
    }),
  });

  if (!resp.ok) {
    const error = await resp.text();
    throw new Error(`Token refresh failed: ${resp.status} ${error}`);
  }

  return resp.json();
}
```

**Step 3:** Update `auth-store.ts` to store the refresh token. Add `refreshToken` to the state:

In the `AuthState` interface, add:
```typescript
  refreshToken: string | null;
```

In the `setAuth` method signature and implementation, accept and store the refresh token:

Change the `setAuth` signature in the interface:
```typescript
  setAuth: (token: string, user: AuthUser, expiresInSeconds: number, refreshToken?: string) => void;
```

Change the `setAuth` implementation:
```typescript
      setAuth: (token, user, expiresInSeconds, refreshToken) => {
        // DS-5: Cap session to server-side sessionTimeoutMinutes
        let effectiveExpiry = expiresInSeconds;
        try {
          const cached = sessionStorage.getItem('azblink-session-timeout-min');
          if (cached) {
            const serverMaxSec = parseInt(cached, 10) * 60;
            if (serverMaxSec > 0 && serverMaxSec < effectiveExpiry) {
              effectiveExpiry = serverMaxSec;
            }
          }
        } catch {
          // sessionStorage not available — use token expiry as-is
        }
        set({
          token,
          user,
          expiresAt: Date.now() + effectiveExpiry * 1000,
          refreshToken: refreshToken ?? null,
        });
      },
```

Update the initial state to include `refreshToken: null`.

Update `logout` to clear it:
```typescript
      logout: async () => {
        set({ token: null, user: null, expiresAt: null, refreshToken: null });
        // ... rest unchanged
```

Update `partialize` to persist it:
```typescript
      partialize: (state) => ({
        token: state.token,
        user: state.user,
        expiresAt: state.expiresAt,
        refreshToken: state.refreshToken,
      }),
```

**Verify:**
```bash
# Hot reload should handle this — check no TypeScript errors
docker logs azblink-directory-ui 2>&1 | tail -5
# Expected: No TS compilation errors
```

---

### Task 12: Wire refresh token in auth callback and add 401 refresh interceptor
**domain:** frontend
**issue:** #27
**depends_on:** [Task 11]
**files:**
- `src/frontend/src/routes/auth/callback.tsx` (MODIFY)
- `src/frontend/src/main.tsx` (MODIFY)
- `src/frontend/src/lib/api-client.ts` (MODIFY)

**Step 1:** In `auth/callback.tsx`, pass the refresh token to `setAuth` (line ~69):

Change:
```typescript
        setAuth(tokens.access_token, user, tokens.expires_in);
```

To:
```typescript
        setAuth(tokens.access_token, user, tokens.expires_in, tokens.refresh_token);
```

**Step 2:** In `api-client.ts`, add a token refresh mechanism. The approach: on 401, if we have a refresh token, attempt to refresh before calling `onUnauthorized`. Add a `getRefreshToken` and `onTokenRefreshed` callback to the config:

Update `ApiClientConfig`:
```typescript
export interface ApiClientConfig {
  baseUrl: string;
  getAuthToken?: () => Promise<string | null>;
  getRefreshToken?: () => string | null;
  onTokenRefreshed?: (response: { access_token: string; refresh_token?: string; expires_in: number }) => void;
  onUnauthorized?: (hadToken: boolean) => void;
  onRateLimited?: (retryAfter: number) => void;
}
```

Replace the 401 handling block (lines 63-68) with refresh logic:

```typescript
    // Handle unauthorized — attempt refresh if we have a refresh token
    if (response.status === 401) {
      if (token && config.getRefreshToken && config.onTokenRefreshed) {
        const rt = config.getRefreshToken();
        if (rt && !_isRefreshing) {
          _isRefreshing = true;
          try {
            const { refreshTokens } = await import('@/lib/oidc');
            const newTokens = await refreshTokens(rt);
            config.onTokenRefreshed(newTokens);
            _isRefreshing = false;
            // Retry the original request with new token
            headers['Authorization'] = `Bearer ${newTokens.access_token}`;
            const retryResponse = await fetch(url, {
              method,
              headers,
              body: body ? JSON.stringify(body) : undefined,
            });
            if (retryResponse.ok) return retryResponse.json();
            if (retryResponse.status === 401) {
              onUnauthorized?.(true);
              throw await extractError(retryResponse);
            }
            if (!retryResponse.ok) throw await extractError(retryResponse);
            return retryResponse.json();
          } catch (refreshError) {
            _isRefreshing = false;
            onUnauthorized?.(true);
            throw await extractError(response);
          }
        }
      }
      onUnauthorized?.(!!token);
      throw await extractError(response);
    }
```

Add a module-level flag to prevent concurrent refresh attempts. Add this before the `createApiClient` function:

```typescript
let _isRefreshing = false;
```

**Step 3:** In `main.tsx`, wire up the refresh callbacks in `initializeApi`:

Change:
```typescript
initializeApi({
  baseUrl: import.meta.env.VITE_API_BASE || '/api',
  getAuthToken: () => Promise.resolve(useAuthStore.getState().token),
  onUnauthorized: (hadToken: boolean) => {
```

To:
```typescript
initializeApi({
  baseUrl: import.meta.env.VITE_API_BASE || '/api',
  getAuthToken: () => Promise.resolve(useAuthStore.getState().token),
  getRefreshToken: () => useAuthStore.getState().refreshToken,
  onTokenRefreshed: (tokens) => {
    const state = useAuthStore.getState();
    if (state.user) {
      state.setAuth(tokens.access_token, state.user, tokens.expires_in, tokens.refresh_token);
    }
  },
  onUnauthorized: (hadToken: boolean) => {
```

**Verify:**
```bash
# Hot reload should handle this — check Vite HMR
docker logs azblink-directory-ui 2>&1 | tail -10
# Expected: No TS compilation errors, HMR update applied
```

---

### Task 13: Add proactive token refresh before expiry
**domain:** frontend
**issue:** #27
**depends_on:** [Task 12]
**files:**
- `src/frontend/src/routes/__root.tsx` (MODIFY)

**Step 1:** Add a `useTokenRefresh` hook that proactively refreshes the access token 5 minutes before expiry. Find `__root.tsx` and add a refresh effect inside the root layout component.

First, check what the root route looks like:

```typescript
import { refreshTokens } from '@/lib/oidc';
```

Add a `useEffect` inside the root component that sets up a timer:

```typescript
  // Proactive token refresh — refresh 5 min before expiry
  useEffect(() => {
    const checkInterval = 60_000; // Check every minute
    const REFRESH_MARGIN_MS = 5 * 60 * 1000; // 5 minutes before expiry

    const timer = setInterval(async () => {
      const { token, expiresAt, refreshToken, user } = useAuthStore.getState();
      if (!token || !expiresAt || !refreshToken || !user) return;

      const timeToExpiry = expiresAt - Date.now();
      if (timeToExpiry > REFRESH_MARGIN_MS) return; // Not yet time
      if (timeToExpiry <= 0) return; // Already expired — let 401 handler deal with it

      try {
        const newTokens = await refreshTokens(refreshToken);
        useAuthStore.getState().setAuth(
          newTokens.access_token,
          user,
          newTokens.expires_in,
          newTokens.refresh_token,
        );
        console.debug('[auth] Token refreshed proactively');
      } catch (err) {
        console.warn('[auth] Proactive refresh failed:', err);
        // Don't logout — the 401 interceptor will handle it on next API call
      }
    }, checkInterval);

    return () => clearInterval(timer);
  }, []);
```

**Verify:**
```bash
# Hot reload — verify no errors
docker logs azblink-directory-ui 2>&1 | tail -10
# Expected: No compilation errors

# Full test suite to verify nothing regressed
just test-quick
# Expected: All tests pass
```

---

## Parallelization Summary

| Phase | Tasks | Can Parallel? |
|-------|-------|--------------|
| 1 | Task 1, 2 | Sequential (2 depends on 1) |
| 2 | Task 3-4, Task 5-7, Task 10 | **All three tracks in parallel** |
| 3 | Task 8-9 | Sequential (9 depends on 8), after Task 2 |
| 4 | Task 11, 12, 13 | Sequential chain |

## Final Verification

After all tasks are complete:

```bash
# Full reset to verify clean-slate deployment
just reset && just up-bg

# Wait for stack healthy (~60s for Authentik)
sleep 90

# Run full test suite
just test-quick

# Verify LDAP schema loaded
docker exec azblink-openldap ldapsearch -Q -Y EXTERNAL -H ldapi:/// -b cn=schema,cn=config '(cn=*azblink*)' cn 2>/dev/null | grep azblink

# Verify ppolicy overlay
docker exec azblink-openldap ldapsearch -Q -Y EXTERNAL -H ldapi:/// -b "olcDatabase={1}mdb,cn=config" "(olcOverlay=ppolicy)" olcOverlay 2>/dev/null

# Manual: Log in via Authentik, verify refresh token is stored in localStorage
# Check: localStorage['azblink-auth'] should contain refreshToken field
```

## Files Created (5)
1. `deploy/dev/ldap/azblink.schema`
2. `deploy/dev/ldap/ppolicy-config.ldif`
3. `src/backend/uc_validation.py`
4. `tests/test_uc_validation.py`
5. `deploy/dev/ldap/ppolicy-module.ldif` (deleted in Task 9, replaced by ppolicy-config.ldif)
6. `deploy/dev/ldap/ppolicy-overlay.ldif` (deleted in Task 9, replaced by ppolicy-config.ldif)
7. `deploy/dev/ldap/ppolicy-default.ldif` (deleted in Task 9, merged into bootstrap.ldif)

## Files Modified (9)
1. `deploy/dev/docker-compose.yml` — schema + ppolicy mounts
2. `src/backend/main.py` — SSO resolver + validation endpoint + import
3. `src/backend/requirements.txt` — dnspython, websockets
4. `tests/test_qr_format.py` — SSO null test
5. `tests/test_qr_signing_unit.py` — SSO roundtrip test
6. `deploy/dev/authentik-seed/seed_authentik.py` — offline_access scope
7. `src/frontend/src/lib/oidc.ts` — offline_access scope + refreshTokens
8. `src/frontend/src/stores/auth-store.ts` — refreshToken state
9. `src/frontend/src/routes/auth/callback.tsx` — pass refresh token
10. `src/frontend/src/lib/api-client.ts` — 401 refresh interceptor
11. `src/frontend/src/main.tsx` — wire refresh callbacks
12. `src/frontend/src/routes/__root.tsx` — proactive refresh timer
13. `deploy/dev/ldap/bootstrap.ldif` — ppolicy data entries
