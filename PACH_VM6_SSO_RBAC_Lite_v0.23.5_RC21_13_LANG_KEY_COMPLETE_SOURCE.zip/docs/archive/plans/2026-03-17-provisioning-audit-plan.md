# Provisioning Audit Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add device_provisions as a 5th audit source in the unified audit system.
**Architecture:** Dedicated `provisioning_audit` table, new `record_provisioning_audit()` method, 5th UNION ALL subquery, frontend types/config/filter updates.
**Tech Stack:** Python/FastAPI/SQLAlchemy (backend), PostgreSQL (migration), React/TypeScript (frontend)
**Domains:** database, backend, frontend, test
**Spec:** `docs/superpowers/specs/2026-03-17-provisioning-audit-design.md`

---

### Task 1: Database Migration
**domain:** database
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [postgresql, sqlalchemy]

**Files:**
- Create: `migrations/026_provisioning_audit.sql`
- Modify: `src/backend/orgdb.py` (add SQLAlchemy table definition after `admin_action_audit`)

**Step 1:** Create `migrations/026_provisioning_audit.sql` with:
```sql
-- 026: Provisioning audit table for device provisioning event tracking
CREATE TABLE IF NOT EXISTS provisioning_audit (
    id            SERIAL PRIMARY KEY,
    action        VARCHAR(32) NOT NULL,
    actor         VARCHAR(128) NOT NULL,
    target_uid    VARCHAR(128) NOT NULL,
    device_id     VARCHAR(128),
    token_hash    VARCHAR(128),
    auth_method   VARCHAR(16),
    platform      VARCHAR(32),
    client_ip     VARCHAR(45),
    detail        JSONB,
    timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_prov_audit_target ON provisioning_audit(target_uid);
CREATE INDEX IF NOT EXISTS idx_prov_audit_timestamp ON provisioning_audit(timestamp);
CREATE INDEX IF NOT EXISTS idx_prov_audit_action ON provisioning_audit(action);
```

**Step 2:** Add SQLAlchemy table definition in `orgdb.py` after `admin_action_audit` (line ~212):
```python
provisioning_audit = Table(
    "provisioning_audit",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("action", String(32), nullable=False),
    Column("actor", String(128), nullable=False),
    Column("target_uid", String(128), nullable=False),
    Column("device_id", String(128), nullable=True),
    Column("token_hash", String(128), nullable=True),
    Column("auth_method", String(16), nullable=True),
    Column("platform", String(32), nullable=True),
    Column("client_ip", String(45), nullable=True),
    Column("detail", JSON, nullable=True),
    Column("timestamp", DateTime(timezone=True), nullable=False, server_default=func.now()),
)
```

**Step 3:** Run the migration: `just psql < ../../migrations/026_provisioning_audit.sql`

**Step 4:** Verify table exists: `just psql -c "\\d provisioning_audit"`

---

### Task 2: Backend — record_provisioning_audit() Method
**domain:** backend
**depends_on:** [1]
**parallel_group:** 2
**capabilities_needed:** [fastapi, sqlalchemy, activity-bus]

**Files:**
- Modify: `src/backend/orgdb.py` (add method + UNION ALL subquery)

**Step 1:** Add `record_provisioning_audit()` method after `record_admin_action()` (~line 1195):
```python
def record_provisioning_audit(
    self,
    action: str,
    actor: str,
    target_uid: str,
    *,
    device_id: str | None = None,
    token_hash: str | None = None,
    auth_method: str | None = None,
    platform: str | None = None,
    client_ip: str | None = None,
    detail: dict | None = None,
) -> int:
    """Record a device provisioning audit event and publish activity bus event."""
    eng = self.connect()
    with eng.begin() as conn:
        result = conn.execute(
            insert(provisioning_audit).values(
                action=action,
                actor=actor,
                target_uid=target_uid,
                device_id=device_id,
                token_hash=token_hash,
                auth_method=auth_method,
                platform=platform,
                client_ip=client_ip,
                detail=json.dumps(detail) if detail else None,
                timestamp=utcnow(),
            )
        )
        row_id = result.inserted_primary_key[0]
    # Activity bus — match existing _publish_activity_event shape
    _title_map = {
        "provisioned": "Device Provisioned (SSO)",
        "consumed": "Device Provisioned (QR)",
        "revoked": "Device Revoked",
        "bulk-revoked": "Bulk Token Revocation",
        "extended": "Token Extended",
    }
    _publish_activity_event({
        "id": f"prov-{row_id}",
        "type": "provisioning",
        "text": f"{_title_map.get(action, action)} — {target_uid}",
        "meta": f"By {actor}" + (f" device={device_id}" if device_id else ""),
        "time": "just now",
        "timestamp": utcnow().isoformat(),
    })
    return row_id
```

**Step 2:** Add 5th UNION ALL subquery in `list_unified_audit()` after `aa_sql` (line ~1375):
```python
# --- Provisioning audit events ---
pa_sql = """
    SELECT
        'AUD-' || LPAD((50000 + pa.id)::text, 5, '0') AS id,
        CASE pa.action
            WHEN 'provisioned' THEN 'device-provisioned'
            WHEN 'consumed'    THEN 'device-provisioned'
            WHEN 'revoked'     THEN 'device-revoked'
            WHEN 'bulk-revoked' THEN 'device-revoked'
            WHEN 'extended'    THEN 'device-extended'
            ELSE 'device-provisioned'
        END AS event_type,
        pa.timestamp AS timestamp,
        CASE pa.action
            WHEN 'provisioned' THEN 'Device Provisioned (SSO)'
            WHEN 'consumed'    THEN 'Device Provisioned (QR)'
            WHEN 'revoked'     THEN 'Device Revoked'
            WHEN 'bulk-revoked' THEN 'Bulk Token Revocation'
            WHEN 'extended'    THEN 'Token Extended'
            ELSE pa.action
        END AS title,
        COALESCE(pa.detail->>'description', pa.action || ' for ' || pa.target_uid) AS description,
        pa.actor AS actor,
        pa.target_uid AS target,
        'PRV-' || LPAD(pa.id::text, 4, '0') AS reference_id,
        'success' AS result,
        'provisioning' AS category,
        NULL::int AS duration_ms,
        NULL AS organization,
        pa.client_ip AS ip_address,
        json_build_object('device_id', pa.device_id, 'platform', pa.platform)::text AS device_json,
        row_to_json(pa.*)::text AS raw_data
    FROM provisioning_audit pa
"""
parts.append(pa_sql)
```

**Step 3:** Update the docstring of `list_unified_audit()` to mention provisioning_audit as a 5th source.

---

### Task 3: Backend — revoke_tokens_for_user() Returns Token Hashes
**domain:** backend
**depends_on:** [1]
**parallel_group:** 2
**capabilities_needed:** [sqlalchemy]

**Files:**
- Modify: `src/backend/orgdb.py` (`revoke_tokens_for_user` at line ~745)

**Step 1:** Modify `revoke_tokens_for_user()` to return both count and hashes:
```python
def revoke_tokens_for_user(self, uid: str) -> tuple[int, list[str]]:
    """Revoke all active provision tokens for a user.

    Returns (count_revoked, list_of_token_hashes).
    """
    eng = self.connect()
    with eng.begin() as conn:
        # First get the hashes that will be revoked
        hashes_result = conn.execute(
            select(device_provisions.c.token_hash).where(
                (device_provisions.c.uid == uid) &
                (device_provisions.c.status == "active")
            )
        )
        token_hashes = [r[0] for r in hashes_result]

        if not token_hashes:
            return 0, []

        result = conn.execute(
            update(device_provisions)
            .where(
                (device_provisions.c.uid == uid) &
                (device_provisions.c.status == "active")
            )
            .values(status="revoked_terminated", used_at=utcnow())
        )
        return result.rowcount, token_hashes
```

**Step 2:** Update the call site in `main.py` (line ~1489) to destructure the new return:
```python
# Old: tokens_revoked = ORGDB.revoke_tokens_for_user(uid)
# New:
tokens_revoked, revoked_hashes = ORGDB.revoke_tokens_for_user(uid)
```

---

### Task 4: Backend — Audit Calls in Provisioning Endpoints
**domain:** backend
**depends_on:** [2, 3]
**parallel_group:** 3
**capabilities_needed:** [fastapi]

**Files:**
- Modify: `src/backend/main.py` (7 endpoints + valid_categories)

**Step 1:** `POST /api/provision/device` (line ~3463, after upsert_device_provision):
```python
try:
    ORGDB.record_provisioning_audit(
        action="provisioned",
        actor=uid,
        target_uid=uid,
        device_id=req.deviceId,
        auth_method="sso",
        platform=req.clientInfo.platform if req.clientInfo else None,
        client_ip=request.client.host if request.client else None,
        detail={"device_cap_used": current_count + 1, "device_cap_max": max_devices},
    )
except Exception:
    logger.warning("Failed to record provisioning audit for uid=%s", uid, exc_info=True)
```

**Step 2:** `POST /api/provision/consume` (line ~1797, after update_provision_token_device):
```python
try:
    ORGDB.record_provisioning_audit(
        action="consumed",
        actor=token_data.get("uid", "unknown"),
        target_uid=token_data.get("uid", "unknown"),
        token_hash=token_hash,
        auth_method="qr",
        platform=platform,
        client_ip=client_ip,
        detail={"auth_method": "qr", "platform": platform, "client_version": version},
    )
except Exception:
    logger.warning("Failed to record provisioning audit for token consume", exc_info=True)
```

**Step 3:** `POST /api/provision/validate` (line ~1726, after successful validation):
```python
try:
    ORGDB.record_provisioning_audit(
        action="consumed",
        actor=token_data.get("uid", "unknown"),
        target_uid=token_data.get("uid", "unknown"),
        token_hash=token_hash,
        auth_method="qr",
        client_ip=request.client.host if request.client else None,
    )
except Exception:
    logger.warning("Failed to record provisioning audit for token validate", exc_info=True)
```

**Step 4:** `DELETE /api/provision/device/{device_id}` (line ~3497, after revoke_device_provision):
```python
try:
    ORGDB.record_provisioning_audit(
        action="revoked",
        actor=uid,
        target_uid=uid,
        device_id=device_id,
        client_ip=request.client.host if request.client else None,
    )
except Exception:
    logger.warning("Failed to record provisioning audit for device revoke", exc_info=True)
```

**Step 5:** `POST /api/provisioning/tokens/bulk-revoke` (line ~1917, after bulk_revoke_tokens):
```python
try:
    ORGDB.record_provisioning_audit(
        action="bulk-revoked",
        actor=extract_actor(claims),
        target_uid="multiple",
        detail={
            "count": result.get("revoked_count", 0),
            "skipped": result.get("skipped_count", 0),
            "token_hashes": req.token_hashes,
        },
    )
except Exception:
    logger.warning("Failed to record provisioning audit for bulk revoke", exc_info=True)
```

**Step 6:** `POST /api/provisioning/tokens/{token_hash}/extend` (line ~1942, after extend_token_expiry):
```python
try:
    ORGDB.record_provisioning_audit(
        action="extended",
        actor=extract_actor(claims),
        target_uid=result.get("uid", "unknown"),
        token_hash=token_hash,
        detail={
            "old_expires_at": result.get("old_expires_at"),
            "new_expires_at": result.get("new_expires_at"),
            "extend_seconds": req.extend_seconds,
        },
    )
except Exception:
    logger.warning("Failed to record provisioning audit for token extend", exc_info=True)
```

**Step 7:** Termination — `revoke_tokens_for_user` call site (line ~1489):
```python
tokens_revoked, revoked_hashes = ORGDB.revoke_tokens_for_user(uid)
actions["tokens_revoked"] = tokens_revoked
if tokens_revoked > 0:
    try:
        ORGDB.record_provisioning_audit(
            action="bulk-revoked",
            actor=terminated_by,
            target_uid=uid,
            detail={
                "count": tokens_revoked,
                "reason": "user_termination",
                "token_hashes": revoked_hashes,
            },
        )
    except Exception:
        logger.warning("Failed to record provisioning audit for termination revoke", exc_info=True)
```

**Step 8:** Update `valid_categories` in both audit endpoints (lines 2559 and 2593):
```python
# Old: valid_categories = {"all", "qr", "user", "auth", "config", "admin"}
# New:
valid_categories = {"all", "user", "auth", "config", "admin", "provisioning"}
```

---

### Task 5: Frontend — Types and Event Config
**domain:** frontend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [typescript, react]

**Files:**
- Modify: `src/frontend/src/types/audit.ts`
- Modify: `src/frontend/src/components/features/audit-management/audit-event-config.ts`

**Step 1:** Update `AuditEventType` in `audit.ts` (line 37-43):
```typescript
export type AuditEventType =
  | 'user-created'
  | 'user-terminated'
  | 'sso-enrolled'
  | 'config-change'
  | 'admin-action'
  | 'login'
  | 'device-provisioned'
  | 'device-revoked'
  | 'device-extended';
```

**Step 2:** Update `EventCategory` in `audit.ts` (line 45):
```typescript
export type EventCategory = 'user' | 'auth' | 'config' | 'admin' | 'provisioning';
```

**Step 3:** Update `AuditDeviceInfo` in `audit.ts` (line 49-54):
```typescript
export interface AuditDeviceInfo {
  model: string;
  os: string;
  app_version: string | null;
  user_agent: string | null;
  device_id?: string;
  platform?: string;
}
```

**Step 4:** Update comment on line 36:
```typescript
/** 9 supported event types — includes device provisioning audit */
```

**Step 5:** Add imports and configs in `audit-event-config.ts`:
```typescript
// Add to imports:
import { Smartphone, ShieldX, Clock } from 'lucide-react';

// Add to auditEventConfig record:
'device-provisioned': {
  icon: Smartphone,
  fg: 'text-green-500',
  bg: 'bg-green-500/10',
  label: 'Device Provisioned',
},
'device-revoked': {
  icon: ShieldX,
  fg: 'text-red-500',
  bg: 'bg-red-500/10',
  label: 'Device Revoked',
},
'device-extended': {
  icon: Clock,
  fg: 'text-amber-500',
  bg: 'bg-amber-500/10',
  label: 'Token Extended',
},
```

---

### Task 6: Frontend — Filter Bar and Detail Panel
**domain:** frontend
**depends_on:** [5]
**parallel_group:** 2
**capabilities_needed:** [react, typescript]

**Files:**
- Modify: `src/frontend/src/components/features/audit-management/AuditFilterBar.tsx`
- Modify: `src/frontend/src/components/features/audit-management/AuditDetailPanel.tsx`

**Step 1:** Add provisioning category option in `AuditFilterBar.tsx` (line ~34):
```typescript
{ value: 'provisioning', label: 'Provisioning' },
```

**Step 2:** Add provisioning filter chip in `AuditFilterBar.tsx` (line ~38):
```typescript
import { Smartphone } from 'lucide-react';

const filterChips: ToggleChip[] = [
  { id: 'user-events', label: 'User Events', icon: <User className="h-3.5 w-3.5" /> },
  { id: 'provisioning-events', label: 'Provisioning', icon: <Smartphone className="h-3.5 w-3.5" /> },
];
```

**Step 3:** Update device info section in `AuditDetailPanel.tsx` (lines 84-95) to handle both shapes:
```typescript
{event.device && (
  <div className="px-5 py-4 border-b border-[var(--color-border-subtle)]">
    <h3 className="text-sm font-medium text-text mb-3">Device Information</h3>
    <DetailGrid>
      {event.device.device_id && <FieldCard label="Device ID" value={event.device.device_id} mono />}
      {event.device.platform && <FieldCard label="Platform" value={event.device.platform} />}
      {event.device.model && <FieldCard label="Device" value={event.device.model} />}
      {event.device.os && <FieldCard label="OS" value={event.device.os} />}
      {event.device.app_version && <FieldCard label="App Version" value={event.device.app_version} mono />}
      {event.device.user_agent && <FieldCard label="User Agent" value={event.device.user_agent} mono />}
    </DetailGrid>
  </div>
)}
```

---

### Task 7: Test Cleanup Fixture
**domain:** test
**depends_on:** [1]
**parallel_group:** 1
**capabilities_needed:** [pytest]

**Files:**
- Modify: `tests/conftest.py`

**Step 1:** Add `provisioning_audit` cleanup to the existing cleanup fixture (after line ~154):
```python
cur.execute("DELETE FROM provisioning_audit WHERE target_uid = %s", (uid,))
```

---

### Task 8: Integration Tests
**domain:** test
**depends_on:** [4, 5, 6, 7]
**parallel_group:** 4
**capabilities_needed:** [pytest, fastapi-testing]

**Files:**
- Create: `tests/test_provisioning_audit.py`

**Step 1:** Create test file with all 10 test cases from the spec. Each test:
1. Calls the provisioning endpoint
2. Queries the database directly to verify the audit record was created
3. Verifies field values (action, actor, target_uid, detail JSON)

**Step 2:** Test unified audit integration:
1. Create a provisioning audit record
2. Call `GET /api/audit/events?category=provisioning`
3. Verify the event appears with `PRV-` prefix and correct fields

**Step 3:** Test category filter isolation:
1. Create records in multiple audit tables
2. Call `GET /api/audit/events?category=provisioning`
3. Verify only provisioning events returned

**Step 4:** Run all tests: `just test-quick`

---

## Parallel Execution Groups

| Group | Tasks | Can Run Simultaneously |
|-------|-------|----------------------|
| 1 | Task 1 (migration), Task 5 (frontend types), Task 7 (test fixture) | Yes — independent files |
| 2 | Task 2 (orgdb method), Task 3 (revoke return), Task 6 (frontend filter/detail) | Yes — backend vs frontend |
| 3 | Task 4 (endpoint audit calls) | Sequential — depends on Tasks 2+3 |
| 4 | Task 8 (integration tests) | Sequential — depends on all code changes |

## Task Dependencies

```
Task 1 (migration) ──┬──> Task 2 (orgdb method) ──┐
                      ├──> Task 3 (revoke return) ──┼──> Task 4 (endpoint calls) ──┐
                      └──> Task 7 (test fixture)    │                              │
                                                    │                              │
Task 5 (frontend types) ──> Task 6 (frontend UI) ──┘                              │
                                                                                   │
                                                    Task 8 (integration tests) <───┘
```
