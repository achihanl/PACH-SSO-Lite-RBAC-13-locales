# Wave 1 Implementation Plan — Quick Wins + P0 Security Foundation

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Implement 6 issues from Epic #15 Wave 1: clean up dead code (#32), fix misleading UX (#31), add suspension events (#30), then build P0 security features (account soft-lock #16, IP blocking #17, UC client stub #18).

**Architecture:** All changes target the existing FastAPI backend (`main.py`, `orgdb.py`, `settingsdb.py`) and React frontend (`SecuritySection.tsx`). New tables via SQL migrations (`018`-`022`). Redis used for IP block cache. UC client follows the `authentik_client.py` pattern (interface + fire-and-forget).

**Tech Stack:** Python 3.12, FastAPI, SQLAlchemy Core, PostgreSQL, Redis, React 19, TypeScript, TanStack Query, @azblink/ui

---

## Task 1: Tech Debt — Drop Dead API Keys Code (#32)

**Files:**
- Remove: 3 methods from `src/backend/settingsdb.py:142-194`
- Remove: 3 routes from `src/backend/main.py:3078-3119`
- Remove: `src/frontend/src/components/features/settings/sections/ApiKeysSection.tsx` (159 lines)
- Remove: `src/frontend/src/lib/queries/api-keys.ts` (30 lines)
- Remove: API key types from `src/frontend/src/types/settings.ts:77-132`
- Modify: `src/frontend/src/components/features/settings/SettingsNav.tsx:29-53`
- Remove: `tests/test_settings.py:109-153` (TestApiKeysEndpoints class)
- Remove: table def from `src/backend/orgdb.py:262-271`
- Create: `migrations/018_drop_api_keys.sql`

**Step 1: Write the migration**

```sql
-- migrations/018_drop_api_keys.sql
-- Wave 1 (#32): Remove dead API keys table
-- No route validates API keys — full CRUD exists but nothing consumes them.

DROP TABLE IF EXISTS api_keys;
```

**Step 2: Remove backend API routes**

In `src/backend/main.py`, delete the three API key endpoints:
- `api_list_keys` (GET /api/keys) — lines 3078-3096
- `api_generate_key` (POST /api/keys) — lines 3099-3105
- `api_revoke_key` (DELETE /api/keys/{key_id}) — lines 3108-3119

**Step 3: Remove backend CRUD methods**

In `src/backend/settingsdb.py`:
- Delete `list_api_keys()` (lines 144-154)
- Delete `generate_api_key()` (lines 156-182)
- Delete `revoke_api_key()` (lines 184-194)
- Remove imports: `hashlib`, `secrets`, `uuid4`
- Update class docstring: "app_settings and api_keys" → "app_settings"
- Update module docstring lines 3-5: remove API keys reference

**Step 4: Remove SQLAlchemy table definition**

In `src/backend/orgdb.py`, delete the `api_keys` table definition (lines 262-271).

**Step 5: Remove frontend components and queries**

- Delete file: `src/frontend/src/components/features/settings/sections/ApiKeysSection.tsx`
- Delete file: `src/frontend/src/lib/queries/api-keys.ts`
- In `src/frontend/src/types/settings.ts`, delete `ApiKey`, `ApiKeyGenerated`, `ApiKeysResponse`, `ApiKeyGenerateResponse` (lines 77-132)
- In `src/frontend/src/lib/queries/keys.ts`, delete `apiKeys: ['api-keys'] as const` entry
- In `src/frontend/src/components/features/settings/SettingsNav.tsx`:
  - Remove `Key` import from lucide-react (line 15)
  - Remove `'api-keys'` from `SECTION_IDS` array (line 35)
  - Remove `{ id: 'api-keys', label: 'API Keys', icon: Key }` from `NAV_ITEMS` (line 49)
- In `src/frontend/src/components/features/settings/SettingsManagementPage.tsx`, remove the `<ApiKeysSection />` render and its import

**Step 6: Remove tests**

In `tests/test_settings.py`, delete class `TestApiKeysEndpoints` (lines 109-153).

**Step 7: Run tests**

Run: `just test-quick`
Expected: All existing tests pass (api key tests removed, no other tests depend on them).

**Step 8: Commit**

```bash
git add migrations/018_drop_api_keys.sql src/backend/settingsdb.py src/backend/main.py \
  src/backend/orgdb.py tests/test_settings.py \
  src/frontend/src/components/features/settings/sections/ApiKeysSection.tsx \
  src/frontend/src/lib/queries/api-keys.ts \
  src/frontend/src/types/settings.ts \
  src/frontend/src/lib/queries/keys.ts \
  src/frontend/src/components/features/settings/SettingsNav.tsx \
  src/frontend/src/components/features/settings/SettingsManagementPage.tsx
git commit -m "chore: remove dead API keys code path (#32)

Drop api_keys table, 3 API routes, frontend section, queries,
types, and 4 tests. No consumer ever validated keys."
```

---

## Task 2: Bug Fix — Settings UX Warning Labels (#31)

**Files:**
- Modify: `src/frontend/src/components/features/settings/sections/SecuritySection.tsx`

**Step 1: Write the failing test**

This is a frontend-only change (visual labels). No backend test needed. Verify visually after the change.

**Step 2: Add "not enforced" warning badges to SecuritySection**

In `src/frontend/src/components/features/settings/sections/SecuritySection.tsx`:

Add a `Badge` import from `@azblink/ui` and a helper warning component. Then add warning hints to each setting that is not yet enforced.

```tsx
/**
 * SecuritySection — security policy settings.
 * - 2 Select dropdowns (sessionTimeout, maxLoginAttempts)
 * - 3 ToggleRows (requireMfa, ipAllowlist, auditApiRequests)
 *
 * NOTE: All 5 settings are stored but NOT enforced by the backend.
 * Warning labels indicate this to prevent misleading UX.
 * Remove warnings as DS-1/DS-2/DS-5 wire enforcement logic.
 */

import { Badge, Select, ToggleRow } from '@azblink/ui';
import type { SecuritySettings } from '@/types/settings';
import { SettingsSection } from '../SettingsSection';
import { FormRow } from '../FormRow';
import { FormGroup } from '../FormGroup';

/** Inline warning for settings that are saved but not enforced by backend logic. */
function NotEnforcedHint() {
  return (
    <Badge variant="warning" className="ml-2 text-[10px]">
      Not enforced
    </Badge>
  );
}

const SESSION_TIMEOUT_OPTIONS = [
  { value: '15', label: '15 minutes' },
  { value: '30', label: '30 minutes' },
  { value: '60', label: '1 hour' },
  { value: '240', label: '4 hours' },
  { value: '480', label: '8 hours' },
];

const MAX_LOGIN_ATTEMPTS_OPTIONS = [
  { value: '0', label: 'Unlimited' },
  { value: '3', label: '3 attempts' },
  { value: '5', label: '5 attempts' },
  { value: '10', label: '10 attempts' },
];

interface SecuritySectionProps {
  settings: SecuritySettings;
  onFieldChange: (key: keyof SecuritySettings, value: number | boolean) => void;
}

export function SecuritySection({ settings, onFieldChange }: SecuritySectionProps) {
  return (
    <SettingsSection
      sectionId="security"
      title="Security"
      description="Session management, login policies, and access controls. Settings marked 'Not enforced' are saved but have no backend effect yet."
    >
      {/* Selects */}
      <FormRow>
        <FormGroup
          label={<>Session Timeout <NotEnforcedHint /></>}
          htmlFor="security-session-timeout"
        >
          <Select
            id="security-session-timeout"
            options={SESSION_TIMEOUT_OPTIONS}
            value={String(settings.sessionTimeoutMinutes)}
            onChange={(val) => onFieldChange('sessionTimeoutMinutes', Number(val))}
          />
        </FormGroup>
        <FormGroup
          label={<>Max Login Attempts <NotEnforcedHint /></>}
          htmlFor="security-max-attempts"
          hint="0 = unlimited"
        >
          <Select
            id="security-max-attempts"
            options={MAX_LOGIN_ATTEMPTS_OPTIONS}
            value={String(settings.maxLoginAttempts)}
            onChange={(val) => onFieldChange('maxLoginAttempts', Number(val))}
          />
        </FormGroup>
      </FormRow>

      {/* Toggles */}
      <div className="mt-6 space-y-0">
        <ToggleRow
          label={<>Require Multi-Factor Authentication <NotEnforcedHint /></>}
          description="Enforce MFA for all administrator accounts"
          checked={settings.requireMfa}
          onChange={(checked) => onFieldChange('requireMfa', checked)}
          name="security-require-mfa"
        />
        <ToggleRow
          label={<>IP Allowlist <NotEnforcedHint /></>}
          description="Restrict admin access to specific IP ranges"
          checked={settings.ipAllowlist}
          onChange={(checked) => onFieldChange('ipAllowlist', checked)}
          name="security-ip-allowlist"
        />
        <ToggleRow
          label={<>Audit API Requests <NotEnforcedHint /></>}
          description="Log all API requests to the audit trail"
          checked={settings.auditApiRequests}
          onChange={(checked) => onFieldChange('auditApiRequests', checked)}
          name="security-audit-api"
        />
      </div>
    </SettingsSection>
  );
}
```

**Step 3: Verify FormGroup accepts ReactNode labels**

Check `src/frontend/src/components/features/settings/FormGroup.tsx` — confirm the `label` prop type accepts `ReactNode` (not just `string`). If it only accepts `string`, update the prop type to `React.ReactNode`.

**Step 4: Verify ToggleRow accepts ReactNode labels**

Check `packages/azblink-ui/primitives/ToggleRow/ToggleRow.tsx` — confirm the `label` prop accepts `ReactNode`. If not, update.

**Step 5: Visual verification**

Run: `just ui-dev` (or rely on Docker HMR)
Navigate to Settings > Security. Confirm all 5 settings show amber "Not enforced" badges.

**Step 6: Commit**

```bash
git add src/frontend/src/components/features/settings/sections/SecuritySection.tsx
git commit -m "fix: add 'Not enforced' warning labels to security settings (#31)

All 5 security settings are saved but no backend logic reads them.
Labels prevent misleading UX. Remove as DS-1/DS-2/DS-5 wire enforcement."
```

---

## Task 3: Suspension Events Table (#30)

**Files:**
- Create: `migrations/019_suspension_events.sql`
- Modify: `src/backend/orgdb.py` — add table + `record_suspension_event()` method
- Modify: `src/backend/main.py` — call `record_suspension_event()` from suspend/unsuspend
- Create: `tests/test_suspension_events.py`

**Step 1: Write the migration**

```sql
-- migrations/019_suspension_events.sql
-- Wave 1 (#30): Dedicated suspension events tracking.
-- Supplements user_lifecycle_audit with suspension-specific detail.

CREATE TABLE IF NOT EXISTS suspension_events (
    id              SERIAL PRIMARY KEY,
    user_uid        VARCHAR(255) NOT NULL,
    action          VARCHAR(20) NOT NULL CHECK (action IN ('suspended', 'unsuspended')),
    performed_by    VARCHAR(255),
    reason          TEXT,
    duration_hours  INTEGER,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_suspension_events_user
    ON suspension_events(user_uid, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_suspension_events_time
    ON suspension_events(created_at DESC);
```

**Step 2: Write the failing test**

Create `tests/test_suspension_events.py`:

```python
"""Suspension events tracking tests (#30)."""

import pytest


class TestSuspensionEvents:
    """Suspension and unsuspension events are recorded to dedicated table."""

    def test_suspend_records_event(self, client, created_users, db_conn):
        """POST /api/users/{uid}/suspend records a suspension_events row."""
        from tests.conftest import create_test_user

        uid = "suspend_evt_test_1"
        create_test_user(client, uid, created_users)

        resp = client.post(
            f"/api/users/{uid}/suspend",
            json={"reason": "policy violation"},
        )
        assert resp.status_code == 200

        # Verify suspension_events row
        with db_conn.cursor() as cur:
            cur.execute(
                "SELECT action, reason, performed_by FROM suspension_events WHERE user_uid = %s",
                (uid,),
            )
            row = cur.fetchone()

        assert row is not None, "No suspension event recorded"
        assert row[0] == "suspended"
        assert row[1] == "policy violation"
        assert row[2] is not None  # performed_by should be set

    def test_unsuspend_records_event(self, client, created_users, db_conn):
        """POST /api/users/{uid}/unsuspend records an unsuspension event."""
        from tests.conftest import create_test_user

        uid = "suspend_evt_test_2"
        create_test_user(client, uid, created_users)

        # Suspend first
        client.post(f"/api/users/{uid}/suspend", json={"reason": "test"})

        # Unsuspend
        resp = client.post(
            f"/api/users/{uid}/unsuspend",
            json={"newPassword": "newpass123"},
        )
        assert resp.status_code == 200

        # Verify both events exist
        with db_conn.cursor() as cur:
            cur.execute(
                "SELECT action FROM suspension_events WHERE user_uid = %s ORDER BY created_at",
                (uid,),
            )
            rows = cur.fetchall()

        actions = [r[0] for r in rows]
        assert "suspended" in actions
        assert "unsuspended" in actions

    def test_suspension_events_appear_in_audit(self, client, created_users):
        """Suspension events should be queryable via audit endpoint."""
        from tests.conftest import create_test_user

        uid = "suspend_evt_test_3"
        create_test_user(client, uid, created_users)

        client.post(f"/api/users/{uid}/suspend", json={"reason": "audit test"})

        resp = client.get("/api/audit/events", params={"category": "user"})
        assert resp.status_code == 200
```

**Step 3: Run the test to verify it fails**

Run: `pytest tests/test_suspension_events.py -v`
Expected: FAIL — `suspension_events` table does not exist.

**Step 4: Add the SQLAlchemy table definition**

In `src/backend/orgdb.py`, after the `auth_failure_audit` table definition (around line 175), add:

```python
suspension_events = Table(
    "suspension_events",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("user_uid", String(255), nullable=False),
    Column("action", String(20), nullable=False),
    Column("performed_by", String(255), nullable=True),
    Column("reason", Text, nullable=True),
    Column("duration_hours", Integer, nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False),
)
```

**Step 5: Add `record_suspension_event()` method**

In `src/backend/orgdb.py`, add a new method to the `OrgDB` class (after `record_lifecycle_event`):

```python
def record_suspension_event(
    self,
    user_uid: str,
    action: str,
    performed_by: str = "unknown",
    reason: str | None = None,
    duration_hours: int | None = None,
) -> None:
    """Record a suspension or unsuspension event."""
    eng = self.connect()
    with eng.begin() as conn:
        conn.execute(
            insert(suspension_events).values(
                user_uid=user_uid,
                action=action,
                performed_by=performed_by,
                reason=reason,
                duration_hours=duration_hours,
                created_at=utcnow(),
            )
        )
```

**Step 6: Wire suspend/unsuspend endpoints**

In `src/backend/main.py`, update `api_user_suspend` (around line 1388-1404):

After the existing `record_lifecycle_event` call, add:

```python
    try:
        ORGDB.record_suspension_event(
            uid, "suspended", claims.get("sub", "unknown"), req.reason,
        )
    except Exception:
        pass
```

In `api_user_unsuspend` (around line 1407-1423), add similarly:

```python
    try:
        ORGDB.record_suspension_event(
            uid, "unsuspended", claims.get("sub", "unknown"),
        )
    except Exception:
        pass
```

**Step 7: Run the migration**

Run: `just psql < migrations/019_suspension_events.sql`

**Step 8: Run tests**

Run: `pytest tests/test_suspension_events.py -v`
Expected: PASS

Run: `just test-quick`
Expected: All tests pass.

**Step 9: Add cleanup to conftest**

In `tests/conftest.py`, in the `created_users` fixture teardown, add:

```python
cur.execute("DELETE FROM suspension_events WHERE user_uid = %s", (uid,))
```

**Step 10: Commit**

```bash
git add migrations/019_suspension_events.sql src/backend/orgdb.py src/backend/main.py \
  tests/test_suspension_events.py tests/conftest.py
git commit -m "feat: suspension events table (#30)

New suspension_events table with dedicated tracking for suspend/unsuspend
actions. Both endpoints now record events alongside existing lifecycle audit."
```

---

## Task 4: DS-1 — Account Soft-Lock (#16)

**Files:**
- Create: `migrations/020_account_locks.sql`
- Modify: `src/backend/orgdb.py` — table def + lock/unlock/check methods
- Modify: `src/backend/settingsdb.py` — add `lockoutDurationMinutes` default
- Modify: `src/backend/main.py` — lock check in `_claims_from_auth_header()` + unlock endpoint
- Create: `tests/test_account_lock.py`

**Step 1: Write the migration**

```sql
-- migrations/020_account_locks.sql
-- Wave 1 (#16): Account soft-lock after repeated auth failures.

CREATE TABLE IF NOT EXISTS account_locks (
    id              SERIAL PRIMARY KEY,
    username        VARCHAR(255) NOT NULL,
    locked_until    TIMESTAMPTZ NOT NULL,
    locked_by       VARCHAR(100) NOT NULL DEFAULT 'system',
    reason          VARCHAR(255),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_account_locks_username
    ON account_locks(username);

CREATE INDEX IF NOT EXISTS idx_account_locks_expiry
    ON account_locks(locked_until);
```

**Step 2: Write the failing test**

Create `tests/test_account_lock.py`:

```python
"""Account soft-lock tests (#16 DS-1).

Lock accounts after repeated auth failures. Unlock via admin endpoint.
"""

import pytest


class TestAccountLockAPI:
    """Admin lock/unlock endpoints."""

    def test_lock_status_returns_unlocked_by_default(self, client):
        """GET /api/users/{uid}/lock-status returns unlocked for normal user."""
        resp = client.get("/api/users/jsmith/lock-status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["locked"] is False

    def test_admin_can_unlock_locked_account(self, client, db_conn):
        """POST /api/users/{uid}/unlock clears an active lock."""
        # Insert a lock directly
        with db_conn.cursor() as cur:
            cur.execute(
                """INSERT INTO account_locks (username, locked_until, reason)
                   VALUES ('jsmith', NOW() + INTERVAL '1 hour', 'test lock')
                   ON CONFLICT (username) DO UPDATE SET locked_until = NOW() + INTERVAL '1 hour'""",
            )

        # Verify locked
        resp = client.get("/api/users/jsmith/lock-status")
        assert resp.json()["locked"] is True

        # Unlock
        resp = client.post("/api/users/jsmith/unlock")
        assert resp.status_code == 200
        assert resp.json()["ok"] is True

        # Verify unlocked
        resp = client.get("/api/users/jsmith/lock-status")
        assert resp.json()["locked"] is False

        # Cleanup
        with db_conn.cursor() as cur:
            cur.execute("DELETE FROM account_locks WHERE username = 'jsmith'")


class TestAccountLockEnforcement:
    """Verify locked accounts are rejected at auth level."""

    def test_count_failures_in_window(self, client, db_conn):
        """Auth failures are counted within a sliding window."""
        # Insert test failures
        with db_conn.cursor() as cur:
            for i in range(6):
                cur.execute(
                    """INSERT INTO auth_failure_audit
                       (username, failure_reason, client_ip, endpoint, timestamp)
                       VALUES ('locktest_user', 'invalid_token', '127.0.0.1',
                               '/api/settings', NOW() - INTERVAL '%s minutes')""",
                    (i,),
                )

        # Query via API to verify count endpoint works
        resp = client.get("/api/users/locktest_user/lock-status")
        assert resp.status_code == 200

        # Cleanup
        with db_conn.cursor() as cur:
            cur.execute("DELETE FROM auth_failure_audit WHERE username = 'locktest_user'")
            cur.execute("DELETE FROM account_locks WHERE username = 'locktest_user'")
```

**Step 3: Run test to verify it fails**

Run: `pytest tests/test_account_lock.py -v`
Expected: FAIL — `account_locks` table does not exist; endpoints don't exist.

**Step 4: Add SQLAlchemy table definition**

In `src/backend/orgdb.py`, after the `suspension_events` table (added in Task 3), add:

```python
account_locks = Table(
    "account_locks",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("username", String(255), nullable=False, unique=True),
    Column("locked_until", DateTime(timezone=True), nullable=False),
    Column("locked_by", String(100), nullable=False, server_default="system"),
    Column("reason", String(255), nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False),
)
```

**Step 5: Add lock/unlock/check methods to OrgDB**

In `src/backend/orgdb.py`, add these methods to the `OrgDB` class:

```python
def check_account_locked(self, username: str) -> tuple[bool, str | None]:
    """Check if an account is currently locked.

    Returns (is_locked, locked_until_iso). Expired locks are ignored.
    """
    eng = self.connect()
    stmt = text("""
        SELECT locked_until FROM account_locks
        WHERE username = :username AND locked_until > NOW()
    """)
    with eng.begin() as conn:
        row = conn.execute(stmt, {"username": username}).fetchone()
    if row:
        return True, row[0].isoformat()
    return False, None

def lock_account(
    self,
    username: str,
    duration_minutes: int,
    reason: str = "max_login_attempts_exceeded",
    locked_by: str = "system",
) -> None:
    """Lock an account for a given duration. Upserts on username."""
    eng = self.connect()
    stmt = text("""
        INSERT INTO account_locks (username, locked_until, locked_by, reason, created_at)
        VALUES (:username, NOW() + (:minutes || ' minutes')::INTERVAL, :locked_by, :reason, NOW())
        ON CONFLICT (username)
        DO UPDATE SET locked_until = NOW() + (:minutes || ' minutes')::INTERVAL,
                      locked_by = :locked_by, reason = :reason
    """)
    with eng.begin() as conn:
        conn.execute(stmt, {
            "username": username,
            "minutes": str(duration_minutes),
            "locked_by": locked_by,
            "reason": reason,
        })

def unlock_account(self, username: str) -> bool:
    """Remove an active lock. Returns True if a lock was removed."""
    eng = self.connect()
    stmt = text("DELETE FROM account_locks WHERE username = :username")
    with eng.begin() as conn:
        result = conn.execute(stmt, {"username": username})
    return result.rowcount > 0

def count_auth_failures(self, username: str, window_minutes: int = 15) -> int:
    """Count auth failures for a user within a sliding window."""
    eng = self.connect()
    stmt = text("""
        SELECT COUNT(*) FROM auth_failure_audit
        WHERE username = :username
          AND timestamp > NOW() - (:minutes || ' minutes')::INTERVAL
    """)
    with eng.begin() as conn:
        row = conn.execute(stmt, {"username": username, "minutes": str(window_minutes)}).fetchone()
    return row[0] if row else 0
```

**Step 6: Add `lockoutDurationMinutes` to settings defaults**

In `src/backend/settingsdb.py`, update the `security` section of `SETTINGS_DEFAULTS`:

```python
    "security": {
        "sessionTimeoutMinutes": 60,
        "maxLoginAttempts": 5,
        "lockoutDurationMinutes": 30,
        "requireMfa": False,
        "ipAllowlist": False,
        "auditApiRequests": True,
    },
```

**Step 7: Add lock check to `_claims_from_auth_header()` and add endpoints**

In `src/backend/main.py`:

1. After `verify_bearer_token(token)` succeeds (around line 191), add lock check:

```python
    try:
        claims = verify_bearer_token(token)
    except Exception as e:
        client_ip = request.client.host if request.client else "unknown"
        user_agent = request.headers.get("user-agent")
        # Extract username from token if possible (for lock tracking)
        username = None
        try:
            import jwt as pyjwt
            unverified = pyjwt.decode(token, options={"verify_signature": False})
            username = unverified.get("preferred_username") or unverified.get("sub")
        except Exception:
            pass
        try:
            ORGDB.record_auth_failure(
                client_ip=client_ip,
                endpoint=request.url.path,
                failure_reason="invalid_token",
                username=username,
                user_agent=user_agent,
            )
        except Exception:
            pass

        # DS-1: Check if failures exceed threshold — auto-lock
        if username:
            try:
                settings_db = get_settings_db()
                sec = settings_db.get_all_settings().get("security", {})
                max_attempts = sec.get("maxLoginAttempts", 5)
                lockout_minutes = sec.get("lockoutDurationMinutes", 30)
                if max_attempts > 0:
                    failure_count = ORGDB.count_auth_failures(username, window_minutes=15)
                    if failure_count >= max_attempts:
                        ORGDB.lock_account(username, lockout_minutes)
            except Exception:
                pass

        raise HTTPException(401, f"Invalid token: {e}")

    # DS-1: Check account lock AFTER successful token verification
    uid = claims.get("preferred_username") or claims.get("sub")
    if uid:
        is_locked, locked_until = ORGDB.check_account_locked(uid)
        if is_locked:
            raise HTTPException(
                403,
                detail=f"Account locked until {locked_until}. Contact your administrator.",
            )

    return claims
```

2. Add lock-status and unlock endpoints:

```python
@app.get("/api/users/{uid}/lock-status")
def api_user_lock_status(uid: str, claims: dict = Depends(require_admin)):
    """Check if a user account is locked (DS-1)."""
    is_locked, locked_until = ORGDB.check_account_locked(uid)
    failure_count = ORGDB.count_auth_failures(uid, window_minutes=15)
    settings_db = get_settings_db()
    sec = settings_db.get_all_settings().get("security", {})
    return {
        "locked": is_locked,
        "locked_until": locked_until,
        "recent_failures": failure_count,
        "max_attempts": sec.get("maxLoginAttempts", 5),
    }


@app.post("/api/users/{uid}/unlock")
def api_user_unlock(uid: str, claims: dict = Depends(require_admin)):
    """Manually unlock a locked user account (DS-1)."""
    removed = ORGDB.unlock_account(uid)
    actor = claims.get("sub", "unknown")
    logger.info("Account %s unlocked by %s (had_lock=%s)", uid, actor, removed)
    return {"ok": True, "unlocked": removed}
```

**Step 8: Run the migration**

Run: `just psql < migrations/020_account_locks.sql`

**Step 9: Run tests**

Run: `pytest tests/test_account_lock.py -v`
Expected: PASS

Run: `just test-quick`
Expected: All tests pass.

**Step 10: Commit**

```bash
git add migrations/020_account_locks.sql src/backend/orgdb.py src/backend/main.py \
  src/backend/settingsdb.py tests/test_account_lock.py
git commit -m "feat: account soft-lock on auth failures (#16 DS-1)

Lock accounts after maxLoginAttempts failures within 15-min window.
Auto-lock on Nth failure, admin unlock via POST /api/users/{uid}/unlock.
Lock check at _claims_from_auth_header() protects all 53 endpoints."
```

---

## Task 5: DS-2 — IP-Based Blocking (#17)

**Files:**
- Create: `migrations/021_blocked_ips.sql`
- Modify: `src/backend/orgdb.py` — table def + IP block methods
- Modify: `src/backend/main.py` — middleware + admin endpoints
- Modify: `src/backend/rate_limit.py` — add IP block check middleware class
- Create: `tests/test_ip_blocking.py`

**Step 1: Write the migration**

```sql
-- migrations/021_blocked_ips.sql
-- Wave 1 (#17): IP-based blocking for repeated auth violations.

CREATE TABLE IF NOT EXISTS blocked_ips (
    id              SERIAL PRIMARY KEY,
    ip_address      VARCHAR(45) NOT NULL,
    blocked_until   TIMESTAMPTZ NOT NULL,
    reason          VARCHAR(255),
    blocked_by      VARCHAR(100) NOT NULL DEFAULT 'system',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_blocked_ips_address
    ON blocked_ips(ip_address);

CREATE INDEX IF NOT EXISTS idx_blocked_ips_expiry
    ON blocked_ips(blocked_until);
```

**Step 2: Write the failing test**

Create `tests/test_ip_blocking.py`:

```python
"""IP-based blocking tests (#17 DS-2)."""

import pytest


class TestIPBlockingAPI:
    """Admin IP block management endpoints."""

    def test_list_blocked_ips_empty_by_default(self, client):
        """GET /api/security/blocked-ips returns empty list initially."""
        resp = client.get("/api/security/blocked-ips")
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["blocked_ips"] == []

    def test_admin_can_block_and_unblock_ip(self, client, db_conn):
        """POST block + DELETE unblock cycle works."""
        # Block
        resp = client.post(
            "/api/security/blocked-ips",
            json={"ip": "10.99.99.99", "reason": "test block", "duration_hours": 1},
        )
        assert resp.status_code == 200

        # Verify in list
        resp = client.get("/api/security/blocked-ips")
        ips = [b["ip_address"] for b in resp.json()["blocked_ips"]]
        assert "10.99.99.99" in ips

        # Unblock
        resp = client.delete("/api/security/blocked-ips/10.99.99.99")
        assert resp.status_code == 200

        # Verify removed
        resp = client.get("/api/security/blocked-ips")
        ips = [b["ip_address"] for b in resp.json()["blocked_ips"]]
        assert "10.99.99.99" not in ips

        # Cleanup
        with db_conn.cursor() as cur:
            cur.execute("DELETE FROM blocked_ips WHERE ip_address = '10.99.99.99'")

    def test_count_failures_by_ip(self, client, db_conn):
        """Auth failures from same IP are countable."""
        # Insert test failures from specific IP
        with db_conn.cursor() as cur:
            for _ in range(5):
                cur.execute(
                    """INSERT INTO auth_failure_audit
                       (username, failure_reason, client_ip, endpoint, timestamp)
                       VALUES (NULL, 'invalid_token', '10.88.88.88', '/api/test', NOW())""",
                )

        # The IP should have failures counted
        resp = client.get("/api/security/blocked-ips")
        assert resp.status_code == 200

        # Cleanup
        with db_conn.cursor() as cur:
            cur.execute("DELETE FROM auth_failure_audit WHERE client_ip = '10.88.88.88'")
            cur.execute("DELETE FROM blocked_ips WHERE ip_address = '10.88.88.88'")
```

**Step 3: Run test to verify it fails**

Run: `pytest tests/test_ip_blocking.py -v`
Expected: FAIL — endpoints and table don't exist.

**Step 4: Add SQLAlchemy table definition**

In `src/backend/orgdb.py`, add after `account_locks`:

```python
blocked_ips = Table(
    "blocked_ips",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("ip_address", String(45), nullable=False, unique=True),
    Column("blocked_until", DateTime(timezone=True), nullable=False),
    Column("reason", String(255), nullable=True),
    Column("blocked_by", String(100), nullable=False, server_default="system"),
    Column("created_at", DateTime(timezone=True), nullable=False),
)
```

**Step 5: Add IP block methods to OrgDB**

```python
def is_ip_blocked(self, ip: str) -> tuple[bool, str | None]:
    """Check if an IP is currently blocked. Returns (blocked, until_iso)."""
    eng = self.connect()
    stmt = text("""
        SELECT blocked_until FROM blocked_ips
        WHERE ip_address = :ip AND blocked_until > NOW()
    """)
    with eng.begin() as conn:
        row = conn.execute(stmt, {"ip": ip}).fetchone()
    if row:
        return True, row[0].isoformat()
    return False, None

def block_ip(
    self,
    ip: str,
    duration_hours: int = 24,
    reason: str = "repeated_auth_failures",
    blocked_by: str = "system",
) -> None:
    """Block an IP address. Upserts on ip_address."""
    eng = self.connect()
    stmt = text("""
        INSERT INTO blocked_ips (ip_address, blocked_until, reason, blocked_by, created_at)
        VALUES (:ip, NOW() + (:hours || ' hours')::INTERVAL, :reason, :blocked_by, NOW())
        ON CONFLICT (ip_address)
        DO UPDATE SET blocked_until = NOW() + (:hours || ' hours')::INTERVAL,
                      reason = :reason, blocked_by = :blocked_by
    """)
    with eng.begin() as conn:
        conn.execute(stmt, {
            "ip": ip, "hours": str(duration_hours),
            "reason": reason, "blocked_by": blocked_by,
        })

def unblock_ip(self, ip: str) -> bool:
    """Remove an IP block. Returns True if a block was removed."""
    eng = self.connect()
    stmt = text("DELETE FROM blocked_ips WHERE ip_address = :ip")
    with eng.begin() as conn:
        result = conn.execute(stmt, {"ip": ip})
    return result.rowcount > 0

def list_blocked_ips(self) -> list[dict]:
    """List currently blocked IPs."""
    eng = self.connect()
    stmt = text("""
        SELECT ip_address, blocked_until, reason, blocked_by, created_at
        FROM blocked_ips WHERE blocked_until > NOW()
        ORDER BY created_at DESC
    """)
    with eng.begin() as conn:
        rows = conn.execute(stmt).mappings().all()
    return [dict(r) for r in rows]

def count_failures_by_ip(self, ip: str, window_minutes: int = 15) -> int:
    """Count auth failures from an IP within a sliding window."""
    eng = self.connect()
    stmt = text("""
        SELECT COUNT(*) FROM auth_failure_audit
        WHERE client_ip = :ip
          AND timestamp > NOW() - (:minutes || ' minutes')::INTERVAL
    """)
    with eng.begin() as conn:
        row = conn.execute(stmt, {"ip": ip, "minutes": str(window_minutes)}).fetchone()
    return row[0] if row else 0
```

**Step 6: Add IP blocking middleware**

In `src/backend/rate_limit.py`, add the middleware class after the existing code:

```python
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse as StarletteJSONResponse


class IPBlockingMiddleware(BaseHTTPMiddleware):
    """Block requests from IPs in the blocked_ips table.

    Checks Redis cache first (fast path), falls back to PostgreSQL.
    Must be added BEFORE CORSMiddleware in the middleware stack.
    """

    def __init__(self, app, orgdb, redis_url: str = ""):
        super().__init__(app)
        self.orgdb = orgdb
        self._redis = None
        if redis_url:
            try:
                import redis as redis_lib
                self._redis = redis_lib.Redis.from_url(redis_url, decode_responses=True)
            except Exception:
                pass

    async def dispatch(self, request, call_next):
        client_ip = get_client_ip(request)

        # Fast path: check Redis cache
        if self._redis:
            try:
                cached = self._redis.get(f"blocked_ip:{client_ip}")
                if cached:
                    return StarletteJSONResponse(
                        {"error": "ip_blocked", "detail": "Your IP has been blocked."},
                        status_code=403,
                    )
            except Exception:
                pass

        # Slow path: check PostgreSQL
        try:
            is_blocked, until = self.orgdb.is_ip_blocked(client_ip)
            if is_blocked:
                # Cache in Redis for fast subsequent checks (60s TTL)
                if self._redis:
                    try:
                        self._redis.setex(f"blocked_ip:{client_ip}", 60, "1")
                    except Exception:
                        pass
                return StarletteJSONResponse(
                    {"error": "ip_blocked", "detail": f"Your IP has been blocked until {until}."},
                    status_code=403,
                )
        except Exception:
            pass  # Fail open — don't block if DB is down

        return await call_next(request)
```

**Step 7: Wire middleware and add admin endpoints**

In `src/backend/main.py`:

1. Add middleware BEFORE CORSMiddleware (line 82):

```python
# IP blocking middleware (DS-2) — must be before CORS
from rate_limit import IPBlockingMiddleware
app.add_middleware(IPBlockingMiddleware, orgdb=ORGDB, redis_url=REDIS_URL)
```

2. Add auto-block logic in `_claims_from_auth_header()` failure path (extend the DS-1 block):

After the lock_account logic, add IP auto-blocking:

```python
        # DS-2: Auto-block IP after threshold
        try:
            ip_failure_count = ORGDB.count_failures_by_ip(client_ip, window_minutes=15)
            if ip_failure_count >= 20:  # Higher threshold than per-user
                ORGDB.block_ip(client_ip, duration_hours=1, reason="repeated_auth_failures")
        except Exception:
            pass
```

3. Add admin endpoints for IP management:

```python
@app.get("/api/security/blocked-ips")
def api_list_blocked_ips(claims: dict = Depends(require_admin)):
    """List currently blocked IPs (DS-2)."""
    blocked = ORGDB.list_blocked_ips()
    return {
        "ok": True,
        "blocked_ips": [
            {
                "ip_address": b["ip_address"],
                "blocked_until": b["blocked_until"].isoformat() if b.get("blocked_until") else None,
                "reason": b.get("reason"),
                "blocked_by": b.get("blocked_by"),
            }
            for b in blocked
        ],
    }


class IPBlockRequest(BaseModel):
    ip: str = Field(..., description="IP address to block")
    reason: str = Field("manual_block", max_length=255)
    duration_hours: int = Field(24, ge=1, le=8760)


@app.post("/api/security/blocked-ips")
def api_block_ip(req: IPBlockRequest, claims: dict = Depends(require_admin)):
    """Manually block an IP address (DS-2)."""
    actor = claims.get("sub", "unknown")
    ORGDB.block_ip(req.ip, req.duration_hours, req.reason, blocked_by=actor)
    return {"ok": True}


@app.delete("/api/security/blocked-ips/{ip}")
def api_unblock_ip(ip: str, claims: dict = Depends(require_admin)):
    """Unblock an IP address (DS-2)."""
    removed = ORGDB.unblock_ip(ip)
    if not removed:
        raise HTTPException(404, f"IP '{ip}' not found in block list")
    return {"ok": True}
```

**Step 8: Run the migration**

Run: `just psql < migrations/021_blocked_ips.sql`

**Step 9: Run tests**

Run: `pytest tests/test_ip_blocking.py -v`
Expected: PASS

Run: `just test-quick`
Expected: All tests pass.

**Step 10: Commit**

```bash
git add migrations/021_blocked_ips.sql src/backend/orgdb.py src/backend/main.py \
  src/backend/rate_limit.py tests/test_ip_blocking.py
git commit -m "feat: IP-based blocking for auth violations (#17 DS-2)

IPBlockingMiddleware checks Redis cache + PostgreSQL blocked_ips table.
Auto-blocks IPs after 20 failures in 15 minutes. Admin endpoints for
manual block/unblock. Middleware runs before CORS for full coverage."
```

---

## Task 6: DS-3 — UC Server Client Stub (#18)

**Files:**
- Create: `src/backend/uc_client.py`
- Modify: `src/backend/config.py` — add `UC_SERVER_*` env vars
- Modify: `src/backend/main.py` — wire UC client into termination flow
- Create: `tests/test_uc_client.py`

**Step 1: Write the failing test**

Create `tests/test_uc_client.py`:

```python
"""UC Server client stub tests (#18 DS-3).

Stub interface for SIP/XMPP session termination.
Real implementation deferred until UC Server API spec is available.
"""

import pytest
import sys
from pathlib import Path

# Add backend to path for direct import
sys.path.insert(0, str(Path(__file__).parent.parent / "src" / "backend"))


class TestUCClientInterface:
    """UC client stub interface tests (no real UC server needed)."""

    def test_stub_client_is_importable(self):
        """uc_client module can be imported."""
        from uc_client import UCClient, UCClientError
        assert UCClient is not None
        assert UCClientError is not None

    def test_stub_client_not_configured_by_default(self):
        """Client without URL/token reports not configured."""
        from uc_client import UCClient
        client = UCClient(api_url="", api_token="")
        assert client.configured is False

    def test_stub_client_configured_with_values(self):
        """Client with URL/token reports configured."""
        from uc_client import UCClient
        client = UCClient(api_url="http://localhost:8080", api_token="test-token")
        assert client.configured is True

    def test_terminate_returns_stub_result(self):
        """terminate_user_sessions returns stub result (no real API call)."""
        from uc_client import UCClient
        client = UCClient(api_url="http://localhost:8080", api_token="test-token")
        result = client.terminate_user_sessions("testuser")
        assert "sip_sessions" in result
        assert "xmpp_sessions" in result
        # Stub returns 0 for both
        assert result["sip_sessions"] == 0
        assert result["xmpp_sessions"] == 0

    def test_check_session_status_returns_stub(self):
        """check_session_status returns stub data."""
        from uc_client import UCClient
        client = UCClient(api_url="http://localhost:8080", api_token="test-token")
        result = client.check_session_status("testuser")
        assert "active_sip" in result
        assert "active_xmpp" in result

    def test_unconfigured_client_raises_error(self):
        """Operations on unconfigured client raise UCClientError."""
        from uc_client import UCClient, UCClientError
        client = UCClient(api_url="", api_token="")
        with pytest.raises(UCClientError, match="not configured"):
            client.terminate_user_sessions("testuser")


class TestUCClientInTermination:
    """UC client integration in the termination endpoint."""

    def test_termination_returns_uc_sessions_field(self, client, created_users):
        """Termination response includes uc_sessions_terminated."""
        from tests.conftest import create_test_user

        uid = "uc_term_test_1"
        create_test_user(client, uid, created_users)

        resp = client.post(
            f"/api/users/{uid}/terminate",
            json={"reason": "uc client test"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "actions" in data
        # UC client not configured in dev — should be "not_configured" or 0
        assert "uc_sessions_terminated" in data["actions"] or data["actions"].get("uc_sessions") is not None
```

**Step 2: Run test to verify it fails**

Run: `pytest tests/test_uc_client.py::TestUCClientInterface -v`
Expected: FAIL — `uc_client` module does not exist.

**Step 3: Create the UC client stub**

Create `src/backend/uc_client.py`:

```python
"""UC Server client stub for SIP/XMPP session management.

- terminate_user_sessions(): Kill active SIP registrations + XMPP sessions
- check_session_status(): Query active session count for a user

This is a STUB — real implementation requires UC Server API specification
(Asterisk ARI for SIP, ejabberd/Prosody admin API for XMPP).

Pattern: Mirrors authentik_client.py (stateless, fire-and-forget, graceful degradation).
"""

from __future__ import annotations

import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


class UCClientError(Exception):
    """Raised when UC Server API call fails."""
    pass


class UCClient:
    """Client for UC Server session management.

    - Stateless: no session caching
    - Graceful degradation: caller should handle UCClientError
    - STUB: all methods return placeholder results until real API is available
    """

    def __init__(self, api_url: str, api_token: str):
        self.api_url = api_url.rstrip("/") if api_url else ""
        self.api_token = api_token

    @property
    def configured(self) -> bool:
        """Whether the client has valid connection info."""
        return bool(self.api_url and self.api_token)

    def terminate_user_sessions(self, uid: str) -> Dict[str, Any]:
        """Terminate all active SIP and XMPP sessions for a user.

        Returns dict with sip_sessions and xmpp_sessions counts.
        STUB: Returns 0 for both — real impl needs Asterisk ARI + XMPP admin API.
        """
        if not self.configured:
            raise UCClientError("UC Server client not configured")

        # TODO: Implement real SIP session termination via Asterisk ARI
        # e.g., DELETE /ari/channels?search=uid
        sip_terminated = 0

        # TODO: Implement real XMPP session termination via admin API
        # e.g., POST /api/kick_session {jid: uid@domain}
        xmpp_terminated = 0

        logger.info(
            "UC session termination for %s: sip=%d, xmpp=%d (STUB)",
            uid, sip_terminated, xmpp_terminated,
        )

        return {
            "sip_sessions": sip_terminated,
            "xmpp_sessions": xmpp_terminated,
        }

    def check_session_status(self, uid: str) -> Dict[str, Any]:
        """Check active session count for a user.

        STUB: Returns 0 for both — real impl needs UC Server query API.
        """
        if not self.configured:
            raise UCClientError("UC Server client not configured")

        return {
            "active_sip": 0,
            "active_xmpp": 0,
        }
```

**Step 4: Run unit tests**

Run: `pytest tests/test_uc_client.py::TestUCClientInterface -v`
Expected: PASS

**Step 5: Add config vars**

In `src/backend/config.py`, add after the Authentik section:

```python
# ----------------------------
# UC Server (SIP/XMPP session termination) — stub until API spec available
# ----------------------------
UC_SERVER_API_URL = os.getenv("UC_SERVER_API_URL", "")
UC_SERVER_API_TOKEN = os.getenv("UC_SERVER_API_TOKEN", "")
```

**Step 6: Wire into main.py**

In `src/backend/main.py`:

1. Add import near `authentik_client` import:

```python
from uc_client import UCClient, UCClientError
```

2. Add config import:

```python
from config import UC_SERVER_API_URL, UC_SERVER_API_TOKEN
```

3. Add initialization after `_authentik_client` init (around line 104):

```python
# UC client for session termination (optional — graceful if not configured)
_uc_client: UCClient | None = None
if UC_SERVER_API_URL and UC_SERVER_API_TOKEN:
    _uc_client = UCClient(api_url=UC_SERVER_API_URL, api_token=UC_SERVER_API_TOKEN)
```

4. Replace the TODO at line 1354 in `api_user_terminate`:

```python
    # 4. Terminate UC sessions (SIP/XMPP)
    uc_sessions_terminated = None
    if _uc_client:
        try:
            uc_result = _uc_client.terminate_user_sessions(uid)
            uc_sessions_terminated = uc_result["sip_sessions"] + uc_result["xmpp_sessions"]
            actions["uc_sip_sessions"] = uc_result["sip_sessions"]
            actions["uc_xmpp_sessions"] = uc_result["xmpp_sessions"]
        except UCClientError as e:
            logger.warning("UC session termination failed for %s: %s", uid, e)
            actions["uc_error"] = str(e)
    else:
        actions["uc_sessions"] = "not_configured"
```

**Step 7: Run integration test**

Run: `pytest tests/test_uc_client.py -v`
Expected: PASS

Run: `just test-quick`
Expected: All tests pass.

**Step 8: Commit**

```bash
git add src/backend/uc_client.py src/backend/config.py src/backend/main.py \
  tests/test_uc_client.py
git commit -m "feat: UC Server client stub for session termination (#18 DS-3)

Stub UCClient with terminate_user_sessions() and check_session_status().
Wired into termination flow (fire-and-forget pattern like authentik_client).
Real implementation deferred until Asterisk ARI + XMPP admin API available."
```

---

## Post-Wave Summary

After all 6 tasks, run the full test suite:

```bash
just test
```

Expected: All tests pass, including 4 new test files:
- `tests/test_suspension_events.py` (3 tests)
- `tests/test_account_lock.py` (3 tests)
- `tests/test_ip_blocking.py` (3 tests)
- `tests/test_uc_client.py` (7 tests)

### Migration Sequence

```bash
just psql < migrations/018_drop_api_keys.sql
just psql < migrations/019_suspension_events.sql
just psql < migrations/020_account_locks.sql
just psql < migrations/021_blocked_ips.sql
```

### Architecture Spec Updates

Per `docs/architecture/SOP.md`, update after Wave 1:
- §04 (Authentication): Add account soft-lock (DS-1) and IP blocking (DS-2)
- §07 (Security): Add rate limiting enhancement and auto-lock logic
- §03 (Data Architecture): Add 3 new tables (suspension_events, account_locks, blocked_ips), remove api_keys
- §08 (Integration Points): Add UC Server client stub

---

*Generated by Claude Code (Opus 4.6) — 2026-03-08*
