# Dashboard Phase 2 Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add ProvisioningChartCard and RecentQRCard to the dashboard left column with mock data.
**Architecture:** 5 new feature components in features/dashboard/, recharts dependency, modify DashboardMain.
**Tech Stack:** React 19, TypeScript, recharts, Tailwind CSS 4, @azblink/ui primitives
**Domains:** frontend

---

### Task 1: Add recharts dependency
**domain:** frontend
**depends_on:** []
**parallel_group:** 1

**Files:**
- Modify: `src/frontend/package.json`

**Steps:**
1. Run `npm install recharts` in `src/frontend/`
2. Verify `recharts` appears in `package.json` dependencies
3. Verify TypeScript can resolve: `import { AreaChart } from 'recharts'`

---

### Task 2: Create ChartLegend component
**domain:** frontend
**depends_on:** []
**parallel_group:** 1

**Files:**
- Create: `src/frontend/src/components/features/dashboard/ChartLegend.tsx`

**Component spec:**
- Props: `items: { color: string; label: string }[]`
- Layout: `flex gap-4` row of legend items
- Each item: 8px dot (rounded-full) + label text (text-xs text-muted)
- Export named `ChartLegend`

---

### Task 3: Create ProvisioningChartCard component
**domain:** frontend
**depends_on:** [1]
**parallel_group:** 2

**Files:**
- Create: `src/frontend/src/components/features/dashboard/ProvisioningChartCard.tsx`

**Component spec:**
- Uses `Card`, `CardHeader`, `CardTitle`, `CardAction` from `@azblink/ui`
- CardTitle: "Provisioning Activity"
- CardAction: Period toggle (3 buttons: 24h, 7d, 30d) with `useState<ChartPeriod>('7d')`
- Period buttons: inline `flex gap-1` with active state styling
- CardContent: ChartLegend + recharts AreaChart
- AreaChart config:
  - `ResponsiveContainer width="100%" height={220}`
  - Two `<Area>` series: `generated` (blue #3b82f6), `consumed` (green #22c55e)
  - `linearGradient` defs for each series (0.3 → 0 opacity)
  - `type="monotone"` for smooth curves
  - Custom `dot={{ r: 3, strokeWidth: 2 }}` on each series
  - `XAxis dataKey="day"` with muted text styling
  - `YAxis` hidden or minimal
  - `CartesianGrid` with subtle dashed lines
  - `Tooltip` with dark-themed custom content
- Mock data: 7 days (Mon-Sun), values from HTML reference:
  ```ts
  const MOCK_CHART_DATA: ChartDataPoint[] = [
    { day: 'Mon', generated: 12, consumed: 9 },
    { day: 'Tue', generated: 15, consumed: 11 },
    { day: 'Wed', generated: 10, consumed: 8 },
    { day: 'Thu', generated: 18, consumed: 14 },
    { day: 'Fri', generated: 14, consumed: 11 },
    { day: 'Sat', generated: 8, consumed: 6 },
    { day: 'Sun', generated: 15, consumed: 11 },
  ];
  ```

---

### Task 4: Create QRTableRow component
**domain:** frontend
**depends_on:** []
**parallel_group:** 1

**Files:**
- Create: `src/frontend/src/components/features/dashboard/QRTableRow.tsx`

**Component spec:**
- Props: `row: QRCodeRow` (from `types/dashboard.ts`)
- Layout: CSS Grid row matching `grid-template-columns: 2fr 1fr 1fr 1fr` with `gap-4 px-5 py-3.5 items-center`
- Column 1 (User): `flex items-center gap-2.5` — `Avatar` (initials + gradient) + name span
- Column 2 (Status): `StatusBadge` with `status={row.status}`
- Column 3 (Device): `row.device ?? '—'` with muted text
- Column 4 (Time): `font-mono text-xs` with muted text
- Border bottom between rows: `border-b border-[var(--color-border-subtle)]`

---

### Task 5: Create QRTable component
**domain:** frontend
**depends_on:** [4]
**parallel_group:** 2

**Files:**
- Create: `src/frontend/src/components/features/dashboard/QRTable.tsx`

**Component spec:**
- Props: `rows: QRCodeRow[]`
- Header row: same grid columns, `px-5 py-3 text-xs font-medium text-muted` — "User", "Status", "Device", "Time"
- Border bottom on header: `border-b border-[var(--color-border-subtle)]`
- Map rows to `QRTableRow`
- Last row: no border-bottom (use `last:border-0` or conditional)

---

### Task 6: Create RecentQRCard component
**domain:** frontend
**depends_on:** [5]
**parallel_group:** 3

**Files:**
- Create: `src/frontend/src/components/features/dashboard/RecentQRCard.tsx`

**Component spec:**
- Uses `Card`, `CardHeader`, `CardTitle`, `CardAction`, `CardContent` from `@azblink/ui`
- CardTitle: "Recent QR Codes"
- CardAction: "View all →" link (text-sm text-[var(--color-blue-500)] cursor-pointer)
- CardContent: `QRTable` with no padding (`className="!p-0"` or override)
- Mock data: 5 rows from HTML reference:
  ```ts
  const MOCK_QR_ROWS: QRCodeRow[] = [
    { id: '1', user: { name: 'Alice Chen', initials: 'AC', gradient: ['#3b82f6', '#8b5cf6'] }, status: 'consumed', device: 'iPhone 15 Pro', time: '10:23 AM', issuedAt: '2026-03-10T10:23:00Z' },
    { id: '2', user: { name: 'Bob Johnson', initials: 'BJ', gradient: ['#22c55e', '#06b6d4'] }, status: 'pending', device: null, time: '9:45 AM', issuedAt: '2026-03-10T09:45:00Z' },
    { id: '3', user: { name: 'Carol Williams', initials: 'CW', gradient: ['#f59e0b', '#ef4444'] }, status: 'consumed', device: 'Samsung S24', time: '9:12 AM', issuedAt: '2026-03-10T09:12:00Z' },
    { id: '4', user: { name: 'David Lee', initials: 'DL', gradient: ['#a855f7', '#ec4899'] }, status: 'expired', device: null, time: 'Yesterday', issuedAt: '2026-03-09T14:30:00Z' },
    { id: '5', user: { name: 'Emma Martinez', initials: 'EM', gradient: ['#06b6d4', '#3b82f6'] }, status: 'pending', device: null, time: 'Yesterday', issuedAt: '2026-03-09T11:15:00Z' },
  ];
  ```

---

### Task 7: Integrate into DashboardMain
**domain:** frontend
**depends_on:** [3, 6]
**parallel_group:** 4

**Files:**
- Modify: `src/frontend/src/components/features/dashboard/DashboardMain.tsx`

**Steps:**
1. Remove the two placeholder `<Card>` blocks
2. Import `ProvisioningChartCard` and `RecentQRCard`
3. Render them as direct children of the fragment:
   ```tsx
   <>
     <ProvisioningChartCard />
     <RecentQRCard />
   </>
   ```
4. Update file docstring

---

### Task 8: Verify build and tests
**domain:** frontend
**depends_on:** [7]
**parallel_group:** 5

**Steps:**
1. Run `just test-quick` — all tests must pass
2. Run TypeScript check: `cd src/frontend && npx tsc --noEmit`
3. Run Vite build: `cd src/frontend && npx vite build`
4. Verify zero TypeScript errors, zero console warnings
