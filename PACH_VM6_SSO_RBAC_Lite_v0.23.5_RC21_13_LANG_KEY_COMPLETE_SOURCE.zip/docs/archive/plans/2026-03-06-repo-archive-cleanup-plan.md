# Repo Archive & Cleanup Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Move all pre-March stale docs/plans/migration artifacts into `_ARCHIVE_/` with mirrored directory structure; clean up empty dirs and stale CLAUDE.md references.

**Architecture:** Single `_ARCHIVE_/` directory at repo root mirrors original paths. Git mv preserves history tracking. One commit bundles all moves + cleanup.

**Tech Stack:** git mv, bash, markdown editing

---

### Task 1: Create `_ARCHIVE_/` directory structure

**Files:**
- Create: `_ARCHIVE_/docs/archive/` (dir)
- Create: `_ARCHIVE_/docs/plans/sessions/` (dir)
- Create: `_ARCHIVE_/docs/reports/` (dir)
- Create: `_ARCHIVE_/docs/domains/` (dir)
- Create: `_ARCHIVE_/docs/api/` (dir)
- Create: `_ARCHIVE_/new-migration-ui/` (dir)
- Create: `_ARCHIVE_/.cursor/rules/` (dir)

**Step 1: Create all target directories**

```bash
mkdir -p _ARCHIVE_/docs/archive \
         _ARCHIVE_/docs/plans/sessions \
         _ARCHIVE_/docs/reports \
         _ARCHIVE_/docs/domains \
         _ARCHIVE_/docs/api \
         _ARCHIVE_/new-migration-ui \
         _ARCHIVE_/.cursor/rules
```

**Step 2: Verify structure**

```bash
find _ARCHIVE_ -type d | sort
```

Expected: All 9 directories listed.

---

### Task 2: Write `_ARCHIVE_/README.md` manifest

**Files:**
- Create: `_ARCHIVE_/README.md`

**Step 1: Create the README**

Write `_ARCHIVE_/README.md` with these exact contents:

```markdown
# _ARCHIVE_ — Scheduled for deletion 2026-03-21

**Created:** 2026-03-06
**Delete after:** 2026-03-21 (15-day retention)

## Why

Pre-March content superseded by single-LDAP architecture (PR #12), Authentik OIDC auth (PR #13), and Authentik dev stack (PR #14). These files are no longer referenced by active code or current plans.

## Contents

| Original Location | Description |
|-------------------|-------------|
| `docs/archive/` | 48 files — v1.0 specs, old implementation plans, Jan design docs |
| `docs/plans/2026-02-*` | 57 files — February plans (UED sync, groups, settings, etc.) |
| `docs/plans/sessions/2026-02-*` | 9 files — February session artifacts |
| `docs/reports/` | 2 files — UED/SSO analysis reports |
| `docs/domains/split-panel-migrations.md` | 1 file — old migration domain doc |
| `docs/api/` | 3 files — Jan 25 OpenAPI specs + frontend contracts |
| `new-migration-ui/` | 19 files — HTML screenshots + migration specs |
| `.cursor/rules/` | 2 files — old workflow .mdc files |

## Recovery

Any file can be recovered from git history:

    git log --all -- <original-path>
    git show <commit>:<original-path>

## Deletion

On or after 2026-03-21:

    rm -rf _ARCHIVE_/
    # Edit .dockerignore to remove _ARCHIVE_/ line
    git add -A && git commit -m "chore: remove _ARCHIVE_ after 15-day retention"
```

**Step 2: Verify file was written**

```bash
cat _ARCHIVE_/README.md | head -5
```

Expected: First 5 lines of the README visible.

---

### Task 3: Move `docs/archive/` (48 files)

**Files:**
- Move: all files from `docs/archive/` → `_ARCHIVE_/docs/archive/`

**Step 1: Move all files using git mv**

```bash
git mv docs/archive/* _ARCHIVE_/docs/archive/
```

**Step 2: Verify source is empty, target has files**

```bash
ls docs/archive/ 2>/dev/null | wc -l && ls _ARCHIVE_/docs/archive/ | wc -l
```

Expected: `0` then `48`.

---

### Task 4: Move February plan files (57 files)

**Files:**
- Move: `docs/plans/2026-02-*` → `_ARCHIVE_/docs/plans/`

**Step 1: Move February plan files**

```bash
git mv docs/plans/2026-02-* _ARCHIVE_/docs/plans/
```

**Step 2: Verify only March plans remain**

```bash
ls docs/plans/2026-0* 2>/dev/null | head -5
```

Expected: Only `2026-03-*` files listed.

---

### Task 5: Move February session files (9 files)

**Files:**
- Move: `docs/plans/sessions/2026-02-*` → `_ARCHIVE_/docs/plans/sessions/`

**Step 1: Move February session files**

```bash
git mv docs/plans/sessions/2026-02-* _ARCHIVE_/docs/plans/sessions/
```

**Step 2: Verify only March sessions remain**

```bash
ls docs/plans/sessions/
```

Expected: Only `2026-03-*` files listed.

---

### Task 6: Move `docs/reports/` (2 files)

**Files:**
- Move: `docs/reports/*` → `_ARCHIVE_/docs/reports/`

**Step 1: Move report files**

```bash
git mv docs/reports/* _ARCHIVE_/docs/reports/
```

**Step 2: Verify**

```bash
ls _ARCHIVE_/docs/reports/
```

Expected: `2026-02-14-ued-sync-xmpp-sip-qr-auth-analysis.md` and `2026-02-15-sso-requirements-gap-audit.md`.

---

### Task 7: Move `docs/domains/split-panel-migrations.md`

**Files:**
- Move: `docs/domains/split-panel-migrations.md` → `_ARCHIVE_/docs/domains/`

**Step 1: Move the file**

```bash
git mv docs/domains/split-panel-migrations.md _ARCHIVE_/docs/domains/
```

**Step 2: Verify source dir is empty**

```bash
ls docs/domains/
```

Expected: Empty directory.

---

### Task 8: Move `docs/api/` (3 files)

**Files:**
- Move: `docs/api/*` → `_ARCHIVE_/docs/api/`

**Step 1: Move API doc files**

```bash
git mv docs/api/* _ARCHIVE_/docs/api/
```

**Step 2: Verify**

```bash
ls _ARCHIVE_/docs/api/
```

Expected: `FRONTEND_API_CONTRACTS.md`, `openapi.json`, `openapi.yaml`.

---

### Task 9: Move `new-migration-ui/` (19 files)

**Files:**
- Move: `new-migration-ui/*` → `_ARCHIVE_/new-migration-ui/`

**Step 1: Move migration UI files**

```bash
git mv new-migration-ui/* _ARCHIVE_/new-migration-ui/
```

**Step 2: Verify**

```bash
ls _ARCHIVE_/new-migration-ui/ | wc -l
```

Expected: `19`.

---

### Task 10: Move `.cursor/rules/` (2 files)

**Files:**
- Move: `.cursor/rules/*` → `_ARCHIVE_/.cursor/rules/`

**Step 1: Move cursor rule files**

```bash
git mv .cursor/rules/* _ARCHIVE_/.cursor/rules/
```

**Step 2: Verify**

```bash
ls _ARCHIVE_/.cursor/rules/
```

Expected: `settings-migration-workflow.mdc` and `split-panel-migration-workflow.mdc`.

---

### Task 11: Remove empty source directories

**Files:**
- Remove: `docs/archive/`, `docs/reports/`, `docs/domains/`, `docs/api/`, `docs/knowledge/archive/`, `new-migration-ui/`, `.cursor/rules/`

**Step 1: Remove empty directories**

Note: `git mv` leaves empty dirs. Remove them. Also remove the empty `docs/knowledge/archive/` dir.

```bash
rmdir docs/archive docs/reports docs/domains docs/api docs/knowledge/archive new-migration-ui .cursor/rules .cursor 2>/dev/null
```

Some may fail if not empty (e.g., `.cursor/` if it has other contents) — that's fine.

**Step 2: Verify key empty dirs are gone**

```bash
ls -d docs/archive docs/reports docs/domains docs/api new-migration-ui 2>&1
```

Expected: All should show "No such file or directory".

---

### Task 12: Update `CLAUDE.md` — remove stale references

**Files:**
- Modify: `CLAUDE.md`

Three references to update:

**Step 1: Update design docs reference (line ~214-216)**

Find this block in the "Typography & Design Token Rules" section:

```markdown
**Design docs:**
- `docs/plans/2026-02-07-design-system-consolidation.md` - Token consolidation plan (active)
- `docs/api/FRONTEND_API_CONTRACTS.md` - API types and endpoints
- `docs/archive/2025-01-25-enterprise-ui-redesign.md` - UI/UX design system (reference)
```

Replace with:

```markdown
**Design docs:**
- `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md` - Phase 2 PRD (design system scope)
- `specs/v2.0/Directory_Portal_Specification_v4.1.md` - v2.0 specification
```

**Step 2: Update Implementation Status section (line ~355)**

Find:

```markdown
- `docs/archive/` - Historical milestones, audits, and completed plans
```

Replace with:

```markdown
- `_ARCHIVE_/` - Pre-March docs archived 2026-03-06 (deletion: 2026-03-21)
```

**Step 3: Update Technical Debt section reference (line ~362)**

Find:

```markdown
Tracked items that require prerequisite infrastructure or product decisions before implementation. Full details in `docs/plans/2026-02-12-user-detail-migration.md` § Deferred.
```

Replace with:

```markdown
Tracked items that require prerequisite infrastructure or product decisions before implementation. Full details in `_ARCHIVE_/docs/plans/2026-02-12-user-detail-migration.md` § Deferred (archived 2026-03-06).
```

**Step 4: Verify no remaining references to archived paths**

```bash
grep -n 'docs/archive\|new-migration-ui\|docs/reports\|\.cursor/rules\|docs/domains\|docs/api/' CLAUDE.md
```

Expected: No matches (or only the `_ARCHIVE_/` reference from step 3).

---

### Task 13: Add `_ARCHIVE_/` to `.dockerignore`

**Files:**
- Modify: `.dockerignore`

**Step 1: Append `_ARCHIVE_/` to .dockerignore**

Add at the end of the file:

```
# Archived docs (scheduled deletion 2026-03-21)
_ARCHIVE_/
```

**Step 2: Verify**

```bash
tail -3 .dockerignore
```

Expected: The two new lines visible.

---

### Task 14: Verify final state

**Step 1: Check git status summary**

```bash
git status --short | head -20
git status --short | wc -l
```

Expected: ~140+ renamed files (`R  old-path -> _ARCHIVE_/new-path`), a few modifications (CLAUDE.md, .dockerignore), a few new files (_ARCHIVE_/README.md), and some deletions (empty dirs).

**Step 2: Verify no source code was touched**

```bash
git diff --name-only -- src/ tests/ deploy/ migrations/ tools/
```

Expected: Empty — no live code changes.

**Step 3: Verify kept directories still intact**

```bash
ls docs/prd/ && ls specs/v2.0/ && ls docs/knowledge/libraries/ && ls docs/knowledge/patterns/ && ls docs/plans/2026-03-* | head -5
```

Expected: All kept directories show their files.

---

### Task 15: Commit

**Step 1: Stage all changes**

```bash
git add _ARCHIVE_/ docs/ new-migration-ui/ .cursor/ CLAUDE.md .dockerignore
```

Note: `git add new-migration-ui/` and `git add .cursor/` will stage the deletions of now-empty dirs.

**Step 2: Commit**

```bash
git commit -m "$(cat <<'EOF'
chore: archive pre-March stale docs and migration artifacts

Move 138 files to _ARCHIVE_/ with mirrored directory structure:
- docs/archive/ (v1.0 specs, old impl plans)
- docs/plans/2026-02-* (February plans, superseded by single-LDAP + Authentik)
- docs/reports/ (UED/SSO analysis)
- docs/api/ (stale OpenAPI specs)
- new-migration-ui/ (HTML screenshots + migration specs)
- .cursor/rules/ (old workflow files)

Scheduled deletion: 2026-03-21 (15-day retention).
Updated CLAUDE.md references. Added _ARCHIVE_/ to .dockerignore.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

**Step 3: Verify clean state**

```bash
git status
```

Expected: `nothing to commit, working tree clean`.

---

## Post-Implementation Reminder

On **2026-03-21** (or after), run the deletion:

```bash
rm -rf _ARCHIVE_/
# Edit .dockerignore: remove the _ARCHIVE_/ lines
# Edit CLAUDE.md: remove the _ARCHIVE_/ reference in Implementation Status
git add -A && git commit -m "chore: remove _ARCHIVE_ after 15-day retention"
```
