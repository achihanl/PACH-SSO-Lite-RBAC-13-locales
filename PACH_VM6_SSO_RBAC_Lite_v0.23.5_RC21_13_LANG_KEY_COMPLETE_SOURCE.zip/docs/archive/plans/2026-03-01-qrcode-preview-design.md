# QR Code Preview — Architecture Design

## Architecture Decisions

### 1. Preview link creation: On-demand (share button), NOT automatic
**Rationale:** Not every QR code needs a shareable link. Creating preview links on-demand:
- Avoids unnecessary DB rows for QR codes that are only scanned directly
- Lets the admin choose the preview link TTL at share time
- Keeps the existing `GET /api/users/{uid}/qrcode` endpoint unchanged

### 2. Separate preview token, NOT the provision token
**Rationale:** Defense in depth. The provision token grants device access. The preview token is read-only viewing. Different threat model, different token.

### 3. Preview link TTL is independent of QR token TTL
**Rationale:** Admin may want a 1-hour preview link for a QR code that's valid 24 hours. Preview link expiry controls "how long can someone view this QR" vs "how long can a device consume this QR."

### 4. URL structure: `/qr/preview/{token}` (frontend) + `/api/qr/preview/{token_hash}` (API)
**Rationale:** Clean, short URL for sharing. Frontend route prefix `/qr/` makes it easy to add to PUBLIC_ROUTES. Token is in the URL path, not a query param (easier to copy/share).

**Important:** The raw preview token appears in the URL. The API endpoint receives the hash (computed client-side). This means the backend never sees the raw token in request logs — only the hash.

*Correction:* Actually, for simplicity and to avoid requiring JS for initial load, the API will accept the raw token and hash it server-side. This matches the existing `POST /api/provision/validate` pattern. The URL will be: `/qr/preview/{token}` (both frontend route and API).

### 5. Store QR image + metadata at creation time
**Rationale:** When the preview link is created, snapshot the QR PNG and metadata into the preview table. This avoids:
- Re-generating the QR at view time (the provision token may have been consumed)
- Needing to look up user data from LDAP on public endpoint
- Data inconsistency if user is modified between share and view

### 6. No additional access restrictions beyond link knowledge + expiry
**Rationale:** The security model is "anyone with the link can view." This matches standard sharing patterns (Google Docs sharing, Slack invite links). Rate limiting prevents enumeration.

---

## Component Design

### Database: `qr_preview_links` table

```sql
CREATE TABLE IF NOT EXISTS qr_preview_links (
    id              SERIAL PRIMARY KEY,
    preview_token   VARCHAR(64) NOT NULL UNIQUE,   -- SHA-256 hash of the URL token
    uid             VARCHAR(128) NOT NULL,          -- user the QR belongs to
    display_name    VARCHAR(255),                   -- snapshot of user display name
    org_dn          TEXT,                           -- snapshot of org DN
    qr_png_base64   TEXT NOT NULL,                  -- snapshot of QR PNG
    qr_payload      JSONB NOT NULL,                 -- snapshot of signed payload (for metadata display)
    qr_expires_at   TIMESTAMPTZ NOT NULL,           -- when the QR token itself expires
    preview_expires_at TIMESTAMPTZ NOT NULL,         -- when this preview link expires
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      VARCHAR(255) NOT NULL,          -- admin who created the preview link
    access_count    INTEGER NOT NULL DEFAULT 0,     -- view counter
    last_accessed_at TIMESTAMPTZ                    -- last view time
);

CREATE INDEX idx_preview_links_expires ON qr_preview_links(preview_expires_at);
CREATE INDEX idx_preview_links_uid ON qr_preview_links(uid);
```

### Backend: New endpoints

**1. `POST /api/users/{uid}/qrcode/share` (auth required)**
- Creates a preview link for an existing QR code
- Accepts: `{ qrData: QRCodeResponse, previewTtlSec: number }`
  - Actually, cleaner: admin already has QR data from generation. Send it with the share request.
- Returns: `{ ok: true, previewUrl: string, previewExpiresAt: string }`
- Generates preview token, stores snapshot in DB

**2. `GET /api/qr/preview/{token}` (NO auth)**
- Public endpoint, rate-limited (`LIMIT_QR`)
- Hashes token, looks up in `qr_preview_links`
- Returns: `{ ok: true, uid, displayName, orgDn, pngBase64, qrExpiresAt, previewExpiresAt, services }`
- If expired/not found: `{ ok: false, error: "PREVIEW_EXPIRED" | "PREVIEW_NOT_FOUND" }`
- Increments access_count

### Frontend: New route + component

**Route: `src/frontend/src/routes/qr/preview.$token.tsx`**
- Public route (add `/qr/` prefix to PUBLIC_ROUTES in `__root.tsx`)
- Uses `createFileRoute('/qr/preview/$token')`
- Fetches from `GET /api/qr/preview/{token}` using plain `fetch()` (no auth)

**Component: `src/frontend/src/components/features/qr-preview/QRPreviewPage.tsx`**
- Full-screen centered layout (like login page pattern)
- AZBlink branding header
- QR code image (large, centered)
- Metadata: user display name, org, services
- Live countdown timer to preview link expiry
- "Download QR" button
- Expired state: friendly message with AZBlink branding
- Loading state: skeleton

**Integration with existing QR flow:**
- `src/frontend/src/components/features/qr-display.tsx` — modify "Copy Link" button to create a preview link
  - Currently copies the provision token to clipboard
  - Change to: POST to share endpoint, then copy the preview URL

---

## Data Flow

```
Admin clicks "Share" on QR display
  → POST /api/users/{uid}/qrcode/share { qrData, previewTtlSec }
  → Backend generates preview_token = secrets.token_urlsafe(32)
  → Backend stores hash + snapshot in qr_preview_links
  → Backend returns { previewUrl: "/qr/preview/{token}", previewExpiresAt }
  → Admin copies URL or sends via email

Recipient opens link /qr/preview/{token}
  → Frontend route matches, renders QRPreviewPage
  → Component fetches GET /api/qr/preview/{token}
  → Backend hashes token, looks up in DB
  → If valid: returns QR image + metadata (no credentials)
  → If expired: returns error, frontend shows expired message
  → Component renders QR image + metadata + countdown
```

---

## Error Handling

| Scenario | HTTP Status | Error Code | Frontend Display |
|----------|-------------|------------|------------------|
| Preview link not found | 404 | PREVIEW_NOT_FOUND | "This QR preview link is invalid or has been removed." |
| Preview link expired | 410 | PREVIEW_EXPIRED | "This QR preview link has expired. Please request a new link from your administrator." |
| Rate limited | 429 | rate_limit_exceeded | "Too many requests. Please try again later." |
| Server error | 500 | internal_error | "Something went wrong. Please try again." |

---

## Security Considerations

1. **Token entropy:** 32 bytes (256 bits) via `secrets.token_urlsafe(32)` — infeasible to brute-force
2. **No credentials in preview:** QR payload is stored, but the preview API strips credentials before returning
3. **Rate limiting:** Same LIMIT_QR (10/minute) on public endpoint
4. **Independent expiry:** Preview link can expire before the QR token, limiting exposure window
5. **Access logging:** access_count + last_accessed_at for audit
6. **No enumeration:** 404 for missing, 410 for expired (no timing difference)
7. **CORS:** Public endpoint inherits existing CORS config

---

## Test Strategy

1. **Backend unit tests:**
   - Create preview link → verify DB row
   - Fetch valid preview → verify response shape, no credentials
   - Fetch expired preview → verify 410
   - Fetch non-existent → verify 404
   - Access counter increment
   - Rate limiting on public endpoint

2. **Frontend:**
   - Preview page renders QR image + metadata
   - Expired state renders correctly
   - Loading/error states
   - Countdown timer ticks
   - Download button works

3. **Integration:**
   - Full flow: generate QR → create preview → fetch preview → verify data matches
