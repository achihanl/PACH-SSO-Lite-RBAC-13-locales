# Wave 2 Implementation Plan — DS-5, DS-4, DS-7

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Implement 3 issues from Epic #15 Wave 2: enforce security settings (#20 DS-5), add self-service /api/me endpoints (#19 DS-4), and create admin actions audit with decorator pattern (#22 DS-7).

**Architecture:**
- DS-5: Add in-memory settings cache with 60s TTL, public `/api/settings/security` endpoint, wire each setting to its enforcement point (maxLoginAttempts already wired in Wave 1, add ipAllowlist bypass and auditApiRequests middleware)
- DS-4: 5 new `/api/me` endpoints using existing `require_user()` dependency, LDAP self-lookup via `get_user()`, password change via LDAP rebind verification
- DS-7: New `admin_action_audit` table, `record_admin_action()` in orgdb, callable from endpoints (not decorator — endpoints have varying signatures, explicit call is simpler and more maintainable)

**Tech Stack:** Python 3.12, FastAPI, SQLAlchemy Core, PostgreSQL, Redis, React 19, TypeScript, TanStack Query, Zustand

---

## Task 1: DS-7 — Admin Actions Audit Table + Recording (#22)

**domain:** backend + database
**depends_on:** []
**parallel_group:** 1

**Files:**
- Create: `migrations/019_admin_action_audit.sql`
- Modify: `src/backend/orgdb.py` — table definition + `record_admin_action()` + extend `list_unified_audit()`
- Create: `tests/test_admin_audit.py`

**Step 1: Write the migration**

```sql
-- migrations/019_admin_action_audit.sql
-- Wave 2 (#22 DS-7): Admin actions audit table
CREATE TABLE IF NOT EXISTS admin_action_audit (
    id SERIAL PRIMARY KEY,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    detail JSONB,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_admin_action_audit_actor ON admin_action_audit(actor);
CREATE INDEX IF NOT EXISTS idx_admin_action_audit_timestamp ON admin_action_audit(timestamp);
```

**Step 2: Add SQLAlchemy table definition in orgdb.py** (after suspension_events)

**Step 3: Add `record_admin_action()` method to OrgDB class**

**Step 4: Extend `list_unified_audit()` UNION ALL** — add admin_action_audit as 5th table with 'admin' category, 'ADM-' prefix for reference_id

**Step 5: Wire admin action recording to key CRUD endpoints in main.py** — add `ORGDB.record_admin_action(...)` calls to:
- `api_org_create`, `api_org_rename`, `api_org_delete`
- `api_user_create`, `api_user_update`, `api_user_terminate`, `api_user_suspend`, `api_user_unsuspend`
- `api_group_create`, `api_group_delete`
- `api_patch_settings`, `api_reset_settings`

**Step 6: Write integration tests** — verify action recorded, appears in unified log, correct actor

**Step 7: Run tests** — `just test-quick`

**Step 8: Commit**

---

## Task 2: DS-5 — Security Settings Cache + Public Endpoint (#20)

**domain:** backend
**depends_on:** []
**parallel_group:** 1

**Files:**
- Modify: `src/backend/settingsdb.py` — add `get_security_settings()` with in-memory cache (60s TTL)
- Modify: `src/backend/main.py` — add `GET /api/settings/security` (unauthenticated), wire `auditApiRequests` toggle
- Modify: `src/backend/rate_limit.py` — add `ipAllowlist` bypass to IPBlockingMiddleware
- Create: `tests/test_settings_enforcement.py`

**Step 1: Add cached security settings reader to SettingsDB**

Add `get_security_settings()` method with module-level cache dict + TTL:
```python
_security_cache: dict[str, Any] = {"data": None, "expires": 0.0}

def get_security_settings(self) -> dict[str, Any]:
    """Get security settings with 60s in-memory cache."""
    now = time.time()
    if _security_cache["data"] and now < _security_cache["expires"]:
        return _security_cache["data"]
    all_settings = self.get_all_settings()
    sec = all_settings.get("security", {})
    _security_cache["data"] = sec
    _security_cache["expires"] = now + 60
    return sec
```

**Step 2: Add `GET /api/settings/security` endpoint** (no auth required — frontend needs it before login)

**Step 3: Wire `ipAllowlist` to IPBlockingMiddleware** — if `ipAllowlist` is a list, skip blocking for listed IPs

**Step 4: Add request audit logging middleware** — if `auditApiRequests` is enabled, log request method + path + actor

**Step 5: Update `_claims_from_auth_header()` to use cached settings** — replace direct `get_all_settings()` call with `get_security_settings()`

**Step 6: Write tests** — public settings endpoint, cache behavior, ipAllowlist bypass

**Step 7: Run tests** — `just test-quick`

**Step 8: Commit**

---

## Task 3: DS-5 Frontend — Session Timeout Enforcement (#20)

**domain:** frontend
**depends_on:** [2]
**parallel_group:** 2

**Files:**
- Modify: `src/frontend/src/stores/auth-store.ts` — fetch session timeout from public endpoint, enforce locally
- Modify: `src/frontend/src/lib/queries/settings.ts` — add public security settings query

**Step 1: Add public security settings query** in `settings.ts`

**Step 2: Add session timeout check to auth-store** — on `setAuth()`, cap `expiresAt` to `sessionTimeoutMinutes` from server

**Step 3: Verify frontend builds** — `just ui-build` (no test needed — backend integration tests cover the API)

**Step 4: Commit**

---

## Task 4: DS-4 — Self-Service /api/me Endpoints (#19)

**domain:** backend
**depends_on:** []
**parallel_group:** 1

**Files:**
- Modify: `src/backend/main.py` — 5 new endpoints: GET /api/me, PATCH /api/me, POST /api/me/password, GET /api/me/devices, GET /api/me/qrcodes
- Modify: `src/backend/ldap_client.py` — add `verify_user_password()` for current password check
- Create: `tests/test_self_service.py`

**Step 1: Add `verify_user_password()` to ldap_client.py** — attempt LDAP bind with user's DN + provided password

**Step 2: Add Pydantic models** for self-service requests (MeUpdateReq, MePasswordReq)

**Step 3: Add `GET /api/me`** — uses `require_user()`, extracts uid from claims, calls `get_user(uid)`, returns profile

**Step 4: Add `PATCH /api/me`** — allows only displayName, mail, mobile updates

**Step 5: Add `POST /api/me/password`** — verify current password via LDAP bind, then reset

**Step 6: Add `GET /api/me/devices`** — query provision_tokens for user's devices

**Step 7: Add `GET /api/me/qrcodes`** — query qr_issuance_audit for user's QR codes

**Step 8: Write integration tests** — each endpoint, restricted fields, password change

**Step 9: Run tests** — `just test-quick`

**Step 10: Commit**

---

## Task 5: Integration Testing + Final Verification

**domain:** test
**depends_on:** [1, 2, 3, 4]
**parallel_group:** 3

**Step 1: Run full test suite** — `just test`

**Step 2: Verify unified audit includes admin actions** — smoke test

**Step 3: Verify public settings endpoint works without auth** — smoke test

**Step 4: Commit any fixes**
