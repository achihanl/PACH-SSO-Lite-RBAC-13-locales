# Backend Dashboard API Endpoints — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add 6 dashboard API endpoints matching the frontend contract in `src/frontend/src/types/dashboard.ts`
**Architecture:** All endpoints in main.py, new OrgDB methods for chart/pending/stats aggregation, reuse existing list_unified_audit + list_qr_issuance + list_users
**Tech Stack:** FastAPI, SQLAlchemy (raw text + ORM), python-ldap3, Pydantic
**Domains:** backend

---

### Task 1: New OrgDB methods (chart_data, pending_provisions, dashboard_stats)
**domain:** backend
**depends_on:** []
**parallel_group:** 1

**Files:**
- Modify: `src/backend/orgdb.py` — add 3 new methods

**Step 1:** Add `get_dashboard_chart_data(period)` method
- GROUP BY time-series on qr_issuance_audit.issued_at
- Period: 24h=hourly buckets, 7d/30d=daily buckets
- Two series: generated count, consumed count per bucket
- Returns: `{"data": [{"day": "...", "generated": N, "consumed": N}], "period": "..."}`

**Step 2:** Add `get_pending_provisions()` method
- Query provision_tokens WHERE consumed_at IS NULL AND (expires_at IS NULL OR expires_at > NOW())
- Return: id, uid, expires_at, issued_at fields
- No LDAP enrichment at DB layer — that happens in main.py

**Step 3:** Add `get_dashboard_stats()` method
- total users count (delegated to caller via LDAP)
- pending_provisions count from provision_tokens
- success_rate from QR consumed/generated ratio over 30 days
- active_sessions = 0 (placeholder — needs Authentik API)
- Returns: `{"pending_provisions": N, "success_rate": N, "active_sessions": 0}`

---

### Task 2: Dashboard Stats endpoint — GET /api/dashboard/stats
**domain:** backend
**depends_on:** [1]
**parallel_group:** 2

**Files:**
- Modify: `src/backend/main.py` — add endpoint

**Step 1:** Add `api_dashboard_stats()` with `require_permission("dashboard_access")`
- Call ldap_client.list_users() for total_users count
- Call ORGDB.get_dashboard_stats() for pending/success_rate
- Return flat DashboardStatsApiResponse shape

---

### Task 3: Chart endpoint — GET /api/dashboard/chart
**domain:** backend
**depends_on:** [1]
**parallel_group:** 2

**Files:**
- Modify: `src/backend/main.py` — add endpoint

**Step 1:** Add `api_dashboard_chart(period)` with auth
- Validate period in {24h, 7d, 30d}
- Call ORGDB.get_dashboard_chart_data(period)
- Return `{"data": [...], "period": period}`

---

### Task 4: Recent QR codes — GET /api/qr-codes/recent
**domain:** backend
**depends_on:** [1]
**parallel_group:** 2

**Files:**
- Modify: `src/backend/main.py` — add endpoint

**Step 1:** Add `api_qr_codes_recent(limit=5)` with auth
- Call ORGDB.list_qr_issuance(limit=limit) (existing method)
- Enrich with LDAP user data via get_users_batch
- Transform to QRCodeRow format
- Return `{"rows": [...]}`

---

### Task 5: Dashboard Health — GET /api/dashboard/health
**domain:** backend
**depends_on:** []
**parallel_group:** 2

**Files:**
- Modify: `src/backend/main.py` — add endpoint

**Step 1:** Add `api_dashboard_health()` with `require_permission("dashboard_access")`
- Check: PostgreSQL, LDAP, Redis (existing pattern from api_health_deep)
- Add: Authentik check (HTTP HEAD to API URL)
- Add: XMPP Server check (optional — if configured)
- Add: SIP Server check (optional — if configured)
- Measure latency per service
- Return `{"services": [{"name": "...", "status": "...", "latency": "..."}]}`

---

### Task 6: Pending Provisions — GET /api/provisions/pending
**domain:** backend
**depends_on:** [1]
**parallel_group:** 2

**Files:**
- Modify: `src/backend/main.py` — add endpoint

**Step 1:** Add `api_provisions_pending()` with auth
- Call ORGDB.get_pending_provisions()
- Enrich with LDAP user data
- Calculate detail text (time until expiry)
- Return `{"items": [...]}`

---

### Task 7: Activity Feed — GET /api/activity/recent
**domain:** backend
**depends_on:** []
**parallel_group:** 2

**Files:**
- Modify: `src/backend/main.py` — add endpoint

**Step 1:** Add `api_activity_recent(limit=20)` with auth
- Call ORGDB.list_unified_audit(page=1, page_size=limit, time_range="7d")
- Transform to simplified ActivityEvent format
- Return `{"events": [...]}`

---

### Task 8: Integration tests
**domain:** test
**depends_on:** [2,3,4,5,6,7]
**parallel_group:** 3

**Files:**
- Create: `tests/test_dashboard_api.py`

**Step 1:** Write tests for all 6 endpoints:
- test_dashboard_stats_returns_expected_shape
- test_dashboard_stats_requires_auth
- test_dashboard_chart_returns_data
- test_dashboard_chart_validates_period
- test_qr_codes_recent_returns_rows
- test_dashboard_health_returns_services
- test_provisions_pending_returns_items
- test_activity_recent_returns_events
- test_activity_recent_limit_param
