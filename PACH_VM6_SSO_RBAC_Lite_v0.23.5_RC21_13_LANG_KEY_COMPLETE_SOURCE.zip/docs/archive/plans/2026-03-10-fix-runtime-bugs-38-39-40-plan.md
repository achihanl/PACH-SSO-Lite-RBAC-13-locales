# Fix Runtime Bugs #38 #39 #40 — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Fix three frontend runtime bugs — AuditRow crash, React 19 inert warning, My Profile 404 crash
**Architecture:** Surgical fixes to existing components; no new files, no new patterns
**Tech Stack:** React 19, TypeScript, TanStack Query v5, Zustand
**Domains:** frontend

---

### Task 1: Add admin-action to AuditEventType union (#38)
**domain:** frontend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [typescript]

**Files:**
- Modify: `src/frontend/src/types/audit.ts`

**Step 1:** Add `| 'admin-action'` to the `AuditEventType` union at line 61 (before `| 'login'`)
**Step 2:** Update the JSDoc comment on line 51 to say "10 supported event types" instead of "9"

---

### Task 2: Add admin-action entry to auditEventConfig (#38)
**domain:** frontend
**depends_on:** [1]
**parallel_group:** 1
**capabilities_needed:** [react, typescript]

**Files:**
- Modify: `src/frontend/src/components/features/audit-management/audit-event-config.ts`

**Step 1:** Import `ShieldAlert` from lucide-react (admin action icon — distinct from Settings used by config-change)
**Step 2:** Add `'admin-action'` entry to auditEventConfig after the `'config-change'` entry:
```ts
'admin-action': {
  icon: ShieldAlert,
  fg: 'text-orange-500',
  bg: 'bg-orange-500/10',
  label: 'Admin Action',
},
```

---

### Task 3: Add defensive null check in AuditRow and AuditDetailPanel (#38)
**domain:** frontend
**depends_on:** [2]
**parallel_group:** 1
**capabilities_needed:** [react, typescript]

**Files:**
- Modify: `src/frontend/src/components/features/audit-management/AuditRow.tsx`
- Modify: `src/frontend/src/components/features/audit-management/AuditDetailPanel.tsx`

**Step 1 (AuditRow.tsx):** Add fallback for unknown event types:
```tsx
const config = auditEventConfig[event.event_type] ?? {
  icon: HelpCircle,
  fg: 'text-zinc-400',
  bg: 'bg-zinc-500/10',
  label: event.event_type,
};
```
Import `HelpCircle` from lucide-react.

**Step 2 (AuditDetailPanel.tsx):** Same fallback pattern at line 20-21.

---

### Task 4: Fix inert boolean attribute (#39)
**domain:** frontend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [react]

**Files:**
- Modify: `src/frontend/src/components/features/settings/PendingChangesDrawer.tsx`

**Step 1:** On line 129, change:
```tsx
// @ts-expect-error -- inert is valid HTML but React types lag behind
inert={!isOpen ? '' : undefined}
```
to:
```tsx
inert={!isOpen || undefined}
```
Remove the `@ts-expect-error` comment since React 19 natively supports `inert` as a boolean prop.

---

### Task 5: Fix My Profile 404 crash with OIDC fallback (#40)
**domain:** frontend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [react, tanstack-query, typescript]

**Files:**
- Modify: `src/frontend/src/routes/my-profile.tsx`

**Step 1:** Replace `useSuspenseQuery` with `useQuery` for both queries:
```tsx
import { useQuery } from '@tanstack/react-query';
// Remove: import { useSuspenseQuery } from '@tanstack/react-query';
```

**Step 2:** Update ProfileContent to handle loading/error states:
```tsx
function ProfileContent({ uid }: { uid: string }) {
  const { data: userData, isLoading, isError } = useQuery(userQueryOptions(uid));
  const { data: groupsData } = useQuery(userGroupsQueryOptions(uid));
  const { user: authUser } = useAuthStore();

  if (isLoading) return <ProfileSkeleton />;

  if (isError || !userData) {
    // OIDC-only user — show available claims
    return <OIDCFallbackProfile user={authUser} />;
  }

  const user = userData.user;
  const groups = groupsData?.groups || [];
  // ... rest of existing render
}
```

**Step 3:** Remove the `<Suspense>` wrapper in `MyProfilePage` since we're no longer using suspense queries.

**Step 4:** Create `OIDCFallbackProfile` component inline (same file) that shows:
- User avatar from displayName/uid
- Available OIDC claims (email, displayName, uid)
- Info banner: "Your account is not provisioned in the directory. Contact an administrator."
- No groups section

---

### Task 6: Run tests and verify
**domain:** frontend
**depends_on:** [1, 2, 3, 4, 5]
**parallel_group:** 2
**capabilities_needed:** [testing]

**Step 1:** Run `just test-quick` to verify no regressions
**Step 2:** Verify TypeScript compilation: `cd src/frontend && npx tsc --noEmit`
