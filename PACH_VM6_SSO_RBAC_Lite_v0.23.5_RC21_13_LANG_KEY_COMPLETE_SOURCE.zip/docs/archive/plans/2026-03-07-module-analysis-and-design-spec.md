# AZBlink Directory — Module Analysis & Design Specification

**Date:** 2026-03-07
**Author:** Claude Code (Opus 4.6) + Agent Team
**Status:** Analysis Complete — Design Specification Draft
**Scope:** Directory Manager, Access Policy Manager, Provisioning Manager, Audit Manager

---

## Executive Summary

This document presents a comprehensive analysis of the AZBlink Directory platform across four management modules. Five parallel explorer agents analyzed the codebase (backend, frontend, tests, specs, PRDs, migrations) to produce this inventory.

**Overall Implementation: ~78% of core platform capabilities**

| Module | Coverage | P0 Gaps | P1 Gaps | P2 Gaps |
|--------|----------|---------|---------|---------|
| Directory Manager | 85% | 0 | 4 | 3 |
| Access Policy Manager | 78% | 2 | 3 | 4 |
| Provisioning Manager | 75% | 1 | 2 | 5 |
| Audit Manager | 72% | 0 | 3 | 5 |

The system is **production-ready for QR-based UC provisioning** (Phase 1 MVP) but requires P0 security features and Phase 2 SSO integration before enterprise deployment.

---

## Table of Contents

1. [Module 1: Directory Manager](#module-1-directory-manager)
2. [Module 2: Access Policy Manager](#module-2-access-policy-manager)
3. [Module 3: Provisioning Manager](#module-3-provisioning-manager)
4. [Module 4: Audit Manager](#module-4-audit-manager)
5. [Cross-Module Gap Summary](#cross-module-gap-summary)
6. [Suggested Design Specification](#suggested-design-specification)
7. [Implementation Roadmap](#implementation-roadmap)
8. [Appendix: File Inventory](#appendix-file-inventory)

---

## Module 1: Directory Manager

### 1.1 Current State — 85% Complete

The Directory Manager handles LDAP user/group/org CRUD, search, lifecycle management, and bulk operations. It operates on a single-LDAP architecture where identity and UC attributes coexist on the same DN.

### 1.2 Implemented Capabilities

#### User Management (Full)

| Capability | Backend | Frontend | Tests |
|------------|---------|----------|-------|
| Create user (with org, groups, profile-linked UC) | `main.py` `api_user_create` | OnboardingWizard (5-step) | `test_users.py` |
| Read user (with manager resolution, status derivation) | `main.py` `api_user_get` | UserDetailPanel | `test_users.py` |
| Update user (displayName, mail, mobile) | `main.py` `api_user_update` | EditUserModal | `test_users.py` |
| List users (search, filter, sort, paginate) | `main.py` `api_users` | UserList | `test_users.py` |
| Search users (full-text: uid, displayName, mail) | `main.py` `api_users_search` | SearchBar | `test_users.py` |
| Reset password (SSHA hash) | `main.py` `api_user_reset_password` | — | `test_users.py` |
| Move user between orgs | `main.py` `api_user_move_org` | — | — |
| CSV bulk import (auto-create orgs/groups) | `main.py` `api_user_import_csv` | — | `test_import_csv.py` (8 tests) |
| Batch user lookup (OR filter) | `main.py` `api_users_batch` | — | — |

**Account Status Derivation Logic:**
```
LDAP description="TERMINATED" → terminated
LDAP userPassword="{DISABLED}" → terminated
LDAP description="SUSPENDED"  → suspended
LDAP userPassword="{SUSPENDED}" → suspended
Valid SSHA password → active
No password → pending
```

#### Organization Management (Full)

| Capability | Backend | Frontend | Tests |
|------------|---------|----------|-------|
| Create org (with 3-way OU mirroring) | `main.py` `api_org_create` | CreateOrgModal | `test_org_groups.py` |
| Org tree (nested hierarchy) | `main.py` `api_orgs_tree` | OrgTree + TreeNode | `test_org_groups.py` |
| Org detail (stats, users, profile, SSO) | `main.py` `api_orgs_detail` | OrgDetailPanel (4 tabs) | `test_org_groups.py` |
| Rename org (cascades mirrors) | `main.py` `api_org_rename` | — | — |
| Delete org (validates empty, cascades) | `main.py` `api_org_delete` | — | — |

**Three-Way OU Mirroring:**
```
ou=Sales,ou=Dept,ou=org,dc=...      (Org tree — structure)
ou=Sales,ou=Dept,ou=people,dc=...   (User locations — mirror)
ou=Sales,ou=Dept,ou=groups,dc=...   (Group locations — mirror)
```

#### Group Management (Full)

| Capability | Backend | Frontend | Tests |
|------------|---------|----------|-------|
| Create group (LDAP groupOfNames + PG profile) | `main.py` `api_group_create` | — | `test_org_groups.py` |
| List groups (type filter, search, sort, paginate) | `main.py` `api_groups` | GroupList | `test_org_groups.py` |
| Group detail + members | `main.py` `api_group_detail` | GroupDetailPanel (3 tabs) | `test_org_groups.py` |
| Add/remove members | `main.py` `api_group_add/remove` | AddMembersModal | `test_org_groups.py` |
| Member roles (owner, admin, member) | `main.py` `api_group_member_role` | — | — |
| Group permissions (bitfield: 3 flags) | `main.py` `api_group_permissions` | PermissionsTab | — |
| Delete group (cascades PG profile) | `main.py` `api_group_delete` | DeleteGroupModal | — |

#### Account Lifecycle (Full)

| Capability | Backend | Tests |
|------------|---------|-------|
| Terminate (LDAP disable + token revoke + Authentik revoke + audit) | `main.py` `api_user_terminate` | `test_security.py` |
| Suspend (reversible LDAP lock) | `main.py` `api_user_suspend` | `test_suspend.py` |
| Unsuspend (new password + clear flags) | `main.py` `api_user_unsuspend` | `test_suspend.py` |
| Lifecycle event logging | `orgdb.py` `record_lifecycle_event` | `test_lifecycle_audit.py` |

### 1.3 Missing Capabilities

| ID | Gap | Priority | Spec Ref | Effort |
|----|-----|----------|----------|--------|
| D-1 | `/api/me` self-service endpoints (view/edit own profile) | P1 | v2.0 §2.7 | 1d |
| D-2 | `/api/users/export` (CSV/JSON export) | P1 | v2.0 §2.3 | 1d |
| D-3 | Custom LDAP schema (`azblink.schema` — azblinkUser, azblinkOrganization, azblinkGroup) | P1 | v2.0 §4.2 | 2d |
| D-4 | LDAP overlays (ppolicy, memberof, refint) | P1 | v2.0 §4.3 | 1d |
| D-5 | LDAP service accounts (directory-portal, authentik-sync, uc-server) | P2 | v2.0 §4.4 | 1d |
| D-6 | Nested groups / dynamic group rules | P2 | — | 3d |
| D-7 | Bulk update/move operations (beyond CSV import) | P2 | — | 2d |
| D-8 | Directory backup/LDIF export | P2 | — | 1d |
| D-9 | Performance: caching for list_users(), org tree (100k+ scale) | P3 | — | 2d |
| D-10 | Directory federation (external AD/LDAP sync) | P3 | — | 5d+ |

### 1.4 Architecture Notes

- `ldap_client.py` (~950 lines) handles all LDAP operations
- `main.py` (~3100 lines) contains all API routes — monolithic but well-structured
- `orgdb.py` (~400 lines) provides PostgreSQL enrichment (profiles, groups, audit)
- Frontend: 3 feature component directories (user-management, org-management, group-management)
- 15+ TanStack Query hooks for data fetching

---

## Module 2: Access Policy Manager

### 2.1 Current State — 78% Complete

Authentication uses Authentik OIDC exclusively (Plane B). UC services authenticate via direct LDAP bind (Plane A). The dual-plane design ensures UC works even when Authentik is unavailable.

### 2.2 Implemented Capabilities

#### Authentication (Full)

| Capability | Location | Status |
|------------|----------|--------|
| Authentik OIDC (sole auth path for web UI) | `oidc_verify.py`, `oidc.ts` | Complete |
| PKCE S256 flow (Web Crypto API + fallback) | `src/frontend/src/lib/oidc.ts` | Complete |
| Multi-issuer token validation | `config.py` `OIDC_ACCEPTED_ISSUERS` | Complete |
| Dev auth bypass (DEV_AUTH_TOKEN) | `oidc_verify.py` | Complete |
| Login + callback routes | `routes/login.tsx`, `routes/auth/callback.tsx` | Complete |
| Token persistence (localStorage) | `stores/auth-store.ts` | Complete |
| Session expired modal | `api-client.ts` (401 handler) | Complete |

#### Authorization (Partial)

| Capability | Location | Status |
|------------|----------|--------|
| Admin group check (`IT-Admins`) | `main.py` `require_admin()` | Complete — 65+ endpoints |
| RBAC infrastructure (`require_permission`) | `main.py` lines 226-249 | Partial — only group mgmt endpoints |
| Group-based permissions (3 bitfield flags) | `orgdb.py` `get_user_permissions()` | Complete |
| Valid permissions set | `user_management`, `qr_provisioning`, `audit_log_access`, `system_configuration` | Defined |

**RBAC coverage gap:** `require_permission` is only used on ~7 group management endpoints. All other admin endpoints use the coarser `require_admin()` check. The infrastructure is ready but not widely adopted.

#### Rate Limiting (Full)

| Endpoint Pattern | Limit | Backend |
|------------------|-------|---------|
| Bootstrap | 5/hour | `rate_limit.py` (Redis-backed slowapi) |
| User creation | 20/minute | `rate_limit.py` |
| QR operations | 10/minute | `rate_limit.py` |
| Default (all others) | 100/minute | `rate_limit.py` |

#### Token/Session Lifecycle (Full)

| Capability | Location | Status |
|------------|----------|--------|
| OAuth2 token revocation on termination | `authentik_client.py` | Complete |
| Authentik session revocation on termination | `authentik_client.py` | Complete |
| Auth failure recording | `orgdb.py` `record_auth_failure()` | Complete |
| Frontend auth state management | `auth-store.ts` (Zustand) | Complete |

#### Security Settings (Stub Only — Dead Code)

```python
# settingsdb.py — DEFINED but NOT enforced anywhere
"security": {
    "sessionTimeoutMinutes": 60,    # NOT enforced
    "maxLoginAttempts": 5,          # NOT enforced
    "requireMfa": False,            # NOT enforced
    "ipAllowlist": False,           # NOT enforced
    "auditApiRequests": True,       # NOT enforced
}
```

These settings can be viewed and modified in the Settings UI, but no backend logic reads or enforces them. This is misleading UX — users can change values that have no effect.

### 2.3 Missing Capabilities

| ID | Gap | Priority | Spec Ref | Effort |
|----|-----|----------|----------|--------|
| A-1 | **Account soft-lock on auth failures** (lock after 5 failures) | **P0** | v2.0 §1.3 | 1d |
| A-2 | **IP-based blocking** (repeated violations from same IP) | **P0** | v2.0 §1.3 | 1d |
| A-3 | Enforce security settings (make stubs functional) | P1 | — | 2d |
| A-4 | RBAC adoption (migrate endpoints from require_admin to require_permission) | P1 | — | 2d |
| A-5 | Refresh token rotation (currently: full re-auth on expiry) | P1 | — | 1d |
| A-6 | Conditional access rules / policy engine | P2 | — | 5d+ |
| A-7 | MFA enforcement (leverage Authentik MFA) | P2 | — | 2d |
| A-8 | Session policies (timeout, max concurrent) | P2 | — | 2d |
| A-9 | Idempotency key support | P2 | gap §3.3 | 1d |

### 2.4 Architecture Notes

- **Dual auth planes:** Plane A (LDAP bind for SIP/XMPP) is independent of Plane B (Authentik OIDC for web UI)
- **RBAC TODO in code:** `main.py:232` — "OIDC sub claim may not match LDAP uid — RBAC needs uid mapping"
- **API keys:** Table exists (`api_keys` with SHA256 hashes) but no route validates them — dead code path

---

## Module 3: Provisioning Manager

### 3.1 Current State — 75% Complete

The provisioning system centers on QR-based device provisioning with profile-linked UC service configuration. Direct LDAP writes (single-LDAP architecture) replace the former async sync pipeline.

### 3.2 Implemented Capabilities

#### QR Token System (Full)

| Capability | Backend | Frontend | Tests |
|------------|---------|----------|-------|
| QR code generation (HMAC-SHA256 signed, `azblink.provisioning.v2`) | `qr_signing.py`, `main.py` | QRGenerationModal | `test_qr_signing.py`, `test_qr_format.py` |
| One-time token creation + atomic consumption | `orgdb.py`, `main.py` | — | `test_provisioning.py` |
| Token expiration (configurable TTL, max 24h) | `main.py` | — | `test_provisioning.py` |
| Token revocation (per-user, bulk max 100) | `orgdb.py`, `main.py` | — | `test_provisioning.py` |
| Token expiry extension (with max cap) | `orgdb.py` | — | — |
| QR preview shareable links (public, access-counted) | `orgdb.py`, `main.py` | `/qr/preview.$token` | — |
| Device tracking (device_id, IP, platform, version) | `orgdb.py` | — | `test_provisioning.py` |

**QR Payload Schema (`azblink.provisioning.v2`):**
```json
{
  "schema": "azblink.provisioning.v2",
  "iat": 1709849600,
  "exp": 1709853200,
  "nonce": "random-uuid",
  "sig": "hmac-sha256-signature",
  "payload": {
    "uc": { "jid": "...", "sip_uri": "...", "ws_url": "..." },
    "sso": { "issuer": "...", "client_id": "..." }
  }
}
```

#### Profile-Linked UC Provisioning (Full)

| Capability | Backend | Tests |
|------------|---------|-------|
| UC resource allocation (uidNumber, extension counters) | `provisioning.py` | `test_profile_provisioning.py` |
| UC LDAP attribute builder (posixAccount + AsteriskPjsip*) | `ldap_client.py` `build_uc_attrs()` | `test_uc_attrs.py` |
| Atomic MODIFY_ADD to LDAP entry | `ldap_client.py` `add_uc_attrs_to_user()` | `test_uc_attrs.py` |
| SIP password generation (24-char random) | `provisioning.py` | `test_profile_provisioning.py` |
| Range exhaustion error handling | `orgdb.py` | `test_profile_provisioning.py` |

**Provisioning Flow:**
```
1. Admin creates user with profileId
2. If profile.xmpp_enabled OR profile.sip_enabled:
   a. Allocate uidNumber (atomic UPDATE...RETURNING)
   b. Allocate extension (if sip_enabled)
   c. Generate SIP password
   d. Build UC LDAP attrs
   e. MODIFY_ADD to inetOrgPerson entry
3. Return provisioning_info in API response
```

#### Profile/Template Management (Full)

| Capability | Backend | Frontend |
|------------|---------|----------|
| Profile CRUD (create, read, update, delete) | `orgdb.py` | OrgProfilePage |
| Org ↔ profile assignment tracking | `config_template_assignments` table | — |
| Field-level change history | `config_template_history` table | — |
| UC toggles (xmpp_enabled, sip_enabled) | `orgdb.py` | ProvisioningTab |
| UC endpoints (domain, ws_url, wss_url) | `orgdb.py` | ProvisioningTab |
| SSO config (Authentik OIDC settings) | `orgdb.py` | SSOConfigTab |
| QR settings (TTL, one-time-use, deep link scheme) | `orgdb.py` | — |

#### Device & Compliance (Partial)

| Capability | Backend | Frontend | Status |
|------------|---------|----------|--------|
| Provisioned device inventory | `orgdb.py` `list_provisioned_devices()` | DevicesTab | Complete |
| Compliance alerts (unconsumed >30d, excessive QR) | `main.py` `api_provisioning_compliance` | ComplianceTab | Complete |
| Device online/offline status | — | — | **Not Implemented** (D3) |
| Device revocation/wipe | — | — | **Not Implemented** (D4) |

### 3.3 Missing Capabilities

| ID | Gap | Priority | Spec Ref | Effort |
|----|-----|----------|----------|--------|
| P-1 | **UC Server client** (session termination for SIP/XMPP) | **P0** | Phase2 PRD §3.4.2 | 2d |
| P-2 | Phase 2 SSO block full integration in QR payload | P1 | Phase2 PRD | 2d |
| P-3 | Profile UC endpoint validation (verify services are reachable) | P1 | — | 1d |
| P-4 | SCIM 2.0 provisioning endpoint | P2 | — | 5d+ |
| P-5 | Joiners/Movers/Leavers automation | P2 | — | 5d+ |
| P-6 | Approval workflows for user creation | P2 | — | 3d |
| P-7 | Self-service enrollment (end-user registration) | P2 | — | 3d |
| P-8 | Scheduled/batch provisioning (cron jobs) | P2 | — | 2d |
| P-9 | Split QR mode (backward compat for legacy clients) | P2 | gap §5.3 | 1d |

### 3.4 Architecture Notes

- `provisioning.py` (~120 lines) is lean — just resource allocation
- UC LDAP attr building is in `ldap_client.py` (lines 30-99)
- Profile resolution: `orgdb.resolve_template_for_org(org_dn)` finds assigned template
- Atomic counter allocation prevents race conditions: `UPDATE...RETURNING` pattern

**TODOs found in code:**
- `main.py:1354` — UC Server session termination (placeholder)
- `main.py:1407` — Batch user counts for large org trees (>100 nodes)
- `main.py:1521` — "Provisioned at" field needs provision_tokens join
- `main.py:2406` — SMTP test endpoint (placeholder)

---

## Module 4: Audit Manager

### 4.1 Current State — 72% Complete

The audit system records events across four specialized tables and provides a unified viewer with rich filtering. The foundation is solid but lacks operational features (export, retention, SIEM).

### 4.2 Implemented Capabilities

#### Audit Tables

| Table | Purpose | Key Fields |
|-------|---------|------------|
| `qr_issuance_audit` | QR generation events | user_uid, issued_by, issued_at, consumed, consumed_at, client_ip |
| `user_lifecycle_audit` | User state changes | user_uid, action (created/suspended/unsuspended/password_reset), performed_by |
| `termination_events` | User termination details | user_uid, terminated_by, reason, actions_taken (JSON) |
| `auth_failure_audit` | Failed auth attempts | username, failure_reason, client_ip, user_agent, endpoint |
| `config_template_history` | Profile change tracking | template_id, actor, field, old_value, new_value |

#### Unified Audit Log (Full)

| Capability | Backend | Frontend |
|------------|---------|----------|
| Multi-source UNION ALL query (4 tables) | `orgdb.py` `list_unified_audit()` (lines 1418-1685) | AuditLogPage |
| Time range filtering (today/7d/30d/90d/all) | `orgdb.py` | AuditFilterBar |
| Category filtering (qr/user/auth/config) | `orgdb.py` | AuditFilterBar |
| Full-text search (actor, target, reference_id) | `orgdb.py` | SearchBar (Cmd+K shortcut) |
| Pagination (page + page_size) | `orgdb.py` | — |
| Reference ID system (QR-, TRM-, SES-, USR-, AUD-*) | `orgdb.py` | AuditRow |
| Split-panel detail view | — | AuditDetailPanel |
| URL-driven filters (bookmarkable) | — | URL search params |
| Device info for QR events (platform, device_id) | `orgdb.py` | AuditDetailPanel |

#### Per-Entity Audit (Full)

| Capability | Backend | Frontend |
|------------|---------|----------|
| QR issuance history per user (with device join) | `orgdb.py` `list_qr_issuance_for_user()` | UserDetailPanel |
| Device inventory per user | `orgdb.py` `list_devices_for_user()` | — |
| User stats aggregates (device count, QR count) | `orgdb.py` `get_user_stats()` | UserDetailPanel |
| Profile change history (field-level diffs) | `orgdb.py` `list_template_history()` | — |

#### Audit API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/audit/qr_issuance` | GET | QR generation events |
| `/api/audit/terminations` | GET | Termination events |
| `/api/audit/auth_failures` | GET | Auth failure events |
| `/api/audit/user_lifecycle` | GET | Lifecycle events |
| `/api/audit/events` | GET | Unified audit log (paginated, filtered) |
| `/api/config-templates/{id}/history` | GET | Profile change history |

### 4.3 Missing Capabilities

| ID | Gap | Priority | Spec Ref | Effort |
|----|-----|----------|----------|--------|
| AU-1 | Admin actions audit (who changed what user/org/group) | P1 | gap §2.8 | 2d |
| AU-2 | Suspension events table (dedicated tracking) | P1 | gap §3.1 | 0.5d |
| AU-3 | Audit export (CSV/JSON download) | P1 | — | 1d |
| AU-4 | Table partitioning (monthly partitions for audit tables) | P2 | gap §3.2 | 1d |
| AU-5 | Cleanup functions (`cleanup_expired_tokens`, `vacuum_audit_tables`) | P2 | gap §3.2 | 1d |
| AU-6 | Data retention policies (configurable TTL per table) | P2 | — | 1d |
| AU-7 | SIEM integration (syslog/webhook export) | P2 | — | 3d |
| AU-8 | Successful login tracking (currently only failures logged) | P2 | — | 1d |
| AU-9 | Audit dashboard (charts, KPIs, trend visualizations) | P3 | — | 3d |
| AU-10 | Audit trail integrity (hash chains for tamper detection) | P3 | — | 2d |

### 4.4 Architecture Notes

- Unified audit uses a complex UNION ALL with event type normalization
- Append-only design: audit tables use INSERT only, no UPDATE/DELETE
- 60s server-side cache on compliance alerts
- Authentik sessions are revoked but not logged back to audit tables
- No UC event pipeline exists (blocks D1/D2 deferred items)

---

## Cross-Module Gap Summary

### P0 — Critical (Must Have Before Production)

| ID | Gap | Module | Effort | Dependency |
|----|-----|--------|--------|------------|
| A-1 | Account soft-lock on auth failures | Access Policy | 1d | `auth_failure_audit` table exists |
| A-2 | IP-based blocking (repeated violations) | Access Policy | 1d | Rate limiter exists |
| P-1 | UC Server client (SIP/XMPP session termination) | Provisioning | 2d | Requires UC Server API spec |

### P1 — Core Functionality

| ID | Gap | Module | Effort | Dependency |
|----|-----|--------|--------|------------|
| D-1 | `/api/me` self-service endpoints | Directory | 1d | None |
| D-2 | User export (CSV/JSON) | Directory | 1d | None |
| D-3 | Custom LDAP schema (`azblink.schema`) | Directory | 2d | OpenLDAP config |
| D-4 | LDAP overlays (ppolicy, memberof, refint) | Directory | 1d | OpenLDAP config |
| A-3 | Enforce security settings (make stubs work) | Access Policy | 2d | A-1 |
| A-4 | RBAC migration (require_permission adoption) | Access Policy | 2d | None |
| A-5 | Refresh token rotation | Access Policy | 1d | None |
| P-2 | Phase 2 SSO block in QR payload | Provisioning | 2d | Authentik integration |
| P-3 | Profile UC endpoint validation | Provisioning | 1d | None |
| AU-1 | Admin actions audit table | Audit | 2d | None |
| AU-2 | Suspension events table | Audit | 0.5d | None |
| AU-3 | Audit export (CSV/JSON) | Audit | 1d | None |

### P2 — Operations & Polish

| ID | Gap | Module | Effort | Dependency |
|----|-----|--------|--------|------------|
| D-5 | LDAP service accounts | Directory | 1d | D-3 |
| D-6 | Nested groups | Directory | 3d | None |
| D-7 | Bulk update/move | Directory | 2d | None |
| A-6 | Conditional access / policy engine | Access Policy | 5d+ | — |
| A-7 | MFA enforcement | Access Policy | 2d | Authentik MFA config |
| A-8 | Session policies | Access Policy | 2d | None |
| A-9 | Idempotency keys | Access Policy | 1d | None |
| P-4 | SCIM 2.0 endpoint | Provisioning | 5d+ | — |
| P-5 | JML automation | Provisioning | 5d+ | — |
| P-6 | Approval workflows | Provisioning | 3d | — |
| P-7 | Self-service enrollment | Provisioning | 3d | — |
| P-8 | Scheduled provisioning | Provisioning | 2d | — |
| AU-4 | Table partitioning | Audit | 1d | None |
| AU-5 | Cleanup functions | Audit | 1d | None |
| AU-6 | Data retention policies | Audit | 1d | AU-5 |
| AU-7 | SIEM integration | Audit | 3d | — |
| AU-8 | Login success tracking | Audit | 1d | None |

---

## Suggested Design Specification

### DS-1: Account Soft-Lock (P0)

**Problem:** Auth failures are recorded but no lockout logic exists. An attacker can brute-force credentials indefinitely.

**Design:**
- After `maxLoginAttempts` (default: 5) failures within a sliding window (15 min), lock the account
- Lockout duration: configurable (default: 30 min), or until admin manual unlock
- Read `maxLoginAttempts` from `settingsdb.security` (currently a stub)
- Add `locked_until` column to `auth_failure_audit` (column exists but unused)
- Add `POST /api/users/{uid}/unlock` admin endpoint
- Add `GET /api/users/{uid}/lock-status` endpoint

**Backend changes:**
- `oidc_verify.py` — Check lock status before token validation
- `orgdb.py` — `check_account_locked(username)`, `lock_account(username, duration)`, `unlock_account(username)`
- `main.py` — New unlock endpoint
- `settingsdb.py` — Wire `maxLoginAttempts` and add `lockoutDurationMinutes`

**Frontend changes:**
- Lock status indicator on UserDetailPanel
- Unlock button for admins

**Files:** `oidc_verify.py`, `orgdb.py`, `main.py`, `settingsdb.py`

---

### DS-2: IP-Based Blocking (P0)

**Problem:** Rate limiting is per-endpoint, not per-IP for auth failures. A distributed attack from one IP hitting different endpoints bypasses limits.

**Design:**
- Track auth failures per IP in `auth_failure_audit` (already recorded)
- After N failures from same IP within window, block IP for configurable duration
- Use Redis sorted set for fast IP lookup: `blocked_ips:{ip}` with TTL
- Add IP to X-Forwarded-For resolution in rate limiter
- Add `ipAllowlist` enforcement from `settingsdb.security`

**Backend changes:**
- `rate_limit.py` — Add IP block check middleware
- `orgdb.py` — `count_failures_by_ip(ip, window_minutes)`, `block_ip(ip, duration)`
- `main.py` — Admin IP management endpoints: list blocked, unblock
- `settingsdb.py` — Wire `ipAllowlist`

**Files:** `rate_limit.py`, `orgdb.py`, `main.py`, `settingsdb.py`

---

### DS-3: UC Server Client (P0)

**Problem:** User termination revokes LDAP + Authentik but cannot kill active SIP registrations or XMPP sessions. Terminated users remain connected until their existing sessions expire.

**Design:**
- Define `uc_client.py` module with abstract interface
- Methods: `terminate_sip_sessions(uid)`, `terminate_xmpp_sessions(uid)`, `check_session_status(uid)`
- Implementation depends on UC Server API (Asterisk ARI for SIP, ejabberd/Prosody admin API for XMPP)
- Graceful degradation: if UC Server unreachable, log warning but don't block termination

**Backend changes:**
- New file: `src/backend/uc_client.py`
- `main.py:1354` — Replace TODO with `uc_client.terminate_sessions(uid)`
- `config.py` — Add `UC_SIP_API_URL`, `UC_XMPP_API_URL`, `UC_API_TOKEN`

**Files:** `uc_client.py` (new), `main.py`, `config.py`

---

### DS-4: Self-Service `/api/me` Endpoints (P1)

**Problem:** Users cannot view or edit their own profile. All changes require admin action.

**Design:**
- `GET /api/me` — Return authenticated user's profile (from OIDC claims + LDAP lookup)
- `PATCH /api/me` — Update allowed fields (displayName, mail, mobile)
- `POST /api/me/password` — Change own password (requires current password verification)
- `GET /api/me/devices` — List user's provisioned devices
- `GET /api/me/qrcodes` — List user's QR codes
- Auth: `require_user()` (any authenticated user, not just admin)

**Backend changes:**
- `main.py` — New `/api/me` route group
- `oidc_verify.py` — Add `require_user()` dependency (extracts uid from OIDC claims)

**Files:** `main.py`, `oidc_verify.py`

---

### DS-5: Enforce Security Settings (P1)

**Problem:** Settings UI allows changing security values that have no effect. Misleading UX.

**Design:**
- Wire each setting to its enforcement point:
  - `sessionTimeoutMinutes` → Frontend token expiry check in `auth-store.ts`
  - `maxLoginAttempts` → Backend lock logic (DS-1)
  - `requireMfa` → Authentik flow configuration (or block non-MFA tokens)
  - `ipAllowlist` → IP blocking middleware (DS-2)
  - `auditApiRequests` → Request logging middleware
- Add `GET /api/settings/security` public endpoint for frontend to fetch server-enforced values
- Cache settings in memory with 60s TTL (avoid DB hit per request)

**Backend changes:**
- `settingsdb.py` — Add `get_security_settings()` with caching
- `main.py` — New settings fetch endpoint; wire settings to middleware
- `oidc_verify.py` — Read `maxLoginAttempts` from settings
- `rate_limit.py` — Read `ipAllowlist` from settings

**Frontend changes:**
- `auth-store.ts` — Fetch `sessionTimeoutMinutes` from server, enforce locally

**Files:** `settingsdb.py`, `main.py`, `oidc_verify.py`, `rate_limit.py`, `auth-store.ts`

---

### DS-6: RBAC Migration (P1)

**Problem:** 65+ admin endpoints use coarse `require_admin()`. Fine-grained `require_permission()` exists but is only used on 7 group management routes.

**Design:**
- Map each endpoint to a permission:
  - User CRUD → `user_management`
  - Org CRUD → `org_management` (new permission, add to VALID_PERMISSIONS)
  - QR operations → `qr_provisioning`
  - Audit queries → `audit_log_access`
  - Settings/bootstrap → `system_configuration`
- Migrate endpoints incrementally (keep `require_admin()` as fallback)
- Resolve OIDC sub ↔ LDAP uid mapping (TODO at main.py:232)

**Backend changes:**
- `main.py` — Replace `require_admin` with `require_permission` per-endpoint
- `orgdb.py` — Add `org_management` to permission schema

**Files:** `main.py`, `orgdb.py`

---

### DS-7: Admin Actions Audit (P1)

**Problem:** User lifecycle and termination are audited, but admin CRUD operations on orgs, groups, and settings are not tracked.

**Design:**
- New table: `admin_action_audit` (actor, action, resource_type, resource_id, detail, timestamp)
- Actions: `create_user`, `update_user`, `delete_group`, `create_org`, `rename_org`, `update_settings`, etc.
- Decorator/middleware approach: `@audit_action("create_user")` on endpoints
- Include in unified audit log UNION ALL

**Backend changes:**
- `orgdb.py` — New table + `record_admin_action()` method
- `main.py` — Add audit decorator to admin endpoints
- `orgdb.py` — Extend `list_unified_audit()` UNION ALL

**Files:** `orgdb.py`, `main.py`

---

### DS-8: Audit Export (P1)

**Problem:** Audit data is only accessible via paginated REST API. No bulk export for compliance review.

**Design:**
- `GET /api/audit/export` — Stream audit events as CSV or JSON
- Query params: `format` (csv/json), `time_range`, `category`, `limit` (max 10000)
- Use streaming response (no full in-memory load)
- Add `Content-Disposition: attachment` header

**Backend changes:**
- `main.py` — New export endpoint with `StreamingResponse`
- `orgdb.py` — Generator-based query for streaming

**Files:** `main.py`, `orgdb.py`

---

## Implementation Roadmap

### Phase 1 — Security Hardening (P0, ~4 dev-days)

```
Week 1:
  Day 1: DS-1 Account soft-lock
  Day 2: DS-2 IP-based blocking
  Day 3-4: DS-3 UC Server client (depends on API spec availability)
```

### Phase 2 — Core Completeness (P1, ~12 dev-days)

```
Week 2:
  Day 1: DS-4 Self-service /api/me
  Day 2-3: DS-5 Enforce security settings
  Day 4-5: DS-6 RBAC migration

Week 3:
  Day 1: D-1/D-2 User export + LDAP schema
  Day 2-3: DS-7 Admin actions audit
  Day 4: DS-8 Audit export
  Day 5: AU-2 Suspension events + P-3 UC endpoint validation
```

### Phase 3 — Operations & Polish (P2, ~20+ dev-days)

```
Week 4-5:
  - Table partitioning + cleanup functions
  - Data retention policies
  - Nested groups
  - Bulk operations
  - MFA enforcement
  - Session policies

Week 6+:
  - SCIM 2.0 (5d+)
  - JML automation (5d+)
  - SIEM integration (3d)
  - Approval workflows (3d)
```

### Estimated Total Effort

| Phase | Effort | Coverage After |
|-------|--------|----------------|
| Phase 1 (P0) | 4 dev-days | ~82% |
| Phase 2 (P1) | 12 dev-days | ~92% |
| Phase 3 (P2) | 20+ dev-days | ~98% |
| **Total** | **~36 dev-days** | **~98%** |

---

## Appendix: File Inventory

### Backend Source Files

| File | Lines | Module(s) |
|------|-------|-----------|
| `src/backend/main.py` | ~3100 | All — API routes |
| `src/backend/ldap_client.py` | ~950 | Directory, Provisioning |
| `src/backend/orgdb.py` | ~2400 | All — PostgreSQL operations |
| `src/backend/provisioning.py` | ~120 | Provisioning |
| `src/backend/qr_signing.py` | ~150 | Provisioning |
| `src/backend/oidc_verify.py` | ~105 | Access Policy |
| `src/backend/authentik_client.py` | ~150 | Access Policy, Provisioning |
| `src/backend/rate_limit.py` | ~63 | Access Policy |
| `src/backend/config.py` | ~80 | All — configuration |
| `src/backend/settingsdb.py` | ~120 | Access Policy (stubs) |

### Frontend Source Files

| Directory | Purpose | Module |
|-----------|---------|--------|
| `src/frontend/src/routes/directory/` | User/org/group pages | Directory |
| `src/frontend/src/routes/provisioning/` | QR, token pages | Provisioning |
| `src/frontend/src/routes/audit-log/` | Audit viewer | Audit |
| `src/frontend/src/routes/configuration/` | Settings, profiles | Access Policy, Provisioning |
| `src/frontend/src/routes/login.tsx` | OIDC login | Access Policy |
| `src/frontend/src/routes/auth/callback.tsx` | OIDC callback | Access Policy |
| `src/frontend/src/components/features/user-management/` | User UI (12 components) | Directory |
| `src/frontend/src/components/features/org-management/` | Org UI (10 components) | Directory |
| `src/frontend/src/components/features/group-management/` | Group UI (9 components) | Directory |
| `src/frontend/src/components/features/audit-management/` | Audit UI (6 components) | Audit |
| `src/frontend/src/components/features/org-profiles/` | Profile UI | Provisioning |
| `src/frontend/src/components/features/provisioning-ops/` | Device/compliance UI | Provisioning |
| `src/frontend/src/components/features/qr-management/` | QR UI | Provisioning |
| `src/frontend/src/lib/oidc.ts` | PKCE flow | Access Policy |
| `src/frontend/src/lib/api-client.ts` | API client + auth | Access Policy |
| `src/frontend/src/stores/auth-store.ts` | Auth state | Access Policy |
| `src/frontend/src/lib/queries/` | TanStack Query hooks | All |

### Test Files

| File | Module | Tests |
|------|--------|-------|
| `tests/test_users.py` | Directory | 15+ |
| `tests/test_org_groups.py` | Directory | 10+ |
| `tests/test_import_csv.py` | Directory | 8 |
| `tests/test_suspend.py` | Directory | 4 |
| `tests/test_security.py` | Access Policy | 10+ |
| `tests/test_provisioning.py` | Provisioning | 10+ |
| `tests/test_qr_signing.py` | Provisioning | 5+ |
| `tests/test_qr_signing_unit.py` | Provisioning | 5+ |
| `tests/test_qr_format.py` | Provisioning | 5+ |
| `tests/test_qr_flow_integration.py` | Provisioning | 5+ |
| `tests/test_qr_management.py` | Provisioning | 5+ |
| `tests/test_profile_provisioning.py` | Provisioning | 5+ |
| `tests/test_uc_attrs.py` | Provisioning | 5+ |
| `tests/test_audit.py` | Audit | 6+ |
| `tests/test_lifecycle_audit.py` | Audit | 4 |

### Migration Files

| File | Purpose |
|------|---------|
| `migrations/004_phase1_uc_qr.sql` | QR schema, provision tokens |
| `migrations/008_config_templates.sql` | Profile templates |
| `migrations/011-015_ued_*.sql` | Profile-UED linking (historical) |
| `migrations/016_qr_preview_links.sql` | QR preview shareable links |
| `migrations/017_single_ldap.sql` | Single-LDAP migration |

### Spec/PRD Documents

| File | Purpose |
|------|---------|
| `docs/prd/PHASE1_UC_CORE_QR_PRD.md` | Phase 1 requirements |
| `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md` | Phase 2 requirements |
| `specs/v2.0/Directory_Portal_Specification_v4.1.md` | v2.0 specification |
| `specs/v2.0/V1_TO_V2_GAP_ANALYSIS.md` | Gap analysis |

---

*Generated by Claude Code (Opus 4.6) agent team — 5 parallel explorers, 2026-03-07*
