# Epic Planning Brief — Module Analysis & Design Implementation

**Date:** 2026-03-08
**Epic:** [#15](https://github.com/KeithMoc/azb-azblink-directory-and-identity-stack/issues/15)
**Source:** `docs/plans/2026-03-07-module-analysis-and-design-spec.md`
**Status:** Planning Complete — Ready for Implementation

---

## 1. Dependency Graph

```
Independent (no blockers):
  #18 DS-3: UC Server client
  #22 DS-7: Admin actions audit
  #23 DS-8: Audit export
  #24 User export CSV/JSON
  #28 SSO in QR payload
  #29 UC endpoint validation
  #30 Suspension events table
  #31 Bug: Settings UX warning labels
  #32 Tech debt: API keys cleanup

Sequential chains:
  #16 DS-1 (soft-lock) ──┐
                         ├──→ #20 DS-5 (enforce settings)
  #17 DS-2 (IP block)  ──┘

  #25 LDAP schema ────→ #26 LDAP overlays

Shared concern (coordinate, not blocking):
  #19 DS-4 (/api/me) ←── uid mapping ──→ #21 DS-6 (RBAC)
  Both need OIDC sub ↔ LDAP uid mapping fix at main.py:232
```

**Critical path:** #16 → #17 → #20 (security chain, ~5d total)

---

## 2. Risk & Complexity Matrix

| # | Issue | Complexity | Risk | Confidence | Revised Effort | Key Finding |
|---|-------|-----------|------|------------|---------------|-------------|
| #16 | DS-1: Soft-lock | Moderate | Low | 90% | 1-1.5d | Single integration point at `_claims_from_auth_header()` L193. Protects all 53 endpoints. No `locked_until` column — needs migration. |
| #17 | DS-2: IP blocking | Mod-High | Medium | 80% | 1.5-2d | Middleware before CORS at L82. Redis wired. `get_client_ip()` handles X-Forwarded-For. Performance-sensitive — runs every request. |
| #18 | DS-3: UC client | Low | **High** | **50%** | 2-3d | **Blocked on UC Server API spec.** Stub interface only until Asterisk ARI + XMPP admin API available. |
| #19 | DS-4: /api/me | Low-Mod | Medium | 75% | 1-1.5d | Needs `require_user()` dep. Shares uid-mapping TODO with DS-6. Password change needs LDAP bind verify. |
| #20 | DS-5: Enforce settings | Moderate | Low | 85% | 1.5-2d | Depends on DS-1+DS-2. Settings framework exists — just wiring. 60s cache TTL. |
| #21 | DS-6: RBAC migration | Moderate | **High** | **60%** | 2-3d | 46 endpoints → 5 permission groups. High blast radius. Needs uid mapping fix. Keep `require_admin()` fallback. |
| #22 | DS-7: Admin audit | Moderate | Low | 90% | 1.5-2d | Clean pattern from existing `record_*()` methods. ~20-line table + decorator. Extend UNION ALL (~50 lines). |
| #23 | DS-8: Audit export | Low | Low | 95% | 0.5-1d | StreamingResponse not imported yet but trivial. Generator wraps existing `list_unified_audit()`. |
| #24 | User export | Low | Low | 90% | 0.5-1d | Same streaming pattern as DS-8. CSV mirrors import format for round-trip. |
| #25 | LDAP schema | Moderate | Medium | 70% | 1.5-2d | OID allocation, schema LDIF, Docker volume mount. Backward compat testing needed. |
| #26 | LDAP overlays | Moderate | Medium | 65% | 1-1.5d | ppolicy/memberof/refint may interact with existing LDAP ops unexpectedly. |
| #27 | Refresh tokens | Moderate | Medium | 70% | 1.5-2d | Authentik `offline_access` scope. Secure storage (httpOnly cookie). 401 interceptor rewrite. |
| #28 | SSO in QR | Low | Low | 85% | 0.5-1d | Schema has `sso` block already. Populate from profile config. |
| #29 | UC validation | Low | Low | 90% | 0.5-1d | DNS SRV + WebSocket handshake. Pure utility. |
| #30 | Suspension events | Low | Low | 95% | 0.5d | Simple table + extend suspend/unsuspend endpoints. |
| #31 | Bug: Settings UX | Low | Low | 95% | 0.5d | Add "not enforced" warning labels. Interim before DS-5. |
| #32 | Tech debt: API keys | Low | Low | 95% | 0.5d | Delete dead code + migration to drop table. |

**Aggregate revised effort:** 15.5-22d (original estimate: 16d)

---

## 3. Execution Sequence

### Wave 1 — Quick Wins + P0 Foundation (3-4d)

| Day | Issues | Effort | Rationale |
|-----|--------|--------|-----------|
| 1 | #32 tech debt + #31 bug fix + #30 suspension events | 1.5d | Clean codebase, build momentum, low risk |
| 2 | #16 DS-1: Account soft-lock | 1d | P0 security, unblocks DS-5 |
| 3 | #17 DS-2: IP blocking | 1.5d | P0 security, unblocks DS-5 |
| 4 | #18 DS-3: UC client (stub) | 1d | Interface + config only; real impl when API available |

**Wave 1 delivers:** 3 P0 security features + 3 quality fixes

### Wave 2 — Core Security Completion (3-4d)

| Day | Issues | Effort | Rationale |
|-----|--------|--------|-----------|
| 5 | #20 DS-5: Enforce settings | 1.5d | Now unblocked by DS-1 + DS-2 |
| 6 | #19 DS-4: Self-service /api/me | 1.5d | Resolve uid mapping (reused by DS-6) |
| 7-8 | #21 DS-6: RBAC migration | 2d | Reuses uid mapping from DS-4 |

**Wave 2 delivers:** Settings enforcement, self-service, granular RBAC

### Wave 3 — Audit + Export (2-3d)

| Day | Issues | Effort | Rationale |
|-----|--------|--------|-----------|
| 9 | #22 DS-7: Admin actions audit | 1.5d | New table, decorator pattern, UNION ALL |
| 10 | #23 DS-8: Audit export + #24 User export | 1d | Same streaming pattern, batch together |

**Wave 3 delivers:** Full audit trail + export capabilities

### Wave 4 — Infrastructure + Integration (3-4d)

| Day | Issues | Effort | Rationale |
|-----|--------|--------|-----------|
| 11 | #25 LDAP schema | 1.5d | Foundation for overlays |
| 12 | #26 LDAP overlays | 1d | Requires schema from #25 |
| 13 | #27 Refresh tokens | 1.5d | Authentik config + frontend 401 rewrite |
| 14 | #28 SSO in QR + #29 UC validation | 1d | Quick P1 completions |

**Wave 4 delivers:** LDAP improvements, session continuity, QR completeness

---

## 4. Code-Level Integration Points

Key findings from codebase exploration:

### Authentication Chain (DS-1, DS-2, DS-5)

```
Request
  │
  ▼
[IPBlockingMiddleware]  ← NEW (DS-2): check Redis blocked_ips, 403 if blocked
  │
  ▼
[CORSMiddleware]        ← existing (main.py:82-92)
  │
  ▼
[slowapi rate limiter]  ← existing (rate_limit.py)
  │
  ▼
_claims_from_auth_header()  ← main.py:172-207
  │
  ├── verify_bearer_token()  ← oidc_verify.py:73-103
  │
  ├── [LOCK CHECK]  ← NEW (DS-1): check locked_until after token verify
  │
  ▼
require_user() → require_admin() OR require_permission()
  │
  ▼
Endpoint handler
```

- **Single lock check** at main.py:193 protects all 53 authenticated endpoints
- **IP blocking middleware** must be added BEFORE CORS in middleware stack
- **Settings cache** (60s TTL) avoids DB hit per request for `maxLoginAttempts`/`ipAllowlist`

### Audit Pattern (DS-7)

```python
# Existing pattern (orgdb.py record_*):
def record_admin_action(self, actor, action, resource_type, resource_id, detail=None):
    eng = self.connect()
    with eng.begin() as conn:
        conn.execute(insert(admin_action_audit).values(...))

# Decorator pattern for endpoints:
@audit_action("create_user")
async def api_user_create(...):
    ...
```

- 6 existing `record_*()` methods follow identical append-only INSERT pattern
- `list_unified_audit()` at orgdb.py:1417-1684 (268 lines) — 4 tables via UNION ALL
- Adding 5th table: ~50 lines new SELECT block + category filter update

### Streaming Export (DS-8, #24)

```python
# Not yet used — import needed:
from fastapi.responses import StreamingResponse

# Generator wraps existing list_unified_audit() query:
async def audit_export_generator(format, filters):
    for row in query_results:
        yield format_row(row, format)
```

---

## 5. Migrations Required

| Issue | Migration | Schema Change |
|-------|-----------|---------------|
| #16 DS-1 | `018_account_locks.sql` | New `account_locks` table (uid, locked_until, locked_by, reason) |
| #17 DS-2 | `019_blocked_ips.sql` | New `blocked_ips` table (ip, blocked_until, reason, blocked_by) |
| #22 DS-7 | `020_admin_action_audit.sql` | New `admin_action_audit` table (actor, action, resource_type, resource_id, detail, timestamp) |
| #30 | `021_suspension_events.sql` | New `suspension_events` table (user_uid, action, performed_by, reason, timestamps, duration) |
| #32 | `022_drop_api_keys.sql` | Drop `api_keys` table (if removing dead code path) |

---

## 6. Strategic Notes

### High-Risk Items

- **DS-3 (#18, 50% confidence):** Stub the interface and config vars. Ship it. Create follow-up issue for real Asterisk ARI + XMPP admin API implementation when UC Server API spec is available. Don't block Wave 1 on this.
- **DS-6 (#21, 60% confidence):** Migrate incrementally by permission group with `require_admin()` fallback preserved. Test each group in isolation. Plan for 1 extra day if uid mapping fix is more complex than expected.
- **LDAP overlays (#26, 65% confidence):** ppolicy and memberof overlays can interact with existing LDAP operations. Full test suite must pass after overlay enablement before merging.

### Quick Wins for Momentum

#32 + #31 + #30 are all <0.5d each and clean up the codebase. Start here in Wave 1 to build confidence and clear noise before tackling P0 security.

### Architecture Spec Updates

After implementation, update per `docs/architecture/SOP.md`:
- DS-1/DS-2 → §04 (Authentication) + §07 (Security)
- DS-4 → §04 (new `require_user()` auth level)
- DS-7 → §03 (Data Architecture: new table) + §07 (Security: audit)
- LDAP schema/overlays → §03 (Data Architecture: LDAP schema)

---

*Generated by Claude Code (Opus 4.6) — 2026-03-08*
