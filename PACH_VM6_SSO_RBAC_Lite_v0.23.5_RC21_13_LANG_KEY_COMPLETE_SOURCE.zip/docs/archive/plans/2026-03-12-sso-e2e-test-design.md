# SSO Device Provisioning E2E Test — Design

**Date:** 2026-03-12
**Status:** Implemented (PR #63 — automated tests, notebook migrated 2026-03-13)
**Scope:** Replace QR-centric e2e test with SSO device provisioning flow using real Authentik OIDC tokens

## Problem

The existing e2e test (`test_xmpp_e2e.py::test_full_platform_flow`) exercises the QR-based provisioning pipeline: admin generates QR code, token is extracted, consumed via `/api/provision/consume`. This flow is deprecated — the platform now uses SSO device provisioning (`POST /api/provision/device`) where authenticated users self-provision via short-lived tokens with libsodium sealed-box encryption.

The current `test_device_provisioning.py` validates the SSO provisioning endpoint but uses `DEV_AUTH_TOKEN` (hardcoded `preferred_username="dev-admin"`), so it never exercises real OIDC token validation, real per-user `preferred_username` mapping, or cross-layer credential verification against a live XMPP server.

## Design Decisions

- **Real Authentik OIDC tokens** — no DEV_AUTH_TOKEN bypass; tokens flow through full JWKS verification
- **M2M client_credentials grant** — test-only confidential OAuth2 provider in Authentik for programmatic token acquisition
- **App passwords per test user** — Authentik's M2M flow requires app tokens (not login passwords) for `grant_type=client_credentials`
- **Two test variants** — local-only (no external network) and full e2e (external XMPP server)
- **Dual LDAP provisioning** — local OpenLDAP (via API) for AD Directory + credential retrieval; external XMPP LDAP (via direct LDAP ADD) for XMPP auth
- **No new files** — helpers in `conftest.py`, tests in `test_xmpp_e2e.py`

## Infrastructure: Test OAuth2 Provider

### Seed Script Addition (`seed_authentik.py`)

New function `ensure_test_oauth2_provider()` creates a confidential provider alongside the existing public PKCE provider:

| Field | Value |
|-------|-------|
| `name` | `AZBlink Directory Test OIDC` |
| `client_type` | `confidential` |
| `client_id` | `azblink-directory-test` |
| `client_secret` | `dev-test-client-secret` |
| `redirect_uris` | `[]` (M2M, no redirects) |
| `access_token_validity` | `minutes=30` |
| `property_mappings` | Same scope PKs as main provider |
| `signing_key` | Same signing key as main provider |
| `sub_mode` | `hashed_user_id` |

Also creates a linked application `azblink-directory-test` (required for Authentik to issue tokens scoped to the provider).

Idempotent — patches existing config on re-seed. Calling order: after `ensure_oauth2_provider()`, before `ensure_application()`.

## Infrastructure: Conftest Fixtures

### Constants

```python
AUTHENTIK_API_URL = "http://localhost:9000"
AUTHENTIK_API_TOKEN = "dev-authentik-api-token"
AUTHENTIK_TEST_CLIENT_ID = "azblink-directory-test"
AUTHENTIK_TEST_CLIENT_SECRET = "dev-test-client-secret"
```

### `_authentik_api(method, path, data=None)`

Helper for authenticated requests to Authentik Admin API v3. Uses `requests` library with `AUTHENTIK_API_TOKEN` Bearer auth. Returns response JSON or raises.

### `authentik_user_factory` (fixture)

Factory fixture that creates Authentik users and auto-cleans on teardown.

**Creation flow:**
1. `POST /api/v3/core/users/` — create user (username, name, email, is_active=True)
2. `POST /api/v3/core/users/{pk}/set_password/` — set login password
3. `POST /api/v3/core/tokens/` — create app password token (intent=app_password)
4. `GET /api/v3/core/tokens/{identifier}/view_key/` — retrieve token key

**Returns:** `(user_pk, app_token_key)` — pk for cleanup, app_token_key for OIDC token acquisition.

**Teardown:** Deletes all created users and tokens (best-effort).

### `oidc_token_factory` (fixture)

Factory fixture that acquires real OIDC access tokens via Authentik's M2M grant.

**Token acquisition:**
```
POST /application/o/token/
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials
client_id=azblink-directory-test
client_secret=dev-test-client-secret
username=<username>
password=<app_token_key>
scope=openid profile email
```

**Returns:** Signed JWT string (Bearer token) with `preferred_username` = Authentik username.

## Test Variant 1: Local Dev Stack (`TestSsoProvisioningLocal`)

**Marker:** None (runs with standard `just test`)
**Dependencies:** Local Docker stack only (OpenLDAP, PostgreSQL, API, Authentik)

### Flow

```
 1. Create test user in Authentik (authentik_user_factory)
 2. Create same user in AD Directory via API with UC-enabled profile
 3. Acquire real OIDC token via M2M grant (oidc_token_factory)
 4. POST /api/provision/device with real Bearer token + Curve25519 pubkey
 5. Decrypt sealed box -> extract xmppPassword, sipPassword
 6. Verify credentials match LDAP (azbXmppBindPassword, AstAuthPassword)
 7. Verify audit trail: provision_tokens row (auth_method='sso_token')
 8. Re-provision same device -> 200 (upsert, not duplicate)
 9. Cleanup: revoke device, delete AD user, delete Authentik user
```

### What This Proves

- Real OIDC token → JWKS → JWT validation chain (no DEV_AUTH_TOKEN bypass)
- `preferred_username` from real Authentik token maps correctly to LDAP uid
- Sealed credentials match LDAP-stored passwords (cross-layer verification)
- Device upsert semantics work with real token-derived user identity

## Test Variant 2: External XMPP Server (`TestSsoProvisioningE2E`)

**Marker:** `@pytest.mark.external_network` (skipped without `EXTERNAL_LDAP_ADMIN_PASSWORD`)
**Dependencies:** External XMPP server at 192.168.122.89 + full local stack

### Flow (Two Users)

```
 1. Create user1 + user2 in Authentik (authentik_user_factory)
 2. Create user1 + user2 in external XMPP LDAP (posixAccount, direct LDAP ADD)
 3. Create user1 + user2 in AD Directory via API with UC-enabled profile
    - Same uid and same password across both LDAPs
 4. Acquire OIDC token for user1 via M2M grant
 5. Acquire OIDC token for user2 via M2M grant
 6. POST /api/provision/device with user1's Bearer token + keypair
 7. POST /api/provision/device with user2's Bearer token + keypair
 8. Decrypt sealed boxes -> extract xmppPassword for each user
 9. Connect user1 to external XMPP server with unsealed password
10. Connect user2 to external XMPP server with unsealed password
11. user1 -> user2: "Hello from user1"
12. user2 -> user1: "Reply from user2"
13. Verify provision_tokens rows (auth_method='sso_token', both users)
14. Cleanup: revoke devices, delete AD users, delete XMPP users, delete Authentik users
```

### Key Property

The external XMPP server authenticates via LDAP bind against `userPassword`. The sealed credential returns `azbXmppBindPassword`, which is synchronized with `userPassword` at creation time. The test implicitly validates password sync correctness by using the unsealed credential to authenticate to XMPP.

## File Changes

| File | Change |
|------|--------|
| `deploy/dev/authentik-seed/seed_authentik.py` | Add `ensure_test_oauth2_provider()`, `ensure_test_application()`, called from `main()` |
| `tests/conftest.py` | Add `_authentik_api()`, `authentik_user_factory`, `oidc_token_factory` fixtures |
| `tests/test_xmpp_e2e.py` | Replace `test_full_platform_flow` with `TestSsoProvisioningE2E`; add `TestSsoProvisioningLocal` |

### What Stays Unchanged in `test_xmpp_e2e.py`

- `XMPPTestClient` class — reused for XMPP auth + messaging
- `_ssha_hash()`, `_provision_xmpp_user()`, `_delete_xmpp_user()` — still needed for external LDAP
- `test_provision_users_to_external_ldap` — pure LDAP test, no auth flow change
- `test_xmpp_auth_and_messaging` — pure XMPP test, passwords known directly

### What Gets Replaced

- `test_full_platform_flow` → `TestSsoProvisioningE2E.test_full_sso_platform_flow`
  - QR generation (`GET /api/users/{uid}/qrcode`) removed
  - Token consumption (`POST /api/provision/consume`) removed
  - Replaced with SSO device provisioning (`POST /api/provision/device`)
  - Real OIDC tokens instead of DEV_AUTH_TOKEN

### What Gets Added

- `TestSsoProvisioningLocal` — local-only variant, no external network marker

### What `_cleanup_ad_user()` Gains

- Additional cleanup: delete Authentik user (accepts optional `authentik_pk` param)

## Security Notes

- Test provider `client_secret` is hardcoded (`dev-test-client-secret`) — dev-only, never deployed to production
- App password tokens are created per-test-run and deleted in teardown
- The test confidential provider has no redirect URIs — cannot be used for browser-based flows
- Access tokens are short-lived (30 minutes) — expire quickly even if leaked from test output

## Implementation Notes

### Design Change: Public Provider Reuse

The original design called for a separate confidential test OAuth2 provider (`azblink-directory-test`). Implementation reused the existing public `azblink-directory` provider with `client_credentials` grant instead — simpler, no seed script changes needed.

### Notebook Migration (2026-03-13)

`tools/e2e_xmpp_notebook.py` (Marimo) was migrated from the QR-based flow to match the SSO device provisioning architecture:

- Authentik user creation + app passwords (inlined from conftest helpers)
- M2M `client_credentials` OIDC token acquisition
- `POST /api/provision/device` with Curve25519 sealed-box
- XMPP auth with **unsealed** credentials (proving full credential chain)
- SSO-specific audit trail verification (`auth_method='sso_token'`)
- Cleanup includes Authentik user deletion
