# Authentik UI Branding — Architecture Design

## Approach: Seed-Script Branding via Admin API + Mounted Assets

### Architecture Decisions
1. **Extend existing seed script** — add `ensure_branding()` function matching idempotent pattern
2. **Volume-mount assets** into `authentik-server` container at `/web/dist/assets/azblink/`
3. **Custom CSS via Brand API** — inline CSS in `branding_custom_css` field (not file mount)
4. **Dark theme default** — set via `attributes.settings.theme.base = "dark"`

### Components
1. **Brand Assets** (`deploy/dev/authentik-seed/assets/`) — logo.svg, favicon.svg, custom.css
2. **Seed Script** — `ensure_branding()` in seed_authentik.py
3. **Docker Volume** — mount assets into authentik-server container

### Data Flow
```
authentik-server starts → serves /web/dist/ at /static/dist/
authentik-seed starts → wait_for_authentik()
ensure_branding() → GET brands/?default=true → PATCH brand/{uuid}/
  - title: "AZBlink Directory"
  - logo: /static/dist/assets/azblink/logo.svg
  - favicon: /static/dist/assets/azblink/favicon.svg
  - custom_css: contents of custom.css
  - attributes: dark theme
(continue with OIDC setup)
```

### Files to Create
- `deploy/dev/authentik-seed/assets/logo.svg` — AZBlink wordmark logo
- `deploy/dev/authentik-seed/assets/favicon.svg` — copy of frontend favicon
- `deploy/dev/authentik-seed/assets/custom.css` — PatternFly overrides

### Files to Modify
- `deploy/dev/authentik-seed/seed_authentik.py` — add ensure_branding()
- `deploy/dev/docker-compose.yml` — add volume mount to authentik-server
