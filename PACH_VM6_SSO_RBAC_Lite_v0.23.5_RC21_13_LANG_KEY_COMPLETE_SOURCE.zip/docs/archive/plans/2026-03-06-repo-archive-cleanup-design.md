# Repo Archive & Cleanup Design

**Date:** 2026-03-06
**Status:** Approved
**Deletion date:** 2026-03-21 (15-day retention)

## Goal

Move all pre-March stale documentation, plans, migration artifacts, and editor config into `_ARCHIVE_/` at repo root. Keep for 15 days as a buffer, then delete.

## Scope

### Archived (pre-March, superseded)

| Source | Files | Reason |
|--------|-------|--------|
| `docs/archive/` (entire dir) | 48 | v1.0 artifacts, old implementation plans, old HTML screenshots |
| `docs/plans/2026-02-*` | ~53 | February plans — superseded by single-LDAP, Authentik OIDC |
| `docs/plans/sessions/2026-02-*` | 8 | February session artifacts |
| `docs/reports/` (entire dir) | 2 | UED/SSO analysis reports (pre single-LDAP) |
| `docs/domains/split-panel-migrations.md` | 1 | Old migration domain doc |
| `docs/api/` (entire dir) | 3 | Jan 25 OpenAPI specs + frontend contracts — stale |
| `new-migration-ui/` (entire dir) | 19 | HTML screenshots + migration specs from Feb |
| `.cursor/rules/` | 2 | Old workflow .mdc files |
| `docs/knowledge/archive/` | 0 | Empty dir — just remove |

### Kept (active reference)

- `docs/prd/` — active PRDs
- `specs/v2.0/` — active v2.0 specification
- `docs/plans/2026-03-*` — current March plans
- `docs/plans/sessions/2026-03-*` — current session artifacts
- `docs/knowledge/libraries/` — active library reference
- `docs/knowledge/patterns/` — active architecture patterns
- `src/`, `tests/`, `deploy/`, `migrations/`, `tools/` — live code/infra
- Root config: `CLAUDE.md`, `README.md`, `Justfile`, `pytest.ini`, `.gitignore`, `.dockerignore`

## Structure

```
_ARCHIVE_/
├── README.md                          # Manifest + deletion date
├── docs/
│   ├── archive/                       # All from docs/archive/
│   ├── plans/                         # Feb plans
│   │   └── sessions/                  # Feb session artifacts
│   ├── reports/                       # 2 report files
│   ├── domains/                       # split-panel-migrations.md
│   └── api/                           # openapi.json, openapi.yaml, FRONTEND_API_CONTRACTS.md
├── new-migration-ui/                  # All 19 migration HTML/spec files
└── .cursor/
    └── rules/                         # 2 .mdc files
```

## Post-Move Cleanup

- Remove empty source directories
- Update `CLAUDE.md` references to archived locations
- Add `_ARCHIVE_/` to `.dockerignore`
- Single commit: `chore: archive pre-March stale docs and migration artifacts`

## Recovery

Any archived file can be recovered from git history:
```bash
git log --all -- <original-path>
git show <commit>:<original-path>
```

## 15-Day Deletion (March 21)

```bash
rm -rf _ARCHIVE_/
# Remove _ARCHIVE_ from .dockerignore
git add -A && git commit -m "chore: remove _ARCHIVE_ after 15-day retention"
```
