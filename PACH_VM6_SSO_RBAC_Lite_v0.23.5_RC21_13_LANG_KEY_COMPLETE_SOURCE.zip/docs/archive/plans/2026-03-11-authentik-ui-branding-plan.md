# Authentik UI Branding Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Apply AZBlink branding to Authentik UI (login page, user dashboard)
**Architecture:** Seed-script branding via Admin API + mounted assets
**Tech Stack:** Python (seed script), CSS (PatternFly overrides), SVG (logo), Docker Compose
**Domains:** backend, frontend, devops

---

### Task 1: Create Brand Assets Directory and Logo SVG
**domain:** frontend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [svg, design-tokens]

**Files:**
- Create: `deploy/dev/authentik-seed/assets/logo.svg`

**Step 1:** Create `deploy/dev/authentik-seed/assets/` directory
**Step 2:** Create `logo.svg` — AZBlink wordmark for Authentik login. White "AZBlink" text on transparent background with blue accent. Use Inter font, `#fafafa` text, `#3b82f6` accent. 180x48 viewBox for Authentik's header. Include "Directory" subtitle in smaller muted text.
**Step 3:** Verify SVG renders correctly (view in browser)

---

### Task 2: Create Favicon SVG
**domain:** frontend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [svg]

**Files:**
- Create: `deploy/dev/authentik-seed/assets/favicon.svg`

**Step 1:** Copy `src/frontend/public/favicon.svg` to `deploy/dev/authentik-seed/assets/favicon.svg`
**Step 2:** Verify file is identical

---

### Task 3: Create Custom CSS Theme
**domain:** frontend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [css, patternfly, authentik-theming]

**Files:**
- Create: `deploy/dev/authentik-seed/assets/custom.css`

**Step 1:** Create `custom.css` with PatternFly variable overrides:
- `--pf-global--primary-color--100: #3b82f6` (AZBlink blue-500)
- `--pf-global--primary-color--200: #2563eb` (AZBlink blue-600)
- `--ak-accent: #3b82f6`
- `--ak-dark-background: #0a0a0b`
- `--ak-dark-background-light: #111113`
- Font family: Inter
**Step 2:** Add login page selectors: `.pf-c-login__main`, `.pf-c-button.pf-m-primary`, `.pf-c-form-control`
**Step 3:** Add user dashboard selectors: `.pf-c-card`, `.pf-c-nav__link`, `.pf-c-page__sidebar`
**Step 4:** Add code font: JetBrains Mono for `code, pre`
**Step 5:** Hide locale selector: `ak-flow-executor::part(locale-select) { display: none; }`

---

### Task 4: Add Volume Mount to Docker Compose
**domain:** devops
**depends_on:** [1]
**parallel_group:** 2
**capabilities_needed:** [docker-compose]

**Files:**
- Modify: `deploy/dev/docker-compose.yml`

**Step 1:** Add volume mount to `authentik-server` service: `./authentik-seed/assets:/web/dist/assets/azblink:ro`
**Step 2:** Verify no existing volumes conflict

---

### Task 5: Add ensure_branding() to Seed Script
**domain:** backend
**depends_on:** [1, 2, 3]
**parallel_group:** 2
**capabilities_needed:** [python, authentik-api]

**Files:**
- Modify: `deploy/dev/authentik-seed/seed_authentik.py`

**Step 1:** Add `ensure_branding()` function before `main()`:
- GET `/core/brands/?default=true` → extract `brand_uuid`
- Read `/seed/assets/custom.css`
- Build PATCH payload: title, logo path, favicon path, custom_css, attributes (dark theme)
- PATCH `/core/brands/{brand_uuid}/`
- Error handling: log and continue if fails
**Step 2:** Add call to `ensure_branding()` in `main()` as step 5 (after admin group, before completion)
**Step 3:** Update main() print numbering

---

### Task 6: Integration Test — Full Stack Validation
**domain:** devops
**depends_on:** [4, 5]
**parallel_group:** 3
**capabilities_needed:** [docker, testing]

**Step 1:** Run `just down && just up` to rebuild stack
**Step 2:** Watch seed logs: `docker logs azblink-authentik-seed --follow`
**Step 3:** Verify "AZBlink branding applied" in seed output
**Step 4:** Verify API: `curl -s -H "Authorization: Bearer dev-authentik-api-token" http://localhost:9000/api/v3/core/brands/?default=true | jq '.results[0].branding_title'` → "AZBlink Directory"
**Step 5:** Visit http://localhost:9000/ in browser → visual check (dark theme, blue accent, AZBlink logo)
