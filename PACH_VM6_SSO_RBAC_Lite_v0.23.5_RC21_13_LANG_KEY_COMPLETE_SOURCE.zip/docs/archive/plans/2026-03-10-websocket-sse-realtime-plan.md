# WebSocket/SSE Real-Time Activity Feed — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Implement WebSocket and SSE endpoints for real-time activity feed, with in-process event bus hooking into existing audit recording functions.
**Architecture:** asyncio Queue-per-subscriber event bus → dual transport (WS + SSE) → hooks into 5 audit functions
**Tech Stack:** FastAPI WebSocket, StreamingResponse SSE, asyncio.Queue, websockets (testing)
**Domains:** backend

---

### Task 1: Create event bus module
**domain:** backend
**depends_on:** []
**parallel_group:** 1
**capabilities_needed:** [python-asyncio, event-driven-architecture]

**Files:**
- Create: `src/backend/activity_bus.py`

**Step 1:** Create `src/backend/activity_bus.py` with:
- `ActivityBus` class with `__init__(max_queue_size=100)`, `_subscribers: set[asyncio.Queue]`
- `subscribe()` → creates Queue(maxsize), adds to set, returns queue
- `unsubscribe(queue)` → removes from set (discard, not remove — idempotent)
- `publish(event: dict)` → iterate `list(self._subscribers)`, `put_nowait()`, catch QueueFull
- Module-level: `_activity_bus: ActivityBus | None`, `init_activity_bus()`, `get_activity_bus()`
- `subscriber_count` property for monitoring

**Step 2:** Verify syntax: `python -c "import activity_bus"` (from src/backend dir)

---

### Task 2: Wire event bus into lifespan and add imports
**domain:** backend
**depends_on:** [1]
**parallel_group:** 2
**capabilities_needed:** [fastapi]

**Files:**
- Modify: `src/backend/main.py` (lifespan + imports)

**Step 1:** Add imports at top of main.py (after existing imports ~line 65):
```python
from fastapi import WebSocket, WebSocketDisconnect, status as ws_status
from activity_bus import init_activity_bus, get_activity_bus
from threading import Lock
```

**Step 2:** Modify the lifespan context manager (line 84) to init the bus:
```python
@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    """Application lifespan manager."""
    init_activity_bus()
    logger.info("Activity bus initialized")
    yield
    logger.info("Activity bus shutting down")
```

**Step 3:** Verify backend starts without errors: check container logs

---

### Task 3: Add connection tracking and WebSocket endpoint
**domain:** backend
**depends_on:** [2]
**parallel_group:** 3
**capabilities_needed:** [fastapi, websocket, auth]

**Files:**
- Modify: `src/backend/main.py` (connection tracking + WS endpoint)

**Step 1:** Add connection tracking code BEFORE the existing `/api/activity/recent` endpoint:
- `_ws_connections: dict[str, int] = {}` — tracks count per user_sub
- `_ws_lock = Lock()` — thread-safe access
- `MAX_WS_CONNECTIONS_PER_USER = 3`
- `_acquire_ws_slot(user_sub: str) -> bool` — returns True if slot acquired, False if limit reached
- `_release_ws_slot(user_sub: str)` — decrement count, delete key at 0

**Step 2:** Add WebSocket auth helper:
```python
def _verify_ws_token(token: str | None) -> dict | None:
    """Verify WebSocket token. Returns claims dict or None."""
    if not token:
        return None
    if DEV_AUTH_TOKEN and token == DEV_AUTH_TOKEN:
        return {"sub": "dev-admin", "preferred_username": "dev-admin", ...}
    try:
        return verify_bearer_token(token)
    except Exception:
        return None
```

**Step 3:** Add WebSocket endpoint AFTER `/api/activity/recent`:
```python
@app.websocket("/api/activity/ws")
async def activity_websocket(websocket: WebSocket, token: str | None = Query(None)):
    """Real-time activity feed via WebSocket."""
    claims = _verify_ws_token(token)
    if not claims:
        await websocket.close(code=ws_status.WS_1008_POLICY_VIOLATION)
        return
    user_sub = claims.get("sub", "unknown")
    if not _acquire_ws_slot(user_sub):
        await websocket.close(code=ws_status.WS_1008_POLICY_VIOLATION)
        return
    bus = get_activity_bus()
    queue = bus.subscribe()
    await websocket.accept()
    try:
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=30.0)
                await websocket.send_json(event)
            except asyncio.TimeoutError:
                await websocket.send_json({"type": "heartbeat"})
    except (WebSocketDisconnect, Exception):
        pass
    finally:
        bus.unsubscribe(queue)
        _release_ws_slot(user_sub)
```

**Step 4:** Verify syntax: `python -c "from main import app"`

---

### Task 4: Add SSE endpoint
**domain:** backend
**depends_on:** [2]
**parallel_group:** 3
**capabilities_needed:** [fastapi, sse]

**Files:**
- Modify: `src/backend/main.py` (SSE endpoint)

**Step 1:** Add SSE endpoint AFTER the WebSocket endpoint:
```python
@app.get("/api/activity/stream")
async def activity_stream(
    request: Request,
    claims: Dict[str, Any] = Depends(require_admin),
):
    """Real-time activity feed via Server-Sent Events (SSE fallback)."""
    user_sub = claims.get("sub", "unknown")
    if not _acquire_ws_slot(user_sub):
        raise HTTPException(429, "Connection limit exceeded")
    bus = get_activity_bus()
    queue = bus.subscribe()

    async def event_generator():
        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30.0)
                    yield f"data: {json.dumps(event)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            bus.unsubscribe(queue)
            _release_ws_slot(user_sub)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )
```

**Step 2:** Verify syntax compiles

---

### Task 5: Hook audit recording functions to publish events
**domain:** backend
**depends_on:** [1]
**parallel_group:** 3
**capabilities_needed:** [python, sqlalchemy]

**Files:**
- Modify: `src/backend/orgdb.py` (5 audit functions)

**Step 1:** Add helper function at module level in orgdb.py (after imports):
```python
def _publish_activity_event(event: dict) -> None:
    """Fire-and-forget publish to activity bus. Never raises."""
    try:
        from activity_bus import get_activity_bus
        bus = get_activity_bus()
        # Use asyncio to publish from sync context
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(bus.publish(event))
        except RuntimeError:
            # No running loop (e.g., during testing without async)
            pass
    except Exception:
        pass  # Never break audit recording
```

**Step 2:** Add publish call to `record_lifecycle_event()` (after conn.execute):
```python
_publish_activity_event({
    "id": f"lc-{user_uid}-{int(utcnow().timestamp())}",
    "type": "user-created" if action == "created" else "user-terminated" if action == "terminated" else action,
    "text": f"User {user_uid} {action}",
    "meta": f"By {performed_by}" + (f": {detail}" if detail else ""),
    "time": "just now",
    "timestamp": utcnow().isoformat(),
})
```

**Step 3:** Add publish to `record_qr_issuance()` (after conn.execute):
```python
_publish_activity_event({
    "id": f"qr-{token_hash[:12]}",
    "type": "qr-generated",
    "text": f"QR token generated for {user_uid}",
    "meta": f"Issued by {issued_by}",
    "time": "just now",
    "timestamp": utcnow().isoformat(),
})
```

**Step 4:** Add publish to `record_admin_action()` (after conn.execute):
```python
_publish_activity_event({
    "id": f"admin-{result.inserted_primary_key[0]}",
    "type": "sso-enrolled" if action == "sso_enroll" else action.replace("_", "-"),
    "text": f"{action.replace('_', ' ').title()}: {resource_type} {resource_id}",
    "meta": f"By {actor}",
    "time": "just now",
    "timestamp": utcnow().isoformat(),
})
```

**Step 5:** Add publish to `record_suspension_event()` (after conn.execute):
```python
_publish_activity_event({
    "id": f"sus-{user_uid}-{int(utcnow().timestamp())}",
    "type": f"user-{action}",
    "text": f"User {user_uid} {action}",
    "meta": f"By {performed_by}" + (f" — {reason}" if reason else ""),
    "time": "just now",
    "timestamp": utcnow().isoformat(),
})
```

**Step 6:** Add publish to `record_auth_failure()` (after conn.execute):
```python
_publish_activity_event({
    "id": f"auth-{int(utcnow().timestamp())}",
    "type": "auth-failure",
    "text": f"Auth failure: {failure_reason}",
    "meta": f"From {client_ip}" + (f" user={username}" if username else ""),
    "time": "just now",
    "timestamp": utcnow().isoformat(),
})
```

**Step 7:** Ensure `import asyncio` is present in orgdb.py imports

---

### Task 6: Write integration tests
**domain:** backend
**depends_on:** [3, 4, 5]
**parallel_group:** 4
**capabilities_needed:** [pytest, websockets, testing]

**Files:**
- Create: `tests/test_activity_realtime.py`

**Step 1:** Create test file with imports and fixtures:
```python
"""Integration tests for WebSocket/SSE real-time activity feed."""
import asyncio
import json
import pytest
import websockets
import httpx

WS_BASE = "ws://localhost:8081/api/activity/ws"
API_BASE = "http://localhost:8081"
AUTH_TOKEN = "dev-test-token"
```

**Step 2:** Test WebSocket auth rejection:
```python
@pytest.mark.asyncio
async def test_websocket_rejects_invalid_token():
    """WS /api/activity/ws rejects invalid token."""
    with pytest.raises(websockets.exceptions.ConnectionClosed) as exc_info:
        async with websockets.connect(f"{WS_BASE}?token=invalid-token"):
            pass
    assert exc_info.value.rcvd.code == 1008
```

**Step 3:** Test WebSocket auth rejection with no token:
```python
@pytest.mark.asyncio
async def test_websocket_rejects_missing_token():
    """WS /api/activity/ws rejects missing token."""
    with pytest.raises(websockets.exceptions.ConnectionClosed):
        async with websockets.connect(WS_BASE):
            pass
```

**Step 4:** Test WebSocket accepts valid token:
```python
@pytest.mark.asyncio
async def test_websocket_accepts_valid_token():
    """WS /api/activity/ws accepts dev auth token."""
    async with websockets.connect(f"{WS_BASE}?token={AUTH_TOKEN}") as ws:
        # Connection accepted — try to receive heartbeat (30s timeout in endpoint)
        # Just verify connection stays open briefly
        await asyncio.sleep(0.5)
        assert ws.open
```

**Step 5:** Test WebSocket receives event on user action:
```python
@pytest.mark.asyncio
async def test_websocket_receives_activity_event(client, created_users):
    """Trigger audit event → verify WebSocket receives it within 5s."""
    import uuid
    uid = f"wstest-{uuid.uuid4().hex[:8]}"

    async with websockets.connect(f"{WS_BASE}?token={AUTH_TOKEN}") as ws:
        # Small delay to ensure subscription is active
        await asyncio.sleep(0.3)

        # Trigger user creation (which records lifecycle event)
        resp = client.post("/api/users/create", json={
            "uid": uid,
            "displayName": f"WS Test {uid}",
            "mail": f"{uid}@test.com",
            "mobile": "1234567890",
            "password": "testpass123",
            "orgDn": "ou=org,dc=azblink,dc=com",
        })
        assert resp.status_code == 201
        created_users.append(uid)

        # Receive event with timeout
        raw = await asyncio.wait_for(ws.recv(), timeout=5.0)
        event = json.loads(raw)
        assert event["type"] in ("user-created", "created")
        assert uid in event["text"]
        assert "timestamp" in event
```

**Step 6:** Test SSE endpoint:
```python
def test_sse_endpoint_returns_event_stream(client):
    """GET /api/activity/stream returns text/event-stream."""
    with client.stream("GET", "/api/activity/stream") as resp:
        assert resp.status_code == 200
        assert "text/event-stream" in resp.headers.get("content-type", "")
        # Read a few bytes then close (don't hang)
        break

@pytest.mark.asyncio
async def test_sse_receives_activity_event():
    """SSE stream receives events when audit action occurs."""
    async with httpx.AsyncClient(base_url=API_BASE, timeout=10) as aclient:
        async with aclient.stream(
            "GET",
            "/api/activity/stream",
            headers={"Authorization": f"Bearer {AUTH_TOKEN}"},
        ) as resp:
            assert resp.status_code == 200
            # Trigger an admin action
            async with httpx.AsyncClient(base_url=API_BASE) as trigger:
                await trigger.get(
                    "/api/dashboard/stats",
                    headers={"Authorization": f"Bearer {AUTH_TOKEN}"},
                )
            # Read lines looking for a data: line
            async for line in resp.aiter_lines():
                if line.startswith("data:"):
                    event = json.loads(line[5:].strip())
                    assert "type" in event
                    break
                if line.startswith(":"):
                    continue  # keepalive
```

**Step 7:** Test SSE rejects unauthorized:
```python
def test_sse_rejects_unauthorized(anon_client):
    """SSE endpoint rejects unauthenticated requests."""
    resp = anon_client.get("/api/activity/stream")
    assert resp.status_code == 401
```

**Step 8:** Run tests: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack && just test-quick`
- Verify ALL existing tests still pass
- Verify new tests pass

---

### Task 7: Run full test suite and fix any issues
**domain:** backend
**depends_on:** [6]
**parallel_group:** 5
**capabilities_needed:** [testing, debugging]

**Files:**
- Possibly fix: any files with issues

**Step 1:** Run full test suite: `just test-quick`
**Step 2:** If any failures, debug and fix
**Step 3:** Verify all tests pass (should be 305+ existing + ~6 new)
