# L1-L5 Dead Code Cleanup — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Remove 10 dead code items (HIGH + MEDIUM severity) found by L1-L5 stratified codebase audit — orphan DB tables, dead config vars, dead methods, dead components, deprecated types, and unused design system primitives.

**Architecture:** Two waves ordered by stack layer. Wave 1 is backend + tests (Python, SQL). Wave 2 is frontend + design system (TypeScript). Each task is independent within its wave.

**Tech Stack:** Python/FastAPI (backend), PostgreSQL (migrations), TypeScript/React (frontend), @azblink/ui (design system)

**Test commands:**
- Backend: `just test-quick` (assumes stack is up)
- Frontend: `just ui-build` (type-checks + builds)

---

## Wave 1: Backend + Test Cleanup

Backend changes with test verification. Run `just test-quick` after each.

---

### Task 1: Drop orphan UED sync tables (#HIGH)

Tables `tenant_ldap_configs` and `sync_events` were created by migration 010 for the UED sync subsystem, which was fully removed during single-LDAP migration. No Table() definition in orgdb.py, zero code references.

**Files:**
- Create: `migrations/023_drop_ued_sync_tables.sql`

**Step 1: Create the migration**

```sql
-- 023_drop_ued_sync_tables.sql
-- Drop orphan tables from removed UED sync subsystem (migrations 010-015).
-- These tables have zero code references since the single-LDAP migration.

DROP TABLE IF EXISTS sync_events;
DROP TABLE IF EXISTS tenant_ldap_configs;
```

**Step 2: Apply the migration**

Run: `just psql < ../../migrations/023_drop_ued_sync_tables.sql`
Expected: DROP TABLE (x2)

**Step 3: Run tests**

Run: `just test-quick`
Expected: All pass — no code references these tables

**Step 4: Commit**

```bash
git add migrations/023_drop_ued_sync_tables.sql
git commit -m "chore(db): drop orphan tenant_ldap_configs and sync_events tables"
```

---

### Task 2: Remove dead config variables (#MEDIUM)

`UCCHAT_WEBRTC_SIP_URL` and `UCCHAT_TURN_URL` are defined in config.py but never read by any backend code.

**Files:**
- Modify: `src/backend/config.py:102-104`

**Step 1: Remove the two lines**

Remove lines 102-104:
```python
# Backward-compat alias (older docs/configs)
UCCHAT_WEBRTC_SIP_URL = os.getenv("UCCHAT_WEBRTC_SIP_URL", UCCHAT_SIP_WSS_URL)
UCCHAT_TURN_URL = os.getenv("UCCHAT_TURN_URL", "")
```

**Step 2: Run tests**

Run: `just test-quick`
Expected: All pass — nothing imports these variables

**Step 3: Commit**

```bash
git add src/backend/config.py
git commit -m "chore(backend): remove unused UCCHAT_WEBRTC_SIP_URL and UCCHAT_TURN_URL config vars"
```

---

### Task 3: Remove dead UCClient.check_session_status() (#MEDIUM)

Stub method with zero callers and zero test coverage. Returns hardcoded `{active_sip: 0, active_xmpp: 0}`.

**Files:**
- Modify: `src/backend/uc_client.py:4,69-80`

**Step 1: Remove the method (lines 69-80)**

Delete `check_session_status()` method from UCClient class.

**Step 2: Update module docstring (line 4)**

Change:
```python
- check_session_status(): Query active session count for a user
```
Remove that line from the docstring.

**Step 3: Run tests**

Run: `just test-quick`
Expected: All pass — no code calls this method

**Step 4: Commit**

```bash
git add src/backend/uc_client.py
git commit -m "chore(backend): remove dead UCClient.check_session_status() stub"
```

---

### Task 4: Fix test fixture missing cleanup (#HIGH)

The `created_users` fixture in conftest.py cleans up `provision_tokens`, `qr_issuance_audit`, `termination_events`, and `suspension_events` but NOT `user_lifecycle_audit`, causing data accumulation between test runs.

**Files:**
- Modify: `tests/conftest.py:154`

**Step 1: Add the missing cleanup line**

After line 154 (`DELETE FROM suspension_events`), add:
```python
            cur.execute("DELETE FROM user_lifecycle_audit WHERE user_uid = %s", (uid,))
```

**Step 2: Run tests**

Run: `just test-quick`
Expected: All pass

**Step 3: Commit**

```bash
git add tests/conftest.py
git commit -m "fix(tests): add user_lifecycle_audit cleanup to created_users fixture"
```

---

## Wave 2: Frontend + Design System Cleanup

Frontend changes with type-check verification. Run `just ui-build` after each.

---

### Task 5: Delete dead QRDisplay component (#MEDIUM)

`QRDisplay` and `QRDisplaySkeleton` are exported but never imported by any file.

**Files:**
- Delete: `src/frontend/src/components/features/qr-display.tsx`

**Step 1: Verify zero imports**

Run: `rg "QRDisplay|QRDisplaySkeleton" src/frontend/src/ --type ts --type tsx`
Expected: Only hits inside `qr-display.tsx` itself

**Step 2: Delete the file**

```bash
rm src/frontend/src/components/features/qr-display.tsx
```

**Step 3: Verify frontend builds**

Run: `just ui-build`
Expected: PASS

**Step 4: Commit**

```bash
git add -u src/frontend/src/components/features/qr-display.tsx
git commit -m "chore(frontend): remove dead QRDisplay component"
```

---

### Task 6: Delete dead HealthStatus component (#MEDIUM)

The `HealthStatus` **component** in `health-status.tsx` is never imported. Note: the `HealthStatus` **type** in `types/dashboard.ts` is alive and unrelated.

**Files:**
- Delete: `src/frontend/src/components/features/health-status.tsx`

**Step 1: Verify zero component imports**

Run: `rg "from.*health-status|import.*HealthStatus.*from.*features" src/frontend/src/`
Expected: Zero matches

**Step 2: Delete the file**

```bash
rm src/frontend/src/components/features/health-status.tsx
```

**Step 3: Verify frontend builds**

Run: `just ui-build`
Expected: PASS

**Step 4: Commit**

```bash
git add -u src/frontend/src/components/features/health-status.tsx
git commit -m "chore(frontend): remove dead HealthStatus component"
```

---

### Task 7: Replace deprecated Group type (#MEDIUM)

The `Group` interface in `types/user.ts` is deprecated in favor of `GroupListItem`. However, the backend `/users/{uid}/groups` endpoint returns `{dn, cn, orgDn}` — neither type matches exactly. Create a proper `UserGroup` type that matches the actual API response.

**Files:**
- Modify: `src/frontend/src/lib/queries/users.ts:8,28`
- Modify: `src/frontend/src/types/user.ts:72-81` (remove deprecated `Group`)

**Step 1: Add UserGroup type to users.ts**

After the existing imports, add:
```typescript
/** Group membership entry from GET /api/users/{uid}/groups */
interface UserGroup {
  dn: string;
  cn: string;
  orgDn: string;
}
```

**Step 2: Update the import line (line 8)**

Change:
```typescript
import type { User, Group, PaginatedUsersResponse, PaginationParams } from '@/types';
```
To:
```typescript
import type { User, PaginatedUsersResponse, PaginationParams } from '@/types';
```

**Step 3: Update the query options (line 28)**

Change:
```typescript
queryFn: () => getApi().get<{ groups: Group[] }>(`/users/${uid}/groups`),
```
To:
```typescript
queryFn: () => getApi().get<{ groups: UserGroup[] }>(`/users/${uid}/groups`),
```

**Step 4: Remove deprecated Group from types/user.ts (lines 72-81)**

Delete the entire `Group` interface and its deprecation comment.

**Step 5: Verify frontend builds**

Run: `just ui-build`
Expected: PASS — no other file imports `Group` from `@/types` or `@/types/user`

**Step 6: Commit**

```bash
git add src/frontend/src/lib/queries/users.ts src/frontend/src/types/user.ts
git commit -m "refactor(frontend): replace deprecated Group type with UserGroup matching API response"
```

---

### Task 8: Remove dead DataTable from @azblink/ui (#MEDIUM)

`DataTable` and `DataTableColumnHeader` are exported from the design system barrel but never imported by the main app.

**Files:**
- Modify: `src/frontend/packages/azblink-ui/index.ts:55-56`
- Delete: `src/frontend/packages/azblink-ui/primitives/DataTable/` (entire directory)

**Step 1: Remove exports from barrel**

Remove these lines from `index.ts`:
```typescript
export { DataTable, DataTableColumnHeader } from './primitives/DataTable';
export type { DataTableProps } from './primitives/DataTable';
```

**Step 2: Delete the primitive directory**

```bash
rm -rf src/frontend/packages/azblink-ui/primitives/DataTable/
```

**Step 3: Verify frontend builds**

Run: `just ui-build`
Expected: PASS

**Step 4: Commit**

```bash
git add -u src/frontend/packages/azblink-ui/
git commit -m "chore(ui): remove unused DataTable primitive from @azblink/ui"
```

---

## Execution Order & Dependencies

```
Wave 1 (backend, all independent):
  Task 1: Drop orphan DB tables ............ HIGH
  Task 2: Remove dead config vars .......... MEDIUM
  Task 3: Remove dead UCClient method ...... MEDIUM
  Task 4: Fix test fixture cleanup ......... HIGH

Wave 2 (frontend, all independent):
  Task 5: Delete QRDisplay component ....... MEDIUM
  Task 6: Delete HealthStatus component .... MEDIUM
  Task 7: Replace deprecated Group type .... MEDIUM
  Task 8: Remove DataTable from @azblink/ui  MEDIUM
```

**Total: 8 tasks, 8 commits, 2 waves**

All tasks within each wave are independent and can run in parallel.

---

## Verification Checklist (run after all tasks)

```bash
# Full test suite
just test-quick

# Full frontend build + type check
just ui-build

# Verify orphan tables dropped
just psql -c "\dt tenant_ldap_configs" 2>&1 | grep -c "Did not find"
just psql -c "\dt sync_events" 2>&1 | grep -c "Did not find"

# Verify dead config vars gone
rg "UCCHAT_WEBRTC_SIP_URL|UCCHAT_TURN_URL" src/backend/

# Verify dead method gone
rg "check_session_status" src/backend/

# Verify dead components gone
rg "QRDisplay|QRDisplaySkeleton" src/frontend/src/ --type ts
rg "from.*health-status" src/frontend/src/

# Verify deprecated Group type removed
rg "interface Group" src/frontend/src/types/user.ts

# Verify DataTable removed
ls src/frontend/packages/azblink-ui/primitives/DataTable/ 2>&1
rg "DataTable" src/frontend/packages/azblink-ui/index.ts
```
