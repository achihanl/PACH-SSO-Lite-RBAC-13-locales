---
feature: websocket-sse-realtime
date: 2026-03-10
status: approved
---

# WebSocket/SSE Real-Time Activity Feed — Architecture Design

## Core Decision: In-Process Event Bus with Dual Transport

In-process asyncio event bus (`activity_bus.py`) with WebSocket (primary) and SSE (fallback) transports. Hooks into existing audit recording functions to publish events immediately after DB commit.

## Components

### 1. `src/backend/activity_bus.py` (NEW, ~80 lines)
- `ActivityBus` class: asyncio.Queue per subscriber, publish/subscribe/unsubscribe
- Global singleton: `init_activity_bus()`, `get_activity_bus()`
- Queue maxsize=100, `put_nowait()` with drop-on-full
- Thread-safe subscriber management

### 2. WebSocket Endpoint — `WS /api/activity/ws` (in main.py)
- Auth: `token` query param → `verify_bearer_token()` or DEV_AUTH_TOKEN bypass
- Connection limit: 3 per user (tracked in dict with lock)
- Subscribe → loop read queue → send_json → catch WebSocketDisconnect → unsubscribe

### 3. SSE Endpoint — `GET /api/activity/stream` (in main.py)
- Auth: Standard Bearer header → `_claims_from_auth_header()`
- Connection limit: shared with WebSocket
- StreamingResponse with async generator
- Format: `data: {json}\n\n`
- Keepalive: `: keepalive\n\n` every 30s
- Disconnect: `request.is_disconnected()` check

### 4. Audit Hooks — 5 functions in orgdb.py
- `record_qr_issuance()` → "qr-generated"
- `record_lifecycle_event()` → "user-created" / "user-terminated" / "qr-consumed"
- `record_suspension_event()` → "user-suspended" / "user-unsuspended"
- `record_admin_action()` → type from action field
- `record_auth_failure()` → "auth-failure"
- All wrapped in try/except (never break audit recording)

### 5. Lifespan (modify main.py:84)
- Startup: `init_activity_bus()`
- Shutdown: logging only (queues GC naturally)

## Event Format (matches ActivityEvent)
```json
{
  "id": "lc-123",
  "type": "user-created",
  "text": "User alice created",
  "meta": "By admin dev-admin",
  "time": "just now",
  "timestamp": "2026-03-10T12:00:00+00:00"
}
```

## Connection Management
- Dict `{user_sub: count}` with threading.Lock
- Max 3 connections per user (WS + SSE combined)
- Reject with WS_1008 / HTTP 429 if limit exceeded
- Release slot in finally block

## Security
- Auth validated BEFORE WebSocket accept
- DEV_AUTH_TOKEN bypass for tests
- No sensitive data in events (UIDs + action summaries only)
- Connection limit prevents resource exhaustion
