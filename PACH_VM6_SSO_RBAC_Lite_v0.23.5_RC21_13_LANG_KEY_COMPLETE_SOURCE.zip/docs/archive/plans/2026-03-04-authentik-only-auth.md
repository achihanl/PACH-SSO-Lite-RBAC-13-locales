# Authentik-Only Auth Implementation Plan (v2 — Fullstack)

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Replace LDAP JWT auth with Authentik OIDC as the sole auth path for the AZBlink Directory admin UI. Remove breakglass. Wire Authentik session revocation into termination flow.

**Architecture:** Two clean auth planes — Plane A (UC/LDAP bind, unchanged) and Plane B (all web UIs behind Authentik OIDC). Backend validates OIDC Bearer tokens only. Frontend redirects to Authentik for login via PKCE. No fallback, no breakglass.

**Tech Stack:** FastAPI, PyJWT/PyJWKClient, OIDC/PKCE, Authentik Admin API v3, React 19, Zustand, TanStack Router, Web Crypto API

**Design Doc:** `docs/plans/sessions/2026-03-04-authentik-only-auth-design.md`
**Exploration:** `docs/plans/sessions/2026-03-04-authentik-only-auth-exploration.md`
**Knowledge:** `docs/knowledge/libraries/oidc-pkce-browser.md`, `docs/knowledge/libraries/authentik-admin-api-v3.md`

**Supersedes:** v1 plan (backend-heavy, frontend was a mega-task)

---

## Task 1: Backend — Remove LDAP JWT Auth Module + Login Endpoint

**Files:**
- Delete: `src/backend/auth.py` (entire file — 207 lines)
- Modify: `src/backend/main.py:59-60` (remove auth.py imports)
- Modify: `src/backend/main.py:370-393` (remove `/api/auth/login` endpoint)

**Step 1: Remove the login endpoint from main.py**

Delete lines 370-393 in `main.py` — the `POST /api/auth/login` route and its handler `api_auth_login`.

**Step 2: Remove auth.py imports from main.py**

In `main.py` line 60, remove:
```python
from auth import LoginRequest, LoginResponse, LoginError, authenticate_user
```

**Step 3: Delete auth.py**

Remove `src/backend/auth.py` entirely.

**Step 4: Run tests to identify breakage**

Run: `just test-quick 2>&1 | head -100`
Expected: Tests that use `/api/auth/login` will fail. This is expected — fixed in Task 3.

**Step 5: Commit**

```bash
git add -u src/backend/auth.py src/backend/main.py
git commit -m "refactor: remove LDAP JWT auth module and login endpoint"
```

---

## Task 2: Backend — Remove Breakglass + Simplify Auth Middleware to OIDC-Only

**Files:**
- Modify: `src/backend/main.py:163-304` (remove breakglass, simplify auth functions)
- Modify: `src/backend/config.py` (remove JWT/breakglass/toggle config vars)
- Delete: `tests/test_breakglass.py`
- Delete: `tests/test_auth.py`
- Modify: `src/cli/directoryctl.py` (remove breakglass commands)

**Step 1: Remove breakglass constants and functions from main.py**

Delete from `main.py`:
- Lines 163-165: `BOOTSTRAP_OPEN_PATHS` set
- Lines 171-198: `_load_breakglass(path)` function
- Lines 203-209: `ADMIN_RECOVERY_PREFIXES` tuple
- Lines 212-231: `_breakglass_allows(request)` function
- Lines 17-18: imports of `REQUIRE_OIDC_AUTH`, `ALLOW_BOOTSTRAP_WITHOUT_OIDC`, `BREAKGLASS_FILE`

**Step 2: Simplify `_claims_from_auth_header` to OIDC-only**

Replace lines 233-259 with:
```python
def _claims_from_auth_header(request: Request, authorization: Optional[str]) -> Dict[str, Any]:
    """Extract and verify OIDC claims from Authorization header.

    Authentik OIDC is the sole auth path — no JWT fallback.
    """
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing Bearer token")
    token = authorization.split(" ", 1)[1].strip()
    try:
        return verify_bearer_token(token)
    except Exception as e:
        client_ip = request.client.host if request.client else "unknown"
        user_agent = request.headers.get("user-agent")
        try:
            ORGDB.record_auth_failure(
                client_ip=client_ip,
                endpoint=request.url.path,
                failure_reason="invalid_token",
                username=None,
                user_agent=user_agent,
            )
        except Exception:
            pass
        raise HTTPException(401, f"Invalid token: {e}")
```

**Step 3: Remove bypass from `require_admin` and `require_permission`**

In `require_admin` (lines 266-275), remove the `if not REQUIRE_OIDC_AUTH: return claims` bypass.
In `require_permission` (lines 278-304), remove the same bypass.

**Step 4: Remove config vars from config.py**

Remove from `config.py`:
- `REQUIRE_OIDC_AUTH` (line ~43)
- `ALLOW_BOOTSTRAP_WITHOUT_OIDC` (line ~46)
- `BREAKGLASS_FILE` (line ~85)
- `JWT_SECRET`, `JWT_ALGORITHM`, `JWT_EXPIRY_HOURS`, `JWT_REMEMBER_DAYS` (lines ~59-76)
- `_validate_jwt_secret()` function and its call

Add (if not present):
- `AUTHENTIK_API_URL = os.getenv("AUTHENTIK_API_URL", "")`
- `AUTHENTIK_API_TOKEN = os.getenv("AUTHENTIK_API_TOKEN", "")`

**Step 5: Remove breakglass from directoryctl.py**

Remove the `breakglass` subcommand group from `src/cli/directoryctl.py`.

**Step 6: Delete test_breakglass.py and test_auth.py**

Remove `tests/test_breakglass.py` and `tests/test_auth.py` entirely.

**Step 7: Commit**

```bash
git add -u
git commit -m "refactor: remove breakglass and dual-auth mode, simplify to OIDC-only

OIDC is now the sole auth path. No REQUIRE_OIDC_AUTH toggle,
no ALLOW_BOOTSTRAP_WITHOUT_OIDC, no breakglass, no JWT."
```

---

## Task 3: Test Infrastructure — Rewrite `auth_headers` Fixture for OIDC Mock

**Files:**
- Modify: `tests/conftest.py` (rewrite `auth_headers` fixture)
- Verify: all 6 test files that use `auth_headers` (~120+ references)

This is the **critical path** — all integration tests depend on this fixture.

**Step 1: Rewrite the auth_headers fixture in conftest.py**

Replace the current fixture (lines 104-110) that calls `/api/auth/login` with an OIDC mock:

```python
@pytest.fixture(autouse=True)
def mock_oidc_verify(monkeypatch):
    """Mock OIDC token verification for all tests.

    Accepts 'mock-admin-token' as a valid admin OIDC token.
    All other tokens raise Exception (invalid).
    """
    def fake_verify(token):
        if token == "mock-admin-token":
            return {
                "sub": "mei",
                "uid": "mei",
                "preferred_username": "mei",
                "email": "mei@azblink.com",
                "groups": ["IT-Admins"],
                "iss": "https://authentik.example.com/application/o/azblink-directory/",
                "aud": "azblink-directory",
            }
        raise Exception("Invalid token")
    monkeypatch.setattr("main.verify_bearer_token", fake_verify)


@pytest.fixture
def auth_headers():
    """Auth headers with mocked OIDC admin token.

    Works because mock_oidc_verify (autouse) accepts this token.
    """
    return {"Authorization": "Bearer mock-admin-token"}
```

**Step 2: Run full test suite**

Run: `just test-quick`
Expected: All existing tests pass with the mocked OIDC fixture. The `auth_headers` fixture returns the same header format (`Bearer <token>`) so all ~120+ usages remain compatible.

**Key insight:** The fixture signature is unchanged — it still returns `{"Authorization": "Bearer <token>"}`. The only change is HOW the token is validated (mock instead of real LDAP login). This means zero changes to the 120+ test callsites.

**Step 3: Commit**

```bash
git add tests/conftest.py
git commit -m "test: rewrite auth_headers fixture for OIDC mock verification

Replace LDAP JWT login with monkeypatched verify_bearer_token.
~120+ test references unchanged — same fixture signature."
```

---

## Task 4: Backend — Create Authentik Admin API Client

**Files:**
- Create: `src/backend/authentik_client.py`
- Create: `tests/test_authentik_client.py`

**Step 1: Write failing test for Authentik client**

Create `tests/test_authentik_client.py`:
```python
"""Tests for Authentik Admin API client.

- Session/token revocation for user termination
- Uses mocked HTTP responses — no real Authentik server
"""

import pytest
from unittest.mock import patch, MagicMock
from authentik_client import AuthentikClient, AuthentikError


@pytest.fixture
def ak_client():
    return AuthentikClient(
        api_url="http://authentik:9000",
        api_token="test-token",
    )


class TestAuthentikClient:
    def test_revoke_user_sessions_success(self, ak_client):
        """Revoke all sessions for a user by username."""
        with patch.object(ak_client, "_api_request") as mock_req:
            mock_req.side_effect = [
                {"results": [{"pk": 42, "username": "testuser"}]},
                {"results": [{"pk": "sess-1"}, {"pk": "sess-2"}]},
                None,
                None,
            ]
            result = ak_client.revoke_user_sessions("testuser")
            assert result["sessions_revoked"] == 2

    def test_revoke_user_sessions_user_not_found(self, ak_client):
        """Return zero revoked if user doesn't exist in Authentik."""
        with patch.object(ak_client, "_api_request") as mock_req:
            mock_req.return_value = {"results": []}
            result = ak_client.revoke_user_sessions("nonexistent")
            assert result["sessions_revoked"] == 0
            assert result["user_found"] is False

    def test_revoke_user_tokens_success(self, ak_client):
        """Revoke all OAuth2 tokens for a user."""
        with patch.object(ak_client, "_api_request") as mock_req:
            mock_req.side_effect = [
                {"results": [{"pk": 42, "username": "testuser"}]},
                {"results": [{"pk": 101}, {"pk": 102}]},
                None,
                None,
            ]
            result = ak_client.revoke_user_tokens("testuser")
            assert result["tokens_revoked"] == 2

    def test_terminate_user_access_combines_both(self, ak_client):
        """Full termination revokes sessions + tokens."""
        with patch.object(ak_client, "revoke_user_sessions") as mock_sess, \
             patch.object(ak_client, "revoke_user_tokens") as mock_tok:
            mock_sess.return_value = {"user_found": True, "sessions_revoked": 3}
            mock_tok.return_value = {"user_found": True, "tokens_revoked": 1}
            result = ak_client.terminate_user_access("testuser")
            assert result["sessions_revoked"] == 3
            assert result["tokens_revoked"] == 1

    def test_api_error_raises_authentik_error(self, ak_client):
        """Network/API errors raise AuthentikError."""
        with patch.object(ak_client, "_api_request") as mock_req:
            mock_req.side_effect = Exception("Connection refused")
            with pytest.raises(AuthentikError, match="Connection refused"):
                ak_client.revoke_user_sessions("testuser")

    def test_client_not_configured(self):
        """Client with empty URL/token raises on use."""
        client = AuthentikClient(api_url="", api_token="")
        with pytest.raises(AuthentikError, match="not configured"):
            client.revoke_user_sessions("testuser")
```

**Step 2: Run test to verify it fails**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack && python -m pytest tests/test_authentik_client.py -v`
Expected: FAIL — `authentik_client` module doesn't exist yet.

**Step 3: Implement authentik_client.py**

Create `src/backend/authentik_client.py`:
```python
"""Authentik Admin API v3 client for session/token lifecycle.

- Revoke user sessions on termination
- Revoke OAuth2 access/refresh tokens on termination
- Used by termination endpoint in main.py

Authentik API: https://docs.goauthentik.io/developer-docs/api/
Gotcha: end_session does NOT revoke tokens — must explicit DELETE.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

logger = logging.getLogger(__name__)


class AuthentikError(Exception):
    """Raised when Authentik API call fails."""
    pass


class AuthentikClient:
    """Client for Authentik Admin API v3.

    - Stateless — no session caching
    - Used for admin operations (revocation, not auth)
    """

    def __init__(self, api_url: str, api_token: str):
        self.api_url = api_url.rstrip("/") if api_url else ""
        self.api_token = api_token

    def _api_request(
        self, method: str, path: str, body: Optional[Dict] = None
    ) -> Optional[Dict[str, Any]]:
        """Make authenticated request to Authentik Admin API."""
        if not self.api_url or not self.api_token:
            raise AuthentikError("Authentik client not configured")

        url = f"{self.api_url}{path}"
        data = json.dumps(body).encode("utf-8") if body else None
        req = Request(url, data=data, method=method)
        req.add_header("Authorization", f"Bearer {self.api_token}")
        req.add_header("Accept", "application/json")
        if data:
            req.add_header("Content-Type", "application/json")

        try:
            with urlopen(req, timeout=10) as resp:
                if resp.status == 204:
                    return None
                return json.loads(resp.read().decode("utf-8"))
        except HTTPError as e:
            raise AuthentikError(
                f"Authentik API {method} {path} returned {e.code}: {e.reason}"
            )
        except URLError as e:
            raise AuthentikError(f"Authentik API unreachable: {e.reason}")

    def _find_user_pk(self, username: str) -> Optional[int]:
        """Find Authentik user PK by username."""
        result = self._api_request("GET", f"/api/v3/core/users/?username={username}")
        users = result.get("results", []) if result else []
        if not users:
            return None
        return users[0]["pk"]

    def revoke_user_sessions(self, username: str) -> Dict[str, Any]:
        """Revoke all Authentik sessions for a user.

        - Finds user PK by username
        - Lists and deletes all AuthenticatedSession objects
        """
        try:
            pk = self._find_user_pk(username)
            if pk is None:
                return {"user_found": False, "sessions_revoked": 0}

            sessions = self._api_request(
                "GET", f"/api/v3/core/authenticated_sessions/?user={pk}"
            )
            session_list = sessions.get("results", []) if sessions else []

            for session in session_list:
                self._api_request(
                    "DELETE",
                    f"/api/v3/core/authenticated_sessions/{session['pk']}/",
                )

            logger.info(
                "Revoked %d Authentik sessions for user %s", len(session_list), username
            )
            return {"user_found": True, "sessions_revoked": len(session_list)}
        except AuthentikError:
            raise
        except Exception as e:
            raise AuthentikError(f"Failed to revoke sessions: {e}")

    def revoke_user_tokens(self, username: str) -> Dict[str, Any]:
        """Revoke all OAuth2 access tokens for a user.

        - Finds user PK by username
        - Lists and deletes all OAuth2 access tokens
        """
        try:
            pk = self._find_user_pk(username)
            if pk is None:
                return {"user_found": False, "tokens_revoked": 0}

            tokens = self._api_request(
                "GET", f"/api/v3/oauth2/access_tokens/?user={pk}"
            )
            token_list = tokens.get("results", []) if tokens else []

            for token in token_list:
                self._api_request(
                    "DELETE", f"/api/v3/oauth2/access_tokens/{token['pk']}/"
                )

            logger.info(
                "Revoked %d OAuth2 tokens for user %s", len(token_list), username
            )
            return {"user_found": True, "tokens_revoked": len(token_list)}
        except AuthentikError:
            raise
        except Exception as e:
            raise AuthentikError(f"Failed to revoke tokens: {e}")

    def terminate_user_access(self, username: str) -> Dict[str, Any]:
        """Full termination — revoke sessions + tokens.

        Called by the user termination endpoint.
        """
        sessions = self.revoke_user_sessions(username)
        tokens = self.revoke_user_tokens(username)
        return {
            "user_found": sessions["user_found"],
            "sessions_revoked": sessions["sessions_revoked"],
            "tokens_revoked": tokens["tokens_revoked"],
        }
```

**Step 4: Run test to verify it passes**

Run: `cd /home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack && python -m pytest tests/test_authentik_client.py -v`
Expected: All 6 tests PASS.

**Step 5: Commit**

```bash
git add src/backend/authentik_client.py tests/test_authentik_client.py
git commit -m "feat: add Authentik Admin API client for session/token revocation"
```

---

## Task 5: Backend — Wire Authentik Client into Termination Flow

**Files:**
- Modify: `src/backend/main.py:1417-1425` (replace placeholders)
- Modify: `src/backend/main.py` top-level (import + initialize AuthentikClient)

**Step 1: Import and initialize AuthentikClient in main.py**

Add imports:
```python
from authentik_client import AuthentikClient, AuthentikError
from config import AUTHENTIK_API_URL, AUTHENTIK_API_TOKEN
```

Add initialization after ORGDB:
```python
# Authentik client for session/token revocation (optional — graceful if not configured)
_authentik_client: Optional[AuthentikClient] = None
if AUTHENTIK_API_URL and AUTHENTIK_API_TOKEN:
    _authentik_client = AuthentikClient(
        api_url=AUTHENTIK_API_URL,
        api_token=AUTHENTIK_API_TOKEN,
    )
```

**Step 2: Replace termination placeholders**

Replace lines 1417-1425 in `main.py` with:
```python
    # 3. Revoke Authentik sessions + tokens
    if _authentik_client:
        try:
            authentik_result = _authentik_client.terminate_user_access(uid)
            actions["authentik_sessions"] = authentik_result["sessions_revoked"]
            actions["authentik_tokens"] = authentik_result["tokens_revoked"]
        except AuthentikError as e:
            actions["authentik_error"] = str(e)
    else:
        actions["authentik_sessions"] = "not_configured"
```

**Step 3: Run tests**

Run: `just test-quick 2>&1 | head -50`
Expected: All tests pass. `_authentik_client` is `None` in test env (no env vars).

**Step 4: Commit**

```bash
git add src/backend/main.py
git commit -m "feat: wire Authentik session revocation into user termination flow"
```

---

## Task 6: Frontend — Create OIDC PKCE Utility Module

**Files:**
- Create: `src/frontend/src/lib/oidc.ts`

**Step 1: Create the OIDC utility module**

Create `src/frontend/src/lib/oidc.ts`:
```typescript
/**
 * OIDC PKCE utilities for Authentik login flow.
 *
 * - Generates code verifier/challenge (RFC 7636, S256)
 * - Builds authorize URL from OIDC discovery
 * - Exchanges authorization code for tokens
 * - Fetches userinfo for claims
 * - Builds end-session (logout) URL
 *
 * Uses Web Crypto API (native, no deps). HTTPS required (localhost exempt).
 */

const OIDC_CLIENT_ID = import.meta.env.VITE_OIDC_CLIENT_ID || 'azblink-directory';
const OIDC_REDIRECT_URI =
  import.meta.env.VITE_OIDC_REDIRECT_URI || `${window.location.origin}/auth/callback`;
const OIDC_ISSUER = import.meta.env.VITE_OIDC_ISSUER || '';

/** Token response from Authentik token endpoint. */
export interface OidcTokenResponse {
  access_token: string;
  id_token?: string;
  token_type: string;
  expires_in: number;
  refresh_token?: string;
}

/** User info from Authentik userinfo endpoint. */
export interface OidcUserInfo {
  sub: string;
  preferred_username?: string;
  name?: string;
  email?: string;
  groups?: string[];
}

// --- PKCE helpers ---

/** Generate 32-byte random code verifier → base64url (43+ chars). */
function generateCodeVerifier(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return base64UrlEncode(array);
}

/** S256 code challenge from verifier via Web Crypto. */
async function generateCodeChallenge(verifier: string): Promise<string> {
  const data = new TextEncoder().encode(verifier);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return base64UrlEncode(new Uint8Array(digest));
}

/** Base64url encode (RFC 4648 §5). */
function base64UrlEncode(bytes: Uint8Array): string {
  const binary = String.fromCharCode(...bytes);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

// --- OIDC discovery ---

let _discoveryCache: Record<string, string> | null = null;

/** Fetch and cache OIDC discovery document. */
async function getDiscovery(): Promise<Record<string, string>> {
  if (_discoveryCache) return _discoveryCache;
  const issuer = OIDC_ISSUER.replace(/\/$/, '');
  const resp = await fetch(`${issuer}/.well-known/openid-configuration`);
  if (!resp.ok) throw new Error(`OIDC discovery failed: ${resp.status}`);
  _discoveryCache = await resp.json();
  return _discoveryCache!;
}

// --- Public API ---

/** Start OIDC login — stores PKCE verifier, redirects to Authentik. */
export async function startOidcLogin(redirectPath = '/'): Promise<void> {
  const verifier = generateCodeVerifier();
  const challenge = await generateCodeChallenge(verifier);

  sessionStorage.setItem('oidc_code_verifier', verifier);
  sessionStorage.setItem('oidc_redirect_path', redirectPath);

  const discovery = await getDiscovery();
  const authUrl = new URL(discovery.authorization_endpoint);
  authUrl.searchParams.set('client_id', OIDC_CLIENT_ID);
  authUrl.searchParams.set('response_type', 'code');
  authUrl.searchParams.set('redirect_uri', OIDC_REDIRECT_URI);
  authUrl.searchParams.set('scope', 'openid profile email');
  authUrl.searchParams.set('code_challenge', challenge);
  authUrl.searchParams.set('code_challenge_method', 'S256');

  window.location.href = authUrl.toString();
}

/** Exchange authorization code for tokens via PKCE. */
export async function exchangeCodeForTokens(code: string): Promise<OidcTokenResponse> {
  const verifier = sessionStorage.getItem('oidc_code_verifier');
  if (!verifier) throw new Error('Missing PKCE code verifier');

  const discovery = await getDiscovery();
  const resp = await fetch(discovery.token_endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'authorization_code',
      client_id: OIDC_CLIENT_ID,
      code,
      redirect_uri: OIDC_REDIRECT_URI,
      code_verifier: verifier,
    }),
  });

  if (!resp.ok) {
    const error = await resp.text();
    throw new Error(`Token exchange failed: ${resp.status} ${error}`);
  }

  // Clean up PKCE state
  sessionStorage.removeItem('oidc_code_verifier');

  return resp.json();
}

/** Fetch user info from OIDC userinfo endpoint. */
export async function fetchUserInfo(accessToken: string): Promise<OidcUserInfo> {
  const discovery = await getDiscovery();
  const resp = await fetch(discovery.userinfo_endpoint, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!resp.ok) throw new Error(`UserInfo fetch failed: ${resp.status}`);
  return resp.json();
}

/** Get stored redirect path (set before OIDC redirect). */
export function getStoredRedirectPath(): string {
  const path = sessionStorage.getItem('oidc_redirect_path') || '/';
  sessionStorage.removeItem('oidc_redirect_path');
  return path;
}

/** Build Authentik end-session (logout) URL. */
export async function getLogoutUrl(): Promise<string> {
  const discovery = await getDiscovery();
  const url = new URL(discovery.end_session_endpoint);
  url.searchParams.set('client_id', OIDC_CLIENT_ID);
  url.searchParams.set('post_logout_redirect_uri', window.location.origin + '/login');
  return url.toString();
}
```

**Step 2: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit src/lib/oidc.ts 2>&1 | head -20`
Expected: No type errors (may have module resolution warnings, which are OK — Vite handles path aliases).

**Step 3: Commit**

```bash
git add src/frontend/src/lib/oidc.ts
git commit -m "feat: add OIDC PKCE utility module for Authentik login flow"
```

---

## Task 7: Frontend — Rewrite Auth Store for OIDC

**Files:**
- Modify: `src/frontend/src/stores/auth-store.ts` (complete rewrite)

**Step 1: Rewrite auth-store.ts**

Replace `src/frontend/src/stores/auth-store.ts` entirely:
```typescript
/**
 * Auth state store — OIDC token management.
 *
 * - Stores Authentik OIDC access token + user info
 * - No local JWT generation — Authentik owns sessions
 * - Logout redirects to Authentik end-session endpoint
 * - localStorage persistence for tab survival
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { getLogoutUrl } from '@/lib/oidc';

/** User info derived from OIDC claims. */
export interface AuthUser {
  sub: string;
  uid: string;
  displayName: string;
  email: string;
  isAdmin: boolean;
  groups: string[];
}

interface AuthState {
  token: string | null;
  user: AuthUser | null;
  expiresAt: number | null;

  /** Store OIDC auth after successful callback. */
  setAuth: (token: string, user: AuthUser, expiresInSeconds: number) => void;
  /** Clear local state + redirect to Authentik end-session. */
  logout: () => Promise<void>;
  /** Check if token exists and is not expired. */
  isAuthenticated: () => boolean;
  /** Check if token existed but has expired. */
  isExpired: () => boolean;
}

const STORAGE_KEY = 'azblink-auth';

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      token: null,
      user: null,
      expiresAt: null,

      setAuth: (token, user, expiresInSeconds) => {
        set({
          token,
          user,
          expiresAt: Date.now() + expiresInSeconds * 1000,
        });
      },

      logout: async () => {
        set({ token: null, user: null, expiresAt: null });
        localStorage.removeItem(STORAGE_KEY);
        try {
          const logoutUrl = await getLogoutUrl();
          window.location.href = logoutUrl;
        } catch {
          window.location.href = '/login';
        }
      },

      isAuthenticated: () => {
        const { token, expiresAt } = get();
        if (!token || !expiresAt) return false;
        return Date.now() < expiresAt;
      },

      isExpired: () => {
        const { token, expiresAt } = get();
        if (!token) return false;
        if (!expiresAt) return true;
        return Date.now() >= expiresAt;
      },
    }),
    {
      name: STORAGE_KEY,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        token: state.token,
        user: state.user,
        expiresAt: state.expiresAt,
      }),
    }
  )
);
```

**Step 2: Check for compile errors**

Run: `cd src/frontend && npx tsc --noEmit 2>&1 | head -20`
Expected: May show errors in files that import old `login()` from auth store — those are fixed in subsequent tasks.

**Step 3: Commit**

```bash
git add src/frontend/src/stores/auth-store.ts
git commit -m "feat: rewrite auth store for OIDC token lifecycle

Replace JWT login() with OIDC setAuth(). Logout redirects to
Authentik end-session. localStorage only (no rememberMe toggle)."
```

---

## Task 8: Frontend — Create Auth Callback Route

**Files:**
- Create: `src/frontend/src/routes/auth/callback.tsx`
- Modify: `src/frontend/src/routes/__root.tsx` (add `/auth/callback` to public routes)

**Step 1: Create the callback route**

Create `src/frontend/src/routes/auth/callback.tsx`:
```typescript
/**
 * OIDC callback handler — exchanges authorization code for tokens.
 *
 * - Receives code from Authentik redirect
 * - Exchanges via PKCE for access token
 * - Fetches userinfo for display name, email, groups
 * - Stores auth state and redirects to original destination
 */

import { useEffect, useState } from 'react';
import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { exchangeCodeForTokens, fetchUserInfo, getStoredRedirectPath } from '@/lib/oidc';
import { useAuthStore } from '@/stores/auth-store';
import type { AuthUser } from '@/stores/auth-store';
import { Loader2 } from 'lucide-react';

export const Route = createFileRoute('/auth/callback')({
  component: AuthCallback,
});

function AuthCallback() {
  const [error, setError] = useState<string | null>(null);
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const errorParam = params.get('error');
    const errorDesc = params.get('error_description');

    if (errorParam) {
      setError(errorDesc || `Authentication failed: ${errorParam}`);
      return;
    }

    if (!code) {
      setError('Missing authorization code');
      return;
    }

    (async () => {
      try {
        const tokens = await exchangeCodeForTokens(code);
        const userInfo = await fetchUserInfo(tokens.access_token);
        const adminGroup = import.meta.env.VITE_OIDC_ADMIN_GROUP || 'IT-Admins';

        const user: AuthUser = {
          sub: userInfo.sub,
          uid: userInfo.preferred_username || userInfo.sub,
          displayName: userInfo.name || userInfo.preferred_username || userInfo.sub,
          email: userInfo.email || '',
          groups: userInfo.groups || [],
          isAdmin: (userInfo.groups || []).includes(adminGroup),
        };

        setAuth(tokens.access_token, user, tokens.expires_in);

        const redirectPath = getStoredRedirectPath();
        navigate({ to: redirectPath });
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Authentication failed');
      }
    })();
  }, [setAuth, navigate]);

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center max-w-md">
          <h1 className="text-xl font-semibold text-text mb-2">Authentication Error</h1>
          <p className="text-text-secondary mb-4">{error}</p>
          <a href="/login" className="text-primary hover:underline">
            Return to login
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
        <p className="text-text-secondary">Completing sign in...</p>
      </div>
    </div>
  );
}
```

**Step 2: Add `/auth/callback` to public routes in __root.tsx**

In `src/frontend/src/routes/__root.tsx` line 20:
```typescript
const PUBLIC_ROUTES = ['/login', '/auth/callback'];
```

**Step 3: Generate route tree**

Run: `just ui-routes`
Expected: Route tree regenerated with `/auth/callback` route.

**Step 4: Commit**

```bash
git add src/frontend/src/routes/auth/callback.tsx \
        src/frontend/src/routes/__root.tsx \
        src/frontend/src/routeTree.gen.ts
git commit -m "feat: add OIDC callback route for Authentik code exchange"
```

---

## Task 9: Frontend — Rewrite Login Page as SSO Redirect

**Files:**
- Modify: `src/frontend/src/routes/login.tsx` (complete rewrite)

**Step 1: Rewrite login.tsx**

Replace `src/frontend/src/routes/login.tsx`:
```typescript
/**
 * Login page — redirects to Authentik OIDC.
 *
 * No local credential form — Authentik handles authentication.
 * Shows a single "Sign in with Authentik" button.
 */

import { createFileRoute, useSearch } from '@tanstack/react-router';
import { useAuthStore } from '@/stores/auth-store';
import { startOidcLogin } from '@/lib/oidc';
import { Button, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@azblink/ui';
import { LogIn, Loader2 } from 'lucide-react';
import { useState } from 'react';

export const Route = createFileRoute('/login')({
  validateSearch: (search: Record<string, unknown>) => ({
    redirect: (search.redirect as string) || '/',
  }),
  component: LoginPage,
});

function LoginPage() {
  const [isRedirecting, setIsRedirecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { isAuthenticated } = useAuthStore();
  const { redirect } = useSearch({ from: '/login' });

  if (isAuthenticated()) {
    window.location.href = redirect || '/';
    return null;
  }

  const handleLogin = async () => {
    setIsRedirecting(true);
    setError(null);
    try {
      await startOidcLogin(redirect);
    } catch (err) {
      setIsRedirecting(false);
      setError(err instanceof Error ? err.message : 'Failed to start login');
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 rounded-xl bg-primary items-center justify-center mb-4">
            <span className="text-white font-bold text-xl">AZ</span>
          </div>
          <h1 className="text-2xl font-semibold text-text">AZBlink Directory</h1>
          <p className="text-text-secondary mt-1">Admin Portal</p>
        </div>

        <Card>
          <CardHeader className="space-y-1">
            <CardTitle className="text-xl">Sign in</CardTitle>
            <CardDescription>
              Sign in with your organization account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={handleLogin}
              className="w-full"
              disabled={isRedirecting}
            >
              {isRedirecting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Redirecting...
                </>
              ) : (
                <>
                  <LogIn className="mr-2 h-4 w-4" />
                  Sign in with Authentik
                </>
              )}
            </Button>

            {error && (
              <p className="text-sm text-error text-center">{error}</p>
            )}
          </CardContent>
        </Card>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Secured by Authentik SSO
        </p>
      </div>
    </div>
  );
}
```

**Step 2: Verify no remaining LDAP auth references in login.tsx**

The old login.tsx imported `useAuthStore().login()` which no longer exists. The new version uses `startOidcLogin()` from `@/lib/oidc` instead.

**Step 3: Commit**

```bash
git add src/frontend/src/routes/login.tsx
git commit -m "feat: replace LDAP credential form with Authentik SSO redirect"
```

---

## Task 10: Frontend — Update Session Expired Modal + main.tsx

**Files:**
- Modify: `src/frontend/src/components/features/session-expired-modal.tsx`
- Modify: `src/frontend/src/main.tsx`

**Step 1: Update session-expired-modal.tsx**

The modal's "Sign in again" button should redirect to Authentik instead of `/login`:

```typescript
import { startOidcLogin } from '@/lib/oidc';

// In the modal's action handler:
const handleLoginAgain = async () => {
  try {
    await startOidcLogin(window.location.pathname);
  } catch {
    window.location.href = '/login';
  }
};
```

**Step 2: Update main.tsx onUnauthorized handler**

In `src/frontend/src/main.tsx` lines 27-34:
```typescript
onUnauthorized: (hadToken: boolean) => {
  if (hadToken) {
    useUIStore.getState().showSessionExpiredModal();
  } else {
    const currentPath = encodeURIComponent(window.location.pathname);
    window.location.href = `/login?redirect=${currentPath}`;
  }
},
```

**Step 3: Search for remaining LDAP auth references in frontend**

Search for and remove:
- `auth/login` API endpoint references
- `LoginRequest` / `LoginResponse` TypeScript types
- `rememberMe` references (no longer needed)

**Step 4: Commit**

```bash
git add src/frontend/src/components/features/session-expired-modal.tsx \
        src/frontend/src/main.tsx
git commit -m "fix: update session expired modal and unauthorized handler for OIDC"
```

---

## Task 11: Config & Environment — OIDC Env Vars

**Files:**
- Modify: `deploy/dev/.env.example`
- Modify: `deploy/dev/docker-compose.yml`

**Step 1: Update .env.example**

Add to `deploy/dev/.env.example`:
```bash
# Authentik OIDC (required for admin UI login)
OIDC_ISSUER=https://authentik.example.com/application/o/azblink-directory/
OIDC_DISCOVERY_URL=
OIDC_CLIENT_ID=azblink-directory
OIDC_AUDIENCE=azblink-directory
OIDC_ADMIN_GROUP=IT-Admins
OIDC_GROUPS_CLAIM=groups

# Authentik Admin API (for user termination session revocation)
AUTHENTIK_API_URL=http://authentik-server:9000
AUTHENTIK_API_TOKEN=

# Frontend OIDC vars (build-time)
VITE_OIDC_ISSUER=https://authentik.example.com/application/o/azblink-directory/
VITE_OIDC_CLIENT_ID=azblink-directory
VITE_OIDC_REDIRECT_URI=http://localhost:8081/auth/callback
VITE_OIDC_ADMIN_GROUP=IT-Admins
```

Remove from `.env.example`:
```bash
# JWT_SECRET (removed — no LDAP JWT auth)
# REQUIRE_OIDC_AUTH (removed — always true)
# ALLOW_BOOTSTRAP_WITHOUT_OIDC (removed — no bootstrap bypass)
```

**Step 2: Update docker-compose.yml**

Pass new env vars to API and UI containers.

**Step 3: Commit**

```bash
git add deploy/dev/.env.example deploy/dev/docker-compose.yml
git commit -m "config: add Authentik OIDC env vars, remove JWT/breakglass config"
```

---

## Task 12: Documentation — Update CLAUDE.md and API Contracts

**Files:**
- Modify: `CLAUDE.md`
- Modify: `docs/api/FRONTEND_API_CONTRACTS.md`

**Step 1: Update CLAUDE.md**

- Remove `POST /api/auth/login` endpoint docs
- Remove breakglass documentation
- Remove `REQUIRE_OIDC_AUTH`, `ALLOW_BOOTSTRAP_WITHOUT_OIDC`, `JWT_SECRET` from env vars
- Remove "Authentication Testing" section (seed user login no longer applies)
- Add `AUTHENTIK_API_URL`, `AUTHENTIK_API_TOKEN`, `VITE_OIDC_*` to env vars
- Update "Break-glass" reference → removed
- Update architecture section for Authentik-only

**Step 2: Update frontend API contracts**

Remove `POST /api/auth/login` from `FRONTEND_API_CONTRACTS.md`. Note that auth is entirely via Authentik OIDC.

**Step 3: Commit**

```bash
git add CLAUDE.md docs/
git commit -m "docs: update for Authentik-only auth architecture"
```

---

## Task 13: Integration Verification

**Step 1: Run full test suite**

Run: `just test`
Expected: All tests pass.

**Step 2: Verify dev stack starts**

Run: `just up-bg && sleep 10 && just logs`
Expected: API starts without import errors. Login page renders. Without real Authentik, OIDC discovery will fail — expected.

**Step 3: Search for orphaned references**

```bash
grep -rn "REQUIRE_OIDC_AUTH" src/ tests/
grep -rn "ALLOW_BOOTSTRAP" src/ tests/
grep -rn "breakglass" src/ tests/
grep -rn "JWT_SECRET" src/ tests/
grep -rn "auth/login" src/ tests/
grep -rn "authenticate_user" src/ tests/
```
Expected: Zero matches in active code (design docs OK).

**Step 4: Verify TypeScript compiles**

Run: `cd src/frontend && npx tsc --noEmit`
Expected: No errors.

**Step 5: Final cleanup commit if needed**

```bash
git add -A
git commit -m "chore: final cleanup of LDAP JWT / breakglass remnants"
```

---

## Summary

| Task | Layer | What | Key Files |
|------|-------|------|-----------|
| 1 | Backend | Remove JWT auth module + login endpoint | `auth.py` (delete), `main.py` |
| 2 | Backend | Remove breakglass + simplify to OIDC-only | `main.py`, `config.py`, `directoryctl.py`, tests (delete) |
| 3 | Test | Rewrite `auth_headers` fixture for OIDC mock | `conftest.py` (~120+ tests unblocked) |
| 4 | Backend | Create Authentik admin API client | `authentik_client.py` (new), test (new) |
| 5 | Backend | Wire Authentik into termination flow | `main.py` |
| 6 | Frontend | Create OIDC PKCE utility module | `lib/oidc.ts` (new) |
| 7 | Frontend | Rewrite auth store for OIDC | `auth-store.ts` |
| 8 | Frontend | Create callback route + update public routes | `auth/callback.tsx` (new), `__root.tsx` |
| 9 | Frontend | Rewrite login page as SSO redirect | `login.tsx` |
| 10 | Frontend | Update session modal + main.tsx | `session-expired-modal.tsx`, `main.tsx` |
| 11 | Config | OIDC env vars | `.env.example`, `docker-compose.yml` |
| 12 | Docs | Update CLAUDE.md + API contracts | `CLAUDE.md`, API docs |
| 13 | Verify | Integration test + orphan reference audit | Full suite |

**Execution order matters:** Tasks 1-2 (remove old auth) → Task 3 (fix test fixture) → Tasks 4-5 (new backend) → Tasks 6-10 (new frontend) → Tasks 11-13 (config/docs/verify)

**Critical path:** Task 3 is the linchpin — all integration tests break without the fixture rewrite.
