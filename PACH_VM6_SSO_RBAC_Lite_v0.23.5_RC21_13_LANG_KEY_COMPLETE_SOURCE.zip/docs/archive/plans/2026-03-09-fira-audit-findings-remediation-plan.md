# FIRA Audit Findings Remediation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Resolve all 10 FIRA audit findings from the Epic #15 reconciliation audit.
**Architecture:** Surgical fixes — no refactors. Fix bugs, add missing config, add missing tests, document intentional deviations.
**Tech Stack:** Python/FastAPI, OpenLDAP, PostgreSQL, pytest
**Domains:** backend, devops, test

---

### Task 1: Fix FUNC-01 — OIDC sub → LDAP uid mapping in require_permission()
**domain:** backend
**depends_on:** []
**parallel_group:** 1
**complexity:** trivial

**Files:**
- Modify: `src/backend/main.py`

**Steps:**
1. At line 365-366, change:
   ```python
   # TODO: OIDC sub claim may not match LDAP uid — RBAC needs uid mapping
   uid = claims.get("uid") or claims.get("sub")
   ```
   To:
   ```python
   uid = claims.get("preferred_username") or claims.get("uid") or claims.get("sub")
   ```
2. Remove the TODO comment — this is now resolved
3. Verify: existing RBAC tests still pass (they use DEV_AUTH_TOKEN which provides both `uid` and `preferred_username`)

---

### Task 2: Fix TEST-01 — Rename duplicate test functions in test_export.py
**domain:** test
**depends_on:** []
**parallel_group:** 1
**complexity:** trivial

**Files:**
- Modify: `tests/test_export.py`

**Steps:**
1. Rename `TestUserExport` test methods to distinguish from `TestAuditExport`:
   - `test_csv_export_returns_csv` → `test_user_csv_export_returns_csv`
   - `test_json_export_returns_json` → `test_user_json_export_returns_json`
   - `test_export_requires_auth` → `test_user_export_requires_auth`
   - `test_invalid_format_rejected` → `test_user_invalid_format_rejected`
2. Run: `just test-quick -- tests/test_export.py -v` — expect 15 tests pass (was 11 due to 4 shadowed)

---

### Task 3: Fix TEST-02 — Renumber migration 019 collision
**domain:** database
**depends_on:** []
**parallel_group:** 1
**complexity:** trivial

**Files:**
- Rename: `migrations/019_admin_action_audit.sql` → `migrations/020_admin_action_audit.sql`

**Steps:**
1. Rename the file (Wave 2's admin_action_audit was created after Wave 1's suspension_events)
2. Check if any code references this migration by name — grep for `019_admin_action_audit`
3. Update any references found

---

### Task 4: Add CFG-01 — memberof/refint LDAP overlays
**domain:** devops
**depends_on:** []
**parallel_group:** 1
**complexity:** small

**Files:**
- Create: `deploy/dev/ldap/memberof-refint-config.ldif`
- Modify: `deploy/dev/docker-compose.yml`

**Steps:**
1. Create `deploy/dev/ldap/memberof-refint-config.ldif` with:
   - Module loads for memberof and refint
   - memberof overlay config (olcMemberOfGroupOC: groupOfNames, etc.)
   - refint overlay config (olcRefintAttribute: member, memberOf, etc.)
   - Follow same cn=config pattern as existing ppolicy-config.ldif
2. Add volume mount in docker-compose.yml openldap service:
   ```yaml
   - ./ldap/memberof-refint-config.ldif:/container/service/slapd/assets/config/bootstrap/ldif/memberof-refint-config.ldif:ro
   ```
3. Note: Requires `just reset && just up` to apply (LDAP overlays only load on first boot)

---

### Task 5: Add SEC-03 — Test for auditApiRequests enforcement
**domain:** test
**depends_on:** []
**parallel_group:** 2
**complexity:** small

**Files:**
- Modify: `tests/test_settings_enforcement.py`

**Steps:**
1. Add test that verifies RequestAuditMiddleware respects the toggle:
   - Make API call, check that audit logging occurs (or doesn't) based on setting
   - Note: This is integration-level — the middleware is already wired up correctly at `rate_limit.py:150-184`
2. Add test that verifies ipAllowlist bypass works:
   - Verify that allowlisted IP bypasses IP blocking
3. Run: `just test-quick -- tests/test_settings_enforcement.py -v`

---

### Task 6: Add FUNC-02 — Test for SSO template → QR payload integration
**domain:** test
**depends_on:** []
**parallel_group:** 2
**complexity:** small

**Files:**
- Modify: `tests/test_uc_validation.py` or create `tests/test_sso_qr_integration.py`

**Steps:**
1. Add test that creates a config template with SSO enabled, assigns it to an org
2. Create a user in that org
3. Generate QR code for the user
4. Verify the QR payload contains SSO fields (provider, issuerUrl, clientId)
5. Run test

---

### Task 7: Document SEC-02, SEC-04, ARCH-01, FUNC-03 — Intentional deviations and verified items
**domain:** backend
**depends_on:** [1, 2, 3, 4, 5, 6]
**parallel_group:** 3
**complexity:** trivial

**Files:**
- Modify: `src/backend/rate_limit.py` (docstring update for SEC-02)
- Modify: `src/backend/main.py` (inline comment for ARCH-01)

**Steps:**
1. SEC-02: Add inline comment in rate_limit.py docstring:
   ```python
   # NOTE: IP blocking uses PostgreSQL (not Redis) — intentional simplification.
   # Redis is used only for cache layer. PostgreSQL adds ~1-3ms vs Redis ~0.1ms.
   # Acceptable at current scale (<1000 concurrent users). See FIRA audit SEC-02.
   ```
2. SEC-04: No backend action — refresh token auto-refresh is frontend-only (oidc.ts). Document in session ledger as "verified: code exists, manual browser test recommended."
3. ARCH-01: Add comment at the single `require_admin` usage (line 3459):
   ```python
   # NOTE: require_admin intentionally retained here (not RBAC).
   # UC validation is a system-level operation — admin-only by design.
   # See FIRA audit ARCH-01.
   ```
4. FUNC-03: Content-Disposition headers are already tested at test_export.py lines 23, 39, 91, 109. Add a comment noting the audit finding was a false positive.

---

### Task 8: Run full test suite and verify
**domain:** test
**depends_on:** [1, 2, 3, 4, 5, 6, 7]
**parallel_group:** 4
**complexity:** trivial

**Steps:**
1. Run: `just test-quick`
2. Verify all tests pass
3. Check for any regressions from the changes
