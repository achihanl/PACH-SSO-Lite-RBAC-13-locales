# Archive

Historical documentation — preserved in git history, moved out of live spec paths.
**Do not treat as current. Do not update.** For the active architecture spec, see
`docs/architecture/`.

## Manifest

| Path | Was | Reason for archiving | Superseded by |
|------|-----|----------------------|---------------|
| `prd/PHASE1_UC_CORE_QR_PRD.md` | `docs/prd/` | QR subsystem removed PR #76/#77 | ARD-008 (QR subsystem removal) + `docs/architecture/spec/05-provisioning.md` |
| `prd/PHASE2_SSO_PROFILE_QR_PRD.md` | `docs/prd/` | SSO shipped (Authentik OIDC); QR surface deleted | ARD-002, ARD-004 + spec/04, spec/05 |
| `specs-v2.0/Directory_Portal_Specification_v4.1.md` | `specs/v2.0/` | Predates Authentik, single-LDAP, profile-services | `docs/architecture/spec/01..08-*.md` (version ≥2.0.0) |
| `specs-v2.0/Directory_Portal_OpenAPI_v4.2.yaml` | `specs/v2.0/` | Drifted vs live FastAPI routes | `docs/api/openapi.yaml` (live export) |
| `specs-v2.0/Directory_Portal_Schema_v4.2.sql` | `specs/v2.0/` | Drifted vs `migrations/004..025` | `migrations/` tree |
| `specs-v2.0/Directory_Portal_LDAP_Schema_v4.2.ldif` | `specs/v2.0/` | Drifted vs live LDAP schema | `deploy/dev/openldap-schema/` |
| `specs-v2.0/Directory_Portal_v4.1_Technical_Audit.md` | `specs/v2.0/` | Audit against deprecated spec | N/A (historical) |
| `specs-v2.0/V1_TO_V2_GAP_ANALYSIS.md` | `specs/v2.0/` | V1→V2 gaps closed by `docs/architecture/spec/` | `docs/architecture/spec/` |
| `specs-v2.0/APPENDIX_A..B` | `specs/v2.0/` | Appendices to archived spec | Historical |
| `plans/*` | `docs/plans/` | Plans archived — new plans go to `docs/architecture/proposals/` | `docs/architecture/proposals/` |

## Rule

`tools/arch_guard.py` unconditionally exempts `docs/archive/**` (test gap G8).
Nothing under this path should be edited.
