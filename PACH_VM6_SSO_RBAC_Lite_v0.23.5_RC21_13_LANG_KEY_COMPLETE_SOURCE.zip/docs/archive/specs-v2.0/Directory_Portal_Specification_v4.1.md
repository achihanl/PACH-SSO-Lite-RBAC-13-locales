# Azblink Directory Portal — Technical Specification v4.1

**Version:** 4.1 (Production-Ready)  
**Status:** Ready for implementation  
**Supersedes:** GitHub SPEC.md v2.0, Directory Portal Specification v3, v4.0

---

## Document Purpose

This specification is the **single source of truth** for building and deploying the Azblink Directory Portal — an LDAP-backed identity and provisioning system shipped as a pre-configured VM appliance. It merges:

- **Business context** (factory model, purchase flow, deployment lifecycle)
- **Security hardening** (QR signing, one-time tokens, rate limiting)
- **Operational procedures** (termination, suspension, break-glass recovery)

> **Critical Invariant:** Azblink UC (XMPP/SIP) **MUST** work even when Authentik is not installed and SSO is never configured. The system degrades gracefully — UC continues when SSO fails.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Business Model](#2-business-model)
3. [Security Requirements](#3-security-requirements)
4. [System Architecture](#4-system-architecture)
5. [QR Provisioning System](#5-qr-provisioning-system)
6. [User Lifecycle Management](#6-user-lifecycle-management)
7. [Deployment Lifecycle](#7-deployment-lifecycle)
8. [API Reference](#8-api-reference)
9. [Audit & Compliance](#9-audit--compliance)
10. [Break-Glass Recovery](#10-break-glass-recovery)
11. [Authentik Integration](#11-authentik-integration)
12. [Configuration Reference](#12-configuration-reference)
13. [Hardening Checklist](#13-hardening-checklist)
14. [Mobile Client Requirements](#14-mobile-client-requirements)
15. [Troubleshooting](#15-troubleshooting)
16. [Deployment Checklists](#16-deployment-checklists)

**Appendices:**
- [A. Database Schema](#appendix-a-database-schema)
- [B. Repository Layout](#appendix-b-repository-layout)
- [C. Docker Compose](#appendix-c-docker-compose)
- [D. CLI Reference](#appendix-d-cli-reference)
- [E. Glossary](#appendix-e-glossary)

---

## 1. Executive Summary

### 1.1 What This System Does

The Azblink Directory Portal provides:

1. **Identity Management** — LDAP-backed users, groups, and org hierarchy
2. **Device Provisioning** — QR code-based mobile/desktop configuration
3. **Optional SSO** — Authentik integration for web application single sign-on
4. **Administrative UI** — Web-based management for Day 0 setup through daily operations

### 1.2 System Overview

```mermaid
graph TB
    subgraph "End Users"
        Mobile["📱 Mobile App"]
        Desktop["💻 Desktop Client"]
        WebUser["🌐 Web Browser"]
    end

    subgraph "Directory Portal"
        Portal["Directory Portal<br/>(FastAPI + UI)"]
        QR["QR Provisioning<br/>Engine"]
    end

    subgraph "Identity Layer"
        LDAP["OpenLDAP<br/>(Users/Groups/Orgs)"]
        Authentik["Authentik<br/>(SSO/OIDC)"]
    end

    subgraph "UC Services"
        UC["UC Server"]
        XMPP["XMPP Server"]
        SIP["SIP Server"]
        VPN["VPN Server"]
    end

    subgraph "Data Stores"
        Postgres["PostgreSQL<br/>(Audit/Config)"]
        Redis["Redis<br/>(Rate Limit/Cache)"]
    end

    Mobile -->|"Scan QR"| QR
    Desktop -->|"Scan QR"| QR
    WebUser -->|"Admin UI"| Portal

    QR --> Portal
    Portal --> LDAP
    Portal --> Postgres
    Portal --> Redis
    Portal -.->|"Optional"| Authentik

    Mobile -->|"LDAP Auth"| UC
    Desktop -->|"LDAP Auth"| UC
    UC --> XMPP
    UC --> SIP
    UC --> VPN
    
    LDAP <-->|"Sync"| Authentik
    WebUser -->|"SSO Login"| Authentik

    style Authentik stroke-dasharray: 5 5
```

### 1.3 Deployment Scenarios

| Scenario | Components | QR Codes | User Experience |
|----------|------------|----------|-----------------|
| **UC-Only** (Simple) | LDAP + UC Server + Portal | Unified QR (UC config only) | One scan → VPN/SIP/XMPP working |
| **UC + SSO** (Advanced) | Above + Authentik | Unified QR (UC + SSO config) | One scan → UC + web app SSO |

### 1.4 Key Design Principles

```mermaid
mindmap
  root((Design<br/>Principles))
    UC Independence
      XMPP/SIP works without Authentik
      SSO failure ≠ UC failure
      Plane A always available
    Factory Entitlements
      Apps installed at factory
      Entitlements pre-seeded
      No runtime binary checks
    Cryptographic Provisioning
      HMAC-SHA256 signing
      One-time tokens
      Expiration enforced
    Immediate Termination
      User disabled → sessions killed
      LDAP + Authentik + UC coordinated
      Atomic revocation
    Graceful Degradation
      Authentik down → UC continues
      Redis down → degraded rate limiting
      Break-glass for recovery
```

---

## 2. Business Model

### 2.1 Purchase-to-Deployment Flow

The Directory Portal ships as part of a **pre-configured VM appliance**. The factory process ensures consistency between purchased licenses and installed software.

```mermaid
sequenceDiagram
    participant Customer
    participant Sales
    participant Factory
    participant Site as Customer Site

    Customer->>Sales: Purchase Order<br/>(VM + SafeNest + eHub)
    Sales->>Factory: Build Request
    
    rect rgb(240, 248, 255)
        Note over Factory: VM Build Process
        Factory->>Factory: Install Ubuntu OS
        Factory->>Factory: Install PostgreSQL + Redis
        Factory->>Factory: Install OpenLDAP + Authentik
        Factory->>Factory: Install Directory Portal
        Factory->>Factory: Install UC Server
        Factory->>Factory: Install SafeNest ✓
        Factory->>Factory: Install eHub ✓
        Factory->>Factory: Skip TeamPulse ✗
    end

    rect rgb(255, 248, 240)
        Note over Factory: Database Seeding
        Factory->>Factory: Pre-seed org_profiles<br/>entitlements: ["safenest", "ehub"]
    end

    Factory->>Site: Ship VM Image
    
    rect rgb(240, 255, 240)
        Note over Site: Deployment Phases
        Site->>Site: Day 0: Bootstrap LDAP
        Site->>Site: Day 1: Enable SSO
        Site->>Site: Practice: Go Live
    end
```

### 2.2 VM Appliance Architecture

```mermaid
block-beta
    columns 1
    
    block:layer3:1
        columns 3
        space
        L3["LAYER 3: OPTIONAL APPS<br/>(Factory-Installed Based on Purchase)"]
        space
    end
    
    block:apps:1
        columns 4
        SafeNest["SafeNest<br/>Property Mgmt<br/>✓ LICENSED"]
        eHub["eHub<br/>Building Auto<br/>✓ LICENSED"]
        TeamPulse["TeamPulse<br/>Team Collab<br/>✗ NOT HERE"]
        Future["Future Apps<br/><br/>"]
    end

    block:layer2:1
        columns 3
        space
        L2["LAYER 2: UC SERVICES<br/>(Always Installed, LDAP-Authenticated)"]
        space
    end

    block:uc:1
        columns 4
        VPN["VPN<br/>Server"]
        SIPSvc["SIP<br/>Server"]
        XMPPSvc["XMPP<br/>Server"]
        UCSvc["UC Server<br/>Orchestrator"]
    end

    block:layer1:1
        columns 3
        space
        L1["LAYER 1: INFRASTRUCTURE<br/>(Always Installed)"]
        space
    end

    block:infra:1
        columns 5
        PG["PostgreSQL<br/>Audit/Config"]
        LDAP2["OpenLDAP<br/>Users/Groups"]
        Redis2["Redis<br/>Rate Limit"]
        Auth["Authentik<br/>SSO/OIDC"]
        DP["Directory<br/>Portal"]
    end

    apps --> uc
    uc --> infra
    
    style SafeNest fill:#90EE90
    style eHub fill:#90EE90
    style TeamPulse fill:#FFB6C1
```

### 2.3 Entitlements Trust Model

```mermaid
flowchart LR
    subgraph Factory["Factory Process (Atomic)"]
        PO["Purchase Order<br/>SafeNest: YES<br/>eHub: YES<br/>TeamPulse: NO"]
        Build["VM Build<br/>Install SafeNest ✓<br/>Install eHub ✓<br/>Skip TeamPulse"]
        Seed["Database Seed<br/>entitlements:<br/>[safenest, ehub]"]
        
        PO --> Build --> Seed
    end

    subgraph Invariant["Trust Invariant"]
        Rule1["If 'safenest' ∈ entitlements<br/>→ SafeNest binary EXISTS"]
        Rule2["If SafeNest binary EXISTS<br/>→ 'safenest' ∈ entitlements"]
    end

    subgraph Portal["Directory Portal"]
        Trust["TRUSTS entitlements[]<br/>NO runtime binary checks<br/>NO 'is app installed?' calls"]
    end

    Factory --> Invariant
    Invariant --> Portal

    style Factory fill:#E6F3FF
    style Invariant fill:#FFF9E6
    style Portal fill:#E6FFE6
```

---

## 3. Security Requirements

> **These are NON-NEGOTIABLE for production deployment.**

### 3.1 Security Architecture Overview

```mermaid
flowchart TB
    subgraph Security["Security Controls"]
        direction TB
        Sign["QR Payload Signing<br/>HMAC-SHA256"]
        OneTime["One-Time Token<br/>Enforcement"]
        Rate["Rate Limiting<br/>Redis-backed"]
    end

    subgraph Threats["Threat Mitigation"]
        T1["Forged QR Codes"]
        T2["Token Replay/Sharing"]
        T3["Brute Force/DoS"]
    end

    Sign -->|"Prevents"| T1
    OneTime -->|"Prevents"| T2
    Rate -->|"Prevents"| T3

    style Sign fill:#90EE90
    style OneTime fill:#90EE90
    style Rate fill:#90EE90
    style T1 fill:#FFB6C1
    style T2 fill:#FFB6C1
    style T3 fill:#FFB6C1
```

### 3.2 QR Payload Signing (Mandatory)

All QR payloads **MUST** be cryptographically signed using HMAC-SHA256.

```mermaid
sequenceDiagram
    participant Admin
    participant Portal as Directory Portal
    participant Client as Mobile Client

    Admin->>Portal: Request QR for user "alice"
    
    rect rgb(240, 255, 240)
        Note over Portal: Signing Process
        Portal->>Portal: Build payload {uc, sso}
        Portal->>Portal: Add iat, exp, nonce
        Portal->>Portal: Compute HMAC-SHA256
        Portal->>Portal: Attach signature
    end

    Portal->>Admin: Signed QR Code

    Admin->>Client: Display QR (print/screen)
    Client->>Client: Scan QR

    rect rgb(255, 248, 240)
        Note over Client: Verification Process
        Client->>Client: Parse JSON payload
        Client->>Client: Extract signature
        Client->>Client: Recompute HMAC
        Client->>Client: Compare signatures
        
        alt Signatures Match
            Client->>Client: Check exp > now
            alt Not Expired
                Client->>Client: ✓ Accept payload
            else Expired
                Client->>Client: ✗ Reject: TOKEN_EXPIRED
            end
        else Signatures Don't Match
            Client->>Client: ✗ Reject: INVALID_SIGNATURE
        end
    end
```

**Signed Payload Structure:**

```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": { /* UC configuration: tenant, xmpp, sip, credentials */ },
    "sso": { /* SSO configuration or null */ }
  },
  "iat": 1704067200,
  "exp": 1704070800,
  "nonce": "unique-one-time-value",
  "sig": "hex-encoded-hmac-sha256-signature"
}
```

**Signing Implementation:**

```python
import hmac
import hashlib
import json
import time
import secrets

def sign_qr_payload(payload: dict, secret: str, ttl_sec: int = 3600) -> dict:
    """Sign a QR payload with HMAC-SHA256."""
    now = int(time.time())
    wrapper = {
        "schema": "azblink.provisioning.v2",
        "payload": payload,
        "iat": now,
        "exp": now + ttl_sec,
        "nonce": secrets.token_urlsafe(16)
    }
    message = json.dumps(wrapper, sort_keys=True, separators=(',', ':'))
    sig = hmac.new(secret.encode(), message.encode(), hashlib.sha256).hexdigest()
    wrapper["sig"] = sig
    return wrapper

def verify_qr_payload(signed_payload: dict, secret: str) -> tuple[bool, str, dict]:
    """Verify a signed QR payload. Returns (valid, error_message, payload)."""
    sig = signed_payload.pop("sig", None)
    if not sig:
        return False, "missing signature", {}

    message = json.dumps(signed_payload, sort_keys=True, separators=(',', ':'))
    expected = hmac.new(secret.encode(), message.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(sig, expected):
        return False, "invalid signature", {}

    now = int(time.time())
    if signed_payload.get("exp", 0) < now:
        return False, "payload expired", {}

    return True, "", signed_payload.get("payload", {})
```

### 3.3 One-Time Token Enforcement (Mandatory)

QR provisioning tokens are **single-use**. This prevents credential sharing and replay attacks.

```mermaid
flowchart TD
    Start([Client Sends Token]) --> Hash["Hash token (SHA-256)"]
    Hash --> Query["SELECT * FROM qr_issuance_audit<br/>WHERE token_hash = :hash"]
    Query --> CheckConsumed{consumed = true?}
    
    CheckConsumed -->|Yes| Reject1["✗ REJECT<br/>TOKEN_ALREADY_CONSUMED"]
    CheckConsumed -->|No| CheckExp{exp < now?}
    
    CheckExp -->|Yes| Reject2["✗ REJECT<br/>TOKEN_EXPIRED"]
    CheckExp -->|No| Update["UPDATE consumed = true<br/>consumed_at = NOW()"]
    
    Update --> Accept["✓ ACCEPT<br/>Return credentials"]

    style Reject1 fill:#FFB6C1
    style Reject2 fill:#FFB6C1
    style Accept fill:#90EE90
```

**Attack Prevention:**

```mermaid
graph LR
    subgraph Without["Without One-Time Enforcement"]
        A1["User shares QR"] --> A2["Multiple devices provision ✗"]
        A3["QR leaked online"] --> A4["Mass compromise ✗"]
        A5["Token intercepted"] --> A6["Replay attack ✗"]
    end

    subgraph With["With One-Time Enforcement"]
        B1["User shares QR"] --> B2["Second scan rejected ✓"]
        B3["QR leaked online"] --> B4["Only first scan works ✓"]
        B5["Token intercepted"] --> B6["Already consumed ✓"]
    end

    style A2 fill:#FFB6C1
    style A4 fill:#FFB6C1
    style A6 fill:#FFB6C1
    style B2 fill:#90EE90
    style B4 fill:#90EE90
    style B6 fill:#90EE90
```

### 3.4 Rate Limiting (Mandatory)

All public-facing endpoints **MUST** be rate-limited.

```mermaid
graph TB
    subgraph Endpoints["Endpoint Categories"]
        E1["/api/bootstrap"]
        E2["/api/users/create"]
        E3["/api/users/*/qrcode*"]
        E4["Auth Failures"]
        E5["All Other Endpoints"]
    end

    subgraph Limits["Rate Limits"]
        L1["5 / hour"]
        L2["20 / minute"]
        L3["10 / minute"]
        L4["5 / 5min + soft-lock"]
        L5["100 / minute"]
    end

    subgraph Actions["On Exceed"]
        A1["429 + 1hr block"]
        A2["429"]
        A3["429"]
        A4["429 + account lock"]
        A5["429"]
    end

    E1 --> L1 --> A1
    E2 --> L2 --> A2
    E3 --> L3 --> A3
    E4 --> L4 --> A4
    E5 --> L5 --> A5
```

**Implementation:** Use Redis-backed sliding window or nginx `limit_req_zone`.

---

## 4. System Architecture

### 4.1 Dual Authentication Planes

The system maintains **two independent authentication planes** to ensure UC services survive SSO failures.

```mermaid
flowchart TB
    LDAP[("OpenLDAP<br/>(User Store)")]

    subgraph PlaneA["PLANE A: UC Authentication<br/>(Always Available)"]
        direction TB
        A_Used["Used by:<br/>ucChat, XMPP, SIP, VPN"]
        A_Method["Auth: Direct LDAP bind"]
        A_Survives["Survives:<br/>✓ Authentik outage<br/>✓ OIDC misconfiguration<br/>✓ Network partition"]
    end

    subgraph PlaneB["PLANE B: App/Web SSO<br/>(Optional)"]
        direction TB
        B_Used["Used by:<br/>SafeNest, eHub, TeamPulse<br/>Admin portals"]
        B_Method["Auth: Authentik OIDC/SAML"]
        B_Requires["Requires:<br/>• Authentik running<br/>• Valid OIDC config"]
    end

    LDAP --> PlaneA
    LDAP --> Authentik["Authentik<br/>(IdP)"]
    Authentik --> PlaneB

    subgraph Services_A["Plane A Services"]
        VPN2["VPN"]
        SIP2["SIP"]
        XMPP2["XMPP"]
    end

    subgraph Services_B["Plane B Services"]
        SafeNest2["SafeNest"]
        eHub2["eHub"]
        TeamPulse2["TeamPulse"]
    end

    PlaneA --> Services_A
    PlaneB --> Services_B

    style PlaneA fill:#90EE90
    style PlaneB fill:#FFE4B5
    style Authentik stroke-dasharray: 5 5
```

### 4.2 Failure Mode Analysis

```mermaid
graph TB
    subgraph Failures["Component Failures"]
        F1["OpenLDAP Down"]
        F2["Authentik Down"]
        F3["Redis Down"]
        F4["UC Server Down"]
    end

    subgraph PlaneA_Impact["Plane A (UC)"]
        A1["✗ DOWN"]
        A2["✓ OK"]
        A3["✓ OK (degraded)"]
        A4["✗ DOWN"]
    end

    subgraph PlaneB_Impact["Plane B (SSO)"]
        B1["✗ DOWN"]
        B2["✗ DOWN"]
        B3["✓ OK (degraded)"]
        B4["✓ OK"]
    end

    subgraph User_Impact["User Impact"]
        U1["Total system failure"]
        U2["UC works, web apps unavailable"]
        U3["Rate limiting degraded"]
        U4["UC unavailable, web apps work"]
    end

    F1 --> A1 & B1 --> U1
    F2 --> A2 & B2 --> U2
    F3 --> A3 & B3 --> U3
    F4 --> A4 & B4 --> U4

    style A1 fill:#FFB6C1
    style A2 fill:#90EE90
    style A3 fill:#FFFACD
    style A4 fill:#FFB6C1
    style B1 fill:#FFB6C1
    style B2 fill:#FFB6C1
    style B3 fill:#FFFACD
    style B4 fill:#90EE90
```

### 4.3 Component Topology

```mermaid
flowchart TB
    subgraph Frontend["Frontend Layer"]
        Index["index.html<br/>(Nav Hub)"]
        DirMgr["directory_manager.html<br/>(Day 0 Admin)"]
        ProvMgr["provision_manager.html<br/>(Day 1 Admin)"]
        DirBrowse["directory.html<br/>(Browse)"]
        Profile["my_profile.html<br/>(Self-Service)"]
    end

    subgraph API["API Layer (FastAPI)"]
        Main["main.py<br/>(Routes)"]
        
        subgraph Modules["Backend Modules"]
            Config["config.py"]
            LdapClient["ldap_client.py"]
            OrgDB["orgdb.py"]
            QRSign["qr_signing.py"]
            OIDC["oidc_verify.py"]
            RateLimit["rate_limit.py"]
            Term["termination.py"]
        end
    end

    subgraph Data["Data Layer"]
        LDAP3[("OpenLDAP<br/>:389")]
        PG[("PostgreSQL<br/>:5432")]
        Auth2[("Authentik<br/>:9000")]
        Redis3[("Redis<br/>:6379")]
        UC2[("UC Server<br/>:5280")]
    end

    Frontend -->|"fetch() /api/*"| Main
    Main --> Modules
    
    LdapClient --> LDAP3
    OrgDB --> PG
    OIDC --> Auth2
    RateLimit --> Redis3
    Term --> UC2
```

### 4.4 Data Ownership

```mermaid
graph TB
    subgraph OpenLDAP["OpenLDAP Owns"]
        L1["Users"]
        L2["Groups"]
        L3["Org Tree"]
        L4["Passwords"]
        L5["Account Status"]
    end

    subgraph PostgreSQL["PostgreSQL Owns"]
        P1["OrgProfiles"]
        P2["SSO Config"]
        P3["QR Audit"]
        P4["Termination Events"]
    end

    subgraph Authentik["Authentik Owns"]
        A1["OIDC/SAML Apps"]
        A2["Active Sessions"]
        A3["MFA Enrollment"]
        A4["Token Blacklist"]
    end

    subgraph Redis["Redis Owns"]
        R1["Rate Limit Counters"]
        R2["Break-Glass Cache"]
        R3["Session References"]
    end

    style OpenLDAP fill:#E6F3FF
    style PostgreSQL fill:#E6FFE6
    style Authentik fill:#FFF9E6
    style Redis fill:#FFE6E6
```

---

## 5. QR Provisioning System

### 5.1 Unified QR Model (Recommended)

A single QR code containing all provisioning data. The SSO block is `null` when SSO is not enabled.

```mermaid
graph LR
    subgraph UC_Only["UC-Only Deployment"]
        QR1["Unified QR"]
        UC1["uc: {xmpp, sip, credentials}"]
        SSO1["sso: null"]
        QR1 --> UC1 & SSO1
    end

    subgraph UC_SSO["UC + SSO Deployment"]
        QR2["Unified QR"]
        UC2["uc: {xmpp, sip, credentials}"]
        SSO2["sso: {issuer, clientId, scopes}"]
        QR2 --> UC2 & SSO2
    end

    style SSO1 fill:#E0E0E0
    style SSO2 fill:#90EE90
```

**UC-ONLY Payload (sso: null):**
```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": {
      "tenant": "example",
      "xmpp": { "domain": "uc.example.com", "wsUrl": "wss://uc.example.com/ws" },
      "sip": { "domain": "sip.example.com", "wssUrl": "wss://sip.example.com/ws" },
      "credentials": { "username": "alice", "token": "one-time-token" }
    },
    "sso": null
  },
  "iat": 1704067200, "exp": 1704070800, "nonce": "abc123", "sig": "..."
}
```

**UC + SSO Payload:**
```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": { /* same as above */ },
    "sso": {
      "issuer": "https://auth.example.com/application/o/mobile/",
      "clientId": "azblink-mobile",
      "scopes": ["openid", "profile", "email"],
      "pkceRequired": true
    }
  },
  "iat": 1704067200, "exp": 1704070800, "nonce": "abc123", "sig": "..."
}
```

### 5.2 QR Availability Decision Logic

```mermaid
flowchart TD
    Start([GET /api/users/[uid]/qrcode]) --> FetchUser["Fetch user from LDAP"]
    FetchUser --> FetchOrg["Fetch OrgProfile from PostgreSQL"]
    FetchOrg --> BuildUC["Build UC block<br/>(ALWAYS included)"]
    
    BuildUC --> CheckEntitlements{entitlements<br/>non-empty?}
    
    CheckEntitlements -->|No| SSONull1["sso = null"]
    CheckEntitlements -->|Yes| CheckEnabled{ssoProfile.enabled<br/>= true?}
    
    CheckEnabled -->|No| SSONull2["sso = null"]
    CheckEnabled -->|Yes| CheckIssuer{ssoProfile.issuer<br/>configured?}
    
    CheckIssuer -->|No| SSONull3["sso = null"]
    CheckIssuer -->|Yes| BuildSSO["Build SSO block"]
    
    SSONull1 & SSONull2 & SSONull3 --> Combine1["payload = {uc, sso: null}"]
    BuildSSO --> Combine2["payload = {uc, sso: {...}}"]
    
    Combine1 & Combine2 --> Sign["Sign payload (HMAC-SHA256)"]
    Sign --> Return([Return QR Code])

    style BuildUC fill:#90EE90
    style SSONull1 fill:#E0E0E0
    style SSONull2 fill:#E0E0E0
    style SSONull3 fill:#E0E0E0
    style BuildSSO fill:#90EE90
```

### 5.3 Legacy Split QR Model (Backward Compatibility)

```mermaid
graph TB
    subgraph Unified["Unified QR (Recommended)"]
        U1["Single QR"]
        U2["Contains: UC + SSO"]
        U3["One scan, full provisioning"]
        U1 --> U2 --> U3
    end

    subgraph Split["Split QR (Legacy)"]
        S1["QR#1: UC Core"]
        S2["QR#2: SSO Profile"]
        S3["Two scans required"]
        S1 & S2 --> S3
    end

    style Unified fill:#90EE90
    style Split fill:#FFFACD
```

### 5.4 QR Provisioning Flow

```mermaid
sequenceDiagram
    participant Admin
    participant Portal as Directory Portal
    participant LDAP as OpenLDAP
    participant DB as PostgreSQL
    participant Client as Mobile App

    Admin->>Portal: GET /api/users/alice/qrcode
    Portal->>LDAP: Fetch user "alice"
    LDAP-->>Portal: User details
    Portal->>DB: Fetch OrgProfile for user's org
    DB-->>Portal: OrgProfile (entitlements, ssoProfile)

    rect rgb(240, 255, 240)
        Note over Portal: Build Payload
        Portal->>Portal: Build UC block (always)
        Portal->>Portal: Check SSO conditions
        alt SSO Enabled
            Portal->>Portal: Build SSO block
        else SSO Disabled
            Portal->>Portal: sso = null
        end
        Portal->>Portal: Sign with HMAC-SHA256
    end

    Portal->>DB: Log QR issuance (audit)
    Portal-->>Admin: Signed QR Code

    Admin->>Client: Display QR

    rect rgb(255, 248, 240)
        Note over Client: Consume QR
        Client->>Client: Scan & parse QR
        Client->>Client: Verify signature
        Client->>Client: Check expiration
        Client->>Portal: Exchange token for credentials
        Portal->>DB: Check token not consumed
        Portal->>DB: Mark token consumed
        Portal-->>Client: Session credentials
        Client->>Client: Store in Keychain/Keystore
        alt SSO block present
            Client->>Client: Initiate PKCE flow
        end
    end

    Client->>Client: ✓ Provisioning Complete
```

---

## 6. User Lifecycle Management

### 6.1 User Lifecycle States

```mermaid
stateDiagram-v2
    [*] --> Created: Admin creates user
    Created --> Active: QR provisioned
    Active --> Suspended: Admin suspends
    Suspended --> Active: Admin unsuspends
    Active --> Terminated: Admin terminates
    Suspended --> Terminated: Admin terminates
    Terminated --> [*]

    note right of Active
        User can:
        - Login to UC
        - Access SSO apps
        - Request new QR
    end note

    note right of Suspended
        User cannot:
        - Login (LDAP disabled)
        Preserves:
        - Tokens (unusable)
        - Associations
        - Audit history
    end note

    note right of Terminated
        Immediately:
        - LDAP disabled
        - Tokens revoked
        - Sessions killed
        - Audit logged
    end note
```

### 6.2 Termination Flow (Critical)

When a user must be **immediately terminated**, all access must be revoked atomically.

```mermaid
sequenceDiagram
    participant Admin
    participant Portal as Directory Portal
    participant LDAP as OpenLDAP
    participant DB as PostgreSQL
    participant Auth as Authentik
    participant UC as UC Server

    Admin->>Portal: POST /api/users/alice/terminate<br/>{reason: "employment_ended"}

    rect rgb(255, 240, 240)
        Note over Portal: Atomic Termination Sequence
        
        Portal->>LDAP: 1. Disable account
        LDAP-->>Portal: ✓ Account disabled
        Note right of LDAP: Blocks all new<br/>LDAP binds

        Portal->>DB: 2. Invalidate all tokens
        DB-->>Portal: ✓ 3 tokens revoked
        Note right of DB: Prevents QR reuse

        Portal->>Auth: 3. Revoke Authentik sessions
        Auth-->>Portal: ✓ 2 sessions revoked
        Note right of Auth: Kills SSO sessions

        Portal->>UC: 4. Terminate UC sessions
        UC-->>Portal: ✓ 1 session terminated
        Note right of UC: Kills XMPP/SIP

        Portal->>DB: 5. Log termination event
        DB-->>Portal: ✓ Audit logged
    end

    Portal-->>Admin: {status: "terminated",<br/>actions: {ldap: ✓, tokens: 3,<br/>authentik: 2, uc: 1}}
```

### 6.3 Termination Actions Detail

```mermaid
flowchart TB
    subgraph Step1["1. Disable LDAP Account"]
        L1["ldap_client.modify(user_dn,<br/>{userAccountControl: DISABLED})"]
        L2["Effect: Blocks all new LDAP binds"]
        L1 --> L2
    end

    subgraph Step2["2. Invalidate Tokens"]
        T1["UPDATE qr_issuance_audit<br/>SET consumed = true,<br/>consumed_reason = 'user_terminated'<br/>WHERE user_uid = :uid"]
        T2["Effect: Prevents QR reuse"]
        T1 --> T2
    end

    subgraph Step3["3. Revoke Authentik"]
        A1["DELETE /api/v3/core/tokens/<br/>?user__username=[uid]"]
        A2["DELETE /api/v3/core/<br/>authenticated_sessions/..."]
        A3["Effect: Kills SSO sessions"]
        A1 --> A2 --> A3
    end

    subgraph Step4["4. Terminate UC"]
        U1["POST /api/admin/sessions/terminate<br/>{username: uid}"]
        U2["Effect: Kills XMPP/SIP"]
        U1 --> U2
    end

    subgraph Step5["5. Audit Log"]
        AU1["INSERT INTO termination_events<br/>(user_uid, terminated_by,<br/>reason, actions_taken)"]
        AU2["Effect: Compliance trail"]
        AU1 --> AU2
    end

    Step1 --> Step2 --> Step3 --> Step4 --> Step5
```

---

## 7. Deployment Lifecycle

### 7.1 Phase Overview

```mermaid
timeline
    title Deployment Lifecycle
    
    section Day 0
        Fresh Install : Start services
                      : Bootstrap LDAP
                      : Create org tree
                      : Create users
                      : Issue QR codes
        Exit Criteria : ✓ UC operational
                      : ✗ No SSO yet
    
    section Day 1
        SSO Setup : Configure Authentik
                  : Set OrgProfile
                  : Enable SSO
                  : Test SSO flow
                  : Harden config
        Exit Criteria : ✓ SSO working
                      : ✓ Config hardened
    
    section Practice
        Daily Ops : Directory browsing
                  : User self-service
                  : Admin CRUD
                  : Terminations
                  : Incident recovery
        Steady State : ✓ All systems nominal
                     : ✓ Monitoring active
```

### 7.2 Day 0: Fresh Installation

```mermaid
sequenceDiagram
    participant Admin
    participant Portal as Directory Portal
    participant LDAP as OpenLDAP
    participant DB as PostgreSQL

    Note over Admin,DB: Configuration: REQUIRE_OIDC_AUTH=false, ALLOW_BOOTSTRAP_WITHOUT_OIDC=true

    Admin->>Portal: 1. Start services
    Portal->>LDAP: Verify connectivity
    Portal->>DB: Verify connectivity

    Admin->>Portal: 2. POST /api/bootstrap<br/>{tenant: "example"}
    Portal->>LDAP: Create ou=org
    Portal->>LDAP: Create ou=people
    Portal->>LDAP: Create ou=groups
    Portal-->>Admin: ✓ Base OUs created

    Admin->>Portal: 3. POST /api/org/create<br/>{name: "Engineering"}
    Portal->>LDAP: Create ou=Engineering,ou=org
    Portal-->>Admin: ✓ Org created

    Admin->>Portal: 4. POST /api/groups/create<br/>{cn: "IT-Admins"}
    Portal->>LDAP: Create cn=IT-Admins,ou=groups
    Portal-->>Admin: ✓ Group created

    Admin->>Portal: 5. POST /api/users/create<br/>{uid: "alice", ...}
    Portal->>LDAP: Create uid=alice,ou=people
    Portal-->>Admin: ✓ User created

    Admin->>Portal: 6. GET /api/users/alice/qrcode
    Portal-->>Admin: QR Code (UC only, sso: null)

    Note over Admin,DB: Day 0 Complete: UC operational, No SSO
```

### 7.3 Day 1: SSO Enablement

```mermaid
sequenceDiagram
    participant Admin
    participant Auth as Authentik
    participant Portal as Directory Portal
    participant DB as PostgreSQL

    Note over Admin,DB: Configuration: REQUIRE_OIDC_AUTH=true

    Admin->>Auth: 1. Configure Authentik
    Note right of Auth: • Add LDAP source<br/>• Create OIDC Provider<br/>• Create Applications

    Admin->>Portal: 2. Login via Authentik SSO
    Portal->>Auth: OIDC authentication
    Auth-->>Portal: JWT token
    Portal-->>Admin: ✓ Authenticated

    Admin->>Portal: 3. POST /api/orgprofiles<br/>{ssoProfile: {enabled: true, oidc: {...}}}
    Portal->>DB: Insert OrgProfile
    Portal-->>Admin: ✓ OrgProfile created

    Admin->>Portal: 4. GET /api/users/alice/qrcode
    Portal->>DB: Fetch OrgProfile
    Portal-->>Admin: QR Code (UC + SSO)

    Admin->>Admin: 5. Set ALLOW_BOOTSTRAP_WITHOUT_OIDC=false
    Admin->>Portal: Restart backend

    Note over Admin,DB: Day 1 Complete: SSO operational, Config hardened
```

### 7.4 Deployment Path Comparison

```mermaid
flowchart TB
    subgraph PathA["Path A: UC-Only (No Authentik)"]
        A1["Deploy LDAP + Postgres + Redis"]
        A2["REQUIRE_OIDC_AUTH=false"]
        A3["Bootstrap LDAP"]
        A4["Create users"]
        A5["Issue QR (UC only)"]
        A6["UC operational ✓"]
        
        A1 --> A2 --> A3 --> A4 --> A5 --> A6
    end

    subgraph PathB["Path B: UC + SSO (With Authentik)"]
        B1["Deploy full stack + Authentik"]
        B2["REQUIRE_OIDC_AUTH=true"]
        B3["Bootstrap LDAP"]
        B4["Configure Authentik"]
        B5["Create OrgProfile with SSO"]
        B6["Issue QR (UC + SSO)"]
        B7["Harden config"]
        B8["Full system operational ✓"]
        
        B1 --> B2 --> B3 --> B4 --> B5 --> B6 --> B7 --> B8
    end

    style A6 fill:#90EE90
    style B8 fill:#90EE90
```

---

## 8. API Reference

### 8.1 API Architecture

```mermaid
graph TB
    subgraph Public["Public Endpoints (No Auth*)"]
        E1["GET /api/tenant"]
        E2["POST /api/bootstrap"]
        E3["GET /api/health"]
    end

    subgraph Authenticated["Authenticated Endpoints"]
        E4["GET /api/org/tree"]
        E5["GET /api/users"]
        E6["GET /api/users/[uid]/qrcode"]
        E7["GET /api/orgprofiles"]
    end

    subgraph Admin["Admin-Only Endpoints"]
        E8["POST /api/users/create"]
        E9["POST /api/users/[uid]/terminate"]
        E10["POST /api/orgprofiles"]
        E11["GET /api/audit/*"]
    end

    Note1["* Exempt when<br/>ALLOW_BOOTSTRAP_WITHOUT_OIDC=true"]

    style Public fill:#E6FFE6
    style Authenticated fill:#FFF9E6
    style Admin fill:#FFE6E6
```

### 8.2 Core Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/bootstrap` | No* | Initialize base OUs |
| GET | `/api/tenant` | No* | Get tenant info |
| GET | `/api/health` | No | Basic health check |
| GET | `/api/health/deep` | Yes | Deep health check |
| GET | `/api/org/tree` | Yes | Get org hierarchy |
| POST | `/api/org/create` | Admin | Create organization |
| GET | `/api/users` | Yes | List users |
| POST | `/api/users/create` | Admin | Create user |
| POST | `/api/users/[uid]/terminate` | Admin | **Terminate user** |
| POST | `/api/users/[uid]/suspend` | Admin | Suspend user |
| GET | `/api/users/[uid]/qrcode` | Yes | **Unified QR** |
| POST | `/api/orgprofiles` | Admin | Create OrgProfile |
| GET | `/api/audit/qr_issuance` | Admin | QR audit log |

*Exempt when `ALLOW_BOOTSTRAP_WITHOUT_OIDC=true`

### 8.3 API Request Flow

```mermaid
sequenceDiagram
    participant Client
    participant Nginx as Nginx (Rate Limit)
    participant Portal as Directory Portal
    participant OIDC as OIDC Verify
    participant Backend as Business Logic

    Client->>Nginx: API Request
    
    alt Rate Limit Exceeded
        Nginx-->>Client: 429 Too Many Requests
    else Within Limit
        Nginx->>Portal: Forward Request
        
        alt Public Endpoint
            Portal->>Backend: Process Request
        else Protected Endpoint
            Portal->>OIDC: Verify JWT
            alt Valid Token
                OIDC-->>Portal: User Context
                Portal->>Backend: Process Request
            else Invalid Token
                OIDC-->>Portal: Reject
                Portal-->>Client: 401 Unauthorized
            end
        end
        
        Backend-->>Portal: Response
        Portal-->>Client: API Response
    end
```

---

## 9. Audit & Compliance

### 9.1 Audit Event Flow

```mermaid
flowchart LR
    subgraph Events["Audit Events"]
        E1["QR Issued"]
        E2["QR Consumed"]
        E3["User Created"]
        E4["User Terminated"]
        E5["Password Reset"]
        E6["Admin Login"]
        E7["Auth Failure"]
        E8["Break-Glass Activated"]
    end

    subgraph Tables["Audit Tables"]
        T1[("qr_issuance_audit")]
        T2[("user_lifecycle_audit")]
        T3[("termination_events")]
        T4[("admin_auth_audit")]
        T5[("auth_failure_audit")]
        T6[("breakglass_audit")]
    end

    subgraph Retention["Retention"]
        R1["2 years"]
        R2["5 years"]
        R3["1 year"]
        R4["90 days"]
    end

    E1 & E2 --> T1 --> R1
    E3 & E5 --> T2 --> R2
    E4 --> T3 --> R2
    E6 --> T4 --> R3
    E7 --> T5 --> R4
    E8 --> T6 --> R2
```

### 9.2 Audit Record Structure

```mermaid
erDiagram
    qr_issuance_audit {
        int id PK
        string user_uid
        string org_dn
        string issued_by
        timestamp issued_at
        string token_hash
        timestamp expires_at
        boolean consumed
        timestamp consumed_at
        string consumed_reason
        inet client_ip
        text user_agent
    }

    termination_events {
        int id PK
        string user_uid
        string terminated_by
        string reason
        timestamp timestamp
        jsonb actions_taken
    }

    auth_failure_audit {
        int id PK
        string username
        string failure_reason
        timestamp timestamp
        inet client_ip
        text user_agent
        string endpoint
    }
```

---

## 10. Break-Glass Recovery

### 10.1 Break-Glass Scenarios

```mermaid
flowchart TD
    subgraph Scenarios["When to Use Break-Glass"]
        S1["Authentik Outage"]
        S2["OIDC Misconfiguration"]
        S3["Certificate Expiry"]
        S4["Network Partition to IdP"]
    end

    subgraph Problem["Problem"]
        P1["Admin locked out"]
        P2["Cannot manage system"]
        P3["REQUIRE_OIDC_AUTH=true<br/>but Authentik unavailable"]
    end

    subgraph Solution["Solution"]
        Sol1["Break-glass bypass"]
        Sol2["Time-limited"]
        Sol3["Localhost-only"]
        Sol4["Audit logged"]
    end

    Scenarios --> Problem --> Solution
```

### 10.2 Break-Glass Flow

```mermaid
sequenceDiagram
    participant Admin as Admin (SSH)
    participant CLI as directoryctl.py
    participant File as /etc/azblink/directory/breakglass.json
    participant Portal as Directory Portal
    participant Audit as Audit Log

    Note over Admin,Audit: Authentik is DOWN, Admin locked out

    Admin->>CLI: python directoryctl.py breakglass enable<br/>--minutes 30 --mode bootstrap_only
    CLI->>File: Write breakglass.json<br/>{enabled: true, expires_at: ..., mode: bootstrap_only}
    CLI-->>Admin: ✓ Break-glass enabled for 30 minutes

    Admin->>Portal: curl http://localhost:8000/api/bootstrap
    Portal->>File: Check breakglass.json
    File-->>Portal: {enabled: true, mode: bootstrap_only}
    Portal->>Audit: Log: "Break-glass bypass used"
    Portal-->>Admin: ✓ Request processed (bypassed OIDC)

    Note over Admin,Audit: Admin fixes Authentik or config

    Admin->>CLI: python directoryctl.py breakglass disable
    CLI->>File: Delete breakglass.json
    CLI-->>Admin: ✓ Break-glass disabled
```

### 10.3 Break-Glass Modes

```mermaid
graph TB
    subgraph BootstrapOnly["Mode: bootstrap_only"]
        BO1["Allowed: /api/tenant"]
        BO2["Allowed: /api/bootstrap"]
        BO3["Blocked: All other endpoints"]
        BO4["Use case: Initial setup recovery"]
    end

    subgraph AdminRecovery["Mode: admin_recovery"]
        AR1["Allowed: All admin endpoints"]
        AR2["Allowed: Full system access"]
        AR3["Use case: Emergency admin access"]
        AR4["⚠️ Use sparingly"]
    end

    style BootstrapOnly fill:#E6FFE6
    style AdminRecovery fill:#FFE6E6
```

---

## 11. Authentik Integration

### 11.1 Integration Architecture

```mermaid
flowchart TB
    subgraph LDAP["OpenLDAP"]
        Users["ou=people"]
        Groups["ou=groups"]
    end

    subgraph Authentik["Authentik"]
        LDAPSource["LDAP Source"]
        OIDCProvider["OIDC Provider"]
        Apps["Applications"]
        
        LDAPSource -->|"Sync"| OIDCProvider
        OIDCProvider --> Apps
    end

    subgraph Applications["Protected Applications"]
        DirPortal["Directory Portal"]
        SafeNest3["SafeNest"]
        eHub3["eHub"]
    end

    LDAP <-->|"Sync users/groups"| LDAPSource
    Apps -->|"OIDC Auth"| Applications

    style Authentik fill:#FFF9E6
```

### 11.2 OIDC Claims Mapping

```mermaid
graph LR
    subgraph LDAP_Attrs["LDAP Attributes"]
        L1["uid"]
        L2["cn"]
        L3["mail"]
        L4["memberOf"]
    end

    subgraph OIDC_Claims["OIDC Claims"]
        O1["preferred_username"]
        O2["name"]
        O3["email"]
        O4["groups"]
    end

    subgraph Required["Required"]
        R1["sub ✓"]
        R2["preferred_username ✓"]
        R3["groups ✓"]
    end

    L1 --> O1 --> R2
    L2 --> O2
    L3 --> O3
    L4 --> O4 --> R3
```

---

## 12. Configuration Reference

### 12.1 Configuration Categories

```mermaid
mindmap
  root((Configuration))
    LDAP
      LDAP_URI
      LDAP_BASE_DN
      LDAP_BIND_DN
      LDAP_BIND_PW
    Database
      DATABASE_URL
      DATABASE_POOL_SIZE
    Redis
      REDIS_URL
      REDIS_POOL_SIZE
    Security
      ORG_QR_SIGNING_SECRET
      ORG_QR_DEFAULT_TTL_SEC
    OIDC
      REQUIRE_OIDC_AUTH
      OIDC_ISSUER
      OIDC_AUDIENCE
    UC
      UCCHAT_XMPP_DOMAIN
      UCCHAT_SIP_DOMAIN
    Integration
      UC_SERVER_API_URL
      AUTHENTIK_API_URL
```

### 12.2 Configuration by Deployment Phase

```mermaid
graph TB
    subgraph Day0["Day 0 Configuration"]
        D0_1["REQUIRE_OIDC_AUTH=false"]
        D0_2["ALLOW_BOOTSTRAP_WITHOUT_OIDC=true"]
        D0_3["ORG_QR_SIGNING_SECRET=<secret>"]
    end

    subgraph Day1["Day 1 Configuration"]
        D1_1["REQUIRE_OIDC_AUTH=true"]
        D1_2["ALLOW_BOOTSTRAP_WITHOUT_OIDC=false"]
        D1_3["OIDC_ISSUER=https://auth.example.com/..."]
        D1_4["OIDC_AUDIENCE=azblink-directory"]
    end

    subgraph Production["Production Configuration"]
        P1["All Day 1 settings +"]
        P2["UC_SERVER_API_URL configured"]
        P3["AUTHENTIK_API_URL configured"]
        P4["Monitoring enabled"]
    end

    Day0 -->|"Enable SSO"| Day1 -->|"Go Live"| Production

    style Day0 fill:#E6FFE6
    style Day1 fill:#FFF9E6
    style Production fill:#E6F3FF
```

---

## 13. Hardening Checklist

### 13.1 Security Checklist Visualization

```mermaid
graph TB
    subgraph Secrets["Secrets Management"]
        S1["☐ QR_SIGNING_SECRET random 32+ bytes"]
        S2["☐ LDAP_BIND_PW dedicated service account"]
        S3["☐ AUTHENTIK_API_TOKEN minimal permissions"]
        S4["☐ Secrets in secrets manager"]
    end

    subgraph Network["Network Security"]
        N1["☐ TLS reverse proxy"]
        N2["☐ LDAP internal only"]
        N3["☐ PostgreSQL internal only"]
        N4["☐ Redis internal only"]
    end

    subgraph Access["Access Control"]
        A1["☐ ALLOW_BOOTSTRAP_WITHOUT_OIDC=false"]
        A2["☐ Break-glass root-only write"]
        A3["☐ Admin group limited membership"]
        A4["☐ MFA for admins"]
    end

    subgraph Monitoring["Monitoring & Alerting"]
        M1["☐ Rate limit violations alert"]
        M2["☐ Auth failure spikes alert"]
        M3["☐ Break-glass activation alert"]
        M4["☐ QR anomalies alert"]
    end

    subgraph Backup["Backup & Recovery"]
        B1["☐ PostgreSQL daily backup"]
        B2["☐ LDAP daily backup"]
        B3["☐ Backup encryption"]
        B4["☐ Restore procedure tested"]
    end
```

---

## 14. Mobile Client Requirements

### 14.1 QR Consumption Flow

```mermaid
flowchart TD
    Start([Scan QR Code]) --> Parse["Parse JSON payload"]
    Parse --> VerifySig["Verify HMAC-SHA256 signature"]
    
    VerifySig --> SigValid{Signature valid?}
    SigValid -->|No| Reject1["✗ Reject: INVALID_SIGNATURE"]
    SigValid -->|Yes| CheckExp["Check expiration"]
    
    CheckExp --> ExpValid{exp > now?}
    ExpValid -->|No| Reject2["✗ Reject: TOKEN_EXPIRED"]
    ExpValid -->|Yes| Exchange["Exchange token for credentials"]
    
    Exchange --> Store["Store in Keychain/Keystore"]
    Store --> CheckSSO{SSO block present?}
    
    CheckSSO -->|Yes| PKCE["Initiate PKCE flow"]
    CheckSSO -->|No| Complete
    PKCE --> Complete([✓ Provisioning Complete])

    style Reject1 fill:#FFB6C1
    style Reject2 fill:#FFB6C1
    style Complete fill:#90EE90
```

### 14.2 Token Storage by Platform

```mermaid
graph TB
    subgraph iOS["iOS"]
        iOS1["Storage: Keychain"]
        iOS2["Attribute: kSecAttrAccessible<br/>AfterFirstUnlock"]
    end

    subgraph Android["Android"]
        And1["Storage: EncryptedShared<br/>Preferences"]
        And2["Requirement: API 23+"]
    end

    subgraph Desktop["Desktop"]
        Desk1["Windows: Credential Manager"]
        Desk2["macOS: Keychain"]
    end

    style iOS fill:#E6F3FF
    style Android fill:#E6FFE6
    style Desktop fill:#FFF9E6
```

### 14.3 Session Termination Handling

```mermaid
stateDiagram-v2
    [*] --> Connected: Normal operation
    
    Connected --> Terminated: Server terminates session
    
    state Terminated {
        [*] --> ClearCreds: Clear all credentials
        ClearCreds --> ShowMessage: Show "Session terminated<br/>by administrator"
        ShowMessage --> ReturnToProvisioning: Return to QR scan screen
    }
    
    Terminated --> [*]: User re-provisions

    note right of Connected
        Termination signals:
        • XMPP stream:error
        • HTTP 401 on refresh
        • Custom terminate stanza
    end note
```

---

## 15. Troubleshooting

### 15.1 Troubleshooting Decision Tree

```mermaid
flowchart TD
    Start([Problem Detected]) --> Q1{QR code not working?}
    
    Q1 -->|Yes| QR1["Check signature verification"]
    QR1 --> QR2["Verify QR_SIGNING_SECRET matches"]
    QR2 --> QR3["Check token expiration"]
    QR3 --> QR4["Check token consumed status"]
    
    Q1 -->|No| Q2{401 on all endpoints?}
    
    Q2 -->|Yes| Auth1["Verify OIDC_ISSUER accessible"]
    Auth1 --> Auth2["Check OIDC_AUDIENCE matches"]
    Auth2 --> Auth3["Verify token not expired"]
    Auth3 --> Auth4["Use break-glass to recover"]
    
    Q2 -->|No| Q3{SSO missing from QR?}
    
    Q3 -->|Yes| SSO1["Check ssoProfile.enabled = true"]
    SSO1 --> SSO2["Verify issuer configured"]
    SSO2 --> SSO3["Check entitlements non-empty"]
    
    Q3 -->|No| Q4{Terminated user still connected?}
    
    Q4 -->|Yes| Term1["Verify UC_SERVER_API_URL"]
    Term1 --> Term2["Check UC Server endpoint working"]
    Term2 --> Term3["Fallback: Restart UC Server"]
```

### 15.2 Common Issues Quick Reference

```mermaid
graph LR
    subgraph QR_Issues["QR Issues"]
        QR_P1["Not working"] --> QR_S1["Check sig, exp, consumed"]
        QR_P2["Missing SSO"] --> QR_S2["Check OrgProfile config"]
    end

    subgraph Auth_Issues["Auth Issues"]
        Auth_P1["401 everywhere"] --> Auth_S1["Break-glass + fix OIDC"]
        Auth_P2["Token invalid"] --> Auth_S2["Check issuer/audience"]
    end

    subgraph Term_Issues["Termination Issues"]
        Term_P1["User still connected"] --> Term_S1["Check UC_SERVER_API_URL"]
        Term_P2["Partial termination"] --> Term_S2["Check component APIs"]
    end

    style QR_S1 fill:#90EE90
    style QR_S2 fill:#90EE90
    style Auth_S1 fill:#90EE90
    style Auth_S2 fill:#90EE90
    style Term_S1 fill:#90EE90
    style Term_S2 fill:#90EE90
```

---

## 16. Deployment Checklists

### 16.1 Day 0 Checklist

```mermaid
graph TB
    subgraph Infrastructure["Infrastructure ✓"]
        I1["☐ PostgreSQL :5432 accepting connections"]
        I2["☐ OpenLDAP :389 accepting connections"]
        I3["☐ Redis :6379 accepting connections"]
        I4["☐ Directory Portal :8000 accessible"]
    end

    subgraph Bootstrap["Bootstrap ✓"]
        B1["☐ POST /api/bootstrap succeeds"]
        B2["☐ Org tree created"]
        B3["☐ Groups created"]
        B4["☐ Users created/imported"]
    end

    subgraph Validation["Validation ✓"]
        V1["☐ QR scan works"]
        V2["☐ VPN connects"]
        V3["☐ SIP registers"]
        V4["☐ XMPP connects"]
    end

    Infrastructure --> Bootstrap --> Validation
```

### 16.2 Day 1 Checklist

```mermaid
graph TB
    subgraph Authentik_Config["Authentik Config ✓"]
        A1["☐ LDAP source configured"]
        A2["☐ OIDC provider created"]
        A3["☐ Applications created"]
    end

    subgraph Portal_Config["Portal Config ✓"]
        P1["☐ OrgProfile with SSO config"]
        P2["☐ ssoProfile.enabled = true"]
        P3["☐ REQUIRE_OIDC_AUTH = true"]
    end

    subgraph Hardening["Hardening ✓"]
        H1["☐ ALLOW_BOOTSTRAP_WITHOUT_OIDC = false"]
        H2["☐ QR includes SSO block"]
        H3["☐ SSO login flow tested"]
    end

    Authentik_Config --> Portal_Config --> Hardening
```

### 16.3 Production Checklist

```mermaid
graph TB
    subgraph Security["Security ✓"]
        S1["☐ All hardening items complete"]
        S2["☐ Secrets in secrets manager"]
        S3["☐ MFA for admins"]
    end

    subgraph Operations["Operations ✓"]
        O1["☐ Monitoring configured"]
        O2["☐ Alerting configured"]
        O3["☐ Break-glass tested"]
    end

    subgraph Recovery["Recovery ✓"]
        R1["☐ Daily backups running"]
        R2["☐ Restore procedure tested"]
        R3["☐ Runbooks documented"]
    end

    Security --> Operations --> Recovery
```

---

## Appendix A: Database Schema

### A.1 Entity Relationship Diagram

```mermaid
erDiagram
    org_profiles {
        uuid id PK
        varchar org_dn UK
        varchar name
        jsonb entitlements
        jsonb sso_profile
        timestamp created_at
        timestamp updated_at
    }

    qr_issuance_audit {
        serial id PK
        varchar user_uid FK
        varchar org_dn
        varchar issued_by
        timestamp issued_at
        varchar token_hash UK
        timestamp expires_at
        boolean consumed
        timestamp consumed_at
        varchar consumed_reason
        inet client_ip
        text user_agent
    }

    termination_events {
        serial id PK
        varchar user_uid FK
        varchar terminated_by
        varchar reason
        timestamp timestamp
        jsonb actions_taken
    }

    auth_failure_audit {
        serial id PK
        varchar username
        varchar failure_reason
        timestamp timestamp
        inet client_ip
        text user_agent
        varchar endpoint
    }

    breakglass_audit {
        serial id PK
        varchar activated_by
        varchar mode
        timestamp activated_at
        timestamp expires_at
        varchar reason
    }

    org_profiles ||--o{ qr_issuance_audit : "org_dn"
    qr_issuance_audit }o--|| termination_events : "user_uid"
```

### A.2 SQL Schema

```sql
-- OrgProfiles
CREATE TABLE org_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_dn VARCHAR(500) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    entitlements JSONB DEFAULT '[]',
    sso_profile JSONB DEFAULT '{"enabled": false}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- QR Issuance Audit
CREATE TABLE qr_issuance_audit (
    id SERIAL PRIMARY KEY,
    user_uid VARCHAR(255) NOT NULL,
    org_dn VARCHAR(500),
    issued_by VARCHAR(255) NOT NULL,
    issued_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    token_hash VARCHAR(64) NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    consumed BOOLEAN DEFAULT FALSE,
    consumed_at TIMESTAMP WITH TIME ZONE,
    consumed_reason VARCHAR(50),
    client_ip INET,
    user_agent TEXT
);

-- Termination Events
CREATE TABLE termination_events (
    id SERIAL PRIMARY KEY,
    user_uid VARCHAR(255) NOT NULL,
    terminated_by VARCHAR(255) NOT NULL,
    reason VARCHAR(100) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    actions_taken JSONB NOT NULL
);

-- Auth Failure Audit
CREATE TABLE auth_failure_audit (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255),
    failure_reason VARCHAR(100) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    client_ip INET NOT NULL,
    user_agent TEXT,
    endpoint VARCHAR(255)
);

-- Indexes
CREATE INDEX idx_qr_audit_user ON qr_issuance_audit(user_uid);
CREATE INDEX idx_qr_audit_token ON qr_issuance_audit(token_hash);
CREATE INDEX idx_qr_audit_consumed ON qr_issuance_audit(consumed, expires_at);
CREATE INDEX idx_auth_failure_ip ON auth_failure_audit(client_ip, timestamp);
CREATE INDEX idx_termination_user ON termination_events(user_uid);
```

---

## Appendix B: Repository Layout

```mermaid
graph TB
    subgraph Root["azblink-directory/"]
        Backend["backend/"]
        UI["ui/"]
        CLI["cli/"]
        Migrations["migrations/"]
        Docker["docker/"]
        Docs["docs/"]
    end

    subgraph BackendFiles["backend/"]
        B1["main.py"]
        B2["config.py"]
        B3["ldap_client.py"]
        B4["orgdb.py"]
        B5["qr_signing.py"]
        B6["oidc_verify.py"]
        B7["rate_limit.py"]
        B8["termination.py"]
        B9["breakglass.py"]
        B10["audit.py"]
    end

    subgraph UIFiles["ui/"]
        U1["index.html"]
        U2["directory_manager.html"]
        U3["directory_provision_manager.html"]
        U4["directory.html"]
        U5["my_profile.html"]
    end

    subgraph CLIFiles["cli/"]
        C1["directoryctl.py"]
    end

    Backend --> BackendFiles
    UI --> UIFiles
    CLI --> CLIFiles
```

---

## Appendix C: Docker Compose

```yaml
version: '3.8'

services:
  openldap:
    image: osixia/openldap:1.5.0
    environment:
      LDAP_ORGANISATION: "Example Inc"
      LDAP_DOMAIN: "example.com"
      LDAP_ADMIN_PASSWORD: "${LDAP_ADMIN_PASSWORD}"
    volumes:
      - ldap_data:/var/lib/ldap
      - ldap_config:/etc/ldap/slapd.d
    networks:
      - azblink

  postgres:
    image: postgres:15
    environment:
      POSTGRES_USER: azblink
      POSTGRES_PASSWORD: "${POSTGRES_PASSWORD}"
      POSTGRES_DB: azblink_directory
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - azblink

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data
    networks:
      - azblink

  authentik-server:
    image: ghcr.io/goauthentik/server:2024.1
    command: server
    environment:
      AUTHENTIK_SECRET_KEY: "${AUTHENTIK_SECRET_KEY}"
      AUTHENTIK_POSTGRESQL__HOST: postgres
      AUTHENTIK_POSTGRESQL__USER: authentik
      AUTHENTIK_POSTGRESQL__PASSWORD: "${AUTHENTIK_DB_PASSWORD}"
      AUTHENTIK_POSTGRESQL__NAME: authentik
      AUTHENTIK_REDIS__HOST: redis
    depends_on:
      - postgres
      - redis
    networks:
      - azblink

  directory-backend:
    build: ./backend
    environment:
      LDAP_URI: ldap://openldap:389
      DATABASE_URL: postgresql+psycopg2://azblink:${POSTGRES_PASSWORD}@postgres:5432/azblink_directory
      REDIS_URL: redis://redis:6379/0
      ORG_QR_SIGNING_SECRET: "${QR_SIGNING_SECRET}"
      REQUIRE_OIDC_AUTH: "false"
    depends_on:
      - openldap
      - postgres
      - redis
    ports:
      - "8000:8000"
    networks:
      - azblink

volumes:
  ldap_data:
  ldap_config:
  postgres_data:
  redis_data:

networks:
  azblink:
    driver: bridge
```

---

## Appendix D: CLI Reference

```bash
# System Status
python directoryctl.py status              # Show system status

# Break-Glass Recovery
python directoryctl.py breakglass enable --minutes 30 --mode bootstrap_only
python directoryctl.py breakglass enable --minutes 30 --mode admin_recovery
python directoryctl.py breakglass disable
python directoryctl.py breakglass status

# User Management
python directoryctl.py user terminate <uid> --reason "employment_ended"
python directoryctl.py user suspend <uid>
python directoryctl.py user unsuspend <uid>
python directoryctl.py user list --org "ou=Engineering,dc=example,dc=com"

# QR Management
python directoryctl.py qr revoke-all <uid>       # Revoke all active tokens
python directoryctl.py qr issue <uid>            # Issue new QR

# Audit Queries
python directoryctl.py audit qr --user <uid> --days 30
python directoryctl.py audit terminations --days 90
python directoryctl.py audit failures --ip <ip> --days 7

# Maintenance
python directoryctl.py maintenance cleanup-expired-tokens
python directoryctl.py maintenance vacuum-audit --older-than-days 365
```

---

## Appendix E: Glossary

| Term | Definition |
|------|------------|
| **Day 0** | Fresh installation; bootstrap LDAP, create users |
| **Day 1** | SSO enablement; configure Authentik, OrgProfiles |
| **Practice** | Daily operations; system fully operational |
| **Plane A** | UC authentication (LDAP); always available |
| **Plane B** | App SSO (Authentik); optional |
| **Unified QR** | Single QR with UC + SSO config (recommended) |
| **Split QR** | Separate QR#1 (UC) and QR#2 (SSO) - legacy |
| **Entitlements** | Licensed apps; factory-set based on purchase |
| **OrgProfile** | PostgreSQL record with SSO config and entitlements |
| **Break-glass** | Emergency admin access when Authentik unavailable |
| **One-time token** | Provisioning credential consumed on first use |
| **PKCE** | Proof Key for Code Exchange; secure mobile OAuth flow |

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| v1.0-v2.0 | 2024-01 | GitHub spec (security hardening) |
| v3.0 | 2025-01 | Business context and ASCII diagrams |
| v4.0 | 2025-01 | Merged: security + business + operations |
| **v4.1** | **2025-01** | **Enhanced with Mermaid diagrams** |

---

## Document Approval

| Role | Name | Date | Signature |
|------|------|------|-----------|
| Technical Lead | | | |
| Security Review | | | |
| Product Owner | | | |
