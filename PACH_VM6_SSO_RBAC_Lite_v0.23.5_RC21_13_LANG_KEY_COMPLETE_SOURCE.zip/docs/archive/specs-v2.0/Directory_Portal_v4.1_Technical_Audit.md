# Directory Portal v4.1 — Technical Audit Report

**Audit Date:** January 2025  
**Auditor:** Technical Review  
**Scope:** API Contracts, Database Design, LDAP Schema  
**Status:** 🔴 CRITICAL GAPS IDENTIFIED — NOT PRODUCTION READY

---

## Executive Summary

This audit extracts and analyzes the API contracts, database schema, and LDAP design from the Directory Portal Specification v4.1. **Significant gaps, inconsistencies, and missing production requirements have been identified.**

### Severity Summary

| Category | Critical | High | Medium | Low |
|----------|----------|------|--------|-----|
| API Contracts | 4 | 7 | 5 | 3 |
| Database Design | 3 | 5 | 4 | 2 |
| LDAP Schema | 2 | 4 | 3 | 1 |
| **Total** | **9** | **16** | **12** | **6** |

---

## Part 1: API Contract Extraction & Audit

### 1.1 Documented API Endpoints

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                    EXTRACTED API SURFACE                                        │
├────────────┬──────────────────────────────────┬────────────┬────────────────────────────────────┤
│   Method   │            Endpoint              │    Auth    │           Description              │
├────────────┼──────────────────────────────────┼────────────┼────────────────────────────────────┤
│ POST       │ /api/bootstrap                   │ No*        │ Initialize base OUs                │
│ GET        │ /api/tenant                      │ No*        │ Get tenant info                    │
│ GET        │ /api/health                      │ No         │ Basic health check                 │
│ GET        │ /api/health/deep                 │ Yes        │ Deep health check                  │
│ GET        │ /api/org/tree                    │ Yes        │ Get org hierarchy                  │
│ POST       │ /api/org/create                  │ Admin      │ Create organization                │
│ POST       │ /api/org/rename                  │ Admin      │ Rename organization                │
│ DELETE     │ /api/org/{dn}                    │ Admin      │ Delete organization                │
│ GET        │ /api/users                       │ Yes        │ List users                         │
│ GET        │ /api/users/{uid}                 │ Yes        │ Get user details                   │
│ POST       │ /api/users/create                │ Admin      │ Create user                        │
│ PATCH      │ /api/users/{uid}                 │ Admin      │ Update user                        │
│ POST       │ /api/users/{uid}/reset_password  │ Admin      │ Reset password                     │
│ POST       │ /api/users/{uid}/move_org        │ Admin      │ Move to different org              │
│ POST       │ /api/users/{uid}/terminate       │ Admin      │ Terminate user                     │
│ POST       │ /api/users/{uid}/suspend         │ Admin      │ Suspend user                       │
│ POST       │ /api/users/{uid}/unsuspend       │ Admin      │ Unsuspend user                     │
│ POST       │ /api/users/import_csv            │ Admin      │ Bulk import                        │
│ GET        │ /api/users/{uid}/qrcode          │ Yes        │ Get unified QR                     │
│ POST       │ /api/users/{uid}/qrcode/revoke   │ Admin      │ Revoke QR tokens                   │
│ GET        │ /api/groups                      │ Yes        │ List groups                        │
│ POST       │ /api/groups/create               │ Admin      │ Create group                       │
│ DELETE     │ /api/groups/{cn}                 │ Admin      │ Delete group                       │
│ POST       │ /api/groups/{cn}/members         │ Admin      │ Add members                        │
│ DELETE     │ /api/groups/{cn}/members/{uid}   │ Admin      │ Remove member                      │
│ GET        │ /api/orgprofiles                 │ Yes        │ List OrgProfiles                   │
│ POST       │ /api/orgprofiles                 │ Admin      │ Create OrgProfile                  │
│ GET        │ /api/orgprofiles/{id}            │ Yes        │ Get OrgProfile                     │
│ PATCH      │ /api/orgprofiles/{id}            │ Admin      │ Update OrgProfile                  │
│ DELETE     │ /api/orgprofiles/{id}            │ Admin      │ Delete OrgProfile                  │
│ GET        │ /api/audit/qr_issuance           │ Admin      │ QR audit log                       │
│ GET        │ /api/audit/terminations          │ Admin      │ Termination log                    │
│ GET        │ /api/audit/auth_failures         │ Admin      │ Auth failure log                   │
└────────────┴──────────────────────────────────┴────────────┴────────────────────────────────────┘

* Exempt when ALLOW_BOOTSTRAP_WITHOUT_OIDC=true
```

### 1.2 API Contract Gaps — CRITICAL

#### 🔴 CRITICAL-API-001: No Request/Response Schemas Defined

**Problem:** The specification lists endpoints but provides NO request body schemas or response schemas.

**Impact:** 
- Developers cannot implement clients
- No contract for validation
- No basis for API testing
- Frontend/backend mismatch guaranteed

**Missing for each endpoint:**
- Request body JSON schema
- Response body JSON schema  
- Error response schemas
- HTTP status codes per scenario

**Example — `/api/users/create` is missing:**

```yaml
# REQUIRED BUT NOT DEFINED:
POST /api/users/create:
  requestBody:
    required: true
    content:
      application/json:
        schema:
          type: object
          required: [uid, cn, mail, org_dn]
          properties:
            uid:
              type: string
              pattern: "^[a-z][a-z0-9_-]{2,31}$"
              description: Unique user identifier
            cn:
              type: string
              maxLength: 255
              description: Common name (display name)
            givenName:
              type: string
              maxLength: 100
            sn:
              type: string
              maxLength: 100
              description: Surname
            mail:
              type: string
              format: email
            telephoneNumber:
              type: string
              pattern: "^\\+?[0-9\\-\\s]+$"
            org_dn:
              type: string
              description: "DN of organization (e.g., ou=Engineering,dc=example,dc=com)"
            password:
              type: string
              minLength: 12
              description: Initial password (will be hashed)
            groups:
              type: array
              items:
                type: string
              description: Group CNs to add user to
  responses:
    201:
      description: User created
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/User'
    400:
      description: Validation error
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/ValidationError'
    409:
      description: User already exists
    422:
      description: Invalid org_dn
```

---

#### 🔴 CRITICAL-API-002: No Token Consumption Endpoint

**Problem:** QR codes contain one-time tokens, but there's no API endpoint for mobile clients to consume/exchange them.

**The spec describes:**
1. QR issued with token → ✓ Documented (`GET /api/users/{uid}/qrcode`)
2. Client scans QR → Described in flow
3. Client exchanges token → ❌ NO ENDPOINT DEFINED
4. Backend marks consumed → Described in DB schema

**Missing endpoint:**

```yaml
POST /api/provision/consume:
  description: Exchange one-time provisioning token for session credentials
  security: []  # No auth - token IS the auth
  requestBody:
    required: true
    content:
      application/json:
        schema:
          type: object
          required: [token]
          properties:
            token:
              type: string
              description: One-time token from QR payload
            device_info:
              type: object
              properties:
                platform: { type: string, enum: [ios, android, desktop] }
                device_id: { type: string }
                app_version: { type: string }
  responses:
    200:
      description: Token valid, credentials returned
      content:
        application/json:
          schema:
            type: object
            properties:
              xmpp_credentials:
                type: object
                properties:
                  jid: { type: string }
                  password: { type: string }
              sip_credentials:
                type: object
                properties:
                  username: { type: string }
                  password: { type: string }
                  domain: { type: string }
              vpn_config:
                type: object
    400:
      description: TOKEN_EXPIRED or TOKEN_ALREADY_CONSUMED
    401:
      description: INVALID_TOKEN or INVALID_SIGNATURE
```

---

#### 🔴 CRITICAL-API-003: No Pagination Defined

**Problem:** List endpoints (`GET /api/users`, `GET /api/groups`, `GET /api/audit/*`) have no pagination parameters.

**Impact:** 
- Will timeout/OOM with thousands of users
- No cursor-based pagination for real-time consistency
- No way to get total counts

**Required for all list endpoints:**

```yaml
parameters:
  - name: page
    in: query
    schema:
      type: integer
      minimum: 1
      default: 1
  - name: page_size
    in: query
    schema:
      type: integer
      minimum: 1
      maximum: 100
      default: 20
  - name: cursor
    in: query
    description: Opaque cursor for cursor-based pagination
    schema:
      type: string
  - name: sort_by
    in: query
    schema:
      type: string
      enum: [created_at, updated_at, uid, cn]
  - name: sort_order
    in: query
    schema:
      type: string
      enum: [asc, desc]
      default: asc

# Response must include:
headers:
  X-Total-Count:
    description: Total number of records
    schema:
      type: integer
  X-Next-Cursor:
    description: Cursor for next page (if cursor-based)
    schema:
      type: string
  Link:
    description: RFC 5988 pagination links
    schema:
      type: string
```

---

#### 🔴 CRITICAL-API-004: No Idempotency Keys

**Problem:** No idempotency mechanism for POST/PATCH operations.

**Impact:**
- Network retries can create duplicate users
- Double-terminate can cause inconsistent state
- No safe retry for failed operations

**Required:**

```yaml
# All mutating endpoints should support:
parameters:
  - name: Idempotency-Key
    in: header
    required: false
    schema:
      type: string
      format: uuid
    description: |
      Client-generated UUID. If the same key is sent twice within 24 hours,
      the second request returns the cached response from the first.
```

---

### 1.3 API Contract Gaps — HIGH

#### 🟠 HIGH-API-001: No Filter/Search Parameters for Users

**Problem:** `GET /api/users` has no query parameters for filtering.

**Required:**

```yaml
GET /api/users:
  parameters:
    - name: org_dn
      in: query
      description: Filter by organization
    - name: group_cn
      in: query
      description: Filter by group membership
    - name: status
      in: query
      schema:
        type: string
        enum: [active, suspended, terminated]
    - name: search
      in: query
      description: Search by uid, cn, mail (partial match)
    - name: created_after
      in: query
      schema:
        type: string
        format: date-time
    - name: created_before
      in: query
      schema:
        type: string
        format: date-time
```

---

#### 🟠 HIGH-API-002: No Bulk Operations

**Problem:** Only `POST /api/users/import_csv` exists for bulk. No bulk update, bulk suspend, bulk terminate.

**Required for production:**

```yaml
POST /api/users/bulk:
  description: Bulk user operations
  requestBody:
    content:
      application/json:
        schema:
          type: object
          properties:
            operation:
              type: string
              enum: [suspend, unsuspend, terminate, move_org, add_to_group]
            user_uids:
              type: array
              items:
                type: string
              maxItems: 100
            params:
              type: object
              description: Operation-specific parameters
```

---

#### 🟠 HIGH-API-003: No Webhook/Event Notifications

**Problem:** No mechanism for external systems to receive events.

**Required for integration:**

```yaml
# Webhook registration
POST /api/webhooks:
  requestBody:
    content:
      application/json:
        schema:
          type: object
          properties:
            url:
              type: string
              format: uri
            events:
              type: array
              items:
                type: string
                enum: 
                  - user.created
                  - user.terminated
                  - user.suspended
                  - qr.issued
                  - qr.consumed
            secret:
              type: string
              description: HMAC secret for webhook signature
```

---

#### 🟠 HIGH-API-004: Missing GET /api/users/{uid}/qrcodes (Split Mode)

**Problem:** Spec mentions `?mode=split` but no schema for split response.

**Required:**

```yaml
GET /api/users/{uid}/qrcode:
  parameters:
    - name: mode
      in: query
      schema:
        type: string
        enum: [unified, split]
        default: unified
  responses:
    200:
      content:
        application/json:
          schema:
            oneOf:
              - $ref: '#/components/schemas/UnifiedQRResponse'
              - $ref: '#/components/schemas/SplitQRResponse'
```

---

#### 🟠 HIGH-API-005: No API Versioning Strategy

**Problem:** No `/v1/` prefix, no version negotiation, no deprecation headers.

**Impact:** Breaking changes will break all clients simultaneously.

**Required:**

```yaml
# Either path versioning:
/api/v1/users
/api/v2/users  # When breaking changes needed

# Or header versioning:
headers:
  Accept:
    description: "application/vnd.azblink.v1+json"
  X-API-Deprecation-Date:
    description: "Date when this version will be removed"
```

---

#### 🟠 HIGH-API-006: No Self-Service Password Change

**Problem:** Only admin can reset password (`POST /api/users/{uid}/reset_password`). Users cannot change their own.

**Required:**

```yaml
POST /api/me/password:
  description: Change own password (authenticated user)
  security:
    - bearerAuth: []
  requestBody:
    content:
      application/json:
        schema:
          type: object
          required: [current_password, new_password]
          properties:
            current_password:
              type: string
            new_password:
              type: string
              minLength: 12
```

---

#### 🟠 HIGH-API-007: No User Self-Service Endpoints

**Problem:** No `/api/me` endpoints for authenticated users to manage themselves.

**Required:**

```yaml
GET /api/me                    # Get own profile
PATCH /api/me                  # Update own profile (limited fields)
GET /api/me/qrcode             # Get own QR code
GET /api/me/sessions           # List own active sessions
DELETE /api/me/sessions/{id}   # Revoke own session
```

---

### 1.4 API Contract Gaps — MEDIUM

#### 🟡 MEDIUM-API-001: No Rate Limit Headers in Response

**Problem:** Rate limits defined but no headers to inform clients.

**Required:**

```yaml
headers:
  X-RateLimit-Limit:
    description: Requests allowed per window
  X-RateLimit-Remaining:
    description: Requests remaining in current window
  X-RateLimit-Reset:
    description: Unix timestamp when window resets
  Retry-After:
    description: Seconds to wait (on 429 response)
```

---

#### 🟡 MEDIUM-API-002: No HATEOAS/Links in Responses

**Problem:** No hypermedia links for resource navigation.

**Example response should include:**

```json
{
  "uid": "alice",
  "cn": "Alice Smith",
  "_links": {
    "self": "/api/users/alice",
    "qrcode": "/api/users/alice/qrcode",
    "groups": "/api/users/alice/groups",
    "terminate": "/api/users/alice/terminate",
    "org": "/api/org/ou=Engineering,dc=example,dc=com"
  }
}
```

---

#### 🟡 MEDIUM-API-003: No ETag/Conditional Requests

**Problem:** No support for `If-None-Match`, `If-Match` headers.

**Impact:** 
- No cache validation
- Lost update problem on concurrent edits

---

#### 🟡 MEDIUM-API-004: No Health Check for Dependencies

**Problem:** `/api/health/deep` mentioned but no schema for what it checks.

**Required:**

```yaml
GET /api/health/deep:
  responses:
    200:
      content:
        application/json:
          schema:
            type: object
            properties:
              status:
                type: string
                enum: [healthy, degraded, unhealthy]
              checks:
                type: object
                properties:
                  ldap:
                    $ref: '#/components/schemas/HealthCheck'
                  postgresql:
                    $ref: '#/components/schemas/HealthCheck'
                  redis:
                    $ref: '#/components/schemas/HealthCheck'
                  authentik:
                    $ref: '#/components/schemas/HealthCheck'
                  uc_server:
                    $ref: '#/components/schemas/HealthCheck'

HealthCheck:
  type: object
  properties:
    status: { type: string, enum: [up, down, degraded] }
    latency_ms: { type: integer }
    last_check: { type: string, format: date-time }
    error: { type: string }
```

---

#### 🟡 MEDIUM-API-005: Audit Endpoint Filters Missing

**Problem:** Audit endpoints have no filter parameters defined.

**Required:**

```yaml
GET /api/audit/qr_issuance:
  parameters:
    - name: user_uid
    - name: issued_by
    - name: consumed
      schema:
        type: boolean
    - name: from_date
    - name: to_date
    - name: page
    - name: page_size
```

---

## Part 2: Database Schema Extraction & Audit

### 2.1 Documented Tables

```sql
-- From spec v4.1:

1. org_profiles
2. qr_issuance_audit
3. termination_events
4. auth_failure_audit
5. breakglass_audit (in ER diagram but no SQL)
```

### 2.2 Database Gaps — CRITICAL

#### 🔴 CRITICAL-DB-001: Missing `users` Table

**Problem:** The spec assumes users are ONLY in LDAP, but needs PostgreSQL shadow for:
- Faster queries than LDAP
- Suspension status (LDAP doesn't have good status field)
- Foreign key relationships
- Audit trail for all changes

**Required:**

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    uid VARCHAR(32) NOT NULL UNIQUE,
    ldap_dn VARCHAR(500) NOT NULL UNIQUE,
    org_profile_id UUID REFERENCES org_profiles(id),
    status VARCHAR(20) NOT NULL DEFAULT 'active' 
        CHECK (status IN ('active', 'suspended', 'terminated')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by VARCHAR(255),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    suspended_at TIMESTAMP WITH TIME ZONE,
    suspended_by VARCHAR(255),
    terminated_at TIMESTAMP WITH TIME ZONE,
    terminated_by VARCHAR(255),
    last_login_at TIMESTAMP WITH TIME ZONE,
    last_qr_issued_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}'
);

CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_org ON users(org_profile_id);
```

---

#### 🔴 CRITICAL-DB-002: Missing `provisioning_tokens` Table

**Problem:** Spec describes one-time tokens but `qr_issuance_audit` is audit-only. Need actual token storage.

**Required:**

```sql
CREATE TABLE provisioning_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token_hash VARCHAR(64) NOT NULL UNIQUE,  -- SHA-256 of actual token
    user_uid VARCHAR(32) NOT NULL,
    issued_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    consumed_at TIMESTAMP WITH TIME ZONE,
    revoked_at TIMESTAMP WITH TIME ZONE,
    revoked_reason VARCHAR(100),
    qr_type VARCHAR(20) NOT NULL CHECK (qr_type IN ('unified', 'uc_only', 'sso_only')),
    payload_hash VARCHAR(64),  -- For detecting payload tampering
    
    CONSTRAINT token_lifecycle CHECK (
        (consumed_at IS NULL AND revoked_at IS NULL) OR  -- Valid
        (consumed_at IS NOT NULL AND revoked_at IS NULL) OR  -- Consumed
        (revoked_at IS NOT NULL)  -- Revoked
    )
);

CREATE INDEX idx_tokens_user ON provisioning_tokens(user_uid);
CREATE INDEX idx_tokens_expires ON provisioning_tokens(expires_at) WHERE consumed_at IS NULL;
```

---

#### 🔴 CRITICAL-DB-003: Missing Suspension Audit

**Problem:** `termination_events` exists but no `suspension_events` table.

**Required:**

```sql
CREATE TABLE suspension_events (
    id SERIAL PRIMARY KEY,
    user_uid VARCHAR(255) NOT NULL,
    action VARCHAR(20) NOT NULL CHECK (action IN ('suspend', 'unsuspend')),
    performed_by VARCHAR(255) NOT NULL,
    reason VARCHAR(255),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    client_ip INET,
    user_agent TEXT
);

CREATE INDEX idx_suspension_user ON suspension_events(user_uid);
```

---

### 2.3 Database Gaps — HIGH

#### 🟠 HIGH-DB-001: `org_profiles.sso_profile` JSONB is Not Validated

**Problem:** JSONB column with no schema enforcement.

**Impact:** Invalid SSO config can be stored, breaking QR generation.

**Required:**

```sql
-- Add check constraint
ALTER TABLE org_profiles 
ADD CONSTRAINT valid_sso_profile CHECK (
    sso_profile IS NULL OR (
        sso_profile ? 'enabled' AND
        (sso_profile->>'enabled' = 'false' OR (
            sso_profile ? 'oidc' AND
            sso_profile->'oidc' ? 'issuer' AND
            sso_profile->'oidc' ? 'clientId'
        ))
    )
);

-- Or use a domain type with validation function
CREATE DOMAIN sso_profile_json AS JSONB
    CHECK (validate_sso_profile(VALUE));
```

---

#### 🟠 HIGH-DB-002: No `user_lifecycle_audit` Table

**Problem:** Spec mentions it in retention table but no schema defined.

**Required:**

```sql
CREATE TABLE user_lifecycle_audit (
    id SERIAL PRIMARY KEY,
    user_uid VARCHAR(255) NOT NULL,
    event_type VARCHAR(50) NOT NULL CHECK (event_type IN (
        'created', 'updated', 'password_reset', 'moved_org',
        'added_to_group', 'removed_from_group', 'suspended', 
        'unsuspended', 'terminated', 'reinstated'
    )),
    performed_by VARCHAR(255) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    old_values JSONB,
    new_values JSONB,
    client_ip INET,
    user_agent TEXT
);

CREATE INDEX idx_lifecycle_user ON user_lifecycle_audit(user_uid);
CREATE INDEX idx_lifecycle_type ON user_lifecycle_audit(event_type);
CREATE INDEX idx_lifecycle_time ON user_lifecycle_audit(timestamp);
```

---

#### 🟠 HIGH-DB-003: No Foreign Key from `qr_issuance_audit` to `users`

**Problem:** `user_uid` is just VARCHAR, no referential integrity.

**Impact:** Orphaned audit records if user deleted.

**Required:**

```sql
-- After creating users table:
ALTER TABLE qr_issuance_audit
ADD CONSTRAINT fk_qr_audit_user 
FOREIGN KEY (user_uid) REFERENCES users(uid)
ON DELETE CASCADE;  -- Or SET NULL depending on retention policy
```

---

#### 🟠 HIGH-DB-004: Missing `admin_auth_audit` Table

**Problem:** Mentioned in spec, no schema.

**Required:**

```sql
CREATE TABLE admin_auth_audit (
    id SERIAL PRIMARY KEY,
    admin_uid VARCHAR(255) NOT NULL,
    action VARCHAR(50) NOT NULL CHECK (action IN (
        'login_success', 'login_failure', 'logout', 
        'token_refresh', 'session_expired'
    )),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    client_ip INET NOT NULL,
    user_agent TEXT,
    session_id VARCHAR(255),
    oidc_subject VARCHAR(255),
    failure_reason VARCHAR(100)
);

CREATE INDEX idx_admin_auth_user ON admin_auth_audit(admin_uid);
CREATE INDEX idx_admin_auth_time ON admin_auth_audit(timestamp);
```

---

#### 🟠 HIGH-DB-005: No `orgprofile_audit` Table

**Problem:** Mentioned in retention but not defined.

**Required:**

```sql
CREATE TABLE orgprofile_audit (
    id SERIAL PRIMARY KEY,
    org_profile_id UUID NOT NULL,
    action VARCHAR(20) NOT NULL CHECK (action IN ('created', 'updated', 'deleted')),
    performed_by VARCHAR(255) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    old_values JSONB,
    new_values JSONB,
    client_ip INET
);

CREATE INDEX idx_orgprofile_audit_org ON orgprofile_audit(org_profile_id);
```

---

### 2.4 Database Gaps — MEDIUM

#### 🟡 MEDIUM-DB-001: No `updated_at` Trigger

**Problem:** `org_profiles.updated_at` defined but no trigger to auto-update.

**Required:**

```sql
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_org_profiles_updated
    BEFORE UPDATE ON org_profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();
```

---

#### 🟡 MEDIUM-DB-002: No Partitioning Strategy for Audit Tables

**Problem:** Audit tables will grow unbounded.

**Required:**

```sql
-- Partition by month for retention management
CREATE TABLE qr_issuance_audit (
    -- columns
) PARTITION BY RANGE (issued_at);

CREATE TABLE qr_issuance_audit_2025_01 
    PARTITION OF qr_issuance_audit
    FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');
```

---

#### 🟡 MEDIUM-DB-003: No Soft Delete for Users

**Problem:** Termination physically removes LDAP entry. Need soft delete for compliance.

**Required:**

```sql
-- Add to users table
deleted_at TIMESTAMP WITH TIME ZONE,
deletion_type VARCHAR(20) CHECK (deletion_type IN ('soft', 'hard', 'gdpr')),

-- Soft delete keeps record, hard delete removes after retention
```

---

#### 🟡 MEDIUM-DB-004: Missing Indexes for Common Queries

**Problem:** Spec indexes are incomplete.

**Required additional indexes:**

```sql
-- For audit queries
CREATE INDEX idx_qr_audit_issued_at ON qr_issuance_audit(issued_at DESC);
CREATE INDEX idx_qr_audit_issued_by ON qr_issuance_audit(issued_by);

-- For termination queries
CREATE INDEX idx_termination_time ON termination_events(timestamp DESC);
CREATE INDEX idx_termination_by ON termination_events(terminated_by);

-- For auth failure analysis
CREATE INDEX idx_auth_failure_time ON auth_failure_audit(timestamp DESC);
CREATE INDEX idx_auth_failure_reason ON auth_failure_audit(failure_reason);
```

---

## Part 3: LDAP Schema Extraction & Audit

### 3.1 Documented LDAP Structure

```
dc=example,dc=com                          (Base DN)
│
├── ou=org                                 (Organization Units)
│   ├── ou=Engineering
│   ├── ou=Sales
│   └── ou=HR
│
├── ou=people                              (User Entries)
│   ├── uid=alice
│   │   ├── cn: Alice Smith
│   │   ├── mail: alice@example.com
│   │   ├── userPassword: {SSHA}...
│   │   └── memberOf: cn=Staff,ou=groups
│   └── uid=bob
│
└── ou=groups                              (Group Entries)
    ├── cn=IT-Admins
    ├── cn=Staff
    └── cn=ServiceStaff
```

### 3.2 LDAP Schema Gaps — CRITICAL

#### 🔴 CRITICAL-LDAP-001: No Formal Object Classes Defined

**Problem:** User entries have no defined objectClass. What schema are we using?

**Impact:** 
- Cannot validate entries
- LDAP replication may fail
- Authentik sync may not work

**Required:**

```ldif
# Custom objectClass for Azblink users
dn: cn=azblinkUser,cn=schema,cn=config
objectClass: olcSchemaConfig
cn: azblinkUser
olcObjectClasses: ( 1.3.6.1.4.1.XXXXX.1.1 
    NAME 'azblinkUser'
    DESC 'Azblink Directory User'
    SUP inetOrgPerson
    STRUCTURAL
    MUST ( uid $ cn $ mail )
    MAY ( telephoneNumber $ mobile $ jpegPhoto $ 
          azblinkStatus $ azblinkLastLogin $ 
          azblinkProvisionedAt $ azblinkOrgDN ) )
```

---

#### 🔴 CRITICAL-LDAP-002: No User Status Attribute

**Problem:** How do we mark suspended/terminated users in LDAP?

**Options:**
1. Use `userAccountControl` (AD-style) — Not standard OpenLDAP
2. Use `nsAccountLock` (389DS-style) — Requires schema
3. Custom attribute `azblinkStatus`

**Required:**

```ldif
# Custom attribute for user status
dn: cn=azblinkStatus,cn=schema,cn=config
olcAttributeTypes: ( 1.3.6.1.4.1.XXXXX.1.2.1
    NAME 'azblinkStatus'
    DESC 'User account status: active, suspended, terminated'
    EQUALITY caseIgnoreMatch
    SYNTAX 1.3.6.1.4.1.1466.115.121.1.15
    SINGLE-VALUE )
```

---

### 3.3 LDAP Schema Gaps — HIGH

#### 🟠 HIGH-LDAP-001: User-Org Association Not Defined

**Problem:** How is user linked to org? By DN placement? By attribute?

**Options:**
1. **DN-based:** `uid=alice,ou=Engineering,ou=org,dc=example,dc=com`
2. **Attribute-based:** `azblinkOrgDN: ou=Engineering,ou=org,dc=example,dc=com`

**Current spec is inconsistent:** Shows users under `ou=people` but also mentions `move_org` operation.

**Recommendation:** Use attribute-based for flexibility:

```ldif
azblinkOrgDN: ou=Engineering,ou=org,dc=example,dc=com
```

---

#### 🟠 HIGH-LDAP-002: Group Membership Schema Unclear

**Problem:** Using `memberOf` attribute but:
- Is it maintained by overlay or manually?
- Forward reference (`member` in group) or back-reference only?

**Required configuration:**

```ldif
# memberOf overlay configuration
dn: olcOverlay=memberof,olcDatabase={1}mdb,cn=config
objectClass: olcOverlayConfig
objectClass: olcMemberOf
olcOverlay: memberof
olcMemberOfDangling: ignore
olcMemberOfRefInt: TRUE
olcMemberOfGroupOC: groupOfNames
olcMemberOfMemberAD: member
olcMemberOfMemberOfAD: memberOf
```

---

#### 🟠 HIGH-LDAP-003: No Access Control (ACL) Defined

**Problem:** Who can read/write what? No ACLs in spec.

**Required:**

```ldif
# Users can read own entry, change own password
olcAccess: to dn.children="ou=people,dc=example,dc=com"
    by self write
    by dn="cn=admin,dc=example,dc=com" write
    by dn="cn=directory-portal,dc=example,dc=com" write
    by * read

# Groups readable by all authenticated
olcAccess: to dn.children="ou=groups,dc=example,dc=com"
    by dn="cn=admin,dc=example,dc=com" write
    by users read

# Password only changeable by self or admin
olcAccess: to attrs=userPassword
    by self write
    by dn="cn=admin,dc=example,dc=com" write
    by anonymous auth
    by * none
```

---

#### 🟠 HIGH-LDAP-004: Password Policy Not Defined

**Problem:** No LDAP password policy for complexity, history, lockout.

**Required:**

```ldif
# Password policy overlay
dn: ou=pwpolicies,dc=example,dc=com
objectClass: organizationalUnit
ou: pwpolicies

dn: cn=default,ou=pwpolicies,dc=example,dc=com
objectClass: pwdPolicy
objectClass: device
cn: default
pwdAttribute: userPassword
pwdMinAge: 0
pwdMaxAge: 7776000        # 90 days
pwdInHistory: 5
pwdCheckQuality: 2
pwdMinLength: 12
pwdExpireWarning: 604800  # 7 days
pwdGraceAuthNLimit: 3
pwdLockout: TRUE
pwdLockoutDuration: 1800  # 30 minutes
pwdMaxFailure: 5
pwdFailureCountInterval: 300
```

---

### 3.4 LDAP Schema Gaps — MEDIUM

#### 🟡 MEDIUM-LDAP-001: No Standard Attributes Mapping

**Problem:** Which inetOrgPerson attributes are used?

**Required mapping:**

```yaml
LDAP_USER_ATTRIBUTE_MAP:
  uid: uid                    # Required, unique identifier
  cn: cn                      # Required, display name
  givenName: givenName        # Optional, first name
  sn: sn                      # Optional, surname
  mail: mail                  # Required, email
  telephoneNumber: telephoneNumber
  mobile: mobile
  title: title
  departmentNumber: departmentNumber
  employeeNumber: employeeNumber
  jpegPhoto: jpegPhoto        # Profile photo
```

---

#### 🟡 MEDIUM-LDAP-002: No Org Unit Schema

**Problem:** `ou=org` contains nested OUs but no attributes defined.

**Required:**

```ldif
# Organization unit with metadata
dn: ou=Engineering,ou=org,dc=example,dc=com
objectClass: organizationalUnit
objectClass: top
ou: Engineering
description: Engineering Department
businessCategory: Technology
```

---

#### 🟡 MEDIUM-LDAP-003: No Service Account for Portal

**Problem:** Spec shows `cn=admin` for binds. Should have dedicated service account.

**Required:**

```ldif
dn: cn=directory-portal,ou=services,dc=example,dc=com
objectClass: simpleSecurityObject
objectClass: organizationalRole
cn: directory-portal
description: Service account for Directory Portal
userPassword: <hashed>
```

---

## Part 4: Cross-Cutting Concerns

### 4.1 API ↔ Database Mismatches

| Issue | API Says | DB Has | Impact |
|-------|----------|--------|--------|
| User status | Suspend/Unsuspend endpoints | No status column | Cannot persist suspension |
| QR revocation | `POST /revoke` | Audit table only | Cannot actually revoke |
| Password reset | Endpoint exists | No reset token table | How is reset done? |
| User groups | Endpoint to add/remove | No junction table | LDAP only? |

### 4.2 API ↔ LDAP Mismatches

| Issue | API Says | LDAP Has | Impact |
|-------|----------|----------|--------|
| User org | `move_org` endpoint | DN-based placement? | Requires LDAP modrdn |
| User status | active/suspended/terminated | No status attribute | Cannot filter by status |
| Group membership | Endpoints defined | memberOf overlay? | May not sync properly |

### 4.3 Business Logic Gaps

| Gap | Description | Impact |
|-----|-------------|--------|
| **Terminated user recovery** | No "reinstate" endpoint | Cannot undo termination |
| **Session management** | No session table/endpoints | Cannot list/revoke sessions |
| **MFA enrollment** | Delegated to Authentik only | Cannot manage via Portal |
| **Password complexity** | No validation rules in API | Weak passwords allowed |
| **Email verification** | No workflow defined | Unverified emails in system |
| **Invitation flow** | No invite token/workflow | Manual QR distribution only |

---

## Part 5: Production Readiness Assessment

### 5.1 Security Gaps

| Gap | Severity | Status |
|-----|----------|--------|
| No CSRF protection defined | High | ❌ Missing |
| No Content-Security-Policy headers | Medium | ❌ Missing |
| No input validation schemas | Critical | ❌ Missing |
| No SQL injection prevention documented | High | ⚠️ Assumed |
| No LDAP injection prevention documented | High | ⚠️ Assumed |
| No secrets rotation mechanism | Medium | ❌ Missing |

### 5.2 Operational Gaps

| Gap | Severity | Status |
|-----|----------|--------|
| No database migration versioning | High | ❌ Missing |
| No rollback procedures | High | ❌ Missing |
| No blue-green deployment support | Medium | ❌ Missing |
| No metrics/observability endpoints | High | ❌ Missing |
| No structured logging format | Medium | ❌ Missing |
| No distributed tracing | Low | ❌ Missing |

### 5.3 Scalability Gaps

| Gap | Severity | Status |
|-----|----------|--------|
| No connection pooling config | Medium | ❌ Missing |
| No LDAP connection pool | High | ❌ Missing |
| No read replica support | Medium | ❌ Missing |
| No caching strategy | Medium | ❌ Missing |
| No async operation queue | Medium | ❌ Missing |

---

## Part 6: Recommended Action Plan

### Phase 1: Critical Fixes (Block Production)

1. **Define complete API request/response schemas** — 5 days
2. **Add token consumption endpoint** — 1 day
3. **Create missing database tables (users, provisioning_tokens)** — 2 days
4. **Define LDAP objectClass and custom attributes** — 2 days
5. **Add pagination to all list endpoints** — 2 days

### Phase 2: High Priority (Before Beta)

1. **Add idempotency keys** — 1 day
2. **Add user self-service endpoints** — 2 days
3. **Add filtering/search to user list** — 1 day
4. **Add LDAP ACLs and password policy** — 2 days
5. **Add all audit tables with proper FKs** — 2 days
6. **Add API versioning strategy** — 1 day

### Phase 3: Medium Priority (Before GA)

1. **Add rate limit headers** — 0.5 day
2. **Add health check details** — 0.5 day
3. **Add bulk operations** — 2 days
4. **Add webhook support** — 3 days
5. **Add database partitioning** — 2 days

---

## Appendix: Complete OpenAPI Specification (Draft)

See separate file: `Directory_Portal_OpenAPI_v4.2.yaml`

---

## Appendix: Complete SQL Schema (Draft)

See separate file: `Directory_Portal_Schema_v4.2.sql`

---

## Appendix: LDAP Schema (Draft)

See separate file: `Directory_Portal_LDAP_Schema.ldif`
