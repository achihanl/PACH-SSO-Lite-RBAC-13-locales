-- =============================================================================
-- Azblink Directory Portal — Database Schema v4.2
-- =============================================================================
-- This schema addresses all gaps identified in the technical audit.
-- Designed for PostgreSQL 15+
-- =============================================================================

-- -----------------------------------------------------------------------------
-- EXTENSIONS
-- -----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- -----------------------------------------------------------------------------
-- CUSTOM TYPES
-- -----------------------------------------------------------------------------
CREATE TYPE user_status AS ENUM ('active', 'suspended', 'terminated');
CREATE TYPE qr_type AS ENUM ('unified', 'uc_only', 'sso_only');
CREATE TYPE lifecycle_event AS ENUM (
    'created', 'updated', 'password_reset', 'moved_org',
    'added_to_group', 'removed_from_group', 
    'suspended', 'unsuspended', 'terminated', 'reinstated'
);
CREATE TYPE suspension_action AS ENUM ('suspend', 'unsuspend');
CREATE TYPE breakglass_mode AS ENUM ('bootstrap_only', 'admin_recovery');

-- -----------------------------------------------------------------------------
-- TABLE: users (Shadow table for LDAP users)
-- -----------------------------------------------------------------------------
-- This table mirrors LDAP user entries for:
-- 1. Faster queries than LDAP
-- 2. Status tracking (LDAP doesn't have good status field)
-- 3. Foreign key relationships
-- 4. Audit trail
-- -----------------------------------------------------------------------------
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Identity (mirrors LDAP)
    uid VARCHAR(32) NOT NULL UNIQUE,
    ldap_dn VARCHAR(500) NOT NULL UNIQUE,
    cn VARCHAR(255) NOT NULL,
    mail VARCHAR(255) NOT NULL UNIQUE,
    
    -- Organization
    org_profile_id UUID,  -- FK added after org_profiles table
    org_dn VARCHAR(500),
    
    -- Status
    status user_status NOT NULL DEFAULT 'active',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by VARCHAR(255),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Suspension
    suspended_at TIMESTAMP WITH TIME ZONE,
    suspended_by VARCHAR(255),
    suspension_reason VARCHAR(255),
    
    -- Termination
    terminated_at TIMESTAMP WITH TIME ZONE,
    terminated_by VARCHAR(255),
    termination_reason VARCHAR(255),
    
    -- Reinstatement (if previously terminated)
    reinstated_at TIMESTAMP WITH TIME ZONE,
    reinstated_by VARCHAR(255),
    
    -- Activity tracking
    last_login_at TIMESTAMP WITH TIME ZONE,
    last_qr_issued_at TIMESTAMP WITH TIME ZONE,
    login_count INTEGER DEFAULT 0,
    
    -- Soft delete support
    deleted_at TIMESTAMP WITH TIME ZONE,
    deletion_type VARCHAR(20) CHECK (deletion_type IN ('soft', 'hard', 'gdpr')),
    
    -- Extensible metadata
    metadata JSONB DEFAULT '{}',
    
    -- Constraints
    CONSTRAINT valid_status_transition CHECK (
        (status = 'active' AND terminated_at IS NULL) OR
        (status = 'suspended' AND suspended_at IS NOT NULL AND terminated_at IS NULL) OR
        (status = 'terminated' AND terminated_at IS NOT NULL)
    )
);

-- Indexes for users
CREATE INDEX idx_users_status ON users(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_org ON users(org_profile_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_org_dn ON users(org_dn) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_mail ON users(mail) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_created ON users(created_at DESC);
CREATE INDEX idx_users_search ON users USING gin(
    to_tsvector('english', uid || ' ' || cn || ' ' || COALESCE(mail, ''))
) WHERE deleted_at IS NULL;

-- -----------------------------------------------------------------------------
-- TABLE: org_profiles
-- -----------------------------------------------------------------------------
CREATE TABLE org_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Organization reference
    org_dn VARCHAR(500) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    
    -- Factory-set entitlements (licensed apps)
    entitlements JSONB DEFAULT '[]',
    
    -- SSO configuration
    sso_profile JSONB DEFAULT '{"enabled": false}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Versioning for optimistic locking
    version INTEGER DEFAULT 1,
    
    -- Constraints
    CONSTRAINT valid_entitlements CHECK (jsonb_typeof(entitlements) = 'array'),
    CONSTRAINT valid_sso_profile CHECK (
        sso_profile IS NULL OR (
            sso_profile ? 'enabled' AND
            (sso_profile->>'enabled' = 'false' OR (
                sso_profile ? 'oidc' AND
                sso_profile->'oidc' ? 'issuer' AND
                sso_profile->'oidc' ? 'clientId'
            ))
        )
    )
);

-- Add FK from users to org_profiles
ALTER TABLE users 
ADD CONSTRAINT fk_users_org_profile 
FOREIGN KEY (org_profile_id) REFERENCES org_profiles(id) 
ON DELETE SET NULL;

-- Index for org_profiles
CREATE INDEX idx_org_profiles_sso ON org_profiles((sso_profile->>'enabled'));

-- -----------------------------------------------------------------------------
-- TABLE: provisioning_tokens (One-time QR tokens)
-- -----------------------------------------------------------------------------
-- Separate from audit - this is the source of truth for token validity
-- -----------------------------------------------------------------------------
CREATE TABLE provisioning_tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Token identification
    token_hash VARCHAR(64) NOT NULL UNIQUE,  -- SHA-256 of actual token
    
    -- User reference
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_uid VARCHAR(32) NOT NULL,
    
    -- Token metadata
    qr_type qr_type NOT NULL,
    payload_version VARCHAR(20) DEFAULT 'v2',
    
    -- Lifecycle
    issued_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    issued_by VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    
    -- Consumption
    consumed_at TIMESTAMP WITH TIME ZONE,
    consumed_by_device_id VARCHAR(255),
    consumed_from_ip INET,
    
    -- Revocation
    revoked_at TIMESTAMP WITH TIME ZONE,
    revoked_by VARCHAR(255),
    revoked_reason VARCHAR(100),
    
    -- Integrity
    payload_hash VARCHAR(64),  -- For detecting tampering
    
    -- Constraints
    CONSTRAINT token_lifecycle CHECK (
        (consumed_at IS NULL AND revoked_at IS NULL) OR  -- Valid
        (consumed_at IS NOT NULL AND revoked_at IS NULL) OR  -- Consumed
        (revoked_at IS NOT NULL)  -- Revoked (may or may not be consumed)
    ),
    CONSTRAINT expires_after_issued CHECK (expires_at > issued_at)
);

-- Indexes for provisioning_tokens
CREATE INDEX idx_tokens_user ON provisioning_tokens(user_uid);
CREATE INDEX idx_tokens_user_id ON provisioning_tokens(user_id);
CREATE INDEX idx_tokens_hash ON provisioning_tokens(token_hash);
CREATE INDEX idx_tokens_active ON provisioning_tokens(expires_at) 
    WHERE consumed_at IS NULL AND revoked_at IS NULL;
CREATE INDEX idx_tokens_issued ON provisioning_tokens(issued_at DESC);

-- -----------------------------------------------------------------------------
-- TABLE: qr_issuance_audit (Audit log for QR generation)
-- -----------------------------------------------------------------------------
CREATE TABLE qr_issuance_audit (
    id SERIAL PRIMARY KEY,
    
    -- User reference
    user_uid VARCHAR(255) NOT NULL,
    org_dn VARCHAR(500),
    
    -- Issuance details
    issued_by VARCHAR(255) NOT NULL,
    issued_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Token reference (hash only, for privacy)
    token_hash VARCHAR(64) NOT NULL,
    token_id UUID REFERENCES provisioning_tokens(id) ON DELETE SET NULL,
    
    -- Token lifecycle
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    qr_type qr_type NOT NULL DEFAULT 'unified',
    
    -- Consumption (denormalized from tokens for query efficiency)
    consumed BOOLEAN DEFAULT FALSE,
    consumed_at TIMESTAMP WITH TIME ZONE,
    consumed_reason VARCHAR(50),  -- 'normal', 'user_terminated', 'admin_revoked', 'expired'
    
    -- Client info
    client_ip INET,
    user_agent TEXT,
    
    -- Request context
    request_id UUID,  -- Correlation ID
    
    CONSTRAINT valid_consumed CHECK (
        (consumed = FALSE AND consumed_at IS NULL) OR
        (consumed = TRUE AND consumed_at IS NOT NULL)
    )
) PARTITION BY RANGE (issued_at);

-- Create partitions for current and next 12 months
DO $$
DECLARE
    start_date DATE := DATE_TRUNC('month', CURRENT_DATE);
    partition_date DATE;
    partition_name TEXT;
BEGIN
    FOR i IN 0..12 LOOP
        partition_date := start_date + (i || ' months')::INTERVAL;
        partition_name := 'qr_issuance_audit_' || TO_CHAR(partition_date, 'YYYY_MM');
        
        EXECUTE format(
            'CREATE TABLE IF NOT EXISTS %I PARTITION OF qr_issuance_audit
             FOR VALUES FROM (%L) TO (%L)',
            partition_name,
            partition_date,
            partition_date + INTERVAL '1 month'
        );
    END LOOP;
END $$;

-- Indexes for qr_issuance_audit
CREATE INDEX idx_qr_audit_user ON qr_issuance_audit(user_uid);
CREATE INDEX idx_qr_audit_token ON qr_issuance_audit(token_hash);
CREATE INDEX idx_qr_audit_issued_at ON qr_issuance_audit(issued_at DESC);
CREATE INDEX idx_qr_audit_issued_by ON qr_issuance_audit(issued_by);
CREATE INDEX idx_qr_audit_consumed ON qr_issuance_audit(consumed, expires_at) 
    WHERE consumed = FALSE;

-- -----------------------------------------------------------------------------
-- TABLE: user_lifecycle_audit
-- -----------------------------------------------------------------------------
CREATE TABLE user_lifecycle_audit (
    id SERIAL PRIMARY KEY,
    
    -- User reference
    user_uid VARCHAR(255) NOT NULL,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    -- Event details
    event_type lifecycle_event NOT NULL,
    performed_by VARCHAR(255) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Change tracking
    old_values JSONB,
    new_values JSONB,
    
    -- Client info
    client_ip INET,
    user_agent TEXT,
    
    -- Request context
    request_id UUID
) PARTITION BY RANGE (timestamp);

-- Create partitions
DO $$
DECLARE
    start_date DATE := DATE_TRUNC('month', CURRENT_DATE);
    partition_date DATE;
    partition_name TEXT;
BEGIN
    FOR i IN 0..12 LOOP
        partition_date := start_date + (i || ' months')::INTERVAL;
        partition_name := 'user_lifecycle_audit_' || TO_CHAR(partition_date, 'YYYY_MM');
        
        EXECUTE format(
            'CREATE TABLE IF NOT EXISTS %I PARTITION OF user_lifecycle_audit
             FOR VALUES FROM (%L) TO (%L)',
            partition_name,
            partition_date,
            partition_date + INTERVAL '1 month'
        );
    END LOOP;
END $$;

-- Indexes for user_lifecycle_audit
CREATE INDEX idx_lifecycle_user ON user_lifecycle_audit(user_uid);
CREATE INDEX idx_lifecycle_type ON user_lifecycle_audit(event_type);
CREATE INDEX idx_lifecycle_time ON user_lifecycle_audit(timestamp DESC);
CREATE INDEX idx_lifecycle_performed_by ON user_lifecycle_audit(performed_by);

-- -----------------------------------------------------------------------------
-- TABLE: termination_events
-- -----------------------------------------------------------------------------
CREATE TABLE termination_events (
    id SERIAL PRIMARY KEY,
    
    -- User reference
    user_uid VARCHAR(255) NOT NULL,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    -- Termination details
    terminated_by VARCHAR(255) NOT NULL,
    reason VARCHAR(255) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Actions taken (detailed breakdown)
    actions_taken JSONB NOT NULL,
    ldap_disabled BOOLEAN,
    tokens_revoked INTEGER,
    authentik_sessions_revoked INTEGER,
    uc_sessions_terminated INTEGER,
    
    -- Errors (if any step failed)
    errors JSONB,
    partial_success BOOLEAN DEFAULT FALSE,
    
    -- Client info
    client_ip INET,
    user_agent TEXT,
    request_id UUID
);

-- Indexes for termination_events
CREATE INDEX idx_termination_user ON termination_events(user_uid);
CREATE INDEX idx_termination_time ON termination_events(timestamp DESC);
CREATE INDEX idx_termination_by ON termination_events(terminated_by);

-- -----------------------------------------------------------------------------
-- TABLE: suspension_events
-- -----------------------------------------------------------------------------
CREATE TABLE suspension_events (
    id SERIAL PRIMARY KEY,
    
    -- User reference
    user_uid VARCHAR(255) NOT NULL,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    -- Suspension details
    action suspension_action NOT NULL,
    performed_by VARCHAR(255) NOT NULL,
    reason VARCHAR(255),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Client info
    client_ip INET,
    user_agent TEXT,
    request_id UUID
);

-- Indexes for suspension_events
CREATE INDEX idx_suspension_user ON suspension_events(user_uid);
CREATE INDEX idx_suspension_time ON suspension_events(timestamp DESC);
CREATE INDEX idx_suspension_action ON suspension_events(action);

-- -----------------------------------------------------------------------------
-- TABLE: auth_failure_audit
-- -----------------------------------------------------------------------------
CREATE TABLE auth_failure_audit (
    id SERIAL PRIMARY KEY,
    
    -- Attempted identity
    username VARCHAR(255),
    
    -- Failure details
    failure_reason VARCHAR(100) NOT NULL,
    endpoint VARCHAR(255),
    
    -- Timing
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Client info
    client_ip INET NOT NULL,
    user_agent TEXT,
    
    -- Request context
    request_id UUID,
    
    -- Rate limiting tracking
    consecutive_failures INTEGER DEFAULT 1,
    account_locked_until TIMESTAMP WITH TIME ZONE
) PARTITION BY RANGE (timestamp);

-- Create partitions (90-day retention, so 3 months)
DO $$
DECLARE
    start_date DATE := DATE_TRUNC('month', CURRENT_DATE);
    partition_date DATE;
    partition_name TEXT;
BEGIN
    FOR i IN 0..3 LOOP
        partition_date := start_date + (i || ' months')::INTERVAL;
        partition_name := 'auth_failure_audit_' || TO_CHAR(partition_date, 'YYYY_MM');
        
        EXECUTE format(
            'CREATE TABLE IF NOT EXISTS %I PARTITION OF auth_failure_audit
             FOR VALUES FROM (%L) TO (%L)',
            partition_name,
            partition_date,
            partition_date + INTERVAL '1 month'
        );
    END LOOP;
END $$;

-- Indexes for auth_failure_audit
CREATE INDEX idx_auth_failure_ip ON auth_failure_audit(client_ip, timestamp DESC);
CREATE INDEX idx_auth_failure_user ON auth_failure_audit(username) WHERE username IS NOT NULL;
CREATE INDEX idx_auth_failure_time ON auth_failure_audit(timestamp DESC);
CREATE INDEX idx_auth_failure_reason ON auth_failure_audit(failure_reason);

-- -----------------------------------------------------------------------------
-- TABLE: admin_auth_audit
-- -----------------------------------------------------------------------------
CREATE TABLE admin_auth_audit (
    id SERIAL PRIMARY KEY,
    
    -- Admin identity
    admin_uid VARCHAR(255) NOT NULL,
    oidc_subject VARCHAR(255),
    
    -- Action details
    action VARCHAR(50) NOT NULL CHECK (action IN (
        'login_success', 'login_failure', 'logout', 
        'token_refresh', 'session_expired', 'mfa_challenge',
        'mfa_success', 'mfa_failure'
    )),
    
    -- Timing
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Session
    session_id VARCHAR(255),
    
    -- Failure details (if applicable)
    failure_reason VARCHAR(100),
    
    -- Client info
    client_ip INET NOT NULL,
    user_agent TEXT,
    
    -- Request context
    request_id UUID
) PARTITION BY RANGE (timestamp);

-- Create partitions (1-year retention, so 13 months)
DO $$
DECLARE
    start_date DATE := DATE_TRUNC('month', CURRENT_DATE);
    partition_date DATE;
    partition_name TEXT;
BEGIN
    FOR i IN 0..13 LOOP
        partition_date := start_date + (i || ' months')::INTERVAL;
        partition_name := 'admin_auth_audit_' || TO_CHAR(partition_date, 'YYYY_MM');
        
        EXECUTE format(
            'CREATE TABLE IF NOT EXISTS %I PARTITION OF admin_auth_audit
             FOR VALUES FROM (%L) TO (%L)',
            partition_name,
            partition_date,
            partition_date + INTERVAL '1 month'
        );
    END LOOP;
END $$;

-- Indexes for admin_auth_audit
CREATE INDEX idx_admin_auth_user ON admin_auth_audit(admin_uid);
CREATE INDEX idx_admin_auth_time ON admin_auth_audit(timestamp DESC);
CREATE INDEX idx_admin_auth_session ON admin_auth_audit(session_id) WHERE session_id IS NOT NULL;

-- -----------------------------------------------------------------------------
-- TABLE: orgprofile_audit
-- -----------------------------------------------------------------------------
CREATE TABLE orgprofile_audit (
    id SERIAL PRIMARY KEY,
    
    -- Profile reference
    org_profile_id UUID NOT NULL,
    org_dn VARCHAR(500),
    
    -- Action details
    action VARCHAR(20) NOT NULL CHECK (action IN ('created', 'updated', 'deleted')),
    performed_by VARCHAR(255) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Change tracking
    old_values JSONB,
    new_values JSONB,
    
    -- Client info
    client_ip INET,
    request_id UUID
);

-- Indexes for orgprofile_audit
CREATE INDEX idx_orgprofile_audit_org ON orgprofile_audit(org_profile_id);
CREATE INDEX idx_orgprofile_audit_time ON orgprofile_audit(timestamp DESC);

-- -----------------------------------------------------------------------------
-- TABLE: breakglass_audit
-- -----------------------------------------------------------------------------
CREATE TABLE breakglass_audit (
    id SERIAL PRIMARY KEY,
    
    -- Activation details
    activated_by VARCHAR(255) NOT NULL,
    mode breakglass_mode NOT NULL,
    reason VARCHAR(500),
    
    -- Timing
    activated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    deactivated_at TIMESTAMP WITH TIME ZONE,
    deactivated_by VARCHAR(255),
    
    -- Usage tracking
    requests_made INTEGER DEFAULT 0,
    
    -- Context
    client_ip INET,
    
    CONSTRAINT expires_after_activated CHECK (expires_at > activated_at)
);

-- Indexes for breakglass_audit
CREATE INDEX idx_breakglass_time ON breakglass_audit(activated_at DESC);
CREATE INDEX idx_breakglass_active ON breakglass_audit(expires_at) 
    WHERE deactivated_at IS NULL;

-- -----------------------------------------------------------------------------
-- TABLE: idempotency_keys (For idempotent API requests)
-- -----------------------------------------------------------------------------
CREATE TABLE idempotency_keys (
    key UUID PRIMARY KEY,
    
    -- Request details
    endpoint VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    request_hash VARCHAR(64),  -- Hash of request body
    
    -- Response
    status_code INTEGER NOT NULL,
    response_body JSONB,
    
    -- Timing
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() + INTERVAL '24 hours'
);

-- Index for cleanup
CREATE INDEX idx_idempotency_expires ON idempotency_keys(expires_at);

-- -----------------------------------------------------------------------------
-- TABLE: webhooks (For event notifications)
-- -----------------------------------------------------------------------------
CREATE TABLE webhooks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Configuration
    url VARCHAR(2048) NOT NULL,
    events JSONB NOT NULL,  -- Array of event types
    secret VARCHAR(255) NOT NULL,  -- For HMAC signing
    
    -- Status
    enabled BOOLEAN DEFAULT TRUE,
    
    -- Reliability tracking
    last_success_at TIMESTAMP WITH TIME ZONE,
    last_failure_at TIMESTAMP WITH TIME ZONE,
    consecutive_failures INTEGER DEFAULT 0,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by VARCHAR(255),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_events CHECK (jsonb_typeof(events) = 'array')
);

-- -----------------------------------------------------------------------------
-- TABLE: webhook_deliveries (Delivery log)
-- -----------------------------------------------------------------------------
CREATE TABLE webhook_deliveries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- References
    webhook_id UUID NOT NULL REFERENCES webhooks(id) ON DELETE CASCADE,
    event_type VARCHAR(50) NOT NULL,
    
    -- Payload
    payload JSONB NOT NULL,
    
    -- Delivery details
    attempted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    response_status INTEGER,
    response_body TEXT,
    
    -- Retry tracking
    attempt_number INTEGER DEFAULT 1,
    next_retry_at TIMESTAMP WITH TIME ZONE,
    
    -- Status
    success BOOLEAN
);

-- Indexes for webhook_deliveries
CREATE INDEX idx_webhook_deliveries_webhook ON webhook_deliveries(webhook_id);
CREATE INDEX idx_webhook_deliveries_retry ON webhook_deliveries(next_retry_at) 
    WHERE success = FALSE AND next_retry_at IS NOT NULL;

-- -----------------------------------------------------------------------------
-- TABLE: user_sessions (For session management)
-- -----------------------------------------------------------------------------
CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- User reference
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_uid VARCHAR(32) NOT NULL,
    
    -- Session details
    session_type VARCHAR(20) NOT NULL CHECK (session_type IN ('web', 'mobile', 'desktop', 'api')),
    
    -- Device info
    device_id VARCHAR(255),
    device_name VARCHAR(255),
    platform VARCHAR(50),
    app_version VARCHAR(50),
    os_version VARCHAR(50),
    
    -- Timing
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_active_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    
    -- Revocation
    revoked_at TIMESTAMP WITH TIME ZONE,
    revoked_by VARCHAR(255),
    revoked_reason VARCHAR(100),
    
    -- Client info
    ip_address INET,
    user_agent TEXT
);

-- Indexes for user_sessions
CREATE INDEX idx_sessions_user ON user_sessions(user_id);
CREATE INDEX idx_sessions_active ON user_sessions(expires_at) 
    WHERE revoked_at IS NULL;
CREATE INDEX idx_sessions_device ON user_sessions(device_id) 
    WHERE device_id IS NOT NULL;

-- -----------------------------------------------------------------------------
-- FUNCTIONS
-- -----------------------------------------------------------------------------

-- Function: Update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function: Increment version for optimistic locking
CREATE OR REPLACE FUNCTION increment_version_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.version = OLD.version + 1;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function: Validate SSO profile JSON
CREATE OR REPLACE FUNCTION validate_sso_profile(profile JSONB)
RETURNS BOOLEAN AS $$
BEGIN
    IF profile IS NULL THEN
        RETURN TRUE;
    END IF;
    
    IF NOT (profile ? 'enabled') THEN
        RETURN FALSE;
    END IF;
    
    IF profile->>'enabled' = 'true' THEN
        IF NOT (profile ? 'oidc' AND 
                profile->'oidc' ? 'issuer' AND 
                profile->'oidc' ? 'clientId') THEN
            RETURN FALSE;
        END IF;
    END IF;
    
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- -----------------------------------------------------------------------------
-- TRIGGERS
-- -----------------------------------------------------------------------------

-- Trigger: Auto-update updated_at on users
CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Trigger: Auto-update updated_at on org_profiles
CREATE TRIGGER trg_org_profiles_updated_at
    BEFORE UPDATE ON org_profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Trigger: Increment version on org_profiles
CREATE TRIGGER trg_org_profiles_version
    BEFORE UPDATE ON org_profiles
    FOR EACH ROW
    EXECUTE FUNCTION increment_version_column();

-- Trigger: Auto-update updated_at on webhooks
CREATE TRIGGER trg_webhooks_updated_at
    BEFORE UPDATE ON webhooks
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- -----------------------------------------------------------------------------
-- CLEANUP FUNCTIONS (For scheduled jobs)
-- -----------------------------------------------------------------------------

-- Function: Clean up expired idempotency keys
CREATE OR REPLACE FUNCTION cleanup_expired_idempotency_keys()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM idempotency_keys WHERE expires_at < NOW();
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Function: Clean up expired provisioning tokens
CREATE OR REPLACE FUNCTION cleanup_expired_tokens()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    -- Mark as consumed (expired) rather than delete
    UPDATE provisioning_tokens 
    SET consumed_at = NOW(), 
        revoked_reason = 'expired'
    WHERE expires_at < NOW() 
      AND consumed_at IS NULL 
      AND revoked_at IS NULL;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Function: Clean up old audit records (respects retention policy)
CREATE OR REPLACE FUNCTION vacuum_audit_tables(retention_days INTEGER)
RETURNS TABLE(table_name TEXT, deleted_count BIGINT) AS $$
BEGIN
    -- Auth failures: 90 days
    DELETE FROM auth_failure_audit 
    WHERE timestamp < NOW() - INTERVAL '90 days';
    RETURN QUERY SELECT 'auth_failure_audit'::TEXT, (SELECT COUNT(*) FROM auth_failure_audit)::BIGINT;
    
    -- Admin auth: 1 year
    DELETE FROM admin_auth_audit 
    WHERE timestamp < NOW() - INTERVAL '1 year';
    RETURN QUERY SELECT 'admin_auth_audit'::TEXT, (SELECT COUNT(*) FROM admin_auth_audit)::BIGINT;
    
    -- QR issuance: 2 years
    DELETE FROM qr_issuance_audit 
    WHERE issued_at < NOW() - INTERVAL '2 years';
    RETURN QUERY SELECT 'qr_issuance_audit'::TEXT, (SELECT COUNT(*) FROM qr_issuance_audit)::BIGINT;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- VIEWS (For common queries)
-- -----------------------------------------------------------------------------

-- View: Active users
CREATE VIEW v_active_users AS
SELECT u.*, op.name as org_name, op.entitlements
FROM users u
LEFT JOIN org_profiles op ON u.org_profile_id = op.id
WHERE u.status = 'active' AND u.deleted_at IS NULL;

-- View: Pending QR tokens (not yet consumed/revoked)
CREATE VIEW v_pending_tokens AS
SELECT pt.*, u.cn as user_name, u.mail as user_email
FROM provisioning_tokens pt
JOIN users u ON pt.user_id = u.id
WHERE pt.consumed_at IS NULL 
  AND pt.revoked_at IS NULL 
  AND pt.expires_at > NOW();

-- View: Recent terminations
CREATE VIEW v_recent_terminations AS
SELECT te.*, u.cn as user_name, u.mail as user_email
FROM termination_events te
LEFT JOIN users u ON te.user_id = u.id
ORDER BY te.timestamp DESC
LIMIT 100;

-- -----------------------------------------------------------------------------
-- COMMENTS (Documentation)
-- -----------------------------------------------------------------------------

COMMENT ON TABLE users IS 'Shadow table for LDAP users - provides faster queries and status tracking';
COMMENT ON TABLE org_profiles IS 'Organization profiles with SSO config and factory-set entitlements';
COMMENT ON TABLE provisioning_tokens IS 'One-time QR provisioning tokens';
COMMENT ON TABLE qr_issuance_audit IS 'Audit log for QR code generation (2-year retention)';
COMMENT ON TABLE user_lifecycle_audit IS 'Audit log for user lifecycle events (5-year retention)';
COMMENT ON TABLE termination_events IS 'Detailed termination records (5-year retention)';
COMMENT ON TABLE auth_failure_audit IS 'Authentication failure log (90-day retention)';
COMMENT ON TABLE breakglass_audit IS 'Break-glass activation log (5-year retention)';

COMMENT ON COLUMN users.status IS 'User account status: active, suspended, or terminated';
COMMENT ON COLUMN org_profiles.entitlements IS 'Factory-set list of licensed apps for this org';
COMMENT ON COLUMN org_profiles.sso_profile IS 'SSO configuration including OIDC issuer and client ID';
COMMENT ON COLUMN provisioning_tokens.token_hash IS 'SHA-256 hash of the actual token (never store plaintext)';
