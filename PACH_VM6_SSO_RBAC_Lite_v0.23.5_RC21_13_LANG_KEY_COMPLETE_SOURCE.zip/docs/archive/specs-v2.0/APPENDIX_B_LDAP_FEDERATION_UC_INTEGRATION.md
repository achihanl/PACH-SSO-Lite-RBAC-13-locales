# Appendix B: LDAP Federation and UC Integration Architecture

**Document Type:** Technical Specification Appendix
**Version:** 1.0
**Status:** Draft
**Date:** 2026-01-26
**Related Documents:**
- `docs/prd/PHASE1_UC_CORE_QR_PRD.md`
- `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md`
- `docs/specs/APPENDIX_A_LDAP_SCHEMA_ANALYSIS.md`

---

## 1. Executive Summary

This document specifies the integration architecture between the AZBlink Directory Portal LDAP and the AZBlink UC (Unified Communications) LDAP for SIP and XMPP account provisioning. It evaluates three federation approaches, provides implementation guidance, and establishes the technical contract between the two systems.

### 1.1 Design Constraint

> **UC MUST work even when Authentik is not installed, SSO is never configured, or Phase 2 is never deployed.**

This constraint requires that UC authentication operates independently of the Directory Portal's web authentication layer, relying solely on LDAP for user verification.

### 1.2 Integration Options Summary

| Approach | Complexity | Latency | Consistency | Recommended For |
|----------|------------|---------|-------------|-----------------|
| **A: Shared LDAP** | Low | Lowest | Perfect | Small deployments, single datacenter |
| **B: LDAP Replication** | Medium | Low | Eventual | Multi-datacenter, HA requirements |
| **C: API Federation** | High | Medium | On-demand | Complex environments, custom UC systems |

**Recommendation:** Start with **Approach A (Shared LDAP)** for simplicity; migrate to **Approach B** if HA or geographic distribution is required.

---

## 2. System Context

### 2.1 Component Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              AZBLINK ECOSYSTEM                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────┐         ┌─────────────────────┐                   │
│  │   Directory Portal  │         │      UC Server      │                   │
│  │   (Admin/API)       │         │   (XMPP/SIP)        │                   │
│  └──────────┬──────────┘         └──────────┬──────────┘                   │
│             │                               │                               │
│             │ Read/Write                    │ Auth (Bind)                   │
│             ▼                               ▼                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        LDAP LAYER                                    │   │
│  │                                                                      │   │
│  │   Option A: Single shared LDAP                                       │   │
│  │   Option B: Primary → Replica replication                            │   │
│  │   Option C: Separate LDAPs with API sync                             │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────┐         ┌─────────────────────┐                   │
│  │   Mobile Client     │         │   Authentik (SSO)   │                   │
│  │   (ucChat)          │         │   (Optional)        │                   │
│  └─────────────────────┘         └─────────────────────┘                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Data Flow Requirements

| Flow | Source | Destination | Data | Frequency |
|------|--------|-------------|------|-----------|
| User Creation | Directory Portal | UC LDAP | uid, cn, mail, password | On create |
| Password Change | Directory Portal | UC LDAP | userPassword | On change |
| User Termination | Directory Portal | UC LDAP | status/disable | On terminate |
| UC Authentication | UC Server | LDAP | bind verification | Per login |
| Session Termination | Directory Portal | UC Server | terminate signal | On terminate |

---

## 3. Approach A: Shared LDAP (Recommended)

### 3.1 Architecture

```
┌─────────────────────┐     ┌─────────────────────┐
│   Directory Portal  │     │      UC Server      │
│                     │     │   (XMPP/SIP)        │
└──────────┬──────────┘     └──────────┬──────────┘
           │                           │
           │ LDAP (read/write)         │ LDAP (read/bind)
           │                           │
           └───────────┬───────────────┘
                       │
                       ▼
           ┌───────────────────────┐
           │      OpenLDAP         │
           │   dc=azblink,dc=com   │
           └───────────────────────┘
```

### 3.2 Characteristics

| Aspect | Details |
|--------|---------|
| **Consistency** | Perfect - single source of truth |
| **Latency** | Zero replication delay |
| **Complexity** | Lowest |
| **Failure Mode** | LDAP down = both systems down |
| **Scalability** | Limited by single LDAP instance |

### 3.3 Service Account Configuration

#### Directory Portal Service Account

```ldif
dn: cn=directory-portal,ou=services,dc=azblink,dc=com
objectClass: top
objectClass: simpleSecurityObject
objectClass: organizationalRole
cn: directory-portal
description: Directory Portal backend - full access
userPassword: {SSHA}...
```

**Permissions:** Full read/write to `ou=people`, `ou=groups`, `ou=org`

#### UC Server Service Account

```ldif
dn: cn=uc-server,ou=services,dc=azblink,dc=com
objectClass: top
objectClass: simpleSecurityObject
objectClass: organizationalRole
cn: uc-server
description: UC Server - read and bind verification only
userPassword: {SSHA}...
```

**Permissions:** Read `ou=people`, verify binds (no write)

### 3.4 ACL Configuration for Shared Access

```ldif
# UC Server can read user entries
dn: olcDatabase={1}mdb,cn=config
changetype: modify
add: olcAccess
olcAccess: {2}to dn.children="ou=people,dc=azblink,dc=com"
  by dn="cn=uc-server,ou=services,dc=azblink,dc=com" read
  by dn="cn=directory-portal,ou=services,dc=azblink,dc=com" write
  by users read
```

### 3.5 UC Server LDAP Configuration

```yaml
# UC Server config (ejabberd/prosody style)
ldap:
  servers:
    - ldap.azblink.internal
  port: 389
  use_tls: true
  tls_verify: true

  # Bind credentials
  bind_dn: "cn=uc-server,ou=services,dc=azblink,dc=com"
  bind_password: "${UC_LDAP_BIND_PW}"

  # Search parameters
  base_dn: "ou=people,dc=azblink,dc=com"
  user_filter: "(&(objectClass=inetOrgPerson)(uid=%u)(!(description=TERMINATED))(!(description=SUSPENDED)))"

  # Attribute mapping
  uid_attr: uid
  dn_attr: dn
```

### 3.6 Authentication Flow

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   ucChat    │     │  UC Server  │     │   OpenLDAP  │
│   Client    │     │             │     │             │
└──────┬──────┘     └──────┬──────┘     └──────┬──────┘
       │                   │                   │
       │ XMPP Connect      │                   │
       │ alice@uc.azblink  │                   │
       │──────────────────▶│                   │
       │                   │                   │
       │                   │ Search user       │
       │                   │ (uid=alice)       │
       │                   │──────────────────▶│
       │                   │                   │
       │                   │◀──────────────────│
       │                   │ User DN + attrs   │
       │                   │                   │
       │                   │ Bind as user      │
       │                   │ (verify password) │
       │                   │──────────────────▶│
       │                   │                   │
       │                   │◀──────────────────│
       │                   │ Bind success      │
       │                   │                   │
       │◀──────────────────│                   │
       │ Session established                   │
       │                   │                   │
```

---

## 4. Approach B: LDAP Replication (Syncrepl)

### 4.1 Architecture

```
┌─────────────────────┐                    ┌─────────────────────┐
│   Directory Portal  │                    │      UC Server      │
└──────────┬──────────┘                    └──────────┬──────────┘
           │                                          │
           │ LDAP (read/write)                        │ LDAP (read/bind)
           ▼                                          ▼
┌─────────────────────┐    Syncrepl    ┌─────────────────────┐
│   Primary LDAP      │───────────────▶│   Replica LDAP      │
│   (Directory)       │    (async)     │   (UC Datacenter)   │
│                     │◀───────────────│                     │
└─────────────────────┘    (optional)  └─────────────────────┘
```

### 4.2 Characteristics

| Aspect | Details |
|--------|---------|
| **Consistency** | Eventual (typically < 1 second) |
| **Latency** | Replication delay (configurable) |
| **Complexity** | Medium |
| **Failure Mode** | Replica can serve reads if primary down |
| **Scalability** | Multiple read replicas possible |

### 4.3 When to Use

- **Geographic distribution:** UC server in different datacenter
- **High availability:** Replica provides failover for reads
- **Read scaling:** Multiple UC servers share replica load
- **Network segmentation:** UC in DMZ, Directory in internal network

### 4.4 Syncrepl Configuration

#### Primary (Provider) Configuration

```ldif
# Enable syncprov overlay
dn: olcOverlay=syncprov,olcDatabase={1}mdb,cn=config
objectClass: olcOverlayConfig
objectClass: olcSyncProvConfig
olcOverlay: syncprov
olcSpCheckpoint: 100 10
olcSpSessionlog: 100

# Replication user
dn: cn=replicator,ou=services,dc=azblink,dc=com
objectClass: top
objectClass: simpleSecurityObject
objectClass: organizationalRole
cn: replicator
description: Replication service account
userPassword: {SSHA}...
```

#### Replica (Consumer) Configuration

```ldif
dn: olcDatabase={1}mdb,cn=config
objectClass: olcDatabaseConfig
objectClass: olcMdbConfig
olcDatabase: mdb
olcSuffix: dc=azblink,dc=com
olcRootDN: cn=admin,dc=azblink,dc=com

# Syncrepl configuration
olcSyncRepl: rid=001
  provider=ldap://primary.ldap.azblink.internal:389
  bindmethod=simple
  binddn="cn=replicator,ou=services,dc=azblink,dc=com"
  credentials=replicator_password
  searchbase="dc=azblink,dc=com"
  scope=sub
  schemachecking=on
  type=refreshAndPersist
  retry="60 +"
  interval=00:00:00:10
```

### 4.5 Partial Replication (UC-Specific)

To replicate only user data needed by UC:

```ldif
olcSyncRepl: rid=001
  provider=ldap://primary.ldap.azblink.internal:389
  ...
  searchbase="ou=people,dc=azblink,dc=com"
  filter="(objectClass=inetOrgPerson)"
  attrs="uid,cn,mail,userPassword,description"
```

### 4.6 Failover Configuration

```yaml
# UC Server with failover
ldap:
  servers:
    - replica.ldap.uc.azblink.internal   # Primary (local replica)
    - primary.ldap.azblink.internal      # Fallback (remote primary)

  # Failover settings
  connection_timeout: 5
  retry_delay: 30
```

---

## 5. Approach C: API Federation

### 5.1 Architecture

```
┌─────────────────────┐                    ┌─────────────────────┐
│   Directory Portal  │                    │      UC Server      │
└──────────┬──────────┘                    └──────────┬──────────┘
           │                                          │
           │                 ┌────────────┐           │
           │                 │  Sync API  │           │
           │────────────────▶│  Service   │◀──────────│
           │   Webhook/API   │            │  LDAP     │
           │                 └─────┬──────┘           │
           │                       │                  │
           ▼                       ▼                  ▼
┌─────────────────────┐    ┌─────────────────────┐
│   Directory LDAP    │    │      UC LDAP        │
│   (Primary)         │    │   (Independent)     │
└─────────────────────┘    └─────────────────────┘
```

### 5.2 Characteristics

| Aspect | Details |
|--------|---------|
| **Consistency** | On-demand or scheduled |
| **Latency** | API call + processing time |
| **Complexity** | Highest |
| **Failure Mode** | Sync service failure = drift |
| **Scalability** | Independent scaling |

### 5.3 When to Use

- **Legacy UC system:** UC LDAP cannot be changed
- **Different schemas:** UC requires different attribute mapping
- **Compliance:** Audit requirements mandate separate systems
- **Vendor constraints:** UC system has proprietary LDAP requirements

### 5.4 Sync Service Specification

#### 5.4.1 User Sync API

```yaml
openapi: 3.0.0
info:
  title: UC LDAP Sync API
  version: 1.0.0

paths:
  /sync/users:
    post:
      summary: Sync user to UC LDAP
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/UserSyncRequest'
      responses:
        '200':
          description: User synced successfully
        '409':
          description: Sync conflict

  /sync/users/{uid}:
    delete:
      summary: Remove user from UC LDAP
      parameters:
        - name: uid
          in: path
          required: true
          schema:
            type: string

components:
  schemas:
    UserSyncRequest:
      type: object
      required:
        - uid
        - action
      properties:
        uid:
          type: string
          description: LDAP uid
        action:
          type: string
          enum: [create, update, disable, delete]
        attributes:
          type: object
          properties:
            cn:
              type: string
            mail:
              type: string
            passwordHash:
              type: string
              description: Pre-hashed password (SSHA)
```

#### 5.4.2 Webhook Events (Directory → Sync Service)

```json
{
  "event": "user.created",
  "timestamp": "2026-01-26T10:30:00Z",
  "data": {
    "uid": "alice",
    "dn": "uid=alice,ou=people,dc=azblink,dc=com",
    "attributes": {
      "cn": "Alice Smith",
      "mail": "alice@azblink.com",
      "passwordHash": "{SSHA}..."
    }
  },
  "signature": "hmac-sha256-signature"
}
```

**Event Types:**
| Event | Trigger | UC LDAP Action |
|-------|---------|----------------|
| `user.created` | New user in Directory | Add entry to UC LDAP |
| `user.updated` | Attribute change | Modify UC LDAP entry |
| `user.password_changed` | Password reset | Update userPassword |
| `user.suspended` | User suspended | Disable UC account |
| `user.terminated` | User terminated | Delete or disable UC entry |

#### 5.4.3 Sync Service Implementation

```python
"""
UC LDAP Sync Service

Receives webhooks from Directory Portal and syncs to UC LDAP.
"""

from fastapi import FastAPI, HTTPException
from ldap3 import Server, Connection, MODIFY_REPLACE
import hmac
import hashlib

app = FastAPI()

UC_LDAP_URI = "ldap://uc-ldap.azblink.internal:389"
UC_LDAP_BIND_DN = "cn=sync-service,ou=services,dc=uc,dc=azblink,dc=com"
UC_LDAP_BIND_PW = os.environ["UC_LDAP_BIND_PW"]
UC_LDAP_PEOPLE_DN = "ou=people,dc=uc,dc=azblink,dc=com"

WEBHOOK_SECRET = os.environ["WEBHOOK_SECRET"]


def verify_signature(payload: bytes, signature: str) -> bool:
    expected = hmac.new(
        WEBHOOK_SECRET.encode(),
        payload,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(signature, expected)


def get_uc_ldap_conn():
    server = Server(UC_LDAP_URI)
    conn = Connection(server, UC_LDAP_BIND_DN, UC_LDAP_BIND_PW, auto_bind=True)
    return conn


@app.post("/webhook/user")
async def handle_user_webhook(request: Request):
    payload = await request.body()
    signature = request.headers.get("X-Signature")

    if not verify_signature(payload, signature):
        raise HTTPException(401, "Invalid signature")

    event = json.loads(payload)
    event_type = event["event"]
    data = event["data"]
    uid = data["uid"]

    conn = get_uc_ldap_conn()
    user_dn = f"uid={uid},{UC_LDAP_PEOPLE_DN}"

    try:
        if event_type == "user.created":
            attrs = {
                "objectClass": ["top", "person", "inetOrgPerson"],
                "uid": uid,
                "cn": data["attributes"]["cn"],
                "sn": data["attributes"]["cn"].split()[-1],
                "mail": data["attributes"]["mail"],
                "userPassword": data["attributes"]["passwordHash"],
            }
            conn.add(user_dn, attributes=attrs)

        elif event_type == "user.updated":
            changes = {}
            for attr, value in data["attributes"].items():
                ldap_attr = {"cn": "cn", "mail": "mail"}.get(attr)
                if ldap_attr:
                    changes[ldap_attr] = [(MODIFY_REPLACE, [value])]
            if changes:
                conn.modify(user_dn, changes)

        elif event_type == "user.password_changed":
            conn.modify(user_dn, {
                "userPassword": [(MODIFY_REPLACE, [data["attributes"]["passwordHash"]])]
            })

        elif event_type in ("user.suspended", "user.terminated"):
            conn.modify(user_dn, {
                "userPassword": [(MODIFY_REPLACE, ["{DISABLED}"])]
            })

    finally:
        conn.unbind()

    return {"ok": True}
```

---

## 6. Termination Flow Integration

### 6.1 Complete Termination Sequence

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Admin     │     │  Directory  │     │  UC Server  │     │    LDAP     │
│   Portal    │     │  Backend    │     │             │     │             │
└──────┬──────┘     └──────┬──────┘     └──────┬──────┘     └──────┬──────┘
       │                   │                   │                   │
       │ POST /api/users/{uid}/terminate       │                   │
       │──────────────────▶│                   │                   │
       │                   │                   │                   │
       │                   │ 1. Disable LDAP   │                   │
       │                   │───────────────────│───────────────────▶
       │                   │                   │   userPassword:   │
       │                   │                   │   {DISABLED}      │
       │                   │◀──────────────────│◀──────────────────│
       │                   │                   │                   │
       │                   │ 2. Revoke tokens (PostgreSQL)         │
       │                   │                   │                   │
       │                   │ 3. Call UC terminate API              │
       │                   │──────────────────▶│                   │
       │                   │                   │                   │
       │                   │                   │ Query active      │
       │                   │                   │ sessions          │
       │                   │                   │──────────────────▶│
       │                   │                   │                   │
       │                   │                   │◀──────────────────│
       │                   │                   │                   │
       │                   │                   │ Send termination  │
       │                   │                   │ notice (XMPP)     │
       │                   │                   │──────▶ Client     │
       │                   │                   │                   │
       │                   │                   │ Disconnect        │
       │                   │                   │ sessions          │
       │                   │                   │                   │
       │                   │◀──────────────────│                   │
       │                   │ Sessions terminated                   │
       │                   │                   │                   │
       │                   │ 4. Log termination event              │
       │◀──────────────────│                   │                   │
       │ Termination complete                  │                   │
       │                   │                   │                   │
```

### 6.2 UC Server Termination API

```yaml
openapi: 3.0.0
info:
  title: UC Server Admin API
  version: 1.0.0

paths:
  /api/admin/sessions/terminate:
    post:
      summary: Terminate all sessions for a user
      security:
        - ApiKeyAuth: []
      requestBody:
        content:
          application/json:
            schema:
              type: object
              required:
                - username
              properties:
                username:
                  type: string
                reason:
                  type: string
      responses:
        '200':
          description: Sessions terminated
          content:
            application/json:
              schema:
                type: object
                properties:
                  terminated_count:
                    type: integer

  /api/admin/notify:
    post:
      summary: Send notification to user's connected clients
      requestBody:
        content:
          application/json:
            schema:
              type: object
              properties:
                username:
                  type: string
                type:
                  type: string
                  enum: [session_terminated, password_changed, account_suspended]
                message:
                  type: string
```

---

## 7. Schema Mapping

### 7.1 Directory LDAP ↔ UC LDAP Attribute Mapping

| Directory LDAP | UC LDAP | Notes |
|----------------|---------|-------|
| `uid` | `uid` | Direct mapping |
| `cn` | `cn` | Direct mapping |
| `mail` | `mail` | Direct mapping |
| `userPassword` | `userPassword` | Same hash format (SSHA) |
| `telephoneNumber` | `telephoneNumber` | Optional |
| `mobile` | `mobile` | Optional |
| `description=TERMINATED` | `userPassword={DISABLED}` | Status mapping |
| `azblinkStatus` | (N/A) | Not replicated to UC |

### 7.2 UC-Specific Attributes

If UC LDAP requires additional attributes:

| UC Attribute | Source | Description |
|--------------|--------|-------------|
| `xmppJid` | Computed | `{uid}@{xmpp_domain}` |
| `sipUri` | Computed | `sip:{uid}@{sip_domain}` |
| `ucEnabled` | Derived | `TRUE` if status=active |

### 7.3 LDAP Filter Differences

| Purpose | Directory LDAP | UC LDAP |
|---------|----------------|---------|
| Active users | `(&(objectClass=inetOrgPerson)(!(description=TERMINATED)))` | `(&(objectClass=inetOrgPerson)(ucEnabled=TRUE))` |
| Auth filter | `(uid=%u)` | `(&(uid=%u)(ucEnabled=TRUE))` |

---

## 8. High Availability Considerations

### 8.1 Approach A (Shared LDAP) HA

```
                    ┌─────────────────┐
                    │   HAProxy/LB    │
                    │  ldap.azblink   │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              ▼              ▼              ▼
      ┌───────────┐  ┌───────────┐  ┌───────────┐
      │  LDAP-1   │  │  LDAP-2   │  │  LDAP-3   │
      │ (Primary) │  │ (Primary) │  │ (Primary) │
      └───────────┘  └───────────┘  └───────────┘
              │              │              │
              └──────────────┼──────────────┘
                             │
                    ┌────────┴────────┐
                    │  Multi-master   │
                    │  Replication    │
                    └─────────────────┘
```

### 8.2 Approach B (Syncrepl) HA

```
┌─────────────────────┐         ┌─────────────────────┐
│    Directory DC     │         │      UC DC          │
├─────────────────────┤         ├─────────────────────┤
│                     │         │                     │
│  ┌───────────────┐  │         │  ┌───────────────┐  │
│  │  Primary LDAP │──│─────────│─▶│  Replica LDAP │  │
│  └───────────────┘  │ Syncrepl│  └───────────────┘  │
│         │           │         │         │           │
│         │ failover  │         │         │ failover  │
│         ▼           │         │         ▼           │
│  ┌───────────────┐  │         │  ┌───────────────┐  │
│  │ Standby LDAP  │──│─────────│─▶│ Standby Repl  │  │
│  └───────────────┘  │         │  └───────────────┘  │
│                     │         │                     │
└─────────────────────┘         └─────────────────────┘
```

---

## 9. Monitoring and Alerting

### 9.1 Health Checks

| Component | Check | Frequency | Alert Threshold |
|-----------|-------|-----------|-----------------|
| LDAP connectivity | TCP port 389/636 | 10s | 2 failures |
| LDAP bind | Service account bind | 30s | 1 failure |
| Replication lag | `contextCSN` comparison | 60s | > 60 seconds |
| User count sync | Count comparison | 300s | > 10 difference |

### 9.2 Replication Lag Monitoring

```bash
#!/bin/bash
# Check syncrepl lag

PRIMARY_CSN=$(ldapsearch -x -H ldap://primary:389 \
  -b "dc=azblink,dc=com" -s base contextCSN | grep contextCSN)

REPLICA_CSN=$(ldapsearch -x -H ldap://replica:389 \
  -b "dc=azblink,dc=com" -s base contextCSN | grep contextCSN)

if [ "$PRIMARY_CSN" != "$REPLICA_CSN" ]; then
  echo "WARN: Replication lag detected"
  echo "Primary: $PRIMARY_CSN"
  echo "Replica: $REPLICA_CSN"
fi
```

### 9.3 Sync Service Metrics (Approach C)

| Metric | Type | Description |
|--------|------|-------------|
| `sync_events_total` | Counter | Total webhook events processed |
| `sync_events_failed` | Counter | Failed sync operations |
| `sync_latency_seconds` | Histogram | Time from event to LDAP write |
| `sync_queue_depth` | Gauge | Pending events in queue |

---

## 10. Security Considerations

### 10.1 Transport Security

| Connection | Protocol | Certificate |
|------------|----------|-------------|
| Directory Portal → LDAP | LDAPS (636) or StartTLS | Required |
| UC Server → LDAP | LDAPS (636) or StartTLS | Required |
| Primary → Replica | LDAPS or StartTLS | Required |
| Directory → Sync Service | HTTPS | Required |

### 10.2 Authentication

| Component | Method | Credential Storage |
|-----------|--------|-------------------|
| Directory Portal | Service account bind | Environment variable |
| UC Server | Service account bind | Config file (encrypted) |
| Replication | Dedicated replicator account | LDAP config |
| Sync Service | API key + webhook signature | Secrets manager |

### 10.3 Least Privilege

| Service Account | Permissions |
|-----------------|-------------|
| `cn=directory-portal` | Full CRUD on people, groups, org |
| `cn=uc-server` | Read people, bind verification |
| `cn=replicator` | Read all (for syncrepl) |
| `cn=authentik-sync` | Read people, groups |

---

## 11. Migration Path

### 11.1 Phase 1: Shared LDAP (Current Target)

1. Deploy single OpenLDAP instance
2. Configure Directory Portal with full access
3. Configure UC Server with read/bind access
4. Test authentication flow end-to-end

### 11.2 Phase 2: Add Replication (Future)

1. Deploy replica LDAP in UC datacenter
2. Configure syncrepl from primary
3. Update UC Server to use local replica
4. Configure failover to primary

### 11.3 Phase 3: API Federation (If Required)

1. Deploy sync service
2. Configure webhooks from Directory Portal
3. Deploy UC-specific LDAP if needed
4. Migrate UC Server to UC LDAP

---

## 12. Decision Matrix

| Requirement | Approach A | Approach B | Approach C |
|-------------|------------|------------|------------|
| Single datacenter | ✅ Best | ⚠️ Overkill | ⚠️ Overkill |
| Multi-datacenter | ⚠️ Possible | ✅ Best | ✅ Works |
| Low latency | ✅ Best | ✅ Good | ⚠️ Medium |
| High availability | ⚠️ SPOF | ✅ Best | ✅ Good |
| Schema differences | ❌ No | ⚠️ Limited | ✅ Full |
| Legacy UC system | ⚠️ Maybe | ⚠️ Maybe | ✅ Best |
| Operational simplicity | ✅ Best | ⚠️ Medium | ❌ Complex |

---

## 13. Appendix: Configuration Templates

### 13.1 Directory Portal Environment

```bash
# LDAP Configuration
LDAP_URI=ldaps://ldap.azblink.internal:636
LDAP_BASE_DN=dc=azblink,dc=com
LDAP_BIND_DN=cn=directory-portal,ou=services,dc=azblink,dc=com
LDAP_BIND_PW=${LDAP_DIRECTORY_PORTAL_PW}
LDAP_USE_SSL=true

# UC Server Integration
UC_SERVER_API_URL=http://uc-server.azblink.internal:5280/api
UC_SERVER_API_KEY=${UC_SERVER_API_KEY}
```

### 13.2 UC Server Configuration (ejabberd)

```yaml
auth_method: ldap

ldap_servers:
  - ldap.azblink.internal

ldap_port: 636
ldap_encrypt: tls
ldap_tls_verify: true
ldap_tls_cacertfile: /etc/ssl/certs/ca-certificates.crt

ldap_rootdn: "cn=uc-server,ou=services,dc=azblink,dc=com"
ldap_password: "${LDAP_UC_SERVER_PW}"

ldap_base: "ou=people,dc=azblink,dc=com"
ldap_uids:
  - uid
ldap_filter: "(&(objectClass=inetOrgPerson)(!(description=TERMINATED))(!(description=SUSPENDED)))"
```

### 13.3 Syncrepl Consumer Configuration

```ldif
dn: olcDatabase={1}mdb,cn=config
changetype: modify
add: olcSyncRepl
olcSyncRepl: rid=001
  provider=ldaps://primary.ldap.azblink.internal:636
  bindmethod=simple
  binddn="cn=replicator,ou=services,dc=azblink,dc=com"
  credentials="${LDAP_REPLICATOR_PW}"
  searchbase="ou=people,dc=azblink,dc=com"
  filter="(objectClass=inetOrgPerson)"
  attrs="uid,cn,sn,givenName,mail,mobile,telephoneNumber,userPassword,description"
  scope=sub
  schemachecking=off
  type=refreshAndPersist
  retry="60 +"
  tls_reqcert=demand
  tls_cacert=/etc/ssl/certs/ca-certificates.crt
```

---

## 14. References

- RFC 4533: LDAP Content Synchronization Operation
- OpenLDAP Administrator's Guide: Replication
- ejabberd Documentation: LDAP Authentication
- Prosody Documentation: mod_auth_ldap
- `specs/v2.0/Directory_Portal_LDAP_Schema_v4.2.ldif`

---

**Document Control:**
| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2026-01-26 | Claude Code | Initial specification |
