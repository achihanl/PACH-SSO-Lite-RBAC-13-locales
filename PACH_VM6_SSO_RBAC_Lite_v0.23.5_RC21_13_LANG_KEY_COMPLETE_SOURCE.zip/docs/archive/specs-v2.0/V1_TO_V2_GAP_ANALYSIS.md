# Gap Analysis: v1.0 Implementation → v2.0 Specification

**Generated:** 2026-01-25
**v1.0 Source:** `src/backend/main.py`, `specs/v1.0/SPEC.md`
**v2.0 Target:** `specs/v2.0/Directory_Portal_Specification_v4.1.md`, `Directory_Portal_OpenAPI_v4.2.yaml`, `Directory_Portal_Schema_v4.2.sql`, `Directory_Portal_LDAP_Schema_v4.2.ldif`

---

## Executive Summary

| Category | v1.0 Coverage | v2.0 Required | Gap Score |
|----------|---------------|---------------|-----------|
| Security Requirements | 70% | 100% | **30% gap** |
| API Endpoints | 75% | 100% | **25% gap** |
| Database Schema | 35% | 100% | **65% gap** |
| LDAP Schema | 20% | 100% | **80% gap** |
| QR Provisioning | 60% | 100% | **40% gap** |
| User Lifecycle | 80% | 100% | **20% gap** |
| Audit & Compliance | 50% | 100% | **50% gap** |
| Infrastructure | 75% | 100% | **25% gap** |

**Overall Implementation Completeness: ~58%** (up from ~40% in previous v1.0-baseline)

---

## 1. Security Requirements Gap Analysis

### 1.1 QR Payload Signing

| Aspect | v1.0 Implementation | v2.0 Spec Requirement | Status |
|--------|---------------------|----------------------|--------|
| Signing Algorithm | HMAC-SHA256 ✓ | HMAC-SHA256 | ✅ Match |
| Schema Identifier | `ucchat-user-provision` | `azblink.provisioning.v2` | ❌ **Gap** |
| Payload Structure | `{type, v, uid, userDn, orgDn, iat, exp, nonce, sig}` | `{schema, payload: {uc, sso}, iat, exp, nonce, sig}` | ❌ **Gap** |
| UC Block | Embedded in payload | Nested under `payload.uc` | ❌ **Gap** |
| SSO Block | Separate QR#2 endpoint | Unified with `payload.sso` (null if disabled) | ❌ **Gap** |
| Nonce Uniqueness | `secrets.token_urlsafe(16)` | `secrets.token_urlsafe(16)` | ✅ Match |
| Expiration (`exp`) | Present | Present | ✅ Match |

**v2.0 Expected Unified Payload:**
```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": {
      "xmpp": {"domain": "...", "wsUrl": "..."},
      "sip": {"domain": "...", "wssUrl": "..."},
      "credentials": {"username": "...", "token": "..."}
    },
    "sso": null | {"issuer": "...", "clientId": "...", "scopes": [...]}
  },
  "iat": 1704067200,
  "exp": 1704070800,
  "nonce": "abc123",
  "sig": "hmac-signature"
}
```

**v1.0 Current Payload:**
```json
{
  "type": "ucchat-user-provision",
  "v": 1,
  "uid": "...",
  "userDn": "...",
  "orgDn": "...",
  "iat": 1704067200,
  "exp": 1704070800,
  "nonce": "...",
  "sig": "..."
}
```

**Required Changes:**
1. Update schema identifier from `ucchat-user-provision` to `azblink.provisioning.v2`
2. Restructure payload with nested `uc` and `sso` blocks
3. Add `credentials.token` (one-time provisioning token)
4. Merge QR#1/QR#2 into unified endpoint

### 1.2 One-Time Token Enforcement

| Aspect | v1.0 Implementation | v2.0 Spec Requirement | Status |
|--------|---------------------|----------------------|--------|
| Token Storage | `provision_tokens` table | `provisioning_tokens` table | ✅ Exists |
| Token Hash | SHA-256 | SHA-256 | ✅ Match |
| Consumption Tracking | `status`, `used_at` | `consumed`, `consumed_at`, `consumed_reason` | ⚠️ Partial |
| Validation Endpoint | `POST /api/provision/validate` | `POST /api/provision/consume` | ⚠️ Name differs |
| Error Codes | `TOKEN_NOT_FOUND`, `TOKEN_EXPIRED`, `TOKEN_ALREADY_CONSUMED` | Same | ✅ Match |
| Device ID Tracking | Not implemented | `consumed_by_device_id` | ❌ **Gap** |
| IP Tracking | Not in token table | `consumed_from_ip` | ❌ **Gap** |
| Revocation | `revoke_tokens_for_user()` | `revoked_at`, `revoked_by`, `revoked_reason` | ⚠️ Partial |

**Required Changes:**
1. Add `consumed_by_device_id`, `consumed_from_ip` to `provision_tokens`
2. Add `revoked_at`, `revoked_by`, `revoked_reason` columns
3. Rename endpoint to `/api/provision/consume` (or keep with alias)

### 1.3 Rate Limiting

| Endpoint | v1.0 Implementation | v2.0 Spec Requirement | Status |
|----------|---------------------|----------------------|--------|
| `/api/bootstrap` | 5/hour | 5/hour | ✅ Match |
| `/api/users/create` | 20/min | 20/min | ✅ Match |
| `/api/users/*/qrcode*` | 10/min | 10/min | ✅ Match |
| Auth failures | Basic recording | 5/5min + soft-lock | ❌ **Gap** |
| All other endpoints | 100/min (slowapi) | 100/min | ✅ Match |
| Account Soft-Lock | Not implemented | Lock account after 5 failures | ❌ **Gap** |
| IP-based Blocking | Not implemented | Block IP after repeated violations | ❌ **Gap** |

**Required Changes:**
1. Implement account soft-lock mechanism (track consecutive failures per user)
2. Add IP-based blocking for repeated auth failures
3. Add `account_locked_until` tracking

---

## 2. API Endpoints Gap Analysis

### 2.1 Health & Bootstrap

| Endpoint | v1.0 | v2.0 | Status |
|----------|------|------|--------|
| `GET /api/health` | ✓ | ✓ | ✅ Match |
| `GET /api/health/deep` | ✓ (checks LDAP, PostgreSQL, Redis) | ✓ | ✅ Match |
| `GET /api/tenant` | ✓ | ✓ | ✅ Match |
| `POST /api/bootstrap` | ✓ | ✓ | ✅ Match |

### 2.2 Organizations

| Endpoint | v1.0 | v2.0 | Status |
|----------|------|------|--------|
| `GET /api/org/tree` | ✓ | `GET /api/organizations` with hierarchy | ⚠️ Renamed |
| `POST /api/org/create` | ✓ | `POST /api/organizations` | ⚠️ Renamed |
| `POST /api/org/rename` | ✓ | `PATCH /api/organizations/{dn}` | ⚠️ Method change |
| `DELETE /api/org/{dn}` | ✓ | `DELETE /api/organizations/{dn}` | ⚠️ Path change |
| `GET /api/org/users` | ✓ | `GET /api/organizations/{dn}/users` | ⚠️ Path change |
| `POST /api/organizations/{dn}/move` | ✗ | ✓ (move org) | ❌ **Gap** |

### 2.3 Users

| Endpoint | v1.0 | v2.0 | Status |
|----------|------|------|--------|
| `GET /api/users` | ✓ | ✓ (with pagination) | ⚠️ Needs cursor/page pagination |
| `GET /api/users/{uid}` | ✓ | ✓ | ✅ Match |
| `POST /api/users/create` | ✓ | `POST /api/users` | ⚠️ Path simplification |
| `PATCH /api/users/{uid}` | ✓ | ✓ | ✅ Match |
| `DELETE /api/users/{uid}` | ✗ | ✓ (soft delete) | ❌ **Gap** |
| `POST /api/users/{uid}/reset_password` | ✓ | `POST /api/users/{uid}/password` | ⚠️ Path change |
| `POST /api/users/{uid}/move_org` | ✓ | `POST /api/users/{uid}/move` | ⚠️ Path change |
| `POST /api/users/{uid}/terminate` | ✓ | ✓ | ✅ Match |
| `POST /api/users/{uid}/suspend` | ✓ | ✓ | ✅ Match |
| `POST /api/users/{uid}/unsuspend` | ✓ | ✓ | ✅ Match |
| `POST /api/users/import_csv` | ✓ | `POST /api/users/import` | ⚠️ Path change |
| `GET /api/users/search` | ✗ | ✓ (full-text search) | ❌ **Gap** |
| `GET /api/users/export` | ✗ | ✓ (CSV/JSON export) | ❌ **Gap** |

### 2.4 Groups

| Endpoint | v1.0 | v2.0 | Status |
|----------|------|------|--------|
| `GET /api/groups` | ✓ | ✓ | ✅ Match |
| `POST /api/groups/create` | ✓ | `POST /api/groups` | ⚠️ Path simplification |
| `DELETE /api/groups/{cn}` | ✓ | ✓ | ✅ Match |
| `GET /api/groups/{cn}/members` | ✓ | ✓ | ✅ Match |
| `POST /api/groups/{cn}/members` | ✓ | ✓ | ✅ Match |
| `DELETE /api/groups/{cn}/members/{uid}` | ✓ | ✓ | ✅ Match |
| `GET /api/groups/{cn}` | ✗ | ✓ (group details) | ❌ **Gap** |
| `PATCH /api/groups/{cn}` | ✗ | ✓ (update description) | ❌ **Gap** |

### 2.5 QR Provisioning

| Endpoint | v1.0 | v2.0 | Status |
|----------|------|------|--------|
| `GET /api/users/{uid}/qrcode` | ✓ (legacy schema) | ✓ (unified v2 schema) | ❌ **Schema gap** |
| `GET /api/users/{uid}/qrcode?mode=split` | ✗ | ✓ (backward compat) | ❌ **Gap** |
| `GET /api/users/{uid}/qrcodes` | ✓ (QR#1 + QR#2) | Deprecated | ⚠️ To deprecate |
| `POST /api/users/{uid}/qrcode/revoke` | ✓ | ✓ | ✅ Match |
| `POST /api/provision/consume` | `POST /api/provision/validate` | ✓ | ⚠️ Rename |

### 2.6 OrgProfiles

| Endpoint | v1.0 | v2.0 | Status |
|----------|------|------|--------|
| `GET /api/orgprofiles` | ✓ | ✓ | ✅ Match |
| `POST /api/orgprofiles` | ✓ | ✓ | ✅ Match |
| `GET /api/orgprofiles/{id}` | ✓ | ✓ | ✅ Match |
| `PATCH /api/orgprofiles/{id}` | ✓ | ✓ | ✅ Match |
| `DELETE /api/orgprofiles/{id}` | ✓ | ✓ | ✅ Match |
| `POST /api/orgprofiles/{id}/rotate_qr` | ✓ | ✓ | ✅ Match |

### 2.7 Self-Service (`/me` endpoints)

| Endpoint | v1.0 | v2.0 | Status |
|----------|------|------|--------|
| `GET /api/me` | ✗ | ✓ (current user profile) | ❌ **Gap** |
| `PATCH /api/me` | ✗ | ✓ (update own profile) | ❌ **Gap** |
| `GET /api/me/qrcode` | ✗ | ✓ (own QR code) | ❌ **Gap** |
| `GET /api/me/sessions` | ✗ | ✓ (active sessions) | ❌ **Gap** |
| `DELETE /api/me/sessions/{id}` | ✗ | ✓ (revoke own session) | ❌ **Gap** |

### 2.8 Audit

| Endpoint | v1.0 | v2.0 | Status |
|----------|------|------|--------|
| `GET /api/audit/qr_issuance` | ✓ | ✓ | ✅ Match |
| `GET /api/audit/terminations` | ✓ | ✓ | ✅ Match |
| `GET /api/audit/auth_failures` | ✓ | ✓ | ✅ Match |
| `GET /api/audit/user_lifecycle` | ✓ | ✓ | ✅ Match |
| `GET /api/audit/admin_actions` | ✗ | ✓ | ❌ **Gap** |
| `GET /api/audit/breakglass` | ✗ | ✓ | ❌ **Gap** |

---

## 3. Database Schema Gap Analysis

### 3.1 Tables Comparison

| Table | v1.0 | v2.0 Required | Status |
|-------|------|---------------|--------|
| `org_profiles` | ✓ | ✓ (with version column) | ⚠️ Missing `version` |
| `qr_issues` | ✓ | Merged into `qr_issuance_audit` | ⚠️ Refactor |
| `provision_tokens` | ✓ | `provisioning_tokens` (enhanced) | ⚠️ Schema changes |
| `qr_issuance_audit` | ✓ (basic) | ✓ (partitioned, enhanced) | ⚠️ Needs partitioning |
| `termination_events` | ✓ | ✓ (enhanced) | ⚠️ Missing columns |
| `user_lifecycle_audit` | ✓ | ✓ (partitioned) | ⚠️ Needs partitioning |
| `auth_failure_audit` | ✓ | ✓ (partitioned) | ⚠️ Needs partitioning |
| `users` (shadow table) | ✗ | ✓ (shadow LDAP users) | ❌ **Gap** |
| `suspension_events` | ✗ | ✓ | ❌ **Gap** |
| `admin_auth_audit` | ✗ | ✓ | ❌ **Gap** |
| `orgprofile_audit` | ✗ | ✓ | ❌ **Gap** |
| `breakglass_audit` | ✗ | ✓ | ❌ **Gap** |
| `idempotency_keys` | ✗ | ✓ | ❌ **Gap** |
| `webhooks` | ✗ | ✓ | ❌ **Gap** |
| `webhook_deliveries` | ✗ | ✓ | ❌ **Gap** |
| `user_sessions` | ✗ | ✓ | ❌ **Gap** |

### 3.2 v2.0 Schema Features Missing

| Feature | Description | Priority |
|---------|-------------|----------|
| Custom ENUM types | `user_status`, `qr_type`, `lifecycle_event`, etc. | P1 |
| Table partitioning | Monthly partitions for audit tables | P2 |
| Shadow `users` table | PostgreSQL mirror of LDAP users for fast queries | P1 |
| Optimistic locking | `version` column on `org_profiles` | P2 |
| Full-text search indexes | GIN indexes on user fields | P3 |
| Views | `v_active_users`, `v_pending_tokens`, etc. | P3 |
| Cleanup functions | `cleanup_expired_tokens()`, `vacuum_audit_tables()` | P2 |
| Triggers | Auto-update `updated_at`, increment `version` | P2 |

### 3.3 Missing `users` Shadow Table

v2.0 requires a PostgreSQL shadow table for LDAP users:

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY,
    uid VARCHAR(32) NOT NULL UNIQUE,
    ldap_dn VARCHAR(500) NOT NULL UNIQUE,
    cn VARCHAR(255) NOT NULL,
    mail VARCHAR(255) NOT NULL UNIQUE,
    org_profile_id UUID REFERENCES org_profiles(id),
    org_dn VARCHAR(500),
    status user_status NOT NULL DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE,
    suspended_at TIMESTAMP WITH TIME ZONE,
    terminated_at TIMESTAMP WITH TIME ZONE,
    last_login_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}'
);
```

**Benefits:**
- Faster queries than LDAP
- Status tracking (LDAP doesn't have good status field)
- Foreign key relationships for audit tables
- Full-text search capability

---

## 4. LDAP Schema Gap Analysis

### 4.1 Custom Attributes Missing

| Attribute | v1.0 | v2.0 Required | Purpose |
|-----------|------|---------------|---------|
| `azblinkStatus` | ✗ | ✓ | User status (active/suspended/terminated) |
| `azblinkOrgDN` | ✗ | ✓ | Organization DN reference |
| `azblinkProvisionedAt` | ✗ | ✓ | First provisioning timestamp |
| `azblinkLastLogin` | ✗ | ✓ | Last login timestamp |
| `azblinkSuspendedAt` | ✗ | ✓ | Suspension timestamp |
| `azblinkSuspensionReason` | ✗ | ✓ | Suspension reason |
| `azblinkTerminatedAt` | ✗ | ✓ | Termination timestamp |
| `azblinkEmployeeId` | ✗ | ✓ | External HR system ID |
| `azblinkMetadata` | ✗ | ✓ | JSON metadata blob |

### 4.2 Custom ObjectClasses Missing

| ObjectClass | v1.0 | v2.0 Required | Purpose |
|-------------|------|---------------|---------|
| `azblinkUser` | ✗ | ✓ | Extends `inetOrgPerson` with custom attrs |
| `azblinkOrganization` | ✗ | ✓ | Extends `organizationalUnit` |
| `azblinkGroup` | ✗ | ✓ | Extends `groupOfNames` |

### 4.3 LDAP Overlays Missing

| Overlay | v1.0 | v2.0 Required | Purpose |
|---------|------|---------------|---------|
| Password Policy (`ppolicy`) | ✗ | ✓ | Enforce password requirements |
| MemberOf (`memberof`) | ✗ | ✓ | Auto-maintain `memberOf` attribute |
| Referential Integrity (`refint`) | ✗ | ✓ | Maintain referential integrity |

### 4.4 Service Accounts Missing

| Account | v1.0 | v2.0 Required |
|---------|------|---------------|
| `cn=directory-portal,ou=services` | ✗ | ✓ |
| `cn=authentik-sync,ou=services` | ✗ | ✓ |
| `cn=uc-server,ou=services` | ✗ | ✓ |

---

## 5. QR Provisioning Gap Analysis

### 5.1 Schema Version

| Aspect | v1.0 | v2.0 |
|--------|------|------|
| Schema Name | `ucchat-user-provision` | `azblink.provisioning.v2` |
| Structure | Flat | Nested (`payload.uc`, `payload.sso`) |
| UC Config | XMPP/SIP domains in flat fields | Structured under `payload.uc` |
| SSO Config | Separate QR#2 | Unified in `payload.sso` |
| Credentials Token | Not in QR | Required in `payload.uc.credentials.token` |

### 5.2 Unified QR Endpoint

v2.0 requires a single endpoint that returns both UC and SSO config:

```
GET /api/users/{uid}/qrcode
```

Response structure must be:
```json
{
  "schema": "azblink.provisioning.v2",
  "payload": {
    "uc": {...},
    "sso": null | {...}
  },
  ...
}
```

### 5.3 Split QR (Backward Compatibility)

v2.0 specifies backward compatibility mode:

```
GET /api/users/{uid}/qrcode?mode=split
```

Should return separate QR#1 and QR#2 for legacy clients.

---

## 6. User Lifecycle Gap Analysis

### 6.1 Termination Flow

| Step | v1.0 | v2.0 | Status |
|------|------|------|--------|
| 1. Disable LDAP account | ✓ | ✓ | ✅ Match |
| 2. Invalidate provisioning tokens | ✓ | ✓ | ✅ Match |
| 3. Revoke Authentik sessions | Placeholder | Required | ⚠️ Needs Authentik client |
| 4. Signal UC Server | Placeholder | Required | ⚠️ Needs UC client |
| 5. Log termination event | ✓ | ✓ | ✅ Match |
| 6. Notify connected clients | ✗ | Optional | ⚠️ Nice to have |

**Missing Integrations:**
- `authentik_client.py` - API client for Authentik Admin API
- `uc_client.py` - API client for UC Server session management

### 6.2 Suspension Flow

| Aspect | v1.0 | v2.0 | Status |
|--------|------|------|--------|
| Suspend endpoint | ✓ | ✓ | ✅ Match |
| Unsuspend endpoint | ✓ | ✓ | ✅ Match |
| LDAP status update | ✓ (`userAccountControl`) | ✓ + `azblinkStatus` | ⚠️ Missing custom attr |
| Suspension audit | ✓ (lifecycle_audit) | ✓ + `suspension_events` table | ⚠️ Missing table |

---

## 7. Infrastructure Gap Analysis

### 7.1 Services

| Service | v1.0 | v2.0 | Status |
|---------|------|------|--------|
| OpenLDAP | ✓ | ✓ | ✅ Match |
| PostgreSQL | ✓ | ✓ | ✅ Match |
| Redis | ✓ | ✓ | ✅ Match |
| Authentik | ✗ | Optional | ⚠️ Integration needed |
| UC Server | ✗ | Required for termination | ⚠️ Client needed |

### 7.2 Backend Modules

| Module | v1.0 | v2.0 | Status |
|--------|------|------|--------|
| `main.py` | ✓ | ✓ | ✅ |
| `config.py` | ✓ | ✓ | ✅ |
| `ldap_client.py` | ✓ | ✓ | ✅ |
| `orgdb.py` | ✓ | ✓ | ✅ |
| `oidc_verify.py` | ✓ | ✓ | ✅ |
| `rate_limit.py` | ✓ | ✓ | ✅ |
| `qr_signing.py` | Inline in main.py | Separate module | ⚠️ Refactor |
| `termination.py` | Inline in main.py | Separate module | ⚠️ Refactor |
| `breakglass.py` | Inline in main.py | Separate module | ⚠️ Refactor |
| `audit.py` | ✗ | Required | ❌ **Gap** |
| `uc_client.py` | ✗ | Required | ❌ **Gap** |
| `authentik_client.py` | ✗ | Required | ❌ **Gap** |

### 7.3 CLI Tool

| Feature | v1.0 | v2.0 | Status |
|---------|------|------|--------|
| `directoryctl.py` | ✓ | ✓ | ✅ |
| `breakglass enable/disable` | ✓ | ✓ | ✅ |
| `user terminate` | ✗ | ✓ | ❌ **Gap** |
| `user suspend/unsuspend` | ✗ | ✓ | ❌ **Gap** |
| `qr revoke-all` | ✗ | ✓ | ❌ **Gap** |
| `audit qr/terminations/failures` | ✗ | ✓ | ❌ **Gap** |
| `maintenance cleanup-expired-tokens` | ✗ | ✓ | ❌ **Gap** |

---

## 8. Configuration Gap Analysis

### 8.1 Environment Variables

| Variable | v1.0 | v2.0 | Status |
|----------|------|------|--------|
| `LDAP_*` | ✓ | ✓ | ✅ |
| `DATABASE_URL` | ✓ | ✓ | ✅ |
| `REDIS_URL` | ✓ | ✓ | ✅ |
| `ORG_QR_SIGNING_SECRET` | ✓ | ✓ | ✅ |
| `REQUIRE_OIDC_AUTH` | ✓ | ✓ | ✅ |
| `DATABASE_POOL_SIZE` | ✗ | ✓ | ❌ **Gap** |
| `LDAP_POOL_SIZE` | ✗ | ✓ | ❌ **Gap** |
| `UC_SERVER_API_URL` | ✗ | ✓ | ❌ **Gap** |
| `UC_SERVER_API_KEY` | ✗ | ✓ | ❌ **Gap** |
| `AUTHENTIK_API_URL` | ✗ | ✓ | ❌ **Gap** |
| `AUTHENTIK_API_TOKEN` | ✗ | ✓ | ❌ **Gap** |
| `ORG_QR_MAX_TTL_SEC` | ✗ | ✓ | ❌ **Gap** |

---

## 9. Priority Implementation Roadmap

### P0 — Critical Security & Compliance (Must Have for Production)

| Item | Effort | Impact |
|------|--------|--------|
| Update QR schema to `azblink.provisioning.v2` | 2d | High |
| Implement unified QR payload structure | 2d | High |
| Add account soft-lock on auth failures | 1d | High |
| Add `users` shadow table in PostgreSQL | 2d | Medium |
| Implement `authentik_client.py` for session revocation | 2d | High |
| Implement `uc_client.py` for session termination | 2d | High |

### P1 — Core Functionality

| Item | Effort | Impact |
|------|--------|--------|
| Add `/me` self-service endpoints | 1d | Medium |
| Add `/api/users/search` full-text search | 1d | Medium |
| Add custom LDAP schema (`azblink.schema`) | 2d | Medium |
| Add `suspension_events` table | 0.5d | Low |
| Add `breakglass_audit` table | 0.5d | Low |
| Implement table partitioning for audit tables | 1d | Low |

### P2 — Operations & Polish

| Item | Effort | Impact |
|------|--------|--------|
| Add connection pooling config | 0.5d | Medium |
| Extract `qr_signing.py`, `breakglass.py` modules | 1d | Low |
| Add CLI commands (`user terminate`, `audit`, etc.) | 2d | Medium |
| Add webhook support | 3d | Low |
| Add idempotency key support | 1d | Low |

### P3 — Documentation & Testing

| Item | Effort | Impact |
|------|--------|--------|
| Generate OpenAPI spec matching v4.2 | 1d | Medium |
| Add integration tests for termination flow | 2d | High |
| Add LDAP overlay configuration guide | 1d | Low |
| Create migration scripts for schema updates | 2d | Medium |

---

## 10. Migration Considerations

### 10.1 QR Schema Migration

**Breaking Change:** The QR payload schema change from `ucchat-user-provision` to `azblink.provisioning.v2` is not backward compatible.

**Migration Strategy:**
1. Add `?schema=v1` query parameter to preserve old format
2. Default to v2 schema for new QR codes
3. Document client upgrade path
4. Deprecate v1 schema after 6 months

### 10.2 Database Migration

The following migrations are needed:

```sql
-- Migration 001: Add version column to org_profiles
ALTER TABLE org_profiles ADD COLUMN version INTEGER DEFAULT 1;

-- Migration 002: Create users shadow table
CREATE TABLE users (...);

-- Migration 003: Create suspension_events table
CREATE TABLE suspension_events (...);

-- Migration 004: Create breakglass_audit table
CREATE TABLE breakglass_audit (...);

-- Migration 005: Add partitioning to audit tables
-- (Requires data migration)
```

### 10.3 LDAP Schema Migration

LDAP schema changes require:
1. Stop services
2. Add custom schema file to `/etc/ldap/schema/`
3. Update slapd.conf or cn=config
4. Restart OpenLDAP
5. Migrate existing users to use new objectClass

---

## 11. Appendix: File Inventory

### v1.0 Current Structure
```
src/backend/
├── main.py                 # 1454 lines (monolith)
├── config.py
├── ldap_client.py
├── orgdb.py
├── oidc_verify.py
├── rate_limit.py
└── requirements.txt
```

### v2.0 Target Structure
```
src/backend/
├── main.py                 # Routes only
├── config.py
├── ldap_client.py
├── orgdb.py
├── oidc_verify.py
├── rate_limit.py
├── qr_signing.py           # NEW - extracted
├── termination.py          # NEW - extracted
├── breakglass.py           # NEW - extracted
├── audit.py                # NEW
├── uc_client.py            # NEW
├── authentik_client.py     # NEW
├── schemas/
│   └── provisioning_v2.py  # NEW - Pydantic models
└── requirements.txt
```

---

## 12. Conclusion

The v1.0 implementation provides a solid foundation with most core functionality in place. The primary gaps for v2.0 compliance are:

1. **QR Schema Update** — The most impactful change, requiring payload restructuring
2. **Shadow Users Table** — Enables faster queries and proper audit relationships
3. **Integration Clients** — Authentik and UC Server clients for complete termination flow
4. **LDAP Custom Schema** — Enables proper status tracking in directory

Estimated total effort to achieve full v2.0 compliance: **~25-30 developer days**

Current implementation readiness: **~58%** (up from ~40% at baseline)
