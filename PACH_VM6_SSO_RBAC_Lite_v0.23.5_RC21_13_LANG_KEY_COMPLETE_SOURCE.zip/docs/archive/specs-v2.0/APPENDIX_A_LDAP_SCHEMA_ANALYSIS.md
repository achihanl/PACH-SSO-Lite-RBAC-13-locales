# Appendix A: LDAP Schema Technical Analysis

**Document Type:** Technical Specification Appendix
**Version:** 1.0
**Status:** Draft
**Date:** 2026-01-26
**Related Documents:**
- `docs/prd/PHASE1_UC_CORE_QR_PRD.md`
- `docs/prd/PHASE2_SSO_PROFILE_QR_PRD.md`
- `specs/v2.0/Directory_Portal_LDAP_Schema_v4.2.ldif`
- `specs/v1.0/LDAP_ARCHITECTURE.md`

---

## 1. Executive Summary

This document provides a comprehensive technical analysis of the LDAP schema used by the AZBlink Directory Portal, extracted from the Phase 1 and Phase 2 Product Requirements Documents. It serves as a reference for implementers, integrators, and operators who need to understand the LDAP data model, its relationship to UC (Unified Communications) provisioning, and the federation approach between the Directory LDAP and external UC LDAP systems.

### 1.1 Key Findings

| Area | Status | Assessment |
|------|--------|------------|
| DIT Structure | ✅ Implemented | Matches design; hierarchical org tree functional |
| User Schema | ⚠️ Partial | Using `inetOrgPerson`; custom `azblinkUser` defined but not deployed |
| Status Tracking | ⚠️ Workaround | Uses password/description fields instead of dedicated attributes |
| Group Schema | ✅ Implemented | Standard `groupOfNames` with member overlay |
| UC Integration | ⚠️ Undefined | Requires formal federation specification |

### 1.2 Scope

This analysis covers:
- Directory Information Tree (DIT) structure
- ObjectClass and attribute definitions
- User lifecycle state management
- QR provisioning data flow
- LDAP federation approaches for UC integration

---

## 2. Directory Information Tree (DIT) Structure

### 2.1 Logical Structure

The AZBlink Directory uses a hierarchical DIT organized by function:

```
dc=azblink,dc=com
│
├── ou=org                              [Organization Hierarchy]
│   └── ou={Department}
│       └── ou={SubDepartment}
│           └── ...
│
├── ou=people                           [User Entries]
│   └── uid={username}
│
├── ou=groups                           [Security Groups]
│   └── cn={GroupName}
│
├── ou=services                         [Service Accounts]
│   └── cn={ServiceName}
│
└── ou=pwpolicies                       [Password Policies]
    ├── cn=default
    └── cn=admin-policy
```

### 2.2 Organizational Unit Mirroring

The implementation mirrors the organization hierarchy across three parallel trees:

| Tree | Base DN | Purpose |
|------|---------|---------|
| Organization | `ou=org,dc=azblink,dc=com` | Logical org structure |
| People | `ou=people,dc=azblink,dc=com` | User placement by org |
| Groups | `ou=groups,dc=azblink,dc=com` | Group placement by org |

**Example Mirroring:**
```
ou=Engineering,ou=org,dc=azblink,dc=com
    ↓ mirrors to
ou=Engineering,ou=people,dc=azblink,dc=com
    ↓ mirrors to
ou=Engineering,ou=groups,dc=azblink,dc=com
```

### 2.3 Sample DIT Instance

```
dc=azblink,dc=com
├── ou=org
│   └── ou=GlobalHQ
│       ├── ou=Engineering
│       │   ├── ou=Platform
│       │   │   ├── ou=Security
│       │   │   └── ou=EdgeSystems
│       │   └── ou=ProductEngineering
│       ├── ou=Marketing
│       │   ├── ou=Brand
│       │   └── ou=DemandGen
│       └── ou=Legal
│
├── ou=people
│   ├── uid=robert      (VP Engineering)
│   ├── uid=alex        (Security)
│   ├── uid=sarah       (EdgeSystems)
│   ├── uid=james       (ProductEngineering)
│   ├── uid=mei         (Brand)
│   ├── uid=kevin       (DemandGen)
│   └── uid=laura       (Legal)
│
├── ou=groups
│   ├── cn=IT-Admins
│   ├── cn=Engineering
│   ├── cn=All-Staff
│   └── cn=Managers
│
└── ou=services
    ├── cn=directory-portal
    ├── cn=authentik-sync
    └── cn=uc-server
```

---

## 3. ObjectClass Definitions

### 3.1 Custom ObjectClasses (v4.2 Schema)

The v4.2 LDAP schema defines three custom objectClasses under the enterprise OID arc `1.3.6.1.4.1.99999`:

#### 3.1.1 azblinkUser

```
objectclass ( 1.3.6.1.4.1.99999.2.1
    NAME 'azblinkUser'
    DESC 'Azblink Directory Portal user'
    SUP inetOrgPerson
    STRUCTURAL
    MUST ( uid $ cn $ mail )
    MAY ( telephoneNumber $ mobile $ jpegPhoto $ title $
          azblinkStatus $ azblinkOrgDN $ azblinkProvisionedAt $
          azblinkLastLogin $ azblinkSuspendedAt $ azblinkSuspensionReason $
          azblinkTerminatedAt $ azblinkEmployeeId $ azblinkMetadata ) )
```

**Inheritance Chain:**
```
top
 └── person
      └── organizationalPerson
           └── inetOrgPerson
                └── azblinkUser
```

#### 3.1.2 azblinkOrganization

```
objectclass ( 1.3.6.1.4.1.99999.2.2
    NAME 'azblinkOrganization'
    DESC 'Azblink organization unit with extended attributes'
    SUP organizationalUnit
    STRUCTURAL
    MAY ( description $ businessCategory ) )
```

#### 3.1.3 azblinkGroup

```
objectclass ( 1.3.6.1.4.1.99999.2.3
    NAME 'azblinkGroup'
    DESC 'Azblink group with extended attributes'
    SUP groupOfNames
    STRUCTURAL
    MAY ( description ) )
```

### 3.2 Implementation Status

| ObjectClass | Schema Defined | Currently Used | Gap |
|-------------|----------------|----------------|-----|
| `azblinkUser` | ✅ Yes | ❌ No | Using `inetOrgPerson` directly |
| `azblinkOrganization` | ✅ Yes | ❌ No | Using `organizationalUnit` |
| `azblinkGroup` | ✅ Yes | ❌ No | Using `groupOfNames` |

**Recommendation:** Migrate to custom objectClasses to enable proper attribute tracking.

---

## 4. Attribute Definitions

### 4.1 Custom Attributes (azblinkUser)

| Attribute | OID | Syntax | Single-Value | Description |
|-----------|-----|--------|--------------|-------------|
| `azblinkStatus` | ...1.1.1 | DirectoryString(20) | Yes | Account status: `active`, `suspended`, `terminated` |
| `azblinkOrgDN` | ...1.1.2 | DN | Yes | Organization DN reference |
| `azblinkProvisionedAt` | ...1.1.3 | GeneralizedTime | Yes | First QR provisioning timestamp |
| `azblinkLastLogin` | ...1.1.4 | GeneralizedTime | Yes | Last successful authentication |
| `azblinkSuspendedAt` | ...1.1.5 | GeneralizedTime | Yes | Suspension timestamp |
| `azblinkSuspensionReason` | ...1.1.6 | DirectoryString(255) | Yes | Suspension reason |
| `azblinkTerminatedAt` | ...1.1.7 | GeneralizedTime | Yes | Termination timestamp |
| `azblinkEmployeeId` | ...1.1.8 | DirectoryString(64) | Yes | External HR system ID |
| `azblinkMetadata` | ...1.1.9 | DirectoryString(65535) | Yes | JSON extensibility blob |

### 4.2 Standard Attributes Used

#### User Attributes (inetOrgPerson)

| Attribute | Required | Description | Example |
|-----------|----------|-------------|---------|
| `uid` | Yes | Login username | `alice` |
| `cn` | Yes | Common/display name | `Alice Smith` |
| `sn` | Yes | Surname | `Smith` |
| `mail` | Yes | Email address | `alice@azblink.com` |
| `givenName` | No | First name | `Alice` |
| `telephoneNumber` | No | Office phone | `8824` |
| `mobile` | No | Mobile phone | `+886-912-345-678` |
| `title` | No | Job title | `Senior Engineer` |
| `jpegPhoto` | No | Profile photo | (binary) |
| `userPassword` | Yes | Hashed password | `{SSHA}...` |
| `manager` | No | Manager's DN | `uid=robert,ou=people,...` |

#### Group Attributes (groupOfNames)

| Attribute | Required | Description |
|-----------|----------|-------------|
| `cn` | Yes | Group name |
| `member` | Yes | Member DNs (multi-valued, min 1) |
| `description` | No | Group purpose |

### 4.3 Attribute Mapping (API ↔ LDAP)

```yaml
LDAP_USER_ATTRIBUTE_MAP:
  # API Field → LDAP Attribute
  uid: uid
  displayName: cn
  firstName: givenName
  lastName: sn
  email: mail
  phone: telephoneNumber
  mobile: mobile
  title: title
  photo: jpegPhoto
  status: azblinkStatus        # When using azblinkUser
  orgDn: azblinkOrgDN
  employeeId: azblinkEmployeeId

LDAP_GROUP_ATTRIBUTE_MAP:
  name: cn
  description: description
  members: member
```

---

## 5. User Entry Specifications

### 5.1 Canonical User Entry (Full Schema)

```ldif
dn: uid=alice,ou=people,dc=azblink,dc=com
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: azblinkUser
uid: alice
cn: Alice Smith
givenName: Alice
sn: Smith
mail: alice@azblink.com
telephoneNumber: 8824
mobile: +886-912-345-678
title: Senior Engineer
userPassword: {SSHA}W6ph5Mm5Pz8GgiULbPgzG37mj9g=
manager: uid=robert,ou=people,dc=azblink,dc=com
azblinkStatus: active
azblinkOrgDN: ou=Engineering,ou=GlobalHQ,ou=org,dc=azblink,dc=com
azblinkEmployeeId: EMP001
azblinkProvisionedAt: 20260115120000Z
azblinkLastLogin: 20260125143022Z
```

### 5.2 Minimal User Entry (Current Implementation)

```ldif
dn: uid=alice,ou=people,dc=azblink,dc=com
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: alice
cn: Alice Smith
givenName: Alice
sn: Smith
mail: alice@azblink.com
userPassword: {SSHA}W6ph5Mm5Pz8GgiULbPgzG37mj9g=
```

### 5.3 User DN Construction

**Pattern:** `uid={username},ou=people,dc=azblink,dc=com`

**With Org Mirroring:** `uid={username},{org_path},ou=people,dc=azblink,dc=com`

Example:
- User `sarah` in Security team
- Org DN: `ou=Security,ou=Platform,ou=Engineering,ou=GlobalHQ,ou=org,dc=azblink,dc=com`
- User DN: `uid=sarah,ou=Security,ou=Platform,ou=Engineering,ou=GlobalHQ,ou=people,dc=azblink,dc=com`

---

## 6. User Lifecycle State Management

### 6.1 State Machine

```
                              ┌─────────────────┐
                              │    (created)    │
                              └────────┬────────┘
                                       │
                                       ▼
                              ┌─────────────────┐
         ┌────────────────────│     active      │────────────────────┐
         │                    └────────┬────────┘                    │
         │                             │                             │
         │ suspend()                   │ terminate()                 │
         ▼                             │                             ▼
┌─────────────────┐                    │                    ┌─────────────────┐
│    suspended    │────────────────────┼────────────────────│   terminated    │
└────────┬────────┘     terminate()    │                    └─────────────────┘
         │                             │                             │
         │ unsuspend()                 │                   reinstate()
         │                             │                             │
         └─────────────────────────────┴─────────────────────────────┘
```

### 6.2 State Transitions

| Transition | From | To | LDAP Changes |
|------------|------|-----|--------------|
| Create | — | active | Add entry with normal password |
| Suspend | active | suspended | `azblinkStatus=suspended`, `azblinkSuspendedAt=<now>` |
| Unsuspend | suspended | active | `azblinkStatus=active`, remove suspension attrs |
| Terminate | active/suspended | terminated | `azblinkStatus=terminated`, `azblinkTerminatedAt=<now>` |
| Reinstate | terminated | active | `azblinkStatus=active`, new password, remove termination attrs |

### 6.3 Current Implementation Workaround

Since custom attributes are not deployed, the implementation uses:

| State | userPassword | description |
|-------|--------------|-------------|
| active | `{SSHA}...` (valid hash) | (empty) |
| suspended | `{SUSPENDED}` | `SUSPENDED` |
| terminated | `{DISABLED}` | `TERMINATED` |

**Code Reference:** `src/backend/ldap_client.py:639-705`

---

## 7. Group Entry Specifications

### 7.1 Group Entry Structure

```ldif
dn: cn=IT-Admins,ou=groups,dc=azblink,dc=com
objectClass: top
objectClass: groupOfNames
cn: IT-Admins
description: IT Administrators with elevated privileges
member: uid=robert,ou=people,dc=azblink,dc=com
member: uid=alex,ou=people,dc=azblink,dc=com
```

### 7.2 MemberOf Overlay

The schema configures the `memberof` overlay to automatically maintain reverse membership:

```
User Entry:
  memberOf: cn=IT-Admins,ou=groups,dc=azblink,dc=com
  memberOf: cn=Engineering,ou=groups,dc=azblink,dc=com
```

**Configuration:**
```ldif
dn: olcOverlay=memberof,olcDatabase={1}mdb,cn=config
objectClass: olcOverlayConfig
objectClass: olcMemberOf
olcOverlay: memberof
olcMemberOfGroupOC: groupOfNames
olcMemberOfMemberAD: member
olcMemberOfMemberOfAD: memberOf
```

### 7.3 Standard Groups

| Group | Purpose | Typical Members |
|-------|---------|-----------------|
| `IT-Admins` | System administrators | Directory admins, IT staff |
| `All-Staff` | All employees | Every active user |
| `Managers` | People managers | Users with direct reports |
| `Engineering` | Engineering department | Engineering staff |

---

## 8. Service Account Specifications

### 8.1 Service Account Entry

```ldif
dn: cn=directory-portal,ou=services,dc=azblink,dc=com
objectClass: top
objectClass: simpleSecurityObject
objectClass: organizationalRole
cn: directory-portal
description: Service account for Directory Portal backend
userPassword: {SSHA}...
```

### 8.2 Defined Service Accounts

| Account | Purpose | Permissions |
|---------|---------|-------------|
| `cn=directory-portal` | Portal backend | Full read/write to people, groups, org |
| `cn=authentik-sync` | Authentik LDAP sync | Read-only to people, groups |
| `cn=uc-server` | UC Server authentication | Read + bind verification to people |

---

## 9. QR Provisioning Data Flow

### 9.1 UC Core Provisioning (Phase 1)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          DIRECTORY PORTAL                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  1. Admin requests QR for user                                          │
│     GET /api/users/{uid}/qrcode                                         │
│                                                                         │
│  2. Portal queries LDAP                                                 │
│     ┌─────────────────────────────────────────┐                         │
│     │ LDAP Query:                             │                         │
│     │   Base: ou=people,dc=azblink,dc=com     │                         │
│     │   Filter: (uid=alice)                   │                         │
│     │   Attrs: uid, cn, mail                  │                         │
│     └─────────────────────────────────────────┘                         │
│                                                                         │
│  3. Portal generates provisioning token                                 │
│     - token = secrets.token_urlsafe(24)                                 │
│     - token_hash = SHA256(token)                                        │
│     - Store in PostgreSQL (not LDAP)                                    │
│                                                                         │
│  4. Portal builds QR payload                                            │
│     ┌─────────────────────────────────────────┐                         │
│     │ {                                       │                         │
│     │   "schema": "azblink.provisioning.v2",  │                         │
│     │   "payload": {                          │                         │
│     │     "uc": {                             │                         │
│     │       "credentials": {                  │                         │
│     │         "username": "alice", ←───────── LDAP uid                  │
│     │         "token": "one-time-token"       │                         │
│     │       },                                │                         │
│     │       "xmpp": {...},                    │                         │
│     │       "sip": {...}                      │                         │
│     │     }                                   │                         │
│     │   },                                    │                         │
│     │   "sig": "hmac-sha256"                  │                         │
│     │ }                                       │                         │
│     └─────────────────────────────────────────┘                         │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ QR Code
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                           MOBILE CLIENT                                  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  5. User scans QR code                                                  │
│                                                                         │
│  6. Client calls POST /api/provision/consume                            │
│     - Validates signature                                               │
│     - Validates token (one-time, not expired)                           │
│     - Returns session credentials                                       │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ LDAP Bind / UC Session
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                             UC SERVER                                    │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  7. Client connects to UC with credentials                              │
│     - XMPP: alice@uc.azblink.com                                        │
│     - SIP: sip:alice@sip.azblink.com                                    │
│                                                                         │
│  8. UC Server authenticates via LDAP bind                               │
│     ┌─────────────────────────────────────────┐                         │
│     │ LDAP Bind:                              │                         │
│     │   DN: uid=alice,ou=people,...           │                         │
│     │   Password: (user's LDAP password)      │                         │
│     └─────────────────────────────────────────┘                         │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 9.2 LDAP Attributes Used in Provisioning

| Stage | LDAP Attribute | Purpose |
|-------|----------------|---------|
| QR Generation | `uid` | Username for credentials block |
| QR Generation | `cn`, `mail` | User context for audit |
| UC Authentication | `userPassword` | LDAP bind verification |
| Status Check | `azblinkStatus` | Block terminated/suspended users |

---

## 10. Search Filter Reference

### 10.1 Common Search Filters

```ldap
# Find all active users
(&(objectClass=inetOrgPerson)(!(description=TERMINATED))(!(description=SUSPENDED)))

# Find all active users (with azblinkUser schema)
(&(objectClass=azblinkUser)(azblinkStatus=active))

# Find user by uid
(&(objectClass=inetOrgPerson)(uid=alice))

# Find users in organization (including sub-orgs)
# Search base: ou=Engineering,ou=people,dc=azblink,dc=com
(objectClass=inetOrgPerson)

# Find users by partial name
(&(objectClass=inetOrgPerson)(|(cn=*smith*)(uid=*smith*)(mail=*smith*)))

# Find group members
(&(objectClass=groupOfNames)(member=uid=alice,ou=people,dc=azblink,dc=com))

# Find user's groups (using memberOf)
(&(objectClass=inetOrgPerson)(uid=alice))
# Then read memberOf attribute

# Find suspended users
(&(objectClass=inetOrgPerson)(description=SUSPENDED))

# Find users not logged in for 90 days (with azblinkUser)
(&(objectClass=azblinkUser)(azblinkLastLogin<=20260101000000Z))
```

### 10.2 Index Recommendations

```ldif
olcDbIndex: uid eq
olcDbIndex: cn eq,sub
olcDbIndex: sn eq,sub
olcDbIndex: mail eq
olcDbIndex: memberOf eq
olcDbIndex: member eq
olcDbIndex: azblinkStatus eq
olcDbIndex: azblinkOrgDN eq
olcDbIndex: azblinkEmployeeId eq
```

---

## 11. Access Control Lists (ACLs)

### 11.1 ACL Summary

| Priority | Target | Who | Access |
|----------|--------|-----|--------|
| 0 | `userPassword` | self, admin, directory-portal | write |
| 0 | `userPassword` | anonymous | auth only |
| 1 | user self-modifiable attrs | self | write |
| 2 | `ou=people` | admin, directory-portal | write |
| 2 | `ou=people` | authenticated | read |
| 3 | `ou=groups` | admin, directory-portal | write |
| 3 | `ou=groups` | authenticated | read |
| 4 | `ou=org` | admin, directory-portal | write |
| 4 | `ou=org` | authenticated | read |
| 5 | `ou=services` | admin only | write |
| 6 | default | authenticated | read |

### 11.2 Self-Modifiable Attributes

Users can modify their own:
- `telephoneNumber`
- `mobile`
- `jpegPhoto`

---

## 12. Password Policy

### 12.1 Default Policy

| Setting | Value | Description |
|---------|-------|-------------|
| `pwdMinLength` | 12 | Minimum password length |
| `pwdMaxAge` | 7776000 (90 days) | Password expiration |
| `pwdInHistory` | 5 | Passwords remembered |
| `pwdMaxFailure` | 5 | Failures before lockout |
| `pwdLockoutDuration` | 1800 (30 min) | Lockout duration |
| `pwdGraceAuthNLimit` | 3 | Grace logins after expiry |

### 12.2 Admin Policy (Stricter)

| Setting | Value |
|---------|-------|
| `pwdMinLength` | 16 |
| `pwdMaxAge` | 2592000 (30 days) |
| `pwdInHistory` | 10 |
| `pwdMaxFailure` | 3 |
| `pwdLockoutDuration` | 3600 (1 hour) |

---

## 13. Appendix: LDIF Templates

### 13.1 Create User

```ldif
dn: uid={uid},ou=people,dc=azblink,dc=com
changetype: add
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: {uid}
cn: {displayName}
givenName: {firstName}
sn: {lastName}
mail: {email}
userPassword: {SSHA}...
```

### 13.2 Suspend User

```ldif
dn: uid={uid},ou=people,dc=azblink,dc=com
changetype: modify
replace: userPassword
userPassword: {SUSPENDED}
-
replace: description
description: SUSPENDED
```

### 13.3 Add User to Group

```ldif
dn: cn={groupName},ou=groups,dc=azblink,dc=com
changetype: modify
add: member
member: uid={uid},ou=people,dc=azblink,dc=com
```

---

## 14. References

- RFC 4510: LDAP Technical Specification Road Map
- RFC 4519: LDAP Schema for User Applications
- RFC 2798: inetOrgPerson Object Class
- `specs/v2.0/Directory_Portal_LDAP_Schema_v4.2.ldif`
- `src/backend/ldap_client.py`

---

**Document Control:**
| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2026-01-26 | Claude Code | Initial extraction from PRDs |
