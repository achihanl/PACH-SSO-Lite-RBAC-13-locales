# Archive — Historical Only

Historical documentation. Do not treat as current. Do not update.

For the active architecture specification, see `docs/architecture/`.
For the active API contract, see `docs/api/openapi.yaml`.
For active migrations, see `migrations/`.
