# PACH VM6 v0.22.4 RC10 Localization Release Notes

Baseline: v0.22.3 RC9. No SSO, LDAP, Authentik, database, API or RBAC behavior changed.

Added 282 draft translation entries across ten newer languages. Provisioning is now complete at source-key level in every newer language. Additional security-sensitive User Management messages translated. Original approved terminology and prior glossary traceability retained.

Glossary reference: PACH Master Terminology v25.9 Final. New entries are labelled as draft; they are not represented as approved terms from the master glossary.

Quality: all new/old JSON keys and interpolation placeholders verified against English, no preexisting translation overwritten. Full UI translation, native-language review, frontend build, and Arabic RTL visual validation are still pending.

Coverage:
- ar: 583/1062 (54.9%), missing 479
- de: 584/1062 (54.99%), missing 478
- es: 583/1062 (54.9%), missing 479
- fr: 584/1062 (54.99%), missing 478
- id: 583/1062 (54.9%), missing 479
- ja: 583/1062 (54.9%), missing 479
- ko: 583/1062 (54.9%), missing 479
- pt-BR: 584/1062 (54.99%), missing 478
- th: 583/1062 (54.9%), missing 479
- vi: 583/1062 (54.9%), missing 479
