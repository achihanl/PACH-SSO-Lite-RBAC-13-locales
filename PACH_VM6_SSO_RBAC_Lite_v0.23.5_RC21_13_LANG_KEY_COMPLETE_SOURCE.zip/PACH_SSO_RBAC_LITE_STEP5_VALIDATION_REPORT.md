# PACH VM6 SSO & RBAC Lite v0.21.4 — Step 5 Validation and Hardening Report

**Baseline:** complete v0.21.3 Step 4 development candidate; earlier PACH extensions preserved.
**Status:** DEVELOPMENT CANDIDATE ONLY. Not production-validated.
**Standard:** PACH-STD-IAM-001 — VM6 handles identity, SSO and simple per-application roles; applications retain fine-grained authorization.

## Changes made in Step 5

1. Fixed the reference OIDC role client to validate dynamic registered role identifiers (`^[a-z][a-z0-9_-]{0,39}$`) instead of hard-coding `admin/operator/user/viewer`. Future registered applications can therefore use custom roles without changing the reusable VM6 integration client. Actual permission choices still belong to each application and `require_role()` fails closed.
2. Aligned the reference client's application ID length with VM6 registration (`^[a-z][a-z0-9-]{1,63}$`, up to 64 characters).
3. Added explicit negative tests for malicious/malformed role strings, unauthorized local actions, invalid identity, path traversal in an application ID, token header injection, and longest supported IDs.
4. Added dependency-isolated tests that exercise the real VM6 `evaluate_app_role()` code with mocked DB and auth dependency imports. These confirm cross-application rejection, no-assignment denial, machine token rejection, no identity denial, disabled app denial and DB failure -> HTTP 503.

## Offline verification performed

| Check | Result | Limit |
| --- | --- | --- |
| 22 Step 4/5 reference integration unit tests | PASS | Network, LDAP, and Authentik not exercised |
| 8 real endpoint logic tests, with dependencies substituted | PASS | Auth token cryptographic validation and DB SQL not exercised |
| Backend and reference Python `compileall` | PASS | Syntax only |
| Original v0.20.0 source inventory | PASS — 1,342 original files retained | File presence does not prove behavior |
| New application SQL migrations present | PASS — 032 and 033 | Not applied against a PostgreSQL instance |
| Full pytest suite / existing regression tests | BLOCKED at collection: `psycopg2` missing | Must run in normal project dev/CI stack |
| Live OIDC login, issuer/audience/azp claims, Authentik provisioning | NOT RUN | Requires real Authentik and OIDC tokens |
| LDAP bind, user lifecycle and provisioned LDAP service auth | NOT RUN | Requires real OpenLDAP |
| PostgreSQL migrations and concurrent role changes | NOT RUN | Requires real PostgreSQL |
| Frontend production build and role UI checks | NOT RUN | `node_modules` unavailable |
| First-party client onboarding, legacy admin RBAC, SIP/XMPP flows | NOT RUN | Full stack/regression suite required |

## Required production-validation gate

1. Set up the project's normal PostgreSQL, LDAP, Redis and Authentik development/CI stack with pinned dependencies. Apply migrations 032 and 033 to a database cloned from v0.20.0. Verify old records/clients persist and the new registry starts empty except approved seeded applications.
2. Run the entire existing unit, contract, integration and E2E suite, not merely the added tests. Compare results with v0.20.0 baseline.
3. Exercise normal OIDC login to both a PACH built-in app and a newly registered partner app. Verify the actual signed token's `iss`, `aud`, `azp`, `preferred_username`, token lifetime, and role lookup binding. This must be checked against real Authentik configuration; mock tests cannot prove it.
4. Register a future app through the UI without code changes; provision OIDC, assign a custom role, deny unassigned users, revoke role, disable application, test invalid and cross-client tokens. Confirm all deny/failure paths.
5. Verify LDAP service binds use VM6 directory, and that application-specific authorization remains local. LDAP-only role lookup via the OIDC `/me` API is *not* supported (known design boundary).
6. Confirm audited administrative changes, no secret disclosure on GET/logs, redirects validated, provisioning retries safe, and existing first-party building-client / SIP / XMPP flows unchanged.
7. Build production frontend, test EN/zh-TW/zh-CN UI, and review dependency/vulnerability scan before signing release.

## Known product limitations unchanged

- Only OIDC and LDAP automatic application authentication provisioning; SAML manual.
- Authentication client registry supports one client per application. Multiple client/method support requires a future reviewed design.
- Disabling an application denies new VM6 role decisions but does not yet deactivate all remote credentials or end independently cached sessions. Applications must enforce revocation and session expiry.
- LDAP-only protocol services authenticate through LDAP and enforce their native/local ACLs; they do not call the user-delegated OIDC role endpoint.
- The application registry does not automatically provision SIP, XMPP or building resources.

**Decision:** Step 5 offline checks passed; live environment acceptance is still open. Do NOT rename this candidate as a production release until the gate above passes.
