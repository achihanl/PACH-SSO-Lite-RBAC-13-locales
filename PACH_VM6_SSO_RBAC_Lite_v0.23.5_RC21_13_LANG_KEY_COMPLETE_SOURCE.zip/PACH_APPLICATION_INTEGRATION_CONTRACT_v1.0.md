# PACH Application Integration Contract v1.0 — Step 3

Status: development candidate, not production certified. Applies to **future OIDC applications** provisioned through VM6 Step 2 as well as existing apps after provisioning.

## Responsibilities
- VM6 authenticates through OpenLDAP/Authentik and stores exactly one role per user per application. No grant = no access.
- Each VM enforces its own UI actions, resource ownership, site/household scoping, device policies and audit.
- SIP, SMTP, IMAP, MQTT, XMPP and other LDAP-capable protocol services continue their supported LDAP authentication; they do not need interactive OIDC login. LDAP-authenticated service role retrieval via a trusted machine channel is **not** implemented in Step 3.

## Standard user-delegated OIDC role endpoint
`GET /api/integration/v1/applications/{application_id}/me`

Request: `Authorization: Bearer <user_access_token>` issued for the **same registered OIDC client** as the requested application.

Successful response with assignment:
```json
{"ok":true,"contract_version":"1.0","application_id":"partner-crm","subject":{"uid":"alice"},"allowed":true,"role":"operator"}
```

Successful response with no assignment (DENY): `allowed:false, role:null`.

Security rules:
1. VM6 validates JWT signature, configured/dynamically registered issuer, audience, expiry, account lock and originating `azp`.
2. Only registered, enabled applications with a ready OIDC authentication registration may query their user role.
3. Token `azp` must **exactly match** that application's registered client. A valid token for application A cannot query application B.
4. Client-credentials tokens are not a human identity and cannot get user roles.
5. Database failure responds 503 (fail closed), invalid client 403, and missing role returns `allowed:false`. No VM6 administrator fallback grants app access.
6. The application must authorize functions/resources locally; never treat an authenticated login or HTTP 200 as authorization.
7. For revocation, query at the protected boundary or use a short-lived cache with a documented maximum stale window. Do not cache an allow result indefinitely.

## Dynamic client allowlist
OIDC token verification now augments the existing static and first-party issuer/audience allowlist using **enabled, ready, OIDC** registrations in the application registry. No hardcoded VM1–VM10 list is required. Database unavailability must never add unregistered clients to trusted issuers or audiences.

## Example future OIDC application onboarding
1. Administrator registers `partner-crm` as OIDC with roles `admin/operator/user/viewer`.
2. Administrator provisions and configures Authentik OIDC client `pach-app-partner-crm` and its redirect URI (Step 2).
3. Administrator assigns `operator` to an existing LDAP user `alice`.
4. User logs in via the application. The application receives a valid OIDC access token for the registered client.
5. Application calls the endpoint above with that user token; denies access unless `allowed` is true. Apply local permissions to CRM resources.
6. Revoke the role or disable the application; subsequent role lookups deny access.

## Limitations / next step
- This interface uses a human's OIDC token and does not introduce privileged arbitrary-user lookup APIs.
- LDAP-only services cannot invoke it with an LDAP bind password. Such services can enforce their existing local ACLs or adopt a separately designed, tightly scoped API-to-API service credential workflow in Step 4.
- Dynamic issuer/audience allowlisting requires live verification against Authentik token behavior, notably the issued `azp`, `aud`, and `iss` claims.
- A source-level test and offline validation do not substitute for full DB, Authentik, and VM integration tests.

## Step 4 reference integration kit
See `examples/pach_rbac_lite/README.md` for working no-infrastructure client examples, LDAP patterns, and a future third-party CRM reference. These reference applications are not an acceptance substitute for deployment tests.
