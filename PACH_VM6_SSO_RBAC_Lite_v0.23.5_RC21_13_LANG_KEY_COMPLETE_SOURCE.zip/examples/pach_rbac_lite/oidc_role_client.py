"""Minimal VM6 application-role lookup client for a *server-side* OIDC web app.

Preconditions:
  * The caller already completed OIDC Authorization Code + PKCE using a
    vetted OIDC library, validated its session and received a USER access token.
  * Never accept a client-supplied Bearer token as a substitute for a login
    session. Never expose the access token to browser JavaScript unnecessarily.
  * VM6 itself validates iss/aud/azp/signature/expiry and binds azp to app_id.

This module only consumes the Step 3 integration API; it does NOT implement
OAuth login, a JWT validator, or a general authorization policy engine.
"""
from __future__ import annotations
from dataclasses import dataclass
import json
import re
import ssl
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit

_APP_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")
_ROLE_ID = re.compile(r"^[a-z][a-z0-9_-]{0,39}$")
# Role names are registered dynamically in VM6; no global four-role allowlist.
# Application-specific authorization is enforced by require_role().

class RoleLookupError(Exception):
    """Role service failure: callers MUST deny access, never grant it."""

@dataclass(frozen=True)
class RoleDecision:
    subject_uid: str
    application_id: str
    allowed: bool
    role: str | None


def parse_decision(payload: dict, expected_app: str, expected_uid: str | None = None) -> RoleDecision:
    """Validate untrusted HTTP JSON before interpreting it as authorization."""
    if not isinstance(payload, dict) or payload.get("ok") is not True or payload.get("contract_version") != "1.0":
        raise RoleLookupError("Invalid version or unsuccessful authorization response")
    if payload.get("application_id") != expected_app or not isinstance(payload.get("subject"), dict):
        raise RoleLookupError("Application/subject mismatch")
    uid = payload["subject"].get("uid")
    if not isinstance(uid, str) or not uid or len(uid) > 255 or (expected_uid is not None and uid != expected_uid):
        raise RoleLookupError("Unexpected subject identity")
    allowed = payload.get("allowed")
    role = payload.get("role")
    if type(allowed) is not bool:
        raise RoleLookupError("Invalid allowed value")
    if allowed and (not isinstance(role, str) or not _ROLE_ID.fullmatch(role)):
        raise RoleLookupError("Invalid or missing registered role identifier")
    if not allowed and role is not None:
        raise RoleLookupError("Denied response must not contain a role")
    return RoleDecision(uid, expected_app, allowed, role)


def lookup_user_role(vm6_base_url: str, app_id: str, user_access_token: str,
                     *, expected_uid: str | None = None, timeout: float = 5.0,
                     opener=None) -> RoleDecision:
    """Fetch authorization once per protected request; no cache by default.

    `opener` injection is for deterministic offline tests only. Deployment
    requires HTTPS with the system trust store or correctly provisioned CA.
    """
    url = urlsplit(vm6_base_url)
    if url.scheme != "https" or not url.netloc or url.username or url.password or url.query or url.fragment:
        raise ValueError("VM6 URL must be a clean HTTPS origin")
    if url.path not in ("", "/"):
        raise ValueError("VM6 URL should not contain a path")
    if not _APP_ID.fullmatch(app_id):
        raise ValueError("Invalid application identifier")
    if not user_access_token or any(c in user_access_token for c in "\r\n"):
        raise ValueError("Invalid bearer token")
    endpoint = f"{vm6_base_url.rstrip('/')}/api/integration/v1/applications/{quote(app_id, safe='')}/me"
    req = Request(endpoint, headers={"Authorization": f"Bearer {user_access_token}",
                                     "Accept": "application/json"})
    try:
        if opener is None:
            with urlopen(req, timeout=timeout, context=ssl.create_default_context()) as response:
                if response.status != 200:
                    raise RoleLookupError("Unexpected authorization status")
                body = response.read(16_385)
        else:
            with opener(req, timeout=timeout) as response:
                if response.status != 200:
                    raise RoleLookupError("Unexpected authorization status")
                body = response.read(16_385)
        if len(body) > 16_384:
            raise RoleLookupError("Authorization response too large")
        return parse_decision(json.loads(body), app_id, expected_uid)
    except (HTTPError, URLError, TimeoutError, ValueError, json.JSONDecodeError) as exc:
        raise RoleLookupError("Cannot verify application access") from exc


def require_role(decision: RoleDecision, allowed_roles: set[str] | frozenset[str]) -> None:
    """One local operation check; individual apps add resource checks themselves."""
    if not decision.allowed or decision.role not in allowed_roles:
        raise PermissionError("Application operation is not authorized")
