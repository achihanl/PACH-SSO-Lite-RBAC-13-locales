"""PACH SSO/RBAC Lite reference integration examples (not production adapters)."""
