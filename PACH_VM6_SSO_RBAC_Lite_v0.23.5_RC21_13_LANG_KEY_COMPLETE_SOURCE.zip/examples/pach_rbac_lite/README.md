# PACH RBAC Lite — Step 4 reference integration kit

**Status:** developer reference code, **not** proof of live OIDC, LDAP, SIP or CRM integration. Reuse integration patterns, not deployment defaults.

## Reference 1: OIDC web applications

1. Register an app (e.g. `partner-crm`) in VM6 Application Registry.
2. Provision an OIDC client via VM6 Step 2; configure redirect URI in the application's OIDC library.
3. Use standard Authorization Code + PKCE flow, verify callback state/nonce and issuer/audience using the OIDC library. Save the verified user access token server-side in a protected session; do not trust a browser-supplied `uid`.
4. On each protected operation call `lookup_user_role(vm6_url, app_id, server_side_access_token, expected_uid=authenticated_uid)`.
5. Require `allowed == true` and the operation's allowed application roles. Check detailed resource ownership **locally**. Fail closed when VM6 cannot be reached.
6. Never use a `client_credentials` token or an ID token for the `/me` API; do not assume a successful web login means application access.

`oidc_role_client.py` is standard-library-only HTTP client code, NOT a replacement for an OIDC login/session library. Its `opener` argument is a test seam only. Enforce HTTPS with certificate verification and limit request size/timeouts.

## Reference 2: LDAP protocol services

Use the native LDAP integration of the SIP, ejabberd, SMTP/IMAP or MQTT implementation, with LDAPS (or authenticated StartTLS), service-account least privilege, and the service's own authorization/ACL rules. `ldap_protocol_adapter.py` provides a Python-only example requiring `ldap3`.

**IMPORTANT:** Step 3's OIDC `/me` API does NOT accept LDAP username/password or generic LDAP bind tokens. LDAP authenticates protocol users, not a grant of application authorization. The service enforces resource permissions using its native ACL system. If a protocol service must consume centrally assigned application roles, a separately scoped machine-to-machine contract needs to be designed and reviewed; do not embed privileged VM6 admin credentials or query the VM6 application-role database directly.

## Reference 3: future partner CRM

`future_partner_crm.py` shows how a CRM can use the fixed v1 API with app id `partner-crm` and still enforce record ownership itself. No VM6 code change is required for registering an additional OIDC application. Provisioning and live claim-validation still require acceptance testing against Authentik.

## Quick offline validation

From repository root:

```bash
python -m unittest discover -s examples/pach_rbac_lite/tests -v
```

For the complete application project test suite, install the existing project requirements and run against the normal PostgreSQL/LDAP/Authentik test environment. These examples must not be counted as production integration tests.
