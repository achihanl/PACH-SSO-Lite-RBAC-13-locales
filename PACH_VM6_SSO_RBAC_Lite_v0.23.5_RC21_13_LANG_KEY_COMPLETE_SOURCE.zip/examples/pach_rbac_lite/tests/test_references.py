"""Offline tests for Step 4 examples; no external infrastructure needed."""
import io
import json
import unittest
from unittest.mock import patch
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from examples.pach_rbac_lite.oidc_role_client import (parse_decision, lookup_user_role,
    RoleLookupError, require_role, RoleDecision)
from examples.pach_rbac_lite.ldap_protocol_adapter import check_local_protocol_acl
from examples.pach_rbac_lite.future_partner_crm import authorize_customer_record

ALLOW = {"ok": True, "contract_version": "1.0", "application_id": "partner-crm",
         "subject": {"uid": "alice"}, "allowed": True, "role": "operator"}
DENY = {**ALLOW, "allowed": False, "role": None}

class FakeResponse:
    status = 200
    def __init__(self, data): self.payload = json.dumps(data).encode()
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, limit): return self.payload[:limit]

class ReferenceTests(unittest.TestCase):
    def test_allow(self):
        decision = parse_decision(ALLOW, "partner-crm", "alice")
        self.assertEqual(decision.role, "operator")
        require_role(decision, {"operator"})

    def test_denied_assignment(self):
        decision = parse_decision(DENY, "partner-crm")
        with self.assertRaises(PermissionError): require_role(decision, {"operator"})

    def test_cross_application_data_rejected(self):
        with self.assertRaises(RoleLookupError): parse_decision(ALLOW, "community-cms")

    def test_subject_mismatch_rejected(self):
        with self.assertRaises(RoleLookupError): parse_decision(ALLOW, "partner-crm", "bob")

    def test_inconsistent_role_rejected(self):
        with self.assertRaises(RoleLookupError): parse_decision({**DENY, "role": "admin"}, "partner-crm")

    def test_invalid_allowed_rejected(self):
        with self.assertRaises(RoleLookupError): parse_decision({**ALLOW, "allowed": 1}, "partner-crm")

    def test_unknown_role_rejected(self):
        with self.assertRaises(RoleLookupError): parse_decision({**ALLOW, "role": "super user"}, "partner-crm")

    def test_future_application_custom_role_is_supported(self):
        # VM6 application registry accepts custom roles; client must not
        # silently refuse them merely because they are not four built-ins.
        payload = {**ALLOW, "role": "billing_reviewer"}
        decision = parse_decision(payload, "partner-crm", "alice")
        require_role(decision, {"billing_reviewer"})
        with self.assertRaises(PermissionError):
            require_role(decision, {"operator"})

    def test_malformed_role_identifiers_denied(self):
        for role in ("", "Admin", "admin role", "a" * 41, "admin/owner", 42, None):
            with self.subTest(role=role), self.assertRaises(RoleLookupError):
                parse_decision({**ALLOW, "role": role}, "partner-crm")

    def test_explicit_app_role_restriction(self):
        decision = parse_decision(ALLOW, "partner-crm", "alice")
        with self.assertRaises(PermissionError):
            require_role(decision, {"admin"})

    def test_missing_expected_identity_fails_closed(self):
        with self.assertRaises(RoleLookupError):
            parse_decision({**ALLOW, "subject": {"uid": ""}}, "partner-crm")

    def test_invalid_endpoint_identifier_rejected(self):
        with self.assertRaises(ValueError):
            lookup_user_role("https://vm6.example", "../cms", "token")

    def test_max_length_registered_application_id_is_supported(self):
        app_id = "a" + "b" * 63  # 64-character registry maximum
        def opener(req, timeout):
            self.assertIn(f"/{app_id}/me", req.full_url)
            return FakeResponse({**ALLOW, "application_id": app_id})
        self.assertTrue(lookup_user_role("https://vm6.example", app_id, "token", opener=opener).allowed)

    def test_invalid_token_header_rejected(self):
        with self.assertRaises(ValueError):
            lookup_user_role("https://vm6.example", "partner-crm", "token\r\nX-Injected: true")

    def test_unsupported_contract_rejected(self):
        with self.assertRaises(RoleLookupError): parse_decision({**ALLOW, "contract_version": "2.0"}, "partner-crm")

    def test_https_only(self):
        with self.assertRaises(ValueError): lookup_user_role("http://vm6.example", "partner-crm", "token")

    def test_url_has_no_credentials(self):
        with self.assertRaises(ValueError): lookup_user_role("https://alice:pwd@vm6.example", "partner-crm", "token")

    def test_good_role_endpoint_request(self):
        def opener(req, timeout):
            self.assertEqual(req.full_url, "https://vm6.example/api/integration/v1/applications/partner-crm/me")
            self.assertEqual(req.get_header("Authorization"), "Bearer secret-token")
            return FakeResponse(ALLOW)
        self.assertTrue(lookup_user_role("https://vm6.example", "partner-crm", "secret-token", expected_uid="alice", opener=opener).allowed)

    def test_network_error_denies(self):
        from urllib.error import URLError
        def bad(*a, **k): raise URLError("down")
        with self.assertRaises(RoleLookupError): lookup_user_role("https://vm6.example", "partner-crm", "token", opener=bad)

    def test_local_ldap_acl(self):
        self.assertTrue(check_local_protocol_acl(True, resource="xmpp:room-a", permitted_resources=frozenset({"xmpp:room-a"})))
        self.assertFalse(check_local_protocol_acl(False, resource="xmpp:room-a", permitted_resources=frozenset({"xmpp:room-a"})))
        self.assertFalse(check_local_protocol_acl(True, resource="xmpp:room-b", permitted_resources=frozenset({"xmpp:room-a"})))

    def test_future_crm_keeps_local_permissions(self):
        decision = RoleDecision("alice", "partner-crm", True, "user")
        with patch("examples.pach_rbac_lite.future_partner_crm.lookup_user_role", return_value=decision):
            self.assertTrue(authorize_customer_record(vm6_url="https://vm6.example", session_access_token="token", session_uid="alice", record_owner_uid="alice", operation="edit"))
            self.assertFalse(authorize_customer_record(vm6_url="https://vm6.example", session_access_token="token", session_uid="alice", record_owner_uid="bob", operation="edit"))

    def test_crm_fail_closed(self):
        with patch("examples.pach_rbac_lite.future_partner_crm.lookup_user_role", side_effect=RoleLookupError("down")):
            self.assertFalse(authorize_customer_record(vm6_url="https://vm6.example", session_access_token="token", session_uid="alice", record_owner_uid="alice", operation="read"))

if __name__ == "__main__": unittest.main()
