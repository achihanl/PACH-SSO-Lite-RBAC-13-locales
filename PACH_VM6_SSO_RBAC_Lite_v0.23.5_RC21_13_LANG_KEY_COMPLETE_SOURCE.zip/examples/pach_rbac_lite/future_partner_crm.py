"""Future application example: no VM6 change when onboarding partner-crm.

The host web framework must first perform standard OIDC Auth Code + PKCE,
verify login/session state, and securely retain the USER access token.
Use this example from a backend route, never from untrusted browser input.
"""
from __future__ import annotations
from .oidc_role_client import lookup_user_role, require_role, RoleLookupError

APPLICATION_ID = "partner-crm"


def authorize_customer_record(*, vm6_url: str, session_access_token: str,
                              session_uid: str, record_owner_uid: str,
                              operation: str) -> bool:
    """VM6 role + CRM-owned record check; deny by default on any failure."""
    try:
        decision = lookup_user_role(vm6_url, APPLICATION_ID, session_access_token,
                                    expected_uid=session_uid)
        if operation == "read":
            require_role(decision, {"admin", "operator", "user", "viewer"})
            return decision.role in ("admin", "operator") or record_owner_uid == session_uid
        if operation == "edit":
            require_role(decision, {"admin", "operator", "user"})
            return decision.role in ("admin", "operator") or record_owner_uid == session_uid
        return False
    except (RoleLookupError, PermissionError):
        return False
