"""LDAP protocol integration example: secure directory bind and LOCAL controls.

Production SIP/SMTP/IMAP/XMPP/MQTT services SHOULD use their native LDAP
modules. This small Python adapter is only for services that explicitly need
an LDAP client integration. It intentionally does NOT fetch PACH application
roles from the VM6 PostgreSQL tables: Step 3's /me endpoint requires an OIDC
human access token, which LDAP credentials cannot impersonate.

Requires: ldap3 (optional demonstration dependency, not imported at startup).
"""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class LdapConfig:
    server_host: str
    service_dn: str
    service_password: str
    base_dn: str
    ca_cert_file: str
    port: int = 636


def authenticate_directory_user(cfg: LdapConfig, uid: str, password: str) -> bool:
    """Search by escaped uid using a service bind, then bind as that DN.

    Reject malformed identities/passwords; require validated LDAPS transport.
    No anonymous or simple cleartext bind fallback. No password logging.
    """
    if not uid or len(uid) > 255 or any(c in uid for c in "\x00\r\n") or not password:
        return False
    import ssl
    from ldap3 import Server, Connection, Tls, SUBTREE, SIMPLE
    from ldap3.utils.conv import escape_filter_chars
    if not cfg.ca_cert_file or not cfg.server_host or not cfg.service_dn:
        raise ValueError("Secure LDAP configuration is required")
    tls = Tls(validate=ssl.CERT_REQUIRED, ca_certs_file=cfg.ca_cert_file)
    server = Server(cfg.server_host, port=cfg.port, use_ssl=True, tls=tls, connect_timeout=5)
    service = Connection(server, user=cfg.service_dn, password=cfg.service_password,
                         authentication=SIMPLE, auto_bind=True, receive_timeout=5)
    try:
        escaped_uid = escape_filter_chars(uid)
        if not service.search(cfg.base_dn, f"(&(objectClass=person)(uid={escaped_uid}))",
                              search_scope=SUBTREE, attributes=["dn"], size_limit=2):
            return False
        if len(service.entries) != 1:
            return False
        user_dn = service.entries[0].entry_dn
    finally:
        service.unbind()
    user_connection = Connection(server, user=user_dn, password=password,
                                 authentication=SIMPLE, auto_bind=False, receive_timeout=5)
    try:
        return bool(user_connection.bind())
    finally:
        user_connection.unbind()


def check_local_protocol_acl(authenticated: bool, *, resource: str,
                             permitted_resources: frozenset[str]) -> bool:
    """Example ONLY: real protocol servers maintain their native ACLs."""
    return bool(authenticated and resource in permitted_resources)
