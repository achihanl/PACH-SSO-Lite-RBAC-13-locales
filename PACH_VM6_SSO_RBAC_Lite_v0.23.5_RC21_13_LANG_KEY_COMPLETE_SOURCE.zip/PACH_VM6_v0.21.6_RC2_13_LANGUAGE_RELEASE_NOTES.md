# PACH VM6 v0.21.6 RC2 — 13-Language Integration Report

Baseline: PACH VM6 v0.21.5 RC1 consolidated source. All 1371 existing archive files retained.

## Supported language codes
`en, ar, de, es, fr, id, ja, ko, pt-BR, th, vi, zh-Hans, zh-Hant` (13 total; matches PACH's established language set).

## Implemented
- Frontend language selector and client-side locale detection updated to 13 languages, including Arabic RTL support via i18next `dir()`.
- Backend `PATCH /api/me` `preferredLanguage` validation updated to exactly the same 13 codes, so preferences persist to LDAP.
- Localized application registry / application roles / OIDC-LDAP provisioning UI (`applications.json`) for 10 newly added languages.
- Localized key navigation, sign-in messages, basic shared controls, and language settings for those languages.
- Namespace/key-level English fallback retained for untranslated legacy administration surfaces.
- Test coverage updated for 13 codes, translated key integrity and interpolation placeholder parity.

## Translation coverage
English source contains **1062** translatable leaf strings. Newly added language resources contain **70 translated leaf strings per locale**, in 5 namespaces. This is **partial UI translation**, not full PACH VM6 localization.

- `en`: 1062 provided strings
- `ar`: 70 provided strings
- `de`: 70 provided strings
- `es`: 70 provided strings
- `fr`: 70 provided strings
- `id`: 70 provided strings
- `ja`: 70 provided strings
- `ko`: 70 provided strings
- `pt-BR`: 70 provided strings
- `th`: 70 provided strings
- `vi`: 70 provided strings
- `zh-Hans`: 1062 provided strings
- `zh-Hant`: 1062 provided strings

## Remaining work / release blockers
- Translate and review remaining English strings in the 10 new languages, then update coverage to 100% before claiming full UI localization.
- Native-speaker terminology QA, including RTL visual review for Arabic and long-label layout for German/Portuguese.
- Frontend production build and browser switching tests in the full frontend dependency environment.
- Backend integration regression and live LDAP preferredLanguage persistence test.
- Existing v0.21.5 RC1 live Authentik/LDAP/PostgreSQL production-validation blockers remain.

## Compatibility
- No changes to application registry, authorization, SSO or protocol authentication APIs and behavior.
- No schema migration required for language additions; LDAP `preferredLanguage` remains a string field.
- The previous release archive is unchanged.
