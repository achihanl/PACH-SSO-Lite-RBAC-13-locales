# MCP Tools for Token Efficiency

## Serena (Symbolic Code Navigation)

Prefer Serena's semantic tools over reading entire files:

| Task | Use This | Not This |
|------|----------|----------|
| Understand a file's structure | `get_symbols_overview` | Reading entire file |
| Find a function/class | `find_symbol` with name pattern | Grep + Read |
| Trace usages | `find_referencing_symbols` | Manual grep |
| Edit a function | `replace_symbol_body` | Read + Edit entire file |

**Activation:** Call `activate_project` at session start — Serena doesn't auto-activate.

## Context7 (Up-to-Date Library Docs)

For current API docs, use Context7 instead of relying on training knowledge:

```
# First resolve library ID
mcp__plugin_context7_context7__resolve-library-id(libraryName="react", query="useEffect cleanup")

# Then query docs
mcp__plugin_context7_context7__query-docs(libraryId="/facebook/react", query="useEffect cleanup")
```

**Use Context7 for:** React 19, TanStack Router/Query, Zustand, Base UI (@base-ui/react), Tailwind CSS 4, Vite 6

**When to use:** Before implementing unfamiliar patterns, when APIs may have changed, or when stuck on library usage.
