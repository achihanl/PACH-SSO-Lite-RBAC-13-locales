---
paths:
  - "deploy/dev/authentik-seed/**"
  - "src/backend/authentik_client.py"
  - "src/backend/oidc_verify.py"
  - "src/backend/config.py"
---

# Authentik API Gotchas (2025.8+)

- **2026.5+:** OAuth2 providers carry a `grant_types` allowlist; freshly created providers default to `[]` → ALL token grants refused (`invalid_grant`). Seed must set it explicitly. The web provider gets `authorization_code` + `refresh_token` only; tests mint user tokens via `client_credentials` on the dev-only `azblink-directory-test` provider
- **In-place upgrades must step one release at a time** (2025.8 → 2026.5 direct = migration crashloop: `column authentik_tenants_tenant.pagination_default_page_size does not exist`). Dev fix: wipe `dev_authentik_pg_data` volume + reseed
- `redirect_uris` must be `[{matching_mode: "strict", url: "..."}]` dicts, NOT plain strings
- `invalidation_flow` is REQUIRED when creating an OAuth2 provider
- OAuth2 provider needs `property_mappings` (openid/profile/email scope mappings) AND `signing_key` — without signing_key, JWKS returns empty
- **Claims from multiple scope mappings are merged with deepmerge's `always_merger` — list-valued claims APPEND, they do not overwrite.** The built-in `profile` mapping already emits `groups`, so adding a custom `groups` scope mapping doubles every entry in the claim (#279). One emitter per list claim. Inspect a mapping's isolated output with `POST /api/v3/propertymappings/all/{pk}/test/ {"user": <pk>}`
- Authentik stamps `iss` claim based on the URL used to access it — Docker-internal vs tunnel URLs produce different issuers
- `OIDC_ACCEPTED_ISSUERS` (comma-separated) handles multi-issuer; `OIDC_ISSUER` is for JWKS/discovery fetching only
- Authentik end-session endpoint does NOT revoke tokens — must use `DELETE /api/v3/oauth2/access_tokens/{id}/`
- **2026.5 RP-initiated logout (`/application/o/<slug>/end-session/`) returns 400 when `post_logout_redirect_uri` is present unless BOTH hold** (see `EndSessionView.validate()`): (1) `id_token_hint` is supplied — it is MANDATORY when a post-logout URI is present (`id_token_hint_missing`); (2) the URI strict/regex-matches a redirect URI of type **`logout`** (`provider.post_logout_redirect_uris`), which is SEPARATE from `authorization`-type callback URIs (`invalid_post_logout_redirect_uri`). Without `post_logout_redirect_uri` at all → no checks, plain logout. `client_id` query param is ignored (provider resolved from URL slug). Frontend must persist the `id_token` and send it as `id_token_hint`; seed must register `<origin>/login` with `redirect_uri_type: "logout"`.
- **`GET /core/applications/?slug=<slug>` does NOT filter `results`.** The application viewset serves `results` from a per-user cache of every *allowed* application and applies the query filter only to `pagination.count`. With two apps seeded, `?slug=<nonexistent>` returns `count=0` with both apps in `results`. So `if results:` is true whenever any app exists and `results[0]["pk"]` is the wrong app. Use retrieve-by-slug (`GET /core/applications/<slug>/` — the viewset's `lookup_field`) or key on `pagination.count`. Filters on `/core/users/?username=`, `/core/groups/?name=`, `/providers/oauth2/?client_id=` and `/sources/ldap/?slug=` are genuinely applied; this defect is specific to applications.
- **A policy on a stage that runs BEFORE the password stage is checked once per executor session.** A session identified while the check passed keeps that stage removed; the password binding itself is re-evaluated per request (`re_evaluate_policies`). Put throttles on the password binding (negated) + a fail-closed guard (`"user_backend" not in request.context`) on a deny stage after it AND on the user-login binding (E5, ARD-018 amendment).
- **Reputation:** row per (identifier, ip); policy passes when the summed score <= threshold; success adds +1 clamped by tenant `reputation_upper_limit` (also clamps the increment, so 0 = successes never heal). `expires` set at insert only; expired rows are hidden but still absorb updates until `clean_expired_models` (every 5 min).
- **Concurrency is not `web.workers × web.threads`.** 2026.5 serves Django through gunicorn `DjangoUvicornWorker` (ASGI); `web.threads` is ignored and each request gets its own thread. 90 of 96 parallel flow POSTs ran at once on dev (the rest hit DB connection errors). Any check-then-act in a flow races at that width (G23); the seed's bind budget reserves atomically in one SQL upsert instead.
- **The brand flow's password binding already carries `default-authentication-flow-password-stage`** ("password needed"). A second policy there is a no-op under the binding's default `policy_engine_mode: any`; set `all` (G22). Blueprint re-apply leaves `policy_engine_mode` and extra bindings alone.
- **Trusted proxies:** 2026.5 default `listen.trusted_proxy_cidrs` trusts every RFC1918 range. Only the Go server reads it; `AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS` takes a comma-separated list.
- **PATCH on `/policies/bindings/<pk>/` answers 405 (`Allow: GET, HEAD, OPTIONS`) on 2026.5; PUT the whole binding.** Expression policies are stored with trailing whitespace stripped: send them stripped or every seed run re-patches.
- **Expression policies run in-process with the real request:** `request.http_request.session` writes persist, `django.db.connection` is the request's connection (autocommit). Errors use the binding's `failure_result`. Policy results are not cached on flow re-evaluation (`ReevaluateMarker` sets `use_cache = False`).
- Policy bindings on a flow-stage binding: target = the binding's `pk`. `GET /policies/bindings/?target=<fsb pk>` returns 400; filter with `?policy=<pk>` and match `target` client-side. Flows are retrieved/deleted by **slug** (`/flows/instances/<slug>/`), not pk.
- Flow-executor POSTs on an already-authenticated session need `X-authentik-CSRF` = the `authentik_csrf` cookie. Admin TOTP/static device create (`/authenticators/admin/*/`) answers 405 on 2026.5; enrol through `default-authenticator-totp-setup` instead.
- First startup takes 2.5-4 min of DB migrations before the API is reachable, longer under load (seed waits up to `AUTHENTIK_WAIT_SEC`, default 600)
- `sub_mode: hashed_user_id` → `sub` claim is hash(pk+install_id), NOT username — use `preferred_username` for LDAP uid mapping

## Branding CSS (`deploy/dev/authentik-seed/assets/custom.css`)

- **Login-layout selectors are coupled to Authentik's flow markup version.** 2026.5 removed the `.pf-c-login__container` grid wrapper, silently breaking the two-column scheme (card uncentered, submit button clipped below fold on short viewports). **Re-verify the login form layout after every Authentik upgrade.** Center the card on the real flex parent `.pf-c-login` (the `ak-flow-executor` host), not on grid wrappers that may not exist.
- CSS ships via Brand API `branding_custom_css` (inline), set by `seed_authentik.py:ensure_branding()`. **Editing the file alone does NOT update a running instance** — re-run seed OR `PATCH /api/v3/core/brands/{uuid}/ {"branding_custom_css": ...}` (token `dev-authentik-api-token`), then reload. Brand uuid: look up via `?default=true`, never hardcode.
- `branding_custom_css` is injected into all Shadow DOMs automatically (Authentik 2025.4+).
