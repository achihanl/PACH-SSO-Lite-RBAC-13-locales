---
paths:
  - "src/frontend/**/*.{tsx,ts,css}"
  - "src/frontend/packages/azblink-ui/**/*"
---

# Frontend Component Architecture

## Two-Layer Component Architecture

**Layer 1 — Primitives (`packages/azblink-ui/primitives/`)**
- Domain-agnostic UI atoms — Button, Badge, Input, Dialog, DataTable, Tabs, Skeleton, StatusBadge, TrendBadge, LiveIndicator, etc. (35 total)
- Single reusable implementation per visual element; consistent look-and-feel
- Each primitive: `Component.tsx` + `Component.module.css` + `Component.types.ts` + `index.ts`
- **Styling:** CSS Modules only — all values MUST reference `tokens.css` variables (`var(--text-sm)`, `var(--leading-snug)`, etc.)
- Built on `@base-ui/react` (headless) — primitives wrap Base UI and add design system styling
- Barrel-exported via `packages/azblink-ui/index.ts` — all consumers import from `@azblink/ui`
- Create when: used by 2+ features, OR standard UI control (form input, modal, table)
- Do NOT create for: one-off feature-specific layout; domain logic baked in

**Layer 2 — Feature components (`src/components/features/`)**
- Domain-specific composites — UserDetailPanel, GroupManagementPage, OrgTree, modals, etc.
- Organized by domain: `user-management/`, `org-management/`, `group-management/`, `dashboard/`, `audit-management/`, `org-profiles/`, `provisioning-ops/`, `qr-management/`, `qr-preview/`, `settings/`
- Shared files: `empty-state.tsx`, `stat-card.tsx`, `search-input.tsx`, `health-status.tsx`, `profile-dropdown.tsx`, `qr-display.tsx`, `session-expired-modal.tsx`, `user-table.tsx`
- **Styling:** Tailwind utilities — colors reference tokens via `globals.css` `@theme inline` bridge (e.g., `text-text`, `bg-muted`)
- Import primitives from `@azblink/ui`, compose with domain data/logic

**Decision flow:**
1. Domain-agnostic and reusable? → **Primitive** in `packages/azblink-ui/primitives/`
2. Domain-specific layout/logic? → **Feature component** in `src/components/features/<domain>/`
3. Shared across domains, no business logic? → Evaluate: primitive candidate or shared feature file
4. `@azblink/ui` already exports something similar? → Use it, don't reinvent

```tsx
// CORRECT — features import primitives from @azblink/ui
import { Button, Card, Badge, cn } from '@azblink/ui';
```

Do NOT create components in `src/frontend/src/components/ui/` — deleted during shadcn migration.

## Typography & Design Token Rules

**Single source of truth:** `tokens.css` owns ALL typography, color, spacing, radius, and shadow values.

| Token Category | CSS Modules (primitives) | Tailwind (features) |
|----------------|--------------------------|---------------------|
| Font family | `var(--font-sans)` | `font-sans` |
| Font size | `var(--text-sm)` | `text-sm` (bridged via `@theme`) |
| Font weight | `var(--font-medium)` | `font-medium` |
| Line height | `var(--leading-snug)` | `leading-snug` (if bridged) |
| Color | `var(--color-text-muted)` | `text-muted-foreground` or `text-[var(--color-text-muted)]` |

**Hard rules:**
- **Never hardcode** `font-size`, `line-height`, `font-weight`, `letter-spacing`, or `font-family` in CSS Modules — always use `var(--token-name)`
- **Font:** Inter (sans), JetBrains Mono (mono) — loaded via Google Fonts in `index.html`
- **globals.css `@theme` block** restates font stacks literally because bare `@theme` (Tailwind CSS 4) can't use `var()` — keep in sync with `tokens.css` manually
- **Dark-first tokens:** `tokens.css` defines dark mode as default; `[data-theme="light"]` overrides — never add color values outside this system
- **Audit before committing CSS:** grep for hardcoded values (`font-size: \d`, `line-height: [\d.]`, `font-weight: \d`) — zero matches expected in CSS Modules
- **Badge variants:** `success`, `warning`, `error`, `info`, `muted`, `purple`, `outline` (NOT `secondary`, NOT `default`)
