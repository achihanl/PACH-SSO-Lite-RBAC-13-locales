---
name: patrol-investigate
version: 1.1.0
description: |
  Investigate a UI bug report by browsing the application, reproducing the issue,
  and documenting findings in a structured YAML issue file. Reads the project's
  Patrol manifest for navigation context. Creates a manifest if none exists.
  Use when asked to "investigate", "reproduce", "look into", or "check this bug".
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
  - Grep
---

# patrol-investigate: Bug Investigation Skill

Investigate a reported bug by browsing the application, reproducing the issue, and writing a structured YAML issue file to `qa/patrol/issues/`.

## 1. Setup

Check for the Patrol directory structure. Create it if missing.

```bash
mkdir -p qa/patrol/issues/screenshots
```

Read `qa/patrol/manifest.yml` if it exists. If it exists but fails to parse, stop and tell the user: "Manifest YAML is malformed — please fix `qa/patrol/manifest.yml` before continuing." Do not attempt recovery.

Check `.patrol-version` if it exists — compare to this skill's version (1.1.0). If the installed version is older, warn: "Patrol skills may be outdated (installed: X, current: 1.1.0). Run the install script to update."

## 2. Parse Input

You receive a freeform bug description, and optionally a URL or page ID hint.

1. Extract the core issue from the description
2. Identify a short title for the issue (used for the issue ID)
3. If the user provided a URL or page ID, note it as the starting point
4. If a manifest exists, scan its `pages` and `flows` for a matching page (by path or ID) or flow. If found, you'll use its navigation steps as a starting point.

## 3. Environment Check

Before launching the browser, scan for `${VAR}` references in the manifest (if it exists) and in any navigation steps you plan to use. For each `${VAR}`:

```bash
echo "${VAR_NAME:-__UNSET__}"
```

If any variable prints `__UNSET__`, stop and report: "Missing environment variables: VAR1, VAR2. Set them before running investigation."

## 4. Browser Investigation

Use `/browse` (gstack) to investigate. Run the browser setup first:

```bash
# Patrol: Browser setup
_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
B=""
[ -n "$_ROOT" ] && [ -x "$_ROOT/.claude/skills/gstack/browse/dist/browse" ] && B="$_ROOT/.claude/skills/gstack/browse/dist/browse"
[ -z "$B" ] && B=~/.claude/skills/gstack/browse/dist/browse
if [ -x "$B" ]; then
  echo "BROWSER_READY"
else
  echo "BROWSER_NOT_AVAILABLE"
fi
```

If `BROWSER_NOT_AVAILABLE`: stop and tell the user "gstack /browse is not available. Install gstack or run the browse setup first."

If `BROWSER_READY`: use `$B` as the command prefix for all browser commands below.

### Navigation Execution Pattern

**Important:** Element refs (`@eN`) from a snapshot are invalidated by any subsequent browser command that modifies the page. Always re-snapshot before using new refs. Never reuse a ref from a previous snapshot.

For each navigation step, use the snapshot-then-ref pattern:

**GOTO:**
```
1. $B goto <baseUrl><path>
2. $B snapshot
3. Verify page loaded — check for expected heading or content in snapshot output
```

**CLICK:**
```
1. $B snapshot
2. Find the element matching "<text>" in snapshot output (look for [button], [link], or [text] containing the target)
3. $B click @eN  (using the element ref from snapshot)
4. Wait 1s if page transition is expected
5. $B snapshot  (verify new state)
```

**FILL:**
```
1. $B snapshot -i  (interactive elements only)
2. Find [textbox] or [input] matching the label/placeholder
3. $B fill @eN "<value>"
```

**WAITFOR:**
```
1. $B snapshot
2. Check if expected text/element is present in snapshot output
3. If found → proceed to next step
4. If not found and attempts < 3 → sleep 2, go to step 1
5. If not found after 3 attempts → record as stale navigation step in notes, continue with remaining steps
```

**ASSERT:**
```
1. $B snapshot
2. Check conditions against snapshot output
3. Record pass/fail — do NOT stop on failure, capture the result for the issue file
```

### Navigation Strategy

- **If manifest has a matching flow**: replay its steps using the patterns above
- **If a URL hint was provided**: use GOTO with `<baseUrl><hint>`
- **If no match and no hint**: use GOTO with `<baseUrl>` (from manifest or ask user)

### Reproduce the Bug

1. Navigate to the area described in the bug report using the patterns above
2. Perform the actions described in the bug report (clicking, filling, etc.)
3. After each action, take a snapshot to observe changes: `$B snapshot`
4. Note: the URL, any visible text, missing elements

### Capture Evidence

Record:
- **url**: current URL after reproduction
- **consoleErrors**: capture from `$B console` using the filtering rules below
- **notes**: your observations about what you saw vs what was expected
- **screenshot**: attempt to capture:
  ```bash
  $B screenshot qa/patrol/issues/screenshots/<issue-id>-observed.png
  ```
  If the screenshot command fails, set screenshot to `null` — it's optional.

### Console Error Filtering

After running `$B console`, filter the output:

**Capture as consoleErrors:**
- Lines containing `[error]` — these are real errors
- Lines containing `[warning]` about WebSocket, network, or resource loading failures

**Ignore:**
- Lines containing `[debug]` — framework debug output
- Lines containing `[info]` — informational messages
- Framework noise: vite connection messages, React DevTools suggestions, authentik debug logs, TanStack debug output

### If the Bug Cannot Be Reproduced

If you navigate to the area and everything works as expected, the bug cannot be reproduced. Still create the issue file but with `status: cannot-reproduce` and note what you observed (the working state).

### If the Page Returns 404/500

The error page IS the bug. Capture the error as the observed state and set `status: reproduced`.

### If the Browser Crashes Mid-Session

Write whatever you've captured so far to the issue file. Add a history note: "Browser crashed during investigation. Partial findings recorded." Do not advance the status beyond what was confirmed.

## 5. Generate Issue ID

Create a unique issue ID from the title:

1. Get today's date: `YYYY-MM-DD`
2. Take the first 6 words of the title
3. Lowercase, replace non-alphanumeric characters with hyphens, collapse multiple hyphens
4. Combine: `YYYY-MM-DD-<slug>` (e.g., `2026-03-25-login-button-doesnt-redirect-after`)
5. Check if `qa/patrol/issues/<id>.yml` already exists
6. If collision: append `-2`, `-3`, etc. until unique

## 6. Deduplication Check

Before creating a new issue file, check for existing duplicates:

1. Read all `qa/patrol/issues/*.yml` files (use Glob to find them)
2. For each existing issue, check:
   - Does `navigation.steps[0]` point to the same starting URL?
   - Do `observed.consoleErrors` overlap with what you found?
   - Do `observed.notes` share key terms with your findings?
3. If a likely duplicate is found:
   - Do NOT create a new file
   - Instead, append a new entry to the existing issue's `history` array
   - Update `observed` with current findings if they differ
   - Print: "Found existing issue `<id>` with matching symptoms. Updated instead of creating duplicate."
   - Return the existing issue's path

## 7. Write Issue File

Create `qa/patrol/issues/<issue-id>.yml` with this structure:

```yaml
schemaVersion: "1.0"
id: "<generated-id>"
title: "<short title from bug description>"
source: "user-report"
created: "<ISO 8601 timestamp>"
status: "reproduced"  # or "cannot-reproduce"

report:
  description: "<original bug description>"

navigation:
  fromManifest: <flow-id or null>
  steps:
    # The actual steps you took to reach the issue
    - goto: <url>
    - click: "<text>"
    # ... etc

observed:
  url: "<current URL>"
  screenshot: <relative path or null>
  consoleErrors: [<any JS errors>]
  notes: "<your observations>"

expected:
  url: null
  screenshot: null
  assertions: []

history:
  - timestamp: "<ISO 8601>"
    action: investigated
    agent: patrol
    notes: "<summary of what was found>"

promote:
  toManifest: true
  targetFlow: <matching flow id or null>
  replaceSteps: false
```

Use the Write tool to create this file. Then validate:

```bash
python3 -c "import yaml; yaml.safe_load(open('qa/patrol/issues/<issue-id>.yml')); print('VALID')"
```

- If `VALID`: proceed to the next section.
- If error: the YAML is malformed (usually quoting or indentation). Read the file, fix the issue, write it again, re-validate. Max 2 retries.

## 8. Bootstrap Manifest

If `qa/patrol/manifest.yml` did NOT exist before this investigation, create a minimal one:

```yaml
version: "1.0"
project:
  name: "<project name from git remote, directory name, or ask user>"
  baseUrl: "<the base URL you investigated>"

auth:
  strategies: []
  # TODO: Configure auth strategies for your project

pages:
  - id: <page-id from the page you visited>
    path: <path>
    title: "<page title>"
    requiresAuth: true  # adjust based on observation
    assertions: []

flows: []
```

Note in your output: "Created initial manifest at `qa/patrol/manifest.yml`. Edit it to add auth strategies and additional pages."

## 9. Output Summary

Print a clear summary:

```
## Investigation Complete

**Issue:** <issue-id>
**File:** qa/patrol/issues/<issue-id>.yml
**Status:** reproduced (or cannot-reproduce)

**Observed:**
- URL: <url>
- Console errors: <count> (list them if any)
- Notes: <brief observation>

**Manifest:** <created | already existed | updated>

**Next steps:**
1. Apply a fix for the issue
2. Run `/patrol-verify <issue-id>` to confirm the fix
```
