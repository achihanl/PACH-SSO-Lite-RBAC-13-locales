---
name: web-configure
version: 1.0.0
description: |
  Discover, configure, and verify settings on remote web admin panels.
  Produces portable YAML playbooks for replay. Uses curl for reliable
  operations and gstack /browse for visual evidence.
  Use this skill whenever the user wants to configure a remote web app,
  set up LDAP/DNS/network/service settings on an admin panel, replay a
  saved configuration playbook, or automate web form submission. Triggers
  on: "configure the X on this server", "set up LDAP client", "replay
  playbook", "web-configure", "admin panel config", "headless configuration",
  or any request to fill in forms on a remote web UI and verify the result.
  NOT for SPAs (React/Vue/Angular), OAuth login flows, or file uploads.
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
  - Grep
---

# web-configure: Headless Web App Configuration

Configure remote web admin panels and produce replayable YAML playbooks.

**Example:**
User: "Configure the LDAP client on the admin panel at http://192.168.122.220:8082, it's under System > User > AD/LDAP"
Result: Discovers page, configures LDAP, saves playbook with screenshots, all assertions passed.

## 1. Setup

```bash
mkdir -p playbooks/web-configure/screenshots
```

Check for gstack /browse:

```bash
_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
B=""
[ -n "$_ROOT" ] && [ -x "$_ROOT/.claude/skills/gstack/browse/dist/browse" ] && B="$_ROOT/.claude/skills/gstack/browse/dist/browse"
[ -z "$B" ] && B=~/.claude/skills/gstack/browse/dist/browse
if [ -x "$B" ]; then
  echo "BROWSER_READY"
else
  echo "BROWSER_NOT_AVAILABLE"
fi
```

If `BROWSER_NOT_AVAILABLE`: warn "gstack /browse not available. Running in curl-only mode." Set `BROWSE_AVAILABLE=false`.
If `BROWSER_READY`: set `BROWSE_AVAILABLE=true`.

## 2. Parse Input

Extract from the user's request:
1. `url` — base URL of the target web app (required)
2. `objective` — what to configure (required, freeform)
3. `navigation_hint` — breadcrumb path (optional, e.g., "System > User > AD/LDAP")
4. `playbook_id` — existing playbook ID (optional, for replay)
5. `--replay` flag — force replay mode
6. `--var VAR=value` — variable overrides

## 3. Playbook Resolution

Search for matching playbook by grepping for the user's target URL:

```bash
# Substitute the actual URL from user input (e.g., "http://192.168.122.220:8082")
grep -rl "$TARGET_URL" playbooks/web-configure/*.yml 2>/dev/null
```

Match on both `target.baseUrl` + `phases.navigate.hint` (two playbooks for same server, different pages coexist).

Decision tree:
- Match found + `--replay` → **Replay mode**
- Match found, no flag → Ask: "Found existing playbook '<id>'. Replay it, or rediscover?"
- No match → **Discover + Configure mode**

## 4. Variable Resolution

For each variable:
1. Check env var: `echo "${VAR_NAME:-__UNSET__}"`
2. Check `--var` flag override
3. If still unset and has `default` → use default
4. If still unset and no default → ask user

**Validation:** If variable has `pattern`, validate against regex. Stop if invalid.

**Security gate:** If any variable has `secret: true` AND `default` is set, reject: "Secret variable '<name>' has a default. Remove it from the playbook."

## 5. Phase: Auth

Authenticate and acquire session cookies.

### TLS Handling

If `target.tlsVerify` is `false`, add `-k` to ALL curl commands. Log: "Warning: TLS verification disabled."

```bash
TLS_FLAG=""  # Set to "-k" if target.tlsVerify is false
```

### curl layer

Substitute values from the playbook's `auth.curl` section — URL from `url`, form fields from `data` with `${VAR}` replaced by resolved values. Parse each cookie listed in `extract.cookies`. Add `--max-time 30` to all curl calls (or use playbook's `timeout` value).

```bash
# Example: substitute actual URL, form data, and cookie names from playbook
COOKIES=$(curl -s --max-time 30 $TLS_FLAG -D - -o /tmp/wc-auth-body.txt \
  -d "action=UserLogin&active=true&loginid=${ADMIN_USER}&loginpasswd=${ADMIN_PASS}" \
  "${BASE_URL}/apps/login.php?item=admin" | grep -i 'Set-Cookie:')

# Parse each cookie name from the playbook's extract.cookies array
PHPSESSID=$(echo "$COOKIES" | grep -oP 'PHPSESSID=\K[^;]+')
```

Check redirect location contains expected string from `expect.redirectContains`. If auth fails (no redirect, wrong status): Stop. "Auth failed. Check credentials."

### browse layer (if BROWSE_AVAILABLE)

Before using browse, read `references/browse-patterns.md` for batching rules.

All browse commands in a SINGLE Bash call:
```bash
B=<browse binary>
CI=1 $B goto "${BASE_URL}<login_url>"
CI=1 $B snapshot -i
CI=1 $B fill @eN "<username>"
CI=1 $B fill @eN "<password>"
CI=1 $B click "Sign In"
```

### Cookie bridge

Inject curl cookies into browse at the start of EVERY browse batch (cookies don't persist between batches because the server restarts between Bash calls):
```bash
CI=1 $B goto "${BASE_URL}/any-page"    # establish domain
CI=1 $B cookie "PHPSESSID=$COOKIE"     # inject cookie
CI=1 $B goto "${BASE_URL}/target"      # now authenticated
```

## 6. Phase: Navigate

Follow navigation hint to target page.

### curl layer

For each URL in `navigate.curl.chain`:
```bash
PAGE=$(curl -s $TLS_FLAG -b "PHPSESSID=$COOKIE" "${BASE_URL}<url>")
echo "$PAGE" | grep -q "<expected>"
```

### Fallback

1. Hint doesn't match → list available links, ask user
2. Still stuck → browse handoff (if BROWSE_AVAILABLE)

### browse layer

Single Bash call:
```bash
CI=1 $B goto "${BASE_URL}<url>"
CI=1 $B cookie "PHPSESSID=$COOKIE"
CI=1 $B goto "${BASE_URL}<target>"
CI=1 $B snapshot -i
```

For frameset apps: `CI=1 $B frame "<selector>"`

## 7. Phase: Discover (first run only)

Map form structure. Skip on replay (do staleness check instead).

### curl layer

```bash
PAGE=$(curl -s $TLS_FLAG -b "PHPSESSID=$COOKIE" "${BASE_URL}<pageUrl>")
```

Extract: forms (count, id, action), fields (id, name, type, value), hidden fields, submit mechanism.

Submit mechanism types:
- `standard-post`: regular POST, follow redirect
- `ajax-post`/`ajax-json`: add `X-Requested-With: XMLHttpRequest`, expect body response
- `js:functionName()`: same as ajax, endpoint found in JS function body

Build `discover.forms` and `discover.fingerprint` for playbook.

### Staleness check (replay only)

Check each fieldId from fingerprint:
```bash
for FIELD in <fieldIds>; do
  echo "$PAGE" | grep -c "id=\"$FIELD\""
done
```

Match rate = `(found / expected) * 100`.
- 100% → continue
- 70-99% → warn, trigger rediscovery
- <70% → stop. "Page changed significantly. Use --rediscover."

### Rediscovery flow

1. Re-run discover with curl
2. Diff new vs stored form map
3. Show user changes (fields added/removed/renamed, action URL changes)
4. Ask: "Update playbook with new structure, or abort?"
5. If update: rewrite discover + configure, preserve auth/navigate/variables/runs
6. Set status to `draft` until next successful verify

## 8. Phase: Configure

Execute named operations.

### curl layer

For each operation in `configure.operations`, substitute the operation's `url` and `data` fields (with `${VAR}` replaced by resolved values):
```bash
# Example: substitute URL and data from the operation's curl section
RESULT=$(curl -s --max-time 30 $TLS_FLAG -b "PHPSESSID=$COOKIE" \
  -H "X-Requested-With: XMLHttpRequest" \
  -d "action=aSystemAdLdapUserAuth&active=save&uri=${LDAP_HOST}" \
  "${BASE_URL}/apps/index.php?item=systema")
```

Content types: `form` → `-d`, `json` → `-H "Content-Type: application/json" -d`, `multipart` → `-F`.

Submit mechanism: `ajax-*`/`js:*` → add `X-Requested-With: XMLHttpRequest`. `standard-post` → use `-L`.

Check response: `[ "$RESULT" = "<expected>" ]`. If fails: Stop. "Operation '<name>' failed."

### browse layer

Single Bash call with screenshots:
```bash
CI=1 $B screenshot "playbooks/web-configure/screenshots/<id>/<date>-before.png"
CI=1 $B snapshot -i
CI=1 $B fill @eN "<value>"
CI=1 $B dialog-accept
CI=1 $B click "Submit"
sleep 3
CI=1 $B screenshot "playbooks/web-configure/screenshots/<id>/<date>-after.png"
```

Show screenshots to user with Read tool after capture.

## 9. Phase: Verify

Confirm configuration persisted.

### Delay

If `verify.delay > 0`: `sleep <delay>`

### curl assertions

**bodyContains:**
```bash
PAGE=$(curl -s $TLS_FLAG -b "PHPSESSID=$COOKIE" "${BASE_URL}<url>")
echo "$PAGE" | grep -q "<expected>" && echo "PASS" || echo "FAIL"
```

**valuePattern:**
```bash
echo "$PAGE" | grep -q 'value="<expected>"' && echo "PASS" || echo "FAIL"
```

**bodyRegex:**
```bash
echo "$PAGE" | grep -qP '<pattern>' && echo "PASS" || echo "FAIL"
```

### Shell command verification

For each entry in `verify.command`:
```bash
OUTPUT=$(<command with ${VAR} substituted> 2>&1)
echo "$OUTPUT" | grep -q "<expected>" && echo "PASS" || echo "FAIL"
```

### browse layer

```bash
CI=1 $B screenshot "playbooks/web-configure/screenshots/<id>/<date>-verified.png"
```

All pass → status = `verified`. Any fail → stop, show expected vs actual.

## 10. Save Playbook

### First run

Write new playbook to `playbooks/web-configure/<id>.yml`. Use `playbooks/web-configure/templates/playbook.yml` as the schema reference — it documents every field with comments.

ID generation: first 5 words of objective, kebab-case. Check collision:
```bash
ls playbooks/web-configure/<id>.yml 2>/dev/null && echo "EXISTS — append -2"
```

Include all phases with both curl and browse data. Add first `runs` entry with timestamp, mode, duration, result, fingerprint match, variables (secrets = "***"), screenshots, assertions.

### Replay

Append to `runs` array, update `lastRun` and `status`.

### Validate

```bash
python3 -c "import yaml; yaml.safe_load(open('<path>')); print('VALID')"
```

If invalid: fix, re-write, re-validate. Max 2 retries.

## 11. Output Summary

```
## Web Configure Complete

**Playbook:** <id>
**Mode:** discover+configure (or replay)
**Target:** <baseUrl>
**Status:** verified (or failed at phase X)

**Phases:**
  ✓ auth      — session acquired
  ✓ navigate  — reached target page
  ✓ discover  — mapped N forms, N fields
  ✓ configure — N operations completed
  ✓ verify    — N/N assertions passed

**Screenshots:**
  - before:   playbooks/web-configure/screenshots/.../before.png
  - after:    playbooks/web-configure/screenshots/.../after.png
  - verified: playbooks/web-configure/screenshots/.../verified.png

**Replay:** /web-configure <url> --replay --playbook <id>
```

## 12. Error Handling

| Situation | Action |
|-----------|--------|
| curl auth fails (non-302) | Stop. "Auth failed." |
| curl timeout | Retry up to `retries` count |
| curl 200-with-error-body | Not retryable. Stop. |
| Navigation hint no match | List links, ask user |
| Navigation still stuck | Browse handoff |
| Form field ID missing (replay) | Flag `stale`, offer rediscovery |
| Browse crash / non-zero exit | Continue curl-only |
| AJAX returns failure | Stop at configure |
| Verify assertions fail | Stop. Show expected vs actual |
| Secret variable has default | Reject playbook |
| 3 consecutive browse fails | Skip browse for remaining phases |

**Browse fail:** non-zero exit code or no output. Counter is global across the run.

## Scope

This skill handles server-rendered web apps (PHP, Django, Rails, CGI panels). Not designed for SPAs (React/Vue/Angular — content loads via JS, curl can't discover forms), OAuth login flows, or file upload configuration.
