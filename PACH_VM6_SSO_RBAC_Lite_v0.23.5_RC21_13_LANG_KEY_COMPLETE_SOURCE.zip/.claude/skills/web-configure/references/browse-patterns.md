# Browse Patterns for web-configure

## Server Setup

```bash
_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
B=""
[ -n "$_ROOT" ] && [ -x "$_ROOT/.claude/skills/gstack/browse/dist/browse" ] && B="$_ROOT/.claude/skills/gstack/browse/dist/browse"
[ -z "$B" ] && B=~/.claude/skills/gstack/browse/dist/browse
if [ -x "$B" ]; then
  echo "BROWSER_READY"
else
  echo "BROWSER_NOT_AVAILABLE"
fi
```

## Critical: Batching Rule

The gstack /browse server auto-terminates when the parent shell exits. In Claude Code, each Bash tool call is a separate process.

**ALL browse commands for a phase MUST be in a SINGLE Bash tool call.** Never split browse commands across separate tool calls — the server will die between them and you'll lose the session.

## CI=1 Sandbox Workaround

Ubuntu 24.04+ restricts Chromium sandbox via AppArmor (`kernel.apparmor_restrict_unprivileged_userns=1`). Prefix ALL browse commands with `CI=1`:

```bash
CI=1 $B goto <url>
CI=1 $B snapshot -i
CI=1 $B screenshot <path>
```

Without `CI=1`, Chromium crashes with: `FATAL: No usable sandbox!`

## Cookie Bridge Pattern

Inject curl-acquired session cookies at the start of each browse batch:

```bash
B=<browse binary>
COOKIE="<value from curl>"

CI=1 $B goto "${BASE_URL}<any_page>"        # establish domain first
CI=1 $B cookie "<COOKIE_NAME>=$COOKIE"       # inject cookie
CI=1 $B goto "${BASE_URL}<target_page>"      # now authenticated
CI=1 $B snapshot -i                          # verify page loaded
```

Repeat this pattern at the start of EVERY browse batch. The cookie must be re-injected because the server restarts between Bash calls.

## Iframe Navigation

For frameset-based apps (common in legacy admin panels), enter the iframe context:

```bash
CI=1 $B frame "<selector or index>"   # enter iframe
CI=1 $B snapshot -i                   # now see iframe content
# ... interact with iframe content ...
CI=1 $B frame main                    # return to top level
```

## Snapshot-Then-Ref Pattern

Element refs (`@eN`) from a snapshot are invalidated by any subsequent browse command that modifies the page. Always snapshot immediately before using refs:

```bash
CI=1 $B snapshot -i           # get fresh @e refs
CI=1 $B fill @e3 "value"     # use ref from THIS snapshot
CI=1 $B click @e5            # still valid from same snapshot
CI=1 $B snapshot -i           # need NEW refs after page changes
CI=1 $B fill @e2 "other"     # use ref from NEW snapshot
```

## Screenshot Capture

```bash
CI=1 $B screenshot "playbooks/web-configure/screenshots/<id>/<date>-<label>.png"
```

If screenshot fails, continue without it — screenshots are evidence, not gates.

## Error Counting

Track consecutive browse failures globally:

- Browse fail = non-zero exit code OR empty output
- After 3 consecutive fails: set `browseDisabled=true`, skip all remaining browse steps
- Log in run record: `browseDisabled: true`
