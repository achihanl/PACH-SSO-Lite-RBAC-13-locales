---
name: qa-azblink
description: QA pipeline orchestrator — explore with gstack, export to Playwright, run tests, report coverage, promote specs
---

# /qa-azblink

QA pipeline orchestrator for AZBlink Directory. Reads `qa/manifest.yml` and orchestrates testing workflows.

## Subcommands

### /qa-azblink explore [page-id|flow-id|all]

Launches gstack `/browse` against manifest targets for exploratory testing.

**Process:**
1. Read `qa/manifest.yml`
2. For each target:
   - Navigate to the page URL (with auth if `requiresAuth: true`)
   - Run manifest assertions (visible text, element counts, console errors)
   - Capture annotated snapshots via `/browse snapshot -i`
   - For flows: execute step sequences, capture diffs at each step
3. Save session log to `qa/sessions/YYYY-MM-DD-<id>.json`

**Session log format:** See spec §Session Log Schema. Key: capture `element.role` + `element.name` at each interaction for export mapping.

**Flags:**
- `--dry-run`: Show what would be explored without launching gstack
- `--timeout <seconds>`: Per-page timeout (default: 300s)

**Example:**
```
/qa-azblink explore dashboard
/qa-azblink explore sso-login
/qa-azblink explore all --dry-run
```

### /qa-azblink export [session-file|latest]

Converts a gstack session log to Playwright `.spec.ts` files.

**Command mapping:**

| gstack browse | Playwright |
|---|---|
| `goto <url>` | `await page.goto('<url>')` |
| `click @eN [button "X"]` | `await page.getByRole('button', { name: 'X' }).click()` |
| `fill @eN [textbox "X"]` | `await page.getByRole('textbox', { name: 'X' }).fill('value')` |
| `is visible ".sel"` | `await expect(page.locator('.sel')).toBeVisible()` |
| `text (contains "X")` | `await expect(page).toContainText('X')` |
| `console --errors` | `page.on('console', ...)` listener |

**Rules:**
- Use `getByRole`/`getByText` over CSS selectors (resilient to DOM changes)
- Map from `element.role` + `element.name` in session log, NOT @e ref numbers
- Write to `src/frontend/e2e/generated/`
- Include `// Source: qa/sessions/<file>.json` header in each generated spec

**Example:**
```
/qa-azblink export latest
/qa-azblink export qa/sessions/2026-03-24-dashboard.json
```

### /qa-azblink run [smoke|full|flow-id]

Wraps `npx playwright test` with appropriate config.

- `smoke`: `npx playwright test --project=smoke` (generated specs only, < 2 min)
- `full`: `npx playwright test --project=full` (all specs)
- `<flow-id>`: `npx playwright test -g "<flow-id>"` (specific flow)

Handles auth setup automatically. Requires Docker stack running (`just health-check` first).

### /qa-azblink report

Cross-references `qa/manifest.yml` against existing spec files.

**Output:**
- Pages tested / total (with list of uncovered pages)
- Flows tested / total (with list of uncovered flows)
- Generated specs with no promoted counterpart
- Promoted specs that reference pages no longer in manifest
- Overall coverage percentage

### /qa-azblink promote [generated-spec]

Moves a generated spec from `e2e/generated/` to `e2e/`.

- If target exists, prompts for confirmation before overwriting
- Promoted tests are "owned" — hand-editable, not overwritten by future exports
- After promoting, run the test to verify: `npx playwright test e2e/<name>.spec.ts`

## Auth

Two strategies available:
1. **Dev bypass** (default for most tests): `authenticatedPage` fixture injects `Authorization: Bearer dev-test-token`
2. **SSO** (for login flow tests): Playwright auth setup project via `e2e/setup/auth.setup.ts`

## Environment

| Variable | Default | Purpose |
|---|---|---|
| `BASE_URL` | `http://localhost:8081` | App URL (Docker stack) |
| `USE_DEV_SERVER` | unset | Set `true` for Vite dev server on :3000 |
| `DEV_AUTH_TOKEN` | `dev-test-token` | Dev bypass bearer token |
| `QA_SSO_USER` | unset | Authentik SSO username |
| `QA_SSO_PASSWORD` | unset | Authentik SSO password |
