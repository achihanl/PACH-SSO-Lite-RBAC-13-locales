---
name: docs-authoring
description: Use when writing or editing any markdown documentation in this repository - defines the portable construct subset, frontmatter schema, and banned constructs, and requires running the linter before committing.
---

# Docs Authoring

Documentation here must render identically in the GitHub web UI, GitHub PR
diffs, and Open Knowledge. That intersection is the whole rule.

## Before committing

Run the linter. It is the gate CI runs:

    python3 .claude/skills/docs-authoring/scripts/lint_docs.py .

Exit 0 or the change is not ready.

## Allowed constructs

Mermaid fences, GitHub alerts, LaTeX, `<details>`, tables, task lists,
footnotes, relative links, fenced code with a language hint. One example of
each is in `reference/blocks.md`.

Mermaid diagrams use `flowchart`, `sequenceDiagram`, or `erDiagram` only.

## Banned constructs

| Banned | Why |
|---|---|
| MDX tags — `<Callout>`, `<Tabs>`, `<Mirror>`, any `<Uppercase>` element | render as literal text on GitHub |
| `[[wikilinks]]` | render as literal text outside GitHub Wikis; Fumadocs does not resolve them |
| `<script>` and interactive HTML | stripped by GitHub's sanitizer |

Lowercase HTML that GitHub's sanitizer keeps — `<details>`, `<summary>`,
`<img>`, `<br>`, `<sub>` — is fine.

## Frontmatter

New files carry all six fields:

    ---
    title: Short title
    description: One line
    type: reference | design | runbook | overview
    product: <repo slug>
    status: current | draft | superseded
    updated: YYYY-MM-DD
    ---

Files that already carry a `<!-- spec-meta: ... -->` comment satisfy this
requirement. Do not add frontmatter to them.

The metadata rule applies only under `docs/` and to the root `README.md`.
Markdown elsewhere in the repository — `deploy/`, `src/`, `tools/` — is still
checked for banned constructs and dead links, but needs no frontmatter.

## Links

Relative links only, resolved from the containing file's directory. The linter
scans the entire repository, not just `docs/`, so `README.md` is checked too —
that is deliberate, and it is where drift historically hides.

## Excluding generated or process files

The linter reads a `.docslintignore` at the repo root, one `fnmatch` pattern
per line (`#` comments and blank lines are skipped). Matching files are
skipped entirely — no banned-construct, dead-link, or frontmatter check.
This is the escape hatch for content that is retained in git but isn't
authored documentation: process exhaust (plans, session ledgers), archived
material, or directories governed by their own separate tooling. Don't use
it to silence a real finding on a page readers will see — fix the page
instead.
