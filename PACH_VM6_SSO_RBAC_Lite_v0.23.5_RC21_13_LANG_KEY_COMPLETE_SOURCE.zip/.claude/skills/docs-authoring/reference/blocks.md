---
title: Allowed Blocks
description: One example of each allowed construct, plus what is banned
type: reference
product: docs-authoring
status: current
updated: 2026-08-08
---

# Allowed Blocks

## Alert

```md
> [!WARNING]
> Production startup fails closed when TLS verification is disabled.
```

## Mermaid

````md
```mermaid
flowchart LR
  A[ucChat] --> B[Adapter]
```
````

## Math

Inline and block both render everywhere in the subset.

```md
Token entropy is $H = -\sum p_i \log_2 p_i$.

$$
H = -\sum_{i=1}^{n} p_i \log_2 p_i
$$
```

## Collapsible

```md
<details>
<summary>Full environment table</summary>

| Variable | Default |
|---|---|
| `PACH_ENV` | `development` |

</details>
```

## Table, task list, footnote, relative link, fenced code

````md
| Route | Method |
|---|---|
| `/healthz` | GET |

- [x] done
- [ ] pending

A claim needing a source.[^1]

[^1]: The source.

See [configuration](./configuration.md).

```python
def f() -> int:
    return 1
```
````

## Banned

These are shown so you recognise them. They are inside code fences, which is
why this file passes its own linter.

```md
<Callout type="warn">no</Callout>
<Tabs><Tab>no</Tab></Tabs>
[[wikilink]]
<script>alert(1)</script>
```
