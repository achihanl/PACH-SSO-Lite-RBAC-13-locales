#!/usr/bin/env python3
"""Lint documentation for portable-construct conformance.

Stdlib only. Targets Python 3.11+.

Enforces the construct subset that renders identically in the GitHub web UI,
GitHub PR diffs, and Open Knowledge. See ../SKILL.md for the rules.
"""

from __future__ import annotations

import argparse
import fnmatch
import re
import sys
from pathlib import Path
from typing import NamedTuple


class Finding(NamedTuple):
    path: str
    line: int
    rule: str
    message: str


_FENCE_RE = re.compile(r"^\s*(`{3,}|~{3,})")
_INLINE_RE = re.compile(r"(`+)(.*?)\1")

BANNED = (
    # Searches anywhere on the line, and matches closing tags, so that a tag
    # sitting mid-sentence in prose or a lone `</Callout>` is caught too. The
    # other two rules already search anywhere; a line-start anchor here was
    # inconsistent and missed real leaks.
    ("mdx-tag", re.compile(r"</?[A-Z][A-Za-z0-9]*[\s/>]"),
     "MDX component tags do not render on GitHub; use the allowed subset"),
    ("wikilink", re.compile(r"\[\["),
     "wikilinks render as literal text on GitHub; use a relative link"),
    ("script", re.compile(r"<script"),
     "script tags are stripped by GitHub's sanitizer"),
)


def _blank_inline(line: str) -> str:
    """Replace inline code spans with spaces, preserving column offsets."""
    return _INLINE_RE.sub(lambda m: " " * len(m.group(0)), line)


def strip_code(text: str) -> str:
    """Blank out fenced code blocks and inline code spans.

    Line count and column offsets are preserved so findings computed against
    the result carry accurate positions for the original text.
    """
    out: list[str] = []
    fence: str | None = None
    for line in text.split("\n"):
        match = _FENCE_RE.match(line)
        if fence is None:
            if match:
                fence = match.group(1)
                out.append("")
                continue
            out.append(_blank_inline(line))
        else:
            if (match
                    and match.group(1)[0] == fence[0]
                    and len(match.group(1)) >= len(fence)):
                fence = None
            out.append("")
    return "\n".join(out)


def scan_banned(text: str, path: str) -> list[Finding]:
    """Scan for banned constructs. `text` must already be code-stripped."""
    findings: list[Finding] = []
    for lineno, line in enumerate(text.split("\n"), start=1):
        for rule, pattern, message in BANNED:
            if pattern.search(line):
                findings.append(Finding(path, lineno, rule, message))
    return findings


# Tolerates one level of nested brackets in the link text. A plain
# `\[[^\]]*\]` silently matches nothing at all for `[Fix [WIP]](missing.md)`,
# so such a link is never checked — a false negative in the linter's core job.
_LINK_RE = re.compile(r"\[(?:[^\[\]]|\[[^\]]*\])*\]\(\s*([^)\s]+?)\s*(?:\"[^\"]*\")?\)")
_EXTERNAL_RE = re.compile(r"^(?:[a-z][a-z0-9+.-]*:|//|#)", re.IGNORECASE)


def check_links(text: str, path: Path, repo_root: Path) -> list[Finding]:
    """Verify every relative link target exists.

    Targets resolve relative to the containing file's directory, per standard
    markdown. `repo_root` is used only to reject targets that escape the repo
    and to render readable paths in findings.
    """
    findings: list[Finding] = []
    rel = path.relative_to(repo_root).as_posix()
    for lineno, line in enumerate(text.split("\n"), start=1):
        for match in _LINK_RE.finditer(line):
            target = match.group(1)
            if _EXTERNAL_RE.match(target):
                continue
            target = target.split("#", 1)[0]
            if not target:
                continue
            resolved = (path.parent / target).resolve()
            try:
                resolved.relative_to(repo_root.resolve())
            except ValueError:
                findings.append(Finding(
                    rel, lineno, "dead-link",
                    f"link target {target!r} escapes the repository root",
                ))
                continue
            if not resolved.exists():
                findings.append(Finding(
                    rel, lineno, "dead-link",
                    f"link target {target!r} does not exist",
                ))
    return findings


ALLOWED_MERMAID = ("flowchart", "sequenceDiagram", "erDiagram")

REQUIRED_FIELDS = ("title", "description", "type", "product", "status", "updated")

VALID_TYPES = ("reference", "design", "runbook", "overview")
VALID_STATUSES = ("current", "draft", "superseded")
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

_SPEC_META_RE = re.compile(r"<!--\s*spec-meta:")

DEFAULT_IGNORES = (
    ".git/**", "node_modules/**", ".venv/**", "venv/**",
    ".pytest_cache/**", ".mypy_cache/**", ".ruff_cache/**",
    ".repomix-packs/**", "staging/**",
    # Tool caches and agent scaffolding. These contain markdown but are not
    # documentation, and are not authored in this repository.
    ".superpowers/**", ".claude/**", ".dead-code/**", "_ARCHIVE_/**",
)

# The metadata rule is documentation-scoped; every other rule is repo-wide.
# Narrowing the link check instead would hide exactly the README drift this
# linter exists to catch.
METADATA_SCOPE = ("docs/",)


def _metadata_required(rel: str) -> bool:
    return rel == "README.md" or rel.startswith(METADATA_SCOPE)


def _iter_fences(text: str):
    """Yield (start_line, info_string, body_lines) for each fenced block."""
    lines = text.split("\n")
    index = 0
    while index < len(lines):
        match = _FENCE_RE.match(lines[index])
        if not match:
            index += 1
            continue
        marker = match.group(1)
        info = lines[index][lines[index].index(marker) + len(marker):].strip()
        start = index + 1
        body: list[str] = []
        index += 1
        while index < len(lines):
            close = _FENCE_RE.match(lines[index])
            if (close
                    and close.group(1)[0] == marker[0]
                    and len(close.group(1)) >= len(marker)):
                index += 1
                break
            body.append(lines[index])
            index += 1
        yield start, info, body


def check_mermaid(text: str, path: str) -> list[Finding]:
    findings: list[Finding] = []
    for start, info, body in _iter_fences(text):
        if info.split()[0:1] != ["mermaid"]:
            continue
        content = [line for line in body if line.strip()]
        if not content:
            findings.append(Finding(
                path, start, "mermaid-empty", "empty mermaid block"))
            continue
        first_word = content[0].split()[0]
        if first_word not in ALLOWED_MERMAID:
            findings.append(Finding(
                path, start, "mermaid-type",
                f"diagram type {first_word!r} is not one of "
                f"{', '.join(ALLOWED_MERMAID)}",
            ))
    return findings


def check_metadata(text: str, path: str) -> list[Finding]:
    # Searched across the whole document, not just the opening paragraph. Real
    # governed files place the comment below a title or deep in the text, and a
    # first-paragraph-only search produced false "missing frontmatter" findings
    # on three azblink files including docs/architecture/SOP.md, which other
    # constraints forbid editing.
    #
    # Run against code-stripped text so a page that merely *quotes* a
    # spec-meta comment as an example (inside a fence) doesn't exempt itself.
    if _SPEC_META_RE.search(strip_code(text)):
        return []
    if not text.startswith("---\n"):
        return [Finding(path, 1, "frontmatter",
                        "missing YAML frontmatter and no spec-meta comment")]
    end = text.find("\n---", 4)
    if end == -1:
        return [Finding(path, 1, "frontmatter", "unterminated frontmatter block")]
    fields = {
        key.strip(): value.strip()
        for key, _, value in (
            line.partition(":")
            for line in text[4:end].split("\n")
            if ":" in line and not line.startswith((" ", "\t", "#"))
        )
    }
    missing = [f for f in REQUIRED_FIELDS if f not in fields]
    if missing:
        return [Finding(path, 1, "frontmatter",
                        f"missing required field(s): {', '.join(missing)}")]
    findings: list[Finding] = []
    for field in ("title", "description"):
        if not fields[field]:
            findings.append(Finding(path, 1, "frontmatter", f"{field} is empty"))
    if fields["type"] not in VALID_TYPES:
        findings.append(Finding(path, 1, "frontmatter",
                        f"type: {fields['type']!r} is not one of "
                        f"{', '.join(VALID_TYPES)}"))
    if fields["status"] not in VALID_STATUSES:
        findings.append(Finding(path, 1, "frontmatter",
                        f"status: {fields['status']!r} is not one of "
                        f"{', '.join(VALID_STATUSES)}"))
    if not _DATE_RE.match(fields["updated"]):
        findings.append(Finding(path, 1, "frontmatter",
                        f"updated: {fields['updated']!r} does not match "
                        "YYYY-MM-DD"))
    return findings


def lint_file(path: Path, repo_root: Path) -> list[Finding]:
    text = path.read_text(encoding="utf-8")
    rel = path.relative_to(repo_root).as_posix()
    stripped = strip_code(text)
    findings = [
        *scan_banned(stripped, rel),
        *check_links(stripped, path, repo_root),
        *check_mermaid(text, rel),
    ]
    if _metadata_required(rel):
        findings.extend(check_metadata(text, rel))
    return findings


def load_ignores(repo_root: Path) -> list[str]:
    ignore_file = repo_root / ".docslintignore"
    if not ignore_file.is_file():
        return []
    return [
        line.strip()
        for line in ignore_file.read_text(encoding="utf-8").split("\n")
        if line.strip() and not line.strip().startswith("#")
    ]


def _is_ignored(rel: str, patterns: list[str]) -> bool:
    return any(
        fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(rel, pattern.rstrip("/*") + "/*")
        for pattern in patterns
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Lint documentation for portable constructs.")
    parser.add_argument("root", nargs="?", default=".", help="repository root to scan")
    args = parser.parse_args(argv)

    repo_root = Path(args.root).resolve()
    patterns = [*DEFAULT_IGNORES, *load_ignores(repo_root)]

    findings: list[Finding] = []
    for path in sorted(repo_root.rglob("*.md")):
        rel = path.relative_to(repo_root).as_posix()
        if _is_ignored(rel, patterns):
            continue
        findings.extend(lint_file(path, repo_root))

    for finding in findings:
        print(f"{finding.path}:{finding.line}: {finding.rule}: {finding.message}")
    if findings:
        print(f"\n{len(findings)} problem(s).", file=sys.stderr)
        return 1
    print("No problems found.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
