---
name: appliance-iso-upload
version: 1.0.0
description: |
  Log into the Azblink appliance PHP web console (captcha-gated) and upload a
  large CD/ISO image with out-of-band progress reporting, then verify it
  registered on the box. Handles the numeric image-captcha, the session-bound
  login POST, and long (multi-GB, 30+ min) multipart uploads over VPN that the
  site itself gives no progress bar for.
  Use ONLY when the user explicitly asks. Triggers on: "upload the ISO to the
  appliance", "upload a CD image", "log into the appliance console", "solve the
  appliance captcha", "System > Host > Upload CD Image", "delete an ISO from the
  appliance", or any request to drive the Azblink appliance login + Upload CD
  Image page. NOT for the AZBlink Directory React admin UI (that is OIDC, no
  captcha) — this is the separate legacy PHP appliance at /apps/.
allowed-tools:
  - Bash
  - Read
  - Write
---

# appliance-iso-upload

Drive the legacy **Azblink appliance PHP console** (`/apps/index.php`): solve its
image captcha, log in, and upload a large ISO to **System › Host › Upload CD
Image** with a home-grown progress monitor (the site has none).

This is a manual, user-invoked skill. Nothing here is stored — credentials are
supplied at runtime and never written to disk.

**Example**
> User: "Upload `deploy/bootstrap-iso/out/azb-ad.iso` into the appliance at
> `http://192.168.11.235:8082`, System > Host > Upload CD Image. Creds are
> admin/admin123."
> Result: captcha solved, logged in, 3.2 GB uploaded over VPN in ~34 min with
> 5-min progress reports, `azb-ad.iso` confirmed in the image list.

## Parameters (collect at runtime — never hardcode secrets)

| Param | Example | Notes |
|-------|---------|-------|
| `BASE` | `http://192.168.11.235:8082/apps` | appliance web root (the `/apps` PHP app) |
| `PORTAL` | `admin` | login portal: `admin` (System), `bordera` (Border), `vpna` (Vpn) |
| `ITEM` | `systema` | post-login item; Host/Upload lives under `systema` |
| `USER` / `PASS` | `admin` / `admin123` | **prompt each run**, never store |
| `ISO` | `deploy/bootstrap-iso/out/azb-ad.iso` | local file to upload |

Use an absolute scratchpad dir for all temp files (`cookies.txt`, captcha PNG,
response HTML, progress log). Do **not** put temp files in the repo.

## Environment constraints (this repo)

The Bash hook rejects `for`-loops, heredocs, `grep`, and `$(cat …)`. So:
- Run repeated fetches as separate `curl` calls, not a loop.
- Read the captcha by **viewing the PNG with the Read tool**, not OCR piping.
- Poll the progress log with `tr '\r' '\n' < log | tail -n 1` (no `grep`).
- Pass payloads by file path, never via heredoc/`$(cat)`.

Networking to the appliance goes over the VPN tunnel; plain `curl` reaches it
(no sandbox override needed).

## Step 1 — Solve captcha & log in

The login form (`login.php?item=<PORTAL>`) posts back to **its own URL including
`?item=<PORTAL>`**. Dropping `item` from the POST URL silently bounces you to the
landing page — this is the #1 failure.

The captcha is a PNG from `authimage.php`, **bound to the PHPSESSID and one-time**.
Fetch it fresh with the same cookie jar, view it, then POST immediately.

1. Prime a session + fetch a fresh captcha (writes/updates `cookies.txt`):
   ```bash
   curl -sS -c "$TMP/cookies.txt" -b "$TMP/cookies.txt" \
     -o "$TMP/captcha.png" "$BASE/authimage.php"
   ```
2. **Read `$TMP/captcha.png`** with the Read tool. It renders as an image; read
   off the 6 digits (e.g. `854401`). That string is `CAPTCHA`.
3. POST the login to `login.php?item=<PORTAL>` (note `item` in the URL):
   ```bash
   curl -sSL -b "$TMP/cookies.txt" -c "$TMP/cookies.txt" \
     -o "$TMP/after_login.html" \
     -w "final=%{url_effective} code=%{http_code} size=%{size_download}\n" \
     --data-urlencode "action=UserLogin" \
     --data-urlencode "active=true" \
     --data-urlencode "select=en_us" \
     --data-urlencode "loginid=$USER" \
     --data-urlencode "loginpasswd=$PASS" \
     --data-urlencode "authimage=$CAPTCHA" \
     --data-urlencode "button=Sign In" \
     "$BASE/login.php?item=$PORTAL"
   ```

**Success vs failure**
- Success: redirects to `index.php?item=<ITEM>&action=a…`, page title `Admin`,
  size ~32 KB.
- Failure: lands back on `login.php` / landing page, title `Login`, size ~3 KB.
  Causes, in order of likelihood: missing `?item=` on the POST URL; stale/expired
  captcha (they have a short TTL — refetch a **new** one and retry within seconds);
  wrong credentials. On captcha failure, redo steps 1–3, do not reuse a code.

The authenticated `PHPSESSID` in `cookies.txt` is now good for everything below —
no further captcha.

## Step 2 — Open the Upload CD Image page

Content loads inside a `main` iframe; fetch the action URL directly:
```bash
curl -sSL -b "$TMP/cookies.txt" -c "$TMP/cookies.txt" \
  -o "$TMP/upload_cd.html" \
  "$BASE/index.php?item=$ITEM&action=aHostUploadImg"
```
The page has two forms:
- **Upload** (`form1`, `multipart/form-data`): hidden `action=aHostUploadImg`,
  `active=upload`, file field `file1`.
- **Delete** (`form3`): hidden `action=aHostUploadImg`, `active=del`, radio
  `packName=<iso filename>`.

Read the delete-list radios to see which ISOs already exist.

## Step 3 — Upload with background progress

A multi-GB POST over VPN runs far past any foreground timeout, and the site shows
no progress. So: run curl **in the background** and redirect its own progress
meter (stderr) to a log you poll.

Launch (mark the Bash call `run_in_background: true`):
```bash
curl -b "$TMP/cookies.txt" -c "$TMP/cookies.txt" \
  -F "action=aHostUploadImg" \
  -F "active=upload" \
  -F "file1=@$ISO;type=application/octet-stream" \
  -o "$TMP/upload_response.html" \
  -w "\n---DONE http=%{http_code} uploaded_bytes=%{size_upload} total_time=%{time_total}s avg_speed_Bps=%{speed_upload}\n" \
  "$BASE/index.php?item=$ITEM&action=aHostUploadImg" \
  2> "$TMP/upload_progress.log"
```

Poll progress (percent / rate / ETA) any time:
```bash
tr '\r' '\n' < "$TMP/upload_progress.log" | tail -n 1
```
Meter columns: `%xferd  total  …  avg-up-rate  time-total  time-spent  time-left  cur-rate`.

**Periodic reporting**: if the user wants updates on a cadence, use the `/loop`
skill, e.g. `/loop 5m report the upload progress by polling upload_progress.log;
when it finishes, verify the ISO is listed and stop the loop`. Stop the loop
(CronDelete) once verified.

**Caveats**
- **No resume.** This form is all-or-nothing; a dropped connection means
  restart from zero. For resumable transfers, stage the ISO to the box over SSH
  (`rsync`) instead and register it there — out of scope for this skill.
- Watch for PHP `post_max_size` / `upload_max_filesize` limits on unfamiliar
  boxes (this appliance is sized for CD images, so large uploads are fine).

## Step 4 — Verify (don't trust exit 0)

When the background task completes, confirm server-side:
1. Check the `---DONE http=200 …` line in the task output and `uploaded_bytes`
   ≈ file size + small multipart overhead.
2. Re-fetch the Upload CD Image page and confirm the filename now appears as a
   `packName` radio:
   ```bash
   curl -sSL -b "$TMP/cookies.txt" -c "$TMP/cookies.txt" \
     -o "$TMP/upload_cd_after.html" \
     "$BASE/index.php?item=$ITEM&action=aHostUploadImg"
   ```
   Read the delete-list radios; the new ISO should be listed (usually first).

Report: HTTP status, bytes, duration, avg throughput, and the confirmed list
entry.

## Delete an ISO (optional)

```bash
curl -sSL -b "$TMP/cookies.txt" -c "$TMP/cookies.txt" \
  -o "$TMP/delete_response.html" -w "code=%{http_code}\n" \
  --data-urlencode "action=aHostUploadImg" \
  --data-urlencode "active=del" \
  --data-urlencode "packName=<iso-filename>" \
  "$BASE/index.php?item=$ITEM&action=aHostUploadImg"
```
Then re-fetch the page (Step 4.2) to confirm it's gone.

## Field reference

**Login** (`POST login.php?item=<PORTAL>`): `action=UserLogin`, `active=true`,
`select=en_us`, `loginid`, `loginpasswd`, `authimage`, `button=Sign In`.
**Upload** (`POST …&action=aHostUploadImg`, multipart): `action=aHostUploadImg`,
`active=upload`, `file1=@…`.
**Delete** (`POST …&action=aHostUploadImg`): `action=aHostUploadImg`,
`active=del`, `packName=<iso>`.
**Nav map**: Host menu → `aHostUploadImg` (Upload CD Image), `aHostAdd` (Add
Host), `aHostMgmt` (Host Management), etc., all under `item=systema`.
