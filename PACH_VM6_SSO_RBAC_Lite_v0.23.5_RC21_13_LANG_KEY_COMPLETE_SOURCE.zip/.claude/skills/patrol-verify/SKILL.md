---
name: patrol-verify
version: 1.1.0
description: |
  Verify that a bug fix resolves a previously investigated issue by replaying
  the navigation steps and checking if the observed behavior matches expectations.
  Updates the issue file and promotes verified behavior to the project manifest.
  Use when asked to "verify", "confirm fix", "check if fixed", or "re-test".
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
  - Grep
---

# patrol-verify: Fix Verification Skill

Verify that a previously investigated bug has been fixed by replaying the investigation steps and comparing the current state to the original observations.

## 1. Load Issue File

You receive an issue ID as input. Read the issue file:

```
qa/patrol/issues/<issue-id>.yml
```

If the file does not exist:
1. List available issues: `ls qa/patrol/issues/*.yml`
2. Print: "Issue `<id>` not found. Available issues: <list>"
3. Stop.

Parse the YAML. Verify `schemaVersion` is "1.0". Read the `navigation`, `observed`, and `promote` sections.

## 2. Load Manifest

Read `qa/patrol/manifest.yml` if it exists. This provides context for:
- Auth strategies (how to authenticate if needed)
- Page definitions (what assertions to check)
- Flow definitions (referenced by `navigation.fromManifest`)

If the manifest is missing, warn but continue — the issue file has its own navigation steps.

If the manifest exists but fails to parse, stop: "Manifest YAML is malformed — please fix `qa/patrol/manifest.yml`."

Check `.patrol-version` if it exists — compare to this skill's version (1.1.0). If the installed version is older, warn: "Patrol skills may be outdated (installed: X, current: 1.1.0). Run the install script to update."

## 3. Environment Check

Scan `${VAR}` references in:
- The issue file's `navigation.steps`
- The manifest's auth strategies (if being used)

For each variable, verify it is set. If any are missing, stop with: "Missing environment variables: VAR1, VAR2."

## 4. Browser Replay

Use `/browse` (gstack) to replay the investigation. Run the browser setup first:

```bash
# Patrol: Browser setup
_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
B=""
[ -n "$_ROOT" ] && [ -x "$_ROOT/.claude/skills/gstack/browse/dist/browse" ] && B="$_ROOT/.claude/skills/gstack/browse/dist/browse"
[ -z "$B" ] && B=~/.claude/skills/gstack/browse/dist/browse
if [ -x "$B" ]; then
  echo "BROWSER_READY"
else
  echo "BROWSER_NOT_AVAILABLE"
fi
```

If `BROWSER_NOT_AVAILABLE`: stop and tell the user "gstack /browse is not available. Install gstack or run the browse setup first."

If `BROWSER_READY`: use `$B` as the command prefix for all browser commands below.

### Replay Navigation Steps

**Important:** Element refs (`@eN`) from a snapshot are invalidated by any subsequent browser command that modifies the page. Always re-snapshot before using new refs. Never reuse a ref from a previous snapshot.

Execute each step from `navigation.steps` using the snapshot-then-ref pattern:

**GOTO:**
```
1. $B goto <baseUrl><url>  (use manifest baseUrl if available)
2. $B snapshot
3. Verify page loaded — check for expected heading or content
```

**CLICK:**
```
1. $B snapshot
2. Find the element matching "<text>" in snapshot output (look for [button], [link], or [text] containing the target)
3. $B click @eN  (using the element ref from snapshot)
4. Wait 1s if page transition is expected
5. $B snapshot  (verify new state)
```

**FILL:**
```
1. $B snapshot -i  (interactive elements only)
2. Find [textbox] or [input] matching the label/placeholder
3. $B fill @eN "<value>"
```

**WAITFOR:**
```
1. $B snapshot
2. Check if expected text/element is present in snapshot output
3. If found → proceed to next step
4. If not found and attempts < 3 → sleep 2, go to step 1
5. If not found after 3 attempts → record as stale navigation step in notes, continue with remaining steps
```

**ASSERT:**
```
1. $B snapshot
2. Check conditions against snapshot output
3. Record pass/fail — do NOT stop on failure, capture the result
```

**If a step fails** (element not found, timeout, wrong page): record which step failed in your notes and continue with remaining steps where possible. The failure itself is useful data.

After replaying all steps:
1. `$B snapshot` (capture final state)
2. `$B console` (capture console output — filter using rules below)
3. Note the current URL

### Console Error Filtering

After running `$B console`, filter the output:

**Capture as consoleErrors:**
- Lines containing `[error]` — these are real errors
- Lines containing `[warning]` about WebSocket, network, or resource loading failures

**Ignore:**
- Lines containing `[debug]` — framework debug output
- Lines containing `[info]` — informational messages
- Framework noise: vite connection messages, React DevTools suggestions, authentik debug logs, TanStack debug output

## 5. Evaluate Result

Compare what you see NOW vs what was recorded in `observed`:

### FIXED
The bug symptoms from `observed` are no longer present:
- Console errors that were in `observed.consoleErrors` are gone
- The URL is correct (not stuck on the wrong page)
- Expected elements are visible
- The described bug behavior does not occur

### NOT FIXED
The same symptoms persist:
- Same console errors
- Same URL problem
- Same described behavior

### REGRESSION
The original bug is fixed BUT you observe a new/different problem:
- Different console errors appeared
- Different UI breakage
- Something else is wrong that was not in the original report

## 6. Update Issue File — FIXED

If the bug is fixed:

1. Update the issue file with Edit tool:
   - Set `status: verified`
   - Fill in `expected` section:
     ```yaml
     expected:
       url: "<current URL (the correct one)>"
       screenshot: <path or null>
       assertions:
         - visible: "<key text that confirms fix>"
         - noConsoleErrors: true
     ```
   - Append to `history`:
     ```yaml
     - timestamp: "<ISO 8601 now>"
       action: verified
       agent: patrol
       notes: "<what you observed — the fix works because...>"
     ```

2. Capture screenshot if possible:
   ```bash
   $B screenshot qa/patrol/issues/screenshots/<issue-id>-expected.png
   ```

3. Validate the updated issue file:
   ```bash
   python3 -c "import yaml; yaml.safe_load(open('qa/patrol/issues/<issue-id>.yml')); print('VALID')"
   ```
   If error: fix the YAML, re-write, re-validate. Max 2 retries.

4. Proceed to Section 8 (Manifest Promotion).

## 7. Update Issue File — NOT FIXED / REGRESSION

### NOT FIXED

1. Update the issue file:
   - Set `status: fix-pending`
   - Update `observed` with current state (may have changed slightly)
   - Append to `history`:
     ```yaml
     - timestamp: "<ISO 8601 now>"
       action: verified
       agent: patrol
       notes: "Bug still present. <describe current state>"
     ```

### REGRESSION

1. Update the original issue file:
   - Set `status: regression`
   - Append to `history`:
     ```yaml
     - timestamp: "<ISO 8601 now>"
       action: regression-found
       agent: patrol
       notes: "Original bug fixed but new issue found: <describe>"
     ```

2. Create a NEW issue file for the regression:
   - Generate a new issue ID from the regression description
   - Set `source: "regression"`
   - Fill in navigation, observed, etc. from what you just saw
   - Set `status: reproduced`
   - Reference the original issue in `report.description`: "Regression from fix of <original-issue-id>"

After any issue file write/edit in this section, validate:
```bash
python3 -c "import yaml; yaml.safe_load(open('qa/patrol/issues/<issue-id>.yml')); print('VALID')"
```
If error: fix the YAML, re-write, re-validate. Max 2 retries.

## 8. Manifest Promotion

Only run if `promote.toManifest` is `true` AND the issue status is now `verified`.

Read `qa/patrol/manifest.yml`.

### Updating an Existing Flow

If `promote.targetFlow` references an existing flow ID in the manifest:

1. **Assertions (additive):** Append new assertions from `expected.assertions` to the flow. Do NOT remove existing assertions.
2. **Contradictions:** If a new assertion directly contradicts an existing one (e.g., old `visible: "Welcome"` vs new `visible: "Dashboard"`), replace the old one. Log the replacement in the issue's history: "Manifest assertion updated: replaced `visible: Welcome` with `visible: Dashboard`"
3. **Navigation steps:** Only replace the flow's steps if `promote.replaceSteps: true`. Otherwise, keep existing steps. New flows always get steps from the issue.

### Creating a New Flow

If `promote.targetFlow` is null:

1. Create a new flow entry in the manifest with:
   - `id`: derived from the issue title (kebab-case)
   - `description`: from the issue title
   - `steps`: from the issue's `navigation.steps`
   - assertions from `expected.assertions`

2. Check if the page path from `navigation.steps[0].goto` exists in `pages`. If not, add a new page entry.

Write the updated manifest with the Write tool. Then validate:

```bash
python3 -c "import yaml; yaml.safe_load(open('qa/patrol/manifest.yml')); print('VALID')"
```

If error: fix the YAML, re-write, re-validate. Max 2 retries.

## 9. Output Summary

Print a clear summary:

```
## Verification Complete

**Issue:** <issue-id>
**Result:** VERIFIED (or NOT FIXED or REGRESSION)

**Findings:**
- <what you observed>

**Issue file:** Updated at qa/patrol/issues/<issue-id>.yml
**Manifest:** <updated with new assertions | no changes | not applicable>

<if REGRESSION>
**Regression:** New issue created at qa/patrol/issues/<new-id>.yml
</if>

<if VERIFIED>
**The fix is confirmed.** The issue can be closed.
</if>

<if NOT FIXED>
**The bug persists.** Apply a fix and run `/patrol-verify <issue-id>` again.
</if>
```
