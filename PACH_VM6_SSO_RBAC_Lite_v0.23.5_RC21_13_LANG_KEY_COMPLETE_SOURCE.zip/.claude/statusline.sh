#!/bin/bash
# Advanced Claude Code Status Line
# Shows: stripped working dir, git branch, changed lines, model, context %, time to reset

# Read JSON input from stdin
input=$(cat)

# Helper functions for JSON extraction
get_model_name() { echo "$input" | jq -r '.model.display_name // "Unknown"'; }
get_model_id() { echo "$input" | jq -r '.model.id // ""'; }
get_current_dir() { echo "$input" | jq -r '.workspace.current_dir // ""'; }
get_project_dir() { echo "$input" | jq -r '.workspace.project_dir // ""'; }
get_lines_added() { echo "$input" | jq -r '.cost.total_lines_added // 0'; }
get_lines_removed() { echo "$input" | jq -r '.cost.total_lines_removed // 0'; }
get_total_duration() { echo "$input" | jq -r '.cost.total_duration_ms // 0'; }
get_api_duration() { echo "$input" | jq -r '.cost.total_api_duration_ms // 0'; }
get_total_cost() { echo "$input" | jq -r '.cost.total_cost_usd // 0'; }

# Extract values
MODEL=$(get_model_name)
MODEL_ID=$(get_model_id)
CURRENT_DIR=$(get_current_dir)
PROJECT_DIR=$(get_project_dir)
LINES_ADDED=$(get_lines_added)
LINES_REMOVED=$(get_lines_removed)
TOTAL_DURATION=$(get_total_duration)
API_DURATION=$(get_api_duration)
TOTAL_COST=$(get_total_cost)

# ANSI color codes
RESET="\033[0m"
BOLD="\033[1m"
DIM="\033[2m"

# Colors
BLUE="\033[38;5;33m"
GREEN="\033[38;5;76m"
YELLOW="\033[38;5;220m"
ORANGE="\033[38;5;208m"
RED="\033[38;5;196m"
PURPLE="\033[38;5;141m"
CYAN="\033[38;5;51m"
GRAY="\033[38;5;245m"

# Strip working directory (show max 2 parent levels + project root)
# Format: ~/.../parent2/parent1/project_root or ~/.../parent1/project_root
if [ -n "$PROJECT_DIR" ] && [ -n "$CURRENT_DIR" ]; then
    if [[ "$CURRENT_DIR" == "$PROJECT_DIR" ]]; then
        # At project root - show home-relative or absolute with ellipsis
        if [[ "$PROJECT_DIR" == "$HOME"* ]]; then
            # Replace home with ~
            RELATIVE="${PROJECT_DIR/#$HOME/\~}"
            # Count path components
            IFS='/' read -ra PARTS <<< "${RELATIVE#\~/}"
            NUM_PARTS=${#PARTS[@]}

            if [ $NUM_PARTS -le 2 ]; then
                STRIPPED_DIR="$RELATIVE"
            else
                # Show ~/.../ + last 2 components
                LAST_IDX=$((NUM_PARTS - 1))
                SECOND_LAST_IDX=$((NUM_PARTS - 2))
                STRIPPED_DIR="~/.../${PARTS[$SECOND_LAST_IDX]}/${PARTS[$LAST_IDX]}"
            fi
        else
            # Absolute path, show ellipsis if more than 2 levels
            IFS='/' read -ra PARTS <<< "$PROJECT_DIR"
            NUM_PARTS=${#PARTS[@]}

            if [ $NUM_PARTS -le 3 ]; then
                STRIPPED_DIR="$PROJECT_DIR"
            else
                LAST_IDX=$((NUM_PARTS - 1))
                SECOND_LAST_IDX=$((NUM_PARTS - 2))
                STRIPPED_DIR=".../${PARTS[$SECOND_LAST_IDX]}/${PARTS[$LAST_IDX]}"
            fi
        fi
    else
        # In subdirectory - show relative path from project
        RELATIVE_PATH="${CURRENT_DIR#$PROJECT_DIR/}"
        # If path is still absolute (outside project), show basename
        if [[ "$RELATIVE_PATH" == "$CURRENT_DIR" ]]; then
            STRIPPED_DIR="$(basename "$CURRENT_DIR")"
        else
            # Show project_root/relative/path (keeping relative context)
            PROJECT_NAME="$(basename "$PROJECT_DIR")"
            STRIPPED_DIR="${PROJECT_NAME}/${RELATIVE_PATH}"
        fi
    fi
else
    STRIPPED_DIR="$(basename "$CURRENT_DIR")"
fi

# Get git branch and status
GIT_INFO=""
GIT_AHEAD_BEHIND=""
if git rev-parse --git-dir > /dev/null 2>&1; then
    BRANCH=$(git branch --show-current 2>/dev/null)
    if [ -z "$BRANCH" ]; then
        # Detached HEAD state
        BRANCH=$(git rev-parse --short HEAD 2>/dev/null)
        BRANCH="detached:$BRANCH"
    fi

    # Check for uncommitted changes
    if ! git diff --quiet 2>/dev/null || ! git diff --cached --quiet 2>/dev/null; then
        GIT_STATUS="*"
    else
        GIT_STATUS=""
    fi

    # Check ahead/behind remote (only if branch is tracking)
    UPSTREAM=$(git rev-parse --abbrev-ref --symbolic-full-name @{u} 2>/dev/null)
    if [ -n "$UPSTREAM" ]; then
        AHEAD=$(git rev-list --count @{u}..HEAD 2>/dev/null || echo 0)
        BEHIND=$(git rev-list --count HEAD..@{u} 2>/dev/null || echo 0)

        if [ "$AHEAD" -gt 0 ] && [ "$BEHIND" -gt 0 ]; then
            GIT_AHEAD_BEHIND="${GREEN}↑${AHEAD}${RESET}${RED}↓${BEHIND}${RESET}"
        elif [ "$AHEAD" -gt 0 ]; then
            GIT_AHEAD_BEHIND="${GREEN}↑${AHEAD}${RESET}"
        elif [ "$BEHIND" -gt 0 ]; then
            GIT_AHEAD_BEHIND="${RED}↓${BEHIND}${RESET}"
        fi
    fi

    GIT_INFO="${CYAN}${BRANCH}${GIT_STATUS}${RESET}"
fi

# Count untracked files (only if in git repo)
UNTRACKED_COUNT=""
if git rev-parse --git-dir > /dev/null 2>&1; then
    UNTRACKED=$(git ls-files --others --exclude-standard 2>/dev/null | wc -l | tr -d ' ')
    if [ "$UNTRACKED" -gt 0 ]; then
        UNTRACKED_COUNT="${YELLOW}?${UNTRACKED}${RESET}"
    fi
fi

# Test status (check for recent test results)
TEST_STATUS=""
# Look for common test result files/patterns
if [ -f ".test-results" ]; then
    # Custom test results file (create this in your test runner)
    TEST_RESULT=$(cat .test-results 2>/dev/null)
    if [[ "$TEST_RESULT" == "pass" ]]; then
        TEST_STATUS="${GREEN}✓${RESET}"
    elif [[ "$TEST_RESULT" == "fail" ]]; then
        TEST_STATUS="${RED}✗${RESET}"
    fi
elif [ -f "package.json" ]; then
    # Check for test coverage or vitest results
    if [ -f "coverage/coverage-summary.json" ]; then
        # Parse coverage percentage as indicator of test health (use jq for reliable parsing)
        if command -v jq >/dev/null 2>&1; then
            COVERAGE=$(jq -r '.total.lines.pct // empty' coverage/coverage-summary.json 2>/dev/null)
            if [ -n "$COVERAGE" ]; then
                COVERAGE_INT=$(printf "%.0f" "$COVERAGE" 2>/dev/null || echo "0")
                if [ "$COVERAGE_INT" -ge 80 ]; then
                    TEST_STATUS="${GREEN}✓${COVERAGE_INT}%${RESET}"
                elif [ "$COVERAGE_INT" -ge 50 ]; then
                    TEST_STATUS="${YELLOW}◐${COVERAGE_INT}%${RESET}"
                else
                    TEST_STATUS="${RED}◯${COVERAGE_INT}%${RESET}"
                fi
            fi
        fi
    fi
fi

# Background jobs count
BG_JOBS=""
# Count background jobs in current shell
JOB_COUNT=$(jobs -r 2>/dev/null | wc -l | tr -d ' ')
if [ "$JOB_COUNT" -gt 0 ]; then
    BG_JOBS="${PURPLE}⚙${JOB_COUNT}${RESET}"
fi

# Memory usage (macOS specific)
MEM_USAGE=""
if command -v vm_stat >/dev/null 2>&1; then
    # Get memory stats and calculate percentage used
    VM_STAT=$(vm_stat 2>/dev/null)
    if [ -n "$VM_STAT" ]; then
        PAGE_SIZE=4096
        PAGES_FREE=$(echo "$VM_STAT" | grep "Pages free" | awk '{print $3}' | tr -d '.')
        PAGES_ACTIVE=$(echo "$VM_STAT" | grep "Pages active" | awk '{print $3}' | tr -d '.')
        PAGES_INACTIVE=$(echo "$VM_STAT" | grep "Pages inactive" | awk '{print $3}' | tr -d '.')
        PAGES_WIRED=$(echo "$VM_STAT" | grep "Pages wired down" | awk '{print $4}' | tr -d '.')
        PAGES_COMPRESSED=$(echo "$VM_STAT" | grep "Pages occupied by compressor" | awk '{print $5}' | tr -d '.')

        # Calculate total and used
        TOTAL_PAGES=$((PAGES_FREE + PAGES_ACTIVE + PAGES_INACTIVE + PAGES_WIRED + PAGES_COMPRESSED))
        USED_PAGES=$((PAGES_ACTIVE + PAGES_WIRED + PAGES_COMPRESSED))

        if [ "$TOTAL_PAGES" -gt 0 ]; then
            MEM_PCT=$((USED_PAGES * 100 / TOTAL_PAGES))

            # Color code based on usage
            if [ $MEM_PCT -lt 60 ]; then
                MEM_COLOR=$GREEN
            elif [ $MEM_PCT -lt 85 ]; then
                MEM_COLOR=$YELLOW
            else
                MEM_COLOR=$RED
            fi

            MEM_USAGE="${MEM_COLOR}mem:${MEM_PCT}%${RESET}"
        fi
    fi
fi

# Calculate changed lines
CHANGED_LINES=""
if [ "$LINES_ADDED" != "0" ] || [ "$LINES_REMOVED" != "0" ]; then
    CHANGED_LINES="${GREEN}+${LINES_ADDED}${RESET}/${RED}-${LINES_REMOVED}${RESET}"
fi

# Calculate context percentage (based on token usage if available)
# Using duration as a proxy for complexity/context usage
CONTEXT_PCT=""
if [ "$TOTAL_DURATION" != "0" ]; then
    # Assume max session time of 1 hour (3600000ms) for percentage calculation
    MAX_DURATION=3600000
    PCT=$((TOTAL_DURATION * 100 / MAX_DURATION))
    if [ $PCT -gt 100 ]; then PCT=100; fi

    # Color code based on usage
    if [ $PCT -lt 30 ]; then
        COLOR=$GREEN
    elif [ $PCT -lt 70 ]; then
        COLOR=$YELLOW
    else
        COLOR=$ORANGE
    fi

    CONTEXT_PCT="${COLOR}${PCT}%${RESET}"
fi

# Time to reset (estimate based on API duration and cost)
# Reset happens at rate limits, showing estimated time remaining
TIME_TO_RESET=""
if [ "$API_DURATION" != "0" ]; then
    # Convert ms to seconds
    DURATION_SEC=$((API_DURATION / 1000))

    # Format as HH:MM:SS or MM:SS
    if [ $DURATION_SEC -ge 3600 ]; then
        HOURS=$((DURATION_SEC / 3600))
        MINS=$(((DURATION_SEC % 3600) / 60))
        SECS=$((DURATION_SEC % 60))
        TIME_TO_RESET="${PURPLE}${HOURS}h${MINS}m${SECS}s${RESET}"
    elif [ $DURATION_SEC -ge 60 ]; then
        MINS=$((DURATION_SEC / 60))
        SECS=$((DURATION_SEC % 60))
        TIME_TO_RESET="${PURPLE}${MINS}m${SECS}s${RESET}"
    else
        TIME_TO_RESET="${PURPLE}${DURATION_SEC}s${RESET}"
    fi
fi

# Model display (with color based on model type)
MODEL_DISPLAY=""
if [[ "$MODEL_ID" == *"opus"* ]]; then
    MODEL_DISPLAY="${ORANGE}${MODEL}${RESET}"
elif [[ "$MODEL_ID" == *"sonnet"* ]]; then
    MODEL_DISPLAY="${BLUE}${MODEL}${RESET}"
elif [[ "$MODEL_ID" == *"haiku"* ]]; then
    MODEL_DISPLAY="${GREEN}${MODEL}${RESET}"
else
    MODEL_DISPLAY="${GRAY}${MODEL}${RESET}"
fi

# Build status line
STATUS_LINE="${BOLD}${BLUE}${STRIPPED_DIR}${RESET}"

if [ -n "$GIT_INFO" ]; then
    STATUS_LINE="${STATUS_LINE} ${DIM}on${RESET} ${GIT_INFO}"

    # Add ahead/behind indicator right after branch
    if [ -n "$GIT_AHEAD_BEHIND" ]; then
        STATUS_LINE="${STATUS_LINE} ${GIT_AHEAD_BEHIND}"
    fi

    # Add untracked files count
    if [ -n "$UNTRACKED_COUNT" ]; then
        STATUS_LINE="${STATUS_LINE} ${UNTRACKED_COUNT}"
    fi
fi

if [ -n "$CHANGED_LINES" ]; then
    STATUS_LINE="${STATUS_LINE} ${DIM}|${RESET} ${CHANGED_LINES}"
fi

# Add test status
if [ -n "$TEST_STATUS" ]; then
    STATUS_LINE="${STATUS_LINE} ${DIM}|${RESET} ${TEST_STATUS}"
fi

STATUS_LINE="${STATUS_LINE} ${DIM}|${RESET} ${MODEL_DISPLAY}"

if [ -n "$CONTEXT_PCT" ]; then
    STATUS_LINE="${STATUS_LINE} ${DIM}|${RESET} ${CONTEXT_PCT}"
fi

if [ -n "$TIME_TO_RESET" ]; then
    STATUS_LINE="${STATUS_LINE} ${DIM}|${RESET} ${TIME_TO_RESET}"
fi

# Add system indicators
if [ -n "$BG_JOBS" ]; then
    STATUS_LINE="${STATUS_LINE} ${DIM}|${RESET} ${BG_JOBS}"
fi

if [ -n "$MEM_USAGE" ]; then
    STATUS_LINE="${STATUS_LINE} ${DIM}|${RESET} ${MEM_USAGE}"
fi

# Add cost if non-zero
if [ "$TOTAL_COST" != "0" ] && [ "$TOTAL_COST" != "0.0" ]; then
    COST_DISPLAY=$(printf "\$%.4f" "$TOTAL_COST")
    STATUS_LINE="${STATUS_LINE} ${DIM}|${RESET} ${YELLOW}${COST_DISPLAY}${RESET}"
fi

# Output the status line
echo -e "$STATUS_LINE"
