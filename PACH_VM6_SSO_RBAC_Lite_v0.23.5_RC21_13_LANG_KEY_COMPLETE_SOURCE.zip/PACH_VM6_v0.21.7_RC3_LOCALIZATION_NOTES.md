# PACH VM6 v0.21.7 RC3 — Localization Expansion

Base: v0.21.6 RC2. This release adds 540 translated values across 10 languages (39 Dashboard and 15 Profile values per language), and correctly registers both new namespaces in the i18n resource bundle. It does **not** declare full localization. The existing English fallback remains for all untranslated namespaces.

### Validation

- English source has 1,062 strings across 13 namespaces.
- No translated keys added outside the English source.
- Every new translation preserves `{{...}}` placeholders.
- All new namespaces are imported and mapped into `resources.ts`.
- The SSO/RBAC Lite and backend implementation from the previous release remains unchanged.

### Remaining work

Complete the `audit`, `groups`, `orgs`, `provisioning`, and `users` namespaces for ten newer languages, perform full frontend build, browser language-switch and Arabic RTL checks, and obtain native-language review. The `errors` namespace is empty in the English source.

See `PACH_VM6_v0.21.7_RC3_LOCALIZATION_STATUS.json` for machine-readable counts.
