# FIRA Follow-Up Issue Drafts — SSO Device Provisioning

## Issue 1: Fix rate limiting to be per-user, not per-IP

**Title:** [BUG] Device provisioning rate limit is per-IP instead of per-user as designed
**Labels:** `bug`, `security`
**Priority:** Medium
**Linked to:** F-01, REQ-22

**Body:**

### Problem

The design spec for SSO device provisioning (`docs/superpowers/specs/2026-03-11-sso-device-provisioning-design.md`) specifies rate limiting should be "per-user (keyed on `preferred_username` from OIDC claims, not per-IP)."

The implementation at `src/backend/main.py:4171` uses `@limiter.limit(LIMIT_DEVICE_PROVISION)` which inherits the default `get_client_ip` key function from slowapi.

### Impact

- Users behind shared NAT share a 5/min limit
- A single user can bypass the limit by switching IPs

### Fix

Add a custom key function to the rate limit decorator that extracts the authenticated user identity:

```python
def _device_provision_key(request: Request) -> str:
    """Rate limit by authenticated user, not IP."""
    # require_user dependency sets this; fall back to IP
    claims = getattr(request.state, 'oidc_claims', None)
    if claims:
        return claims.get('preferred_username', get_client_ip(request))
    return get_client_ip(request)

@limiter.limit(LIMIT_DEVICE_PROVISION, key_func=_device_provision_key)
```

### Evidence

- `src/backend/rate_limit.py:21-26` — default key_func is `get_client_ip`
- `src/backend/main.py:4171` — no custom key_func
- Design spec: "per-user (keyed on preferred_username)"

---

## Issue 2: Add 409 DEVICE_CAP_REACHED integration test

**Title:** [TEST] Add device cap exhaustion test for SSO provisioning
**Labels:** `testing`
**Priority:** Medium
**Linked to:** F-03, REQ-18, REQ-24

**Body:**

### Problem

The device cap enforcement code at `src/backend/main.py:4234-4241` has no integration test that exercises the 409 DEVICE_CAP_REACHED error path. Only the re-provision bypass (same deviceId) is tested.

### What to test

1. Create user with `max_devices_per_user=2` on config template
2. Provision device 1 (unique deviceId) → 200
3. Provision device 2 (unique deviceId) → 200
4. Provision device 3 (unique deviceId) → 409 with `DEVICE_CAP_REACHED`
5. Assert response body includes `current` and `max` fields

### Where

`tests/test_device_provisioning.py` — add `test_device_cap_exhaustion` to `TestDeviceCapEnforcement`

---

## Issue 3: Record client IP in device provisioning audit trail

**Title:** [FEAT] Record client IP in SSO device provision records
**Labels:** `enhancement`, `security`
**Priority:** Low
**Linked to:** F-02

**Body:**

### Problem

The `upsert_device_provision()` method accepts a `client_ip` parameter (`src/backend/orgdb.py:672`) but the `POST /api/provision/device` endpoint does not pass it (`src/backend/main.py:4275-4283`).

The design spec's security model lists "Audit trail (IP, device info)" as a mitigation for stolen OIDC tokens.

### Fix

Add `client_ip=request.client.host if request.client else None` to the `upsert_device_provision()` call in the endpoint.

---

## Issue 4: Exclude expired provisions from device cap count

**Title:** [BUG] Expired device provisions still count against device cap
**Labels:** `bug`
**Priority:** Medium
**Linked to:** F-09

**Body:**

### Problem

`count_active_device_provisions()` at `src/backend/orgdb.py:648-656` filters on `status='active'` but does NOT filter out provisions past their `expires_at` timestamp. After `DEVICE_PROVISION_TTL_SEC` (30 days), provisions conceptually expire but continue consuming cap slots.

### Impact

Users with long-lived provisions will eventually be blocked from provisioning new devices without explicitly revoking expired ones.

### Fix

Add an additional condition:

```python
conditions = [
    provision_tokens.c.uid == uid,
    provision_tokens.c.auth_method == "sso_token",
    provision_tokens.c.status == "active",
    provision_tokens.c.expires_at > utcnow(),  # ← add this
]
```

### Alternative

Add a periodic cleanup job that sets `status='expired'` on provisions past their `expires_at`.

---

## Issue 5: Update design spec to match implementation

**Title:** [DOCS] Update SSO device provisioning spec to match implementation
**Labels:** `documentation`
**Priority:** Low
**Linked to:** F-04, F-10

**Body:**

### Changes needed

1. **Profile resolution:** Spec says `resolve_template_for_org(org_dn)` but code reads `azblinkProfileId` from LDAP user entry and calls `get_config_template(profile_id)` directly. The implementation is better — update spec.

2. **Test location:** Spec says "Updated: `tests/test_provisioning.py`" but coverage was added to `tests/test_device_provisioning.py` instead. Update spec.

3. **Rate limiting:** Once F-01 is fixed, update spec to document the key function approach.

---

## Summary

| # | Title | Priority | Type |
|---|-------|----------|------|
| 1 | Rate limit per-user not per-IP | Medium | Bug |
| 2 | Device cap exhaustion test | Medium | Test |
| 3 | Record client IP in audit trail | Low | Enhancement |
| 4 | Expired provisions cap count | Medium | Bug |
| 5 | Update design spec | Low | Docs |
