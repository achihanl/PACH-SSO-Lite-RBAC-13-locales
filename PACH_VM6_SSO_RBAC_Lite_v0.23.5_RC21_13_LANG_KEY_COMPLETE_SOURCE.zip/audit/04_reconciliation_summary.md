# FIRA Reconciliation Summary — SSO Device Provisioning

## Three-Way Reconciliation

### Spec → Issue → Code

The design spec (`docs/superpowers/specs/2026-03-11-sso-device-provisioning-design.md`) and issue #60 are tightly aligned — the issue body embeds the acceptance criteria derived from the spec. All 25 requirements extracted from the acceptance criteria have corresponding code in PR #61.

**Alignment is strong:**
- LDAP schema, migration, config, deps: 100% match
- LDAP layer (build_uc_attrs, get_uc_credentials, password sync): 100% match
- DB layer (count, upsert, revoke): 100% match
- API endpoints: 95% match (minor deviations noted below)

### Deviations Found

| # | Type | Finding | Severity | Remediation | Status |
|---|------|---------|----------|-------------|--------|
| 1 | spec_to_code | Rate limiting is per-IP, not per-user as spec requires | Medium | Added `_device_provision_key()` extracting `preferred_username` from Bearer token | **RESOLVED** |
| 2 | code_to_spec | `client_ip` not recorded in provision audit trail | Low | Pass `request.client.host` to `upsert_device_provision()` | **RESOLVED** |
| 3 | spec_to_code | No API-level test for 409 DEVICE_CAP_REACHED | Medium | Added `test_device_cap_exhaustion` with `maxDevicesPerUser=2` | **RESOLVED** |
| 4 | spec_to_code | Design spec says update `tests/test_provisioning.py` — not done | Low | Updated spec to reference `tests/test_device_provisioning.py` | **RESOLVED** |
| 5 | code_to_spec | Expired provisions still count against device cap | Medium | Added `expires_at > utcnow()` filter in `count_active_device_provisions()` | **RESOLVED** |
| 6 | code_to_spec | Profile resolved via user LDAP attr, not `resolve_template_for_org(org_dn)` | Info | Updated spec to match implementation | **RESOLVED** |

### Coverage Analysis

**Code coverage by test evidence:**

| Layer | Functions/Endpoints | Tests | Coverage |
|-------|---------------------|-------|----------|
| LDAP `build_uc_attrs` | 1 function (2 new params) | 4 unit tests | Full |
| LDAP `get_uc_credentials` | 1 function | 2 integration tests | Full |
| LDAP `_set_user_passwords` | 1 function | 1 integration test | Full |
| LDAP `reset_user_password` | 1 function (modified) | 1 integration test | Full |
| LDAP user creation flow | 1 path (password passthrough) | 1 integration test | Full |
| DB `count_active_device_provisions` | 1 function | 2 integration tests | Full |
| DB `upsert_device_provision` | 1 function | 2 integration tests | Full |
| DB `revoke_device_provision` | 1 function | 3 integration tests | Full |
| POST `/api/provision/device` | 1 endpoint | 3 integration tests | Full |
| DELETE `/api/provision/device/{id}` | 1 endpoint | 3 integration tests | Full |
| Device cap enforcement | 1 flow | 2 integration tests | Full (re-provision bypass + cap exhaustion 409) |

**23 integration tests total**, covering:
- Auth enforcement (401): 2 tests
- Public key validation (422): 1 test
- Sealed box roundtrip: 1 test
- LDAP credential storage: 1 test
- LDAP credential retrieval: 2 tests
- Password sync: 1 test
- DB device counting: 2 tests
- DB upsert: 2 tests
- DB revocation: 3 tests
- API provisioning: 3 tests (happy path, no auth, invalid key)
- API deletion: 3 tests (delete, nonexistent, no auth)
- Device cap: 2 tests (re-provision bypass + cap exhaustion 409)

**Not tested:**
- Rate limiting behavior (key function verified by code review)
- Edge case: user with no config template

### Spec Completeness

| Spec Section | Implementation Status |
|-------------|----------------------|
| Problem statement | N/A (context) |
| Design decisions | All 6 decisions implemented |
| API contract (POST) | Implemented, response shape matches |
| API contract (DELETE) | Implemented, response shape matches |
| Backend flow (9 steps) | Steps 1-9 all implemented |
| LDAP changes | All 4 items implemented |
| Database changes | Migration + table def + config_templates extension |
| Device cap enforcement | Logic implemented, expiry gap noted |
| Security model | 5/5 mitigations implemented (audit IP gap noted) |
| Files modified | All 11 listed files modified |
| Tests | New test file created (spec said update existing — deviation) |
| Out of scope | Correctly excluded |

## Sceptical Challenge

### Challenge: REQ-18 (Device Cap) — RESOLVED

**Claim:** Device cap enforcement is implemented.
**Evidence:** Code at `main.py:4256-4263` checks `current_count >= max_devices` and raises 409.
**Test evidence:** `test_device_cap_exhaustion` provisions 3 devices against cap=2, asserts 409 DEVICE_CAP_REACHED with `current=2, max=2`.
**Verdict:** **Implemented** — both re-provision bypass and cap exhaustion are tested end-to-end.

### Challenge: REQ-22 (Rate Limiting) — RESOLVED

**Claim:** Rate limiting is per-user.
**Evidence:** `_device_provision_key()` at `main.py:4170-4185` extracts `preferred_username` from Bearer token via unverified JWT decode. Applied via `key_func=_device_provision_key` on the `@limiter.limit()` decorator.
**Verdict:** **Implemented** — rate limiting now keys on OIDC `preferred_username`, falling back to IP for unauthenticated/unparseable tokens.

### Challenge: REQ-25 (No Regression) — VERIFIED

**Claim:** All existing tests pass.
**Evidence:** Full test suite run: 432 passed, 1 pre-existing failure (`test_search_filter` — expects user "mei" that isn't created by fixture), 8 skipped.
**Verdict:** **Verified** — no regressions introduced.
