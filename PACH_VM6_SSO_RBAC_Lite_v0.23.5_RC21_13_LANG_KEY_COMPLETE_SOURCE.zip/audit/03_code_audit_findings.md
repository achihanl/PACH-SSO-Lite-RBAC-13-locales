# FIRA Code Audit Findings — SSO Device Provisioning

## Finding F-01: Rate Limiting Keyed Per-IP, Not Per-User (spec_to_code)

**Severity:** Medium
**Confidence:** High
**Status:** Contradicted

**Spec says:** "Rate limiting: New constant `LIMIT_DEVICE_PROVISION = "5/minute"` in `rate_limit.py`, applied **per-user** (keyed on `preferred_username` from OIDC claims, not per-IP)."

**Code does:** The `@limiter.limit(LIMIT_DEVICE_PROVISION)` decorator at `main.py:4171` uses the default `slowapi` key function, which is `get_client_ip` (defined at `rate_limit.py:21-26`). This means rate limiting is keyed by client IP, not by OIDC `preferred_username`.

**Impact:** A single authenticated user could exceed 5 provisions/minute by switching IPs (e.g., VPN, mobile network). Conversely, multiple users behind a shared NAT would collectively share a 5/min limit.

**Evidence:**
- `src/backend/rate_limit.py:31-36` — limiter key_func is `get_client_ip`
- `src/backend/main.py:4171` — `@limiter.limit(LIMIT_DEVICE_PROVISION)` uses default key_func
- Design spec line 234 — "per-user (keyed on preferred_username from OIDC claims, not per-IP)"

**Recommendation:** Add a custom `key_func` to the `@limiter.limit()` call that extracts `preferred_username` from the OIDC claims, e.g.:
```python
@limiter.limit(LIMIT_DEVICE_PROVISION, key_func=lambda req: getattr(req.state, 'oidc_user', get_client_ip(req)))
```

---

## Finding F-02: Client IP Not Recorded in Provision Audit Trail (code_to_spec)

**Severity:** Low
**Confidence:** High
**Status:** Partially Implemented

**Spec says:** The security model mentions "Audit trail (IP, device info)" as a mitigation for stolen OIDC tokens. The `upsert_device_provision()` method accepts a `client_ip` parameter (`orgdb.py:672`).

**Code does:** The `POST /api/provision/device` endpoint at `main.py:4275-4283` calls `upsert_device_provision()` but does NOT pass `client_ip`. The `client_ip` parameter defaults to `None`.

**Impact:** Provision records lack the originating IP address, reducing audit trail usefulness for security investigations.

**Evidence:**
- `src/backend/orgdb.py:672` — `client_ip: str | None = None` parameter exists
- `src/backend/main.py:4275-4283` — `client_ip` not included in call
- Design spec Security Model table — "Audit trail (IP, device info)"

**Recommendation:** Pass `request.client.host` as `client_ip` to `upsert_device_provision()`.

---

## Finding F-03: No Test for 409 DEVICE_CAP_REACHED (spec_to_code)

**Severity:** Medium
**Confidence:** High
**Status:** Partially Implemented

**Spec says:** Issue #60 acceptance criteria: "Integration tests: auth, **device cap enforcement**, sealed box roundtrip decryption, revocation, re-provision bypass, error cases"

**Code does:** The test suite tests re-provision bypass (same deviceId doesn't consume new slot) and DB-level cap counting, but there is NO test that provisions N+1 unique devices to trigger the 409 DEVICE_CAP_REACHED response at the API level.

**Impact:** The 409 error path is untested at the API level. If the cap enforcement logic has a bug (e.g., off-by-one, wrong comparison operator), it would not be caught.

**Evidence:**
- `tests/test_device_provisioning.py:476-515` — `TestDeviceCapEnforcement` only tests re-provision bypass
- `src/backend/main.py:4234-4241` — cap check code exists but no test drives it to 409
- Issue #60 — "device cap enforcement" listed in acceptance criteria

**Recommendation:** Add a test that creates a user with `max_devices_per_user=2`, provisions 2 unique devices, then attempts a 3rd and asserts 409 with `DEVICE_CAP_REACHED` error.

---

## Finding F-04: Design Spec Says Update `tests/test_provisioning.py` — Not Done (spec_to_code)

**Severity:** Low
**Confidence:** High
**Status:** Missing

**Spec says:** Under "Tests" section: "Updated: `tests/test_provisioning.py` — verify `azbXmppBindPassword` set during user creation"

**Code does:** No changes were made to `tests/test_provisioning.py`. The `azbXmppBindPassword` verification was instead added to the new `tests/test_device_provisioning.py` file (class `TestUserCreationXmppPassword`).

**Impact:** Minimal — the intent is covered in the new test file. The spec's suggested location was advisory, not mandatory.

**Evidence:**
- `git diff main...sso-device-provisioning --stat` shows no changes to `tests/test_provisioning.py`
- `tests/test_device_provisioning.py:149-168` — `TestUserCreationXmppPassword` covers this

**Recommendation:** No action needed. The coverage exists in the new file. Update the design spec to reflect actual test location.

---

## Finding F-05: `appName` Captured in Model But Not Stored (code_to_spec)

**Severity:** Info
**Confidence:** High
**Status:** Implemented (by design)

**Spec says:** "`appName` is not stored."

**Code does:** `ClientInfoModel` at `main.py:4155` includes `appName` as a field but it is never passed to `upsert_device_provision()`. The field is accepted in the request but silently discarded.

**Impact:** None — this is by design per the spec. The field exists in the Pydantic model for forward-compatibility.

**Evidence:**
- `src/backend/main.py:4155` — `appName: str = Field(default="", max_length=64)`
- `src/backend/main.py:4282-4283` — only `platform` and `version` passed to upsert
- Design spec: "`appName` is not stored"

**Recommendation:** None.

---

## Finding F-06: `DELETE /api/provision/device/{device_id}` Has No Rate Limiting (code_to_spec)

**Severity:** Low
**Confidence:** High
**Status:** Partially Implemented

**Spec says:** Rate limiting is specified for `POST /api/provision/device` only.

**Code does:** The DELETE endpoint at `main.py:4303` has no `@limiter.limit()` decorator. It does have `Depends(require_user)` for auth.

**Impact:** Low — the DELETE endpoint only sets status='revoked' on the user's own records. Abuse would require a valid OIDC token and can only affect the authenticated user's own devices. The default global 100/min limit still applies.

**Evidence:**
- `src/backend/main.py:4303-4321` — no limiter decorator
- `src/backend/rate_limit.py:35` — default 100/min global limit applies

**Recommendation:** Acceptable as-is. The global rate limit provides basic protection. Add per-user rate limiting on DELETE if device revocation abuse becomes a concern.

---

## Finding F-07: `get_uc_credentials` Empty String Handling (code quality)

**Severity:** Low
**Confidence:** Medium
**Status:** Implemented

**Code:** `ldap_client.py:143-144` — The condition `if "azbXmppBindPassword" in entry and str(entry["azbXmppBindPassword"])` will treat empty string as falsy (returning None). This matches the spec requirement: "Empty string values treated as missing."

However, the logic is dense and relies on Python truthiness of `str(entry[...])` — if `entry["azbXmppBindPassword"]` is the ldap3 sentinel value for "attribute present but empty," `str()` might return `"[]"` or `""`.

**Impact:** Potential edge case where ldap3 represents an empty attribute as a non-empty string representation (e.g. `"[]"`), which would pass truthiness but return a meaningless value.

**Recommendation:** Add a defensive strip: `val = str(entry["azbXmppBindPassword"]).strip(); xmpp_pw = val if val and val != "[]" else None`

---

## Finding F-08: Sealed Payload Stored in DB (Security Observation)

**Severity:** Info
**Confidence:** High
**Status:** Implemented (by design)

**Spec says:** "Sealed payload in DB is audit-only — permanently unrecoverable after client discards ephemeral key."

**Code does:** `sealed_bytes` is stored in `provision_tokens.sealed_payload` (BYTEA) at `main.py:4280`. This is the ciphertext encrypted to the client's ephemeral public key.

**Impact:** The sealed payload cannot be decrypted without the client's ephemeral private key, which is never transmitted to the server. This is a sound design. However, if the client's private key is compromised AND the DB is breached, credentials could be recovered.

**Recommendation:** None — this is the documented design. The sealed payload serves as an audit trail proving what was encrypted.

---

## Finding F-09: No Expiry Enforcement on Provisions (spec gap)

**Severity:** Medium
**Confidence:** High
**Status:** Partially Implemented

**Spec says:** `DEVICE_PROVISION_TTL_SEC` defaults to 30 days. `expiresAt` is returned in the response.

**Code does:** The `expires_at` is set and stored in `provision_tokens`, but:
1. `count_active_device_provisions()` does NOT filter out expired provisions
2. There is no background job or API hook that marks expired provisions as inactive
3. The device cap count includes expired-but-not-revoked provisions

**Impact:** After 30 days, a provision "expires" conceptually but continues to count against the device cap. The user would need to explicitly DELETE/revoke expired devices to free cap slots.

**Evidence:**
- `src/backend/orgdb.py:648-656` — conditions filter on `status='active'` but NOT on `expires_at > now()`
- `src/backend/main.py:4272` — `expires_at` is set on insert
- Design spec: "Expired provisions → client must re-provision"

**Recommendation:** Add an `expires_at > utcnow()` condition to `count_active_device_provisions()` so expired provisions automatically stop counting against the cap. Alternatively, add a periodic cleanup job.

---

## Finding F-10: Profile Resolution Differs from Spec (code_to_spec)

**Severity:** Info
**Confidence:** Medium
**Status:** Implemented (deviated)

**Spec says:** "Resolve config template — `orgdb.resolve_template_for_org(org_dn)`. Read `maxDevicesPerUser`, service toggles, endpoints."

**Code does:** The endpoint reads `azblinkProfileId` from the LDAP user record, then calls `ORGDB.get_config_template(profile_id)` directly (`main.py:4208-4211`). It does NOT use `resolve_template_for_org(org_dn)`.

**Impact:** This is actually a better approach — it reads the profile_id directly from the user's LDAP entry rather than inferring it from the org hierarchy. The user-level profile linkage is more precise.

**Recommendation:** None — the implementation is better than the spec's suggested approach. Update spec to match.

---

## Findings Summary

| Severity | Count |
|----------|-------|
| Critical | 0 |
| High | 0 |
| Medium | 3 (F-01, F-03, F-09) |
| Low | 3 (F-02, F-04, F-06) |
| Info | 4 (F-05, F-07, F-08, F-10) |
