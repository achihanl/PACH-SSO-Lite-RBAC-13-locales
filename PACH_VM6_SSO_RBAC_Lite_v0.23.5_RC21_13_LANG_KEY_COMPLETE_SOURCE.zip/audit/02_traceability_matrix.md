# FIRA Traceability Matrix — SSO Device Provisioning

## Matrix

| Req ID | Area | Requirement Summary | Acceptance Criteria | Issues | PRs | Code Evidence | Test Evidence | Status | Gap Type | Severity | Confidence | Impact | Recommendation |
|--------|------|---------------------|---------------------|--------|-----|---------------|---------------|--------|----------|----------|------------|--------|----------------|
| REQ-01 | LDAP Schema | `azbXmppBindPassword` attribute in `azblink.schema` | OID AZBlinkAttr:7, caseExactMatch, SINGLE-VALUE, in azblinkUser MAY list | #60 | #61 | `deploy/dev/ldap/azblink.schema:62-69` (attribute def), `azblink.schema:79-80` (MAY list) | None (schema file, no unit test) | Implemented | — | — | High | — | — |
| REQ-02 | DB Migration | `auth_method`, `sealed_payload`, `public_key_hash` columns + indexes on `provision_tokens` | 3 columns, 2 indexes, rollback script | #60 | #61 | `migrations/022_device_provisioning.sql:5-21` | None (migration tested implicitly by integration tests) | Implemented | — | — | High | — | — |
| REQ-03 | DB Migration | `max_devices_per_user` on `config_templates` | Default 5, NOT NULL, integer | #60 | #61 | `migrations/022_device_provisioning.sql:10-12`, `src/backend/orgdb.py:285` (table def) | Implicit via device cap tests | Implemented | — | — | High | — | — |
| REQ-04 | Config | `DEVICE_PROVISION_TTL_SEC` (default 30 days) | Env var, int parse, 2592000 | #60 | #61 | `src/backend/config.py:91` | None (config constant, no dedicated test) | Implemented | — | — | High | — | — |
| REQ-05 | Config | `DEVICE_PROVISION_MAX_DEFAULT` (default 5) | Env var, int parse, 5 | #60 | #61 | `src/backend/config.py:92` | Implicit via device cap endpoint tests | Implemented | — | — | High | — | — |
| REQ-06 | Deps | `PyNaCl>=1.5` in requirements.txt | Import succeeds | #60 | #61 | `src/backend/requirements.txt:13` | `tests/test_device_provisioning.py:37-41` (import check + skipif) | Implemented | — | — | High | — | — |
| REQ-07 | LDAP | `build_uc_attrs()` accepts `xmpp_password`, sets `azbXmppBindPassword` | Parameter added, conditional on xmpp_enabled + xmpp_password | #60 | #61 | `src/backend/ldap_client.py:38` (param), `ldap_client.py:68-70` (attr set) | `tests/test_device_provisioning.py:95-146` (4 unit tests) | Implemented | — | — | High | — | — |
| REQ-08 | LDAP | `build_uc_attrs()` accepts `profile_id`, sets `azblinkProfileId` | Attribute set, azblinkUser objectClass added | #60 | #61 | `src/backend/ldap_client.py:39` (param), `ldap_client.py:73-75` (attr set), `ldap_client.py:77-78` (azblinkUser OC) | Implicit via user creation tests | Implemented | — | — | High | — | — |
| REQ-09 | LDAP | User creation passes plaintext password to `azbXmppBindPassword` | `main.py` passes `req.password` as `xmpp_password` | #60 | #61 | `src/backend/main.py:1508` (`xmpp_password=req.password if xmpp_on else None`) | `tests/test_device_provisioning.py:152-168` (LDAP verify test) | Implemented | — | — | High | — | — |
| REQ-10 | LDAP | `_set_user_passwords()` syncs both passwords atomically | Single LDAP MODIFY, conditional on azblinkUser OC | #60 | #61 | `src/backend/ldap_client.py:955-977` | `tests/test_device_provisioning.py:199-217` (password sync test) | Implemented | — | — | High | — | — |
| REQ-11 | LDAP | `reset_user_password()` delegates to `_set_user_passwords()` | Calls helper | #60 | #61 | `src/backend/ldap_client.py:980-992` (line 990: `_set_user_passwords(user_dn, new_password)`) | `tests/test_device_provisioning.py:199-217` (reset test) | Implemented | — | — | High | — | — |
| REQ-12 | LDAP | `get_uc_credentials(uid)` reads XMPP + SIP passwords | Returns dict; None if not found | #60 | #61 | `src/backend/ldap_client.py:122-147` | `tests/test_device_provisioning.py:174-193` (2 tests: happy path + missing user) | Implemented | — | — | High | — | — |
| REQ-13 | DB | `count_active_device_provisions()` with exclude_device_id | Filters sso_token + active, optional exclude | #60 | #61 | `src/backend/orgdb.py:638-660` | `tests/test_device_provisioning.py:226-246` (2 tests: zero count + QR exclusion) | Implemented | — | — | High | — | — |
| REQ-14 | DB | `upsert_device_provision()` UPSERT keyed on uid+device_id+auth_method | Update-first, insert on rowcount=0 | #60 | #61 | `src/backend/orgdb.py:662-728` | `tests/test_device_provisioning.py:252-289` (2 tests: insert + upsert) | Implemented | — | — | High | — | — |
| REQ-15 | DB | `revoke_device_provision()` sets status='revoked' | Scoped to uid + device_id + sso_token + active | #60 | #61 | `src/backend/orgdb.py:730-744` | `tests/test_device_provisioning.py:295-330` (3 tests: revoke, nonexistent, other-user) | Implemented | — | — | High | — | — |
| REQ-16 | API | `POST /api/provision/device` with OIDC auth | 401 without auth | #60 | #61 | `src/backend/main.py:4170-4175` (route + Depends(require_user)) | `tests/test_device_provisioning.py:407-412` (no auth → 401) | Implemented | — | — | High | — | — |
| REQ-17 | API | Public key validation (32-byte Curve25519, base64) | 422 on invalid | #60 | #61 | `src/backend/main.py:4191-4200` (3-stage validation) | `tests/test_device_provisioning.py:414-419` (invalid key → 422) | Implemented | — | — | High | — | — |
| REQ-18 | API | Device cap check with re-provision awareness | Excludes current deviceId, 409 on exceed | #60 | #61 | `src/backend/main.py:4234-4241` (cap check logic) | `tests/test_device_provisioning.py:487-515` (re-provision bypass) | Partially Implemented | spec_to_code | Medium | Medium | No test for 409 DEVICE_CAP_REACHED when cap is actually exceeded |
| REQ-19 | API | Sealed box encryption | nacl.public.SealedBox.encrypt | #60 | #61 | `src/backend/main.py:4266-4268` | `tests/test_device_provisioning.py:399-405` (roundtrip decrypt) | Implemented | — | — | High | — | — |
| REQ-20 | API | Response shape: ok, uid, sealedCredentials, endpoints, provisioned, expiresAt | JSON response fields | #60 | #61 | `src/backend/main.py:4293-4300` | `tests/test_device_provisioning.py:389-396` (field assertions) | Implemented | — | — | High | — | — |
| REQ-21 | API | `DELETE /api/provision/device/{device_id}` endpoint | 200 revoke, 404 not-found, 401 unauth | #60 | #61 | `src/backend/main.py:4303-4321` | `tests/test_device_provisioning.py:426-469` (3 tests: delete, nonexistent, no auth) | Implemented | — | — | High | — | — |
| REQ-22 | API | Rate limiting: `LIMIT_DEVICE_PROVISION = "5/minute"` | Decorator on POST endpoint | #60 | #61 | `src/backend/rate_limit.py:61`, `src/backend/main.py:4171` | None (rate limiting not integration-tested) | Implemented | — | — | Medium | — | Rate limiting verified by code inspection only |
| REQ-23 | API | Re-provisioning same deviceId updates (not new cap slot) | UPSERT behavior | #60 | #61 | `src/backend/orgdb.py:686-707` (update-first), `src/backend/main.py:4234` (exclude_device_id) | `tests/test_device_provisioning.py:487-515` (re-provision test) | Implemented | — | — | High | — | — |
| REQ-24 | Test | Integration tests for all categories | auth, cap, sealed box, revocation, re-provision, errors | #60 | #61 | `tests/test_device_provisioning.py` (515 lines, 22 tests) | Self-referential | Partially Implemented | spec_to_code | Medium | Medium | Missing: 409 cap exhaustion test, rate limit test |
| REQ-25 | Test | No regression in existing tests | 430 passed, 1 flaky, 8 skipped | #60 | #61 | PR body claims full regression pass | Not independently verified by this audit | Unverified | — | Low | Medium | — | Trust PR claim; verify in CI |

## Summary

| Status | Count |
|--------|-------|
| Implemented | 21 |
| Partially Implemented | 2 |
| Unverified | 1 |
| Missing | 0 |
| Contradicted | 0 |
| Out of Scope | 1 (design spec mentions updating `tests/test_provisioning.py` — not done) |

## Gap Analysis

| Gap Type | Count | Details |
|----------|-------|---------|
| spec_to_code | 3 | REQ-18 (no cap exhaustion test), REQ-24 (missing test categories), design spec mentions updating `tests/test_provisioning.py` but no changes were made |
| code_to_spec | 2 | Rate limiting keyed per-IP (default slowapi behavior) vs spec says per-user; `client_ip` not passed to `upsert_device_provision()` in endpoint |
| issue_to_code | 0 | — |
| spec_to_issue | 0 | — |
