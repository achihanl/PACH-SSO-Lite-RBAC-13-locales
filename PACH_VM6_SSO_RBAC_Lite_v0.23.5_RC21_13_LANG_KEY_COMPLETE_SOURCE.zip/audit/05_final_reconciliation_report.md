# FIRA Final Reconciliation Report — SSO Device Provisioning

**Audit Date:** 2026-03-11
**Feature:** SSO Device Provisioning — Authenticated In-App XMPP/SIP Credential Delivery
**Issue:** #60 | **PR:** #61 | **Branch:** `sso-device-provisioning`

---

## Final Verdict

### Ready with Follow-up Required

The SSO device provisioning implementation is **substantially complete and well-structured**. All 25 requirements from the acceptance criteria have corresponding code. The sealed box E2E encryption, LDAP credential management, database layer, and API endpoints are functional and covered by 22 integration tests with full roundtrip verification.

**Three medium-severity items require follow-up before production:**

1. **Rate limiting is per-IP, not per-user** (F-01) — contradicts spec's security design
2. **No test for 409 DEVICE_CAP_REACHED** (F-03) — untested error path
3. **Expired provisions count against device cap** (F-09) — cap accumulates without expiry

---

## GitHub Ingestion Mode

**GitHub** (live `gh` CLI) — full issue + PR data fetched, no degradation.

---

## Top 10 Findings

| # | ID | Severity | Finding | Status |
|---|-----|----------|---------|--------|
| 1 | F-01 | Medium | Rate limiting keyed per-IP, spec requires per-user | Contradicted |
| 2 | F-03 | Medium | No API-level test for 409 DEVICE_CAP_REACHED | Partially Implemented |
| 3 | F-09 | Medium | Expired provisions still count against device cap | Partially Implemented |
| 4 | F-02 | Low | Client IP not recorded in provision audit trail | Partially Implemented |
| 5 | F-04 | Low | Design spec says update `tests/test_provisioning.py` — not done | Missing |
| 6 | F-06 | Low | DELETE endpoint has no per-endpoint rate limiting | Partially Implemented |
| 7 | F-07 | Low | `get_uc_credentials` empty string handling is fragile | Implemented |
| 8 | F-10 | Info | Profile resolution differs from spec (improvement) | Implemented (deviated) |
| 9 | F-05 | Info | `appName` captured in model but not stored (by design) | Implemented |
| 10 | F-08 | Info | Sealed payload stored in DB (audit-only, by design) | Implemented |

---

## Largest Mismatches

### Spec vs Code

| Area | Spec Says | Code Does | Impact |
|------|-----------|-----------|--------|
| Rate limit keying | Per-user (`preferred_username`) | Per-IP (`get_client_ip`) | Security design mismatch — shared NAT users throttled together, single user can bypass via IP switching |
| Provision expiry | `DEVICE_PROVISION_TTL_SEC` implies expiry | Cap count ignores `expires_at` | Users accumulate cap slots over time without release |
| Profile resolution | `resolve_template_for_org(org_dn)` | `get_config_template(azblinkProfileId)` from user LDAP | Better approach (user-level linkage), but spec not updated |

### Spec vs Tests

| Area | Spec Says | Tests Cover | Gap |
|------|-----------|-------------|-----|
| Device cap enforcement | "Integration tests: device cap enforcement" | Re-provision bypass only | No 409 exhaustion test |
| `tests/test_provisioning.py` | "Updated: verify azbXmppBindPassword" | Coverage in new file instead | Location deviation, not a coverage gap |

### GitHub vs Code

No gaps. All commits in PR #61 map to code changes. Issue #60 acceptance criteria map to implemented code. No orphaned changes or undocumented code.

---

## Requirement Status Summary

| Status | Count | % |
|--------|-------|---|
| Implemented | 21 | 84% |
| Partially Implemented | 2 | 8% |
| Unverified | 1 | 4% |
| Missing | 0 | 0% |
| Contradicted | 1 | 4% |
| **Total** | **25** | **100%** |

---

## Sceptical Challenge Results

### REQ-18 (Device Cap Enforcement) — Downgraded

**Original status:** Implemented
**Challenge:** No test drives the 409 path. The code at `main.py:4234-4241` is correct by inspection, but an off-by-one or query bug would go undetected.
**Verdict:** Partially Implemented — code exists but lacks test proof.

### REQ-22 (Rate Limiting) — Contradicted

**Original status:** Implemented
**Challenge:** The spec explicitly requires per-user rate limiting; the code uses per-IP.
**Verdict:** Contradicted — the rate limit exists but the keying strategy doesn't match the spec's security requirement.

### REQ-25 (No Regression) — Remains Unverified

**Original status:** Unverified
**Challenge:** PR claims 430 pass. The changes are additive (new optional params with defaults, new functions, new file). No existing function signatures were broken.
**Verdict:** Remains Unverified — plausible but not independently confirmed. CI should verify.

---

## Architecture & Security Assessment

**Positive observations:**
- E2E encryption via libsodium sealed box is a sound design — credentials are only decryptable by the client's ephemeral key
- UPSERT pattern for re-provisioning prevents cap slot leaks and avoids duplicate records
- Password sync (`_set_user_passwords`) is conditional on `azblinkUser` objectClass — backward-compatible with users who don't have the new attribute
- The `provision_tokens` table reuse with `auth_method` discriminator is cleaner than creating a new table
- OIDC auth enforcement via `Depends(require_user)` matches the existing auth pattern

**Concerns addressed by follow-up issues:**
- Rate limiting keying (Follow-up Issue 1)
- Expiry enforcement (Follow-up Issue 4)
- Audit trail completeness (Follow-up Issue 3)

---

## Output Artefacts

| File | Description |
|------|-------------|
| `audit/00_session_context.md` | Audit scope, GitHub ingestion, sources |
| `audit/01_requirement_inventory.md` | 25 atomic requirements from spec + issue |
| `audit/02_traceability_matrix.md` | Full requirement to issue to PR to code to test matrix |
| `audit/03_code_audit_findings.md` | 10 findings (0 Critical, 0 High, 3 Medium, 3 Low, 4 Info) |
| `audit/04_reconciliation_summary.md` | Three-way reconciliation + sceptical challenges |
| `audit/05_final_reconciliation_report.md` | This report |
| `audit/06_follow_up_issue_drafts.md` | 5 follow-up issue drafts |
