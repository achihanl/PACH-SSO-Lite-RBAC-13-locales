# Issue #23: [FEAT] DS-8: Streaming audit export (CSV/JSON download)

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P1
- **Created:** 2026-03-08T13:18:33Z
- **Closed:** 2026-03-09T00:21:18Z

## Body

## Problem being solved

> Audit data is only accessible via the paginated REST API and UI viewer. No bulk export capability exists for compliance review, external analysis, or backup.

---

## Proposed solution

> Add `GET /api/audit/export` endpoint with streaming response:
- Query params: `format` (csv/json), `time_range`, `category`, `limit` (max 10000)
- Use `StreamingResponse` (no full in-memory load for large exports)
- `Content-Disposition: attachment` header for browser download
- Generator-based query in `orgdb.py` for memory-efficient streaming

---

## Component / area

> Audit Manager -- data export, compliance

---

## Acceptance criteria

- [ ] `GET /api/audit/export?format=csv` returns CSV with headers
- [ ] `GET /api/audit/export?format=json` returns JSON array (streaming)
- [ ] Time range filtering (today, 7d, 30d, 90d, all)
- [ ] Category filtering (qr, user, auth, config, admin)
- [ ] Limit cap at 10000 rows per export
- [ ] `Content-Disposition: attachment` header set
- [ ] Streaming response -- no full dataset in memory
- [ ] Integration tests: CSV format, JSON format, filtering, limit enforcement

---

## Out of scope

- Scheduled/recurring exports
- SIEM webhook integration (P2)
- PDF export format

---

## Dependencies / blockers

- None -- uses existing unified audit query

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/main.py` -- new `/api/audit/export` endpoint with `StreamingResponse`
- `src/backend/orgdb.py:L1418-L1685` -- add generator-based query variant of `list_unified_audit()`

**Context:** `list_unified_audit()` at orgdb.py:1418-1685 already implements the UNION ALL query with time range, category, and full-text filtering. The export endpoint reuses this query logic but wraps it in a generator for streaming. FastAPI's `StreamingResponse` supports this pattern.

**Part of Epic:** #15
