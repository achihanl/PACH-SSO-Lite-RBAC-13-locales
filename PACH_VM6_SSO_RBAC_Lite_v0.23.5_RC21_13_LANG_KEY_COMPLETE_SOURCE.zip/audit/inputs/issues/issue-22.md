# Issue #22: [FEAT] DS-7: Admin actions audit table with decorator pattern

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P1
- **Created:** 2026-03-08T13:18:22Z
- **Closed:** 2026-03-08T22:00:22Z

## Body

## Problem being solved

> User lifecycle events and terminations are audited, but admin CRUD operations on orgs, groups, settings, and profiles are not tracked. There is no way to answer "who changed this org's settings?" or "who deleted that group?"

---

## Proposed solution

> New table `admin_action_audit` with decorator/middleware pattern for automatic capture:

**Schema:**
```sql
CREATE TABLE admin_action_audit (
    id SERIAL PRIMARY KEY,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    detail JSONB,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);
```

**Actions:** `create_user`, `update_user`, `delete_group`, `create_org`, `rename_org`, `update_settings`, `update_profile`, etc.

**Decorator pattern:** `@audit_action("create_user")` on endpoints, automatically captures actor from auth context.

**Unified audit integration:** Include in `list_unified_audit()` UNION ALL query.

---

## Component / area

> Audit Manager -- admin action tracking, unified audit log

---

## Acceptance criteria

- [ ] `admin_action_audit` table created with migration
- [ ] `record_admin_action()` method in `orgdb.py`
- [ ] `@audit_action()` decorator for automatic capture on endpoints
- [ ] All admin CRUD endpoints decorated (user, org, group, settings, profile)
- [ ] Events included in unified audit log (`list_unified_audit()` UNION ALL)
- [ ] Integration tests: action recorded, appears in unified log, correct actor

---

## Out of scope

- Audit trail integrity (hash chains -- P3)
- SIEM export of admin actions
- Approval workflows for destructive actions

---

## Dependencies / blockers

- None -- can be implemented independently

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/orgdb.py:L1418-L1685` -- `list_unified_audit()` UNION ALL query, add new table
- `src/backend/orgdb.py` -- add `record_admin_action()` method, table creation
- `src/backend/main.py` -- add `@audit_action()` decorator to admin CRUD endpoints
- `migrations/` -- new migration file for `admin_action_audit` table

**Context:** Audit system uses append-only design with 5 specialized tables. `list_unified_audit()` joins 4 tables via UNION ALL with event type normalization. Adding `admin_action_audit` extends this pattern. Reference ID system uses prefixes (QR-, TRM-, SES-, USR-, AUD-*) -- new prefix needed for admin actions.

**Part of Epic:** #15
