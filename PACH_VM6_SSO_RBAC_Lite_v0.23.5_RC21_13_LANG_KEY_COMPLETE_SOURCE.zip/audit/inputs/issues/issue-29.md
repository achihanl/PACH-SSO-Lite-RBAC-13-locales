# Issue #29: [FEAT] UC endpoint validation -- verify SIP/XMPP services are reachable

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P1
- **Created:** 2026-03-08T13:19:57Z
- **Closed:** 2026-03-09T02:33:22Z

## Body

## Problem being solved

> Profile templates define UC service endpoints (XMPP domain, WebSocket URL, SIP domain, WSS URL) but there is no validation that these endpoints are actually reachable. Admins can configure invalid endpoints that cause provisioning failures at device connection time.

---

## Proposed solution

> Add endpoint validation when profiles are saved or tested:
- `POST /api/config-templates/{id}/validate` -- test reachability of configured endpoints
- Check WebSocket URL connectivity (WS/WSS handshake)
- Check SIP domain DNS resolution
- Check XMPP domain DNS SRV records
- Return per-endpoint pass/fail status with error details
- Optional: periodic background validation with alerting

---

## Component / area

> Provisioning Manager -- profile configuration, service health

---

## Acceptance criteria

- [ ] `POST /api/config-templates/{id}/validate` endpoint created
- [ ] WebSocket URL connectivity check (HTTP upgrade attempt)
- [ ] SIP domain DNS resolution check
- [ ] XMPP domain DNS SRV record check
- [ ] Per-endpoint pass/fail response with error details
- [ ] Validation runs on-demand (not blocking save)
- [ ] Integration tests with valid and invalid endpoints

---

## Out of scope

- Continuous monitoring / health dashboard
- Automatic endpoint failover
- Full SIP/XMPP protocol handshake (just connectivity check)

---

## Dependencies / blockers

- None

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/main.py` -- new validate endpoint for config templates
- `src/backend/orgdb.py` -- template retrieval for validation
- `src/backend/config.py` -- UC endpoint defaults (xmpp_domain, sip_domain, ws_url, wss_url)

**Context:** Profile templates in `orgdb.py` store UC endpoint configuration: `xmpp_domain`, `sip_domain`, `xmpp_ws_url`, `sip_wss_url`. These are written to LDAP during provisioning via `build_uc_attrs()` in `ldap_client.py`. Config startup validates required UC fields exist but doesn't check reachability.

**Part of Epic:** #15
