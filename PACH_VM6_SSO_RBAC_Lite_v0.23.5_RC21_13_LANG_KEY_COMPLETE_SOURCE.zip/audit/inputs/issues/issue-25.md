# Issue #25: [FEAT] Custom LDAP schema -- azblink.schema with dedicated objectClasses

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P1
- **Created:** 2026-03-08T13:19:06Z
- **Closed:** 2026-03-09T02:33:21Z

## Body

## Problem being solved

> The platform uses standard objectClasses (inetOrgPerson, posixAccount, AsteriskPjsip*) which limits attribute semantics and prevents platform-specific attributes. No custom schema exists for AZBlink-specific concepts like provisioning status, profile assignment, or service toggles.

---

## Proposed solution

> Create `azblink.schema` with custom objectClasses:
- `azblinkUser` -- auxiliary, extends inetOrgPerson with provisioning metadata
- `azblinkOrganization` -- auxiliary, extends organizationalUnit with profile assignment
- `azblinkGroup` -- auxiliary, extends groupOfNames with permission metadata

Deploy via OpenLDAP schema include in Docker Compose configuration.

---

## Component / area

> Directory Manager -- LDAP schema, OpenLDAP configuration

---

## Acceptance criteria

- [ ] `azblink.schema` file created with proper OID allocation
- [ ] `azblinkUser` objectClass with provisioning/status attributes
- [ ] `azblinkOrganization` objectClass with profile metadata
- [ ] `azblinkGroup` objectClass with permission attributes
- [ ] Schema loaded into OpenLDAP via Docker Compose volume mount
- [ ] Existing entries can be extended with new objectClasses (backward compatible)
- [ ] `ldap_client.py` updated to use new attributes where appropriate
- [ ] Integration tests pass with schema loaded

---

## Out of scope

- Schema migration tool for existing deployments
- Custom attribute indexing optimization

---

## Dependencies / blockers

- OpenLDAP schema include configuration in Docker Compose

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `deploy/dev/` -- OpenLDAP schema volume mount configuration
- `src/backend/ldap_client.py:L30-L99` -- UC attribute builder, extend with custom objectClasses
- `src/backend/ldap_client.py` -- user/org/group CRUD to include new objectClasses

**Context:** Current LDAP schema uses inetOrgPerson + posixAccount + AsteriskPjsip* on user entries. Organizations are `organizationalUnit`. Groups are `groupOfNames`. Custom schema adds auxiliary objectClasses that coexist with standard ones. Docker Compose mounts LDAP seed data from `deploy/dev/`.

**Part of Epic:** #15
