# Issue #28: [FEAT] SSO block in QR payload -- Phase 2 Authentik OIDC integration

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P1
- **Created:** 2026-03-08T13:19:45Z
- **Closed:** 2026-03-09T02:33:22Z

## Body

## Problem being solved

> The QR payload schema (`azblink.provisioning.v2`) includes an `sso` block for OIDC configuration but it is not populated with real Authentik OIDC values. Mobile clients cannot auto-configure SSO from the QR code.

---

## Proposed solution

> Populate the `sso` block in QR payloads with Authentik OIDC configuration:
```json
{
  "sso": {
    "issuer": "https://authentik.example.com/application/o/azblink-directory/",
    "client_id": "azblink-directory",
    "authorization_endpoint": "...",
    "token_endpoint": "...",
    "scopes": ["openid", "profile", "email"]
  }
}
```

Source values from profile/template configuration or global OIDC settings. Allow SSO block to be optional (UC-only provisioning still works without it).

---

## Component / area

> Provisioning Manager -- QR payload, OIDC integration

---

## Acceptance criteria

- [ ] QR payload `sso` block populated with real Authentik OIDC values
- [ ] SSO values sourced from profile configuration or global settings
- [ ] SSO block is optional -- UC-only provisioning works without it
- [ ] QR signing includes SSO block in HMAC calculation
- [ ] Mobile client can extract OIDC config from scanned QR code
- [ ] Integration tests: QR with SSO, QR without SSO, HMAC validation

---

## Out of scope

- Mobile client OIDC implementation (client-side responsibility)
- Per-user SSO configuration (use org/profile-level)

---

## Dependencies / blockers

- Authentik OIDC integration must be stable (implemented in PR #13, #14)

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/qr_signing.py` -- add SSO block to QR payload builder
- `src/backend/main.py` -- QR generation endpoint, pass OIDC config to payload builder
- `src/backend/orgdb.py` -- profile/template SSO configuration fields
- `src/backend/config.py` -- global OIDC config for SSO block defaults

**Context:** QR payload schema `azblink.provisioning.v2` at `qr_signing.py` includes `uc` and `sso` blocks. The `uc` block is populated with JID, SIP URI, and WebSocket URLs. The `sso` block is defined in the schema but not populated. Profile templates in `orgdb.py` have SSO config fields. Global OIDC settings in `config.py` provide fallback values.

**Part of Epic:** #15
