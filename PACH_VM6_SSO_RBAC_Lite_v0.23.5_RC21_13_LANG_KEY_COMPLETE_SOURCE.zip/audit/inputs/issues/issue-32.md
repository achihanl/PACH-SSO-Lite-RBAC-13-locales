# Issue #32: [DEBT] Dead API keys code path -- unused table and no validation route

- **State:** closed
- **State Reason:** completed
- **Labels:** tech-debt
- **Created:** 2026-03-08T13:20:47Z
- **Closed:** 2026-03-08T21:25:37Z

## Body

## What's wrong with the current implementation?

> The `api_keys` table exists in PostgreSQL with full CRUD operations in `settingsdb.py` (generate, list, revoke with SHA256 hashing and soft-delete). However, no authentication middleware validates these keys against incoming requests. The table and its methods are dead code -- they exist but serve no purpose.

---

## Where is it?

- `src/backend/settingsdb.py` -- `generate_api_key()`, `list_api_keys()`, `revoke_api_key()` methods
- `api_keys` table in PostgreSQL -- SHA256 hash storage, prefix display, soft-delete revocation
- No validation route or middleware anywhere in `main.py` or `oidc_verify.py`

---

## Proposed improvement

**Option A -- Remove dead code:**
- Delete `api_keys` methods from `settingsdb.py`
- Drop `api_keys` table via migration
- Remove any frontend API key management UI

**Option B -- Wire and complete:**
- Add `X-API-Key` header validation middleware
- Add API key auth as alternative to OIDC for service-to-service calls
- Scope API keys to specific permissions (ties into DS-6 RBAC)

Recommend **Option A** unless service-to-service API key auth is planned.

---

## Why now?

> Dead code paths create security audit confusion ("is this access path tested?"), increase maintenance surface, and mislead developers who may assume API key auth works. The RBAC migration (DS-6) will need clear auth paths -- dead code muddies the picture.

---

## Risk of doing this

- **Option A:** Low risk -- code is confirmed unused, no runtime impact
- **Option B:** Medium risk -- new auth path needs thorough security review

---

## Definition of done

- [ ] Decision made: remove or wire (coordinate with DS-6 RBAC scope)
- [ ] If remove: dead code deleted, table dropped, migration created
- [ ] If wire: middleware added, tests written, API key scoping defined
- [ ] No remaining references to unused API key infrastructure

---

## Effort estimate

- [x] S -- hours
- [ ] M -- 1-2 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/settingsdb.py` -- `generate_api_key()`, `list_api_keys()`, `revoke_api_key()` methods
- `src/backend/main.py` -- no existing API key validation (confirm absence)
- `src/backend/oidc_verify.py` -- no API key auth path (confirm absence)
- `migrations/` -- table drop migration if removing

**Context:** `settingsdb.py` implements API key lifecycle with SHA256 hashing and prefix-based display. The `api_keys` table has full CRUD but zero consumers. `oidc_verify.py` handles only OIDC token validation and DEV_AUTH_TOKEN bypass -- no API key check exists anywhere in the auth chain.

**Part of Epic:** #15
