# Issue #30: [FEAT] Suspension events table -- dedicated tracking for suspend/unsuspend lifecycle

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P1
- **Created:** 2026-03-08T13:20:09Z
- **Closed:** 2026-03-08T21:25:38Z

## Body

## Problem being solved

> Suspension events are logged in the generic `user_lifecycle_audit` table but lack dedicated tracking. There is no way to query suspension history, duration metrics, or suspension reasons independently.

---

## Proposed solution

> New `suspension_events` table for dedicated tracking:
```sql
CREATE TABLE suspension_events (
    id SERIAL PRIMARY KEY,
    user_uid TEXT NOT NULL,
    action TEXT NOT NULL CHECK (action IN ('suspend', 'unsuspend')),
    performed_by TEXT NOT NULL,
    reason TEXT,
    suspended_at TIMESTAMPTZ DEFAULT NOW(),
    unsuspended_at TIMESTAMPTZ,
    duration_minutes INTEGER
);
```

Record suspension start/end with duration calculation. Include in unified audit log.

---

## Component / area

> Audit Manager -- suspension lifecycle tracking

---

## Acceptance criteria

- [ ] `suspension_events` table created with migration
- [ ] Suspend action records start event with reason
- [ ] Unsuspend action updates matching record with end time and duration
- [ ] Suspension history queryable per user
- [ ] Events included in unified audit log
- [ ] Integration tests: suspend, unsuspend, duration calculation

---

## Out of scope

- Suspension scheduling (auto-suspend/unsuspend at future dates)
- Suspension approval workflow

---

## Dependencies / blockers

- None -- extends existing suspend/unsuspend flow

---

## Effort estimate

- [x] S -- hours
- [ ] M -- 1-2 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/orgdb.py` -- new table, record_suspension(), update_unsuspension()
- `src/backend/orgdb.py:L1418-L1685` -- extend `list_unified_audit()` UNION ALL
- `src/backend/main.py` -- wire suspension event recording into `api_user_suspend` and `api_user_unsuspend`
- `migrations/` -- new migration file

**Context:** Suspend/unsuspend at `main.py` via `api_user_suspend` and `api_user_unsuspend` endpoints. Currently records in `user_lifecycle_audit` via `record_lifecycle_event()`. The new dedicated table adds duration tracking and queryable suspension history. Existing `test_suspend.py` has 4 tests to extend.

**Part of Epic:** #15
