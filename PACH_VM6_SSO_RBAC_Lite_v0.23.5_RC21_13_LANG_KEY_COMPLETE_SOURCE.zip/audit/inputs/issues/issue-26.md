# Issue #26: [FEAT] LDAP overlays -- ppolicy, memberof, refint for directory integrity

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P1
- **Created:** 2026-03-08T13:19:18Z
- **Closed:** 2026-03-09T02:33:22Z

## Body

## Problem being solved

> OpenLDAP runs without overlays. No password policy enforcement (ppolicy), no automatic group membership tracking (memberof), and no referential integrity enforcement (refint) when users are deleted or moved.

---

## Proposed solution

> Enable three OpenLDAP overlays in the Docker Compose development stack:
- **ppolicy** -- Password complexity, history, expiration, lockout (server-side enforcement)
- **memberof** -- Automatic `memberOf` attribute on user entries when added to groups
- **refint** -- Referential integrity: auto-update group memberships when user DNs change

Configure via `slapd.conf` or `cn=config` in Docker Compose.

---

## Component / area

> Directory Manager -- LDAP server configuration, OpenLDAP

---

## Acceptance criteria

- [ ] ppolicy overlay enabled with configurable password policy
- [ ] memberof overlay enabled -- users gain `memberOf` attribute automatically
- [ ] refint overlay enabled -- group memberships update on user DN changes
- [ ] Overlays configured in Docker Compose dev stack
- [ ] `ldap_client.py` updated to leverage `memberOf` for efficient group lookups
- [ ] Existing tests pass with overlays enabled
- [ ] Documentation for overlay configuration in production deployments

---

## Out of scope

- Password policy UI management (use ppolicy defaults initially)
- Custom overlay development

---

## Dependencies / blockers

- OpenLDAP configuration access in Docker Compose

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `deploy/dev/docker-compose.yml` -- OpenLDAP overlay configuration
- `deploy/dev/` -- overlay config files (slapd.conf or LDIF for cn=config)
- `src/backend/ldap_client.py` -- leverage `memberOf` for group membership queries

**Context:** OpenLDAP runs as a Docker container in `deploy/dev/docker-compose.yml`. Currently no overlays are configured. `ldap_client.py` manually queries group membership by searching `groupOfNames` entries -- `memberof` overlay would allow direct `memberOf` attribute lookup on user entries.

**Part of Epic:** #15
