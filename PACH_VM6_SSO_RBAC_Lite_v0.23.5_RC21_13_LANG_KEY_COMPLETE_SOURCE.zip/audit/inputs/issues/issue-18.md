# Issue #18: [FEAT] DS-3: UC Server client for SIP/XMPP session termination

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P0, security
- **Created:** 2026-03-08T13:17:22Z
- **Closed:** 2026-03-08T21:25:38Z

## Body

## Problem being solved

> User termination revokes LDAP credentials and Authentik sessions/tokens but cannot kill active SIP registrations or XMPP sessions. Terminated users remain connected until their existing sessions naturally expire. There is a TODO placeholder at `main.py:1354`.

---

## Proposed solution

> Create a `uc_client.py` module with abstract interface for UC server session management. Implementation depends on UC Server APIs (Asterisk ARI for SIP, ejabberd/Prosody admin API for XMPP). Graceful degradation: if UC Server is unreachable, log warning but don't block the termination flow.

**Backend changes:**
- New file: `src/backend/uc_client.py` -- `terminate_sip_sessions(uid)`, `terminate_xmpp_sessions(uid)`, `check_session_status(uid)`
- `main.py:1354` -- Replace TODO with `uc_client.terminate_sessions(uid)`
- `config.py` -- Add `UC_SIP_API_URL`, `UC_XMPP_API_URL`, `UC_API_TOKEN`

**Interface design:**
```python
class UCClient:
    async def terminate_sip_sessions(self, uid: str) -> TerminationResult
    async def terminate_xmpp_sessions(self, uid: str) -> TerminationResult
    async def check_session_status(self, uid: str) -> SessionStatus
    async def terminate_all(self, uid: str) -> list[TerminationResult]
```

---

## Component / area

> Provisioning Manager -- UC service integration, session lifecycle

---

## Acceptance criteria

- [ ] `uc_client.py` module created with defined interface
- [ ] SIP session termination via Asterisk ARI (or configurable endpoint)
- [ ] XMPP session termination via ejabberd/Prosody admin API (or configurable endpoint)
- [ ] Graceful degradation -- UC Server unreachable logs warning, doesn't block termination
- [ ] `terminate_all()` called during user termination flow
- [ ] Config vars for UC Server URLs and auth token
- [ ] Unit tests with mocked UC Server responses
- [ ] Integration test verifying termination flow includes UC session cleanup

---

## Out of scope

- UC Server provisioning (separate from session management)
- Device online/offline status polling (deferred item D3)
- Device refresh/revoke actions (deferred item D4)

---

## Dependencies / blockers

- **Requires UC Server API spec** -- Asterisk ARI and XMPP admin API endpoints must be known
- Can stub with configurable HTTP endpoints until specific UC Server is deployed

---

## Effort estimate

- [ ] M -- 1-2 days
- [x] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/uc_client.py` (NEW) -- UC Server client module
- `src/backend/main.py:L1354` -- TODO placeholder for UC session termination in `api_user_terminate`
- `src/backend/config.py:L1-L80` -- add UC Server API configuration variables
- `src/backend/authentik_client.py:L1-L150` -- reference pattern for external API client design

**Context:** User termination at `main.py:1354` currently revokes LDAP + Authentik but has a TODO for UC session termination. `authentik_client.py` provides the pattern for external API clients with async HTTP, graceful degradation, and fire-and-forget semantics. The new `uc_client.py` should follow the same pattern.

**Part of Epic:** #15
