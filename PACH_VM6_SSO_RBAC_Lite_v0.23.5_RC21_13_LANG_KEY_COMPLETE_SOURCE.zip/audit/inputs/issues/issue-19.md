# Issue #19: [FEAT] DS-4: Self-service /api/me endpoints

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P1
- **Created:** 2026-03-08T13:17:36Z
- **Closed:** 2026-03-08T22:00:22Z

## Body

## Problem being solved

> Users cannot view or edit their own profile. All changes require admin action. No self-service endpoints exist for the authenticated user.

---

## Proposed solution

> Add a `/api/me` route group for authenticated (non-admin) users:
- `GET /api/me` -- Return authenticated user's profile (OIDC claims + LDAP lookup)
- `PATCH /api/me` -- Update allowed fields (displayName, mail, mobile)
- `POST /api/me/password` -- Change own password (requires current password verification)
- `GET /api/me/devices` -- List user's provisioned devices
- `GET /api/me/qrcodes` -- List user's QR codes

**Auth:** `require_user()` dependency (any authenticated user, not just admin)

---

## Component / area

> Directory Manager -- user self-service, authentication

---

## Acceptance criteria

- [ ] `GET /api/me` returns profile from OIDC claims + LDAP lookup
- [ ] `PATCH /api/me` updates only allowed fields (displayName, mail, mobile)
- [ ] `POST /api/me/password` verifies current password before setting new
- [ ] `GET /api/me/devices` returns user's provisioned devices
- [ ] `GET /api/me/qrcodes` returns user's QR codes
- [ ] `require_user()` dependency created (extracts uid from OIDC claims, non-admin)
- [ ] 403 returned if user tries to modify restricted fields
- [ ] Integration tests for each endpoint

---

## Out of scope

- Self-service enrollment (P2)
- User profile photo upload
- Self-service group membership changes

---

## Dependencies / blockers

- OIDC sub <-> LDAP uid mapping must be resolved (TODO at `main.py:232`)

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/main.py` -- new `/api/me` route group (5 endpoints)
- `src/backend/oidc_verify.py` -- add `require_user()` dependency (non-admin auth)
- `src/backend/ldap_client.py` -- user self-lookup by uid
- `src/backend/orgdb.py` -- device/QR listing filtered by user uid

**Context:** All current endpoints use `require_admin()` which checks IT-Admins group membership. Self-service needs a lighter `require_user()` that validates OIDC token but doesn't require admin group. OIDC sub claim may not match LDAP uid (TODO at main.py:232) -- this mapping must be resolved.

**Part of Epic:** #15
