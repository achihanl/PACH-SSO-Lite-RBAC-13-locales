# Issue #16: [FEAT] DS-1: Account soft-lock on authentication failures

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P0, security
- **Created:** 2026-03-08T13:16:47Z
- **Closed:** 2026-03-08T21:25:38Z

## Body

## Problem being solved

> Auth failures are recorded in `auth_failure_audit` but no lockout logic exists. An attacker can brute-force credentials indefinitely. The `maxLoginAttempts` setting exists in `settingsdb.py` but is not enforced.

---

## Proposed solution

> After `maxLoginAttempts` (default: 5) failures within a sliding window (15 min), lock the account for a configurable duration (default: 30 min) or until admin manual unlock. Add lock status check before token validation, admin unlock endpoint, and frontend lock status indicator.

**Backend changes:**
- `oidc_verify.py` -- Check lock status before token validation
- `orgdb.py` -- `check_account_locked(username)`, `lock_account(username, duration)`, `unlock_account(username)`
- `main.py` -- `POST /api/users/{uid}/unlock`, `GET /api/users/{uid}/lock-status`
- `settingsdb.py` -- Wire `maxLoginAttempts`, add `lockoutDurationMinutes`

**Frontend changes:**
- Lock status indicator on UserDetailPanel
- Unlock button for admins

---

## Component / area

> Access Policy Manager -- authentication, security settings

---

## Acceptance criteria

- [ ] Account locks after N failed attempts within sliding window
- [ ] `maxLoginAttempts` is read from `settingsdb.security` (not hardcoded)
- [ ] Locked accounts receive 403 with clear error message and retry-after
- [ ] Admin can unlock via `POST /api/users/{uid}/unlock`
- [ ] Lock status visible on user detail panel with unlock button
- [ ] Integration tests covering: lock trigger, lock expiry, manual unlock, concurrent failures

---

## Out of scope

- MFA enforcement (separate issue)
- IP-based blocking (DS-2)
- Progressive delay / CAPTCHA on failures

---

## Dependencies / blockers

- `auth_failure_audit` table exists (no schema change needed for tracking)
- DS-5 depends on this (wires `maxLoginAttempts` setting)

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/oidc_verify.py:L1-L105` -- token validation, add lock check before OIDC verification
- `src/backend/orgdb.py:L1-L2400` -- auth failure recording, add lock/unlock methods
- `src/backend/main.py:L1-L3100` -- add unlock/lock-status API endpoints
- `src/backend/settingsdb.py:L1-L120` -- wire maxLoginAttempts, add lockoutDurationMinutes
- `src/frontend/src/components/features/user-management/UserDetailPanel.tsx` -- lock status indicator + unlock button

**Context:** `auth_failure_audit` table already tracks failures with `username`, `client_ip`, `failure_reason`. `settingsdb.py` defines `maxLoginAttempts: 5` as a stub. `oidc_verify.py` handles token validation via `verify_oidc_token()` dependency -- lock check should be inserted here.

**Part of Epic:** #15
