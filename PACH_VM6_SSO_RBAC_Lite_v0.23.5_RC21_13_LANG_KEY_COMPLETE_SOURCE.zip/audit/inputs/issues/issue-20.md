# Issue #20: [FEAT] DS-5: Enforce security settings (wire stubs to logic)

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, security, P1
- **Created:** 2026-03-08T13:17:51Z
- **Closed:** 2026-03-08T22:00:22Z

## Body

## Problem being solved

> The Settings UI allows admins to modify security values (`sessionTimeoutMinutes`, `maxLoginAttempts`, `requireMfa`, `ipAllowlist`, `auditApiRequests`) but no backend logic enforces them. This is misleading UX -- users can change values that have no effect.

---

## Proposed solution

> Wire each setting to its enforcement point:
- `sessionTimeoutMinutes` -> Frontend token expiry check in `auth-store.ts`
- `maxLoginAttempts` -> Backend lock logic (requires DS-1)
- `requireMfa` -> Authentik flow configuration (or block non-MFA tokens)
- `ipAllowlist` -> IP blocking middleware (requires DS-2)
- `auditApiRequests` -> Request logging middleware

Add `GET /api/settings/security` public endpoint for frontend to fetch server-enforced values. Cache settings in memory with 60s TTL.

---

## Component / area

> Access Policy Manager -- security settings, middleware, frontend state

---

## Acceptance criteria

- [ ] `sessionTimeoutMinutes` enforced in frontend token expiry
- [ ] `maxLoginAttempts` reads from settings (not hardcoded) via DS-1 integration
- [ ] `ipAllowlist` enforcement active via DS-2 integration
- [ ] `auditApiRequests` toggles request logging middleware
- [ ] `GET /api/settings/security` returns current values (cacheable)
- [ ] Settings cached server-side with 60s TTL (no DB hit per request)
- [ ] Changing a setting takes effect within 60s
- [ ] Integration tests verifying each setting enforcement

---

## Out of scope

- `requireMfa` full enforcement (depends on Authentik MFA config, can be stubbed)
- New security settings beyond the existing 5

---

## Dependencies / blockers

- **DS-1** (account soft-lock) -- provides `maxLoginAttempts` enforcement point
- **DS-2** (IP blocking) -- provides `ipAllowlist` enforcement point

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/settingsdb.py:L1-L120` -- add `get_security_settings()` with caching
- `src/backend/main.py` -- new settings fetch endpoint; wire settings to middleware
- `src/backend/oidc_verify.py` -- read `maxLoginAttempts` from settings (via DS-1)
- `src/backend/rate_limit.py` -- read `ipAllowlist` from settings (via DS-2)
- `src/frontend/src/stores/auth-store.ts` -- fetch `sessionTimeoutMinutes`, enforce locally

**Context:** `settingsdb.py` defines `SETTINGS_DEFAULTS` with 5 security settings. All are stored in `app_settings` table with section/key/value pattern. `get_all_settings()` merges DB values with defaults. No enforcement code exists -- each setting needs a wire to its enforcement middleware.

**Part of Epic:** #15
