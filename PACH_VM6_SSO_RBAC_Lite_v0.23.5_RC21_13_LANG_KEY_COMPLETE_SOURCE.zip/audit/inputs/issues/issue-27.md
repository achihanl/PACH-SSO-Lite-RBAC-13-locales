# Issue #27: [FEAT] Refresh token rotation for seamless session continuity

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, security, P1
- **Created:** 2026-03-08T13:19:32Z
- **Closed:** 2026-03-09T02:33:22Z

## Body

## Problem being solved

> When the OIDC access token expires, users must perform a full re-authentication (redirect to Authentik login). No refresh token rotation exists. This creates poor UX for long admin sessions.

---

## Proposed solution

> Implement OIDC refresh token flow:
- Request `offline_access` scope during initial OIDC authorization
- Store refresh token securely (httpOnly cookie or encrypted storage)
- Add `POST /api/auth/refresh` endpoint to exchange refresh token for new access token
- Frontend: intercept 401 responses, attempt silent refresh before triggering login redirect
- Rotate refresh tokens on each use (one-time-use refresh tokens)

---

## Component / area

> Access Policy Manager -- OIDC token lifecycle, session management

---

## Acceptance criteria

- [ ] `offline_access` scope requested during OIDC authorization
- [ ] Refresh token stored securely (not in localStorage)
- [ ] `POST /api/auth/refresh` exchanges refresh token for new access token
- [ ] Refresh tokens are one-time-use (rotated on each exchange)
- [ ] Frontend silently refreshes on 401 before triggering login redirect
- [ ] Expired refresh tokens trigger full re-auth gracefully
- [ ] Integration tests: refresh flow, rotation, expiry

---

## Out of scope

- Sliding session windows
- Multi-device session management

---

## Dependencies / blockers

- Authentik OAuth2 provider must support refresh tokens (check `offline_access` scope config)

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/frontend/src/lib/oidc.ts` -- add `offline_access` scope, handle refresh token
- `src/frontend/src/lib/api-client.ts` -- 401 interceptor for silent refresh
- `src/frontend/src/stores/auth-store.ts` -- refresh token storage and management
- `src/backend/main.py` -- `POST /api/auth/refresh` endpoint
- `src/backend/oidc_verify.py` -- refresh token validation
- `deploy/dev/authentik-seed/seed_authentik.py` -- enable `offline_access` scope on OAuth2 provider

**Context:** Frontend OIDC uses PKCE S256 flow via `oidc.ts`. Auth state in Zustand store `auth-store.ts` with localStorage token persistence. API client at `api-client.ts` has 401 handler that shows session expired modal -- this should attempt refresh first. Authentik seed script configures the OAuth2 provider.

**Part of Epic:** #15
