# Issue #21: [FEAT] DS-6: RBAC migration -- require_permission adoption across endpoints

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, security, P1
- **Created:** 2026-03-08T13:18:07Z
- **Closed:** 2026-03-09T00:21:18Z

## Body

## Problem being solved

> 65+ admin endpoints use coarse `require_admin()` (IT-Admins group check). Fine-grained `require_permission()` infrastructure exists but is only adopted on ~7 group management endpoints. This prevents delegating specific capabilities to non-admin roles.

---

## Proposed solution

> Map each endpoint to a granular permission and migrate from `require_admin()` to `require_permission()`:

| Permission | Endpoints |
|---|---|
| `user_management` | User CRUD, password reset, move, import |
| `org_management` (NEW) | Org CRUD, rename, delete |
| `qr_provisioning` | QR generation, token management, preview links |
| `audit_log_access` | Audit queries, export |
| `system_configuration` | Settings, bootstrap, profiles |

**Incremental migration:** Keep `require_admin()` as fallback during transition. Add `org_management` to `VALID_PERMISSIONS` set. Resolve OIDC sub <-> LDAP uid mapping (TODO at main.py:232).

---

## Component / area

> Access Policy Manager -- authorization, RBAC

---

## Acceptance criteria

- [ ] `org_management` permission added to `VALID_PERMISSIONS`
- [ ] All user management endpoints use `require_permission("user_management")`
- [ ] All org management endpoints use `require_permission("org_management")`
- [ ] All QR/provisioning endpoints use `require_permission("qr_provisioning")`
- [ ] All audit endpoints use `require_permission("audit_log_access")`
- [ ] Settings/bootstrap endpoints use `require_permission("system_configuration")`
- [ ] OIDC sub <-> LDAP uid mapping resolved
- [ ] Backward compatibility: existing IT-Admins users retain full access
- [ ] Integration tests verifying permission enforcement per endpoint group

---

## Out of scope

- Custom role builder UI
- Permission inheritance / role hierarchies
- API key permissions (separate tech debt item)

---

## Dependencies / blockers

- Group-based permissions infrastructure exists (3 bitfield flags)
- OIDC sub <-> LDAP uid mapping TODO at `main.py:232`

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/main.py:L226-L249` -- `require_permission()` definition, extend to all endpoint groups
- `src/backend/main.py` -- migrate 65+ endpoints from `require_admin` -> `require_permission`
- `src/backend/orgdb.py` -- add `org_management` to permission schema, `get_user_permissions()` update

**Context:** `require_permission()` at main.py:226-249 checks group-based bitfield permissions. `VALID_PERMISSIONS` set contains `user_management`, `qr_provisioning`, `audit_log_access`, `system_configuration`. Only ~7 group management endpoints use it; all others use `require_admin()` which checks IT-Admins membership.

**Part of Epic:** #15
