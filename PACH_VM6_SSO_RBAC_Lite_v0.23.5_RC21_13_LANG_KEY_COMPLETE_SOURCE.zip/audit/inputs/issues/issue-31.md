# Issue #31: [BUG] Security settings stubs -- misleading UX allows changing non-functional values

- **State:** closed
- **State Reason:** completed
- **Labels:** bug, P1, triage
- **Created:** 2026-03-08T13:20:29Z
- **Closed:** 2026-03-08T21:25:37Z

## Body

## What broke?

> The Settings UI displays 5 security settings that admins can modify, but none of them are enforced by backend logic. Users believe they are configuring security controls when the values have no effect.

---

## Environment

- **Component / area:** Access Policy Manager -- settings UI, settingsdb.py
- **Environment:** All environments (dev, staging, production)
- **Version / branch:** main (since initial settings implementation)

---

## Steps to reproduce

1. Navigate to Settings -> Security tab
2. Change `maxLoginAttempts` from 5 to 3
3. Save settings (success toast appears)
4. Attempt 4+ failed logins
5. **Expected:** Account locks after 3 failures
6. **Actual:** No lockout -- setting has no effect

Applies to all 5 security settings:
- `sessionTimeoutMinutes` -- no frontend enforcement
- `maxLoginAttempts` -- no backend enforcement
- `requireMfa` -- no enforcement
- `ipAllowlist` -- no enforcement
- `auditApiRequests` -- no enforcement

---

## Evidence

```python
# settingsdb.py -- DEFINED but NOT enforced anywhere
"security": {
    "sessionTimeoutMinutes": 60,    # NOT enforced
    "maxLoginAttempts": 5,          # NOT enforced
    "requireMfa": False,            # NOT enforced
    "ipAllowlist": False,           # NOT enforced
    "auditApiRequests": True,       # NOT enforced
}
```

No code anywhere reads these values for enforcement. Values persist in `app_settings` table but are never queried by auth/rate-limit middleware.

---

## Impact

- [x] Medium -- partial breakage, edge case

The settings are non-functional rather than broken. Risk: admins believe security is configured when it is not.

---

## Suspected cause (optional)

> Settings infrastructure (read/write/persist) was built before the enforcement logic. The enforcement was deferred but the UI shipped, creating a gap between UI capability and backend enforcement.

**Fix options:**
1. **Best:** Wire enforcement logic (DS-5 addresses this)
2. **Interim:** Add "Not yet enforced" warning labels on each setting in the UI
3. **Minimal:** Disable/hide security settings section until enforcement ships

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/settingsdb.py:L1-L120` -- settings defaults and storage (no enforcement)
- `src/frontend/src/routes/configuration/` -- settings UI needs warning labels or disabling
- Related: DS-5 (#20) provides the full enforcement fix

**Context:** `settingsdb.py` defines `SETTINGS_DEFAULTS` with 5 security settings stored in `app_settings` table. `get_all_settings()` merges DB with defaults. `update_settings()` persists changes. No middleware or auth code reads these values. DS-5 is the comprehensive fix; this bug tracks the interim UX mitigation.

**Part of Epic:** #15
