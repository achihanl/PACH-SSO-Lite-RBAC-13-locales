# Issue #17: [FEAT] DS-2: IP-based blocking for repeated auth violations

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P0, security
- **Created:** 2026-03-08T13:17:04Z
- **Closed:** 2026-03-08T21:25:38Z

## Body

## Problem being solved

> Rate limiting is per-endpoint, not per-IP for auth failures. A distributed attack from one IP hitting different endpoints bypasses current rate limits. No IP-level blocking exists despite `auth_failure_audit` recording `client_ip`.

---

## Proposed solution

> Track auth failures per IP using Redis sorted sets for fast lookup. After N failures from the same IP within a configurable window, block the IP for a configurable duration. Add admin endpoints for viewing blocked IPs and manual unblock.

**Backend changes:**
- `rate_limit.py` -- Add IP block check middleware before existing rate limiter
- `orgdb.py` -- `count_failures_by_ip(ip, window_minutes)`, `block_ip(ip, duration)`
- `main.py` -- Admin IP management endpoints: `GET /api/security/blocked-ips`, `DELETE /api/security/blocked-ips/{ip}`
- `settingsdb.py` -- Wire `ipAllowlist` setting

**Redis data model:**
- `blocked_ips:{ip}` -- key with TTL for block duration
- `ip_failures:{ip}` -- sorted set with timestamp scores for sliding window

---

## Component / area

> Access Policy Manager -- rate limiting, IP blocking, Redis

---

## Acceptance criteria

- [ ] IP blocked after N auth failures within sliding window (configurable)
- [ ] Blocked IPs receive 403 with retry-after header
- [ ] Redis sorted set used for O(1) block check and sliding window tracking
- [ ] Admin can list blocked IPs via API
- [ ] Admin can unblock IPs via API
- [ ] `ipAllowlist` from settings bypasses blocking for trusted IPs
- [ ] X-Forwarded-For parsing handles proxy chains correctly
- [ ] Integration tests: block trigger, block expiry, manual unblock, allowlisted IP bypass

---

## Out of scope

- GeoIP-based blocking
- CAPTCHA challenge before block
- Distributed IP blocking across multiple backend instances (Redis handles this)

---

## Dependencies / blockers

- Redis already available (used by rate limiter)
- `auth_failure_audit.client_ip` already recorded
- DS-5 depends on this (wires `ipAllowlist` setting)

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/rate_limit.py:L1-L63` -- add IP block check middleware, extend `get_client_ip()`
- `src/backend/orgdb.py` -- add `count_failures_by_ip()`, `block_ip()`, `unblock_ip()`, `list_blocked_ips()`
- `src/backend/main.py` -- add admin IP management endpoints
- `src/backend/settingsdb.py` -- wire `ipAllowlist` enforcement
- `src/backend/config.py` -- Redis URL already configured, add IP blocking thresholds

**Context:** `rate_limit.py` uses slowapi with Redis backend and `get_client_ip()` for X-Forwarded-For parsing. Four rate limit tiers exist (bootstrap 5/hr, user creation 20/min, QR 10/min, default 100/min). IP blocking extends this with per-IP tracking across all auth endpoints. Redis is already the storage backend.

**Part of Epic:** #15
