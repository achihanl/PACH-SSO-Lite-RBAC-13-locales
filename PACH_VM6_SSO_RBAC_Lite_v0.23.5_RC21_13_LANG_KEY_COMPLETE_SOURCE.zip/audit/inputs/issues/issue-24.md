# Issue #24: [FEAT] User export -- CSV/JSON download of directory data

- **State:** closed
- **State Reason:** completed
- **Labels:** enhancement, P1
- **Created:** 2026-03-08T13:18:53Z
- **Closed:** 2026-03-09T00:21:18Z

## Body

## Problem being solved

> No bulk user export capability exists. Admins cannot extract directory data for reporting, migration, or compliance purposes. CSV import exists but there is no corresponding export.

---

## Proposed solution

> Add `GET /api/users/export` endpoint:
- Query params: `format` (csv/json), `org` (filter by org), `status` (filter by account status), `fields` (select columns)
- CSV: standard headers matching import format for round-trip compatibility
- JSON: array of user objects with selected fields
- Use streaming response for large directories
- Respect RBAC: `require_permission("user_management")`

---

## Component / area

> Directory Manager -- user data export

---

## Acceptance criteria

- [ ] `GET /api/users/export?format=csv` returns CSV with headers
- [ ] `GET /api/users/export?format=json` returns JSON array
- [ ] Optional org filter narrows export to specific organization
- [ ] Optional status filter (active/suspended/terminated/pending)
- [ ] CSV format compatible with import (round-trip capable)
- [ ] Streaming response for large exports
- [ ] `Content-Disposition: attachment` header
- [ ] Integration tests: CSV format, JSON format, filtering

---

## Out of scope

- LDIF export (separate consideration)
- User photo/avatar export
- Scheduled/automated exports

---

## Dependencies / blockers

- None

---

## Effort estimate

- [x] M -- 1-2 days
- [ ] L -- 3-5 days

---

## Codebase Context

_Mapped on 2026-03-08 against `azb-azblink-directory-and-identity-stack`_

**Files likely to change:**
- `src/backend/main.py` -- new `/api/users/export` endpoint
- `src/backend/ldap_client.py` -- bulk user query with field selection
- `src/backend/main.py` (`api_user_import_csv`) -- reference for CSV field mapping (round-trip compat)

**Context:** CSV import at `api_user_import_csv` defines the field mapping. Export should mirror this format. `ldap_client.py` has `list_users()` which supports search/filter/sort/paginate -- export extends this with streaming and format conversion.

**Part of Epic:** #15
