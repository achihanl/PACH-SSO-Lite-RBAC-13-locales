# FIRA Requirement Inventory — SSO Device Provisioning

Extracted from Issue #60 acceptance criteria + design spec `docs/superpowers/specs/2026-03-11-sso-device-provisioning-design.md`.

## Requirements

### Infrastructure (REQ-01 to REQ-06)

| ID | Area | Requirement | Acceptance Criteria |
|----|------|-------------|---------------------|
| REQ-01 | LDAP Schema | New LDAP attribute `azbXmppBindPassword` added to `azblink.schema` (OID `AZBlinkAttr:7`, in `azblinkUser` MAY list) | Attribute defined with caseExactMatch, SINGLE-VALUE, Directory String syntax |
| REQ-02 | DB Migration | Migration `022_device_provisioning.sql` adds `auth_method`, `sealed_payload`, `public_key_hash` columns + indexes to `provision_tokens` | 3 columns + 2 indexes + rollback script |
| REQ-03 | DB Migration | Migration adds `max_devices_per_user` to `config_templates` | Default 5, integer, NOT NULL |
| REQ-04 | Config | `DEVICE_PROVISION_TTL_SEC` config (default 30 days = 2592000) | Environment variable with int parsing |
| REQ-05 | Config | `DEVICE_PROVISION_MAX_DEFAULT` config (default 5) | Environment variable with int parsing |
| REQ-06 | Deps | `PyNaCl>=1.5` added to requirements.txt | Import must succeed |

### LDAP Layer (REQ-07 to REQ-12)

| ID | Area | Requirement | Acceptance Criteria |
|----|------|-------------|---------------------|
| REQ-07 | LDAP | `build_uc_attrs()` accepts `xmpp_password` parameter and sets `azbXmppBindPassword` on XMPP-enabled users | Parameter added, attribute set when xmpp_enabled=True AND xmpp_password provided |
| REQ-08 | LDAP | `build_uc_attrs()` accepts `profile_id` parameter and sets `azblinkProfileId` | Attribute set, azblinkUser objectClass added |
| REQ-09 | LDAP | User creation flow passes plaintext password through to LDAP as `azbXmppBindPassword` | `main.py` passes `req.password` as `xmpp_password` |
| REQ-10 | LDAP | `_set_user_passwords()` updates both `userPassword` (SSHA) and `azbXmppBindPassword` (plaintext) atomically | Single LDAP MODIFY, conditional on azblinkUser objectClass |
| REQ-11 | LDAP | `reset_user_password()` uses `_set_user_passwords()` to keep passwords in sync | Delegates to helper |
| REQ-12 | LDAP | `get_uc_credentials(uid)` reads `azbXmppBindPassword` + `AstAuthPassword` from LDAP | Returns dict with xmpp_password, sip_password; None if user not found |

### DB Layer (REQ-13 to REQ-15)

| ID | Area | Requirement | Acceptance Criteria |
|----|------|-------------|---------------------|
| REQ-13 | DB | `count_active_device_provisions(uid, exclude_device_id)` counts SSO provisions (excludes QR tokens) | Filters auth_method='sso_token', status='active', optional exclude |
| REQ-14 | DB | `upsert_device_provision()` implements UPSERT keyed on `(uid, device_id, auth_method='sso_token')` | Update-first, insert on rowcount=0 pattern |
| REQ-15 | DB | `revoke_device_provision(uid, device_id)` sets status to `'revoked'` (user can only revoke own) | Scoped to uid + device_id + auth_method='sso_token' + status='active' |

### API Endpoints (REQ-16 to REQ-23)

| ID | Area | Requirement | Acceptance Criteria |
|----|------|-------------|---------------------|
| REQ-16 | API | `POST /api/provision/device` endpoint with OIDC auth | Bearer token required, 401 without |
| REQ-17 | API | Public key validation (32-byte Curve25519, standard base64) | base64 decode + length check + nacl.public.PublicKey validation, 422 on failure |
| REQ-18 | API | Device cap check with re-provision awareness | Excludes current deviceId from count, 409 DEVICE_CAP_REACHED when exceeded |
| REQ-19 | API | Sealed box encryption of credentials | crypto_box_seal via nacl.public.SealedBox, base64 response |
| REQ-20 | API | Response includes sealed credentials + unencrypted service endpoints + provisioned flags + expiresAt | JSON response with ok, uid, sealedCredentials, endpoints, provisioned, expiresAt |
| REQ-21 | API | `DELETE /api/provision/device/{device_id}` with OIDC auth, user-scoped revocation | 200 on success, 404 for not-found/other-user, 401 unauthenticated |
| REQ-22 | API | Rate limiting: `LIMIT_DEVICE_PROVISION = "5/minute"` | @limiter.limit decorator on POST endpoint |
| REQ-23 | API | Re-provisioning same `deviceId` updates existing row (not a new cap slot) | UPSERT behavior, verified by cap test |

### Testing (REQ-24 to REQ-25)

| ID | Area | Requirement | Acceptance Criteria |
|----|------|-------------|---------------------|
| REQ-24 | Test | Integration tests: auth, device cap enforcement, sealed box roundtrip decryption, revocation, re-provision bypass, error cases | Dedicated test file with all categories |
| REQ-25 | Test | All existing tests continue to pass (no regression) | PR claims 430 passed, 1 pre-existing flaky, 8 skipped |

## Out of Scope (per issue #60)

- XMPP server reconfiguration to read `azbXmppBindPassword` directly
- Password rotation API for `azbXmppBindPassword`
- Admin UI for viewing/managing SSO-provisioned devices
- Per-device credential isolation
- Frontend changes

## Requirement Count

- Total: 25 requirements
- Infrastructure: 6
- LDAP Layer: 6
- DB Layer: 3
- API Endpoints: 8
- Testing: 2
