# Changelog

All notable changes to AZBlink Directory are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/).

## [0.20.0] - 2026-11-01

### Bug Fixes

- **authentik-seed:** Set tenant avatars to initials only (#380)
- **release:** Give git-cliff the new tag so the changelog heading is versioned (#378)
- **auth:** Revoke only the suspended user's Authentik sessions (#381)
- **e2e:** Skip the SSO debugger smoke unless :5173 serves the debugger (#379)
- **auth:** Cut suspended and terminated users off from SSO (#383)
- **users:** Refuse unsuspend of a terminated user (#386)
- **authentik:** 15-minute admin access token, seed converges validity (#391)
- **ui:** Open tabs share one session across token refreshes (#394)
- **auth:** Service clients refuse human app passwords (B2) (#390)
- **deploy:** Browser source from CF-Connecting-IP, trusted only from cloudflared (ARD-021) (#396)
- **deploy:** Real Authentik token for the API; demo purge only marked entries (#400)
- **orgs:** Refuse to delete a non-empty org instead of reporting ok (#398)
- **seed:** Policied applications use policy_engine_mode all (B2 hardening) (#397)
- **auth:** API trusts exactly the edge and Traefik; expired tokens never auto-block (#401)
- **users:** Terminated users stay terminated; exact Authentik user lookup (#403)
- **authentik:** Seed waits for worker objects and keeps the sync secret (#402)
- **deploy:** Build every image on the default network (compose v5) (#404)
- **auth:** Contain account takeover, admin-only activity socket, UI security headers (#407)
- **ops:** Alerting outlives its host, backups the host cannot delete, visible partial revocation (#408)
- **clients:** Refuse a shared relay IP; audit and guide a relay IP clear (ARD-022) (#411)
- **security:** Close review 2's auth, onboarding and UI findings (1.53.0) (#414)
- **deploy:** Tunnel reaches only the edge, backup target without a path, fixed LDAP suffix (ARD-021) (#415)
- **groups:** Delete a mixed-case role group's Authentik copy (#416)
- **deploy:** Verify proves the API holds its own Authentik token, fresh-host runs it (1.56.0)
- **deploy:** Prod preflight refuses backups that stay on the host (ARD-010) (#427)
- **ci:** Fetch the full base branch so PR diffs survive a moving main (#431)
- **seed:** Wait for the implicit-consent flow before falling back (#432)
- **ui:** Split-panel min-width matches the resize hook; drop the spec's extra page loads (#429)
- **qa:** Run the e2e browser in its own network namespace (#430)

### Documentation

- **runbooks:** Client onboarding, credential rotation and deregistration (#389)
- **runbooks:** Client lifecycle follows relay IPs (#392) and B2 policy (#390) (#399)
- **spec:** Agent simulation spec for onboarding a building client (1.52.0) (#412)
- **runbooks:** Onboard-a-building tutorial with E2E screenshots, Add client and PED80 (#413)

### Features

- **obs:** Route alerts to a push webhook and add identity alerts (#384)
- **authentik:** Source throttle in front of the username lockout (B5) (#385)
- **deploy:** Nightly backup lane with off-host copy and restore runbook (#387)
- **deploy:** Production issuer, TLS and relay path (ARD-021) (#388)
- **deploy:** Relay-path hardening, probe, and SIP/XMPP over it (ARD-021) (#392)
- **deploy:** One-command deploy on a fresh host, proven by a throwaway-VM CI job (#395)
- **clients:** Onboard a first-party client end to end in one call (ARD-022) (#393)
- **clients:** Onboarded clients carry their relay IP; preflight accepts them (ARD-022) (#405)
- **ui:** Add client page onboards a first-party client and shows its secrets once (ARD-022) (#409)
- **mcp:** AI agents onboard a client through an MCP server (ARD-022) (#410)
- **deploy:** Converge migrates an existing install's schema before the new API starts (#428)

### Performance

- **auth:** One user lookup and parallel revocation in terminate_user_access (#382)

### Testing

- **e2e:** Admin adds a client that lands in LDAP, Authentik, SIP and XMPP (#406)
- **e2e:** Serve the SSO debugger from its smoke spec on a free port (#426)

### Bump

- Version 0.19.0 → 0.20.0

## [0.19.0] - 2026-10-21

### Bug Fixes

- **auth:** Contain RBAC grants and add API-to-API service principals (#304)
- **arch:** Give Dependabot a lane through arch-guard (#317)
- **dev:** Move Grafana host port to 3002; fix arch-guard in worktrees (#342)
- **tests:** Remove order- and state-dependent failures from the backend suite (#344)
- **dev:** Repair stale .env so raw docker compose starts the web UI (#349)
- **seed:** Move client_credentials off the shared azblink-directory provider (#354)
- **sip:** Refuse PUT /sip for suspended or terminated users (ARD-020) (#371)
- **users:** Read unset mail/mobile back as "" instead of "None" (#372)
- **profiles:** Keep allocation counters inside their range on range changes (#373)
- **ci:** Wait on a time budget for a slow fresh Authentik (#377)
- **profiles:** Resolve a sub-org's profile from its nearest assigned ancestor (#376)

### Documentation

- Fix README drift, add frontmatter and a docs-lint merge gate (#289)
- Adopt the OpenWiki evidence index, drop its automation (#293)
- **vm6-vm7:** Derived integration design + implementation plan (#296)
- **architecture:** Backfill ARD status ledger and accept ARD-017 (#316)
- **reports:** Track headless first-party login gap report and probes (#326)
- **reports:** Record per-building topology and the 2026-10-02 integration audit (#327)
- **reports:** Owner approves decisions 15-18 for SafeNest SSO (#328)
- **reports:** Probe G14, LDAP group sync needs uidObject on role groups (#329)
- **architecture:** ARD-018 headless first-party client login (#330)
- **deploy:** Drop deleted POST /api/auth/login examples (#331)
- **architecture:** Accept ARD-018 headless first-party client login (#335)
- **handoff:** Run complete; escalate public dev Authentik exposure (#339)
- **architecture:** Record Cloudflare Access on dev authentik.keithmoc.dev (#348)
- **handoff:** Session-5 update (#350)
- **architecture:** ARD-019 client-scoped service principals (G18) (#353)
- **arch:** Propose ARD-020 client SIP provisioning and PBX read access (#369)

### Features

- **bootstrap-iso:** Share the source ISO and reclaim build artifacts (#294)
- **seed:** Env-registered first-party headless clients (#332)
- **groups:** Sync first-party client role groups into Authentik (#333)
- **seed:** Shared headless-first-party-auth flow (E3) (#336)
- **deploy:** Register headless first-party clients on the prod path (G20) (#337)
- **authentik:** Lockout and trusted proxies for headless clients (E5) (#338)
- **authentik:** Lockout hardening G22-G24 (web sign-in throttle, ppolicy window, parallel bound) (#345)
- **deploy:** Service-client and audience config on the prod path (#351)
- **authentik:** Atomic LDAP bind budget per username (G23) (#355)
- **audit:** Audit group/RBAC writes and enforce retention (#352)
- **auth:** Client-scoped service principals (ARD-019) (#367)
- **sip:** Client SIP provisioning, layered context and PBX read (ARD-020) (#370)
- **ldap:** UidNumber unique across the whole directory (#374)
- **sip:** Disjoint, capped SIP extension ranges across profiles (ARD-020) (#375)

### Miscellaneous

- **deps:** Bump ruff (#292)
- **deps:** Bump the npm-minor-patch group across 1 directory with 26 updates (#306)
- **deps:** Bump js-yaml and @redocly/openapi-core (#305)
- **deps:** Bump @vitest/mocker and vitest (#302)
- **deps:** Update sqlalchemy requirement in /tests (#315)
- **deps:** Update pyjwt requirement in /tests (#314)
- **deps:** Bump ruff (#308)
- **deps:** Bump the npm-minor-patch group with 14 updates (#307)
- **deps:** Update sqlalchemy requirement in /src/backend (#312)
- **deps:** Update pyjwt requirement in /src/backend (#313)
- **deps-dev:** Bump vitest from 4.1.11 to 5.0.1 (#311)
- **deps:** Update websockets requirement in /src/backend (#309)
- **deps:** Update cryptography requirement in /src/backend (#310)
- **deps:** Bump the actions group across 1 directory with 2 updates (#300)
- **deps:** Regenerate backend lock for the #309/#310/#312/#313 floors (#318)
- **deps:** Combine Dependabot #320-#325 (ruff, pyjwt, sqlalchemy, psycopg2-binary floors) (#343)
- **deps:** Combine Dependabot #356-#364 (ruff, websockets, pyjwt, sqlalchemy, cryptography, npm group) (#365)
- **deps-dev:** Bump brace-expansion from 2.1.4 to 2.1.7 (#341)
- **deps:** Bump esbuild and tsup (#366)

### Testing

- **e2e:** Headless first-party login contract (E4) (#334)

### Bump

- Version 0.18.0 → 0.19.0

### Ci

- Run every workflow on a self-hosted runner (azb-ad-ci) (#368)

## [0.18.0] - 2026-08-07

### Bug Fixes

- **deploy:** Stop azb-sync bricking itself from a detached alpha HEAD
- **auth:** Stop the OIDC groups claim listing every group twice (#279) (#283)
- **ldap:** Point the memberof overlay at the attribute pair we actually write (#285)
- **auth:** Make termination visible to relying parties, not just to us (#286)

### Documentation

- **reports:** VM7 Nextcloud SSO integration findings, corrected against the code (#284)
- **spec:** Publish the directory consumer contract, and keep cn readable (#287)

### Bump

- Version 0.17.0 → 0.18.0

## [0.17.0] - 2026-08-06

### Bug Fixes

- **seed:** Look the Authentik application up by slug, not by the list filter (#281)
- **build:** Repair just lock-backend and record the lane in spec 06

### Features

- **deploy:** Per-VM autoinstall ISO host bootstrap lane, and cut the dev converge over to the rebuilt azb-ad (#280)

### Miscellaneous

- **deps:** Bump ruff (#272)
- **deps:** Update marimo requirement in /tests (#276)
- **deps:** Update redis requirement from >=8.0.1 to >=8.1.0 in /tests (#277)
- **deps-dev:** Bump brace-expansion from 2.1.3 to 2.1.4 (#278)
- **deps:** Bump the npm-minor-patch group across 1 directory with 7 updates (#271)
- **deps:** Bump redis, cryptography and websockets, and regenerate the lock (#282)
- **tooling:** Wire ctx-router code search and add the appliance-iso-upload skill

### Bump

- Version 0.16.0 → 0.17.0

## [0.16.0] - 2026-08-05

### Bug Fixes

- **qa:** Authenticate e2e tests through the auth store, not an HTTP header (#238)
- **arch:** Make the post-merge drift detector able to fire, and record the #226 errata (#232) (#244)
- **security:** Stop the termination audit record asserting a UC result that never happened (TD-8, #233) (#248)
- **tools:** Verify seeded UC attrs against LDAP instead of an API response that cannot carry them (#92) (#250)
- **frontend:** Add the missing org_management permission (#230) (#251)
- **arch:** Make the guard's coverage model honest before enforcing it (#255)
- **arch:** Overlay the surface list from the trusted checkout, not the PR (#262)
- **arch:** Let an ARD declare the SOP section, so governance has an ARD lane (#269)

### Documentation

- **arch:** ARD-011 — Redis cross-worker fan-out + middleware-ordering invariant (#227) (#241)
- **arch:** ARD-012 — authorization posture when the auth stores are unreachable (#228) (#243)
- **arch:** Bring spec sections 02/03/08 up to as-built after the decomposition (#231) (#246)
- **tech-debt:** Narrow TD-4 to the anchor-scoping half that is still open (#261)
- **arch:** Record the LDAP connection-lifecycle decision as ARD-013 (#264) (#266)
- **spec:** Drop the volatile ldap_conn() caller list from §02 (#267)

### Features

- **frontend:** Generate API request types from the OpenAPI contract (#230) (#253)
- **security:** Enforce account locks during a PostgreSQL outage (ARD-012) (#257)
- **arch:** Flip arch-guard to fail mode, plus the realtime/self-service fixes it unblocks (#260)
- **arch:** Detect ungoverned backend modules, and give governance an ARD lane (#268)

### Miscellaneous

- **tooling:** Keep ctx-router agent tooling local, out of the repo (#229) (#240)
- **deps:** Bump ruff (#223)
- **deps:** Update prometheus-client requirement from >=0.25.0 to >=0.26.0 in /src/backend (#224)
- **deps:** Update marimo requirement in /tests (#225)
- **deps:** Bump the npm-minor-patch group with 14 updates (#222)
- **deploy:** Add azb-sync to stop safenest git/worktree drift (#270)

### Bump

- Version 0.15.0 → 0.16.0

## [0.15.0] - 2026-07-29

### Bug Fixes

- **deploy:** Host-reachable LDAP verify URL + symlink-safe autodeploy (#218)

### Features

- **dashboard:** Signal-forward redesign — attention-first hero + worklist sidebar (#219)
- **dev:** LAN remote-dev loop via Mutagen sync (#221)

### Miscellaneous

- **deps:** Bump the actions group with 2 updates (#210)
- **deps:** Bump ruff (#213)
- **deps:** Update slixmpp requirement in /tools (#217)
- **deps:** Update marimo requirement in /tests (#216)
- **deps:** Update slixmpp requirement in /tests (#215)
- **deps:** Bump the npm-minor-patch group with 13 updates (#211)
- **deps-dev:** Bump typescript from 6.0.3 to 7.0.2 (#212)
- **deps:** Update websockets requirement from >=16.0 to >=16.1.1 in /src/backend (#214)
- **deps-dev:** Bump brace-expansion from 5.0.7 to 5.0.8 (#220)

### Performance

- Lazy-load recharts, fix settings timer leak and profile listbox keyboard access (#209)

### Refactor

- **backend:** Decompose god modules into routers/, db/, schemas/ — plus 3 latent bug fixes (#226)

### Bump

- Version 0.14.0 → 0.15.0

## [0.14.0] - 2026-07-15

### Features

- **deploy:** Production deployment artifact (ARD-010) (#206)

### Miscellaneous

- **deps:** Update prometheus-client requirement in /src/backend (#198)
- **deps:** Bump the npm-minor-patch group across 1 directory with 13 updates (#208)
- **deps:** Bump softprops/action-gh-release in the actions group (#207)
- **deps:** Bump pathspec from 0.12.1 to 1.1.1 in /tools (#202)
- **deps:** Update pytest-asyncio requirement in /tests (#201)
- **deps:** Update pytest requirement from >=8.0 to >=9.1.1 in /tests (#200)
- **deps:** Update marimo requirement in /tests (#199)

### Testing

- **versions:** TD-1 failure-path unit test + extract version-probe cache (#205)

### Bump

- Version 0.13.0 → 0.14.0

## [0.13.0] - 2026-07-08

### Bug Fixes

- **ci:** Drop `docker compose up --wait` in QA (one-shot seed abort) (#194)
- **security:** Production-readiness hardening (tranche 1 of #187) (#196)
- **security:** C1 directory-read authz + H4 lock-DoS removal (#187)
- **security:** Directory-browse gating (ARD-009) + tech-debt paydown (v0.13.0 release-prep) (#204)

### Features

- **i18n:** Multi-language admin UI + Phase 2 lib-gaps & data-i18n proposal (#203)

### Bump

- Version 0.12.0 → 0.13.0

## [0.12.0] - 2026-07-06

### Features

- **provisioning:** Idempotent default-profile UC service seeding + GUI-dynamic config (#192)

### Bump

- Version 0.11.0 → 0.12.0

## [0.11.0] - 2026-07-05

### Features

- **uc-journey:** Full SSO→XMPP→SIP reference test client (#188)

### Bump

- Version 0.10.0 → 0.11.0

## [0.10.0] - 2026-07-04

### Bug Fixes

- **onboarding:** Wire create-user mutation so wizard persists to LDAP (#185)

### Features

- Authentik LDAP source — LDAP-backed web SSO (ARD-007) (#184)
- **observability:** Dev-first observability stack (ARD-008) (#186)

### Bump

- Version 0.9.1 → 0.10.0

## [0.9.1] - 2026-07-03

### Bug Fixes

- **ldap-clients:** Show provisioned label on detected client rows (#183)

### Bump

- Version 0.9.0 → 0.9.1

## [0.9.0] - 2026-07-03

### Features

- LDAP client provisioning — ou=clients + inventory reconciliation (#181)

### Miscellaneous

- **docs:** Add tech-debt register + weekly review process
- **ldap-clients:** Provisioning follow-ups — cleanups, ARD-006, review hardening (#182)

### Bump

- Version 0.8.0 → 0.9.0

## [0.8.0] - 2026-07-02

### Features

- System Information — stack versions (#180)

### Bump

- Version 0.7.0 → 0.8.0

## [0.7.0] - 2026-07-02

### Bug Fixes

- **deploy:** Stop azb-autodeploy watch on Ctrl-C (SIGINT trap + interruptible sleep)
- **deploy:** Guard autodeploy install.sh — macOS-only + refuse sudo

### Features

- **deploy:** Rich help + machine-readable AX for azb-autodeploy
- LDAP client inventory + acknowledgement (settings) (#179)

### Bump

- Version 0.6.0 → 0.7.0

## [0.6.0] - 2026-06-30

### Bug Fixes

- **authentik:** Repair 2026.5 login centering + RP-initiated logout 400 (#133)
- **deploy:** Self-heal --host on existing .env + remote logout URIs (#134)
- **authentik:** Retry flow lookup so seed survives worker blueprint race (#147)
- **frontend:** Resolve 13 react-hooks v7 lint errors (#176) (#177)

### Features

- **deploy:** Ansible deploy baseline for AZBlink Directory (#148)
- **deploy:** Forward SSH agent for Ansible GitHub fetch + wire steward ssh_config
- **deploy:** Tag-triggered notify-then-approve auto-deployer (launchd)
- **frontend:** Centralize brand + rename AZBlink to Azblink (#178)
- **deploy:** Autodeploy watch loop (120s countdown) + interactive version picker

### Miscellaneous

- **deps:** Consolidate 11 dependabot bumps + TypeScript 6.0 fix (#146)
- **deploy:** Add LAN/VPN gateway scripts + refresh handoff (#161)
- **deps:** Consolidate 12 dependabot bumps + Vite 8 Rolldown migration (#162)
- **deps:** Fold dependabot batch #163-#173 into consolidation (#175)

### Bump

- Version 0.5.1 → 0.6.0

## [0.5.1] - 2026-06-14

### Bug Fixes

- **ci:** Grant pull-requests:read so release workflow stops 403-panicking (#131)
- **dev:** Self-heal missing routeTree.gen.ts via EXDEV-safe TSR_TMP_DIR (#132)

### Bump

- Version 0.5.0 → 0.5.1

## [0.5.0] - 2026-06-13

### Bug Fixes

- **web-configure:** Apply review fixes to SKILL.md and reference playbook
- **auth:** Don't count OIDC infra failures toward account lock (#88)
- **auth,ui:** Structured 403 for account lock + error boundary on user list (#89)
- **auth:** Dedup same-token auth failures to prevent fanout lockout (#91)
- **auth:** Auto-start OIDC from Authentik app-library tile (#97)
- **dashboard,provisioning:** Recover pending list + devices from blank errors (#98)

### Documentation

- Add provisioning device management frontend design spec
- Add provisioning device management frontend implementation plan
- Add provisioning audit plan + update repo guidance
- Add QA pipeline plan, design spec, and handover notes
- Add web-configure skill design spec
- Add web-configure implementation plan (10 tasks)
- Apply review fixes to web-configure implementation plan
- Add web-configure playbook template with annotated schema
- **claude:** Refresh CLAUDE.md with Phase 0 governance + currency fixes (#103)

### Features

- Provisioning device management frontend (#84)
- QA pipeline with Playwright smoke tests and CI (#85)
- Add Patrol agent for UI bug investigation and verification
- Add QA patrol manifest and WebSocket issue report
- Update Patrol skills to v1.1.0 with improved browser navigation and issue reports
- Add reference playbook for Azblink Server LDAP client config
- **web-configure:** Add SKILL.md and browse-patterns reference
- **sip,ldap:** Validate SIP-LDAP e2e + add AsteriskAccount schema (#93)
- **ci:** Dead-code analysis pipeline + fast PR gate split (#95)
- **arch:** Install spec governance foundations (Phase 0) (#99)
- **arch:** Wire arch-guard enforcement core (Phase 1a, warn-only) (#100)
- **deploy:** Add one-command remote server bootstrap script (#130)

### Miscellaneous

- Add main branch protection hooks
- Add post-clone setup script with `just setup`
- Add web-configure playbook directory structure
- Register web-configure in skills manifest
- **ci,tools:** Apply CodeRabbit nitpicks from PR #95 review (#96)
- **deps-dev:** Bump vitest from 2.1.9 to 3.2.6 (#105)
- **deps:** Full dependency refresh — npm 0 vulns, EOL docker images, authentik 2026.5 (#106)
- **deps-dev:** Bump postcss from 8.5.6 to 8.5.15 (#107)
- **deps:** Atomic safe dependency refresh (10 Dependabot PRs) (#125)
- **deps:** Atomic major dependency bumps (6 Dependabot PRs) (#128)
- **deps:** Bump ruff 0.15.16 → 0.15.17 in /tools (#129)

### Styling

- Apply prettier semi:false and advance provisioning devices resizable panel

### Bump

- Version 0.4.0 → 0.5.0

### Ci

- **governance:** Harden CI/CD pipelines per audit (#108)

## [0.4.0] - 2026-03-18

### Bug Fixes

- **release:** Tag after changelog amend so tag points to final commit
- **backend:** Resolve dangling QR references after SSO/QR removal
- **tests:** Update tests for SSO/QR removal and provision_tokens rename
- **db:** Make migration 024 idempotent for device_provisions table
- Add OIDC groups scope mapping and fix OpenLDAP bootstrap conflict
- **provisioning-audit:** Add chip-to-event-type mapping in AuditList

### Documentation

- Add profile services restructuring design spec
- Add profile services restructuring implementation plan
- Update architecture for profile services model, create ARD-004
- Add provisioning audit design spec

### Features

- **backend:** Add profile_services table and CRUD methods to orgdb
- **backend:** Rewrite allocate_uc_resources for profile_services, update provisioning
- **frontend:** Update org-profiles types for services model
- **frontend:** Add ServiceCard, query hooks, rewrite ConfigTab for dynamic services
- **backend:** Add service endpoints, update build_uc_attrs and formatters
- **provisioning-audit:** Add device_provisions as 5th audit source

### Miscellaneous

- Remove obsolete skills and add architecture/cleanup docs
- **db:** Migration 024 — drop SSO/QR columns, rename provision_tokens
- **db:** Migration 025 — create profile_services, migrate XMPP/SIP data
- Remove orphaned imports and rename qr_provisioning permission
- Remove dead QR audit event code from frontend

### Refactor

- **frontend:** Remove SSO config from org management and profiles
- **backend:** Remove QR tables and methods from orgdb
- **backend:** Rename provision_tokens to device_provisions, drop auth_method
- **backend:** Remove SSO/QR endpoints and models from main.py, delete qr_signing.py
- **backend:** Remove SSO config and QR settings from orgdb config_templates
- **audit:** Replace dual filter system with responsive category pills

### Testing

- Remove QR tests, update conftest for device_provisions rename
- Add profile_services tests, update existing tests for services API
- Add profile_services cleanup fixture in conftest

### Bump

- Version 0.3.0 → 0.4.0

## [0.3.0] - 2026-03-13

### Bug Fixes

- **oidc:** Resolve post-login redirect failures and improve seed idempotency
- **notebook:** Derive uidNumbers from RUN_ID and clean up config templates
- **frontend:** Remove StartupCheck health preloader from app startup (#65)
- **frontend:** Remove deprecated QRHistory.tsx component (#67)
- **frontend:** Remove legacy qr-generator redirect route (#72)
- **frontend:** Replace phantom /qrcode/resend and /qrcode/generate with real endpoint (#68, #69)
- **frontend:** Add visual 'coming soon' state to email/SMS delivery buttons (#70)
- **tests:** Add user_lifecycle_audit cleanup to created_users fixture

### Documentation

- **claude:** Update CLAUDE.md with stale counts and missing just commands
- **backend:** Document qr_issues vs qr_issuance_audit table purposes (#74)
- **plans:** Add QR dead code cleanup implementation plan

### Features

- **authentik:** AZBlink branding + two-panel login redesign (#62)
- **authentik:** Glassmorphic login polish + static circuit backgrounds
- **test:** SSO device provisioning e2e with real Authentik OIDC tokens (#63)
- **notebook:** Migrate e2e notebook from QR flow to SSO device provisioning
- **authentik:** Seed alanl admin user and add branding diff-check

### Miscellaneous

- **db:** Drop orphan tenant_ldap_configs and sync_events tables
- **backend:** Remove unused UCCHAT_WEBRTC_SIP_URL and UCCHAT_TURN_URL config vars
- **backend:** Remove dead UCClient.check_session_status() stub
- **frontend:** Remove dead QRDisplay component
- **frontend:** Remove dead HealthStatus component
- **ui:** Remove unused DataTable primitive from @azblink/ui

### Refactor

- **frontend:** Deduplicate QRHistoryEntry type to single canonical definition (#73)
- **backend:** Move verify_provisioning_payload to test utilities (#71)
- **backend:** Rename record_issue/record_qr_issuance for scope clarity (#75)
- **frontend:** Replace deprecated Group type with UserGroup matching API response

### Bump

- Version 0.2.0 → 0.3.0

## [0.2.0] - 2026-03-11

### Bug Fixes

- **ldap:** Replace invalid dn attribute request with objectClass
- **deploy:** Add nginx reverse proxy for remote access
- Remove dead code from rate_limit.py
- Move health endpoints after require_user definition
- **dev:** Change Redis port to 6380 to avoid conflict
- **backend:** Address code review findings
- **ldap:** Import BASE scope and correct delete_old_dn kwarg
- **tests:** Correct import paths for unit tests
- **tests:** Resolve config pollution in TTL capping test
- **tests:** Add backend path to sys.path in conftest
- Remove import path hacks, use conftest sys.path
- **orgdb:** Capture timestamp once in token validation
- Use same token hash in audit table for correlation
- Fail QR generation if token recording fails
- **auth:** Integration test fixes
- **org-profiles:** CORS PUT method, unassign template_id validation, module logger (review fixes)
- **org-profiles:** Address spec review findings (C1, C2, I1-I6)
- **org-profiles:** DRY date formatting — use shared date-helpers (Task 26)
- **org-profiles:** Stale URL param fallback + skeleton breakpoint alignment
- **settings:** Address Phase 0 review findings
- **settings:** UseRef requires initial value in React 19 (Phase 1 review)
- **tsconfig:** Add @azblink/ui path mapping for TypeScript resolution
- **settings:** Phase 2 review — a11y hint, scroll-spy stability, consistency
- **settings:** Phase 3 review — data-testid, clipboard error handling
- **settings:** Review fixes — remove dead code, fix a11y, drop uninstalled animation classes
- **settings:** Bottom bar — fix gap, overlap, and duplicate Discard buttons
- **settings:** Bottom bar — elevated surface with shadow for clear visual separation
- **settings:** Add breathing room above Danger Zone section
- **settings:** Lock page scroll when pending changes drawer is open
- **delivery:** Replace Button primitive with plain button for icon rendering
- **onboarding:** Restore password max-length check and display password error text
- Address code review findings for UED sync integration
- Use venv python path and install all deps for ued-sync tests
- Update tests for profile-UED merge, fix orgdb create/update + UnboundLocalError
- Remediate 10 FIRA audit findings — OIDC mapping, test gaps, settings serialization (#37)
- Resolve 3 frontend runtime bugs — audit crash, inert warning, profile 404 (#38, #39, #40) (#41)
- **dashboard:** Phase 4 naming & contract reconciliation (#56)

### Documentation

- **deploy:** Add quick-start README
- **deploy:** Add comprehensive deployment specification
- Add v1.0 baseline gap analysis report
- Add project configuration and Path B MVP specification
- Add live demo data enhancement design
- Add live demo data implementation plan
- Add full-page preview enhancement design
- Add Traefik proxy design for dev stack
- Add production readiness assessment for backend vs spec
- Add P0 production blockers implementation plan
- Add backend API testing design
- Add backend API testing implementation plan
- Add testing section to CLAUDE.md
- Add test audit report with spec gap analysis
- Update test audit report with expanded coverage (28% → 78%)
- Add v2.0 spec — OpenAPI, SQL schema, LDAP schema, and technical audit
- Comprehensive v1→v2 spec gap analysis
- Add Phase 1 and Phase 2 PRDs for QR provisioning
- Add Phase 1 QR fixes design document
- Add Phase 1 QR fixes implementation plan
- Add UC provisioning variables to env files
- Add manual migration instructions to CLAUDE.md
- Add enterprise SaaS UI redesign plan
- Add API contracts and OpenAPI spec for Phase 1 UC QR provisioning
- Add React tech stack design for greenfield UI
- Add React UI implementation plan
- Add frontend development section to CLAUDE.md
- Add admin LDAP authentication design
- Add LDAP authentication implementation plan
- Add org profiles migration design doc and prototype
- Add org profiles detailed implementation plan
- **settings:** Design doc, implementation plan, workflow rules, post-mortem update
- **settings:** Phase 2 implementation plan — forms, nav polish, dirty tracking
- **settings:** Phase 3 (final) implementation plan — all remaining sections + polish
- Add UED sync integration section to CLAUDE.md
- Add UED sync integration implementation plan
- Added all design plan docs into remote
- Add monorepo consolidation design for azb-ldap-integration merge
- Add monorepo consolidation implementation plan
- Expand UED Sync env vars in .env.example
- Add UED Sync service to CLAUDE.md
- Add monorepo context notice to UED Sync README
- Update CLAUDE.md with monorepo consolidation learnings
- Update deployment specs and README for UED Sync integration
- Add iterative analysis report for UED Sync, XMPP/SIP profiles, and QR-LDAP auth (#3)
- Add xmpp sip qrcode authenticationreport
- Add comprehensive SSO integration requirements & gap audit (#4)
- Profile-UED 1:1 merge design — inline UED fields on config_templates
- Add profile-UED 1:1 merge implementation plan
- Update CLAUDE.md for profile-UED 1:1 merge
- Added SSO related researchs and specifications
- Add Authentik OIDC gotchas, seed script, and issuer architecture to CLAUDE.md
- **architecture:** V1.0.0 architecture specification — 8 sections, 3 ARDs, SOP, and CLAUDE.md update
- Add FIRA audit artifacts, repomix packs, and session plans
- Add dashboard migration spec, session plans, and bug-fix artifacts
- Dashboard Phase 4 naming reconciliation design spec
- Add Phase 4 reconciliation implementation plan
- Add REVIEW.md for code review plugin configuration
- Update CLAUDE.md to reflect current codebase state
- Streamline CLAUDE.md and extract path-scoped .claude/rules
- Add unified versioning design spec (git-cliff + commitizen)
- Add unified versioning implementation plan

### Features

- **deploy:** Add Dockerfile.api for pre-built Python image
- **deploy:** Add .env.example template
- **deploy:** Add OpenLDAP bootstrap LDIF with demo data
- **deploy:** Add dev breakglass credentials
- **deploy:** Update docker-compose with OpenLDAP and pre-built API image
- **deploy:** Complete dev environment setup
- **seed:** Add demo data seeder with 58 users
- **deploy:** Add seed service and avatar cache volume
- **ui:** Convert preview to full-page tabs
- **deploy:** Add Traefik reverse proxy to dev stack
- **dev:** Add Justfile and hot reload rules
- **infra:** Add Redis service for rate limiting
- **deps:** Add redis and slowapi for rate limiting
- **config:** Add REDIS_URL configuration
- **security:** Add rate limiting module with Redis backend
- **security:** Integrate rate limiting on critical endpoints
- **db:** Add termination_events and qr_issuance_audit tables
- **ldap:** Add disable_user function for termination flow
- **api:** Add POST /api/users/{uid}/terminate endpoint
- **db:** Add token validation and consumption method
- **api:** Add POST /api/provision/validate endpoint
- **api:** Add health check endpoints
- **tests:** Add test infrastructure with core fixtures
- Implement spec v1.0 compliance — API alignment, audit, security, and testing
- **config:** Add ORG_QR_MAX_TTL_SEC setting
- **qr:** Add qr_signing module with HMAC-SHA256
- **db:** Add device tracking columns to provision_tokens
- **orgdb:** Add update_provision_token_device method
- **api:** Update /qrcode endpoint to v2 schema
- Add startup validation for UC config variables
- Add startup validation for signing secret
- **frontend:** Initialize Vite React 19 project
- **frontend:** Add Tailwind CSS with design tokens
- **frontend:** Add Zustand stores for UI and auth state
- **frontend:** Add TypeScript types from API contracts
- **frontend:** Configure shadcn/ui with base components
- **frontend:** Add typed API client with error handling
- **frontend:** Add TanStack Query key factory and hooks
- **frontend:** Add Header component with search trigger
- **frontend:** Add Sidebar component with navigation
- **frontend:** Add StatCard component for dashboard metrics
- **frontend:** Add HealthStatus component for system monitoring
- **frontend:** Add UserTable component with loading skeleton
- **frontend:** Add app entry point and root route
- **frontend:** Integrate app shell in root layout
- **frontend:** Add QRDisplay component for provisioning
- **frontend:** Add keyboard shortcuts (⌘K, ⌘B)
- **frontend:** Complete Dashboard page with stats and health
- **justfile:** Add React UI development commands
- **deploy:** Add Docker config for React UI build
- **frontend:** Add QR Generator page with user selection
- **frontend:** Add User detail page with profile and groups
- **frontend:** Add Playwright E2E test setup
- **deploy:** Integrate React UI into docker-compose
- **frontend:** Complete UI fixes and missing routes
- **auth:** Add JWT configuration for LDAP login
- **auth:** Add LDAP bind login endpoint with JWT tokens
- **ui:** Add shadcn alert-dialog, dropdown-menu, checkbox, label
- **auth:** Update auth store with login/logout actions
- **ui:** Add session expired modal state to UI store
- **api:** Update unauthorized handler to distinguish session expiry
- **ui:** Add session expired modal component
- **ui:** Add profile dropdown component
- **ui:** Add login page with LDAP authentication
- **ui:** Replace static profile button with dropdown
- **auth:** Add route protection with login redirect
- **auth:** Wire up session expiry handler in API client
- **deploy:** Add JWT_SECRET to docker environment
- Admin UI overhaul — design system, split-panel management, QR codes
- QR inline trend stats, ListPanel primitive, UI refinements
- Audit log page, provisioning ops dashboard, and supporting API endpoints
- **ui:** Shared SearchInput, platform-aware shortcuts, scrollable tabs
- **org-profiles:** Add SQL migration for config_templates schema (Task 1)
- **org-profiles:** Add SQLAlchemy table definitions + table existence test (Task 2)
- **org-profiles:** Add CRUD methods + list/get/create endpoints (Task 3)
- **org-profiles:** Add update, delete, toggle endpoints (Task 4)
- **org-profiles:** Add clone, assign, unassign endpoints (Task 5)
- **org-profiles:** Seed default config template on startup (Task 6)
- **org-profiles:** Add TypeScript types, response wrappers, query keys (Task 7)
- **org-profiles:** Add CollapsibleSection primitive with WAI-ARIA disclosure (Task 8)
- **org-profiles:** Add sidebar nav, route scaffolds, settings redirect (Task 9)
- **org-profiles:** Add profile type config + query hooks (Task 10)
- **org-profiles:** Add ProfileCard component for template list (Task 11)
- **org-profiles:** Add ProfileList card container with keyboard nav (Task 12)
- **org-profiles:** Add page header, management page, wire route (Task 13)
- **org-profiles:** Add ConfigSection and ConfigTab components (Task 14)
- **org-profiles:** Add UsageTab and HistoryTab components (Task 15)
- **org-profiles:** Add ProfileDetailPanel with tabs, wire into page (Task 16)
- **org-profiles:** Add modal state machine (Task 17)
- **org-profiles:** Add mutation hooks (Task 18)
- **org-profiles:** Add CreateProfileModal for create + edit (Task 19)
- **org-profiles:** Add DeleteProfileModal (Task 20)
- **org-profiles:** Wire modals + clone action into management page (Task 21)
- **org-profiles:** Wire toggle with optimistic cache updates (Task 22)
- **org-profiles:** Responsive layout + empty state CTA (Tasks 23-24)
- **org-profiles:** Data-testid attributes, accessibility, autoFocus (Task 25)
- **migration-ui:** Add settings migration specification and content-only HTML
- **settings:** Add app_settings + api_keys tables (Phase 0)
- **settings:** Add SettingsDB module for app_settings + api_keys CRUD (Phase 0)
- **settings:** GET + PATCH + PUT /api/settings endpoints (Phase 0)
- **settings:** API keys + test-connection endpoints (Phase 0)
- **settings:** TypeScript types + TanStack Query options (Phase 0)
- **@azblink/ui:** Add Select, RadioGroup, ToggleRow primitives (Phase 0)
- **settings:** UseScrollSpy hook, SettingsSection, SettingsNav (Phase 1)
- **settings:** SystemInfoSection absorbs existing health + build info (Phase 1)
- **settings:** SettingsManagementPage shell + route wiring + hash scroll (Phase 1)
- **settings:** FormRow + FormGroup layout components (Phase 2)
- **settings:** Polish SettingsNav with card wrapper + dirty count badge (Phase 2)
- **settings:** StatusIndicator pill + TestButton components (Phase 2)
- **settings:** LdapSection with 6 inputs + 2 toggles + test connection (Phase 2)
- **settings:** EmailSection with SMTP form + port select + test email (Phase 2)
- **settings:** SecuritySection with timeout/attempts selects + 3 toggles (Phase 2)
- **settings:** Wire LDAP/Email/Security sections + dirty field tracking (Phase 2)
- **settings:** Wire Save/Reset mutations + toast feedback (Phase 3)
- **settings:** BrandingSection + AuditSection components (Phase 3)
- **settings:** AdminsSection + DangerZoneSection components (Phase 3)
- **settings:** ApiKeysSection + query hooks — generate, copy, revoke (Phase 3)
- **settings:** Wire all 5 remaining sections into SettingsManagementPage (Phase 3)
- **settings:** Responsive collapse + accessibility polish (Phase 3)
- **settings:** Add PendingChange type for granular change tracking
- **settings:** Add field-labels constant map for pending changes display
- **settings:** Add BottomSaveBar — sticky bottom save/discard bar with drawer trigger
- **settings:** Add PendingChangesDrawer — grouped change list with per-item revert
- **settings:** Add usePendingChanges hook — Map-based change tracking with per-field revert
- **settings:** Wire usePendingChanges + BottomSaveBar + PendingChangesDrawer into page
- **settings:** Add route guard warning when navigating with unsaved changes
- **settings:** Add design and implementation plans for pending changes feature
- **ui:** Add new pages for user onboarding, user details, workflows, and QR states
- **audit:** Add optional page size change handler to AuditList component
- **onboarding:** Enhance user onboarding with password UX and validation
- **validation:** Refactor to FieldErrors map with password rules
- **onboarding:** Add fieldErrors state and per-field validation dispatch
- **onboarding:** Add per-field inline validation errors to StepUserInfo
- **onboarding:** Add live password complexity checklist
- **onboarding:** Implement onboarding validation UX and delivery button icon fixes
- **api:** Expose issued_by in user QR history response
- **api:** Expose createdAt from LDAP createTimestamp in user detail
- **api:** Resolve manager DN to display name in user detail
- **api:** Add GET /api/users/{uid}/devices endpoint
- **api:** Add GET /api/users/{uid}/stats endpoint
- **ui:** Refactor UserDetailPanel into tabbed layout
- **ui:** Build Overview tab with stats grid and summary cards
- **ui:** Build Provisioning History timeline tab
- **ui:** Build Devices tab with provisioned device cards
- **ui:** Wire Edit User modal with PATCH /api/users/{uid}
- **db:** Add tenant_ldap_configs and sync_events tables for UED integration
- Add Fernet encryption module for UED tenant secrets
- Add UED encryption key config and httpx/cryptography deps
- **db:** Add OrgDB CRUD for tenant_ldap_configs and sync_events
- Add UED Sync HTTP client with event-to-endpoint mapping
- Add async SyncWorker with backoff and per-user ordering
- Wire UED sync emission into user lifecycle routes + admin API
- **ued-sync:** Address code review findings and add sync client tests
- Copy UED Sync API source into src/ued-sync/
- Add Dockerfile for UED Sync API dev container
- Add ued-sync service to dev docker-compose stack
- Add ued-* recipes and test-all to Justfile
- Profile template system — built-in schemas + schema_name support (#5)
- UED self-discovery — simplify config to URL + API key (#7)
- SIP + XMPP profile provisioning enrichment
- **frontend:** Add UED Provisioning section to ConfigTab
- **frontend:** Add useDiscoverProfile mutation hook
- UED architecture fix + frontend layout improvements (#9)
- End-to-end XMPP provisioning test with interactive notebook (#10)
- Shareable QR code preview links with expiring public URLs (#11)
- Single-LDAP architecture — collapse two-LDAP into one (#12)
- Authentik-only OIDC auth — remove LDAP JWT and breakglass (#13)
- Authentik dev stack — local OIDC IdP for end-to-end login (#14)
- Wave 1 — P0 security foundation + quality fixes (Epic #15) (#33)
- Wave 2 — DS-7 admin audit, DS-5 security settings, DS-4 self-service (Epic #15) (#34)
- Wave 3 — DS-6 RBAC, DS-8 audit export, user export (Epic #15) (#35)
- Wave 4 — LDAP schema, ppolicy, refresh tokens, SSO QR, UC validation (Epic #15) (#36)
- **dashboard:** Phase 1 — types, primitives, static shell (#43, #45, #46) (#53)
- **dashboard:** Phase 2 — ProvisioningChartCard + RecentQRCard (#47) (#54)
- **dashboard:** Phase 3 — right column cards + Phase 4 query hooks (#48, #49) (#55)
- **dashboard:** Add 6 backend API endpoints for dashboard data sources (#50) (#57)
- **realtime:** Add WebSocket/SSE real-time activity feed (#51) (#58)
- **dashboard:** Wire live data, WebSocket activity feed, and toast notifications (#49) (#59)
- SSO device provisioning — sealed box credential delivery (#60) (#61)
- Add unified versioning configuration (commitizen + git-cliff)
- Add /api/version endpoint and backend version tracking
- Rewire frontend version to root package.json and add release commands
- Add GitHub Actions release workflow and initial changelog

### Miscellaneous

- **deploy:** Ignore .env file
- **deploy:** Add Dockerfile for seed script
- **deploy:** Add Dockerfile.ui for UI container
- Add Python cache files to .gitignore
- Add .gitkeep files for frontend directory structure
- **frontend:** Add ESLint 9 and Prettier configuration
- **frontend:** Update package-lock.json for Playwright
- Clean stale tenant_ldap_configs comment references
- Archive pre-March stale docs and migration artifacts

### Refactor

- Reorganize repo for spec-driven development
- **ui:** Remove mock data from directory_fixed.html
- **ui:** Remove mock data from directory_mobile_fixed.html
- **ui:** Remove mock data from directory_manager_org_setup_fixed.html
- **ui:** Remove mock data from directory_manager_fixed.html
- **ui:** Remove mock data from my_profile.html
- **ui:** Remove mock data from directory_provision_manager_fixed.html
- Remove duplicate TTL capping from main.py
- **ui:** Mark dead components as deprecated, fix text-xs token bugs
- **orgdb:** Merge tenant_ldap_configs into config_templates
- **main:** Merge UED config into profile endpoints
- **sync_worker:** Resolve profile_id instead of tenant_id
- **provisioning:** Read UED fields from profile directly
- **frontend:** Update types for profile-UED 1:1 merge
- **frontend:** Enhance layout and scrolling behavior in OrgProfilesManagement and Settings components

### Testing

- **health:** Add health endpoint tests
- **security:** Add rate limiting tests
- **security:** Add user termination tests
- **provisioning:** Add token validation and QR tests
- **security:** Add QR payload signing tests (Spec §0.1)
- **security:** Add user create rate limit and termination response shape tests
- **provisioning:** Add QR output format tests (Spec §5.1, §5.3)
- **bootstrap:** Add bootstrap and tenant endpoint tests (Spec §10.1)
- **orgprofiles:** Add OrgProfile CRUD and rotate tests (Spec §10.6)
- **users:** Add user CRUD, password reset, move org tests (Spec §10.3)
- **org-groups:** Add org tree and group CRUD tests (Spec §10.2, §10.4)
- Add QR provisioning integration tests
- **org-profiles:** Expand test suite with edge cases (Task 27)
- **settings:** Add E2E tests for pending changes — bar, drawer, revert, discard
- Add vitest for frontend unit tests with validation sanity check
- Add E2E smoke tests for UED sync event emission

### Migration

- 014 merge tenant_ldap_configs into config_templates

