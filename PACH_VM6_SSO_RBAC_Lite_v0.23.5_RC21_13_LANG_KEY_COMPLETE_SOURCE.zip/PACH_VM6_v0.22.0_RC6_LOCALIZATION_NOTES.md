# VM6 v0.22.0 RC6 — Localization Increment

Baseline: v0.21.9 RC5. This is a **translation-only** source update. Existing keys and translations are retained; no SSO/RBAC/LDAP behavior changed.

## New work

Group Management: all 82 source keys now present in all 13 languages (including a nonlocalized sample group identifier). New translated alerts, member counts, permission explanations, modal buttons and validation messages for all ten added locales. Exact key and `{{placeholder}}` checks run on all 13 languages.

## Release limitation

Localization is NOT complete. Remaining missing source keys fall back to English. Native speaker review, Arabic RTL browser QA, and frontend build are outstanding. See `PACH_VM6_v0.22.0_RC6_LOCALE_COVERAGE.json` for exact numbers. This is not production-approved.
