# PACH VM6 v0.21.5 — Release Candidate 1

**Status: RC / NOT production-approved.** This is the complete v0.21.4 source plus focused release-security hardening and deployment handoff materials. It is NOT a production release, because a running Authentik, OpenLDAP, PostgreSQL, Redis and frontend build environment were not available for complete validation.

## Architectural baseline

PACH-STD-IAM-001: VM6 centralizes OpenLDAP identities, Authentik browser SSO and simple user-to-application roles. Every VM and future registered application uses the VM6 identity authority, but application-specific resource permissions remain local. No general-purpose ABAC engine, no cross-VM per-resource permission catalogue.

## Differences from v0.21.4

1. **Cross-application role privacy:** `GET /api/applications/me/roles` with a dynamic `pach-app-<application_id>` user token now returns only the role for its own provisioned, enabled application using the already-established client-bound role decision. It does not disclose other application role assignments. Existing non-dynamic legacy VM6 management UI tokens retain prior self-role-list behavior, for backward compatibility. The canonical integration contract remains `GET /api/integration/v1/applications/<id>/me`.
2. **Protect cross-application role modifications:** `PUT /api/applications/<id>/users/<uid>` and the matching `DELETE` now require both the existing `user_management` permission and `system_configuration` permission. This prevents delegated directory user managers from granting themselves administrator rights across PACH applications. Existing application administrators may need their VM6 roles adjusted by the platform administrator after upgrade.
3. Added six dependency-isolated offline regression checks for privacy, compatibility, default denial and administrative guard presence.
4. Included a deterministic validation checklist for deployment owners and migration gate.

## Verification carried out in this environment

- PASS: 22 reference app unit tests (`python -m unittest discover -s examples/pach_rbac_lite/tests -q`).
- PASS: 6 new offline regression checks (`python -m unittest discover -s tests/unit -p test_pach_role_roster_isolation_offline.py -q`).
- PASS: `python -m compileall -q src/backend examples/pach_rbac_lite`.
- PASS: ZIP integrity and source-file carry-forward checks (see `RELEASE_MANIFEST.json`).
- BLOCKED: full pytest test collection: `ModuleNotFoundError: No module named 'psycopg2'`.
- NOT RUN: live Authentik/OIDC, LDAP bind, PostgreSQL migration, frontend production build, full service regression/E2E, real VM1–VM10 integrations.

The v0.21.4 test report recorded 30 prior offline checks; they were not all rerun here. Do not combine historical test totals with current test evidence.

## Known limits intentionally retained

- OIDC/LDAP provisioning: coded but not live validated. SAML must be configured manually.
- One authentication client per registered application. No automatic multi-client provisioning.
- LDAP protocol services authenticate through their native VM6 LDAP integration; LDAP-only role retrieval via the OIDC `/me` endpoint is not supported.
- Disabling an application blocks VM6 authorization decisions, but does not automatically revoke existing remote client credentials or locally cached sessions.
- Applications must enforce roles and detailed authorization locally. There is no guarantee of instantaneous revocation unless an application rechecks role decisions.

## Required approval gate before production

1. Restore v0.20.0 data in a staging PostgreSQL copy, apply migrations 032 and 033, inspect all existing organization/user/client records; verify rollback plan (DB backup restoration, not reverse migration).
2. Install pinned project dependencies and run complete existing VM6 tests plus new checks. Compare with original v0.20.0 regression baseline.
3. Build frontend and verify management UI/EN/zh-TW/zh-CN strings and permission gating.
4. Authenticate against live Authentik, check cryptographic JWT signature, issuer, audience and client binding. Confirm only same-client user roles can be retrieved.
5. Exercise new future app onboarding (`partner-crm`), assign custom role, deny unknown user, revoke role, disable app, verify app never receives another app's data. Verify Authentik remote client setup.
6. Exercise LDAP services in staging for SIP, XMPP, mail and MQTT configurations actually used by PACH. Verify client-credential handling and service failure behavior.
7. Regress existing building first-party provisioning flows: SIP/XMPP must be unchanged by generic app registration.
8. Review both platform permission requirements for role assignment. Verify admin UI displays 403 appropriately for delegated directory managers.
9. Review release with two maintainers, record test evidence and approval before changing RC status.

## Rollout

- Preserve original v0.20.0 source and database snapshot.
- Do not overwrite production VM6 or run migrations against live data without staging evidence.
- Follow existing project deployment mechanism, not a manually invented deployment command.
- Use the new source ZIP as consolidated RC candidate. Individual VM integration remains separate work.
