# PACH VM6 SSO & RBAC Lite — Step 2 Development Candidate

Base: v0.21.0 development source, derived from v0.20.0. Status: **unverified development source**, not production approved.

## New capabilities
- New `pach_application_auth_clients` table and migration `033`, separate from building-specific `first_party_clients`.
- Admin-only `GET /api/applications/{application_id}/authentication` for non-secret status.
- Admin-only `POST /api/applications/{application_id}/authentication/provision` with `{ "method": "oidc", "redirect_uris": ["https://crm.example.com/callback"] }` or `{ "method": "ldap", "redirect_uris": [] }`.
- OIDC provisions a dedicated `pach-app-<application_id>` Authentik provider, code/refresh grant, exact approved redirect URI, authenticated-human policy, with one-time secret disclosure.
- LDAP reuses existing `ldap_provisioning.provision`, with a dedicated stable `pach-...` bind client name and one-time generated secret. It provisions only service bind credentials, **not user permissions or LDAP group policies**.
- Admin UI provisions OIDC/LDAP authentication clients and displays one-time secrets; English / Traditional Chinese / Simplified Chinese keys added.
- Retryable `pending` and `ready` records; replays never rotate credentials or return stored secrets.
- No building, SIP, XMPP, or first-party scope provisioning.

## Integration contract and restrictions
- A successful login is **not** an application authorization grant. Each application must query a secure role endpoint and deny users without active assignments. Generic OIDC login currently authenticates directory users, not application-role-filtered users at Authentik login time.
- The v0.21.0 `/api/applications/me/roles` endpoint works for the authenticated user. Dedicated service-mediated role lookup and client verification belong to Step 3.
- Only **one** authentication client registration is supported per application in Step 2. Multiple protocols/clients per app require a later extension; do not claim this is supported yet.
- **SAML automatic provisioning is not implemented.** SAML applications may be registered in the catalogue, but their Authentik registration remains manual.
- OIDC URI changes and credential rotation are intentionally not available through this endpoint. A reviewed rotation/update workflow is required.
- Disabling a registry application removes its role grants from API lookups but **does not yet disable its already-provisioned Authentik provider or LDAP bind account**. Administrators must disable those separately until lifecycle synchronization is implemented.
- During a partially successful external provisioning call, a secret may have been created but not returned; an operator must recover/rotate it using the standard credential-management process, not trust a blind retry.
- Future application registration is dynamic: no VM6 source change is required for another OIDC or LDAP app whose requirements fit these interfaces.

## Verification and rollout
- Run migrations/033 before upgrading existing databases; metadata `create_all()` creates missing tables only.
- Offline Python compilation, DDL parity checks, and targeted Authentik adapter tests were performed. Full pytest, frontend build, live Authentik/LDAP and end-to-end tests are **not performed** in this environment.
- Always keep the prior v0.21.0 zip and production v0.20.0 source for rollback; verify DB migrations and credentials carefully in a staging environment.
