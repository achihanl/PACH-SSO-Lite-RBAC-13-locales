# PACH VM6 v0.23.3 RC19

Cumulative release based on v0.23.2 RC18. Added 32 new Settings translations in each of ten newly added languages (320 entries). Focus: LDAP search/bind field labels, security and audit controls, credential-strength warnings, and first-party onboarding validation errors.

Current coverage: 994/1062 keys per newly added language; remaining 68 keys (Settings only).

Existing translations and source retained; interpolation placeholders and locale key consistency verified. Approved PACH glossary terminology and existing Concept ID provenance left unchanged. New wording is draft pending native review. Frontend builds, RTL visual checks, and live integration remain unverified.
