# PACH VM6 v0.23.0 RC16 — Settings locale expansion

Baseline: v0.22.9 RC15.

Added 45 new translated Settings keys and reused 10 exact-match strings per added language, for 550 newly populated locale entries. Reuse mapping and coverage included in JSON report. Existing translated values have not been overwritten.

This release preserves VM6 authentication, LDAP, Authentik, RBAC Lite and future application integration source. No backend changes.

PACH Master Terminology v25.9 remains terminology reference. New translations are drafts, not approved glossary modifications. Native language review, frontend build and RTL tests remain pending.
