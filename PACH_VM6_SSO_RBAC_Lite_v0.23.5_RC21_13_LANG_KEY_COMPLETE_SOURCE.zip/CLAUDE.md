# CLAUDE.md

## SKILLS (to be considered and prioritied)

### gstack
Use /browse from gstack for all web browsing. Never use mcp__claude-in-chrome__* tools.
Available skills: /plan-ceo-review, /plan-eng-review, /plan-design-review,
/design-consultation, /review, /ship, /browse, /qa, /qa-only,
/setup-browser-cookies, /retro, /document-release.

## Project Overview

AZBlink Directory: LDAP-backed identity directory with device provisioning and optional Authentik SSO integration. Single-LDAP architecture: one LDAP holds both identity (inetOrgPerson) and UC service attributes (posixAccount + AsteriskPjsip*) on the same entry. UC provisioning (XMPP/SIP) is direct — attributes are written atomically during user creation.

**Critical design rules:**
- UC must work even when Authentik is not installed
- Single LDAP holds identity + UC attrs on same DN (no separate UC LDAP)
- Profiles are named configuration containers; UC services (XMPP, SIP, future) are independent `profile_services` records

## Development Commands

Use `just` for all dev commands. Run `just --list` to see available commands.

```bash
# First time setup
cd deploy/dev && cp .env.example .env
just up           # Start with build (foreground)
just up-bg        # Start in background

# Common commands
just logs         # API logs (follow mode)
just ps           # Container status
just down         # Stop (preserves data)
just reset        # Stop and delete all data

# Recovery & maintenance
just recover      # Restart all services and wait for healthy
just resync       # Reset and reseed the database
just restart      # Restart all services
just api-rebuild  # Rebuild API container (after lock-backend / requirements.txt changes)

# Diagnostics
just health       # Check all service health status
just health-check # Quick health check (exit code 0/1)
just connections  # Show service connection details
just stats        # Container resource usage
just ldap-dump    # Full LDAP dump
just ldap-users   # List LDAP users
just ldap-orgs    # List LDAP org tree

# Release & versioning
just version      # Show current platform version
just release      # Bump version + generate changelog + tag
just release-dry  # Preview next version bump (dry run)
just cz-commit    # Guided conventional commit (interactive TUI)
```

**Services when running:**
- UI: http://localhost:8081/
- API: http://localhost:8081/api (docs at /api/docs)
- PostgreSQL: localhost:5433 (azblink_directory/azblink_directory)
- OpenLDAP: localhost:1390 (cn=admin,dc=azblink,dc=com / adminpassword)
- Authentik IdP: http://localhost:9000/ (akadmin / adminpassword)
- Authentik Admin API: http://localhost:9000/api/v3/ (Bearer dev-authentik-api-token)

## Testing

```bash
just test          # Run all tests (starts stack if needed)
just test-quick    # Run tests (assumes stack is up)
just test-security # Run security tests only
just test-cov      # Run with coverage report
just test-xmpp-e2e # Run XMPP e2e test (requires 192.168.122.89 + EXTERNAL_LDAP_ADMIN_PASSWORD)
```

41 test files across: core, security, provisioning, UC/LDAP, orgs/groups, user lifecycle, admin, auth, realtime, e2e. Tests run against the real Docker stack (no mocks).

**Test fixtures:** `client` = authenticated (DEV_AUTH_TOKEN), `anon_client` = unauthenticated (see `tests/conftest.py`).

## Authentication

Authentik OIDC exclusively. No local LDAP login endpoint.

- Backend uses Docker-internal URL (`http://authentik-server:9000/...`) for JWKS/discovery
- Frontend uses browser-accessible URL (`https://authentik.keithmoc.dev/...`) for login redirects
- Tokens may have either URL as `iss` — backend validates both via `OIDC_ACCEPTED_ISSUERS`
- **Dev/test bypass:** `DEV_AUTH_TOKEN=dev-test-token` — `Bearer dev-test-token` bypasses OIDC, returns admin claims. Never in production.

## Code Style

**Python (backend):**
- No explicit formatter configured — follow existing patterns in `src/backend/`
- Type hints on all function signatures
- Pydantic models for request/response validation
- Async endpoints where I/O is involved

**TypeScript (frontend):**
- ESLint + Prettier configured in `src/frontend/`
- Run `just ui-lint` and `just ui-format` before committing frontend changes
- Strict TypeScript — no `any` types without justification

## Hot Reload Rules

**CRITICAL:** Know when to rebuild vs rely on hot reload.

| Change Type | Action Required | Command |
|-------------|-----------------|---------|
| `src/backend/*.py` | None — auto reload | (wait ~1s) |
| `src/backend/requirements.txt` | Regenerate lock + rebuild | `just lock-backend && just api-rebuild` |
| `src/frontend/src/**/*` | None — Vite HMR | (wait ~1s) |
| `src/frontend/packages/azblink-ui/**/*` | None — Vite HMR | (wait ~1s) |
| `src/frontend/package.json` | Rebuild UI | `just ui` |
| `deploy/dev/Dockerfile.*` | Full rebuild | `just up` |
| `deploy/dev/docker-compose.yml` | Restart stack | `just down && just up` |
| Added/deleted/renamed route file | Regenerate routes | `just ui-routes` |
| `src/backend/schemas/*.py` (request model) | Refresh contract baseline + regen frontend types | `just openapi-accept && just ui-types` |

**WARNING:** Do NOT use `npx tsr generate` — that resolves to `ts-remove-unused`, a different package entirely. Use `just ui-routes` or `npx @tanstack/router-cli generate`.

## Frontend Development

**Stack:** Vite 6, React 19, TanStack Router, TanStack Query, Zustand, @azblink/ui (Base UI + CSS Modules), Tailwind CSS 4

```bash
just ui-dev         # Dev server at http://localhost:3000 (proxies /api)
just ui-routes      # Regenerate route tree
just ui-types       # Regenerate api.gen.ts from tests/contract/openapi.baseline.json
just ui-lint        # Lint
just ui-format      # Format
just ui-build       # Production build
```

**Key directories:**
- `src/frontend/src/routes/` — File-based routing (TanStack Router)
- `src/frontend/src/components/features/` — Domain components (Tailwind utilities)
- `src/frontend/src/hooks/` — Custom hooks (5 total)
- `src/frontend/src/lib/queries/` — TanStack Query hooks (24 query/mutation files)
- `src/frontend/src/lib/` — Core utilities: `api-client.ts`, `oidc.ts`, `errors.ts`, `version.ts`
- `src/frontend/src/stores/` — Zustand stores: `auth-store.ts`, `ui-store.ts`
- `src/frontend/src/types/` — TypeScript types (from API contracts)
- `src/frontend/packages/azblink-ui/` — @azblink/ui design system (npm workspace package)

**Component rules:** See `.claude/rules/frontend-components.md` (loaded automatically when editing frontend files).

**Design docs:**
- Historical product/spec docs: `docs/archive/` (read-only)

## Repository Structure

```
azblink-AD/
├── docs/
│   ├── architecture/               # Spec (8 sections, versioned), ARDs, SOP, surfaces.yaml
│   ├── archive/                    # Historical docs (read-only, do not edit)
│   ├── knowledge/                  # Auto-generated knowledge snapshots
│   └── reports/                    # Generated reports (dead-code, QA coverage, etc.)
├── src/
│   ├── backend/                    # FastAPI (23 modules + routers/; partial list)
│   │   ├── _version.py                  # Version info
│   │   ├── main.py                     # App composition only: lifespan, middleware order, exception handlers, router registration
│   │   ├── routers/                    # The route handlers (15 modules; registration order is load-bearing)
│   │   ├── config.py                   # Environment config (pydantic-settings)
│   │   ├── oidc_verify.py              # OIDC token verification (PyJWT)
│   │   ├── authentik_client.py         # Authentik Admin API client
│   │   ├── ldap_client.py              # LDAP CRUD + UC attr builder
│   │   ├── orgdb.py                    # PostgreSQL OrgProfile + profile_services operations
│   │   ├── settingsdb.py              # Settings DB (json: prefix encoding)
│   │   ├── provisioning.py             # UC resource allocation
│   │   ├── response_utils.py           # Response shaping + exception-to-HTTP mappings
│   │   ├── rate_limit.py               # Rate limiting
│   │   ├── activity_bus.py             # WebSocket/SSE event bus
│   │   ├── uc_client.py                # UC service client
│   │   └── uc_validation.py            # UC input validation
│   ├── frontend/                   # React admin UI (Vite + @azblink/ui)
│   └── cli/directoryctl.py         # Status CLI
├── deploy/dev/                     # Docker Compose dev environment
│   └── authentik-seed/             # Authentik IdP bootstrap
├── migrations/                     # SQL migrations (004–031), applied by src/backend/db/migrate.py
├── tools/                          # arch_guard.py, dead-code scripts, XMPP e2e notebook, SSO provision ref
├── tests/                          # Integration tests (41 files, real Docker stack)
└── .claude/
    ├── rules/                      # Path-scoped rules (frontend, authentik, MCP tools)
    └── skills/                     # patrol-{investigate,verify}, qa-azblink, web-configure
```

## Architecture (Quick Reference)

> **Full specification:** `docs/architecture/README.md` — 8 sections, versioned (SemVer), with ARD decision records.

- **Single LDAP** (ARD-001): One LDAP holds identity + UC attrs on same DN. `userPassword` = login + XMPP bind. `AstAuthPassword` = SIP digest only.
- **Dual Auth Planes**: Plane A (UC/LDAP bind — always available) + Plane B (Authentik OIDC — web admin UI).
- **Profile + Services** (ARD-004, spec §05): `config_templates` = named container with UID range + device cap. `profile_services` = child records per service type (XMPP, SIP, future) with own config JSON + counters.
- **Device Provisioning** (spec §05): Token-based device provisioning tracked in `device_provisions`.
- **Authentik-Only Auth** (ARD-002): No LDAP JWT, no breakglass. `DEV_AUTH_TOKEN` for dev/test only.

**ARDs:** ARD-001 … ARD-020 in `docs/architecture/decisions/` (ARD-016 is reserved, no file) — that directory is the list, deliberately not re-enumerated here. Only ARD-015 (VM host bootstrap ISO) is still `status: proposed`; the other eighteen are accepted. Check the `status` frontmatter before treating one as binding.

**When modifying architecture:** Follow `docs/architecture/SOP.md` — update spec sections, bump version, add CHANGELOG entry. For significant changes, create an ARD.

## Key Environment Variables

```bash
# LDAP
LDAP_URI=ldap://openldap:389
LDAP_BASE_DN=dc=azblink,dc=com
LDAP_BIND_DN=cn=admin,dc=azblink,dc=com
LDAP_BIND_PW=adminpassword
LDAP_CLIENTS_OU=ou=clients,dc=azblink,dc=com          # provisioned client accounts subtree

# OIDC (backend — Docker-internal)
OIDC_ISSUER=http://authentik-server:9000/application/o/azblink-directory/
# OIDC_ACCEPTED_ISSUERS — comma-separated, both Docker-internal + Cloudflare tunnel URLs

# OIDC (frontend — browser-accessible)
VITE_OIDC_ISSUER=https://authentik.keithmoc.dev/application/o/azblink-directory/

# Authentik IdP
AUTHENTIK_BOOTSTRAP_PASSWORD=adminpassword
AUTHENTIK_BOOTSTRAP_TOKEN=dev-authentik-api-token

# Device provisioning
DEVICE_PROVISION_TTL_SEC=2592000          # 30 days default
DEVICE_PROVISION_MAX_EXTEND_SEC=86400     # 1 day max extension
SIP_AUTH_REALM=asterisk
```

## Database Migrations

Fresh deployments don't need migrations — tables are created on startup. Upgrades are the
converge's `migrate.yml`, which runs `python -m db.migrate /migrations` (`src/backend/db/migrate.py`)
before the new API starts: a ledger (`schema_migrations`), files up to `029` taken as the baseline,
one transaction, refuses a schema it cannot migrate. Do not replay every file by hand: `025` fails
on a current schema. Operator steps: `deploy/ansible/README.md` § Upgrading an install; proof:
`tools/upgrade_drill.py` (workflow `upgrade.yml`).

New migration files (after `029`) must be idempotent (`IF NOT EXISTS`) and must not `BEGIN`/`COMMIT`.

## PR Review Gate

All PRs must pass code review before merging:
- Automated reviews (CodeRabbit, CI checks) must be addressed — fix valid findings, dismiss false positives with justification
- Run `/review` before `/ship` to catch structural issues tests miss
- Pin dependency versions when importing specific sub-module APIs (e.g., `PyJWT>=2.6.0` for `PyJWKClientConnectionError`)
- Strip internal infrastructure details from user-facing error messages (hostnames, ports, stack traces)

## Spec-Driven Development Workflow

1. **Architecture spec:** `docs/architecture/README.md` (authoritative as-built source of truth; versioned SemVer; SOP at `docs/architecture/SOP.md`)
2. **ARDs:** `docs/architecture/decisions/` (immutable decision records — append-only amendments)
3. **Proposals:** `docs/architecture/proposals/` (forward-facing pre-ARD designs)
4. **Implement against the spec + its ARDs.**
5. **After changes:** update affected spec sections, bump `spec-meta.version` per `docs/architecture/SOP.md`, add `ARD:` or `Spec-Patch:` commit trailer.
6. **Historical:** `docs/archive/` — read-only, not current. Do not edit.

## Architecture Commit Trailers

Architectural changes (edits to surfaces listed in `docs/architecture/surfaces.yaml`) must carry one of:

- `ARD: ARD-NNN` — references an accepted (or proposed during PR-1 of §6.1) ARD whose `spec_sections_affected` covers every touched surface.
- `Spec-Patch: NN[,MM,…]` — non-decisional edits to listed spec section(s). May not assert new behavior. Covers a surface only when the named section file is actually edited in the same diff.
- `Spec-Patch: SOP` — the same lane for `governance_metadata` and `ci_release_gates`, which map to the literal section `SOP`. Requires editing `docs/architecture/SOP.md`.
- `ARD-POST: placeholder` — emergency lane. CI files an `arch-post-followup` tracking issue; resolve within 7 days.

The guard (`tools/arch_guard.py`) runs in **fail mode** — a PR touching a surface without covering trailer coverage fails the `arch-guard` check. See `docs/architecture/SOP.md § Enforcement`. Note the check is not yet a *required* status check: branch protection is unavailable on this repo's plan (SOP.md § Known enforcement gap), so the failure is visible but does not itself block the merge button.

Local helpers:
- `just arch-guard-setup` — install pinned guard deps (matches CI).
- `just arch-guard` — run the guard against the current staged diff.

**CLAUDE.md § Architecture (Quick Reference)** is conceptually a surface — edits in that section should carry the same trailer as code edits. (Anchor-scoped enforcement lands in Phase 1b; today the whole file triggers the workflow but is not trailer-gated.)

<!-- ctx-system:code-search-policy — provenance marker; install.sh greps for it to stay idempotent. -->
## Code search policy
Built-in Grep/Glob/find are disabled. Use `mcp__ctx-router__code_search`, `find_symbol`, `impact`.
They merge the prebuilt base index (clean files) with your live edits (dirty files). Read only the
file:line anchors they return.
