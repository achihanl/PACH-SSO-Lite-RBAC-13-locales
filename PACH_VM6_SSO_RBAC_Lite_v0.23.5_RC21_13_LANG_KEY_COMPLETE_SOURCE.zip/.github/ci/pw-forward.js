// Runs inside the Playwright browser container (qa.yml). Listens on the
// container's loopback for each port in FWD and pipes it to the same port on
// the runner host, so the browser keeps using http://localhost:<port> — same
// URL, same Host header, same OIDC redirect URIs — while living in its own
// network namespace, out of reach of the host's interface churn.
const net = require("net");

for (const port of process.env.FWD.split(" ")) {
  net
    .createServer((client) => {
      const upstream = net.connect(port, "host.docker.internal");
      client.pipe(upstream).pipe(client);
      upstream.on("error", () => client.destroy());
      client.on("error", () => upstream.destroy());
    })
    .listen(port, "127.0.0.1");
}
