# TODOS

Deferred engineering work with full context. Items here have been considered and explicitly scoped out of a prior PR, not forgotten. Read the "Why" and "Context" before picking any item up.

---

## Web SSO Provision Debugger — upgrade to full browser-flow CI regression

**What:** Extend the web SSO provisioning debugger (`tools/web-sso-provision-ref/`) into a CI regression test that drives the real user-driven browser OIDC flow end-to-end, replacing the Marimo notebook's M2M `client_credentials` shortcut as the browser-layer regression test. Current artifact stops at "credentials unsealed and displayed"; the upgrade adds automation that also verifies XMPP/SIP auth succeeds with those credentials.

**Why:** The current Marimo notebook (`tools/e2e_xmpp_notebook.py`) runs headless in CI but acquires OIDC tokens via Authentik's M2M `client_credentials` grant, not the real user-driven browser redirect flow. A green notebook does not prove PKCE, redirect URI registration, consent screen behavior, session cookies, or the `authorization_code` exchange actually work. The current Approach A debugger exercises the real flow but only via manual runs. This upgrade closes the CI gap.

**Pros:**
- Retires the notebook's false-positive risk for browser-OIDC bugs
- Mobile team regressions caught in CI, not during mobile integration
- Single authoritative end-to-end test for the mobile SSO path (browser layer)

**Cons / risks:**
- Authentik consent screen automation in CI is flaky (cookie banners, token storage, redirect timing)
- Requires either marking the `azblink-directory` app as "trusted" (affects all consumers) or creating a separate `azblink-directory-ci` OAuth2 provider
- Scope: a full upgrade also requires browser-side or CI-side verification that the unsealed credentials actually authenticate against XMPP/SIP. Two sub-paths: (a) extend the browser debugger to include strophe.js and connect (re-adds the scope we cut on 2026-04-14), or (b) have the Playwright spec scrape the displayed credentials and shell out to a Python script that feeds them into `slixmpp` for the XMPP auth check.

**Context:** Decision made in office-hours design session 2026-04-14, then scope-reduced further the same day. The original plan was to include XMPP connect + messaging in the web client. That was cut — the debugger now stops at credential display, and XMPP/SIP verification is handled externally via (a) the Python notebook for CI-automated verification at the Python layer, and (b) the XMPP/SIP engineer's manual/CLI verification with the debugger's copy-to-clipboard credential kit.

**Triggers for reopening:**
- The minimal render smoke test starts passing while manual runs fail (indicates the smoke is too shallow)
- Mobile team asks for CI-gated browser-OIDC verification
- An XMPP-layer regression bites in production that a browser-flow test would have caught
- The XMPP/SIP engineer asks for CI coverage of their credential-consumer path that doesn't duplicate the Python notebook

**Depends on / blocked by:**
- Shipping and stabilizing the Approach A debugger first
- External XMPP server (192.168.122.89) being reachable from CI runners, or a dockerized XMPP server added to the CI pipeline
- Authentik CI automation strategy decision (trusted app vs separate provider vs seeded session cookie)
- Decision on sub-path (a) browser connects XMPP vs (b) Playwright scrapes and shells out to Python — prefer (b) since it preserves the debugger's scope discipline and reuses notebook code

---

## Frontend: refresh stale OIDC token before dashboard fanout

**What:** In `src/frontend/src/lib/oidc.ts` / `api-client.ts`, detect expired access tokens *before* firing requests and either refresh or redirect to `/login` instead of letting 5 parallel dashboard queries blast the backend with a known-bad token.

**Why:** Dashboard mount triggers ~5 TanStack Query calls in parallel (`/dashboard/stats`, `/dashboard/chart`, `/dashboard/health`, `/provisions/pending`, `/activity/recent`). If the token is stale, pre-fix behaviour produced 5 audit rows + instant `ACCOUNT_LOCKED` for the user (threshold is 5). Backend PR (fix D, this commit) dedupes by token fingerprint so one stale token = 1 failure — but the client is still firing garbage requests and seeing 5× 401s. Client-side check fixes the real source.

**Pros:**
- Eliminates spurious 401 spam in backend audit log
- Better UX: one redirect instead of 5 failed queries → "unauthenticated" banner
- Removes reliance on the backend dedup as a safety net

**Cons / risks:**
- Clock-skew edge cases: treating a token as "expired" on the client vs backend validator
- Need a single choke-point interceptor so every query goes through the check

**Context:** Triggered 2026-04-15 when `akadmin` auto-locked from one stale-token dashboard refresh (5 endpoints in 466ms). Immediate fix shipped as backend dedup. This TODO is the root-cause cleanup.

**Depends on / blocked by:**
- None — can proceed any time

