# VM6 v0.21.2 Step 3 — Development Candidate

Baseline: v0.21.1 Step 2 consolidated source. All previous files retained.

Added `src/backend/routers/application_integration.py` for user-bound cross-application role lookup restricted to the token's registered OIDC client.
Extended `db/applications.py` with ready-client lookup and atomic application/client/role decision.
Extended `oidc_verify.py` dynamic issuer/audience allowlisting for ready enabled OIDC applications (fail-closed).
Registered new router without touching old endpoints.
Added contract and unit tests.

No schema migration required for Step 3. No new directory, general-purpose policy engine, machine credentials or SIP/XMPP provisioning flows introduced.

Remaining: live tests and project dependency installation; Step 4 LDAP and reference VM integration approach; Step 5 security regression and production readiness.
