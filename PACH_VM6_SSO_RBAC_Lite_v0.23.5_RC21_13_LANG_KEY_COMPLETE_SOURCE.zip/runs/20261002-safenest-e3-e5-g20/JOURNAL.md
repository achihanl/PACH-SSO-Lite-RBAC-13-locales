# JOURNAL

Append-only. One entry per session. Decisions use: rule, worst case, revert.

## 2026-10-02, session 4

Reconcile: `main` = `1d821e4`, stack up 3 weeks, only `HANDOFF.md` dirty (session 3 notes).
Authentik 2026.5.2.

### Probe facts (live dev stack)

- `default-authentication-flow`: identification(10, no inline password, no captcha) →
  password(20, backends Inbuilt/Kerberos/LDAP/Token, `failed_attempts_before_cancel` 5) →
  mfa-validation(30, `not_configured_action: skip`, all device classes) → login(100).
  Password and MFA bindings carry expression policies (skip password if already authenticated;
  skip MFA for passwordless webauthn).
- Policy bindings target a flow-stage binding by the binding's own `pk`
  (not `policybindingmodel_ptr_id`); `?target=` filter rejects it, list all and filter.
- G2: Authentik 2026.5 default `listen.trusted_proxy_cidrs` = 127/8, 10/8, 172.16/12,
  192.168/16, fe80::/10, ::1. So any container on a docker network can set XFF.
- Reputation (`authentik/policies/reputation`): score row per (identifier, ip); policy sums
  rows for `identifier=username` (and/or ip) and **passes when sum <= threshold**.
  Failed password −1, failed identification −1, successful login +1, clamped per row to the
  tenant's `reputation_lower_limit`/`reputation_upper_limit` (−5/+5). `expires` is set at row
  insert only (default 86400 s), not refreshed on update.
- Password stage cancels the flow when `initial_score - new_score >= failed_attempts_before_cancel`,
  where `initial_score` is read after the first failure. So N allows N+1 failures per executor
  session, and a deny stage placed before the password stage is not re-checked between retries
  inside one session.
- ppolicy: `pwdMaxFailure 5`, `pwdLockoutDuration 300`, `pwdFailureCountInterval 0` (failures
  only clear on a successful bind).

### Decisions

- **D1 Order E3 → E5 → G20.** Rule: a security policy is bound to the flow it will live on;
  E5 binds to the shared flow (ARD-018), and binding it to the default flow would also
  throttle admin web login. Worst case: E5 (blocks real users) lands a few hours later.
  Revert: none needed.
- **D2 Run state in `runs/20261002-safenest-e3-e5-g20/`**, root `HANDOFF.md` stays the handoff.
  Rule: durable-run needs committed state; root HANDOFF is where the next session already looks.
  Worst case: two handoff-like files drift. Revert: delete `runs/`.
- **D3 E3 flow uses its own stages**, not the default flow's stage objects. Rule: ARD-018
  "isolated from brand-flow edits". Worst case: a later fix to a default stage is not
  mirrored. Revert: delete the flow + four `headless-first-party-auth-*` stages; providers
  fall back when `authentication_flow` is PATCHed to null.
- **D4 MFA stage keeps every device class**, webauthn included, though a relay cannot do
  webauthn. Rule: fail closed (rule 5); dropping a class would let a user enrolled only in that
  class skip MFA. Worst case: webauthn-only users cannot use a relay and go to web sign-in.
  Revert: edit `device_classes` in `ensure_headless_flow()`.
- **D5 Flow created only when `AUTHENTIK_FIRST_PARTY_CLIENTS` is non-empty.** Rule: YAGNI.
  Worst case: none (no clients, no relays). Revert: drop the `if`.
- **D6 ARD-018 summary/References not edited for E3.** arch-guard `ard-immutability` rejects
  any change above `## Amendments` on an accepted ARD. The README ARD row carries `#336`.

### M1 E3 evidence

- Seed run 1: created flow + 4 stages + 4 bindings, patched `safenest-dev`
  `authentication_flow`. Run 2: no creates, provider "already current".
- `pytest tests/test_headless_first_party_login.py`: 8 passed (75 s), 7 old + MFA test.
- Mutation: unbound the MFA stage → MFA test failed (`'xak-flow-redirect' ==
  'ak-stage-authenticator-validate'`); the next seed run re-bound it.
- Unit: `tests/unit/test_authentik_seed_*`: 13 passed. ruff (CI selection) clean,
  docs lint clean, `just arch-guard` clean.
- G3 probe: TOTP enrol via `default-authenticator-totp-setup` needs the `X-authentik-CSRF`
  header (session is authenticated); validate-stage POST before login does not.
  Admin device create (`/authenticators/admin/totp/`) answers 405 on 2026.5.

### M3 G20 (done before M2 while the E5 advisors ran; branch stacked on E3)

- **D7 G20 reuses the seed on the prod path**, not a separate ansible Admin-API task.
  Fact: `authentik-seed` has no compose profile, so `COMPOSE_PROFILES=prod docker compose
  -f docker-compose.yml -f docker-compose.prod.yml config --services` lists it; spec 06's
  "seed does not run on the prod path" was stale (only the demo `seed` is dev-only). Rule:
  reuse what exists (one registration path for dev and prod). Worst case: a bad inventory
  value makes the seed exit non-zero (`parse_first_party_clients` raises) → `verify.yml`
  times out and the converge fails loudly; nothing half-registered. Revert: empty
  `authentik_first_party_clients` (seed stops creating; existing providers stay until deleted
  in Authentik) or revert the PR.
- **D8 Verify waits per client provider** with an exact `client_id` match (Authentik list
  filters are not trusted, see `find_application()`). Worst case: +retries×delay on a broken
  seed. Revert: drop the task.
- Evidence: `render_check.py` (scratchpad) renders `env.j2` through ansible with the dev
  inventory, with no clients and with two, then runs `docker compose --env-file <rendered>
  config authentik-seed`: compose passes the seed exactly the inventory dict in both cases
  (empty → `''`, which the seed parses as no clients). `ansible-playbook --syntax-check`
  clean. Docs lint clean.

### M2 E5 design: adversarial review and reconciliation

Advisors (read-only, opus): `agents/e5-redteam.md` (ACCEPT-WITH-CHANGES), `agents/e5-architect.md`
(agree with tuned proposal). SafeNest's own phase-2 review independently flagged the banked-success
hole (k prior sign-ins add up to +5, so LDAP locks first).

Live probes this session:
- Red-team #1 **confirmed** (`probe_toctou.py`, scratch flow, local user): with a deny stage before
  the password stage, a session staged before the score dropped still reached the bind
  (score −1 → −2). With the reputation policy **negated on the password binding** plus a deny stage
  guarded by `"user_backend" not in request.context`, the same session got `ak-stage-access-denied`
  and no bind. The architect's order-15 design keeps the hole, so the red-team placement wins.
- G2 baseline: spoofed XFF from the host (172.20.0.1, inside 172.16/12) was recorded as the client IP.
  With `AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS=127.0.0.1/32,::1/128` (comma form; only the Go server
  reads it) the spoof is ignored (recorded 172.20.0.1) and XFF from loopback inside the container is
  still honoured (positive control).
- Expired reputation rows are hidden by `ExpiringManager`, still absorb upserts, and are deleted by
  `clean_expired_models` every 5 min (`2-59/5`).

Decisions:
- **D9 Mechanism stays ARD-018's reputation policy** (username, `check_ip: false`, threshold −3).
  Both advisors agree; no mechanism amendment. Worst case: residuals below. Revert: delete the
  policy binding on the password stage.
- **D10 Check on the password stage's own binding (negated) + fail-closed deny guard at 25**, not a
  deny stage at 15. Rule: a check must run on every request that can reach the LDAP bind (verified
  live). Worst case: a reputation-policy error skips the password stage and the guard denies the
  login (fail closed). Revert: remove both policy bindings.
- **D11 `reputation_upper_limit: 0` tenant-wide, positive rows deleted.** Rule: banked successes must
  not buy extra failures (advisors + SafeNest). Worst case (R2): successes no longer heal, so 3 typos
  within a row's 24 h lifetime block that username until expiry or an admin deletes the rows.
  Revert: PATCH `/admin/settings/` back to 5.
- **D12 `failed_attempts_before_cancel` stays 5.** With the per-request check the limit is ~3 in total,
  not per session; 1 would change the first-failure response for redirect-following clients
  (red-team #6). Revert: n/a.
- **D13 Distinct throttle message**, not "Invalid password" (architect). Rule: a user with the right
  password must be told to stop and use web sign-in / an admin, or they will reset a password that
  is not the problem. Enumeration already leaks via R4. Revert: edit `deny_message`.
- **D14 Trusted proxies default `127.0.0.1/32,::1/128`**; relays added as /32. Worst case: web users via
  the tunnel are audited under cloudflared's IP (no IP-keyed policy exists). Revert: set
  `AUTHENTIK_TRUSTED_PROXY_CIDRS`.
- **D15 No ppolicy change in E5** (`pwdMaxFailure`, `pwdFailureCountInterval`). Rule: an LDAP-wide
  posture change (XMPP/SIP too) and raising `pwdMaxFailure` contradicts ARD-018's "below 5" text →
  owner + amendment. The guarantee is stated as **sequential** relay traffic. Revert: n/a.
- **D16 Default flow not throttled in E5** (red-team #2): it is the brand/admin web login; a 24 h
  no-heal block there is an owner call. Recorded as a new gap.
- **D17 Admin unblock = runbook** (delete the username's reputation rows; for an LDAP lock clear
  `pwdAccountLockedTime`/`pwdFailureTime`). No new API.

Residuals recorded for the spec/gap report: R1 row expiry vs ppolicy interval 0 (after a row's 24 h
an attacker gets 2 more failures → LDAP lock), R2 no healing, R3 non-Authentik LDAP paths, R4 count
oracle (unknown id −2 per attempt), R5 zombie window (≤5 min after expiry, no counting), R6 parallel
requests all pass the check (≤ server concurrency), R7 default flow unthrottled.

### SafeNest dev users (peer request)

- **D18 Provision SafeNest's 4 dev users + `safenest-dev-{resident,staff,admin,visitor}` in the local dev
  stack through the directory API** (not the seed). Rule: decision 19 (azb-AD creates role groups via
  `/api/groups`); dev-only data, passwords are SafeNest's documented dev ones. Worst case: dev UC
  resources allocated for 4 demo users. Revert: `DELETE /api/users/<uid>`, `DELETE /api/groups/<cn>`.
  Evidence: `verify_dev_users.py`: each logs in through the headless flow, token `groups` =
  `["safenest-dev-<role>"]`.

### /security-review (E5 + G20 branch)

Sub-task review: no High/Medium finding at >= 8/10. Two items below the bar, both fixed:
- Transition bypass (reviewer ~5/10): a flow plan stored in a session before E5 has no deny stage;
  once the negated reputation policy skips its password stage, MFA (no device) and user-login run →
  logged in without a password. **Confirmed live** (`probe_stale_plan.py`): with the deny binding
  removed and no login guard, a throttled local user got an authorization code with no password.
  - **D19 Guard on the user-login binding** (`"user_backend" not in request.context`, negated,
    failure_result False → login skipped on error). Rule: never rely on plan shape for an auth
    decision; the stage that creates the session checks the password passed. Same probe with the
    guard: no code. Worst case: none for legit logins (password stage always sets user_backend).
    Revert: delete that policy binding (do not, while the reputation binding exists).
- Low: `verify.yml` per-client provider task would print `client_secret` under `-v` → `no_log: true`.

Evidence: unit 10 passed (guards at 25 and 100 asserted), `tests/test_headless_first_party_login.py` 10 passed.

### Session 4 close

Merged: #336 E3 (`6a64d34`), #337 G20 (`5ee8f3b`). Open: #338 E5 (+ `/security-review` fix, rules doc).
SafeNest told: E3 sha, dev users, throttle shape (mapped on their side, `d971787`). Owed: E5 sha.
Root `HANDOFF.md` rewritten. No retry cap hit; no milestone stalled.

### Run complete (2026-10-03)

- #338 E5 merged `16a80bd` after CI confirmed the 10 headless tests ran and passed (639 passed overall).
  SafeNest sent the sha; throttle text unchanged. All PLAN milestones checked.
- **D20 Public dev-Authentik exposure (SafeNest report): escalate, do not change.** Rule: the fix is
  outward-facing (Cloudflare tunnel owned by another project) or rotates credentials wired through
  the dev toolchain; owner decision. Worst case while open: anyone reading the repo administers dev
  Authentik via the tunnel. Revert: n/a (no change). Push notification sent; HANDOFF top item.
