# E5 red-team review

## Plan

Read the executor, planner, markers, password, identification and deny stages, the reputation code, ExpiringManager, ClientIPMiddleware and the cleanup schedule in the `azblink-authentik-server` container. Inspect the live config with read-only GETs. Attack the invariant with sequential attacks, then concurrent ones.

## Log

- `GET /flows/bindings`: both flows' password stages use `LDAPBackend`. `default-authentication-flow` has no reputation policy and `failed_attempts_before_cancel: 5`. Tenant limits are -5/+5. There are 0 reputation policies.
- Score rows show relay probes arriving as `172.21.0.1` (the gateway of the relay's network) and host traffic as `172.20.0.1`.
- No writes were made and no login attempts were run.

## Result

**1. CRITICAL: the check runs once per session, so sessions can be pre-staged (TOCTOU).** `plan.next()` evaluates the marker of `bindings[0]` only, on each request (`flows/views/executor.py:208`, `flows/planner.py:94-112`). The Deny stage's marker runs on the one request that lands on it. If it passes, the binding is removed and the session is saved (`markers.py:67-75`, `planner.py:106`, `executor.py:180`, `root/middleware.py:118`), and it is never checked again.
Attack: open K cookie jars. In each, POST the identification for the victim and GET once; the score is 0, so the deny stage is dropped. Then POST 2 wrong passwords in each jar without a GET in between. With K=3 that is 6 LDAP failures, so LDAP locks and XMPP goes down. Jars stay valid for `unauthenticated_age: days=1` (`lib/default.yml:93`). Pre-staging about 150 jars allows about one guess every 5 minutes once each lock expires, roughly 288 guesses per day instead of 3.
Fix: put the check on the password stage's own binding, which is re-evaluated on every POST before the bind:
- Password binding (order 20): the reputation policy, **negated**.
- Deny stage at order 25 with `re_evaluate_policies`, plus an expression policy `return "user_backend" not in request.context`. The password stage sets `user_backend` only on success (`stages/password/stage.py:33,131`).

If the password stage is skipped, the request fails closed into Deny in the same request and never reaches the bind. This also makes `failed_attempts_before_cancel: 1` unnecessary: the limit becomes about 3 failures in total, not per session. Drop the order-15 deny.

**2. HIGH: `default-authentication-flow` is an open LDAP-lockout path.** Its password stage includes `LDAPBackend`, has no reputation check, and the flow restarts indefinitely. Anyone who can reach port 9000 or the tunnel can lock any user with 5 POSTs. Done-criterion 2 holds only for relay traffic.
Fix: apply the same binding and guard from #1 to this flow. Its password binding already has `default-authentication-flow-password-stage`, so set that binding's `policy_engine_mode` to `all`. Under `any`, the new check is a no-op.

**3. HIGH: concurrency defeats any Authentik-side check.** K parallel password POSTs all pass the marker before any `login_failed` lands. Within one session, `initial_score` is read and written without a lock (`stage.py:167-172`). K is bounded only by server concurrency: 2 workers × 4 threads = 8 per replica (`default.yml:162-163`). With at most 2 earlier failures plus 8 concurrent ones, LDAP locks.
Fix: give LDAP a margin, `pwdMaxFailure` ≥ deny-at + 8×replicas + 1 (for example 12). The ARD treats this as parameter tuning, not a mechanism change. An alternative is to limit the headless flow to relay CIDRs and add a per-username mutex in the relay, but #2 still needs the margin.

**4. MEDIUM: expired "ghost" rows break R1 harder than stated.** `ExpiringManager` hides rows where `expires<now` (`core/models.py:1138-1139`). The upsert still writes to them, and it never refreshes `expires` (`policies/reputation/signals.py:29-46`). The rows are deleted only every 5 minutes (`core/apps.py:57-59`).
For up to 5 minutes, failures are invisible to both the policy (`reputation/models.py:53-55`) and the cancel counter (`stage.py:157-163`), so there is no limit at all. The attacker knows the timing because they set T0. If the relay forwards client XFF, the attacker can plant rows under chosen IPs and schedule several ghost windows.
Fix: set `pwdFailureCountInterval` (for example 3600, well below the 86400 reputation expiry) so LDAP forgets before Authentik does. This closes R1 and limits ghosts to one 5-minute LDAP lock.

**5. MEDIUM: R2 is wrong.** With `upper_limit=0`, a success adds `min(0, 1) = 0` (`signals.py:27`). A successful login never unblocks a user, and the user's own typos pile up across successful logins for 24 hours. Admin deletion of scores resets Authentik but not LDAP (which has interval 0), which re-arms a lock.
Fix: the unblock runbook must also clear `pwdFailureTime`, or adopt #4.

**6. MEDIUM: the relay-contract claim depends on the HTTP client.** A `stage_ok` redirect to the same URL is returned as a raw 302 (`executor.py:552-553`). A client that follows it GETs the challenge, which persists `initial_score` (`stage.py:153-154`). With cancel=1, the **first** wrong password then returns AccessDenied, not `invalid` (`stage.py:172-174`). The brief's N+1 measurement implies a client that does not follow redirects.
Fix: with #1 in place, keep cancel at ≥3 and test with the real relay client.

**7. LOW: R4 understates enumeration.** An unknown identifier loses 2 points per attempt: `identification_failed` (`identification/stage.py:180`) and `login_failed` (`stage.py:66`). It is denied on attempt 2, while a real user is denied on attempt 4. Existence leaks at the cost of one LDAP failure for a real user. Document it.

**8. LOW: `check_ip` defaults to True** (`reputation/models.py:32`). If the seed omits `check_ip: false`, every relay user's failures sum together on the shared relay-IP row, and one attacker can block all of them. Assert it in the seed test.

**9. LOW: XFF.** Python trusts `XFF[0]` without checks (`root/middleware.py:197-204`). The relay must **overwrite** XFF with the peer IP it observes, not append to it, or the attacker chooses the IP on reputation rows (which feeds #4). In dev, the relay's egress is its network gateway (`172.21.0.1`), shared by every container on that network.

**Residuals:** R1 holds and is worse (see #4). Likely, though not verified against ppolicy here: once LDAP has 5 stored failures with interval 0, every later single failure re-locks it. R2 is false (#5). R3 holds, but `default-authentication-flow` is not an "other path": it is an Authentik path with no throttle (#2). R4 is understated (#7). The stated invariant fails because of #1, #3 and #4.

**Verdict: ACCEPT-WITH-CHANGES.** The username-keyed mechanism holds; the binding placement does not. Mandatory before real users:
- (a) #1: move the check onto the password binding, with a fail-closed `user_backend` Deny guard.
- (b) #2: apply the same to `default-authentication-flow`, with `policy_engine_mode: all`.
- (c) #3: raise LDAP `pwdMaxFailure` above deny-threshold + server concurrency, and #4: set `pwdFailureCountInterval`. Both are owner LDAP decisions, but without them done-criterion 2 cannot be met.
- (d) Tests for the pre-staged-sessions attack and a parallel burst of 8.
