# E5 architect review

## Plan

1. Sketch a design from Goal + Facts only.
2. Check the facts against the Authentik 2026.5.2 source in `azblink-authentik-server`, plus read-only API GETs.
3. Compare the sketch with the proposal and answer Q1–Q5.

## Log

**Sketch, written before reading the proposal.** A Deny stage between identification and password, gated by a username-only reputation policy at threshold −3. It must not be a negated policy on the password binding, because skipping that stage logs the user in. `check_ip` stays off: all relay traffic shares one egress IP, so an IP key would block every user. Rows are per (identifier, IP) and their scores are summed, and the upper limit applies to each row. Any positive row therefore buys extra binds, so `reputation_upper_limit` must be 0. Retries inside one session skip the gate, so the per-session cap has to be ≤ 2. I suspected the 24 h expiry breaks "never".

**Checked against the source:**

- `update_score` clamps the *amount* too: `amount = max(lower, min(upper, amount))`. With upper limit 0, a successful login adds **0**. Proposal R2 says a success raises one row by 1; that is wrong. Recovery is row expiry or an admin only.
- `ExpiringManager` hides expired rows as soon as they expire. `clean_expired_models` deletes them on cron `2-59/5`. The upsert (`on_conflict … update_values={score}`) never refreshes `expires`. So for up to 5 minutes after expiry, new failures land in an invisible row. In that window the Deny gate sees 0, and the password stage's `initial − new` stays 0, so the session never cancels. **This is a new residual, R5.**
- `initial_score` is set in `get_challenge`, but GET never re-saves the plan: the session is saved only when `modified`, and `stage_ok` is the only place that reassigns it. This fits the brief's measured "N+1". The per-session cap therefore depends on the POST path persisting the session as a side effect. Nothing guarantees that.
- `failed_attempts_before_cancel` is an IntegerField. At 0, `initial − new >= 0` is always true, so the first wrong password cancels the flow, which breaks E4 `test_bad_password_is_invalid`.
- `default-authentication-flow`'s password stage also has the LDAP backend, with N = 5. Anyone can lock LDAP through it in a single session. There are no other reputation policies, so setting the upper limit to 0 has no blast radius today.
- With `pretend_user_exists`, an unknown user's attempt sends **both** `identification_failed` and `login_failed` (−2 per attempt). Unknown users are denied after 2 attempts and real users after 3, so the count reveals whether a username exists. R4 is real, and its signal is the count more than the message.
- Parallel sessions all pass the gate before any of them fails (TOCTOU). Five sessions through identification, then five password POSTs, gives 5 binds and a locked LDAP account. Any check-then-bind design inside Authentik has this race.

## Result

The proposal is sound as a guard against **sequential** bursts, which is the ARD-018 G1 intent: a user fat-fingering through the app. Against an adversary, "LDAP never locks" cannot be achieved inside Authentik with any mechanism. Three paths remain: parallel sessions, `default-authentication-flow`, and R1/R5. Only ppolicy can close them. The spec should say the guarantee covers sequential traffic, without promising more.

**Q1, mechanism: keep the reputation policy. No ARD amendment.** An Event-count expression policy (sliding window, insert-only, no clamping, no per-IP rows, no tenant setting) would close R1 and R5. It would not close the parallel-session race or the default-flow path. The per-session cap would still run on Reputation deltas: a row clamped at −5, or a zombie row, means the session never cancels. That is custom expression code plus an amendment for a partial gain. Agree with proposal points (a)1–3.

**Q2: `failed_attempts_before_cancel: 1`. Agree.** 0 breaks the E4 contract. 2 allows 3 failures per session, so a session starting at −2 reaches 5 binds and locks LDAP. 1 is the only value that works. Two conditions:

- The relay contract must say **one password attempt per executor session**. Otherwise failure 3 followed by the right password in the same session succeeds, and done-criterion 1 fails.
- E5 must test the cap directly. In one session, failure 1 returns `ak-stage-password` `invalid` and failure 2 returns `ak-stage-access-denied`. The cap rides on incidental session persistence, and this test catches it if an upgrade changes that.

**Q3, R1: accept and document, with corrected wording.** An attacker does not get "a few locks/day". Once a row expires, they lock LDAP deterministically with 2 failures, again on every row lifetime. Add R5 (zombie window, ≤ 5 min after expiry, no counting and no in-session cap). Leave `AUTHENTIK_REPUTATION__EXPIRY` alone. Successes no longer heal the score, so a longer expiry only lengthens lockouts, and a shorter one creates more epochs.

Setting `pwdFailureCountInterval` stays an owner decision, as proposed. It closes the slow, accidental case (failures spread over days). It does not strictly close R1: with N = 1, two adjacent epochs can put up to 8 relay failures inside one window. Don't try to fix R5 by editing the cleanup schedule: it is a `ScheduleSpec` and is probably reconciled back on startup.

**Q4, trusted proxies: loopback only. Agree, tightened.** Use `127.0.0.1/32,::1/128`. Add each relay as a **/32 with a static IP**. Never add a shared network CIDR or a docker gateway IP: `172.20.0.1` is what every published-port client looks like. Because `check_ip` is off, the relay's XFF changes only audit IPs and which row is keyed, so dev needs no relay entry at all.

**Q5, admin unblock: a runbook line, no new API.** Use Authentik admin, Customization → Policies → Reputation scores, and delete the user's rows. The API equivalent is `GET /api/v3/policies/reputation/scores/?identifier=<username>`, then `DELETE …/scores/<pk>/` for each row. The same runbook entry should cover an LDAP lock: clear `pwdAccountLockedTime` and `pwdFailureTime`.

**Residuals to record:** R1 (corrected), R2 (corrected: successes add 0), R3, R4 (the 2-vs-3 count oracle), R5 (zombie window), R6 (parallel-session race), R7 (`default-authentication-flow` is an N = 5 LDAP-lock path, so gating it with the same policy is a follow-up, not E5).

**Final design (exact settings):**

| Item | Setting |
|---|---|
| Tenant `admin/settings` | `reputation_upper_limit: 0`, `reputation_lower_limit: -5` (unchanged); seed deletes rows with `score > 0` once |
| ReputationPolicy `headless-first-party-auth-username-reputation` | `check_username: true`, `check_ip: false`, `threshold: -3` |
| DenyStage `headless-first-party-auth-throttled` | `deny_message: "Invalid password"` (same text as the password-stage cancel) |
| Deny stage binding | order 15, `evaluate_on_plan: false`, `re_evaluate_policies: true`, policy bound not negated |
| Password stage | `failed_attempts_before_cancel: 1` |
| Compose `authentik-server` | `AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS: ${AUTHENTIK_TRUSTED_PROXY_CIDRS:-127.0.0.1/32,::1/128}` |
| Relay contract | one password attempt per executor session; one in-flight login per username |

**E5 tests:**

1. Three wrong passwords, each in a fresh session, then the right password in a fresh session is denied.
2. The in-session cap test from Q2.
3. `pwdFailureTime` count ≤ 3 and a direct LDAP bind succeeds.
4. Another user is unaffected.
5. Deleting the scores unblocks the user.
