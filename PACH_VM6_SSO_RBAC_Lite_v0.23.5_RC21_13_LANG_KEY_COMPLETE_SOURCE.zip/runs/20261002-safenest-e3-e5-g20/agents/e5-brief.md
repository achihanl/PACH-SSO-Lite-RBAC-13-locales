# E5 design brief (for advisors)

## Goal (gap report row E5, ARD-018 "Lockout", both binding)

Headless first-party clients (e.g. SafeNest) run a backend "relay" that drives Authentik's
flow executor (`/api/v3/flows/executor/headless-first-party-auth/`) with a user's username +
password. Users live in OpenLDAP; Authentik's password stage uses `LDAPBackend`, which binds
to LDAP as the user. OpenLDAP ppolicy: `pwdMaxFailure 5`, `pwdLockout TRUE`,
`pwdLockoutDuration 300`, `pwdFailureCountInterval 0` (failures only clear on a successful
bind). An LDAP lock also kills XMPP for that user (same `userPassword`).

Done when:
1. 3 bad passwords through the relay flow block that username **in Authentik only**
   (4th attempt refused even with the right password).
2. The LDAP account is never locked by relay traffic; a direct LDAP bind still works.
3. Other users are unaffected.
4. `X-Forwarded-For` from an untrusted source is ignored
   (`AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS` = registered relay egress CIDRs).

ARD-018 (accepted, body frozen) says: "Authentik's username-keyed reputation policy on the
shared flow trips at 3 failures, below ppolicy's pwdMaxFailure of 5." Changing the mechanism
needs an ARD amendment; tuning parameters does not.

## Facts measured on the live dev stack (Authentik 2026.5.2)

- Flow `headless-first-party-auth` (E3, just built): identification(order 10, email/username,
  `pretend_user_exists: true`, no inline password) → password(20, Inbuilt + LDAP backends,
  `failed_attempts_before_cancel: 5`) → authenticator-validate(30) → user-login(100).
  Bindings: `evaluate_on_plan: false`, `re_evaluate_policies: true`.
- Reputation code (read from the container, `/authentik/policies/reputation/{models,signals}.py`):
  - Row per `(identifier, ip)`. `ReputationPolicy.passes`: sums `score` over rows matching
    `identifier=request.user.username` (if `check_username`) OR `ip=client_ip` (if `check_ip`);
    **passes when sum <= threshold**.
  - `login_failed` → −1 for `credentials["username"]`; `identification_failed` → −1 for the
    typed identifier; `user_logged_in` → +1 for `user.username`. Each update clamps the row to
    tenant `reputation_lower_limit`/`reputation_upper_limit` (defaults −5/+5) via
    `Greatest(lower, Least(upper, score + amount))`.
  - `expires` is set only on insert (default `reputation.expiry` 86400 s), never refreshed.
- Password stage (`/authentik/stages/password/stage.py`): `challenge_invalid` reads
  `initial_score` (the reputation score after the first failure in this executor session) and
  cancels the flow (`stage_invalid`) when `initial_score - new_score >= failed_attempts_before_cancel`.
  So within one executor session the relay can retry the password stage N+1 times; any check
  placed before the password stage is not re-run between those retries.
- Re-evaluated stage-binding policies get the **pending user** as `request.user`
  (`ReevaluateMarker`), so a username-keyed policy on a binding after identification sees the
  real username.
- Trusted proxies default on 2026.5: 127/8, 10/8, 172.16/12, 192.168/16, fe80::/10, ::1.
  Dev: Authentik is on `dev_azblink-net` (172.18/16) and `cloudflare-tunnel` (172.20/16, shared
  with cloudflared and several unrelated projects' containers). Host-originated requests to
  `localhost:9000` show up as `172.20.0.1`. The SafeNest relay container is on its own network
  (172.21/16) and reaches Authentik through the published port 9000.

## Proposed design (to attack / compare)

(a) Lockout
1. Tenant setting `reputation_upper_limit = 0` (seed PATCHes `/api/v3/admin/settings/`), and
   the seed deletes existing rows with `score > 0` once. Reason: with +5, a user with past
   successes gets up to 8 failures before a −3 threshold, and LDAP locks at 5.
2. `ReputationPolicy` "headless-first-party-auth: username reputation <= -3":
   `check_username: true`, `check_ip: false`, `threshold: -3`.
3. A Deny stage `headless-first-party-auth-throttled` bound at order 15 (after identification,
   before password), `re_evaluate_policies: true`, with the reputation policy on that stage
   binding (not negated). Never bind a negated policy to the password stage: skipping the
   password stage would log the user in.
4. Password stage `failed_attempts_before_cancel: 1` → at most 2 failures per executor session,
   and the first failure still returns the normal `invalid` password error (relay contract
   unchanged).
   Claimed invariant (Authentik path only): rows are always <= 0, so
   `sum(username rows) <= -(LDAP failures since last successful bind)`. Deny at sum <= −3
   means a session starts with sum >= −2, adds at most 2 failures → LDAP failures <= 4 < 5.

(b) Trusted proxies: compose sets
`AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS: ${AUTHENTIK_TRUSTED_PROXY_CIDRS:-127.0.0.0/8,::1/128}`
on `authentik-server`; operators add each registered relay's egress CIDR. Consequence: web
users via the Cloudflare tunnel show cloudflared's IP in Authentik (no IP-keyed policy exists).

## Known residuals (please check these and find more)

- R1: rows expire 24 h after their first failure while LDAP never forgets failures
  (`pwdFailureCountInterval 0`): after expiry, 2 more relay failures lock LDAP. Bounded to a few
  5-minute LDAP locks per day per targeted user. Closing it needs `pwdFailureCountInterval`
  set (an LDAP-wide policy change) — proposed as a follow-up owner decision, not done in E5.
- R2: a blocked user stays blocked until the row expires, a successful login elsewhere raises
  one row by 1, or an admin deletes the scores.
- R3: failures via other LDAP paths (XMPP binds, direct binds) count in LDAP but not in
  Authentik reputation.
- R4: after 3 failures the deny message differs from the password error → reveals the
  username exists (`pretend_user_exists` normally hides that).
