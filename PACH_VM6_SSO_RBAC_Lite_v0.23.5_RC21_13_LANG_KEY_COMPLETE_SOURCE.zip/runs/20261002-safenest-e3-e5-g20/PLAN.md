# PLAN: SafeNest headless login, azb-AD remainder (E3, E5, G20)

Source of truth for scope: `docs/reports/2026-09-25-safenest-headless-login-gap-report.md`
(rows E3, E5; gaps G1, G2, G20) and ARD-018 (accepted, body frozen above `## Amendments`).
Handoff for the next session: root `HANDOFF.md`. Decisions and risk notes: `JOURNAL.md`.

## Constraints

- Owner pre-authorised autonomous decisions for this run (2026-10-02). Every decision is
  logged in JOURNAL with: rule applied, worst case, how to revert.
- No hook bypass. Conventional commits. One PR per milestone, squash-merge after CI green.
- ARD-018 mechanism changes need an `## Amendments` entry, not a body edit.
- Never send the `safenest-dev` client secret over the session channel.

## Milestones

- [x] **M1 E3: shared `headless-first-party-auth` flow.**
  DoD:
  1. `just test-quick tests/test_headless_first_party_login.py` passes with E4's executor slug
     switched to `headless-first-party-auth`.
  2. A new test: a TOTP-enrolled user gets `ak-stage-authenticator-validate` after the password
     stage (relay fails closed).
  3. Running the seed twice: the second run creates nothing new for the flow.
  4. Each first-party provider's `authentication_flow` is the headless flow; the web app's
     provider is unchanged.
- [x] **M2 E5: lockout and throttling.**
  DoD (gap report row E5):
  1. 3 bad passwords via the headless flow, then the 4th attempt (even with the right password)
     is denied by Authentik.
  2. The LDAP entry has no `pwdAccountLockedTime` and a direct LDAP bind with the right
     password succeeds.
  3. Another user logs in normally right after.
  4. XFF from an untrusted source is ignored (recorded client IP is the socket peer).
  5. `/security-review` run, findings resolved or recorded.
- [x] **M3 G20: prod registration path** for `AUTHENTIK_FIRST_PARTY_CLIENTS`.
  DoD: the ansible prod path can register a first-party client (env rendered + seed or task
  runs), with spec 06 updated; checked by an ansible template render or unit test.
- [x] **M4 close-out:** SafeNest peer told each merged sha; root `HANDOFF.md` rewritten.
