-- 022_device_provisioning.sql
-- Add SSO device provisioning support to provision_tokens table.
-- New columns discriminate QR vs SSO tokens and store E2E encrypted payloads.

ALTER TABLE provision_tokens
  ADD COLUMN IF NOT EXISTS auth_method VARCHAR(32) NOT NULL DEFAULT 'qr',
  ADD COLUMN IF NOT EXISTS sealed_payload BYTEA,
  ADD COLUMN IF NOT EXISTS public_key_hash VARCHAR(128);

-- Add max_devices_per_user to config_templates (default 5)
ALTER TABLE config_templates
  ADD COLUMN IF NOT EXISTS max_devices_per_user INTEGER NOT NULL DEFAULT 5;

-- Index for device cap counting (SSO tokens by user + status)
CREATE INDEX IF NOT EXISTS idx_pt_uid_auth_method_status
  ON provision_tokens (uid, auth_method, status);

-- Unique partial index for SSO device upsert (prevents duplicate device registrations)
CREATE UNIQUE INDEX IF NOT EXISTS idx_pt_sso_device_upsert
  ON provision_tokens (uid, consumed_by_device_id, auth_method)
  WHERE auth_method = 'sso_token';

-- Rollback:
-- DROP INDEX IF EXISTS idx_pt_sso_device_upsert;
-- DROP INDEX IF EXISTS idx_pt_uid_auth_method_status;
-- ALTER TABLE config_templates DROP COLUMN IF EXISTS max_devices_per_user;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS public_key_hash;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS sealed_payload;
-- ALTER TABLE provision_tokens DROP COLUMN IF EXISTS auth_method;
