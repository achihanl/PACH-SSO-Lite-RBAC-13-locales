-- migrations/014_profile_ued_merge.sql
-- Merge tenant_ldap_configs into config_templates (1:1 profile = UED).
-- After this migration, each profile directly owns its UED endpoint,
-- discovery cache, and allocation counters. tenant_ldap_configs is dropped.
BEGIN;

-- 1. Add UED columns to config_templates
ALTER TABLE config_templates
    ADD COLUMN IF NOT EXISTS ued_api_url TEXT,
    ADD COLUMN IF NOT EXISTS ued_api_key_enc TEXT,
    ADD COLUMN IF NOT EXISTS ued_enabled BOOLEAN NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS discovered_schema_name TEXT,
    ADD COLUMN IF NOT EXISTS discovered_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS next_uid_number INTEGER NOT NULL DEFAULT 5000,
    ADD COLUMN IF NOT EXISTS uid_range_start INTEGER NOT NULL DEFAULT 5000,
    ADD COLUMN IF NOT EXISTS uid_range_end INTEGER NOT NULL DEFAULT 65533,
    ADD COLUMN IF NOT EXISTS next_extension INTEGER NOT NULL DEFAULT 6000,
    ADD COLUMN IF NOT EXISTS ext_range_start INTEGER NOT NULL DEFAULT 6000,
    ADD COLUMN IF NOT EXISTS ext_range_end INTEGER NOT NULL DEFAULT 6999,
    ADD COLUMN IF NOT EXISTS last_sync_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS last_error TEXT;

-- 2. Copy data from linked tenant_ldap_configs rows
UPDATE config_templates ct
SET
    ued_api_url = tlc.ued_api_url,
    ued_api_key_enc = tlc.ued_api_key_enc,
    ued_enabled = tlc.enabled,
    discovered_schema_name = tlc.discovered_schema_name,
    discovered_at = tlc.discovered_at,
    next_uid_number = tlc.next_uid_number,
    uid_range_start = tlc.uid_range_start,
    uid_range_end = tlc.uid_range_end,
    next_extension = tlc.next_extension,
    ext_range_start = tlc.ext_range_start,
    ext_range_end = tlc.ext_range_end,
    last_sync_at = tlc.last_sync_at,
    last_error = tlc.last_error
FROM tenant_ldap_configs tlc
WHERE ct.ued_config_id = tlc.id;

-- 3. Add profile_id to sync_events, backfill from tenant_id → tenant_ldap_configs → config_templates
ALTER TABLE sync_events
    ADD COLUMN IF NOT EXISTS profile_id VARCHAR(128)
        REFERENCES config_templates(id) ON DELETE SET NULL;

UPDATE sync_events se
SET profile_id = ct.id
FROM tenant_ldap_configs tlc
JOIN config_templates ct ON ct.ued_config_id = tlc.id
WHERE se.tenant_id = tlc.tenant_id;

-- 4. Drop old tenant_id FK and column from sync_events
ALTER TABLE sync_events
    DROP CONSTRAINT IF EXISTS sync_events_tenant_id_fkey;
ALTER TABLE sync_events
    DROP COLUMN IF EXISTS tenant_id;

-- 5. Drop ued_config_id from config_templates
ALTER TABLE config_templates
    DROP CONSTRAINT IF EXISTS config_templates_ued_config_id_fkey;
ALTER TABLE config_templates
    DROP COLUMN IF EXISTS ued_config_id;

-- 6. Drop tenant_ldap_configs
DROP TABLE IF EXISTS tenant_ldap_configs;

COMMIT;
