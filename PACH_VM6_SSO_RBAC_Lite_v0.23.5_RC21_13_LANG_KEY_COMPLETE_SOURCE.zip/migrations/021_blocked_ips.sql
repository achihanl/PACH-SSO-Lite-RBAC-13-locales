-- migrations/021_blocked_ips.sql
-- Wave 1 (#17): IP-based blocking for repeated auth violations.

CREATE TABLE IF NOT EXISTS blocked_ips (
    id              SERIAL PRIMARY KEY,
    ip_address      VARCHAR(45) NOT NULL,
    blocked_until   TIMESTAMPTZ NOT NULL,
    reason          VARCHAR(255),
    blocked_by      VARCHAR(100) NOT NULL DEFAULT 'system',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_blocked_ips_address
    ON blocked_ips(ip_address);

CREATE INDEX IF NOT EXISTS idx_blocked_ips_expiry
    ON blocked_ips(blocked_until);
