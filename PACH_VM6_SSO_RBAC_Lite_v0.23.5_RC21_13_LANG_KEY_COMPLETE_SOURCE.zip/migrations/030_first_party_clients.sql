-- migrations/030_first_party_clients.sql
-- First-party clients onboarded at runtime (ARD-022), merged with the env registry.
-- Hand-mirror of the first_party_clients Table in db/tables.py.

CREATE TABLE IF NOT EXISTS first_party_clients (
    client_id         VARCHAR(64)  PRIMARY KEY,
    service_client_id VARCHAR(64)  NOT NULL UNIQUE,
    roles             VARCHAR(255) NOT NULL,
    redirect_uris     JSON         NOT NULL,
    created_by        VARCHAR(100) NOT NULL,
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
