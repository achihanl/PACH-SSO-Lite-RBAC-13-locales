-- migrations/012_profile_ued_link.sql
-- Link config_templates to UED tenant configs for profile-aware provisioning.
-- Add uidNumber and SIP extension counter columns to tenant_ldap_configs.

BEGIN;

-- 1. Add FK from config_templates to tenant_ldap_configs
ALTER TABLE config_templates
    ADD COLUMN IF NOT EXISTS ued_config_id VARCHAR(36)
        REFERENCES tenant_ldap_configs(id) ON DELETE SET NULL;

COMMENT ON COLUMN config_templates.ued_config_id IS
    'Optional FK to tenant_ldap_configs.id — links this profile to a UED provisioning config. '
    'NULL means no UED provisioning (legacy/manual profiles).';

-- 2. Add uidNumber and extension counters to tenant_ldap_configs
ALTER TABLE tenant_ldap_configs
    ADD COLUMN IF NOT EXISTS next_uid_number INTEGER NOT NULL DEFAULT 5000,
    ADD COLUMN IF NOT EXISTS uid_range_start INTEGER NOT NULL DEFAULT 5000,
    ADD COLUMN IF NOT EXISTS uid_range_end   INTEGER NOT NULL DEFAULT 65533,
    ADD COLUMN IF NOT EXISTS next_extension  INTEGER NOT NULL DEFAULT 6000,
    ADD COLUMN IF NOT EXISTS ext_range_start INTEGER NOT NULL DEFAULT 6000,
    ADD COLUMN IF NOT EXISTS ext_range_end   INTEGER NOT NULL DEFAULT 6999;

COMMENT ON COLUMN tenant_ldap_configs.next_uid_number IS
    'Atomic counter for POSIX uidNumber allocation. Range: uid_range_start..uid_range_end.';
COMMENT ON COLUMN tenant_ldap_configs.next_extension IS
    'Atomic counter for SIP extension allocation. Range: ext_range_start..ext_range_end.';

COMMIT;
