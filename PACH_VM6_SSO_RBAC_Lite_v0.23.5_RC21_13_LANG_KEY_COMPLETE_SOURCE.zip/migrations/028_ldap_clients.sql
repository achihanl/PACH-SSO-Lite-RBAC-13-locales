-- migrations/028_ldap_clients.sql
-- LDAP client inventory: clients binding directly to the platform OpenLDAP
-- (UED/XMPP, Asterisk, API), detected from slapd stats log + acknowledged by admins.
-- Hand-mirror of the ldap_clients Table in orgdb.py (create_all provisions fresh stacks).

CREATE TABLE IF NOT EXISTS ldap_clients (
    id               SERIAL PRIMARY KEY,
    bind_dn          VARCHAR(255) NOT NULL,            -- '' = anonymous bind
    source_ip        VARCHAR(45)  NOT NULL,
    service          VARCHAR(20)  NOT NULL DEFAULT 'unknown',
    status           VARCHAR(20)  NOT NULL DEFAULT 'unknown',
    label            VARCHAR(255),
    first_seen       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_seen        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    session_count    INTEGER      NOT NULL DEFAULT 0,
    last_bind_mech   VARCHAR(30),
    acknowledged_by  VARCHAR(100),
    acknowledged_at  TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_ldap_clients_bind_ip ON ldap_clients(bind_dn, source_ip);
CREATE INDEX IF NOT EXISTS idx_ldap_clients_last_seen ON ldap_clients(last_seen);
CREATE INDEX IF NOT EXISTS idx_ldap_clients_status ON ldap_clients(status);
