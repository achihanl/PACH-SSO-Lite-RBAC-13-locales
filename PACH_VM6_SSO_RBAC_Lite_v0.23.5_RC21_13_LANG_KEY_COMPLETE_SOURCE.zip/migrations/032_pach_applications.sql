-- PACH-STD-IAM-001. Application catalog deliberately separate from
-- ARD-022 first_party_clients (building/SIP/XMPP onboarding).
CREATE TABLE IF NOT EXISTS pach_applications (
    application_id VARCHAR(64) PRIMARY KEY,
    display_name VARCHAR(255) NOT NULL,
    auth_method VARCHAR(16) NOT NULL,
    supported_roles JSON NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS pach_application_roles (
    user_uid VARCHAR(255) NOT NULL,
    application_id VARCHAR(64) NOT NULL REFERENCES pach_applications(application_id) ON DELETE CASCADE,
    role VARCHAR(40) NOT NULL,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_uid, application_id)
);
