-- migrations/020_account_locks.sql
-- Wave 1 (#16): Account soft-lock after repeated auth failures.

CREATE TABLE IF NOT EXISTS account_locks (
    id              SERIAL PRIMARY KEY,
    username        VARCHAR(255) NOT NULL,
    locked_until    TIMESTAMPTZ NOT NULL,
    locked_by       VARCHAR(100) NOT NULL DEFAULT 'system',
    reason          VARCHAR(255),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_account_locks_username
    ON account_locks(username);

CREATE INDEX IF NOT EXISTS idx_account_locks_expiry
    ON account_locks(locked_until);
