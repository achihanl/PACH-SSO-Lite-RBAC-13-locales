-- migrations/029_ldap_provisioned_clients.sql
-- Registry of LDAP client credentials PROVISIONED by the platform (intent).
-- Distinct from ldap_clients (observed/detected). No secret column — the hash
-- lives only in LDAP. Hand-mirror of the ldap_provisioned_clients Table in orgdb.py.

CREATE TABLE IF NOT EXISTS ldap_provisioned_clients (
    id              SERIAL PRIMARY KEY,
    client_id       VARCHAR(64)  NOT NULL UNIQUE,
    bind_dn         VARCHAR(255) NOT NULL UNIQUE,
    label           VARCHAR(255),
    created_by      VARCHAR(100) NOT NULL,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_rotated_at TIMESTAMPTZ,
    revoked_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_ldap_prov_clients_active
    ON ldap_provisioned_clients(revoked_at);
