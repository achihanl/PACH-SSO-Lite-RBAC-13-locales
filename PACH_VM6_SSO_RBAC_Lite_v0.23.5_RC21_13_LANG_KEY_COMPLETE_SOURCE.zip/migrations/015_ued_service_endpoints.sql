-- migrations/015_ued_service_endpoints.sql
-- Cache full UED discovery result on config_templates.
-- Drop xmpp_config/sip_config (UED is now single source of truth for services).
BEGIN;

-- 1. Add new discovery cache columns
ALTER TABLE config_templates
    ADD COLUMN IF NOT EXISTS discovered_capabilities TEXT[] DEFAULT '{}',
    ADD COLUMN IF NOT EXISTS discovered_service_endpoints JSONB DEFAULT '{}';

-- 2. Backfill capabilities from discovered_schema_name for existing rows
-- pjsip-combined -> {posix,sip,xmpp}
UPDATE config_templates
SET discovered_capabilities = ARRAY['posix','sip','xmpp']
WHERE discovered_schema_name = 'pjsip-combined'
  AND (discovered_capabilities IS NULL OR discovered_capabilities = '{}');

-- sip-legacy -> {posix,sip}
UPDATE config_templates
SET discovered_capabilities = ARRAY['posix','sip']
WHERE discovered_schema_name = 'sip-legacy'
  AND (discovered_capabilities IS NULL OR discovered_capabilities = '{}');

-- xmpp-only -> {posix,xmpp}
UPDATE config_templates
SET discovered_capabilities = ARRAY['posix','xmpp']
WHERE discovered_schema_name = 'xmpp-only'
  AND (discovered_capabilities IS NULL OR discovered_capabilities = '{}');

-- 3. Drop deprecated independent config blobs (UED is source of truth)
ALTER TABLE config_templates
    DROP COLUMN IF EXISTS xmpp_config,
    DROP COLUMN IF EXISTS sip_config;

COMMIT;
