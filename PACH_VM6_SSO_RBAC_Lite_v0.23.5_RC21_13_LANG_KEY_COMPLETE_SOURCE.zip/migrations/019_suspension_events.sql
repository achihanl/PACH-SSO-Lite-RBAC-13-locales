-- migrations/019_suspension_events.sql
-- Wave 1 (#30): Dedicated suspension events tracking.
-- Supplements user_lifecycle_audit with suspension-specific detail.

CREATE TABLE IF NOT EXISTS suspension_events (
    id              SERIAL PRIMARY KEY,
    user_uid        VARCHAR(255) NOT NULL,
    action          VARCHAR(20) NOT NULL CHECK (action IN ('suspended', 'unsuspended')),
    performed_by    VARCHAR(255),
    reason          TEXT,
    duration_hours  INTEGER,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_suspension_events_user
    ON suspension_events(user_uid, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_suspension_events_time
    ON suspension_events(created_at DESC);
