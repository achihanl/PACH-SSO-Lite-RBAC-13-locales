-- Migration 005: Groups Management (RBAC + enrichment)
-- For existing deployments upgrading in-place.
-- Fresh deployments auto-create via OrgDB.init().

CREATE TABLE IF NOT EXISTS group_profiles (
    cn              TEXT PRIMARY KEY,
    group_type      TEXT NOT NULL DEFAULT 'distribution'
                    CHECK (group_type IN ('security','distribution','department','project')),
    permissions     JSONB NOT NULL DEFAULT '[]',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS group_member_roles (
    group_cn        TEXT NOT NULL REFERENCES group_profiles(cn) ON DELETE CASCADE,
    member_uid      TEXT NOT NULL,
    role            TEXT NOT NULL DEFAULT 'member'
                    CHECK (role IN ('owner','admin','member')),
    assigned_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (group_cn, member_uid)
);

CREATE INDEX IF NOT EXISTS idx_gmr_member ON group_member_roles(member_uid);
