-- Migration 004: Phase 1 UC Core QR Support
-- Enhances provision_tokens table for device tracking at consumption time

-- Add device tracking columns
ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS consumed_by_device_id VARCHAR(128);

ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS consumed_from_ip VARCHAR(45);

ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS client_platform VARCHAR(32);

ALTER TABLE provision_tokens
ADD COLUMN IF NOT EXISTS client_version VARCHAR(32);

-- Add index for user-based token lookup (used by revocation)
CREATE INDEX IF NOT EXISTS idx_provision_tokens_uid_status
ON provision_tokens(uid, status);

-- Add index for cleanup of expired tokens
CREATE INDEX IF NOT EXISTS idx_provision_tokens_expires
ON provision_tokens(expires_at)
WHERE status = 'active';
