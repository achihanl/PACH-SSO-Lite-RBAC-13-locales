-- migrations/012_ued_self_discovery.sql
-- UED Self-Discovery: simplify tenant_ldap_configs to URL + API key only.
--
-- UED Sync API instances now self-configure LDAP connection and schema
-- from their own environment variables. AD Directory only stores the
-- endpoint URL + API key and caches discovery results.

BEGIN;

-- Drop the schema source constraint first (depends on schema_config/schema_name)
ALTER TABLE tenant_ldap_configs
    DROP CONSTRAINT IF EXISTS chk_schema_source;

-- Drop LDAP connection columns (now owned by UED instance env vars)
ALTER TABLE tenant_ldap_configs
    DROP COLUMN IF EXISTS ldap_uri,
    DROP COLUMN IF EXISTS ldap_base_dn,
    DROP COLUMN IF EXISTS ldap_bind_dn,
    DROP COLUMN IF EXISTS ldap_bind_pw_enc,
    DROP COLUMN IF EXISTS ldap_use_ssl,
    DROP COLUMN IF EXISTS ldap_timeout_ms;

-- Drop schema columns (now owned by UED instance SCHEMA_NAME env var)
ALTER TABLE tenant_ldap_configs
    DROP COLUMN IF EXISTS schema_config,
    DROP COLUMN IF EXISTS schema_name;

-- Add discovery cache columns
ALTER TABLE tenant_ldap_configs
    ADD COLUMN IF NOT EXISTS discovered_schema_name TEXT,
    ADD COLUMN IF NOT EXISTS discovered_at TIMESTAMPTZ;

COMMENT ON COLUMN tenant_ldap_configs.discovered_schema_name IS
    'Cached schema name from GET /api/v1/discovery (e.g., pjsip-combined). '
    'Refreshed periodically or on admin request.';

COMMENT ON COLUMN tenant_ldap_configs.discovered_at IS
    'Timestamp of last successful discovery call.';

COMMIT;
