-- migrations/009_settings.sql
-- Migration 009: App settings (key/value) and API keys
-- For existing deployments upgrading in-place.
-- Fresh deployments auto-create via OrgDB.init().

-- App-level settings: key/value grouped by section
CREATE TABLE IF NOT EXISTS app_settings (
    id          SERIAL PRIMARY KEY,
    section     VARCHAR(50) NOT NULL,
    key         VARCHAR(100) NOT NULL,
    value       TEXT NOT NULL DEFAULT '',
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(section, key)
);

CREATE INDEX IF NOT EXISTS idx_app_settings_section
    ON app_settings(section);

-- API keys for programmatic access
CREATE TABLE IF NOT EXISTS api_keys (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    prefix      VARCHAR(30) NOT NULL,
    key_hash    VARCHAR(128) NOT NULL,
    created_by  VARCHAR(100) NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_used_at TIMESTAMPTZ,
    revoked_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_api_keys_active
    ON api_keys(created_at DESC) WHERE revoked_at IS NULL;
