-- PACH-STD-IAM-001 Step 2: authentication client registrations, no secrets.
-- Separate from building first_party_clients and LDAP provisioning registry.
CREATE TABLE IF NOT EXISTS pach_application_auth_clients (
    application_id VARCHAR(64) PRIMARY KEY REFERENCES pach_applications(application_id) ON DELETE CASCADE,
    client_id VARCHAR(96) NOT NULL UNIQUE,
    auth_method VARCHAR(16) NOT NULL,
    redirect_uris JSON NOT NULL,
    status VARCHAR(16) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
