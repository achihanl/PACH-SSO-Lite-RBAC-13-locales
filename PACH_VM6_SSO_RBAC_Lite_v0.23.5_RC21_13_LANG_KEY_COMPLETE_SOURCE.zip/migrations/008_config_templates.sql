-- migrations/008_config_templates.sql
-- Migration 008: Config templates for reusable org provisioning profiles
-- For existing deployments upgrading in-place.
-- Fresh deployments auto-create via OrgDB.init().

CREATE TABLE IF NOT EXISTS config_templates (
    id              VARCHAR(128) PRIMARY KEY,
    name            VARCHAR(255) NOT NULL UNIQUE,
    description     TEXT NOT NULL DEFAULT '',
    template_type   VARCHAR(20) NOT NULL DEFAULT 'custom'
                    CHECK (template_type IN ('default', 'custom')),
    status          VARCHAR(20) NOT NULL DEFAULT 'draft'
                    CHECK (status IN ('active', 'draft', 'archived')),
    xmpp_config     JSONB NOT NULL DEFAULT '{"enabled":false}',
    sip_config      JSONB NOT NULL DEFAULT '{"enabled":false}',
    sso_config      JSONB NOT NULL DEFAULT '{"enabled":false}',
    qr_settings     JSONB NOT NULL DEFAULT '{"defaultValidityMinutes":60,"oneTimeUse":true,"autoEmailOnCreate":false,"deepLinkScheme":"azblink"}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      VARCHAR(255),
    updated_by      VARCHAR(255)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_config_templates_default
    ON config_templates (template_type) WHERE template_type = 'default';

CREATE TABLE IF NOT EXISTS config_template_assignments (
    id              VARCHAR(128) PRIMARY KEY,
    template_id     VARCHAR(128) NOT NULL REFERENCES config_templates(id) ON DELETE CASCADE,
    org_dn          VARCHAR(512) NOT NULL UNIQUE,
    assigned_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by     VARCHAR(255)
);

CREATE INDEX IF NOT EXISTS idx_config_template_assignments_template
    ON config_template_assignments(template_id);

CREATE TABLE IF NOT EXISTS config_template_history (
    id              VARCHAR(128) PRIMARY KEY,
    template_id     VARCHAR(128) REFERENCES config_templates(id) ON DELETE SET NULL,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    actor           VARCHAR(255) NOT NULL,
    description     TEXT NOT NULL,
    field           VARCHAR(255),
    old_value       TEXT,
    new_value       TEXT
);

CREATE INDEX IF NOT EXISTS idx_config_template_history_template
    ON config_template_history(template_id, timestamp DESC);
