-- Migration 016: QR Preview Links
-- Shareable preview links for QR codes with independent expiry
-- Each link stores a snapshot of the QR image + metadata at creation time

CREATE TABLE IF NOT EXISTS qr_preview_links (
    id                  SERIAL PRIMARY KEY,
    preview_token_hash  VARCHAR(64) NOT NULL UNIQUE,
    uid                 VARCHAR(128) NOT NULL,
    display_name        VARCHAR(255),
    org_dn              TEXT,
    qr_png_base64       TEXT NOT NULL,
    qr_payload          JSONB NOT NULL,
    qr_expires_at       TIMESTAMPTZ NOT NULL,
    preview_expires_at  TIMESTAMPTZ NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          VARCHAR(255) NOT NULL,
    access_count        INTEGER NOT NULL DEFAULT 0,
    last_accessed_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_qr_preview_links_expires ON qr_preview_links(preview_expires_at);
CREATE INDEX IF NOT EXISTS idx_qr_preview_links_uid ON qr_preview_links(uid);
