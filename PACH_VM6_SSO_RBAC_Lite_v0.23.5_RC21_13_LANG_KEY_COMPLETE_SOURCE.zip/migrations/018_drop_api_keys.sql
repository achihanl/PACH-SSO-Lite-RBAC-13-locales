-- migrations/018_drop_api_keys.sql
-- Wave 1 (#32): Remove dead API keys table
-- No route validates API keys — full CRUD exists but nothing consumes them.

DROP TABLE IF EXISTS api_keys;
