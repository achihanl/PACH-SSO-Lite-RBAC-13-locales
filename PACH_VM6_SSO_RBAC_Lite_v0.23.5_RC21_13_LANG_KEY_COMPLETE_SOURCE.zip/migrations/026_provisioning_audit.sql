-- 026: Provisioning audit table for device provisioning event tracking
CREATE TABLE IF NOT EXISTS provisioning_audit (
    id            SERIAL PRIMARY KEY,
    action        VARCHAR(32) NOT NULL,
    actor         VARCHAR(128) NOT NULL,
    target_uid    VARCHAR(128) NOT NULL,
    device_id     VARCHAR(128),
    token_hash    VARCHAR(128),
    auth_method   VARCHAR(16),
    platform      VARCHAR(32),
    client_ip     VARCHAR(45),
    detail        JSONB,
    timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_prov_audit_target ON provisioning_audit(target_uid);
CREATE INDEX IF NOT EXISTS idx_prov_audit_timestamp ON provisioning_audit(timestamp);
CREATE INDEX IF NOT EXISTS idx_prov_audit_action ON provisioning_audit(action);
