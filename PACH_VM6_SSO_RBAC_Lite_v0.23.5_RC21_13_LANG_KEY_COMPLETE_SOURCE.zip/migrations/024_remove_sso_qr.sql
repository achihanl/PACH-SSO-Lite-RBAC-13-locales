-- 024_remove_sso_qr.sql
-- Remove SSO config and QR infrastructure from config_templates.
-- Rename provision_tokens → device_provisions (SSO-only going forward).

ALTER TABLE config_templates DROP COLUMN IF EXISTS sso_config;
ALTER TABLE config_templates DROP COLUMN IF EXISTS qr_settings;

DROP TABLE IF EXISTS qr_issuance_audit;
DROP TABLE IF EXISTS qr_issues;
DROP TABLE IF EXISTS qr_preview_links;

-- Rename provision_tokens → device_provisions and drop auth_method.
-- Handle case where device_provisions already exists (created by app init).
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'provision_tokens') THEN
        IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'device_provisions') THEN
            -- Both tables exist: migrate data, drop old table
            INSERT INTO device_provisions (token_hash, uid, profile_id, issued_at, expires_at,
                used_at, status, consumed_by_device_id, consumed_from_ip,
                client_platform, client_version, sealed_payload, public_key_hash)
            SELECT token_hash, uid, profile_id, issued_at, expires_at,
                used_at, status, consumed_by_device_id, consumed_from_ip,
                client_platform, client_version, sealed_payload, public_key_hash
            FROM provision_tokens
            ON CONFLICT (token_hash) DO NOTHING;
            DROP TABLE provision_tokens;
        ELSE
            ALTER TABLE provision_tokens RENAME TO device_provisions;
        END IF;
    END IF;
END $$;

ALTER TABLE device_provisions DROP COLUMN IF EXISTS auth_method;
