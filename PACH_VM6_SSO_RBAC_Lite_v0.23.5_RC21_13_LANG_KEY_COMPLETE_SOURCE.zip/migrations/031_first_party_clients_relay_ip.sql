-- migrations/031_first_party_clients_relay_ip.sql
-- An onboarded client's relay box address (ARD-022 amendment): stored only; Authentik
-- trusts it after the operator adds it to authentik_relay_ips and converges (ARD-021).
-- OrgDB.init() applies the same statement, so a running install needs no manual step.

ALTER TABLE first_party_clients ADD COLUMN IF NOT EXISTS relay_ip VARCHAR(15);
