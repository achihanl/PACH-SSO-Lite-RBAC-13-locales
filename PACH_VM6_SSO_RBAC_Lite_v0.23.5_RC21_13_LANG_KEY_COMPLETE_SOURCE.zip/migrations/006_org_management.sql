-- Migration 006: Org management enhancements
-- For existing deployments upgrading in-place.
-- Fresh deployments auto-create via OrgDB.init().
--
-- Adds org_type column to org_profiles for classifying org nodes
-- (root, org, dept, team) and indexes for efficient lookups.

ALTER TABLE org_profiles ADD COLUMN IF NOT EXISTS org_type VARCHAR(32) NOT NULL DEFAULT 'org';

CREATE INDEX IF NOT EXISTS idx_org_profiles_org_dn ON org_profiles(org_dn);
CREATE INDEX IF NOT EXISTS idx_org_profiles_tenant ON org_profiles(tenant);
