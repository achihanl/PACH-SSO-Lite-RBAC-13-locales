-- migrations/011_ued_schema_name.sql
-- Add schema_name support to tenant_ldap_configs
--
-- Allows tenants to reference built-in schemas by name (e.g., "sip-legacy")
-- instead of storing the full inline ProvisioningSchema as JSONB.
-- Mutually exclusive: provide schema_config OR schema_name, not both empty.

BEGIN;

-- Add schema_name column (nullable — existing rows have schema_config)
ALTER TABLE tenant_ldap_configs
    ADD COLUMN IF NOT EXISTS schema_name TEXT;

-- Make schema_config nullable (was NOT NULL — now optional when schema_name set)
ALTER TABLE tenant_ldap_configs
    ALTER COLUMN schema_config DROP NOT NULL;

-- At least one schema source must be present
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_schema_source'
    ) THEN
        ALTER TABLE tenant_ldap_configs
        ADD CONSTRAINT chk_schema_source CHECK (
            schema_config IS NOT NULL OR schema_name IS NOT NULL
        );
    END IF;
END $$;

COMMENT ON COLUMN tenant_ldap_configs.schema_name IS
    'Built-in schema name (e.g., pjsip-combined, sip-legacy, xmpp-only). '
    'Mutually exclusive with schema_config — provide one or the other.';

COMMIT;
