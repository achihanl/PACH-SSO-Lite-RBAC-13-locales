-- Migration 007: Provisioning Operations performance indexes
-- For existing deployments upgrading in-place.
-- Fresh deployments auto-create via OrgDB.init().
--
-- Required by: GET /api/provisioning/compliance (6 analytical queries)
-- Required by: GET /api/provisioning/devices (device_id lookups)

CREATE INDEX IF NOT EXISTS idx_pt_device
ON provision_tokens(consumed_by_device_id)
WHERE consumed_by_device_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_pt_issued_at
ON provision_tokens(issued_at DESC);
