-- Migration 027: Add app_name column to device_provisions
--
-- Problem: ClientInfoModel.appName is accepted by the API but silently dropped —
-- no DB column exists to store it. This migration adds the column so client
-- application identification (e.g., "AzBlink-Mobile", "AzBlink-Desktop") is
-- captured alongside platform and version for device fleet visibility.
--
-- Idempotent: safe to run multiple times.

ALTER TABLE device_provisions
    ADD COLUMN IF NOT EXISTS app_name VARCHAR(64);

-- Optional index if we expect to filter by app_name in device list UI.
-- Left commented unless query patterns require it.
-- CREATE INDEX IF NOT EXISTS idx_device_provisions_app_name
--     ON device_provisions (app_name);
