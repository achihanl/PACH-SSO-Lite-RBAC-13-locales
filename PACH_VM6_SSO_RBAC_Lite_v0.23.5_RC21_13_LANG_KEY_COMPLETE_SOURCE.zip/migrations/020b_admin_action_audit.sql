-- migrations/019_admin_action_audit.sql
-- Wave 2 (#22 DS-7): Admin actions audit table
-- Tracks admin CRUD operations on orgs, users, groups, settings, profiles.
-- Included in list_unified_audit() UNION ALL with 'admin' category.

CREATE TABLE IF NOT EXISTS admin_action_audit (
    id SERIAL PRIMARY KEY,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    detail JSONB,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_admin_action_audit_actor ON admin_action_audit(actor);
CREATE INDEX IF NOT EXISTS idx_admin_action_audit_timestamp ON admin_action_audit(timestamp);
CREATE INDEX IF NOT EXISTS idx_admin_action_audit_resource ON admin_action_audit(resource_type, resource_id);
