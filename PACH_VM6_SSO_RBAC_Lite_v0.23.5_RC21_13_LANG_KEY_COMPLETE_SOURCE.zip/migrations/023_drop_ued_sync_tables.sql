-- 023_drop_ued_sync_tables.sql
-- Drop orphan tables from removed UED sync subsystem (migrations 010-015).
-- These tables have zero code references since the single-LDAP migration.

DROP TABLE IF EXISTS sync_events;
DROP TABLE IF EXISTS tenant_ldap_configs;
