-- Migration 017: Single-LDAP Architecture
-- Collapse two-LDAP into one: remove UED Sync infrastructure, add direct UC provisioning fields.
-- UC attributes (posixAccount + AsteriskPjsip*) are now written directly onto inetOrgPerson entries.

BEGIN;

-- 1. Drop UED sync event queue (no more async relay)
DROP TABLE IF EXISTS sync_events CASCADE;

-- 2. Add direct UC provisioning toggle + service endpoint fields
ALTER TABLE config_templates
    ADD COLUMN IF NOT EXISTS xmpp_enabled BOOLEAN NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS sip_enabled BOOLEAN NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS xmpp_domain TEXT,
    ADD COLUMN IF NOT EXISTS xmpp_ws_url TEXT,
    ADD COLUMN IF NOT EXISTS sip_domain TEXT,
    ADD COLUMN IF NOT EXISTS sip_wss_url TEXT;

-- 3. Remove UED connector fields (no longer needed — no external UED Sync service)
ALTER TABLE config_templates
    DROP COLUMN IF EXISTS ued_api_url,
    DROP COLUMN IF EXISTS ued_api_key_enc,
    DROP COLUMN IF EXISTS ued_enabled,
    DROP COLUMN IF EXISTS discovered_schema_name,
    DROP COLUMN IF EXISTS discovered_at,
    DROP COLUMN IF EXISTS discovered_capabilities,
    DROP COLUMN IF EXISTS discovered_service_endpoints,
    DROP COLUMN IF EXISTS last_sync_at,
    DROP COLUMN IF EXISTS last_error;

COMMIT;
