-- migrations/010_ued_sync.sql
-- UED Sync Integration: tenant configs + async sync event queue

BEGIN;

-- Tenant UED connection configs (one per tenant)
CREATE TABLE IF NOT EXISTS tenant_ldap_configs (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id        TEXT NOT NULL,
    name             TEXT NOT NULL,
    ued_api_url      TEXT NOT NULL,
    ued_api_key_enc  TEXT NOT NULL,
    ldap_uri         TEXT NOT NULL,
    ldap_base_dn     TEXT NOT NULL,
    ldap_bind_dn     TEXT NOT NULL,
    ldap_bind_pw_enc TEXT NOT NULL,
    ldap_use_ssl     BOOLEAN NOT NULL DEFAULT TRUE,
    ldap_timeout_ms  INTEGER NOT NULL DEFAULT 5000,
    schema_config    JSONB NOT NULL,
    enabled          BOOLEAN NOT NULL DEFAULT TRUE,
    last_sync_at     TIMESTAMPTZ,
    last_error       TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id)
);

-- Async sync event queue
CREATE TABLE IF NOT EXISTS sync_events (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id     TEXT NOT NULL REFERENCES tenant_ldap_configs(tenant_id) ON DELETE CASCADE,
    user_uid      TEXT NOT NULL,
    event_type    TEXT NOT NULL,
    payload       JSONB NOT NULL,
    status        TEXT NOT NULL DEFAULT 'pending',
    attempts      INTEGER NOT NULL DEFAULT 0,
    max_attempts  INTEGER NOT NULL DEFAULT 10,
    next_retry_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_error    TEXT,
    request_id    UUID DEFAULT gen_random_uuid(),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at  TIMESTAMPTZ,

    CONSTRAINT valid_event_type CHECK (event_type IN (
        'user_created','user_updated','user_suspended',
        'user_unsuspended','user_terminated','password_changed'
    )),
    CONSTRAINT valid_status CHECK (status IN ('pending','in_progress','completed','failed'))
);

-- Worker polling index
CREATE INDEX idx_sync_events_pending
    ON sync_events (next_retry_at)
    WHERE status IN ('pending', 'in_progress');

-- Per-user ordering index
CREATE INDEX idx_sync_events_user_ordering
    ON sync_events (tenant_id, user_uid, created_at)
    WHERE status IN ('pending', 'in_progress');

-- Retention cleanup index
CREATE INDEX idx_sync_events_completed
    ON sync_events (completed_at)
    WHERE status = 'completed';

-- Dashboard: failed events
CREATE INDEX idx_sync_events_failed
    ON sync_events (created_at DESC)
    WHERE status = 'failed';

COMMIT;
