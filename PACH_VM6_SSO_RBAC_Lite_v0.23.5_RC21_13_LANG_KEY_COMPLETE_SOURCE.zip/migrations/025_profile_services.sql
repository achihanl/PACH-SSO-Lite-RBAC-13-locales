-- 025_profile_services.sql
-- Create profile_services table; migrate XMPP/SIP from flat columns.

CREATE TABLE IF NOT EXISTS profile_services (
    id            VARCHAR(128) PRIMARY KEY,
    profile_id    VARCHAR(128) NOT NULL REFERENCES config_templates(id) ON DELETE CASCADE,
    service_type  VARCHAR(50) NOT NULL,
    enabled       BOOLEAN NOT NULL DEFAULT true,
    config        JSON NOT NULL DEFAULT '{}',
    next_counter  INTEGER,
    counter_start INTEGER,
    counter_end   INTEGER,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(profile_id, service_type)
);

-- Migrate XMPP services
INSERT INTO profile_services (id, profile_id, service_type, enabled, config)
SELECT
    gen_random_uuid()::text, id, 'xmpp', xmpp_enabled,
    json_build_object('domain', COALESCE(xmpp_domain, ''), 'ws_url', COALESCE(xmpp_ws_url, ''))
FROM config_templates
WHERE xmpp_enabled = true OR xmpp_domain IS NOT NULL;

-- Migrate SIP services with counters
INSERT INTO profile_services (id, profile_id, service_type, enabled, config, next_counter, counter_start, counter_end)
SELECT
    gen_random_uuid()::text, id, 'sip', sip_enabled,
    json_build_object('domain', COALESCE(sip_domain, ''), 'wss_url', COALESCE(sip_wss_url, '')),
    next_extension, ext_range_start, ext_range_end
FROM config_templates
WHERE sip_enabled = true OR sip_domain IS NOT NULL;

-- Drop migrated columns
ALTER TABLE config_templates DROP COLUMN IF EXISTS xmpp_enabled;
ALTER TABLE config_templates DROP COLUMN IF EXISTS sip_enabled;
ALTER TABLE config_templates DROP COLUMN IF EXISTS xmpp_domain;
ALTER TABLE config_templates DROP COLUMN IF EXISTS xmpp_ws_url;
ALTER TABLE config_templates DROP COLUMN IF EXISTS sip_domain;
ALTER TABLE config_templates DROP COLUMN IF EXISTS sip_wss_url;
ALTER TABLE config_templates DROP COLUMN IF EXISTS next_extension;
ALTER TABLE config_templates DROP COLUMN IF EXISTS ext_range_start;
ALTER TABLE config_templates DROP COLUMN IF EXISTS ext_range_end;
