# PACH VM6 v0.21.9 RC5 — Localization Expansion

Baseline: v0.21.8 RC4 consolidated source. No SSO / RBAC behavior modified.

## New translation work
- Filled remaining Navigation namespace keys in ten newer languages.
- Filled missing Common UI namespace keys in ten newer languages.
- Preserved every pre-existing locale key and translation verbatim.
- Checked exact translation keys and interpolation placeholders in all 13 locales.

## Coverage
English reference: 1062 leaf keys. New translated entries per locale: {'ar': 76, 'de': 76, 'es': 76, 'fr': 76, 'id': 76, 'ja': 76, 'ko': 76, 'pt-BR': 76, 'th': 76, 'vi': 76}.
See `PACH_VM6_v0.21.9_RC5_LOCALE_COVERAGE.json` for exact namespace coverage.

## Remaining release criteria
- Complete remaining untranslated keys in User, Group, Organization, Settings, Audit, and other legacy namespaces.
- Language-expert review of all translated strings.
- Frontend build and per-language UI tests, including Arabic RTL.
- Existing VM6 live SSO / LDAP / Authentik validation remains outstanding.

This is a development localization increment, not a 13-language production-complete claim.
