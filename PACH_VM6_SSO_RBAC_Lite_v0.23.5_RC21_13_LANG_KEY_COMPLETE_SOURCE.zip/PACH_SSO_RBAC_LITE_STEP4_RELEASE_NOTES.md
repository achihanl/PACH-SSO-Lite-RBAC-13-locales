# PACH VM6 SSO & RBAC Lite v0.21.3 — Step 4 development candidate

Baseline: complete v0.21.2 Step 3 source. This release adds reference integrations and tests, not new authorization server endpoints or a change in VM6's authentication policies.

## Added
- `examples/pach_rbac_lite/oidc_role_client.py`: HTTPS, client-bound `/me` consumer with strict validation and local role checks.
- `examples/pach_rbac_lite/ldap_protocol_adapter.py`: illustrative LDAP service/user bind pattern using TLS validation and escaping, plus local protocol ACL. Native protocol LDAP integration remains preferred.
- `examples/pach_rbac_lite/future_partner_crm.py`: future OIDC application with independent resource ownership checks.
- `examples/pach_rbac_lite/tests/test_references.py`: deterministic no-infrastructure tests.
- `examples/pach_rbac_lite/README.md`: onboarding guidance for VM developers.

## Security and compatibility
No privileged arbitrary-user role lookup was added. LDAP bind remains for protocol authentication; the OIDC delegated endpoint remains for application roles. No application permissions, household/device policy or detailed ACLs were centralized into VM6. Existing VM6 source files and database migrations are unchanged in Step 4.

## Known limits
- Reference OIDC code presupposes a completed, securely validated login; production applications must use their existing OIDC libraries and integrate it with verified server-side sessions.
- LDAP Python adapter is demonstration only; production protocol-specific configuration must be validated per daemon/version.
- OIDC client claim compatibility with Authentik and live LDAP / PostgreSQL connectivity require integration tests.
- Optional `ldap3` dependency not installed in this isolated test environment.
- Future server-to-server service-identity role queries require separate architecture/security review; this Step 4 does not implement them.

## Test
`python -m unittest discover -s examples/pach_rbac_lite/tests -v`
