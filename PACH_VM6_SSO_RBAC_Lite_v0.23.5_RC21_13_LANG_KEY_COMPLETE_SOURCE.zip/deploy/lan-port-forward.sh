#!/usr/bin/env bash
# lan-port-forward.sh
# - Expose the azb AD platform (on the VPN VM) to ONE LAN client via a simple
#   socat TCP port-forward on this host. No sudo / iptables / routing needed.
# - Path: client -> 192.168.4.111:8888 (socat) -> 192.168.11.126:8081 over tun0.
#   socat opens the upstream leg from THIS host, so the VPN return path works
#   and no MASQUERADE/ip_forward is required.
# - Listener is locked to the client source IP (socat range=).
# - Actions: up (default) | down | status. Runs socat in the background, tracks
#   it by pidfile so `down` is exact.
#
# OIDC LIMIT: browser login will NOT complete through this single forward — the
# platform emits absolute 192.168.11.126:9000 URLs the client can't reach. This
# enables the UI shell + API/Bearer-token access. For full web login use the
# gateway-route approach, or reseed the platform with 192.168.4.111 URLs.
set -euo pipefail

# --- Config (override via env) -----------------------------------------------
LISTEN_IP="${LISTEN_IP:-192.168.4.111}"   # this host's LAN IP (wlo1)
LISTEN_PORT="${LISTEN_PORT:-8888}"        # LAN-facing port (unprivileged)
CLIENT="${CLIENT:-192.168.4.233}"         # only this source IP may connect
TARGET_IP="${TARGET_IP:-192.168.11.126}"  # platform host behind the VPN
TARGET_PORT="${TARGET_PORT:-8081}"        # platform UI/API (traefik)

ACTION="${1:-up}"
PIDFILE="/tmp/lan-fwd-${LISTEN_PORT}.pid"
LOGFILE="/tmp/lan-fwd-${LISTEN_PORT}.log"

running() { [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; }

up() {
  command -v socat >/dev/null || { echo "ERROR: socat not installed" >&2; exit 1; }
  running && { echo "Already up (pid $(cat "$PIDFILE")) on ${LISTEN_IP}:${LISTEN_PORT}"; exit 0; }
  [[ "$(cat /sys/class/net/tun0/operstate 2>/dev/null || echo down)" == "down" ]] && \
    echo "WARN: tun0 looks down — VPN must be up for the forward to reach ${TARGET_IP}." >&2
  # fork: one child per connection; reuseaddr: fast restart; range: source lock.
  setsid socat \
    "TCP4-LISTEN:${LISTEN_PORT},bind=${LISTEN_IP},fork,reuseaddr,range=${CLIENT}/32" \
    "TCP4:${TARGET_IP}:${TARGET_PORT}" \
    >"$LOGFILE" 2>&1 < /dev/null &
  echo $! > "$PIDFILE"
  sleep 0.3
  running || { echo "ERROR: socat failed to start — see $LOGFILE:" >&2; cat "$LOGFILE" >&2; rm -f "$PIDFILE"; exit 1; }
  echo "UP (pid $(cat "$PIDFILE")): ${LISTEN_IP}:${LISTEN_PORT}  ->  ${TARGET_IP}:${TARGET_PORT}   (client ${CLIENT} only)"
  echo "From the client: curl -I http://${LISTEN_IP}:${LISTEN_PORT}/   then browse http://${LISTEN_IP}:${LISTEN_PORT}/"
}

down() {
  if running; then kill "$(cat "$PIDFILE")" 2>/dev/null || true; echo "DOWN: stopped pid $(cat "$PIDFILE")"; else echo "Not running."; fi
  rm -f "$PIDFILE"
}

status() {
  if running; then echo "RUNNING pid $(cat "$PIDFILE") on ${LISTEN_IP}:${LISTEN_PORT} -> ${TARGET_IP}:${TARGET_PORT} (client ${CLIENT})";
  else echo "STOPPED"; fi
  ss -ltnp 2>/dev/null | grep ":${LISTEN_PORT} " || true
}

case "$ACTION" in
  up)     up ;;
  down)   down ;;
  status) status ;;
  *) echo "usage: $0 [up|down|status]   (env: LISTEN_IP= LISTEN_PORT= CLIENT= TARGET_IP= TARGET_PORT=)" >&2; exit 2 ;;
esac

# PERSIST across reboot (optional): wrap in a systemd unit, e.g.
#   ExecStart=/usr/bin/socat TCP-LISTEN:8888,bind=192.168.4.111,fork,reuseaddr,range=192.168.4.233/32 TCP:192.168.11.126:8081
# socat dies if tun0 drops mid-connection; just re-run `up` after the VPN reconnects.
