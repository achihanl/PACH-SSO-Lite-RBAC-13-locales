# AZBlink Directory - Local Development

Quick-start guide for running the Directory API locally with Docker Compose.

## Prerequisites

- Docker & Docker Compose v2+
- ~2GB disk space

## Deploying to a server

Server deployments use **Ansible** — see `deploy/ansible/README.md`. It installs
host dependencies (Docker, just), renders a per-environment `.env` (production
secrets via `ansible-vault`; `DEV_AUTH_TOKEN` omitted and `ENVIRONMENT=production`
so the dev auth-bypass cannot start), deploys the stack, and gates on a seed/health
verify. Ansible is the only supported path for any network-reachable host.

> **This README covers local development only.** Do not point a browser-reachable
> host at the dev Compose defaults (default credentials, `admin/admin` Grafana,
> plaintext transport). Use the Ansible path for anything beyond localhost.

> **Deploy with `git clone`, not a tarball.** `src/frontend/src/routeTree.gen.ts`
> is committed *despite* matching `src/frontend/.gitignore` — a `git clone` ships
> it, but a `tarball → git init → git add -A` shortcut silently drops it (and any
> other tracked-but-ignored file), breaking the UI with `Failed to resolve import
> "./routeTree.gen"`. The dev UI container also self-heals a missing route tree on
> restart (see `TSR_TMP_DIR` in `docker-compose.yml`).

## Quick Start

```bash
# First time (builds images, ~45s)
docker compose up --build

# Subsequent runs (~2s)
docker compose up

# Background mode
docker compose up -d
```

A raw `docker compose` here only matches `just up` if `.env` sets
`COMPOSE_FILE=docker-compose.yml:docker-compose.dev.yml` and
`COMPOSE_PROFILES=dev`, as `.env.example` does. The web UI (`directory-ui`) is in
the `dev` profile. Without these lines the stack starts with no UI, so
`http://localhost:8081/` returns Traefik's `404 page not found`, and a raw
`docker compose down` removes the UI container for good. A `.env` made before
these lines existed lacks them: run `just setup` to add them. `just` sets both
variables itself, so `just up` / `just up-bg` are not affected.

## Services

| Service | URL | Notes |
|---------|-----|-------|
| UI | http://localhost:8081/ | React admin interface |
| API | http://localhost:8081/api | REST API |
| API Docs | http://localhost:8081/api/docs | OpenAPI/Swagger |
| PostgreSQL | localhost:5433 | Port 5433 to avoid conflicts |
| OpenLDAP | localhost:1390 | Port 1390 to avoid conflicts |
| Redis | localhost:6380 | Rate limiting / caching |
| UED Sync | http://ued-sync:8000 | Internal only — no host port. Stateless LDAP provisioner for XMPP/SIP. |
| Traefik Dashboard | http://localhost:8083 | Routing debug |

## Preseed Accounts

### LDAP Admin (for direct LDAP operations)

| Attribute | Value |
|-----------|-------|
| DN | `cn=admin,dc=azblink,dc=com` |
| Password | `adminpassword` |

### Web Portal Login

Web admin access comes from membership of the **Authentik** `IT-Admins` group,
not the LDAP one. Authentik deliberately does not sync `IT-Admins` from LDAP: the
LDAP source syncs only first-party clients' `<client_id>-*` role groups (gap report
G12, `ldap_group_filter` in `authentik-seed/seed_authentik.py`). The seed adds one
user, `LDAP_DEMO_SSO_USER` (default `mei`), to Authentik's `IT-Admins`.

| Username | Password | Web access |
|----------|----------|------------|
| `mei` | `password123` | **Web admin.** The only seeded admin test account. |
| any other LDAP user | see below | Signs in, but every admin API call returns 403 `Admin group required`. |
| `akadmin` | `AUTHENTIK_BOOTSTRAP_PASSWORD` in `deploy/dev/.env` | Authentik admin at http://localhost:9000/, not a directory web admin. The password is no longer `adminpassword`. |

### All Bootstrap Users (from `bootstrap.ldif`)

The Group column is the **LDAP** group. LDAP `IT-Admins` membership does not
make robert or alex web admins (see above).

| UID | Name | Password | Group |
|-----|------|----------|-------|
| robert | Robert Lin | `password123` | IT-Admins (LDAP only, not a web admin) |
| alex | Alex Chen | `password123` | IT-Admins (LDAP only, not a web admin) |
| sarah | Sarah Kim | `password123` | Engineering |
| james | James Miller | `password123` | Engineering |
| mei | Mei Wang | `password123` | All-Staff |
| kevin | Kevin Huang | `password123` | All-Staff |
| laura | Laura Chen | `password123` | All-Staff |

### Demo Users (from `seed` service)

On first startup, the `seed` container adds **50+ additional users** with realistic org structure:
- Password for all demo users: `demo123`
- Includes executives, sales, operations, finance, HR, legal, customer success
- See `deploy/dev/seed/seed_demo_data.py` for full list

## Seeding Process

The dev environment seeds data in two stages:

1. **bootstrap.ldif** - Mounted into OpenLDAP, creates 7 core users + 4 groups + org tree
2. **seed service** - Runs once after LDAP is healthy, adds 50+ demo users with avatars

To re-seed from scratch:
```bash
docker compose down -v  # Deletes all data
docker compose up --build
```

## Hot Reload

All Python and frontend code hot-reloads automatically:

| Service | Source Path | Mechanism |
|---------|------------|-----------|
| Directory API | `src/backend/*.py` | uvicorn `--reload` |
| UED Sync | `src/ued-sync/src/**/*.py` | uvicorn `--reload` |
| UI | `src/frontend/src/**/*` | Vite HMR |

Watch logs:
```bash
docker compose logs -f directory-api  # API logs
just ued-logs                          # UED Sync logs
```

## Test Data Summary

OpenLDAP is pre-seeded with:
- **~58 users**: 7 bootstrap + ~51 demo (passwords: `password123` / `demo123`)
- **~12 groups**: IT-Admins, Engineering, All-Staff, Managers, C-Suite, Directors, etc.
- **~30 org units**: GlobalHQ → Engineering/Sales/Marketing/Operations/etc.

## Useful Commands

Use `just` for common operations (run `just --list` for full list):

```bash
# Stack management
just up              # Start with build (foreground)
just up-bg           # Start in background
just down            # Stop (preserves data)
just reset           # Stop and delete all data
just ps              # Container status

# Logs
just logs            # API logs (follow mode)
just ued-logs        # UED Sync logs (follow mode)

# Testing
just test            # Backend integration tests
just ued-test        # UED Sync unit tests (in container)
just test-all        # All tests (backend + UED Sync)

# UED Sync management
just ued-restart     # Restart UED Sync container
just ued-rebuild     # Rebuild UED Sync (after dep changes)
just ued-test-cov    # UED Sync tests with coverage

# Database / LDAP
just psql            # PostgreSQL shell
just ldap-users      # List LDAP users
just ldap-orgs       # List LDAP org tree

# Quick access
just docs            # Open API docs in browser
just browse          # Open UI in browser
```

### Manual Commands

```bash
# Authenticated API call (dev bypass; there is no login endpoint, ARD-002)
curl -H "Authorization: Bearer $DEV_AUTH_TOKEN" http://localhost:8081/api/users

# Query LDAP users (from host)
ldapsearch -x -H ldap://localhost:1390 -b "ou=people,dc=azblink,dc=com" \
  -D "cn=admin,dc=azblink,dc=com" -w adminpassword "(objectClass=inetOrgPerson)" uid cn

# Reset everything (deletes all data)
docker compose down -v
```

## Troubleshooting

**API won't start?**
```bash
docker compose logs directory-api
```

**LDAP connection refused?**
Wait for OpenLDAP to fully initialize (~10s on first start).

**Seed service failed?**
```bash
docker compose logs seed
```

**Reset to clean state:**
```bash
docker compose down -v
docker compose up --build
```

## UED Sync API

The UED Sync service is an internal microservice for provisioning XMPP/SIP accounts on tenant UC LDAP servers. It runs inside the Docker network with no host port — only the Directory API communicates with it.

**Key points:**
- Stateless: all config passed per-request from Directory API
- Optional: stack works without it for basic directory operations
- Hot reload: edit `src/ued-sync/src/` and changes apply automatically
- Tests run inside container: `just ued-test` (uses `/app/.venv/bin/python`, not system Python)

**Environment variables** (in `.env`):
```bash
UED_API_KEY=dev-ued-api-key          # Shared auth key between API and UED Sync
UED_ENCRYPTION_KEY=                  # Fernet key (needed only when tenant configs exist)
```

## See Also

- [DEPLOYMENT_SPEC.md](./DEPLOYMENT_SPEC.md) - Full deployment specification
