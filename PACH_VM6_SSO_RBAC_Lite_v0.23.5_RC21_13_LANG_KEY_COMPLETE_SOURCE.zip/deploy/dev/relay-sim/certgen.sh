#!/bin/sh
# certgen.sh DIR HOST — a throwaway CA and a certificate for HOST, written as the
# three files ansible renders on a prod box (roles/azblink_app/tasks/config.yml):
# fullchain.pem, privkey.pem, ca.pem. Test stacks only. Keeps existing files, so
# a restart does not change the certificate under running readers.
set -eu
dir=$1
host=$2
[ -s "$dir/fullchain.pem" ] && [ -s "$dir/privkey.pem" ] && [ -s "$dir/ca.pem" ] && exit 0
work=$(mktemp -d)
openssl req -x509 -newkey rsa:2048 -nodes -days 30 -subj "/CN=relay-sim test CA" \
  -keyout "$work/ca.key" -out "$work/ca.pem" \
  -addext "basicConstraints=critical,CA:TRUE" -addext "keyUsage=critical,keyCertSign,cRLSign"
openssl req -newkey rsa:2048 -nodes -subj "/CN=$host" -keyout "$work/privkey.pem" -out "$work/leaf.csr"
printf 'subjectAltName=DNS:%s\nextendedKeyUsage=serverAuth\n' "$host" > "$work/ext"
openssl x509 -req -in "$work/leaf.csr" -CA "$work/ca.pem" -CAkey "$work/ca.key" -CAcreateserial \
  -days 30 -extfile "$work/ext" -out "$work/leaf.pem"
cat "$work/leaf.pem" > "$dir/fullchain.pem"
cp "$work/ca.pem" "$dir/ca.pem"
cp "$work/privkey.pem" "$dir/privkey.pem"
# Readers run as other users (Authentik uid 1000, slapd's openldap). Test key only.
chmod 644 "$dir"/*.pem
rm -rf "$work"
echo "certgen: CA and certificate for $host in $dir"
