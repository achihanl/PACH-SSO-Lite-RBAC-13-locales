#!/bin/sh
# pbx-sim: Asterisk with PJSIP endpoints, auths and AoRs read live from LDAP,
# the way UED on the PED80 does it (ARD-020 verification amendment).
set -eu
cp /sim/asterisk/*.conf /etc/asterisk/
mkdir -p /var/run/asterisk /var/lib/asterisk /var/log/asterisk /var/spool/asterisk
exec asterisk -f -U root -vvv
