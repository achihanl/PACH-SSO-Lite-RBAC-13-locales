"""relayctl: what a building's boxes do on the routed private path, stdlib only.

Runs inside the relay-sim boxes (docker-compose.relay-sim.yml); each command
prints one JSON object. tests/test_relay_path.py drives it with `docker exec`.

  discovery APP              GET <issuer>/.well-known/openid-configuration
  token CLIENT SECRET        client_credentials token; prints its iss and aud
  login FLOW USER PW         one password attempt through a flow executor,
        [--xff IP]           as a relay that forwards the client IP
        [--cf-ip IP]         with CF-Connecting-IP set, as cloudflared sends it
        [--plain]            over plain HTTP (cloudflared -> edge), not TLS
  tls NAME                   TLS handshake to --connect, verified for NAME
  sip-register EXT PW        REGISTER with digest auth
  sip-call A PW_A B PW_B     both register, A calls B, B rings then answers busy
  xmpp-login JID PW          SASL PLAIN and resource bind

--connect HOST:PORT pins the server like `curl --resolve`: the URL, Host header
and certificate check keep the public name, the socket goes to HOST:PORT.

A SECRET or PW given as "-" is read from stdin, one line per "-" in order: in
argv it would show in error messages, and one starting with "-" reads as an option.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import http.client
import json
import re
import socket
import ssl
import sys
import threading
import time
import urllib.parse
import uuid

PUBLIC_HOST = "id.relay.test"
CA = "/tls/ca.pem"


# ── HTTPS on the relay path ──────────────────────────────────────────────────


class _Pinned(http.client.HTTPSConnection):
    """HTTPS to the public name, with the TCP connection pinned to one address."""

    def __init__(self, host: str, addr: tuple[str, int], ctx: ssl.SSLContext):
        super().__init__(host, 443, context=ctx, timeout=60)
        self._addr = addr

    def connect(self) -> None:
        sock = socket.create_connection(self._addr, self.timeout)
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


class _PinnedHTTP(http.client.HTTPConnection):
    """Plain HTTP to the public name with the socket pinned: cloudflared's hop to the edge."""

    def __init__(self, host: str, addr: tuple[str, int], _ctx=None):
        super().__init__(host, 80, timeout=60)
        self._addr = addr

    def connect(self) -> None:
        self.sock = socket.create_connection(self._addr, self.timeout)


class Session:
    def __init__(self, connect: str, xff: str | None = None, cf_ip: str | None = None, plain: bool = False):
        ip, port = connect.rsplit(":", 1)
        self.addr = (ip, int(port))
        self.ctx = None if plain else ssl.create_default_context(cafile=CA)
        self.cookies: dict[str, str] = {}
        self.xff, self.cf_ip, self.conn_cls = xff, cf_ip, (_PinnedHTTP if plain else _Pinned)

    def request(self, method: str, path: str, body: bytes | None = None,
                ctype: str | None = None) -> tuple[int, bytes]:
        conn = self.conn_cls(PUBLIC_HOST, self.addr, self.ctx)
        headers = {"Accept": "application/json"}
        if ctype:
            headers["Content-Type"] = ctype
        if self.cookies:
            headers["Cookie"] = "; ".join(f"{k}={v}" for k, v in self.cookies.items())
        if self.xff:
            # The relay sets the client IP it observed; it never appends (spec 08).
            headers["X-Forwarded-For"] = self.xff
        if self.cf_ip:
            headers["CF-Connecting-IP"] = self.cf_ip
        conn.request(method, path, body=body, headers=headers)
        resp = conn.getresponse()
        for cookie in resp.headers.get_all("Set-Cookie") or []:
            name, _, rest = cookie.partition("=")
            self.cookies[name.strip()] = rest.split(";", 1)[0]
        data = resp.read()
        conn.close()
        location = resp.headers.get("Location")
        if resp.status in (301, 302, 303) and location:
            # The flow executor answers a stage POST with a redirect to its next challenge.
            target = urllib.parse.urlsplit(location)
            return self.request("GET", target.path + (f"?{target.query}" if target.query else ""))
        return resp.status, data


def cmd_discovery(a) -> dict:
    status, data = Session(a.connect, plain=a.plain).request("GET", f"/application/o/{a.app}/.well-known/openid-configuration")
    return {"status": status, "issuer": json.loads(data).get("issuer") if status == 200 else None}


def cmd_token(a) -> dict:
    form = urllib.parse.urlencode({"grant_type": "client_credentials", "client_id": a.client,
                                   "client_secret": a.secret, "scope": "openid profile"}).encode()
    status, data = Session(a.connect).request("POST", "/application/o/token/", form,
                                              "application/x-www-form-urlencoded")
    if status != 200:
        return {"status": status, "body": data.decode(errors="replace")[:300]}
    payload = json.loads(data)["access_token"].split(".")[1]
    claims = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
    return {"status": status, "iss": claims.get("iss"), "aud": claims.get("aud")}


def cmd_login(a) -> dict:
    s = Session(a.connect, xff=a.xff, cf_ip=a.cf_ip, plain=a.plain)
    ex = f"/api/v3/flows/executor/{a.flow}/?query="
    s.request("GET", ex)

    def post(body: dict) -> str:
        status, data = s.request("POST", ex, json.dumps(body).encode(), "application/json")
        try:
            comp = json.loads(data).get("component")
        except ValueError:
            return f"http{status}"
        return {"ak-stage-password": "bind-failed", "xak-flow-redirect": "signed-in",
                "ak-stage-access-denied": "refused"}.get(comp, comp or f"http{status}")

    first = post({"component": "ak-stage-identification", "uid_field": a.user})
    if first != "bind-failed":  # "bind-failed" here = the password stage is next
        return {"outcome": first}
    return {"outcome": post({"component": "ak-stage-password", "password": a.password})}


def cmd_tls(a) -> dict:
    ip, port = a.connect.rsplit(":", 1)
    ctx = ssl.create_default_context(cafile=CA)
    try:
        with socket.create_connection((ip, int(port)), timeout=10) as sock:
            with ctx.wrap_socket(sock, server_hostname=a.name) as tls:
                return {"ok": True, "subject": dict(x[0] for x in tls.getpeercert()["subject"])}
    except (ssl.SSLError, OSError) as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


# ── SIP phone (UDP, digest auth) ─────────────────────────────────────────────


def _md5(s: str) -> str:
    return hashlib.md5(s.encode(), usedforsecurity=False).hexdigest()


def _parse(raw: bytes) -> dict:
    text = raw.decode(errors="replace")
    head, _, body = text.partition("\r\n\r\n")
    lines = head.split("\r\n")
    headers: list[tuple[str, str]] = []
    for line in lines[1:]:
        name, _, value = line.partition(":")
        headers.append((name.strip().lower(), value.strip()))
    first = lines[0].split(" ", 2)
    msg = {"first": lines[0], "headers": headers, "body": body}
    if first[0].startswith("SIP/"):
        msg["status"] = int(first[1])
    else:
        msg["method"] = first[0]
    return msg


def _h(msg: dict, name: str) -> str:
    return next((v for k, v in msg["headers"] if k == name), "")


def _digest(challenge: str, user: str, password: str, method: str, uri: str) -> str:
    p = {m.group(1).lower(): m.group(2) or m.group(3)
         for m in re.finditer(r'(\w+)\s*=\s*(?:"([^"]*)"|([^,\s]+))', challenge)}
    ha1, ha2 = _md5(f"{user}:{p['realm']}:{password}"), _md5(f"{method}:{uri}")
    parts = [f'username="{user}"', f'realm="{p["realm"]}"', f'nonce="{p["nonce"]}"', f'uri="{uri}"',
             "algorithm=MD5"]
    if "qop" in p:
        cnonce = uuid.uuid4().hex[:16]
        parts += [f'response="{_md5(f"{ha1}:{p["nonce"]}:00000001:{cnonce}:auth:{ha2}")}"',
                  "qop=auth", "nc=00000001", f'cnonce="{cnonce}"']
    else:
        parts.append(f'response="{_md5(f"{ha1}:{p["nonce"]}:{ha2}")}"')
    if "opaque" in p:
        parts.append(f'opaque="{p["opaque"]}"')
    return "Digest " + ", ".join(parts)


class Phone:
    def __init__(self, ext: str, password: str, pbx: str):
        self.ext, self.password, self.pbx = ext, password, (pbx, 5060)
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(self.pbx)
        self.ip = probe.getsockname()[0]
        probe.close()
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((self.ip, 0))
        self.port = self.sock.getsockname()[1]
        self.tag = uuid.uuid4().hex[:8]
        self.cseq = 1

    def _via(self) -> str:
        return f"SIP/2.0/UDP {self.ip}:{self.port};branch=z9hG4bK-{uuid.uuid4().hex[:12]};rport"

    def send(self, text: str) -> None:
        self.sock.sendto(text.encode(), self.pbx)

    def recv(self, timeout: float) -> dict | None:
        """Next message, answering the PBX's qualify OPTIONS on the way."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            self.sock.settimeout(max(0.05, deadline - time.time()))
            try:
                raw, _ = self.sock.recvfrom(65535)
            except socket.timeout:
                return None
            msg = _parse(raw)
            if msg.get("method") == "OPTIONS":
                self.reply(msg, 200, "OK")
                continue
            return msg
        return None

    def reply(self, req: dict, code: int, reason: str, to_tag: str | None = None) -> None:
        vias = "".join(f"Via: {v}\r\n" for k, v in req["headers"] if k == "via")
        to = _h(req, "to") + (f";tag={to_tag}" if to_tag and "tag=" not in _h(req, "to") else "")
        self.send(f"SIP/2.0 {code} {reason}\r\n{vias}From: {_h(req, 'from')}\r\nTo: {to}\r\n"
                  f"Call-ID: {_h(req, 'call-id')}\r\nCSeq: {_h(req, 'cseq')}\r\n"
                  f"Contact: <sip:{self.ext}@{self.ip}:{self.port}>\r\nContent-Length: 0\r\n\r\n")

    def _request(self, method: str, uri: str, to: str, call_id: str, extra: str = "",
                 body: str = "", ctype: str = "") -> str:
        via = self._via()
        msg = (f"{method} {uri} SIP/2.0\r\nVia: {via}\r\nMax-Forwards: 70\r\n"
               f"From: <sip:{self.ext}@{self.pbx[0]}>;tag={self.tag}\r\nTo: {to}\r\n"
               f"Call-ID: {call_id}\r\nCSeq: {self.cseq} {method}\r\n"
               f"Contact: <sip:{self.ext}@{self.ip}:{self.port}>\r\nUser-Agent: relay-sim\r\n{extra}"
               + (f"Content-Type: {ctype}\r\n" if ctype else "")
               + f"Content-Length: {len(body)}\r\n\r\n{body}")
        self.send(msg)
        return via

    def _final(self, timeout: float = 8.0) -> tuple[dict | None, list[int]]:
        seen = []
        while True:
            msg = self.recv(timeout)
            if msg is None or "status" not in msg:
                if msg is None:
                    return None, seen
                continue
            seen.append(msg["status"])
            if msg["status"] >= 200:
                return msg, seen

    def register(self) -> int:
        uri, to, call_id = f"sip:{self.pbx[0]}", f"<sip:{self.ext}@{self.pbx[0]}>", uuid.uuid4().hex
        extra = "Expires: 120\r\n"
        self._request("REGISTER", uri, to, call_id, extra)
        resp, _ = self._final()
        if resp and resp["status"] == 401:
            self.cseq += 1
            auth = _digest(_h(resp, "www-authenticate"), self.ext, self.password, "REGISTER", uri)
            self._request("REGISTER", uri, to, call_id, extra + f"Authorization: {auth}\r\n")
            resp, _ = self._final()
        self.cseq += 1
        return resp["status"] if resp else 0

    def _ack(self, uri: str, to_hdr: str, call_id: str, via: str, cseq: int) -> None:
        self.send(f"ACK {uri} SIP/2.0\r\nVia: {via}\r\nMax-Forwards: 70\r\n"
                  f"From: <sip:{self.ext}@{self.pbx[0]}>;tag={self.tag}\r\nTo: {to_hdr}\r\n"
                  f"Call-ID: {call_id}\r\nCSeq: {cseq} ACK\r\nContent-Length: 0\r\n\r\n")

    def invite(self, callee: str) -> list[int]:
        uri, call_id = f"sip:{callee}@{self.pbx[0]}", uuid.uuid4().hex
        to = f"<sip:{callee}@{self.pbx[0]}>"
        sdp = (f"v=0\r\no=- 1 1 IN IP4 {self.ip}\r\ns=-\r\nc=IN IP4 {self.ip}\r\nt=0 0\r\n"
               "m=audio 40000 RTP/AVP 0 8\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\n")
        via = self._request("INVITE", uri, to, call_id, body=sdp, ctype="application/sdp")
        resp, codes = self._final()
        if resp and resp["status"] in (401, 407):
            self._ack(uri, _h(resp, "to"), call_id, via, self.cseq)
            self.cseq += 1
            name = "Proxy-Authorization" if resp["status"] == 407 else "Authorization"
            challenge = _h(resp, "proxy-authenticate" if resp["status"] == 407 else "www-authenticate")
            auth = _digest(challenge, self.ext, self.password, "INVITE", uri)
            via = self._request("INVITE", uri, to, call_id, f"{name}: {auth}\r\n", sdp, "application/sdp")
            resp, more = self._final(20.0)
            codes += more
        if resp:
            self._ack(uri, _h(resp, "to"), call_id, via, self.cseq)
        self.cseq += 1
        return codes


def cmd_sip_register(a) -> dict:
    return {"status": Phone(a.ext, a.password, a.pbx).register()}


def cmd_sip_call(a) -> dict:
    caller, callee = Phone(a.caller, a.caller_pw, a.pbx), Phone(a.callee, a.callee_pw, a.pbx)
    out = {"callee_register": callee.register(), "caller_register": caller.register(), "callee_got_invite": False}

    def ring() -> None:
        invite = callee.recv(15.0)
        while invite is not None and invite.get("method") != "INVITE":
            invite = callee.recv(15.0)
        if invite is None:
            return
        out["callee_got_invite"] = True
        tag = uuid.uuid4().hex[:8]
        callee.reply(invite, 180, "Ringing", tag)
        time.sleep(0.5)
        callee.reply(invite, 486, "Busy Here", tag)
        callee.recv(2.0)  # the PBX's ACK

    ringer = threading.Thread(target=ring)
    ringer.start()
    out["caller_codes"] = caller.invite(a.callee)
    ringer.join()
    return out


# ── XMPP client login (SASL PLAIN, resource bind) ────────────────────────────


def cmd_xmpp_login(a) -> dict:
    user, _, domain = a.jid.partition("@")
    sock = socket.create_connection((a.server, 5222), timeout=15)
    buf = b""

    def until(*marks: bytes) -> bytes:
        nonlocal buf
        while not any(m in buf for m in marks):
            chunk = sock.recv(65536)
            if not chunk:
                break
            buf += chunk
        got, buf = buf, b""
        return got

    def stream() -> bytes:
        sock.sendall(f"<?xml version='1.0'?><stream:stream to='{domain}' xmlns='jabber:client' "
                     "xmlns:stream='http://etherx.jabber.org/streams' version='1.0'>".encode())
        return until(b"</stream:features>")

    try:
        features = stream()
        if b"PLAIN" not in features:
            return {"ok": False, "error": "no SASL PLAIN offered"}
        token = base64.b64encode(f"\0{user}\0{a.password}".encode()).decode()
        sock.sendall(f"<auth xmlns='urn:ietf:params:xml:ns:xmpp-sasl' mechanism='PLAIN'>{token}</auth>".encode())
        result = until(b"<success", b"</failure>")
        if b"<success" not in result:
            m = re.search(rb"<failure[^>]*>\s*<([\w-]+)", result)
            return {"ok": False, "error": m.group(1).decode() if m else result.decode(errors="replace")[:200]}
        stream()
        sock.sendall(b"<iq type='set' id='bind1'><bind xmlns='urn:ietf:params:xml:ns:xmpp-bind'>"
                     b"<resource>relay-sim</resource></bind></iq>")
        bound = re.search(rb"<jid>([^<]+)</jid>", until(b"</iq>"))
        return {"ok": bool(bound), "jid": bound.group(1).decode() if bound else None}
    finally:
        sock.close()


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name, fn, args in (
        ("discovery", cmd_discovery, ["app"]),
        ("token", cmd_token, ["client", "secret"]),
        ("login", cmd_login, ["flow", "user", "password"]),
        ("tls", cmd_tls, ["name"]),
        ("sip-register", cmd_sip_register, ["ext", "password"]),
        ("sip-call", cmd_sip_call, ["caller", "caller_pw", "callee", "callee_pw"]),
        ("xmpp-login", cmd_xmpp_login, ["jid", "password"]),
    ):
        sp = sub.add_parser(name)
        for arg in args:
            sp.add_argument(arg)
        sp.add_argument("--connect", help="HOST:PORT the socket goes to")
        sp.add_argument("--xff")
        sp.add_argument("--cf-ip")
        sp.add_argument("--plain", action="store_true")
        sp.add_argument("--pbx")
        sp.add_argument("--server")
        sp.set_defaults(fn=fn)
    a = p.parse_args()
    for name in ("secret", "password", "caller_pw", "callee_pw"):
        if getattr(a, name, None) == "-":
            setattr(a, name, sys.stdin.readline().rstrip("\n"))
    print(json.dumps(a.fn(a)))


if __name__ == "__main__":
    main()
