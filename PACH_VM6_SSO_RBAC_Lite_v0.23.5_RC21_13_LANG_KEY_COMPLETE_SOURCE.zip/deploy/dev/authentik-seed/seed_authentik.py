#!/usr/bin/env python3
"""
Seed Authentik with AZBlink OIDC application config and branding.

- Applies AZBlink brand theme (logo, favicon, custom CSS, dark mode)
- Creates OAuth2 provider (public client, PKCE)
- Creates application linked to provider
- Sets default_application on brand for post-login redirect
- Creates IT-Admins group with akadmin assigned
- Creates the directory API's Admin API token when it differs from the bootstrap token
- Creates API-to-API service clients and headless first-party clients (ARD-018)
- Idempotent — safe to run multiple times, patches existing config
"""

import json
import os
import re
import sys
import time
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from urllib.parse import quote

API_URL = os.getenv("AUTHENTIK_API_URL", "http://authentik-server:9000")
API_TOKEN = os.getenv("AUTHENTIK_BOOTSTRAP_TOKEN", "dev-authentik-api-token")

# Directory API (for self-provisioning the LDAP sync client in dev)
DIRECTORY_API_URL = os.getenv("DIRECTORY_API_URL", "http://directory-api:8000")
DEV_AUTH_TOKEN = os.getenv("DEV_AUTH_TOKEN", "")
SYNC_CLIENT_ID = os.getenv("AUTHENTIK_LDAP_SYNC_CLIENT_ID", "authentik-sync")
SYNC_CLIENT_PASSWORD = os.getenv("AUTHENTIK_LDAP_SYNC_PASSWORD", "")
LDAP_SOURCE_URI = os.getenv("LDAP_URI", "ldap://openldap:389")
LDAP_DEMO_SSO_USER = os.getenv("LDAP_DEMO_SSO_USER", "mei")
LDAP_SOURCE_SLUG = "azblink-ldap"
LDAP_SOURCE_NAME = "AZBlink Directory LDAP"
LDAP_BASE_DN = os.getenv("LDAP_BASE_DN", "dc=azblink,dc=com")

MAX_RETRIES = 30
RETRY_DELAY = 5
# A fresh Authentik spends 2.5-4 min on CPU-bound migrations, longer on a busy
# box: wait on a time budget, not an attempt count (t-0029). The worker then
# creates default flows and mappings, on the same budget (_polls).
AUTHENTIK_WAIT_SEC = int(os.getenv("AUTHENTIK_WAIT_SEC", "600"))
# Once some flow of a designation exists, how long to wait for the preferred one
# (_get_flow_pk) before taking what is there.
PREFERRED_FLOW_WAIT_SEC = 60


def _polls():
    """Yield until AUTHENTIK_WAIT_SEC has passed, sleeping RETRY_DELAY between yields.

    For what Authentik's worker creates after the API answers (default flows,
    scope and source mappings). A fixed 12 polls (60 s) gave up on a loaded fresh
    box, and the web provider got no `profile` mapping (CI run 39803379493).
    """
    deadline = time.monotonic() + AUTHENTIK_WAIT_SEC
    while True:
        yield
        if time.monotonic() >= deadline:
            return
        time.sleep(RETRY_DELAY)

# Built-in scope mappings the provider needs. Note there is deliberately NO
# custom `groups` mapping: Authentik's built-in `profile` mapping already emits
# a `groups` claim, and adding a second emitter doubles it (#279, see
# delete_legacy_groups_scope_mapping).
WANTED_SCOPE_MAPPINGS = {
    "goauthentik.io/providers/oauth2/scope-openid",
    "goauthentik.io/providers/oauth2/scope-profile",
    "goauthentik.io/providers/oauth2/scope-email",
    "goauthentik.io/providers/oauth2/scope-offline_access",
}
LEGACY_GROUPS_MAPPING_NAME = "AZBlink OAuth Mapping: groups"

# OAuth2 provider config
CLIENT_ID = "azblink-directory"
_DEFAULT_REDIRECT_URIS = (
    "https://azblink-ad.keithmoc.dev/auth/callback,"
    "http://localhost:8081/auth/callback,"
    "http://127.0.0.1:8081/auth/callback,"
    # web SSO provisioning debugger — see tools/web-sso-provision-ref/
    # LAN callbacks (e.g. http://<dev-box-lan-ip>:5173/callback) must be added
    # via the OAUTH2_REDIRECT_URIS env so we do not bake one workstation's IP
    # into the default set (CodeRabbit #1).
    "http://localhost:5173/callback,"
    "http://127.0.0.1:5173/callback"
)
# Post-logout (RP-initiated logout) redirect targets. Authentik 2026.5 validates
# post_logout_redirect_uri against redirect_uris of type "logout" (distinct from
# the authorization callbacks above) AND requires id_token_hint — without a
# registered logout URI the end-session endpoint returns 400. Frontend logout
# lands on <origin>/login (see src/frontend/src/lib/oidc.ts getLogoutUrl).
_DEFAULT_POST_LOGOUT_REDIRECT_URIS = (
    "https://azblink-ad.keithmoc.dev/login,"
    "http://localhost:8081/login,"
    "http://127.0.0.1:8081/login"
)
_env_uris = os.getenv("OAUTH2_REDIRECT_URIS", "").strip()
_env_logout_uris = os.getenv("OAUTH2_POST_LOGOUT_REDIRECT_URIS", "").strip()
REDIRECT_URIS = [
    {"matching_mode": "strict", "url": url.strip()}
    for url in (_env_uris or _DEFAULT_REDIRECT_URIS).split(",")
    if url.strip()
] + [
    {"matching_mode": "strict", "url": url.strip(), "redirect_uri_type": "logout"}
    for url in (_env_logout_uris or _DEFAULT_POST_LOGOUT_REDIRECT_URIS).split(",")
    if url.strip()
]
APP_SLUG = "azblink-directory"
APP_NAME = "AZBlink Directory"
ADMIN_GROUP_NAME = "IT-Admins"
# 2026.5+: providers carry a per-provider grant allowlist; freshly created
# providers default to [] (all grants refused) — must be set explicitly.
# No client_credentials: with it, any app-password holder mints a token this
# API accepts without the browser flow (MFA, policies). The test suite mints
# its user tokens through the dev-only `azblink-directory-test` service client.
GRANT_TYPES = ["authorization_code", "refresh_token"]
# API-to-API callers (CSV of client_ids) — one confidential client_credentials
# provider each; see ensure_service_client. Empty = none (prod default).
SERVICE_CLIENTS = [c.strip() for c in os.getenv("AUTHENTIK_SERVICE_CLIENTS", "").split(",") if c.strip()]
# The dev/CI-only service client tests/conftest.py mints user tokens through: the one
# service client that keeps accepting human app passwords (no access policy, B2).
TEST_USER_TOKEN_CLIENT = "azblink-directory-test"

_FIRST_PARTY_CLIENT_ID = re.compile(r"^[a-z0-9][a-z0-9-]{1,62}$")


def parse_first_party_clients(raw: str, reserved: set[str]) -> dict[str, list[str]]:
    """AUTHENTIK_FIRST_PARTY_CLIENTS: JSON {client_id: [redirect_uri, ...]}. Empty = none.

    One JSON value, not per-client env names: `AUTHENTIK_CLIENT_SAFENEST-A1_*`
    is not a valid env name (gap report G13). Allowed groups are not configured:
    they are always `<client_id>-*` (ARD-018).
    """
    if not raw.strip():
        return {}
    clients = json.loads(raw)
    if not isinstance(clients, dict):
        raise ValueError("AUTHENTIK_FIRST_PARTY_CLIENTS must be a JSON object {client_id: [redirect_uri, ...]}")
    for client_id, uris in clients.items():
        if not _FIRST_PARTY_CLIENT_ID.match(client_id):
            raise ValueError(f"first-party client_id {client_id!r} must match {_FIRST_PARTY_CLIENT_ID.pattern}")
        if client_id in reserved:
            raise ValueError(f"first-party client_id {client_id!r} is already used by another provider")
        if not isinstance(uris, list) or not uris or not all(isinstance(u, str) and u.strip() for u in uris):
            raise ValueError(f"first-party client {client_id!r} needs a non-empty list of redirect URIs")
        # ARD-019 §1: `safenest-a1-*` members would pass `safenest`'s `<client_id>-*` access policy.
        nested = [other for other in clients if other.startswith(f"{client_id}-")]
        if nested:
            raise ValueError(f"first-party client_id {client_id!r} nests with {nested}")
    return clients


# Headless first-party clients (ARD-018): confidential authorization_code +
# refresh_token providers whose backend relays its own login form. Empty = none.
FIRST_PARTY_CLIENTS = parse_first_party_clients(
    os.getenv("AUTHENTIK_FIRST_PARTY_CLIENTS", ""), reserved={CLIENT_ID, *SERVICE_CLIENTS})
FIRST_PARTY_GRANT_TYPES = ["authorization_code", "refresh_token"]
HEADLESS_FLOW_SLUG = "headless-first-party-auth"
USERNAME_LOCKOUT_THRESHOLD = -3  # 3 failures; must stay below ppolicy pwdMaxFailure (5) (ARD-018)
HEADLESS_THROTTLE_MESSAGE = "Too many failed sign-in attempts. Use web sign-in or ask an administrator."
# The brand flow behind web sign-in, admin included (gap report G22).
WEB_FLOW_SLUG = "default-authentication-flow"
WEB_THROTTLE_MESSAGE = "Too many failed sign-in attempts. Ask an administrator to unblock your account."
# Bind budget (gap report G23): password POSTs per username that may be at LDAP or failed there,
# reserved atomically before the bind. The window slides from the last reservation and must outlast
# ppolicy's pwdFailureCountInterval (3600) plus a running bind, so LDAP has forgotten every failure
# it counted before the budget resets.
BIND_BUDGET = -USERNAME_LOCKOUT_THRESHOLD
BIND_BUDGET_WINDOW = 3900
# One Reputation row per username holds -(reservations). ReputationPolicy matches identifiers
# exactly, and no client IP is '::', so neither the reputation check nor update_score() sees it.
BIND_BUDGET_PREFIX = "ldap-bind-budget:"
BIND_BUDGET_IP = "::"
BIND_BUDGET_SESSION_KEY = "azb_ldap_bind_budget"
# Source throttle (blocker B5, ARD-018 amendment 2026-10-21): one client IP may spend only 2 of a
# username's 3 failures, so a spray from one source throttles that source and leaves the username
# usable from everywhere else. The IP is Authentik's ak_client_ip: X-Forwarded-For counts only from
# AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS (the relays), otherwise it is the socket peer.
# - Failures: the (username, IP) reputation row, the one Authentik's login_failed writes.
# - Race guard: a second budget row per (username, IP), identifier ldap-bind-budget:<name>, IP the
#   client's; reserved before the username's row, released if the username's is refused.
SOURCE_LOCKOUT_THRESHOLD = -2  # must stay above USERNAME_LOCKOUT_THRESHOLD
SOURCE_BIND_BUDGET = -SOURCE_LOCKOUT_THRESHOLD
_RELEASE = ('release = "UPDATE " + Reputation._meta.db_table + " SET score = LEAST(score + 1, 0), updated = now()'
            ' WHERE identifier = %s AND ip = %s AND expires > now()"')
# Reserve on POST only (only a POST runs the password stage's bind); a GET only renders the form.
# One statement takes a reservation or none (no row returned): a refused attempt reserves nothing,
# so it neither extends the window nor outlives the burst that caused it.
BIND_BUDGET_EXPRESSION = f'''\
import unicodedata
from django.db import connection
from django.db.models import Sum
from authentik.policies.reputation.models import Reputation
http = request.http_request
if http is None or http.method != "POST":
    return True
source = str(ak_client_ip)
failed = Reputation.objects.filter(identifier=request.user.username, ip=source).aggregate(s=Sum("score"))["s"]
if (failed or 0) <= {SOURCE_LOCKOUT_THRESHOLD}:
    return False
name = " ".join(unicodedata.normalize("NFKC", request.user.username).split()).lower()
key = "{BIND_BUDGET_PREFIX}" + name
reserve = (
    "INSERT INTO " + Reputation._meta.db_table + " AS r (reputation_uuid, identifier, ip, ip_geo_data,"
    " ip_asn_data, score, updated, expires, expiring) VALUES (gen_random_uuid(), %s, %s, '{{}}', '{{}}',"
    " -1, now(), now() + make_interval(secs => %s), true) ON CONFLICT (identifier, ip) DO UPDATE SET"
    " score = CASE WHEN r.expires <= now() THEN -1 ELSE r.score - 1 END, updated = now(),"
    " expires = EXCLUDED.expires WHERE r.expires <= now() OR r.score > -%s RETURNING score")
{_RELEASE}
held = []
with connection.cursor() as cursor:
    for ip, budget in ((source, {SOURCE_BIND_BUDGET}), ("{BIND_BUDGET_IP}", {BIND_BUDGET})):
        cursor.execute(reserve, [key, ip, {BIND_BUDGET_WINDOW}, budget])
        if cursor.fetchone() is None:
            for ip in held:
                cursor.execute(release, [key, ip])
            return False
        held.append(ip)
http.session["{BIND_BUDGET_SESSION_KEY}"] = [key, held]
return True'''
# Deny unless a stage authenticated the pending user: the password stage sets user_backend,
# a passkey at identification sets pending_user.backend (and skips the password stage).
# Once authenticated, give back this session's bind-budget reservations (once: the key is popped).
# A bare key is a reservation taken before the source throttle (username row only).
NOT_AUTHENTICATED_EXPRESSION = f'''\
authenticated = "user_backend" in request.context or hasattr(request.context.get("pending_user"), "backend")
http = request.http_request
held = http.session.pop("{BIND_BUDGET_SESSION_KEY}", None) if authenticated and http is not None else None
if held:
    from django.db import connection
    from authentik.policies.reputation.models import Reputation
    key, ips = (held, ["{BIND_BUDGET_IP}"]) if isinstance(held, str) else held
    {_RELEASE}
    with connection.cursor() as cursor:
        for ip in ips:
            cursor.execute(release, [key, ip])
return not authenticated'''

# Seed users — none. alanl was a local-only seed user (not in LDAP); it is removed
# by delete_local_user() below. Web identities come from the LDAP source; akadmin
# stays local (break-glass).
SEED_USERS: list[dict] = []

# Brand config — matches AZBlink design tokens (tokens.css v2.0)
BRAND_TITLE = "AZBlink Directory"
BRAND_LOGO = "/static/dist/assets/azblink/logo.svg"
BRAND_FAVICON = "/static/dist/assets/azblink/favicon.svg"
BRAND_CSS_PATH = "/seed/assets/custom.css"
# ARD-021: the brand's web certificate is what Authentik's :9443 listener (the
# relay path) serves. The worker discovers PEMs mounted at /certs/<name>/ as a
# keypair called <name>. Empty = keep Authentik's self-signed default (dev).
WEB_CERT_NAME = os.getenv("AUTHENTIK_WEB_CERT_NAME", "").strip()


def api_request(method: str, path: str, data: dict | None = None, allow_404: bool = False) -> dict | None:
    """Make an authenticated request to Authentik Admin API v3.

    allow_404 turns "not found" into a normal None answer (no stderr noise) for
    lookups where absence is expected — see find_application().
    """
    url = f"{API_URL}/api/v3{path}"
    headers = {
        "Authorization": f"Bearer {API_TOKEN}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    body = json.dumps(data).encode() if data else None
    req = Request(url, data=body, headers=headers, method=method)
    try:
        with urlopen(req, timeout=30) as resp:
            if resp.status == 204:
                return None
            return json.loads(resp.read().decode())
    except HTTPError as e:
        if allow_404 and e.code == 404:
            return None
        body_text = e.read().decode() if e.fp else ""
        print(f"  API error {e.code}: {body_text[:500]}", file=sys.stderr)
        raise


def directory_api_request(method: str, path: str, data: dict | None = None) -> tuple[int, dict | None]:
    """Call the directory API with the dev bypass token.

    - Returns (status_code, parsed_json_or_None).
    - Does NOT raise on 4xx — callers branch on status (e.g. 409 → rotate).
    """
    url = f"{DIRECTORY_API_URL}{path}"
    headers = {
        "Authorization": f"Bearer {DEV_AUTH_TOKEN}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    body = json.dumps(data).encode() if data else None
    req = Request(url, data=body, headers=headers, method=method)
    try:
        with urlopen(req, timeout=30) as resp:
            payload = None if resp.status == 204 else json.loads(resp.read().decode())
            return resp.status, payload
    except HTTPError as e:
        text = e.read().decode() if e.fp else ""
        try:
            payload = json.loads(text) if text else None
        except json.JSONDecodeError:
            payload = {"detail": text[:500]}
        return e.code, payload


def ensure_sync_client() -> str | None:
    """Ensure the LDAP sync bind account exists; return its secret.

    - Prod (DEV_AUTH_TOKEN unset): secret supplied via AUTHENTIK_LDAP_SYNC_PASSWORD
      (from vault); do NOT self-provision.
    - Dev: POST provision; on 409 rotate to obtain a fresh show-once secret.
    """
    if not DEV_AUTH_TOKEN:
        if not SYNC_CLIENT_PASSWORD:
            print("  WARNING: no DEV_AUTH_TOKEN and no AUTHENTIK_LDAP_SYNC_PASSWORD "
                  "— cannot configure LDAP source bind_password")
            return None
        print("  Using supplied AUTHENTIK_LDAP_SYNC_PASSWORD (prod path)")
        return SYNC_CLIENT_PASSWORD

    status, payload = directory_api_request(
        "POST", "/api/settings/ldap/clients/provisioned",
        {"client_id": SYNC_CLIENT_ID, "label": "Authentik LDAP sync"},
    )
    if status == 200:
        print(f"  Provisioned sync client '{SYNC_CLIENT_ID}'")
        return payload["secret"]
    if status == 409:
        print(f"  Sync client '{SYNC_CLIENT_ID}' exists — rotating for a fresh secret")
        rstatus, rpayload = directory_api_request(
            "POST", f"/api/settings/ldap/clients/provisioned/{SYNC_CLIENT_ID}/rotate",
        )
        if rstatus == 200:
            return rpayload["secret"]
        print(f"  ERROR: rotate failed ({rstatus}): {rpayload}")
        return None
    print(f"  ERROR: provision failed ({status}): {payload}")
    return None


def wait_for_authentik():
    """Wait up to AUTHENTIK_WAIT_SEC for the Authentik API to be reachable."""
    print(f"Waiting up to {AUTHENTIK_WAIT_SEC}s for Authentik at {API_URL}...")
    start = time.monotonic()
    while True:
        try:
            req = Request(
                f"{API_URL}/api/v3/root/config/",
                headers={"Authorization": f"Bearer {API_TOKEN}"},
            )
            with urlopen(req, timeout=5) as resp:
                if resp.status == 200:
                    print(f"  Authentik ready after {time.monotonic() - start:.0f}s")
                    return
        except (URLError, OSError) as e:
            print(f"  {time.monotonic() - start:.0f}s/{AUTHENTIK_WAIT_SEC}s: {e}")
        if time.monotonic() - start >= AUTHENTIK_WAIT_SEC:
            break
        time.sleep(RETRY_DELAY)
    print(f"ERROR: Authentik did not become ready in {AUTHENTIK_WAIT_SEC}s", file=sys.stderr)
    sys.exit(1)


def _get_flow_pk(designation: str, preferred: list[str], label: str) -> str:
    """Find a flow by designation, retrying while the worker imports blueprints.

    - Default flows are created ASYNC by the Authentik worker after the API is
      reachable — the same race get_scope_mapping_pks() guards. Without retry a
      fresh/production deploy crashes here ('No <label> flow found') before the
      OAuth2 provider is created, leaving OIDC web login dead.
    - `preferred` is an ordered list of slug substrings (highest priority first);
      first match wins, else falls back to the first flow returned.
    - The worker imports blueprints one at a time, so the first flows to appear
      need not include `preferred[0]`. Wait up to PREFERRED_FLOW_WAIT_SEC for it
      before falling back: taking explicit consent because it landed first bound
      the first-party providers to a consent screen, and every headless sign-in
      got no authorization code.
    """
    results: list[dict] = []
    first_seen = None
    for _ in _polls():
        resp = api_request("GET", f"/flows/instances/?designation={designation}")
        results = resp.get("results", [])
        if not results:
            print(f"  Waiting for {label} flow (worker importing blueprints)...")
            continue
        if any(preferred[0] in f.get("slug", "") for f in results):
            break
        first_seen = time.monotonic() if first_seen is None else first_seen
        if time.monotonic() - first_seen >= PREFERRED_FLOW_WAIT_SEC:
            print(f"  No '{preferred[0]}' {label} flow after {PREFERRED_FLOW_WAIT_SEC}s, falling back")
            break
        print(f"  Waiting for '{preferred[0]}' {label} flow (worker importing blueprints)...")
    if not results:
        raise RuntimeError(
            f"No {label} flow found in {AUTHENTIK_WAIT_SEC}s — "
            "Authentik worker did not import default blueprints in time"
        )
    for substr in preferred:
        for flow in results:
            if substr in flow.get("slug", ""):
                print(f"  Found {label} flow: {flow['slug']} (pk={flow['pk']})")
                return flow["pk"]
    print(f"  Using first {label} flow: {results[0]['slug']} (pk={results[0]['pk']})")
    return results[0]["pk"]


def get_authorization_flow_pk() -> str:
    """Find the authorization flow — prefer implicit-consent for auto-redirect
    back to the app (no consent screen), else any default-provider-authorization."""
    return _get_flow_pk(
        "authorization",
        ["implicit-consent", "default-provider-authorization"],
        "authorization",
    )


def get_invalidation_flow_pk() -> str:
    """Find the default invalidation (logout) flow."""
    return _get_flow_pk("invalidation", ["default-invalidation"], "invalidation")


def get_signing_key_pk() -> str | None:
    """Find the self-signed certificate for JWT signing.

    Without a signing key, the JWKS endpoint returns {} and
    the backend gets "The JWK Set did not contain any keys".
    """
    resp = api_request("GET", "/crypto/certificatekeypairs/")
    results = resp.get("results", [])
    for cert in results:
        if "self-signed" in cert.get("name", "").lower():
            print(f"  Found signing key: {cert['name']} (pk={cert['pk']})")
            return cert["pk"]
    if results:
        print(f"  Using first available key: {results[0]['name']}")
        return results[0]["pk"]
    print("  WARNING: No certificate key pairs found — JWKS will be empty")
    return None


def get_scope_mapping_pks() -> list[str]:
    """Find PKs for openid, profile, email, and offline_access scope mappings.

    These are required for the /userinfo/ endpoint to work —
    without them, access tokens have no scopes and Authentik
    returns 403 insufficient_scope.

    Polls for up to AUTHENTIK_WAIT_SEC (_polls) because Authentik's
    worker creates default property mappings asynchronously after
    the API becomes reachable.

    May return fewer than WANTED_SCOPE_MAPPINGS if the worker never finishes —
    callers must treat a short list as "incomplete" and not prune from it.
    """
    wanted = WANTED_SCOPE_MAPPINGS
    pks: list[str] = []
    for _ in _polls():
        resp = api_request("GET", "/propertymappings/all/?page_size=200")
        results = resp.get("results", [])
        pks = []
        for mapping in results:
            managed = mapping.get("managed", "")
            if managed in wanted:
                pks.append(mapping["pk"])
                print(f"  Found scope mapping: {mapping['name']} (pk={mapping['pk']})")
        if len(pks) == len(wanted):
            return pks
        print(f"  Waiting for scope mappings ({len(pks)}/{len(wanted)})...")
    print(f"  WARNING: expected {len(wanted)} scope mappings, found {len(pks)}")
    return pks


def get_ldap_source_mapping_pks() -> list[str]:
    """PKs for the OpenLDAP user property mappings (uid, cn, mail).

    Mirrors get_scope_mapping_pks(): sweeps /propertymappings/all/ and filters
    on the managed ID. Retries because the worker creates default source
    mappings asynchronously (same race as scope mappings / flows).
    """
    wanted = {
        "goauthentik.io/sources/ldap/openldap-uid",
        "goauthentik.io/sources/ldap/openldap-cn",
        "goauthentik.io/sources/ldap/default-mail",
    }
    pks: list[str] = []
    for _ in _polls():
        resp = api_request("GET", "/propertymappings/all/?page_size=200")
        results = resp.get("results", [])
        pks = [m["pk"] for m in results if m.get("managed", "") in wanted]
        if len(pks) == len(wanted):
            for m in results:
                if m.get("managed", "") in wanted:
                    print(f"  Found LDAP mapping: {m['name']} (pk={m['pk']})")
            return pks
        print(f"  Waiting for LDAP source mappings ({len(pks)}/{len(wanted)})...")
    print(f"  WARNING: expected {len(wanted)} LDAP mappings, found {len(pks)}")
    return pks


def delete_legacy_groups_scope_mapping() -> None:
    """Delete the custom `groups` scope mapping this seed used to create (#279).

    The mapping was added on the assumption that Authentik has no built-in
    groups claim. It does: the built-in `profile` scope mapping returns
    `groups: [group.name for group in request.user.groups.all()]`. Authentik
    merges each granted mapping's output with deepmerge's `always_merger`,
    which APPENDS lists rather than overwriting — so a client requesting both
    `profile` and `groups` got every group name exactly twice.

    Deleting the mapping leaves `profile` as the single emitter. Authentik
    drops it from the provider's `property_mappings` M2M as part of the
    delete, so this both detaches and removes it.
    """
    resp = api_request(
        "GET", f"/propertymappings/all/?search={quote(LEGACY_GROUPS_MAPPING_NAME)}")
    # Delete every exact-name match, not just the first: Authentik does not
    # enforce unique property-mapping names, so a hand-created copy would
    # otherwise survive and keep duplicating the claim.
    removed = 0
    for mapping in (resp or {}).get("results", []):
        if mapping.get("name") == LEGACY_GROUPS_MAPPING_NAME:
            pk = mapping["pk"]
            api_request("DELETE", f"/propertymappings/provider/scope/{pk}/")
            print(f"  Removed redundant groups scope mapping (pk={pk})")
            removed += 1
    if not removed:
        print("  No redundant groups scope mapping present")


def get_ldap_group_mapping_pks() -> list[str]:
    """The openldap-cn mapping names a synced group after its cn.

    Called after get_ldap_source_mapping_pks(), which already waited for the
    worker to create the default LDAP mappings.
    """
    resp = api_request("GET", "/propertymappings/all/?page_size=200")
    return [m["pk"] for m in resp.get("results", [])
            if m.get("managed") == "goauthentik.io/sources/ldap/openldap-cn"]


def ldap_group_filter(client_ids) -> str:
    """Sync only registered first-party clients' role groups (ARD-018).

    One `cn=<client_id>-*` term per client; IT-Admins and every other group stay
    out (gap report G12). client_ids are validated `[a-z0-9-]`, so no escaping.
    """
    terms = "".join(f"(cn={c}-*)" for c in client_ids)
    return f"(&(objectClass=groupOfNames)(|{terms}))"


def ensure_ldap_source(bind_password: str | None, mapping_pks: list[str], group_mapping_pks: list[str]) -> str | None:
    """Create or update the OpenLDAP source. Returns the source slug.

    Idempotent: GET by slug, PATCH drifted fields, else POST. bind_password is
    always sent when given (Authentik never returns it to compare); None keeps
    the source's current one.

    The group filter keeps every `(cn=<client_id>-*)` term already on the source:
    the directory API adds one per client it onboards at runtime (ARD-022), and a
    reseed must not drop those clients' role groups from the sync.
    """
    resp = api_request("GET", f"/sources/ldap/?slug={LDAP_SOURCE_SLUG}")
    results = resp.get("results", [])
    synced = set(FIRST_PARTY_CLIENTS)
    if results:
        synced |= set(re.findall(r"\(cn=([a-z0-9-]+)-\*\)", results[0].get("group_object_filter") or ""))
    desired = {
        "name": LDAP_SOURCE_NAME,
        "slug": LDAP_SOURCE_SLUG,
        "server_uri": LDAP_SOURCE_URI,
        "bind_cn": f"cn={SYNC_CLIENT_ID},ou=clients,{LDAP_BASE_DN}",
        "bind_password": bind_password,
        "base_dn": LDAP_BASE_DN,
        "additional_user_dn": "ou=people",
        "user_object_filter": "(&(objectClass=inetOrgPerson)(uid=*))",
        "object_uniqueness_field": "uid",   # CRITICAL — default objectSid imports 0 OpenLDAP users
        "user_property_mappings": mapping_pks,
        "sync_users": True,
        "sync_users_password": False,        # read-minus-secrets can't read userPassword; bind-based login
        "password_login_update_internal_password": False,
        # ARD-007 left group sync off; ARD-018 turns it on for first-party
        # clients' `<client_id>-*` role groups only. Those carry uidObject +
        # uid=<cn>, because object_uniqueness_field=uid skips a plain
        # groupOfNames (G14). No clients registered = no group sync.
        "sync_groups": bool(synced),
        "additional_group_dn": "ou=groups" if synced else "",
        "group_object_filter": ldap_group_filter(sorted(synced)) if synced else "(objectClass=group)",
        "group_membership_field": "member",
        "group_property_mappings": group_mapping_pks if synced else [],
        "delete_not_found_objects": False,  # deactivation handled by Plane A {DISABLED} swap
        "enabled": True,
    }
    if bind_password is None:
        del desired["bind_password"]
    if results:
        existing = results[0]
        # LDAP source detail endpoints are keyed by slug, not pk (confirmed
        # live: GET /sources/ldap/{slug}/ = 200, GET /sources/ldap/{pk}/ = 404).
        patch = {k: v for k, v in desired.items()
                 if k in ("bind_password",) or existing.get(k) != v}
        if set(existing.get("user_property_mappings", [])) == set(mapping_pks):
            patch.pop("user_property_mappings", None)
        if patch:
            api_request("PATCH", f"/sources/ldap/{LDAP_SOURCE_SLUG}/", patch)
            print(f"  Patched LDAP source: {', '.join(sorted(patch.keys()))}")
        else:
            print(f"  LDAP source '{LDAP_SOURCE_SLUG}' already current")
        return LDAP_SOURCE_SLUG
    api_request("POST", "/sources/ldap/", desired)
    print(f"  Created LDAP source '{LDAP_SOURCE_SLUG}'")
    return LDAP_SOURCE_SLUG


def trigger_ldap_sync(slug: str) -> None:
    """Fire an initial sync and poll to completion.

    Finds the source's schedule by rel_obj_id == source pk (schedules carry
    rel_obj_id + actor_name, NOT the slug), POSTs /send/, then polls
    sync/status/. Retries the schedule lookup — the worker registers the
    schedule asynchronously after the source is created.

    sync/status/ response shape (confirmed live, Authentik 2026.5):
      {"is_running": bool, "last_successful_sync": <iso ts>|None,
       "last_sync_status": "done"|...}
    — no per-task list, just a flat running flag.
    """
    resp = api_request("GET", f"/sources/ldap/?slug={slug}")
    results = resp.get("results", [])
    if not results:
        print(f"  WARNING: source '{slug}' not found — cannot trigger sync")
        return
    source_pk = str(results[0]["pk"])

    schedule_id = None
    for _ in _polls():
        resp = api_request("GET", "/tasks/schedules/?page_size=200")
        matches = [s for s in resp.get("results", [])
                   if str(s.get("rel_obj_id")) == source_pk]
        if matches:
            sync = [s for s in matches if "sync" in (s.get("actor_name") or "").lower()]
            schedule_id = (sync or matches)[0]["id"]
            break
        print("  Waiting for LDAP sync schedule...")
    if not schedule_id:
        print("  WARNING: no sync schedule found — source will sync on its next cycle")
        return

    # Capture the prior successful-sync timestamp: is_running can read a stale
    # False immediately after /send/ (before the worker starts), so require a
    # NEW successful sync (timestamp advanced) to call it complete.
    prev = api_request("GET", f"/sources/ldap/{slug}/sync/status/")
    prev_sync = prev.get("last_successful_sync") if isinstance(prev, dict) else None

    api_request("POST", f"/tasks/schedules/{schedule_id}/send/")
    print(f"  Triggered LDAP sync (schedule {schedule_id})")

    for _attempt in range(1, MAX_RETRIES + 1):
        time.sleep(RETRY_DELAY)
        status = api_request("GET", f"/sources/ldap/{slug}/sync/status/")
        if (isinstance(status, dict)
                and status.get("is_running") is False
                and status.get("last_successful_sync") != prev_sync):
            print(f"  LDAP sync complete (status={status.get('last_sync_status')})")
            return
    print("  WARNING: LDAP sync did not report completion in time")


def ldap_source_binds() -> bool:
    """True when the existing LDAP source binds as the sync account with its stored secret, now.

    The source's `connectivity` field is a cache (2 h TTL, refreshed hourly and on
    save of the source), so it still reads "ok" after an LDAP-side rotate, restore
    or reset (t-0062). The debug endpoint builds each synchronizer with
    source.connection(), a live bind with the stored bind_cn and password, and
    answers 500 when LDAP refuses it. It reads at most 10 entries per class.
    """
    source = api_request("GET", f"/sources/ldap/{LDAP_SOURCE_SLUG}/", allow_404=True)
    if not source or source.get("bind_cn") != f"cn={SYNC_CLIENT_ID},ou=clients,{LDAP_BASE_DN}":
        return False
    try:
        api_request("GET", f"/sources/ldap/{LDAP_SOURCE_SLUG}/debug/")
    except HTTPError:
        return False
    return True


def ensure_ldap_federation():
    """Provision sync client → resolve mappings → ensure source → trigger sync.

    Dev/CI self-provision the sync client, and a re-run used to rotate its secret
    every time. While the source still binds, the secret is kept (None leaves
    bind_password alone); otherwise it is provisioned or rotated as before.
    """
    if DEV_AUTH_TOKEN and ldap_source_binds():
        print(f"  LDAP source binds as '{SYNC_CLIENT_ID}': keeping its secret")
        secret = None
    else:
        secret = ensure_sync_client()
        if not secret:
            print("  Skipping LDAP source (no sync secret)")
            return
    mapping_pks = get_ldap_source_mapping_pks()
    slug = ensure_ldap_source(secret, mapping_pks, get_ldap_group_mapping_pks())
    if slug:
        trigger_ldap_sync(slug)


def upsert_provider(data: dict) -> int:
    """Create the OAuth2 provider `data["client_id"]`, or converge an existing one.

    The one create/patch path for every provider this seed owns: the web app,
    service clients and first-party clients. On update it syncs
    authorization_flow, redirect_uris, grant_types, property_mappings and the
    token validities `data` sets, and sets signing_key only when it is missing.
    Name and client_type are create-time only.
    """
    client_id = data["client_id"]
    signing_key_pk = get_signing_key_pk()
    resp = api_request("GET", f"/providers/oauth2/?client_id={quote(client_id)}")
    existing = next((p for p in resp.get("results", []) if p.get("client_id") == client_id), None)
    if existing is None:
        if signing_key_pk:
            data = {**data, "signing_key": signing_key_pk}
        pk = api_request("POST", "/providers/oauth2/", data)["pk"]
        print(f"  Created OAuth2 provider '{client_id}' (pk={pk})")
        return pk

    pk = existing["pk"]
    patch = {}
    have, want = existing.get("property_mappings", []), data["property_mappings"]
    if len(want) == len(WANTED_SCOPE_MAPPINGS):
        # Converge on the exact desired set so a mapping this seed no longer
        # wants is dropped. Union-only kept the redundant groups mapping
        # attached forever once seeded (#279).
        if set(have) != set(want):
            patch["property_mappings"] = want
    elif set(want) - set(have):
        # Partial resolve (worker still creating defaults) — add only.
        # Pruning against an incomplete set would strip working mappings.
        patch["property_mappings"] = list(set(have) | set(want))
    if not existing.get("signing_key") and signing_key_pk:
        patch["signing_key"] = signing_key_pk
    for key in ("authentication_flow", "authorization_flow", "access_token_validity", "refresh_token_validity"):
        if key in data and existing.get(key) != data[key]:
            patch[key] = data[key]
    if {u.get("url") for u in existing.get("redirect_uris", [])} != {u["url"] for u in data["redirect_uris"]}:
        patch["redirect_uris"] = data["redirect_uris"]
    if set(existing.get("grant_types") or []) != set(data["grant_types"]):
        patch["grant_types"] = data["grant_types"]
    if patch:
        api_request("PATCH", f"/providers/oauth2/{pk}/", patch)
        print(f"  Patched provider '{client_id}': {', '.join(patch.keys())}")
    else:
        print(f"  OAuth2 provider '{client_id}' already current (pk={pk})")
    return pk


def ensure_oauth2_provider() -> int:
    """The web app's public PKCE provider. Returns provider pk.

    Access 15 min: the admin UI refreshes 5 min before expiry, so a leaked access
    token dies quickly. Refresh 12 h (review finding 9, owner decision): the
    browser keeps it in localStorage, where any script on the origin can read it,
    so an unused one must not outlive a working day. A tab idle past it goes back
    through Authentik. Each refresh rotates the token, so an active session slides.
    """
    return upsert_provider({
        "name": f"{APP_NAME} OIDC",
        "authorization_flow": get_authorization_flow_pk(),
        "invalidation_flow": get_invalidation_flow_pk(),
        "client_type": "public",
        "client_id": CLIENT_ID,
        "redirect_uris": REDIRECT_URIS,
        "access_token_validity": "minutes=15",
        "refresh_token_validity": "hours=12",
        "property_mappings": get_scope_mapping_pks(),
        "sub_mode": "hashed_user_id",
        "include_claims_in_id_token": True,
        "grant_types": GRANT_TYPES,
    })


def ensure_client_application(client_id: str, provider_pk: int, policy_engine_mode: str | None = None) -> dict:
    """Application whose slug == client_id, so the issuer is /application/o/<client_id>/.

    policy_engine_mode `all` for an app guarded by an access policy: under Authentik's
    default `any`, a binding added later would outvote it. Set on create, patched
    on an existing install.
    """
    app = find_application(client_id)
    if app is None:
        data = {"name": client_id, "slug": client_id, "provider": provider_pk}
        if policy_engine_mode:
            data["policy_engine_mode"] = policy_engine_mode
        app = api_request("POST", "/core/applications/", data)
        print(f"  Created application '{client_id}'")
    elif policy_engine_mode and app.get("policy_engine_mode") != policy_engine_mode:
        app = api_request("PATCH", f"/core/applications/{client_id}/", {"policy_engine_mode": policy_engine_mode})
        print(f"  Set application '{client_id}' policy_engine_mode to {policy_engine_mode}")
    return app


def ensure_service_client(client_id: str) -> None:
    """Confidential provider + application for one API-to-API caller.

    - grant_types = client_credentials ONLY (no browser flow, no redirect URIs).
    - Provider name == client_id, so Authentik's generated service account is
      exactly `ak-<client_id>-client_credentials` — the name the directory API
      keys OIDC_SERVICE_PERMISSIONS on.
    - Secret is generated by Authentik and never rotated here; the calling
      service reads it once from the Admin API into its own vault.
    - Short-lived access tokens (15 min): services re-request, nothing to refresh.
    - Access policy: only that generated account gets a token (B2). Without it the
      provider minted one for any user's app password (username + password on the
      same grant). The application's policy_engine_mode is `all`, so a binding
      added later cannot outvote it. TEST_USER_TOKEN_CLIENT is left open for the test suite.
    """
    pk = upsert_provider({
        "name": client_id,
        "authorization_flow": get_authorization_flow_pk(),
        "invalidation_flow": get_invalidation_flow_pk(),
        "client_type": "confidential",
        "client_id": client_id,
        "redirect_uris": [],
        "access_token_validity": "minutes=15",
        "property_mappings": get_scope_mapping_pks(),
        "sub_mode": "hashed_user_id",
        "include_claims_in_id_token": True,
        "grant_types": ["client_credentials"],
    })
    if client_id == TEST_USER_TOKEN_CLIENT:
        ensure_client_application(client_id, pk)
        return
    app = ensure_client_application(client_id, pk, policy_engine_mode="all")
    account = f"ak-{client_id}-client_credentials"
    policy = ensure_named("/policies/expression/", {
        "name": f"{client_id}: only {account}", "expression": f"return request.user.username == {account!r}"})
    ensure_policy_binding(policy["pk"], app["pk"], negate=False, failure_result=False)


def ensure_named(path: str, data: dict) -> dict:
    """Create the object at `path` named data["name"], or PATCH the fields that differ."""
    resp = api_request("GET", f"{path}?name={quote(data['name'])}")
    obj = next((o for o in resp.get("results", []) if o.get("name") == data["name"]), None)
    if obj is None:
        obj = api_request("POST", path, data)
        print(f"  Created {path} '{data['name']}'")
        return obj
    patch = {k: v for k, v in data.items() if obj.get(k) != v}
    if patch:
        obj = api_request("PATCH", f"{path}{obj['pk']}/", patch)
        print(f"  Patched {path} '{data['name']}': {', '.join(patch)}")
    return obj


def ensure_headless_flow() -> str:
    """The shared `headless-first-party-auth` flow (ARD-018 rule 2, gap report E3). Returns its pk.

    Own stages, so edits to the brand's default flow never change what a relay
    drives. Identification and password stay separate stages (no inline
    password), the shape relays already post. ensure_username_throttle adds the
    lockout's deny stage at 25. The MFA stage keeps every device
    class: a user with any enrolled device is challenged, and a relay that has
    not built that step refuses the login (rule 5, fail closed).
    """
    flow = api_request("GET", f"/flows/instances/{HEADLESS_FLOW_SLUG}/", allow_404=True)
    if flow is None:
        flow = api_request("POST", "/flows/instances/", {
            "name": "Headless first-party login", "slug": HEADLESS_FLOW_SLUG, "title": "Sign in",
            "designation": "authentication", "authentication": "none",
        })
        print(f"  Created flow '{HEADLESS_FLOW_SLUG}'")
    stages = [
        (10, "/stages/identification/", {
            "name": f"{HEADLESS_FLOW_SLUG}-identification", "user_fields": ["email", "username"],
            "case_insensitive_matching": True, "pretend_user_exists": True, "show_matched_user": False}),
        (20, "/stages/password/", {
            "name": f"{HEADLESS_FLOW_SLUG}-password",
            "backends": ["authentik.core.auth.InbuiltBackend", "authentik.sources.ldap.auth.LDAPBackend"],
            "failed_attempts_before_cancel": 5}),
        (30, "/stages/authenticator/validate/", {
            "name": f"{HEADLESS_FLOW_SLUG}-mfa-validation", "not_configured_action": "skip",
            "device_classes": ["static", "totp", "webauthn", "duo", "sms", "email"]}),
        (100, "/stages/user_login/", {"name": f"{HEADLESS_FLOW_SLUG}-login"}),
    ]
    bindings = api_request("GET", f"/flows/bindings/?target={flow['pk']}")["results"]
    bound = {}
    for order, path, data in stages:
        stage = ensure_named(path, data)
        bound[order] = ensure_flow_binding(flow["pk"], HEADLESS_FLOW_SLUG, stage, order, bindings)
    ensure_username_throttle(flow["pk"], HEADLESS_FLOW_SLUG, bound[20], bound[100], HEADLESS_THROTTLE_MESSAGE)
    return flow["pk"]


def ensure_flow_binding(flow_pk: str, slug: str, stage: dict, order: int, bindings: list[dict]) -> dict:
    """Bind `stage` to the flow at `order` (re-evaluated on every request) unless already bound there."""
    binding = next((b for b in bindings if b["stage"] == stage["pk"] and b["order"] == order), None)
    if binding is None:
        binding = api_request("POST", "/flows/bindings/", {
            "target": flow_pk, "stage": stage["pk"], "order": order,
            "evaluate_on_plan": False, "re_evaluate_policies": True})
        print(f"  Bound '{stage['name']}' to '{slug}' at {order}")
    return binding


def ensure_web_flow_throttle() -> None:
    """The headless lockout on the brand flow behind web sign-in, admin included (gap report G22).

    Its password stage binds LDAP like the headless one, so unthrottled it let anyone lock an LDAP
    account (and XMPP) with 5 attempts. The stages come from Authentik's blueprint; they are found
    by component, not by name or order.
    """
    flow = api_request("GET", f"/flows/instances/{WEB_FLOW_SLUG}/")
    bindings = api_request("GET", f"/flows/bindings/?target={flow['pk']}")["results"]

    def only(component: str) -> dict:
        (binding,) = [b for b in bindings if b["stage_obj"]["component"] == component]
        return binding

    ensure_username_throttle(flow["pk"], WEB_FLOW_SLUG, only("ak-stage-password-form"),
                             only("ak-stage-user-login-form"), WEB_THROTTLE_MESSAGE)


def ensure_username_throttle(flow_pk: str, slug: str, password_binding: dict, login_binding: dict,
                             deny_message: str) -> None:
    """Lockout (ARD-018, gap report E5/G1/G22): 3 failures block the username in Authentik,
    before ppolicy's 5 lock the LDAP account (and XMPP with it).

    - Username reputation (sum of the username's rows <= -3), bound NEGATED on the password stage's
      own binding. That binding is re-evaluated on every request before the LDAP bind; a deny stage
      in front of the password stage runs once per executor session, so a session staged while the
      score was clean would skip it. The binding's policy engine mode is `all`, so a policy already
      bound there (the brand flow's "password needed") cannot outvote the check.
    - When the check fails the password stage is skipped, and a deny stage after it must stop the
      flow: it runs unless a stage authenticated the user, and fails closed on a policy error.
      The same guard, negated, sits on the user-login binding: a flow plan stored in a session
      before the deny stage existed has no deny stage, and must still never log anyone in.
    - Tenant reputation_upper_limit 0: past successes must not bank extra failures (with +5, a
      user's own sign-ins let an attacker reach 5 LDAP failures first). Rows already above 0 go.
    - Bind budget on the same binding (G23): the reputation check races, since parallel POSTs all
      pass it before any failure is recorded. Each POST atomically reserves one of the username's
      3 binds first (one counter row shared by both flows); a success gives its reservation back
      through the guard. Errors fail closed (failure_result False).
    Residual (other LDAP paths): spec 08.
    """
    if api_request("GET", "/admin/settings/").get("reputation_upper_limit") != 0:
        api_request("PATCH", "/admin/settings/", {"reputation_upper_limit": 0})
        print("  Set tenant reputation_upper_limit to 0")
    while banked := [r for r in api_request("GET", "/policies/reputation/scores/?ordering=-score")["results"]
                     if r["score"] > 0]:
        for row in banked:
            api_request("DELETE", f"/policies/reputation/scores/{row['pk']}/")
        print(f"  Deleted {len(banked)} positive reputation score(s)")
    # Both checks need the binding re-evaluated on every request, and neither may be outvoted.
    want = {"policy_engine_mode": "all", "re_evaluate_policies": True}
    if patch := {k: v for k, v in want.items() if password_binding.get(k) != v}:
        api_request("PATCH", f"/flows/bindings/{password_binding['pk']}/", patch)
        print(f"  Set '{slug}' password binding: {', '.join(patch)}")
    deny = ensure_named("/stages/deny/", {"name": f"{slug}-throttled", "deny_message": deny_message})
    deny_binding = ensure_flow_binding(flow_pk, slug, deny, password_binding["order"] + 5,
                                       api_request("GET", f"/flows/bindings/?target={flow_pk}")["results"])
    reputation = ensure_named("/policies/reputation/", {
        "name": f"{slug}-username-reputation",
        "check_username": True, "check_ip": False, "threshold": USERNAME_LOCKOUT_THRESHOLD})
    guard = ensure_named("/policies/expression/", {
        "name": f"{slug}-password-not-passed", "expression": NOT_AUTHENTICATED_EXPRESSION})
    budget = ensure_named("/policies/expression/", {
        "name": f"{slug}-ldap-bind-budget", "expression": BIND_BUDGET_EXPRESSION})
    ensure_policy_binding(reputation["pk"], password_binding["pk"], negate=True, failure_result=False)
    ensure_policy_binding(budget["pk"], password_binding["pk"], negate=False, failure_result=False)
    ensure_policy_binding(guard["pk"], deny_binding["pk"], negate=False, failure_result=True)
    ensure_policy_binding(guard["pk"], login_binding["pk"], negate=True, failure_result=False)


def ensure_avatars() -> None:
    """Tenant avatars `initials` only. With gravatar, the first serialization of each user in 8 h
    sends an outbound HEAD to gravatar.com: ~280 ms on every user GET (the suspend path included),
    and up to a 5 s stall on a host with no internet."""
    if api_request("GET", "/admin/settings/").get("avatars") != "initials":
        api_request("PATCH", "/admin/settings/", {"avatars": "initials"})
        print("  Set tenant avatars to initials")


def ensure_policy_binding(policy_pk: str, target: str, negate: bool, failure_result: bool) -> None:
    """Bind `policy_pk` to `target` (a flow-stage binding or an application) with the given negate/failure_result."""
    want = {"negate": negate, "failure_result": failure_result, "enabled": True}
    resp = api_request("GET", f"/policies/bindings/?policy={policy_pk}")
    binding = next((b for b in resp.get("results", []) if b.get("policy") == policy_pk and b.get("target") == target), None)
    if binding is None:
        api_request("POST", "/policies/bindings/", {"policy": policy_pk, "target": target, "order": 0, "timeout": 30, **want})
        print(f"  Bound policy {policy_pk} to {target}")
    elif patch := {k: v for k, v in want.items() if binding.get(k) != v}:
        # 2026.5 answers PATCH on a policy binding with 405; PUT the whole binding.
        keep = ("policy", "target", "order", "timeout", "group", "user")
        api_request("PUT", f"/policies/bindings/{binding['pk']}/", {**{k: binding.get(k) for k in keep}, **want})
        print(f"  Patched policy binding {binding['pk']}: {', '.join(patch)}")


def ensure_first_party_client(client_id: str, redirect_uris: list[str], authentication_flow: str) -> None:
    """Provider + application + access policy for one headless first-party client (ARD-018).

    - Confidential, authorization_code + refresh_token only (rule 1); access
      15 min, refresh 7 d (rule 3). The secret is never rotated here.
    - Authentication flow is the shared headless flow (rule 2).
    - Standard scope mappings only: the profile scope already emits `groups`,
      so no custom groups mapping (#279).
    - client_id is NOT an accepted audience of the directory API: its tokens
      must keep failing there (G19).
    """
    pk = upsert_provider({
        "name": client_id,
        "authentication_flow": authentication_flow,
        "authorization_flow": get_authorization_flow_pk(),
        "invalidation_flow": get_invalidation_flow_pk(),
        "client_type": "confidential",
        "client_id": client_id,
        "redirect_uris": [{"matching_mode": "strict", "url": u} for u in redirect_uris],
        "access_token_validity": "minutes=15",
        "refresh_token_validity": "days=7",
        "property_mappings": get_scope_mapping_pks(),
        "sub_mode": "hashed_user_id",
        "include_claims_in_id_token": True,
        "grant_types": FIRST_PARTY_GRANT_TYPES,
    })
    app = ensure_client_application(client_id, pk, policy_engine_mode="all")
    ensure_group_prefix_policy(app["pk"], client_id)


def ensure_group_prefix_policy(app_pk: str, client_id: str) -> None:
    """Only members of a `<client_id>-*` group may get tokens for this client (G11).

    An expression policy rather than group bindings: the role groups arrive
    later through LDAP sync, and a new role needs no seed change.
    """
    name = f"{client_id}: member of {client_id}-*"
    expression = f"return any(g.name.startswith({client_id + '-'!r}) for g in request.user.ak_groups.all())"
    resp = api_request("GET", f"/policies/expression/?name={quote(name)}")
    policy = next((p for p in resp.get("results", []) if p.get("name") == name), None)
    if policy is None:
        policy = api_request("POST", "/policies/expression/", {"name": name, "expression": expression})
        print(f"  Created access policy '{name}'")
    elif policy.get("expression") != expression:
        api_request("PATCH", f"/policies/expression/{policy['pk']}/", {"expression": expression})
        print(f"  Patched access policy '{name}'")
    resp = api_request("GET", f"/policies/bindings/?target={app_pk}")
    if not any(b.get("policy") == policy["pk"] and b.get("target") == app_pk for b in resp.get("results", [])):
        api_request("POST", "/policies/bindings/", {
            "policy": policy["pk"], "target": app_pk, "order": 0, "enabled": True, "negate": False, "timeout": 30})
        print(f"  Bound access policy to application '{client_id}'")


def find_application(slug: str) -> dict | None:
    """Look up one application by slug. Returns None if it does not exist.

    Deliberately NOT `GET /core/applications/?slug=<slug>`: Authentik's
    application viewset serves `results` from a per-user cache of *every*
    allowed application and applies the query filter only to
    `pagination.count`. Measured on 2026.5 with two applications seeded:

        ?slug=<nonexistent> -> count=0, results=[azblink-directory, nextcloud]
        ?slug=nextcloud     -> count=1, results=[azblink-directory, nextcloud]

    So a truthy `results` means "some application exists" (not ours), and
    `results[0]` is the wrong application. Retrieve-by-slug hits the DB —
    the viewset's lookup_field is `slug`.
    """
    return api_request("GET", f"/core/applications/{quote(slug)}/", allow_404=True)


def ensure_application(provider_pk: int):
    """Create or find the application linked to the provider."""
    if find_application(APP_SLUG) is not None:
        print(f"  Application '{APP_SLUG}' already exists")
        return

    data = {
        "name": APP_NAME,
        "slug": APP_SLUG,
        "provider": provider_pk,
        # RP-initiated login URL: points users to the SPA's /login page with
        # ?auto=1 so the frontend immediately calls startOidcLogin() (which
        # generates a session-specific PKCE challenge and redirects back to
        # /application/o/authorize/). The bare SPA root does not start OAuth
        # and leaves the user stranded on /login requiring a manual click.
        "meta_launch_url": "https://azblink-ad.keithmoc.dev/login?auto=1",
    }
    api_request("POST", "/core/applications/", data)
    print(f"  Created application '{APP_SLUG}'")


API_TOKEN_IDENTIFIER = "azblink-directory-api"


def ensure_api_token() -> None:
    """Make the directory API's AUTHENTIK_API_TOKEN a real Authentik token.

    Authentik creates only the bootstrap token, on first start. When the vault gives
    the API a different token, the seed creates `azblink-directory-api` for akadmin
    (the API revokes sessions and tokens and deactivates users, so it needs admin
    rights) and keeps its key equal to the vault value, so a rotation converges too.
    """
    key = os.getenv("AUTHENTIK_API_TOKEN", "")
    if not key or key == API_TOKEN:
        print("  The API uses the bootstrap token; nothing to create")
        return
    path = f"/core/tokens/{API_TOKEN_IDENTIFIER}/"
    if api_request("GET", path, allow_404=True) is None:
        akadmin = api_request("GET", "/core/users/?username=akadmin")["results"][0]
        api_request("POST", "/core/tokens/", {
            "identifier": API_TOKEN_IDENTIFIER,
            "intent": "api",
            "user": akadmin["pk"],
            "expiring": False,
            "description": "AZBlink Directory API (AUTHENTIK_API_TOKEN)",
        })
        print(f"  Created token '{API_TOKEN_IDENTIFIER}'")
    if api_request("GET", f"{path}view_key/")["key"] != key:
        api_request("POST", f"{path}set_key/", {"key": key})
        print(f"  Set the key of '{API_TOKEN_IDENTIFIER}' from AUTHENTIK_API_TOKEN")
    else:
        print(f"  Token '{API_TOKEN_IDENTIFIER}' already in sync")


def ensure_admin_group():
    """Create IT-Admins group and assign akadmin user."""
    # Check if group exists
    resp = api_request("GET", f"/core/groups/?name={ADMIN_GROUP_NAME}")
    results = resp.get("results", [])
    if results:
        group_pk = results[0]["pk"]
        print(f"  Group '{ADMIN_GROUP_NAME}' already exists (pk={group_pk})")
    else:
        resp = api_request("POST", "/core/groups/", {
            "name": ADMIN_GROUP_NAME,
            "is_superuser": False,
        })
        group_pk = resp["pk"]
        print(f"  Created group '{ADMIN_GROUP_NAME}' (pk={group_pk})")

    # Find akadmin user
    resp = api_request("GET", "/core/users/?username=akadmin")
    users = resp.get("results", [])
    if not users:
        print("  WARNING: akadmin user not found — skipping group assignment")
        return

    user_pk = users[0]["pk"]
    user_groups = [g["pk"] for g in users[0].get("groups_obj", [])]

    if group_pk in user_groups:
        print(f"  akadmin already in '{ADMIN_GROUP_NAME}'")
        return

    # Add user to group
    user_groups.append(group_pk)
    api_request("PATCH", f"/core/users/{user_pk}/", {"groups": user_groups})
    print(f"  Added akadmin to '{ADMIN_GROUP_NAME}'")


def add_ldap_user_to_admin_group(username: str) -> None:
    """Add a synced LDAP user to IT-Admins so the SSO demo lands in the admin UI.

    Safe-by-default: sync grants NO admin rights; this is an explicit demo grant.
    No-op if the user isn't present yet (sync incomplete / user absent in LDAP).
    """
    resp = api_request("GET", f"/core/groups/?name={quote(ADMIN_GROUP_NAME)}")
    groups = resp.get("results", [])
    if not groups:
        print(f"  WARNING: group '{ADMIN_GROUP_NAME}' not found")
        return
    group_pk = groups[0]["pk"]

    resp = api_request("GET", f"/core/users/?username={quote(username)}")
    users = resp.get("results", [])
    if not users:
        print(f"  Demo user '{username}' not synced yet — skipping admin grant")
        return
    user = users[0]
    user_groups = [g["pk"] for g in user.get("groups_obj", [])]
    if group_pk in user_groups:
        print(f"  '{username}' already in '{ADMIN_GROUP_NAME}'")
        return
    user_groups.append(group_pk)
    api_request("PATCH", f"/core/users/{user['pk']}/", {"groups": user_groups})
    print(f"  Added demo user '{username}' to '{ADMIN_GROUP_NAME}'")


def delete_local_user(username: str) -> None:
    """Delete a purely-LOCAL (non-LDAP-sourced) Authentik user, so any federated
    identity of the same username owns it.

    ensure_seed_users is skip-if-exists, so on an already-built stack it can't
    remove an old local account; that local user would shadow/collide with the
    LDAP one (same password), making a 'successful' SSO prove nothing about the
    LDAP path. Only deletes a user with NO LDAP source connection — never the
    federated user. Runs BEFORE the LDAP sync (see main()), so on a clean run
    the local copy is gone before the LDAP copy is imported.
    """
    resp = api_request("GET", f"/core/users/?username={quote(username)}")
    for u in resp.get("results", []):
        pk = u["pk"]
        conns = api_request("GET", f"/sources/user_connections/ldap/?user={pk}")
        linked = bool((conns or {}).get("results")) or \
            ((conns or {}).get("pagination", {}) or {}).get("count", 0) > 0
        if linked:
            print(f"  '{username}' is LDAP-sourced — keeping")
            continue
        api_request("DELETE", f"/core/users/{pk}/")
        print(f"  Deleted local user '{username}' (pk={pk}) — removed local (non-federated) copy")


def ensure_seed_users():
    """Create seed users and assign them to IT-Admins group.

    - Idempotent: skips creation if user exists, always resets password
    - Assigns to IT-Admins group if not already a member
    """
    if not SEED_USERS:
        print("  No seed users configured")
        return

    # Resolve IT-Admins group pk
    resp = api_request("GET", f"/core/groups/?name={ADMIN_GROUP_NAME}")
    results = resp.get("results", [])
    if not results:
        print(f"  WARNING: Group '{ADMIN_GROUP_NAME}' not found — create it first")
        return
    group_pk = results[0]["pk"]

    for user_cfg in SEED_USERS:
        username = user_cfg["username"]
        password = user_cfg["password"]

        # Check if user exists
        resp = api_request("GET", f"/core/users/?username={username}")
        users = resp.get("results", [])

        if users:
            user_pk = users[0]["pk"]
            print(f"  User '{username}' already exists (pk={user_pk})")
            # Ensure group membership
            user_groups = [g["pk"] for g in users[0].get("groups_obj", [])]
            if group_pk not in user_groups:
                user_groups.append(group_pk)
                api_request("PATCH", f"/core/users/{user_pk}/", {"groups": user_groups})
                print(f"  Added '{username}' to '{ADMIN_GROUP_NAME}'")
        else:
            # Create user with group assignment
            create_data = {
                "username": username,
                "name": user_cfg.get("name", username),
                "email": user_cfg.get("email", ""),
                "is_active": user_cfg.get("is_active", True),
                "type": "internal",
                "groups": [group_pk],
            }
            resp = api_request("POST", "/core/users/", create_data)
            user_pk = resp["pk"]
            print(f"  Created user '{username}' (pk={user_pk}) in '{ADMIN_GROUP_NAME}'")

        # Always set/reset password (idempotent)
        api_request("POST", f"/core/users/{user_pk}/set_password/", {"password": password})
        print(f"  Set password for '{username}'")


def ensure_flow_titles():
    """Rename default authentication flow titles from 'Welcome to authentik!' to 'Sign in'.

    Patches both default-authentication-flow and default-source-authentication.
    Idempotent — skips flows already titled correctly.
    """
    slugs = ["default-authentication-flow", "default-source-authentication"]
    desired_title = "Sign in"
    for slug in slugs:
        try:
            resp = api_request("GET", f"/flows/instances/{slug}/")
            if not resp:
                continue
            current = resp.get("title", "")
            if current == desired_title:
                print(f"  Flow '{slug}' already titled '{desired_title}'")
                continue
            api_request("PATCH", f"/flows/instances/{slug}/", {"title": desired_title})
            print(f"  Renamed flow '{slug}': '{current}' → '{desired_title}'")
        except HTTPError as e:
            print(f"  WARNING: Failed to patch flow '{slug}' (HTTP {e.code})", file=sys.stderr)


def find_web_certificate(name: str) -> str:
    """Return the pk of the discovered keypair `name`, waiting for the worker.

    Exits non-zero if it never appears: a deploy that asked for TLS must not
    finish serving Authentik's self-signed certificate on the relay path.
    """
    for _ in _polls():
        resp = api_request("GET", f"/crypto/certificatekeypairs/?name={quote(name)}&has_key=true")
        for kp in (resp or {}).get("results", []):
            if kp["name"] == name:
                return kp["pk"]
        print(f"  Waiting for the worker to discover certificate '{name}'...")
    sys.exit(f"ERROR: no keypair '{name}' with a key; mount it at /certs/{name}/ on authentik-worker")


def ensure_branding():
    """Apply AZBlink branding and default_application to the default brand.

    - Sets title, logo, favicon, and dark theme
    - Injects custom CSS matching AZBlink design tokens
    - Sets default_application so users redirect to app after login
    - Sets web_certificate when AUTHENTIK_WEB_CERT_NAME names one (ARD-021)
    - Diff-checks current vs desired — skips PATCH if already in sync
    """
    # Find the default brand (auto-created on first Authentik boot)
    resp = api_request("GET", "/core/brands/?default=true")
    results = resp.get("results", []) if resp else []
    if not results:
        print("  WARNING: No default brand found — skipping branding")
        return

    brand = results[0]
    brand_uuid = brand["brand_uuid"]
    current_title = brand.get("branding_title", "")
    print(f"  Found default brand (uuid={brand_uuid}, title='{current_title}')")

    # Read custom CSS from mounted assets
    custom_css = ""
    try:
        with open(BRAND_CSS_PATH, "r") as f:
            custom_css = f.read()
        print(f"  Loaded custom CSS ({len(custom_css)} bytes)")
    except FileNotFoundError:
        print(f"  WARNING: {BRAND_CSS_PATH} not found — applying branding without custom CSS")

    # Resolve application slug → pk for default_application
    app_pk = None
    try:
        app = find_application(APP_SLUG)
        if app:
            app_pk = app["pk"]
        else:
            print(f"  WARNING: Application '{APP_SLUG}' not found — skipping default_application")
    except HTTPError:
        print("  WARNING: Failed to look up application — skipping default_application")

    # Desired state — each key maps to the brand API field name
    desired = {
        "branding_title": BRAND_TITLE,
        "branding_logo": BRAND_LOGO,
        "branding_favicon": BRAND_FAVICON,
        "branding_custom_css": custom_css,
        "attributes": {
            "settings": {
                "theme": {
                    "base": "dark"
                }
            }
        },
    }
    if app_pk:
        desired["default_application"] = app_pk
    if WEB_CERT_NAME:
        desired["web_certificate"] = find_web_certificate(WEB_CERT_NAME)

    # Diff current brand against desired — only PATCH changed fields
    patch = {}
    for key, desired_val in desired.items():
        current_val = brand.get(key)
        # default_application comes back as pk string or None
        if key == "default_application":
            current_val = brand.get("default_application")
        if current_val != desired_val:
            patch[key] = desired_val

    if not patch:
        print("  Branding already in sync — skipping PATCH")
        return

    changed_keys = ", ".join(patch.keys())
    print(f"  Branding drift detected: {changed_keys}")

    try:
        api_request("PATCH", f"/core/brands/{brand_uuid}/", patch)
        print(f"  Applied AZBlink branding ({len(patch)} field(s) updated)")
    except HTTPError as e:
        print(f"  WARNING: Failed to apply branding (HTTP {e.code}) — continuing", file=sys.stderr)


def main():
    # Piped stdout is block-buffered: without this `docker logs` of a seed still
    # waiting (or killed) shows nothing.
    sys.stdout.reconfigure(line_buffering=True)
    print("=" * 60)
    print("Authentik Seed: AZBlink OIDC Application Setup")
    print("=" * 60)

    wait_for_authentik()

    print("\n0. Ensuring the directory API's Admin API token...")
    ensure_api_token()

    print("\n1. Removing redundant groups scope mapping (#279)...")
    delete_legacy_groups_scope_mapping()

    print("\n2. Ensuring OAuth2 provider...")
    provider_pk = ensure_oauth2_provider()

    print("\n3. Ensuring application...")
    ensure_application(provider_pk)

    print("\n3b. Ensuring API-to-API service clients...")
    for service_client_id in SERVICE_CLIENTS:
        ensure_service_client(service_client_id)

    print("\n3c. Ensuring headless first-party clients (ARD-018)...")
    # The flow exists even with no env clients: the directory API onboards clients
    # at runtime onto it (ARD-022).
    headless_flow_pk = ensure_headless_flow()
    for fp_client_id, fp_uris in FIRST_PARTY_CLIENTS.items():
        ensure_first_party_client(fp_client_id, fp_uris, headless_flow_pk)

    print("\n4. Ensuring admin group...")
    ensure_admin_group()

    print("\n5. Ensuring seed users...")
    ensure_seed_users()

    print("\n5b. Removing legacy local seed users (web identities come from LDAP)...")
    delete_local_user("alanl")

    print("\n5c. Ensuring LDAP source federation (sync client + source + initial sync)...")
    ensure_ldap_federation()

    print("\n5d. Granting demo LDAP user admin access...")
    add_ldap_user_to_admin_group(LDAP_DEMO_SSO_USER)

    print("\n6. Renaming flow titles...")
    ensure_flow_titles()

    print("\n6b. Throttling web sign-in (ARD-018 lockout, G22)...")
    ensure_web_flow_throttle()

    print("\n6c. Setting tenant avatars to initials (no gravatar lookups)...")
    ensure_avatars()

    print("\n7. Applying AZBlink branding...")
    ensure_branding()

    print("\n" + "=" * 60)
    print("Authentik seed complete!")
    print(f"  OIDC Issuer:    {API_URL}/application/o/{APP_SLUG}/")
    print(f"  Client ID:      {CLIENT_ID}")
    print(f"  Redirect URIs:  {', '.join(u['url'] for u in REDIRECT_URIS)}")
    print(f"  First-party:    {', '.join(FIRST_PARTY_CLIENTS) or '(none)'}")
    print(f"  Admin group:    {ADMIN_GROUP_NAME}")
    print(f"  Branding:       {BRAND_TITLE}")
    print(f"  Default app:    {APP_SLUG}")
    print("=" * 60)


if __name__ == "__main__":
    main()
