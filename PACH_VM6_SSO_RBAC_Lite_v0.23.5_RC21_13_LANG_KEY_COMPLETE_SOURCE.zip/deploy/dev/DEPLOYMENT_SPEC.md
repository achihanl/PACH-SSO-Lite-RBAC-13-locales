# AZBlink Directory - Deployment Specification

Complete technical specification for the Directory API development environment.

## 1. Overview

### Purpose
Local development environment for the AZBlink Directory stack with:
- Pre-built Docker images for fast startup (~2s vs ~30s)
- Hot reload for Python code changes (API + UED Sync)
- Hot reload for React/CSS/TS changes (UI via Vite HMR)
- Pre-seeded OpenLDAP with realistic test data
- PostgreSQL for persistent application state
- UED Sync API for XMPP/SIP provisioning (internal microservice)

### Audience
- Developers working on Directory API
- QA testing directory features
- Demo/training environments

### Prerequisites
- Docker Engine 20.10+
- Docker Compose v2.0+
- 2GB available disk space
- Ports 1390, 5433, 8081 available (non-standard to avoid conflicts)

## 2. Architecture

### Service Diagram

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                            Docker Network (azblink-net)                          │
│                                                                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────────┐   │
│  │PostgreSQL│  │  Redis   │  │ OpenLDAP │  │   API    │  │       UI         │   │
│  │  :5432   │  │  :6379   │  │   :389   │  │  :8000   │  │      :5173       │   │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────────┬─────────┘   │
│       │             │             │             │                  │              │
│       └─────────────┴─────────────┴─────────────┴──────────────────┘              │
│                                    │                                              │
│                            ┌───────┴───────┐                                      │
│                            │    Traefik    │                                      │
│                            │     :80       │                                      │
│                            └───────────────┘                                      │
│                                                                                  │
│  ┌──────────────┐  ┌──────────┐                                                  │
│  │   UED Sync   │  │   Seed   │  (one-time, runs after LDAP healthy)             │
│  │    :8000     │  │ container│                                                  │
│  │  (internal)  │  └──────────┘                                                  │
│  └──────────────┘                                                                │
│        ▲                                                                         │
│        │ HTTP (directory-api → ued-sync:8000)                                    │
│        │ No host port — internal only                                            │
└──────────────────────────────────────────────────────────────────────────────────┘
         │
    Host Ports: 8081 (HTTP), 1390 (LDAP), 5433 (PostgreSQL), 6380 (Redis)
```

### Port Mappings (Host → Container)

| Host Port | Container Port | Service | Description |
|-----------|----------------|---------|-------------|
| 8081 | 80 | Traefik | HTTP (routes /api → API, / → UI) |
| 1390 | 389 | OpenLDAP | LDAP directory queries |
| 1637 | 636 | OpenLDAP | LDAPS (disabled by default) |
| 5433 | 5432 | PostgreSQL | Database |
| 6380 | 6379 | Redis | Rate limiting / caching |
| 8083 | 8080 | Traefik | Dashboard (debug) |
| *(none)* | 8000 | UED Sync | Internal only — called by API via `http://ued-sync:8000` |

### Data Flow

**Admin requests (user-facing):**
1. **User request** → Traefik (:8081)
2. **Routing** → `/api/*` → Directory API, `/*` → UI
3. **Auth check** → LDAP bind verify or JWT validation
4. **User/Group queries** → OpenLDAP
5. **Org/QR state** → PostgreSQL
6. **Rate limiting** → Redis
7. **Response** → JSON to client

**UED Sync flow (internal, async):**
1. **User mutation** (create/update/suspend/terminate/password) → Directory API writes to LDAP
2. **Sync event created** → `sync_events` table in PostgreSQL (status: pending)
3. **SyncWorker** (background task in API) → picks up pending events
4. **HTTP POST** → `http://ued-sync:8000/api/v1/sync/user` with tenant LDAP config + user payload
5. **UED Sync** → writes to tenant's UC LDAP (XMPP/SIP provisioning)
6. **On failure** → exponential backoff retry (5s × 3^attempt, capped at 1hr, max 10 attempts)

## 3. Configuration

### Environment Variables

Copy `.env.example` to `.env` and customize:

```bash
cp .env.example .env
```

#### Database (PostgreSQL)

| Variable | Default | Description |
|----------|---------|-------------|
| `POSTGRES_USER` | azblink_directory | Database username |
| `POSTGRES_PASSWORD` | azblink_directory | Database password |
| `POSTGRES_DB` | azblink_directory | Database name |

#### LDAP (osixia/openldap)

| Variable | Default | Description |
|----------|---------|-------------|
| `LDAP_ORGANISATION` | AZBlink | Organization name |
| `LDAP_DOMAIN` | azblink.com | Domain → dc=azblink,dc=com |
| `LDAP_ADMIN_PASSWORD` | adminpassword | Admin bind password |

#### API LDAP Connection

| Variable | Default | Description |
|----------|---------|-------------|
| `LDAP_URI` | ldap://openldap:389 | LDAP server URI |
| `LDAP_BASE_DN` | dc=azblink,dc=com | Base DN for searches |
| `LDAP_TENANT` | azblink | Tenant identifier |
| `LDAP_BIND_DN` | cn=admin,dc=azblink,dc=com | Service account DN |
| `LDAP_BIND_PW` | adminpassword | Service account password |

#### API Authentication

| Variable | Default | Description |
|----------|---------|-------------|
| `REQUIRE_OIDC_AUTH` | false | Require OIDC tokens |
| `ALLOW_BOOTSTRAP_WITHOUT_OIDC` | true | Allow bootstrap endpoints |
| `ORG_QR_SIGNING_SECRET` | dev_signing_secret_change_in_prod | QR code signing key |
| `BREAKGLASS_FILE` | /etc/azblink/directory/breakglass.json | Emergency access config |

#### UED Sync API (Internal Service)

| Variable | Default | Description |
|----------|---------|-------------|
| `UED_API_KEY` | `dev-ued-api-key` | Bearer token for UED Sync API authentication |
| `UED_DEBUG` | `false` | Structured logging mode (`true` = human-readable, `false` = JSON) |
| `UED_RATE_LIMIT_ENABLED` | `true` | Enable per-API-key rate limiting on UED Sync |
| `UED_RATE_LIMIT_REQUESTS` | `100` | Requests per rate limit window |

#### UED Integration (Directory API Side)

| Variable | Default | Description |
|----------|---------|-------------|
| `UED_ENCRYPTION_KEY` | *(empty)* | Fernet key for encrypting tenant secrets at rest. Required only when `tenant_ldap_configs` has rows. Generate: `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"` |

## 4. LDAP Schema

### DN Structure

```
dc=azblink,dc=com                    (domain root - auto-created)
├── ou=org                           (organization tree)
│   └── ou=GlobalHQ
│       ├── ou=Engineering
│       │   ├── ou=Platform
│       │   │   ├── ou=Security
│       │   │   └── ou=EdgeSystems
│       │   └── ou=ProductEngineering
│       ├── ou=Marketing
│       │   ├── ou=Brand
│       │   └── ou=DemandGen
│       └── ou=Legal
├── ou=people                        (user accounts)
│   ├── uid=robert
│   ├── uid=alex
│   ├── uid=sarah
│   ├── uid=james
│   ├── uid=mei
│   ├── uid=kevin
│   └── uid=laura
└── ou=groups                        (security groups)
    ├── cn=IT-Admins
    ├── cn=Engineering
    ├── cn=All-Staff
    └── cn=Managers
```

### Object Classes

#### organizationalUnit (org tree, containers)
```ldif
objectClass: organizationalUnit
ou: <unit name>
description: <optional description>
```

#### inetOrgPerson (users)
```ldif
objectClass: inetOrgPerson
objectClass: organizationalPerson
objectClass: person
uid: <username>
cn: <full name>
sn: <surname>
givenName: <first name>
displayName: <display name>
title: <job title>
mail: <email>
telephoneNumber: <extension>
l: <location>
ou: <department>
manager: <manager DN>
userPassword: <password>
```

#### groupOfNames (groups)
```ldif
objectClass: groupOfNames
cn: <group name>
description: <description>
member: <user DN>
member: <user DN>
...
```

## 5. Preseed Data

Data is seeded in two stages during `docker compose up`:

### Stage 1: bootstrap.ldif (immediate)

Mounted into OpenLDAP container. Creates core users, groups, and org tree.

### Stage 2: seed service (after LDAP healthy)

The `seed` container runs `seed_demo_data.py` once to add 50+ demo users with avatars.

---

### Admin Credentials

| Purpose | Credential | Value |
|---------|------------|-------|
| LDAP Admin DN | `cn=admin,dc=azblink,dc=com` | `adminpassword` |
| PostgreSQL | `azblink_directory` | `azblink_directory` |

### Web Portal Login (Recommended)

| Username | Password | Notes |
|----------|----------|-------|
| `mei` | `password123` | Use for login/auth testing |

### Bootstrap Users (7 total, from `bootstrap.ldif`)

| uid | Name | Title | Dept | Manager | Password |
|-----|------|-------|------|---------|----------|
| robert | Robert Lin | VP of Engineering | Engineering | - | `password123` |
| alex | Alex Chen | Senior NFV Architect | Security | robert | `password123` |
| sarah | Sarah Kim | Network Automation Engineer | EdgeSystems | alex | `password123` |
| james | James Miller | Product Engineer | ProductEngineering | robert | `password123` |
| mei | Mei Wang | Brand Strategist | Brand | - | `password123` |
| kevin | Kevin Huang | Demand Generation Lead | DemandGen | - | `password123` |
| laura | Laura Chen | Corporate Counsel | Legal | - | `password123` |

### Demo Users (~51 total, from `seed` service)

All demo users have password: **`demo123`**

| Department | Count | Example UIDs |
|------------|-------|--------------|
| Executive | 2 | dchang (CEO), ewu |
| Engineering | 11 | tchen, ywang, jlee, mlin, qlin |
| Sales | 10 | mtorres (CSO), cyang, dwang |
| Marketing | 4 | jpark (CMO), alin, vchen |
| Operations | 6 | rlee (COO), slin, dhuang |
| Finance | 4 | suchen (CFO), jhuang, hchen |
| HR | 4 | aliu (CHRO), elin, phuang |
| Legal | 2 | wzhang (GC), nwu |
| Customer Success | 5 | nicolew (VP), jchen, ylin |

See `deploy/dev/seed/seed_demo_data.py` for complete list with all attributes.

### Bootstrap Groups (4 total)

| Group | Members |
|-------|---------|
| IT-Admins | robert, alex |
| Engineering | robert, alex, sarah, james |
| All-Staff | all 7 bootstrap users |
| Managers | robert, alex |

### Demo Groups (from seed service)

| Group | Description |
|-------|-------------|
| Sales | All sales department |
| Operations | All operations |
| Finance | All finance |
| HR | All HR |
| CustomerSuccess | All CS |
| Executive | C-suite assistants |
| C-Suite | All C-level executives |
| Directors | Directors and VPs |

## 6. Development Workflow

### Initial Setup

```bash
# Navigate to dev deployment
cd deploy/dev

# Copy environment template
cp .env.example .env

# Build and start (first time, ~45s)
docker compose up --build
```

### Daily Development

```bash
# Start services (~2s)
docker compose up

# Or in background
docker compose up -d

# Watch API logs
docker compose logs -f directory-api

# Edit src/backend/*.py files - changes auto-reload
```

### Testing Changes

```bash
# API health check
curl http://localhost:8081/api/health

# List users via API (DEV_AUTH_TOKEN bypass; real logins go through Authentik OIDC, ARD-002)
curl -H "Authorization: Bearer $DEV_AUTH_TOKEN" http://localhost:8081/api/users

# List org tree via API
curl -H "Authorization: Bearer $DEV_AUTH_TOKEN" http://localhost:8081/api/org/tree

# Direct LDAP query (from host)
ldapsearch -x -H ldap://localhost:1390 \
  -b "ou=people,dc=azblink,dc=com" \
  -D "cn=admin,dc=azblink,dc=com" \
  -w adminpassword \
  "(objectClass=inetOrgPerson)" uid cn title
```

### Debugging

```bash
# API container shell
docker compose exec directory-api bash

# Check LDAP connectivity from API container
docker compose exec directory-api python -c "
import ldap3
conn = ldap3.Connection('ldap://openldap:389', 'cn=admin,dc=azblink,dc=com', 'adminpassword', auto_bind=True)
print('LDAP connected:', conn.bound)
"

# PostgreSQL shell
docker compose exec postgres psql -U azblink_directory

# View running containers
docker compose ps

# Check seed service logs
docker compose logs seed

# Redis CLI
docker compose exec redis redis-cli
```

### Clean Reset

```bash
# Stop and remove volumes (deletes all data including seed state)
docker compose down -v

# Rebuild from scratch (re-runs bootstrap + seed)
docker compose up --build
```

## 7. Troubleshooting

### API Fails to Start

**Symptom:** `directory-api` exits immediately
**Check:** `docker compose logs directory-api`
**Common causes:**
- Missing requirements in `requirements.txt`
- Syntax error in Python code
- Dependent services (postgres, openldap, redis) not healthy yet

### LDAP Connection Refused

**Symptom:** API logs show "LDAP connection refused"
**Check:** `docker compose logs openldap`
**Solution:** OpenLDAP takes ~10s to initialize on first start. Wait and retry.

### Database Connection Failed

**Symptom:** "could not connect to server"
**Check:** `docker compose ps` - verify postgres is running
**Check:** `docker compose logs postgres`
**Solution:** Wait for healthcheck to pass, or `docker compose restart directory-api`

### LDAP Data Not Found

**Symptom:** API returns empty users/groups
**Check:**
```bash
docker compose exec openldap ldapsearch -x -b "dc=azblink,dc=com" -D "cn=admin,dc=azblink,dc=com" -w adminpassword
```
**Solution:** If bootstrap.ldif wasn't loaded, `docker compose down -v` and restart.

### Hot Reload Not Working

**Symptom:** Code changes don't take effect
**Check:** Volume mount in `docker compose ps`
**Solution:** Ensure `src/backend` path is correct relative to `docker-compose.yml`

### Seed Service Failed

**Symptom:** Only 7 users exist (demo users missing)
**Check:** `docker compose logs seed`
**Common causes:**
- LDAP not healthy when seed started
- Network connectivity issues to ui-avatars.com (avatar download)
**Solution:** `docker compose down -v && docker compose up --build`

### Missing Demo Data After Restart

**Symptom:** Had 58 users, now only 7
**Cause:** Volumes were deleted (`docker compose down -v`)
**Solution:** Seed runs automatically on fresh volumes. Just wait ~30s for seed to complete.

### UED Sync Not Responding

**Symptom:** Sync events stuck in `pending` or `failed` status
**Check:** `just ued-logs` or `docker compose logs ued-sync`
**Common causes:**
- UED Sync container not running — check `just ps`
- Wrong `UED_API_KEY` — API and UED Sync must share the same key
- Python import error — check for missing deps (`just ued-rebuild`)

### UED Encryption Key Missing

**Symptom:** API fails when creating/reading tenant UED configs
**Check:** `UED_ENCRYPTION_KEY` in `.env`
**Solution:** Generate a Fernet key: `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`
**Note:** Only required when `tenant_ldap_configs` table has rows. Not needed for basic directory operations.

### UED Sync Tests Failing

**Symptom:** `just ued-test` fails with import errors
**Check:** Tests run inside the container using `/app/.venv/bin/python`, not system Python.
**Solution:** `just ued-rebuild` to reinstall deps, then `just ued-test`

## 8. Production Notes

This development setup is **NOT** production-ready. For production:

| Aspect | Dev | Production |
|--------|-----|------------|
| LDAP password | `adminpassword` | Strong, rotated password |
| LDAP TLS | Disabled | Required (LDAPS or StartTLS) |
| DB password | `azblink_directory` | Strong, rotated password |
| JWT secret | `dev_jwt_secret_...` | `openssl rand -hex 32` |
| QR signing secret | `dev_signing_secret_...` | Vault/secrets manager |
| User passwords | `password123` / `demo123` | User-set, hashed |
| OIDC auth | Disabled | Required |
| Breakglass | Always enabled | Disabled or time-limited |
| Volumes | Local Docker | Persistent storage (EBS, etc) |
| Networking | Host ports | Internal only, load balancer |
| Redis | No auth | Password + TLS |
| UED API key | `dev-ued-api-key` | Strong random key per tenant, rotated |
| UED encryption key | Empty / optional | Required Fernet key via secrets manager |
| UED networking | Docker internal | Private subnet, no public exposure |
| UED scaling | Single instance | One instance per tenant (horizontal) |
| UED hot reload | Enabled (`--reload`) | Disabled; use gunicorn + uvicorn workers |
| CORS origins | `localhost:8081` | Explicit frontend origin(s) only |

### UED Sync Production Considerations

- **Encryption:** `UED_ENCRYPTION_KEY` (Fernet) encrypts tenant LDAP passwords and API keys at rest in PostgreSQL. Rotate via key re-encryption migration.
- **Retry worker:** Background `SyncWorker` in directory-api processes events with exponential backoff (5s → 1hr cap, 10 attempts). Failed events kept indefinitely for manual retry.
- **Event retention:** Completed events pruned after 90 days (configurable). Failed events require manual intervention via admin API.
- **Health monitoring:** UED Sync exposes `GET /health` (no auth). Wire to load balancer or orchestrator health checks.
- **Isolation:** UED Sync must never be exposed to end users. Internal-only networking. API key auth on every request.
- **Per-tenant model:** Each tenant gets its own UED URL + API key stored in `tenant_ldap_configs`. In production, consider separate UED Sync instances per tenant for blast-radius isolation.

See main deployment documentation for production hardening checklist.
