#!/usr/bin/env bash
# lan-to-vpn-gateway.sh
# - Makes THIS host a NAT gateway so ONE LAN client can reach the azb AD
#   platform on the VPN subnet (UI :8081 + Authentik :9000 on 192.168.11.126),
#   with full OIDC web login + logout working (redirect URIs are origin-derived,
#   so they stay 192.168.11.126 — no platform/Authentik changes needed).
# - Path: client -> this host (192.168.4.111/wlo1) -> tun0 -> 192.168.11.0/24.
# - MASQUERADE is required: the VPN peer only routes back to this host's tunnel
#   IP, not to the client, so the client source is rewritten onto the tunnel.
# - Rules are INSERTED at the top of FORWARD to beat Docker's chain.
# - Idempotent. Actions: up (default) | down | status. Self-elevates via sudo.
# - Runtime only (not persisted across reboot — see PERSIST note at the bottom).
set -euo pipefail

# --- Config (override via env: CLIENT=x.x.x.x ./lan-to-vpn-gateway.sh) --------
CLIENT="${CLIENT:-192.168.4.233}"           # the single LAN device allowed in
VPN_SUBNET="${VPN_SUBNET:-192.168.11.0/24}" # platform subnet behind the VPN
# Auto-detect the tunnel iface that routes to the VPN subnet; fall back to tun0.
TUN="${TUN:-$(ip route get "${VPN_SUBNET%/*}" 2>/dev/null \
  | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -1)}"
TUN="${TUN:-tun0}"

ACTION="${1:-up}"

# --- Re-exec as root (iptables/sysctl need it); preserve env overrides --------
if [[ $EUID -ne 0 ]]; then exec sudo -E "$0" "$@"; fi

# Source IP this host uses to reach the client = the gateway IP to advertise.
GW_IP="$(ip route get "$CLIENT" 2>/dev/null | sed -n 's/.*src \([0-9.]*\).*/\1/p' | head -1)"
GW_IP="${GW_IP:-192.168.4.111}"

# Rule fragments (kept identical for add / -C check / -D delete).
FWD_OUT=(-s "$CLIENT" -d "$VPN_SUBNET" -j ACCEPT)
FWD_RET=(-s "$VPN_SUBNET" -d "$CLIENT" -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT)
NAT_MASQ=(-s "$CLIENT" -d "$VPN_SUBNET" -o "$TUN" -j MASQUERADE)

# Insert into FORWARD only if missing; always at the top to outrank Docker.
ins_forward() { iptables -C FORWARD "$@" 2>/dev/null || iptables -I FORWARD 1 "$@"; }
del_forward() { while iptables -C FORWARD "$@" 2>/dev/null; do iptables -D FORWARD "$@"; done; }
add_nat()     { iptables -t nat -C POSTROUTING "$@" 2>/dev/null || iptables -t nat -A POSTROUTING "$@"; }
del_nat()     { while iptables -t nat -C POSTROUTING "$@" 2>/dev/null; do iptables -t nat -D POSTROUTING "$@"; done; }

up() {
  [[ "$(cat /sys/class/net/"$TUN"/operstate 2>/dev/null || echo down)" == "down" ]] && \
    echo "WARN: $TUN looks down — VPN must be up for this to work." >&2
  sysctl -w net.ipv4.ip_forward=1 >/dev/null
  ins_forward "${FWD_RET[@]}"   # return path first
  ins_forward "${FWD_OUT[@]}"   # client -> VPN
  add_nat     "${NAT_MASQ[@]}"
  echo "UP: $CLIENT  ->  $VPN_SUBNET  via $TUN  (gateway $GW_IP)"
  echo
  echo "Now on the CLIENT ($CLIENT) add a route to the VPN subnet:"
  echo "  Linux:    sudo ip route add $VPN_SUBNET via $GW_IP"
  echo "  macOS:    sudo route -n add $VPN_SUBNET $GW_IP"
  echo "  Windows:  route add ${VPN_SUBNET%/*} mask 255.255.255.0 $GW_IP   (admin)"
  echo
  echo "Then on the client:  curl -I http://192.168.11.126:8081/"
  echo "Then browse:         http://192.168.11.126:8081/   (login + logout work)"
}

down() {
  del_forward "${FWD_OUT[@]}"
  del_forward "${FWD_RET[@]}"
  del_nat     "${NAT_MASQ[@]}"
  echo "DOWN: removed gateway rules for $CLIENT -> $VPN_SUBNET (ip_forward left as-is)"
  echo "On the client, drop the route:  sudo ip route del $VPN_SUBNET   (Linux)"
}

status() {
  echo "ip_forward = $(cat /proc/sys/net/ipv4/ip_forward)   TUN=$TUN operstate=$(cat /sys/class/net/"$TUN"/operstate 2>/dev/null || echo missing)"
  echo "--- FORWARD (our rules) ---"
  iptables -S FORWARD | grep -E "$CLIENT|${VPN_SUBNET%/*}" || echo "(none)"
  echo "--- nat POSTROUTING (counters) ---"
  iptables -t nat -L POSTROUTING -v -n | grep -E "MASQUERADE|${VPN_SUBNET%/*}" || echo "(none)"
}

case "$ACTION" in
  up)     up ;;
  down)   down ;;
  status) status ;;
  *) echo "usage: $0 [up|down|status]   (env: CLIENT=, VPN_SUBNET=, TUN=)" >&2; exit 2 ;;
esac

# PERSIST (optional, survive reboot): after `up` works,
#   apt-get install -y iptables-persistent   # saves current rules
#   echo 'net.ipv4.ip_forward=1' | sudo tee /etc/sysctl.d/99-vpn-gw.conf
# Rules still need tun0 up at boot; re-run `up` after the VPN reconnects.
