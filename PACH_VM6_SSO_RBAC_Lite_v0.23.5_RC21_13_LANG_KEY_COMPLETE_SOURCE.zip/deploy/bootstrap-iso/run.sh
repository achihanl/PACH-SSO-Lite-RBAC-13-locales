#!/usr/bin/env bash
# The whole bootstrap-ISO pipeline behind one command.
#
#   ./run.sh azb-node02
#
#   1. source ISO in the shared cache?  no -> resolve the current point release,
#                                            download it, verify its sha256
#   2. build.py --host <host>                -> out/<host>.iso, verified on build
#   3. smoke-test.sh out/<host>.iso          -> qemu/OVMF on VNC :1, you watch
#   4. print the upload steps, and clean.sh as the follow-up
#
# It stops with the ISO ready to upload and does not go further: attaching it to
# the hypervisor is manual and out of band, so the pipeline must not reclaim the
# artifact it just produced. That is clean.sh's job, once the VM is up.
#
# Environment:
#   AZB_ISO_CACHE       where the shared source ISO lives (~/.cache/azb/iso)
#   AZB_UBUNTU_RELEASE  release series to resolve against (24.04)
#   AZB_PYTHON          interpreter for build.py, which needs PyYAML (python3).
#                       If pip here is configured with require-virtualenv, this
#                       is how you point at the venv that has it.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ISO_CACHE="${AZB_ISO_CACHE:-$HOME/.cache/azb/iso}"
UBUNTU_RELEASE="${AZB_UBUNTU_RELEASE:-24.04}"
RELEASE_URL="https://releases.ubuntu.com/${UBUNTU_RELEASE}"
PYTHON="${AZB_PYTHON:-python3}"

# sha256 tool differs between GNU (Linux) and BSD (macOS).
if command -v sha256sum >/dev/null 2>&1; then
    _sha256() { sha256sum "$1" | cut -d' ' -f1; }
else
    _sha256() { shasum -a 256 "$1" | cut -d' ' -f1; }
fi

# The newest ubuntu-*-live-server-amd64.iso in a SHA256SUMS file, printed as
# "<sha256> <filename>". Empty output means the file lists no such image.
#
# Version-sorted, not lexicographic: 24.04.10 supersedes 24.04.4, and plain sort
# ranks them the other way round — which would silently pin a superseded image.
_newest_live_server() {
    awk '$2 ~ /^\*?ubuntu-.*-live-server-amd64\.iso$/ {
             sub(/^\*/, "", $2); print $2, $1
         }' "$1" | sort -V | tail -1 | awk 'NF {print $2, $1}'
}

_newest_iso_in() {
    [ -d "$1" ] || return 0
    find "$1" -maxdepth 1 -type f -name 'ubuntu-*-live-server-*.iso' 2>/dev/null \
        | sort -V | tail -1
}

# Downloads into $1 and prints the verified ISO's path on stdout.
_download_and_verify() {
    local dest_dir="$1" sums digest name part final
    sums="$(mktemp)"

    echo "  resolving current point release from $RELEASE_URL/SHA256SUMS" >&2
    if ! curl -fsSL --retry 3 -o "$sums" "$RELEASE_URL/SHA256SUMS"; then
        rm -f "$sums"
        echo "error: cannot reach $RELEASE_URL/SHA256SUMS." >&2
        echo "       Refusing to build against an unverified ISO. Fetch one by hand," >&2
        echo "       check it against that file, and drop it in $dest_dir:" >&2
        echo "         $RELEASE_URL/" >&2
        return 1
    fi

    read -r digest name <<<"$(_newest_live_server "$sums")"
    rm -f "$sums"
    if [ -z "${digest:-}" ] || [ -z "${name:-}" ]; then
        echo "error: $RELEASE_URL/SHA256SUMS lists no *-live-server-amd64.iso." >&2
        echo "       Is AZB_UBUNTU_RELEASE=$UBUNTU_RELEASE a real release series?" >&2
        return 1
    fi

    mkdir -p "$dest_dir"
    part="$dest_dir/$name.part"
    final="$dest_dir/$name"
    echo "  downloading $name (~3.2 GB) into $dest_dir" >&2
    if ! curl -fL --retry 3 -C - -o "$part" "$RELEASE_URL/$name"; then
        rm -f "$part"
        echo "error: download failed; removed the partial file." >&2
        return 1
    fi

    echo "  verifying sha256" >&2
    if [ "$(_sha256 "$part")" != "$digest" ]; then
        rm -f "$part"
        echo "error: sha256 mismatch against the freshly-fetched SHA256SUMS." >&2
        echo "       Deleted the download and refusing to build." >&2
        return 1
    fi
    mv "$part" "$final"
    echo "$final"
}

# Prints the path to a usable source ISO, downloading one only if none exists.
_ensure_source_iso() {
    local existing dest_dir

    # Cache before src/ — the same order build.py resolves in, so run.sh and a
    # bare build.py invocation never disagree about which image is in use.
    existing="$(_newest_iso_in "$ISO_CACHE")"
    [ -n "$existing" ] || existing="$(_newest_iso_in "$HERE/src")"
    if [ -n "$existing" ]; then
        echo "$existing"
        return 0
    fi

    dest_dir="$ISO_CACHE"
    mkdir -p "$dest_dir" 2>/dev/null || true
    if [ ! -w "$dest_dir" ]; then
        echo "warning: $dest_dir is not writable — using $HERE/src instead." >&2
        echo "         This clone will keep its own copy; fix the cache to share one." >&2
        dest_dir="$HERE/src"
    fi
    _download_and_verify "$dest_dir"
}

# Sourcing defines the helpers without running the pipeline. That is the seam
# tests/unit/test_bootstrap_iso_run.py uses to exercise the parsing above.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then return 0; fi

# --------------------------------------------------------------------------
# pipeline
# --------------------------------------------------------------------------

HOST="${1:?usage: run.sh <host>   (a name in hosts/, without .env)}"
ISO="$HERE/out/$HOST.iso"

echo "==> 1/3  source ISO"
SOURCE="$(_ensure_source_iso)"
echo "  using $SOURCE"

echo
echo "==> 2/3  build"
"$PYTHON" "$HERE/build.py" --host "$HOST" --source "$SOURCE"

echo
echo "==> 3/3  smoke test — qemu/OVMF on VNC :${VNC_DISPLAY:-1}"
# A Ctrl-C aimed at qemu lands on this whole process group, and Ctrl-C is the
# normal way a smoke test ends. Absorb it here so the upload steps below still
# get printed; smoke-test.sh traps the same signal and clears its own scratch.
trap 'echo' INT
if ! "$HERE/smoke-test.sh" "$ISO"; then
    echo "warning: the smoke test did not complete cleanly (qemu may be absent)." >&2
    echo "         $ISO is built and verified, and is still uploadable." >&2
fi
trap - INT

cat <<EOF

Next:
  1. upload $ISO through the hypervisor's web panel
  2. attach as CD/DVD, boot UEFI, watch VNC (~4-8 min)
  3. read the address off the login banner, or log in and run \`azb-netinfo\`
  4. add the host to deploy/ansible/inventories/*/hosts.ini and converge
  5. once the VM is up: $HERE/clean.sh      # reclaims out/ (~3.2 GB per ISO)
EOF
