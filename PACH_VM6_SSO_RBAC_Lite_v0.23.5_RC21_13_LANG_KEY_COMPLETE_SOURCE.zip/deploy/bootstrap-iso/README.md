# VM bootstrap ISO

Turns a bare VM into a box `deploy/ansible` can SSH into and converge, with no
keystrokes after "power on".

## Why an ISO at all

The hypervisor gives us exactly one input channel: **upload an ISO → attach as
CD/DVD → boot UEFI → watch VNC**. No cloud-init drive, no disk import, no API.
So the ISO *is* the API — every per-VM fact has to be baked in before upload.

It has to be baked in, specifically, rather than fetched at boot. The obvious
alternative is one universal ISO that pulls its config from an HTTP server
(cloud-init's `ds=nocloud;s=http://…`), and most write-ups recommend exactly
that. It does not work here: the provisioner would live on our side of the VPN,
and a freshly-booted VM has a DHCP lease and no route to us. It would hang
fetching `user-data`, and we would debug it over VNC — which is the manual step
this exists to remove.

So: one ISO per VM, generated locally, with all identity baked in and zero
network dependency during install.

## Scope — what this deliberately does NOT do

The ISO installs Ubuntu, a user, a key, a static address, and the guest agent.
That is all. Docker, `just`, git, the app itself — those are `deploy/ansible`'s
job (`host_prep` + `azblink_app`) and it already does them idempotently.

Resist putting software here. A golden image or a fat package list creates a
second place that defines what is on the box, and the two will drift. The
handoff is deliberately narrow: **the ISO's only contract is "SSH-reachable at
a known address with a known key".**

## Usage

```bash
cp hosts/example.env hosts/azb-node02.env && $EDITOR hosts/azb-node02.env
just bootstrap-iso-preview azb-node02    # read the rendered YAML — costs nothing
just bootstrap-iso-run azb-node02        # source ISO -> build -> smoke test
```

`bootstrap-iso-run` acquires a source ISO the first time it needs one, into
`~/.cache/azb/iso` — shared by every clone on this machine, so nothing after the
first run downloads 3 GB again. It resolves the current point release from a
`SHA256SUMS` fetched at download time rather than hardcoding one (24.04.4
supersedes .3) and verifies the download against that. If it cannot reach
`releases.ubuntu.com` it stops and prints the manual URL: an unverified ISO is
never built against.

The individual steps are still there when you want one of them on its own:

```bash
just bootstrap-iso azb-node02            # -> out/azb-node02.iso, verified on build
just bootstrap-iso-test azb-node02       # boot under qemu/OVMF on VNC :1
```

Then upload `out/azb-node02.iso` through the hypervisor's web panel, attach it as
CD/DVD, boot UEFI, watch VNC (~4–8 min). Read the DHCP address off the login
banner or run `azb-netinfo`, then:

```bash
ssh keith@<address>
# add to deploy/ansible/inventories/dev/hosts.ini, then:
cd deploy/ansible && ansible-playbook site.yml -K
```

## Verification

`build.py` verifies every ISO it builds, before you upload it:

- the built ISO's El Torito boot configuration is **identical to the source's**
  (a dropped or altered boot record means it will not boot under UEFI)
- the volume ID is unchanged — casper finds the medium by label, and renaming it
  is a classic non-booting ISO
- `/autoinstall.yaml` and `/azb/azb-netinfo` read back byte-identical
- `grub.cfg` carries the `autoinstall` kernel argument **and** defaults to the
  `azb-autoinstall` entry
- **every** installer entry in `grub.cfg` is unattended — not just ours. A stock
  entry without `autoinstall` fails the build (see "A keystroke is a failure
  mode" below)
- the rendered `autoinstall.yaml` parses. This requires PyYAML; without it the
  build now **fails** rather than printing a note and continuing, because a
  silently-skipped check on the only machine that builds ISOs is worse than no
  check. Override with `--skip-yaml-check` if you really mean it

Re-check an ISO without rebuilding it (seconds, not minutes):

```bash
just bootstrap-iso azb-node02 --verify-only
```

That covers the ways ISO surgery goes wrong. What it cannot catch is subiquity
rejecting the autoinstall *semantically* — a key it does not recognise. Only a
real boot finds that, which is what `just bootstrap-iso-test` is for when qemu is
installed. The remote loop is upload-over-VPN → boot → squint at VNC → find a
typo → repeat, so run it whenever the config changes shape.

**On comparing boot records:** Ubuntu ships the EFI boot image as an *appended
GPT partition*, not a file in the ISO filesystem. Adding `/autoinstall.yaml` and
`/azb/` makes the image larger, so that partition necessarily starts at a
different offset — the check normalises those offsets and the image's own path,
while still requiring the partition *size*, every structural flag, and both
partition-type GUIDs to match. A verifier that compares the report verbatim
fails every legitimate build.

## First question after a boot: did autoinstall actually run?

Ask the box directly, on the VNC console:

```
cat /etc/azb-bootstrap
```

```
azb-autoinstall=applied
ssh.service=disabled        <- expected: sshd is socket-activated on 24.04
ssh.socket=enabled          <- this is the one that means SSH will answer
```

`ssh.service=disabled` is **not** a fault. On 24.04 sshd is started on demand by
`ssh.socket`, so the service unit is legitimately disabled on a box that accepts
SSH perfectly well. Both units are recorded by name precisely so that this file
cannot be misread as a broken install.

**No such file ⇒ the autoinstall never applied** and you are looking at a
hand-installed box, whatever else it looks like. Treat everything else as
unconfigured and reinstall; do not debug forward from there.

This exists because the alternative is inferring it from absences — no sshd, no
`azb-netinfo`, an `/etc/issue` with no banner — which is slow and reaches the
right answer only if you already suspect it. `/etc/issue` still carries the
banner and is the faster tell pre-login, but it is a side effect; this file is
the statement.

## Networking: DHCP by default, read the address back over VNC

There is nothing to configure. The default is `AZB_NIC=auto` (netplan matches
every `en*` interface) and `AZB_IP_CIDR=dhcp`, so the box configures itself on
a bridged segment and **the NIC name never has to be known** — which matters,
because it varies by hypervisor (`enp1s0` / `ens18` / `ens192`) and cannot be
guessed from here.

That leaves one question: what address did it get? Two answers, both on the
VNC console you already have:

1. **Before logging in.** The install appends to `/etc/issue`, so the login
   banner itself shows the hostname and IPv4 (via agetty's `\4` escape):

   ```
   AZB bootstrap node azb-node02  --  IPv4: 192.168.11.57
   Log in and run 'azb-netinfo' for the full network + SSH details.
   ```

2. **After logging in**, `azb-netinfo` prints everything needed to take over
   from the control node — interfaces with MAC/address/DHCP-vs-static, default
   route, DNS, whether sshd is up, password auth, key count, the SSH host-key
   fingerprints (worth checking on a first connect over the VPN), and a
   copy-paste `hosts.ini` line:

   ```
   == Connect from the deploy control node ==
     ssh keith@192.168.11.57

     deploy/ansible/inventories/dev/hosts.ini
       azb-node02 ansible_host=192.168.11.57 ansible_user=keith
   ```

   It needs no sudo, and stays useful after Ansible has installed Docker — it
   filters out veth/bridge interfaces so the real NIC does not get buried.

`qemu-guest-agent` is in the default package list for the same reason: it
reports the lease to the hypervisor, which shows the address in its VM summary.

**To know the address in advance**, don't go static — add a DHCP reservation
against the vNIC MAC, which the hypervisor shows in the VM settings before the
VM has ever booted. That keeps addressing in one place, keeps the NIC name out
of it, and survives a hypervisor upgrade renaming the interface.

**Static config** (`AZB_NIC` + `AZB_IP_CIDR` + `AZB_GATEWAY` + `AZB_DNS`) is
only for a segment with no DHCP. To get the NIC name for it without installing
anything: boot the stock Ubuntu ISO, choose *Try or Install Ubuntu*, and stop
at the **"Network connections"** screen — it lists every interface by real name
and MAC, and shows the DHCP lease if one was offered. Screenshot, power off.

## How the ISO is built

Not extract-and-repack. That means reconstructing the source ISO's El Torito
boot records by hand, which is where the guides go wrong — and Ubuntu 24.04
live-server no longer ships `isolinux/`, so every recipe with
`-b isolinux/isolinux.bin` fails outright on it.

Instead `build.py` copies the ISO with `xorriso -boot_image any replay`, which
reproduces the original boot configuration exactly, and overlays two files:

| Path in ISO | Source |
|---|---|
| `/autoinstall.yaml` | rendered from `templates/autoinstall.yaml.tmpl` |
| `/boot/grub/grub.cfg` | Canonical's file, verbatim, + `templates/grub.cfg.tmpl` appended |
| `/azb/` | `files/` — copied into the installed system by `late-commands` |

Everything else is untouched, so the signed shim, GRUB and kernel stay
byte-identical and the ISO still boots under Secure Boot. Ubuntu does not
signature-check `grub.cfg`, so editing it is safe.

Subiquity finds `/autoinstall.yaml` because it sits at the root of the install
medium and `autoinstall` is on the kernel command line. That kernel argument is
the whole trick — without it the installer stops and asks a human to confirm.

## Gotchas encoded here

Each of these is a real failure mode, handled in the templates or `build.py`:

- **Root-of-medium and `ds=nocloud` are different mechanisms.** Guides routinely
  mix them (put `autoinstall.yaml` at the root, then point `ds=` at a
  `nocloud/` directory that does not exist). We use root-of-medium only.
- **`set default=` is load-bearing.** On this platform the stock menu can come
  up with the highlight on *UEFI Firmware Settings*; an unattended boot that
  times out there sits in the firmware setup screen forever. We select by
  `--id`, appended last, so the stock menu is left intact as a fallback.
- **A keystroke is a failure mode.** `set default` only governs what the
  *timeout* picks. Stock entry #1, "Try or Install Ubuntu Server", boots the
  installer interactively — so anyone watching VNC who presses a key during the
  1-second menu gets a manual install. The box that produces has no sshd, no
  `azb-netinfo` and an unmodified `/etc/issue`, which looks identical to the ISO
  never having been read, and sends you debugging the wrong thing. `build.py`
  now appends `autoinstall` to every stock casper entry and refuses to ship an
  ISO where any installer entry is still interactive.
- **The installer leaves `deb cdrom:` in the target's `sources.list`.** Once the
  CD is detached — the normal end state — apt resolves packages to `file:/cdrom`
  paths that no longer exist and fails there, without falling through to the
  network mirror. `apt install openssh-server` on such a box dies with
  `File not found - /cdrom/pool/main/o/openssh/…`. A late-command comments the
  line out.
- **`/cdrom` is not visible inside the `curtin in-target` chroot.** Anything
  shipped on the ISO must be copied to `/target` by a plain late-command first.
- **Every late-command pipeline goes through `bash -c`.** A bare pipeline is the
  classic "installer hangs forever at Executing late commands".
- **The `lvm` layout does not use the whole disk.** It caps the root LV and
  leaves the rest unallocated in the VG. `AZB_GROW_ROOT=true` extends to
  `100%FREE` (with `|| true`, because `lvextend` exits non-zero when there is
  nothing left to take, which would fail the install).
- **Never change the volume ID on repack.** Casper locates the medium by its
  label; renaming it produces an ISO that will not boot.
- **The NIC name cannot be guessed.** See `AZB_NIC` in `hosts/example.env`.
- `md5sum.txt` in the ISO goes stale. Harmless — it only affects the "Check
  disc for defects" menu entry, which unattended boots never select.

## Files

```
build.py            render + xorriso replay (stdlib only; PyYAML used if present)
smoke-test.sh       qemu + OVMF boot, watched over VNC
templates/          autoinstall.yaml.tmpl, grub.cfg.tmpl
files/              payload copied into the installed system:
                      azb-netinfo  -> /usr/local/bin/azb-netinfo
                      issue.azb    -> appended to /etc/issue
hosts/example.env   per-VM config template (real ones are gitignored)
src/                source Ubuntu ISOs (gitignored)
out/                built ISOs + qemu scratch (gitignored)
```

A minimal host config is four lines — hostname, username, password hash, key.
Everything else defaults.

## Disk

A source ISO is 3.2 GB, every built ISO is another 3.2 GB, and a smoke test's
qemu scratch disk is ~4.4 GB. Left alone that reached 20.6 GB across two repos on
a 250 GB laptop, and nothing warned on the way down. Three things bound it:

- **One source ISO per machine, not per clone.** `build.py` resolves
  `--source` → `AZB_SOURCE_ISO` → `$AZB_ISO_CACHE` → `src/`. The cache comes
  *before* `src/` deliberately: if `src/` won, a fresh clone that downloaded
  locally would keep its own copy and the de-duplication would hold only on
  machines already tidied by hand. `src/` still works as a legacy fallback, and
  both overrides still win when you need a different point release.
- **Smoke-test scratch is removed on exit**, including on the Ctrl-C that
  normally ends a VNC session. Set `AZB_KEEP_SCRATCH=1` to keep it when an
  install failed and the disk image is worth inspecting.
- **Built ISOs are reclaimed when you say so:**

```bash
just bootstrap-iso-clean            # out/ — built ISOs and any qemu scratch
just bootstrap-iso-clean --cache    # ...and the shared source ISO
```

`--cache` is opt-in because that cache is shared: dropping it from one repo
forces a 3.2 GB re-download in all the others. Cleanup is a verb you type rather
than something automatic because building an ISO is a rare, deliberate act —
machinery that prunes siblings during an unrelated build adds a failure mode to a
path exercised too rarely to be trusted.

## Requirements

Builds run on the **laptop**, not the LAN dev box. The ISO has to end up where it
is uploaded from, and that upload is a browser form on the hypervisor's web
panel — building on `safenest` would mean shipping 3 GB there and pulling it
straight back.

```bash
brew install xorriso    # required
brew install qemu       # optional, for the smoke test
```

`src/` and `out/` are gitignored **and** Mutagen-ignored (see `Justfile`,
`sync-start`). Mutagen does not read `.gitignore`, so without those two entries
the source ISO and every ISO built from it would sync to the dev box and fill its
disk. The shared cache needs no entry — it lives outside the repo. Budget ~3 GB
for the source plus ~3 GB per built ISO; built ISOs are disposable once uploaded,
which is what `just bootstrap-iso-clean` is for (see "Disk" above).
