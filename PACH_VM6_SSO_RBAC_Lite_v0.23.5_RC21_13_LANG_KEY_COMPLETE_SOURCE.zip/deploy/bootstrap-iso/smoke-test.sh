#!/usr/bin/env bash
# Boot a built bootstrap ISO locally under qemu + UEFI, viewed over VNC.
#
# The point is the feedback loop. Without this, every typo in autoinstall.yaml
# costs a multi-GB upload over the VPN, a boot, and a VNC session to discover.
# This exercises the same path the hypervisor will: UEFI firmware -> GRUB ->
# unattended install -> reboot, watched over VNC.
#
#   ./smoke-test.sh out/azb-node02.iso [disk_size]
#
# Then point a VNC viewer at 127.0.0.1:5901 (macOS: open vnc://127.0.0.1:5901).
# A pass looks like: GRUB flashes past in ~1s, the installer runs with no
# prompts, and the VM reboots to a login banner showing the static address.
set -euo pipefail

ISO="${1:?usage: smoke-test.sh <iso> [disk_size]}"
DISK_SIZE="${2:-20G}"
[ -f "$ISO" ] || { echo "no such ISO: $ISO" >&2; exit 1; }

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRATCH="$HERE/out/smoke-$(basename "$ISO" .iso)"
VNC_DISPLAY="${VNC_DISPLAY:-1}"

command -v qemu-system-x86_64 >/dev/null || {
    echo "qemu-system-x86_64 not found (apt install qemu-system-x86 / brew install qemu)" >&2
    exit 1
}

# UEFI firmware. Split CODE/VARS pflash is required — the VM must be able to
# write its own boot entries, and a shared VARS file would leak state between
# runs, so we always start from a pristine copy.
CODE=""
VARS_SRC=""
for pair in \
    "/usr/share/OVMF/OVMF_CODE_4M.fd:/usr/share/OVMF/OVMF_VARS_4M.fd" \
    "/usr/share/OVMF/OVMF_CODE.fd:/usr/share/OVMF/OVMF_VARS.fd" \
    "/usr/share/edk2/ovmf/OVMF_CODE.fd:/usr/share/edk2/ovmf/OVMF_VARS.fd" \
    "$(brew --prefix 2>/dev/null || echo /nonexistent)/share/qemu/edk2-x86_64-code.fd:$(brew --prefix 2>/dev/null || echo /nonexistent)/share/qemu/edk2-i386-vars.fd"
do
    c="${pair%%:*}"; v="${pair##*:}"
    if [ -f "$c" ] && [ -f "$v" ]; then CODE="$c"; VARS_SRC="$v"; break; fi
done
[ -n "$CODE" ] || {
    echo "no OVMF/edk2 UEFI firmware found — install it (apt install ovmf)." >&2
    echo "BIOS boot is not a valid substitute: the hypervisor boots UEFI." >&2
    exit 1
}

# Ctrl-C out of the VNC session is the *normal* way a smoke test ends, so cleanup
# has to survive a signal. It is also why qemu is not exec'd below: exec replaces
# this shell, no trap would ever fire, and the multi-GB scratch disk would stay
# resident between runs — present exactly while nobody is looking at it.
cleanup() {
    trap - EXIT INT TERM        # else the EXIT trap re-runs this after INT/TERM
    [ -n "${SCRATCH:-}" ] || return 0
    if [ "${AZB_KEEP_SCRATCH:-0}" = "1" ]; then
        echo "scratch kept for inspection: $SCRATCH" >&2
        return 0
    fi
    rm -rf "$SCRATCH"
}
trap cleanup EXIT INT TERM

mkdir -p "$SCRATCH"
cp -f "$VARS_SRC" "$SCRATCH/uefi-vars.fd"
chmod u+w "$SCRATCH/uefi-vars.fd"
rm -f "$SCRATCH/disk.qcow2"
qemu-img create -f qcow2 "$SCRATCH/disk.qcow2" "$DISK_SIZE" >/dev/null

echo "firmware : $CODE"
echo "scratch  : $SCRATCH"
echo "VNC      : 127.0.0.1:$((5900 + VNC_DISPLAY))   (vnc://127.0.0.1:$((5900 + VNC_DISPLAY)))"
echo "Ctrl-C here to abort. Scratch is removed on exit — AZB_KEEP_SCRATCH=1 keeps it."
echo

qemu-system-x86_64 \
    -machine q35,accel=kvm:hvf:tcg \
    -m 4096 -smp 2 \
    -drive if=pflash,format=raw,unit=0,readonly=on,file="$CODE" \
    -drive if=pflash,format=raw,unit=1,file="$SCRATCH/uefi-vars.fd" \
    -drive file="$SCRATCH/disk.qcow2",if=virtio,format=qcow2 \
    -drive file="$ISO",media=cdrom,readonly=on \
    -boot order=d \
    -netdev user,id=n0 -device virtio-net-pci,netdev=n0 \
    -display none -vnc "127.0.0.1:${VNC_DISPLAY}"
