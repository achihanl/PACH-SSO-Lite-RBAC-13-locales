#!/usr/bin/env bash
# Reclaim bootstrap-ISO build artifacts and report what was recovered.
#
# Building an ISO is a rare, deliberate act — once when standing up a VM, then
# effectively never. So cleanup is a verb the operator types, not machinery that
# fires on a schedule or silently deletes siblings during an unrelated build.
#
#   ./clean.sh              out/ — built ISOs and any leftover qemu scratch
#   ./clean.sh --cache      ...and the shared source ISO in $AZB_ISO_CACHE
#
# --cache is opt-in because that cache is shared by every clone on this machine.
# Dropping it from one repo forces a 3.2 GB re-download in all the others.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="$HERE/out"
ISO_CACHE="${AZB_ISO_CACHE:-$HOME/.cache/azb/iso}"

usage() {
    echo "usage: clean.sh [--cache]"
    echo
    echo "  (no flags)  remove built ISOs and qemu scratch from $OUT"
    echo "  --cache     also remove the shared source ISO from $ISO_CACHE"
}

WITH_CACHE=0
while [ $# -gt 0 ]; do
    case "$1" in
        --cache)   WITH_CACHE=1 ;;
        -h|--help) usage; exit 0 ;;
        *)         echo "unknown option: $1" >&2; usage >&2; exit 2 ;;
    esac
    shift
done

# stat's size flag differs between BSD (macOS) and GNU. Probe once.
if stat -f %z . >/dev/null 2>&1; then
    _size() { stat -f %z "$1"; }
else
    _size() { stat -c %s "$1"; }
fi

# Total bytes of every regular file under the given paths. A missing path
# contributes nothing rather than failing — "already clean" is a success.
_bytes() {
    local total=0 f
    while IFS= read -r f; do
        total=$(( total + $(_size "$f") ))
    done < <(find "$@" -type f 2>/dev/null)
    echo "$total"
}

_human() {
    awk -v b="$1" 'BEGIN {
        split("bytes KB MB GB TB", u, " ")
        i = 1
        while (b >= 1024 && i < 5) { b /= 1024; i++ }
        if (i == 1) printf "%d %s", b, u[i]; else printf "%.2f %s", b, u[i]
    }'
}

freed=0

if [ -d "$OUT" ]; then
    n="$(_bytes "$OUT")"
    # Contents only: build.py writes straight into out/, so removing the
    # directory itself would just add a step to the next build.
    find "$OUT" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
    freed=$(( freed + n ))
    echo "out   : $(_human "$n") reclaimed from $OUT"
else
    echo "out   : nothing to do — $OUT does not exist"
fi

if [ "$WITH_CACHE" = 1 ]; then
    n=0
    if [ -d "$ISO_CACHE" ]; then
        while IFS= read -r f; do
            n=$(( n + $(_size "$f") ))
            rm -f "$f"
        done < <(find "$ISO_CACHE" -maxdepth 1 -type f \
                      -name 'ubuntu-*-live-server-*.iso' 2>/dev/null)
    fi
    freed=$(( freed + n ))
    echo "cache : $(_human "$n") reclaimed from $ISO_CACHE"
    echo "        the next build in ANY repo on this machine re-downloads it"
else
    echo "cache : kept — shared by every clone; pass --cache to drop it"
fi

echo
echo "freed $(_human "$freed")  [$freed bytes]"
