#!/usr/bin/env python3
"""Build a per-VM unattended Ubuntu 24.04 autoinstall ISO.

Why this exists: the hypervisor gives us exactly one input channel — upload an
ISO, attach it as CD/DVD, boot UEFI, watch VNC. So the ISO *is* the API. Every
per-VM fact (hostname, static address, SSH key) has to be baked in before
upload, because the installing VM cannot be assumed to reach anything on our
side of the VPN.

Mechanism: rather than extract 3 GB and try to reconstruct the source ISO's
El Torito boot records by hand, this copies the ISO with
`xorriso -boot_image any replay`, which reproduces the original boot
configuration exactly, and overlays just two files:

    /autoinstall.yaml     rendered from templates/autoinstall.yaml.tmpl
    /boot/grub/grub.cfg   stock file + the block in templates/grub.cfg.tmpl

Nothing else in the image is touched, so the signed shim/GRUB/kernel stay
byte-identical and the result still boots under Secure Boot.

Scope: the ISO's whole job is to produce a box that `deploy/ansible` can SSH
into and converge. It deliberately installs almost nothing — see README.md.

Usage:
    python3 build.py --host azb-node02
    python3 build.py --host azb-node02 --dry-run     # review before a 3 GB build
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from string import Template

HERE = Path(__file__).resolve().parent
TEMPLATES = HERE / "templates"
FILES = HERE / "files"
HOSTS = HERE / "hosts"
OUT = HERE / "out"

# One source ISO per machine, not per clone. Every repo that ships this tooling
# used to glob its own src/, so each acquired its own 3.2 GB copy of the same
# image. find_source_iso() consults this first for that reason — see below.
ISO_CACHE = Path(
    os.environ.get("AZB_ISO_CACHE", Path.home() / ".cache" / "azb" / "iso")
).expanduser()

REQUIRED = ["AZB_HOSTNAME", "AZB_USERNAME", "AZB_PASSWORD_HASH"]

DEFAULTS = {
    # DHCP by default. The address only has to be *predictable* from the
    # control node, not static — a DHCP reservation against the vNIC MAC gets
    # there too, and keeps the NIC name (which varies by hypervisor and cannot
    # be guessed) out of the config entirely. Whatever DHCP hands out, the
    # operator reads back off the VNC console with `azb-netinfo`.
    "AZB_NIC": "auto",
    "AZB_IP_CIDR": "dhcp",
    "AZB_LOCALE": "en_AU.UTF-8",
    "AZB_KEYBOARD": "us",
    "AZB_TIMEZONE": "Australia/Brisbane",
    "AZB_REALNAME": "",
    "AZB_GATEWAY": "",
    "AZB_DNS": "",
    "AZB_DNS_SEARCH": "",
    "AZB_STORAGE_LAYOUT": "lvm",
    "AZB_GROW_ROOT": "true",
    "AZB_PACKAGES": "qemu-guest-agent",
    "AZB_SSH_KEY_FILE": "",
    "AZB_SSH_KEY": "",
    "AZB_SOURCE_ISO": "",
}


class BuildError(Exception):
    pass


# --------------------------------------------------------------------------
# config
# --------------------------------------------------------------------------


def load_env(path: Path) -> dict[str, str]:
    """Parse a KEY=value file. Stdlib only — no PyYAML, no venv to activate."""
    cfg = dict(DEFAULTS)
    for lineno, raw in enumerate(path.read_text().splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise BuildError(f"{path}:{lineno}: expected KEY=value, got {raw!r}")
        key, _, val = line.partition("=")
        val = val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        cfg[key.strip()] = val
    return cfg


def validate(cfg: dict[str, str]) -> None:
    missing = [k for k in REQUIRED if not cfg.get(k)]
    if missing:
        raise BuildError("missing required key(s): " + ", ".join(missing))

    pw = cfg["AZB_PASSWORD_HASH"]
    if not pw.startswith("$") or pw.count("$") < 3:
        raise BuildError(
            "AZB_PASSWORD_HASH is not a crypt hash — it looks like a plaintext "
            "password. Generate one with:  openssl passwd -6"
        )
    if "REPLACE" in pw:
        raise BuildError("AZB_PASSWORD_HASH still holds the example placeholder")

    ip = cfg["AZB_IP_CIDR"]
    if ip != "dhcp":
        if "/" not in ip:
            raise BuildError(f"AZB_IP_CIDR={ip!r} needs a prefix length, e.g. 192.168.11.130/24")
        for key in ("AZB_GATEWAY", "AZB_DNS"):
            if not cfg.get(key):
                raise BuildError(f"{key} is required when AZB_IP_CIDR is a static address")

    if cfg["AZB_STORAGE_LAYOUT"] not in ("lvm", "direct"):
        raise BuildError("AZB_STORAGE_LAYOUT must be 'lvm' or 'direct'")


def collect_ssh_keys(cfg: dict[str, str]) -> list[str]:
    keys: list[str] = []
    for spec in cfg["AZB_SSH_KEY_FILE"].split(","):
        spec = spec.strip()
        if not spec:
            continue
        p = Path(os.path.expanduser(spec))
        if not p.is_file():
            raise BuildError(f"AZB_SSH_KEY_FILE: no such file: {p}")
        keys.extend(ln.strip() for ln in p.read_text().splitlines() if ln.strip())
    inline = cfg["AZB_SSH_KEY"].strip()
    if inline:
        keys.append(inline)
    if not keys:
        raise BuildError(
            "no SSH keys — set AZB_SSH_KEY_FILE (e.g. ~/.ssh/id_rsa.pub) or AZB_SSH_KEY. "
            "The install sets allow-pw:false, so a keyless box is unreachable."
        )
    for k in keys:
        if not k.startswith(("ssh-", "ecdsa-", "sk-")):
            raise BuildError(f"does not look like a public key: {k[:40]!r}")
    return keys


# --------------------------------------------------------------------------
# rendering
# --------------------------------------------------------------------------


def render_network(cfg: dict[str, str]) -> str:
    """Emit the `ethernets:` mapping body at 6-space indent."""
    ind = " " * 6
    nic = cfg["AZB_NIC"]
    out = []

    if nic == "auto":
        # Escape hatch for the very first boot on unknown virtual hardware.
        # Applies to every en* interface — pin the real name once you know it.
        out += [f"{ind}primary:", f"{ind}  match:", f'{ind}    name: "en*"']
    else:
        out.append(f"{ind}{nic}:")

    if cfg["AZB_IP_CIDR"] == "dhcp":
        out.append(f"{ind}  dhcp4: true")
        return "\n".join(out)

    dns = ", ".join(d.strip() for d in cfg["AZB_DNS"].split(",") if d.strip())
    search = ", ".join(d.strip() for d in cfg["AZB_DNS_SEARCH"].split(",") if d.strip())
    out += [
        f"{ind}  dhcp4: false",
        f"{ind}  addresses:",
        f"{ind}    - {cfg['AZB_IP_CIDR']}",
        f"{ind}  routes:",
        f"{ind}    - to: default",
        f"{ind}      via: {cfg['AZB_GATEWAY']}",
        f"{ind}  nameservers:",
        f"{ind}    addresses: [{dns}]",
        f"{ind}    search: [{search}]",
    ]
    return "\n".join(out)


def render_packages(cfg: dict[str, str]) -> str:
    pkgs = [p.strip() for p in cfg["AZB_PACKAGES"].split(",") if p.strip()]
    if not pkgs:
        return "  packages: []"
    lines = ["  packages:"] + [f"    - {p}" for p in pkgs]
    return "\n".join(lines)


def render_late_commands(cfg: dict[str, str]) -> str:
    """late-commands run in the *installer* environment, with the new system at
    /target. `curtin in-target --` is what runs a command inside the install.

    Two traps encoded here:
      - /cdrom is NOT visible inside the in-target chroot. Anything shipped on
        the ISO must be copied to /target first, with a plain (non-in-target)
        command.
      - every shell pipeline goes through `bash -c`. A bare pipeline here is
        the classic "installer hangs forever at Executing late commands".
    """
    cmds = [
        "curtin in-target -- bash -c 'systemctl enable qemu-guest-agent || true'",
        # files/ is mapped to /azb on the ISO. These two are plain commands, NOT
        # in-target: /cdrom does not exist inside the chroot, so the copy has to
        # happen from the installer environment writing into /target.
        "bash -c 'install -m 0755 /cdrom/azb/azb-netinfo /target/usr/local/bin/azb-netinfo'",
        # Puts the DHCP-assigned address on the pre-login VNC console via
        # agetty's \4 escape, so it can be read without logging in at all.
        "bash -c 'cat /cdrom/azb/issue.azb >> /target/etc/issue'",
        # The installer leaves `deb cdrom:` at the top of the target's
        # sources.list. Once the ISO is detached — the normal end state — apt
        # resolves every package to a file:/cdrom path that no longer exists
        # and fails there, without ever falling through to the network mirror.
        # `apt install openssh-server` on a box in that state dies with
        # "File not found - /cdrom/pool/main/o/openssh/...".
        "curtin in-target -- bash -c 'sed -i -e \"/^deb cdrom:/s/^/#/\" /etc/apt/sources.list || true'",
        # Records that late-commands ran at all, and whether the box came up
        # with a working sshd. "Did autoinstall apply?" is otherwise inferred
        # from the absence of things, which is a slow way to find out.
        #
        # Both units are recorded because since 24.04 sshd is socket-activated:
        # ssh.service is legitimately `disabled` while ssh.socket is `enabled`,
        # on a box that accepts SSH perfectly well. Logging only ssh.service
        # makes a healthy install look broken — the exact wrong answer from the
        # one file that exists to end that ambiguity in a single `cat`.
        "curtin in-target -- bash -c 'echo azb-autoinstall=applied > /etc/azb-bootstrap; "
        "echo ssh.service=$(systemctl is-enabled ssh 2>&1) >> /etc/azb-bootstrap; "
        "echo ssh.socket=$(systemctl is-enabled ssh.socket 2>&1) >> /etc/azb-bootstrap || true'",
    ]
    if cfg["AZB_STORAGE_LAYOUT"] == "lvm" and cfg["AZB_GROW_ROOT"].lower() == "true":
        # Ubuntu's lvm layout caps the root LV well below the disk size and
        # leaves the rest unallocated in the VG — a 100 GB root on a 500 GB
        # disk is the usual surprise. `|| true` because lvextend exits non-zero
        # when the LV is already at 100%FREE, which would fail the install.
        cmds += [
            "curtin in-target -- bash -c 'lvextend -l +100%FREE /dev/ubuntu-vg/ubuntu-lv || true'",
            "curtin in-target -- bash -c 'resize2fs /dev/ubuntu-vg/ubuntu-lv || true'",
        ]
    lines = ["  late-commands:"] + [f"    - {c}" for c in cmds]
    return "\n".join(lines)


def render(cfg: dict[str, str]) -> tuple[str, str]:
    keys = collect_ssh_keys(cfg)
    subs = dict(cfg)
    subs["AZB_REALNAME"] = cfg["AZB_REALNAME"] or cfg["AZB_USERNAME"]
    subs["AZB_SSH_KEYS_BLOCK"] = "\n".join(f'      - "{k}"' for k in keys)
    subs["AZB_NETWORK_BLOCK"] = render_network(cfg)
    subs["AZB_PACKAGES_BLOCK"] = render_packages(cfg)
    subs["AZB_LATE_COMMANDS_BLOCK"] = render_late_commands(cfg)

    autoinstall = Template((TEMPLATES / "autoinstall.yaml.tmpl").read_text()).substitute(subs)
    grub_block = Template((TEMPLATES / "grub.cfg.tmpl").read_text()).substitute(subs)
    return autoinstall, grub_block


# Matches the kernel line of any entry that boots the live installer, stock or
# ours: `linux /casper/vmlinuz ---` and the HWE variant `/casper/hwe-vmlinuz`.
_CASPER_LINUX = re.compile(r"^(?P<pre>[ \t]*linux[ \t]+/casper/\S*vmlinuz)(?P<args>[^\n]*)$", re.M)


def harden_stock_grub(stock: str) -> tuple[str, int]:
    """Put `autoinstall` on *every* installer entry, not just the one we append.

    Appending our own entry and pointing `set default` at it is the intended
    path, but it only holds if nothing selects an entry before the timeout
    expires. A human watching VNC who presses Enter on the stock "Try or
    Install Ubuntu Server" highlight gets a fully interactive install — and the
    resulting box is indistinguishable from one where the ISO was never read:
    no late-commands, so no sshd, no azb-netinfo, no /etc/issue banner.

    That is exactly the state azb-ad came up in, and `set default` alone cannot
    prevent it. Making every casper entry unattended removes the failure class
    rather than relying on the default sticking, and costs nothing: the stock
    entries and ours then do the same thing.
    """
    count = 0

    def sub(m: re.Match[str]) -> str:
        nonlocal count
        if "autoinstall" in m.group("args"):
            return m.group(0)
        count += 1
        return f"{m.group('pre')} autoinstall{m.group('args')}"

    return _CASPER_LINUX.sub(sub, stock), count


def check_yaml(text: str, allow_skip: bool = False) -> None:
    """Parse the rendered autoinstall. A typo costs a 3 GB upload and a VNC session.

    This used to degrade to a printed note when PyYAML was absent — which, on a
    build host that never had PyYAML, meant the check silently never ran while
    the README went on advertising it. A verification step that is off by
    default on the only machine that builds ISOs is worse than no step at all,
    so a missing parser is now an error unless explicitly waived.
    """
    try:
        import yaml  # noqa: PLC0415
    except ImportError:
        if allow_skip:
            print("  WARNING: PyYAML absent and --skip-yaml-check given — "
                  "autoinstall.yaml is UNVALIDATED")
            return
        raise BuildError(
            "PyYAML is not installed, so the rendered autoinstall.yaml cannot be "
            "checked. Subiquity falls back to an INTERACTIVE install when it "
            "cannot parse the file, which looks exactly like the ISO never being "
            "read.\n"
            "  fix:      pip3 install pyyaml\n"
            "            if pip refuses with 'Could not find an activated virtualenv',\n"
            "            pip is configured with require-virtualenv — build a venv and\n"
            "            run this script with it:\n"
            "              python3 -m venv ~/.venvs/azb-tools\n"
            "              ~/.venvs/azb-tools/bin/pip install -r tools/arch_guard_requirements.txt\n"
            "              ~/.venvs/azb-tools/bin/python deploy/bootstrap-iso/build.py ...\n"
            "  override: --skip-yaml-check"
        ) from None
    try:
        doc = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise BuildError(f"rendered autoinstall.yaml is not valid YAML:\n{exc}") from exc
    if not isinstance(doc, dict) or "autoinstall" not in doc:
        raise BuildError("rendered autoinstall.yaml has no top-level `autoinstall:` key")


# --------------------------------------------------------------------------
# iso
# --------------------------------------------------------------------------


def find_source_iso(cfg: dict[str, str], override: str | None) -> Path:
    if override:
        p = Path(override).expanduser()
    elif cfg["AZB_SOURCE_ISO"]:
        p = Path(os.path.expanduser(cfg["AZB_SOURCE_ISO"]))
        if not p.is_absolute():
            p = HERE / p
    else:
        # Cache before src/. If src/ won, a fresh clone that downloaded locally
        # would keep its own copy and the de-duplication would hold only on
        # machines already tidied by hand. src/ stays as a legacy fallback, and
        # --source / AZB_SOURCE_ISO still override both.
        pattern = "ubuntu-*-live-server-*.iso"
        found = sorted(ISO_CACHE.glob(pattern)) or sorted((HERE / "src").glob(pattern))
        if not found:
            raise BuildError(
                "no source ISO. Run deploy/bootstrap-iso/run.sh <host>, which "
                f"downloads and verifies one into\n  {ISO_CACHE}\n"
                "or set AZB_SOURCE_ISO / --source. Manual download (check "
                "SHA256SUMS for the current point release):\n"
                "  https://releases.ubuntu.com/24.04/ubuntu-24.04.4-live-server-amd64.iso"
            )
        p = found[-1]
    if not p.is_file():
        raise BuildError(f"source ISO not found: {p}")
    return p


def _el_torito(iso: Path) -> str:
    """An image's boot configuration, normalised for comparison.

    Ubuntu ships the EFI boot image as an *appended GPT partition* rather than a
    file inside the filesystem, and the report records where that partition
    starts in absolute terms. Adding /autoinstall.yaml and /azb/ makes the image
    larger, so the partition necessarily lands at a different offset — that is
    the mechanism working, not a fault. Its *size* must still match, as must
    every structural flag and both partition-type GUIDs, so only the offsets and
    the image's own path are normalised away.
    """
    res = subprocess.run(
        ["xorriso", "-indev", str(iso), "-report_el_torito", "as_mkisofs"],
        check=True, capture_output=True, text=True,
    )
    text = " ".join(
        ln.strip() for ln in res.stdout.splitlines()
        if ln.strip() and "modification-date" not in ln  # stamped per-image
    )
    text = re.sub(r"'[^']*\.iso'", "'<IMAGE>'", text)          # -interval path operand
    text = re.sub(r":/[^:']*\.iso", ":<IMAGE>", text)          # bare path operand
    text = re.sub(r"\d+d-\d+d", "<RANGE>d", text)              # appended-partition byte range
    text = re.sub(r"start_\d+s_size_", "start_<LBA>s_size_", text)  # keeps size_NNNNd
    return text


def verify_iso(source: Path, out: Path, autoinstall: str) -> None:
    """Read the built ISO back and prove it is what we meant to build.

    Cheap, and the only automated check available without qemu — a laptop build
    host has no OVMF. It catches the ways ISO surgery goes wrong (boot record
    dropped, volume ID renamed, a payload that silently did not get mapped in);
    it cannot catch subiquity rejecting the autoinstall semantically. That is
    what `just bootstrap-iso-test` is for, where qemu is available.
    """
    src_boot, out_boot = _el_torito(source), _el_torito(out)
    if src_boot != out_boot:
        raise BuildError(
            "boot configuration differs from the source ISO — it would likely not "
            "boot under UEFI.\n  source: " + src_boot + "\n  built : " + out_boot
        )

    with tempfile.TemporaryDirectory(prefix="azb-verify-") as td:
        tmp = Path(td)
        subprocess.run(
            ["xorriso", "-osirrox", "on", "-indev", str(out),
             "-extract", "/autoinstall.yaml", str(tmp / "autoinstall.yaml"),
             "-extract", "/boot/grub/grub.cfg", str(tmp / "grub.cfg"),
             "-extract", "/azb/azb-netinfo", str(tmp / "azb-netinfo")],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        for name in ("autoinstall.yaml", "grub.cfg", "azb-netinfo"):
            if not (tmp / name).is_file():
                raise BuildError(f"{name} is missing from the built ISO")

        if (tmp / "autoinstall.yaml").read_text() != autoinstall:
            raise BuildError("/autoinstall.yaml in the ISO differs from what was rendered")
        if (tmp / "azb-netinfo").read_bytes() != (FILES / "azb-netinfo").read_bytes():
            raise BuildError("/azb/azb-netinfo in the ISO differs from files/azb-netinfo")

        grub = (tmp / "grub.cfg").read_text()
        # Both halves matter: the kernel argument is what makes the install
        # unattended, and the default selection is what stops an unattended boot
        # from timing out into the firmware settings entry.
        if "autoinstall" not in grub:
            raise BuildError("grub.cfg carries no `autoinstall` kernel argument")
        if 'set default="azb-autoinstall"' not in grub:
            raise BuildError("grub.cfg does not default to the azb-autoinstall entry")
        # The check the previous version was missing. Verifying only that *an*
        # entry is unattended still passes an ISO whose stock entries boot the
        # installer interactively — one keystroke on the VNC console and the
        # install silently becomes a manual one.
        interactive = [
            m.group(0).strip()
            for m in _CASPER_LINUX.finditer(grub)
            if "autoinstall" not in m.group("args")
        ]
        if interactive:
            raise BuildError(
                "grub.cfg still has installer entries that boot interactively — a "
                "keystroke on the VNC console would produce a hand-installed box:\n  "
                + "\n  ".join(interactive)
            )

    print("  verified: boot record matches source, payload intact, every installer "
          "entry unattended")


def build_iso(source: Path, out: Path, autoinstall: str, grub_block: str) -> None:
    if not shutil.which("xorriso"):
        raise BuildError("xorriso not found (apt install xorriso / brew install xorriso)")
    for name in ("azb-netinfo", "issue.azb"):
        if not (FILES / name).is_file():
            raise BuildError(f"missing payload file: {FILES / name}")

    with tempfile.TemporaryDirectory(prefix="azb-iso-") as td:
        tmp = Path(td)

        # Pull the stock grub.cfg out of the source and append our block, so we
        # inherit whatever Canonical shipped instead of hand-writing a config.
        subprocess.run(
            ["xorriso", "-osirrox", "on", "-indev", str(source),
             "-extract", "/boot/grub/grub.cfg", str(tmp / "grub.cfg")],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        if not (tmp / "grub.cfg").is_file():
            raise BuildError(f"{source} has no /boot/grub/grub.cfg — is it an Ubuntu live-server ISO?")
        (tmp / "grub.cfg").chmod(0o644)  # xorriso extracts read-only
        stock = (tmp / "grub.cfg").read_text()
        stock, hardened = harden_stock_grub(stock)
        if hardened:
            print(f"  grub: added `autoinstall` to {hardened} stock installer entr"
                  f"{'y' if hardened == 1 else 'ies'}")
        (tmp / "grub.cfg").write_text(stock + grub_block)
        (tmp / "autoinstall.yaml").write_text(autoinstall)

        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists():
            out.unlink()

        # `-boot_image any replay` reproduces the source's El Torito records
        # verbatim. No -volid: casper locates the medium by its volume label,
        # and renaming it is a classic way to get an ISO that will not boot.
        # files/ rides along at /azb; late-commands copy it into /target.
        subprocess.run(
            ["xorriso", "-indev", str(source), "-outdev", str(out),
             "-boot_image", "any", "replay",
             "-map", str(tmp / "grub.cfg"), "/boot/grub/grub.cfg",
             "-map", str(tmp / "autoinstall.yaml"), "/autoinstall.yaml",
             "-map", str(FILES), "/azb"],
            check=True,
        )


# --------------------------------------------------------------------------


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--host", required=True, help="name of a file in hosts/ (without .env)")
    ap.add_argument("--source", help="source Ubuntu live-server ISO (overrides AZB_SOURCE_ISO)")
    ap.add_argument("--out", help="output ISO path (default out/<host>.iso)")
    ap.add_argument("--dry-run", action="store_true", help="print rendered files, build nothing")
    ap.add_argument("--verify-only", action="store_true",
                    help="re-verify an already-built ISO without rebuilding it")
    ap.add_argument("--skip-yaml-check", action="store_true",
                    help="build even though PyYAML is missing (autoinstall.yaml unvalidated)")
    args = ap.parse_args()

    host_file = HOSTS / f"{args.host}.env"
    if not host_file.is_file():
        existing = sorted(p.stem for p in HOSTS.glob("*.env"))
        print(f"error: no host config at {host_file}", file=sys.stderr)
        print(f"       available: {', '.join(existing) or '(none)'}", file=sys.stderr)
        return 2

    try:
        cfg = load_env(host_file)
        validate(cfg)
        autoinstall, grub_block = render(cfg)
        check_yaml(autoinstall, allow_skip=args.skip_yaml_check)

        if args.dry_run:
            print(f"===== /autoinstall.yaml ({host_file.name}) =====")
            print(autoinstall)
            print("===== appended to /boot/grub/grub.cfg =====")
            print(grub_block)
            return 0

        source = find_source_iso(cfg, args.source)
        out = Path(args.out).expanduser() if args.out else OUT / f"{args.host}.iso"

        if args.verify_only:
            if not out.is_file():
                raise BuildError(f"nothing to verify: {out} does not exist")
            print(f"  verifying {out}")
            verify_iso(source, out, autoinstall)
            return 0

        print(f"  source : {source}")
        print(f"  target : {cfg['AZB_HOSTNAME']} @ {cfg['AZB_IP_CIDR']} ({cfg['AZB_NIC']})")
        print(f"  output : {out}")
        build_iso(source, out, autoinstall, grub_block)
        verify_iso(source, out, autoinstall)
        size_gb = out.stat().st_size / 1024**3
        print(f"\n  built {out} ({size_gb:.2f} GB)")
        print("\nNext:")
        print(f"  1. just bootstrap-iso-test {args.host}      # boot it under qemu/OVMF first")
        print("  2. upload, attach as CD/DVD, boot UEFI, watch VNC (~4-8 min)")
        if cfg["AZB_IP_CIDR"] == "dhcp":
            print("  3. read the DHCP address off the VNC login banner, or log in and")
            print("     run `azb-netinfo` for the ssh + hosts.ini lines")
        else:
            print(f"  3. ssh {cfg['AZB_USERNAME']}@{cfg['AZB_IP_CIDR'].split('/')[0]}")
        print("  4. add the host to deploy/ansible/inventories/*/hosts.ini and converge")
        return 0

    except BuildError as exc:
        sys.stdout.flush()  # else the piped-stdout progress lines land after this
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except subprocess.CalledProcessError as exc:
        print(f"error: {exc.cmd[0]} failed with exit {exc.returncode}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
