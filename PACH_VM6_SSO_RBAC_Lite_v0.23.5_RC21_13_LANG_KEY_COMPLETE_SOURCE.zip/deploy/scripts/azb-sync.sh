#!/usr/bin/env bash
# =============================================================================
# azb-sync — keep this laptop (alpha) and the safenest test worker (beta) in
# sync: file content via Mutagen, git HEAD via an explicit realignment.
#
# Why this exists: the Mutagen session runs with --ignore-vcs, so it mirrors the
# worktree but never .git. Beta's HEAD therefore stays wherever it was while its
# files march forward, and `git status` on beta fills with phantom modifications
# measured against a stale commit. That drift reached 27 commits / 114 paths
# before anyone noticed, because nothing was watching for it.
#
# `align` is the fix and the git hooks installed by `install-hooks` fire it
# whenever alpha's HEAD moves. Run `azb-sync help` for usage.
# =============================================================================
set -uo pipefail   # no -e: hooks must never abort a commit on a transient error

export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin"

# Resolve symlinks so paths are right when invoked via ~/.local/bin/azb-sync.
_src="${BASH_SOURCE[0]}"
while [ -L "$_src" ]; do
  _dir="$(cd -P "$(dirname "$_src")" && pwd)"
  _src="$(readlink "$_src")"; case "$_src" in /*) ;; *) _src="$_dir/$_src";; esac
done
SCRIPT_DIR="$(cd -P "$(dirname "$_src")" && pwd)"   # deploy/scripts
SCRIPT_SELF="$SCRIPT_DIR/$(basename "$_src")"       # real path, for hook bodies
ALPHA="$(cd "$SCRIPT_DIR/../.." && pwd)"            # repo root
unset _src _dir

# --- config ------------------------------------------------------------------
SESSION="azb"
BETA_HOST="safenest"
BETA_PATH="/home/keith/_WORKSPACES_/azb-azblink-directory-and-identity-stack"
# Two non-branch refs (non-branch side-steps receive.denyCurrentBranch on a
# checked-out repo). STAGE is object transport and moves on every attempt; REF
# is the ledger of where align last successfully parked beta, and must move only
# after the reset lands — a refused attempt that advanced it would erase the
# very evidence the safety check reads.
SYNC_REF="refs/azb-sync/alpha"
SYNC_STAGE="refs/azb-sync/incoming"
LOGFILE="$HOME/Library/Logs/azb-sync.log"
LOCKDIR="${TMPDIR:-/tmp}/azb-sync.lock"
SSH_OPTS=(-A -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=accept-new)
HOOKS=(post-commit post-checkout post-merge post-rewrite)

# The canonical ignore list. `setup` is the only writer of the session config,
# so this array is the single source of truth for what never crosses the wire.
IGNORES=(
  node_modules dist .venv __pycache__ .pytest_cache
  .dead-code .tanstack playwright-report test-results .DS_Store
  # Tool caches: every host writes its own, at identical paths, with different
  # content. Under one-way-safe that is one conflict per file — 1722 of them
  # from .mypy_cache alone. The others had not fired yet only because they
  # existed on one side.
  .mypy_cache .ruff_cache .coverage /.serena/cache
  /src/frontend/src/routeTree.gen.ts /src/frontend/src/.tsr-tmp
  /deploy/dev/.env /.claude/settings.local.json
)

EX_OK=0; EX_USAGE=2; EX_DRIFT=3; EX_UNREACHABLE=4

mkdir -p "$(dirname "$LOGFILE")"
QUIET=0
log(){ printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOGFILE"; }
say(){ [ "$QUIET" -eq 1 ] || printf '%s\n' "$*"; log "$*"; }
err(){ printf '%s\n' "$*" >&2; log "ERROR $*"; }

# Stderr goes to the log, not /dev/null. A git failure on beta prints nothing to
# stdout and can still exit 0 (`rev-parse` on an ambiguous ref does exactly
# that), so a discarded stderr left callers with an empty string and no way to
# tell a broken repo from a broken network — which is how a stray refs/heads/HEAD
# read as "beta unreachable" for eleven commits. The status returned is ssh's:
# 255 is transport failure, anything else came from the remote side.
beta_git(){ ssh "${SSH_OPTS[@]}" "$BETA_HOST" "cd '$BETA_PATH' && git $*" 2>>"$LOGFILE"; }

# --- align -------------------------------------------------------------------
# Moves beta's branch ref + index to alpha's HEAD without touching beta's files.
# The worktree is already alpha's content (Mutagen put it there); only git's
# idea of "where am I" is stale, so a --mixed reset is the whole repair.
# Serialized wrapper. Some git operations fire two of our hooks (`commit --amend`
# triggers post-commit AND post-rewrite), which raced two resets onto beta's
# index. mkdir is the atomic test-and-set; a stale lock clears after 10 minutes.
cmd_align(){
  if [ -d "$LOCKDIR" ] && [ -n "$(find "$LOCKDIR" -maxdepth 0 -mmin +10 2>/dev/null)" ]; then
    rmdir "$LOCKDIR" 2>/dev/null
  fi
  if ! mkdir "$LOCKDIR" 2>/dev/null; then
    log "align: another align is running — skipped"
    return "$EX_OK"
  fi
  _align "$@"; local rc=$?
  rmdir "$LOCKDIR" 2>/dev/null
  return "$rc"
}

_align(){
  local force=0 arg
  for arg in "$@"; do
    case "$arg" in
      --force) force=1 ;;
      --quiet) QUIET=1 ;;
      *) err "align: unknown option '$arg'"; return "$EX_USAGE" ;;
    esac
  done

  # symbolic-ref, not `rev-parse --abbrev-ref`: the latter answers the literal
  # string "HEAD" on a detached alpha and exits 0, and align used to carry that
  # straight into `symbolic-ref HEAD refs/heads/HEAD` on beta. That created a
  # branch actually named HEAD, after which every `rev-parse HEAD` on beta was
  # ambiguous — and align, reading the resulting empty string as an unreachable
  # host, could never repair the ref that was blocking it. symbolic-ref fails
  # cleanly when detached, so the state is refused here instead of exported.
  local sha branch
  sha="$(git -C "$ALPHA" rev-parse HEAD 2>/dev/null)"
  branch="$(git -C "$ALPHA" symbolic-ref --short HEAD 2>/dev/null)"
  [ -n "$sha" ] || { err "align: cannot read alpha HEAD"; return "$EX_USAGE"; }
  if [ -z "$branch" ]; then
    err "align: alpha is detached at ${sha:0:7} — no branch for beta to follow."
    err "       Check out a branch, then re-run 'azb-sync align'."
    return "$EX_USAGE"
  fi

  # Push content first so beta's files match the commit we are about to pin it
  # to. Best-effort: a busy session is not a reason to skip the git repair.
  mutagen sync flush "$SESSION" >/dev/null 2>&1 || log "align: flush failed (session down?)"

  local beta_branch beta_rc
  beta_branch="$(beta_git symbolic-ref --short HEAD)"; beta_rc=$?
  if [ "$beta_rc" -eq 255 ]; then
    err "align: $BETA_HOST unreachable — skipped"
    return "$EX_UNREACHABLE"
  fi
  # Reached the host but could not name its branch: beta is detached, or the
  # repo path is wrong. Distinct from unreachable, and never again reported as
  # such — the real error is in the log now.
  if [ -z "$beta_branch" ]; then
    err "align: reached $BETA_HOST but could not read its branch (exit $beta_rc)."
    err "       Beta is detached or $BETA_PATH is not a repo — see $LOGFILE."
    return "$EX_DRIFT"
  fi

  # Legacy repair for hosts a pre-fix align already pinned to refs/heads/HEAD.
  # Only that one ref is touched; align is its sole writer and the commit it
  # holds came from alpha, so dropping it discards nothing beta authored. Left
  # alone it keeps every rev-parse there ambiguous.
  if [ "$beta_branch" = "heads/HEAD" ]; then
    say "align: clearing stray refs/heads/HEAD on $BETA_HOST (pre-fix artifact)"
    ssh "${SSH_OPTS[@]}" "$BETA_HOST" "cd '$BETA_PATH' \
      && git symbolic-ref HEAD 'refs/heads/$branch' \
      && git update-ref -d refs/heads/HEAD" >/dev/null 2>>"$LOGFILE"
    beta_branch="$branch"
  fi

  # Read these BEFORE the push, which overwrites SYNC_REF. `last_aligned` is
  # where the previous align parked beta; `beta_tip` is where its copy of
  # alpha's branch sits now. Both may be empty on a first run.
  local last_aligned beta_tip
  last_aligned="$(beta_git rev-parse --verify --quiet "$SYNC_REF")"
  beta_tip="$(beta_git rev-parse --verify --quiet "refs/heads/$branch")"

  # Transfer the objects ourselves. post-commit fires BEFORE push, so alpha's
  # HEAD is routinely absent from origin — beta could never fetch it. Pushing to
  # a non-branch ref avoids receive.denyCurrentBranch on a checked-out repo.
  if ! git -C "$ALPHA" push --quiet "$BETA_HOST:$BETA_PATH" "+$sha:$SYNC_STAGE" 2>>"$LOGFILE"; then
    err "align: could not push objects to $BETA_HOST — skipped"
    return "$EX_UNREACHABLE"
  fi

  # Following alpha onto a different branch is the normal case and is safe: we
  # move only the branch alpha is on, so beta's other branches (and their
  # unpushed commits) are never touched. The one case needing consent is a
  # same-name branch carrying commits beta made itself.
  #
  # Ancestry alone cannot detect that: `commit --amend` and rebase both leave
  # beta's tip off the new history while representing no beta-side work at all,
  # and post-rewrite fires on exactly those. So trust the ledger instead — if
  # beta's tip is still where the last align parked it, beta has authored
  # nothing, however the two histories now relate.
  if [ -n "$beta_tip" ] && [ "$beta_tip" != "$last_aligned" ]; then
    if ! beta_git merge-base --is-ancestor "$beta_tip" "$sha" >/dev/null; then
      if [ "$force" -eq 0 ]; then
        err "align: beta's '$branch' (${beta_tip:0:7}) holds commits alpha's ${sha:0:7} lacks,"
        err "       and it is not where the last align left it — refusing."
        err "       Inspect on $BETA_HOST, or re-run with --force to discard it."
        return "$EX_DRIFT"
      fi
      say "align: --force: discarding beta's divergent '$branch' (recoverable via reflog)"
    fi
  fi
  [ "$beta_branch" != "$branch" ] && say "align: beta HEAD $beta_branch -> $branch"

  # symbolic-ref moves HEAD between branches without a checkout, so beta's files
  # are never rewritten; --mixed then moves that branch and refreshes the index.
  # The ledger update is chained after the reset so it records only what landed.
  ssh "${SSH_OPTS[@]}" "$BETA_HOST" "cd '$BETA_PATH' \
    && git symbolic-ref HEAD 'refs/heads/$branch' \
    && git reset --mixed --quiet '$sha' \
    && git update-ref '$SYNC_REF' '$sha' \
    && git fetch --quiet origin 2>/dev/null; true" >/dev/null 2>&1

  local now; now="$(beta_git rev-parse HEAD)"
  if [ "$now" = "$sha" ]; then
    say "align: beta $BETA_HOST -> $branch @ ${sha:0:7}"
    return "$EX_OK"
  fi
  err "align: beta HEAD is ${now:0:7}, expected ${sha:0:7}"
  return "$EX_DRIFT"
}

# --- status ------------------------------------------------------------------
cmd_status(){
  local tmpl='{{range .}}{{len .Conflicts}} {{.ExcludedConflicts}} {{.Status}}{{end}}'
  local raw conflicts excluded state total
  raw="$(mutagen sync list "$SESSION" --template "$tmpl" 2>/dev/null)"
  read -r conflicts excluded state <<< "${raw:-0 0 MISSING}"
  # Non-numeric survives an unexpected template result; the arithmetic below
  # would otherwise abort status precisely when the session is broken.
  case "$conflicts$excluded" in (*[!0-9]*|"") conflicts=0; excluded=0;; esac
  total=$(( conflicts + excluded ))

  local a_sha a_branch b_sha b_branch
  a_sha="$(git -C "$ALPHA" rev-parse HEAD 2>/dev/null)"
  a_branch="$(git -C "$ALPHA" symbolic-ref --short HEAD 2>/dev/null)"
  b_sha="$(beta_git rev-parse HEAD)"
  b_branch="$(beta_git symbolic-ref --short HEAD)"

  echo "session:  $SESSION ($state)"
  echo "alpha:    ${a_branch:-DETACHED} @ ${a_sha:0:7}  $ALPHA"
  if [ -z "$b_sha" ]; then
    echo "beta:     UNREACHABLE  $BETA_HOST:$BETA_PATH"
  else
    echo "beta:     ${b_branch:-DETACHED} @ ${b_sha:0:7}  $BETA_HOST:$BETA_PATH"
  fi
  # Mutagen's API returns at most 10 conflicts; the rest arrive as a separate
  # count. Report the sum — the truncated 10 is what Raycast shows, and it is
  # why 1722 conflicts read as a minor annoyance for weeks.
  echo "conflicts: $total"

  local rc=0
  if [ -n "$b_sha" ] && [ "$a_sha" != "$b_sha" ]; then
    local behind; behind="$(git -C "$ALPHA" rev-list --count "$b_sha..$a_sha" 2>/dev/null)"
    echo "DRIFT:    beta is ${behind:-?} commit(s) behind alpha — run 'azb-sync align'"
    rc="$EX_DRIFT"
  fi
  [ -n "$b_sha" ] && [ "$a_branch" != "$b_branch" ] && {
    echo "DRIFT:    branch mismatch — run 'azb-sync align'"; rc="$EX_DRIFT"; }
  [ -z "$a_branch" ] && {
    echo "DRIFT:    alpha is detached — align refuses until you check out a branch"; rc="$EX_DRIFT"; }
  [ "$b_branch" = "heads/HEAD" ] && {
    echo "DRIFT:    beta sits on the stray refs/heads/HEAD — 'azb-sync align' clears it"; rc="$EX_DRIFT"; }
  [ "$total" -gt 0 ] && {
    echo "DRIFT:    unresolved sync conflicts — inspect with 'mutagen sync list -l $SESSION'"; rc="$EX_DRIFT"; }
  [ "$state" = "MISSING" ] && {
    echo "DRIFT:    no Mutagen session '$SESSION' — run 'azb-sync setup'"; rc="$EX_DRIFT"; }
  return "$rc"
}

# --- setup -------------------------------------------------------------------
cmd_setup(){
  local args=() i
  for i in "${IGNORES[@]}"; do args+=(-i "$i"); done
  say "setup: recreating session '$SESSION' with ${#IGNORES[@]} ignore rules"
  mutagen sync terminate "$SESSION" >/dev/null 2>&1
  mutagen sync create \
    --name="$SESSION" --label=project=azb-directory \
    --sync-mode=one-way-safe --ignore-vcs \
    "${args[@]}" "$ALPHA" "$BETA_HOST:$BETA_PATH" || { err "setup: create failed"; return 1; }
  mutagen sync flush "$SESSION" >/dev/null 2>&1
  say "setup: done"
}

# --- install-hooks -----------------------------------------------------------
cmd_install_hooks(){
  local dir h
  dir="$(git -C "$ALPHA" rev-parse --git-path hooks 2>/dev/null)"
  case "$dir" in /*) ;; *) dir="$ALPHA/$dir";; esac
  mkdir -p "$dir"
  for h in "${HOOKS[@]}"; do
    local p="$dir/$h"
    # Never silently eat someone else's hook (pre-commit installs some of these).
    if [ -e "$p" ] && ! grep -q 'azb-sync' "$p" 2>/dev/null; then
      mv "$p" "$p.pre-azb-sync"
      say "install-hooks: preserved existing $h -> $h.pre-azb-sync (chained)"
    fi
    {
      echo '#!/usr/bin/env bash'
      echo '# installed by azb-sync install-hooks — realigns safenest git HEAD'
      echo "[ -x \"\$0.pre-azb-sync\" ] && \"\$0.pre-azb-sync\" \"\$@\""
      # Absolute path, not PATH: hooks inherit a trimmed environment and
      # ~/.local/bin is routinely absent. nohup, not setsid: macOS has no setsid,
      # and the failure was invisible because the hook redirects to /dev/null.
      # Backgrounded + redirected so a commit never waits on ssh; `exit 0` so a
      # failed realignment can never fail the commit itself.
      echo "[ -x '$SCRIPT_SELF' ] && nohup '$SCRIPT_SELF' align --quiet >/dev/null 2>&1 &"
      echo 'exit 0'
    } > "$p"
    chmod +x "$p"
  done
  say "install-hooks: installed ${HOOKS[*]} in $dir"
}

cmd_help(){
  cat <<EOF
azb-sync — keep the laptop (alpha) and the safenest test worker (beta) in sync.

SYNOPSIS
  azb-sync <command> [options]

DESCRIPTION
  Mutagen mirrors the worktree but runs --ignore-vcs, so beta's git HEAD never
  advances on its own. This tool repairs that, and owns the Mutagen ignore list
  that keeps per-host tool caches (.mypy_cache, .ruff_cache, ...) off the wire.

COMMANDS
  status                    Session state, both HEADs, conflict total, drift.
  align [--force]           Flush Mutagen, then move beta's branch + index to
                            alpha's HEAD. Never touches beta's files, and never
                            touches branches alpha is not on. Refuses when alpha
                            is detached (no branch to follow), and when beta's
                            same-name branch has diverged; --force wins on the
                            latter.
  setup                     Recreate the Mutagen session with the canonical
                            ignore list. Idempotent; safe to re-run.
  install-hooks             Install post-commit/checkout/merge/rewrite hooks that
                            fire 'align' in the background. Chains any existing hook.
  help                      This text.

OPTIONS
  --quiet                   Suppress stdout (still logs). Used by the hooks.

EXIT CODES
  0 ok    2 usage    3 drift detected / not fully repaired    4 beta unreachable

FILES
  Log: $LOGFILE
  Global Mutagen defaults: ~/.mutagen.yml
EOF
}

case "${1:-}" in
  ""|help|-h|--help) cmd_help ;;
  status)            cmd_status ;;
  align)             shift; cmd_align "$@" ;;
  setup)             cmd_setup ;;
  install-hooks)     cmd_install_hooks ;;
  *) err "azb-sync: unknown command '$1' — run 'azb-sync help'"; exit "$EX_USAGE" ;;
esac
