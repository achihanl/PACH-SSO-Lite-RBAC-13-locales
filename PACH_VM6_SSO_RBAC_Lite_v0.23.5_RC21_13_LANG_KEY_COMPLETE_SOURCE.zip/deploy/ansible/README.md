# AZBlink Directory — Ansible Deploy

Native, idempotent deploy of the stack. Reusable baseline for production.
Spec: `docs/superpowers/specs/2026-06-21-ansible-deploy-baseline-design.md`.

## One command, fresh host or not

```bash
just deploy prod --ask-vault-pass -K     # from the repo root on the control node
```

That installs the collections in `requirements.yml` and runs `site.yml` against
`inventories/prod`. The target needs only what an
[ARD-015 bootstrap ISO](../bootstrap-iso/README.md) gives it: Ubuntu, SSH with your
key, a sudo user and Python 3. Docker, `just`, the repo, the stack, the relay-path
certificate, Grafana alert routing and the nightly backup timer all come from the
run, which ends in `verify.yml`'s health gate. Re-running it updates the host.
Fill the inventory first (see [Production](#production)).

`just deploy-fresh-test` proves this end to end: it boots a throwaway Ubuntu 24.04
VM under qemu/KVM, converges it with the production playbook and the
`inventories/prod` example files (REPLACE fields filled with test values, random
secrets, a throwaway CA), then checks the alert contact point, runs one backup
and destroys the VM. About 20 minutes; `--keep` leaves the VM up. The
`fresh-host.yml` workflow runs it on PRs that touch the deploy, and nightly.
Details: [`fresh-host/run.py`](fresh-host/run.py).

## Prerequisites (control node)
- Ansible core 2.1x+ (`just deploy` installs the collections in `requirements.yml`)
- SSH reachability to the target (dev: VPN up to 192.168.11.136)

## Deploy (dev)
```bash
just deploy dev -K                  # type the target's sudo password
```

Run a subset with tags: `--tags host`, `--tags app`, `--tags verify`.

## What it does
1. `host_prep` — git/curl/jq, Docker Engine + Compose v2, just, docker group.
2. `azblink_app` — clone/update repo → render `.env` (host-derived OIDC/CORS) →
   ensure `cloudflare-tunnel` placeholder network (LAN layout only; the TLS overlay
   takes Traefik and Authentik off it) → `docker compose up -d --build`
   → wait for deep health → **assert Authentik seeded** (providers=1/apps=1,
   discovery 200). The deploy FAILS if the IdP is not correctly seeded.

## Idempotency
Re-running converges to no-ops (`changed=0`). Do not hand-edit `/opt` — the git
task fails on a dirty tree (override with `-e azblink_git_force=true`).

## Production
Copy the `*.example` files to their real names (drop `.example`):
`inventories/prod/hosts.ini`, `inventories/prod/group_vars/all/main.yml`,
`inventories/prod/group_vars/all/vault.yml`. Fill secrets, then
`ansible-vault encrypt inventories/prod/group_vars/all/vault.yml`. Run with
`-i inventories/prod --ask-vault-pass -K`. `dev_auth_token` MUST be empty in prod.

Transport (ARD-021): set `azblink_public_host`, `azblink_private_ip`, the certificate
(`azblink_tls_fullchain`, `azblink_tls_ca`, and `azblink_tls_privkey` in vault) and
`cf_tunnel_token` (vault). The Cloudflare side (tunnel, public hostname, Origin CA
certificate) is set up in the dashboard; `preflight.yml` refuses a prod converge
without it. The tunnel's public hostname maps to `http://edge:80`, the browser edge
that turns `CF-Connecting-IP` into each browser's own source (`azblink_edge_net`).
cloudflared shares a network with the edge only, so a container target answers 502.
A port published on `azblink_private_ip` (Authentik's TLS `:443`) stays reachable from it, so
never point the tunnel there. Each relay box maps `azblink_public_host` to `azblink_private_ip` and trusts
`azblink_tls_ca`. Once up, `azblink_relay_path_up` in Prometheus (alert **Relay path down**)
shows whether each listener still works the way a relay reaches it.

> Vars live in a `group_vars/all/` **directory** (both `main.yml` and `vault.yml`
> auto-load). A standalone `group_vars/vault.yml` would NOT be loaded by Ansible.

## Upgrading an install

A converge onto a host that already runs the stack is an upgrade, with the same
command. `migrate.yml` runs before the new API starts: it brings PostgreSQL up alone,
dry-runs `python -m db.migrate` (`src/backend/db/migrate.py`) in a one-off
`directory-api` container, dumps the database to
`/var/backups/azblink/pre-migrate-<UTC>.dump` when files will run, then migrates. The
runner is one transaction. If it refuses (exit 2) or a file fails (exit 1), nothing in
the database changed, the converge stops, and the old stack keeps serving. LDAP
(`ldap_source.yml`) and Authentik (the seed) converge in place on every run.

Any release from v0.5.0 on upgrades automatically (`tools/upgrade_drill.py` passes from
v0.10.0 and v0.19.0). An older install is refused: the runner compares the whole schema
(columns, types, nullability, defaults, indexes, tables old files dropped) with this
release's. Before the first converge onto an existing host, check on the host:

1. **What runs.** `cd /opt/azblink-directory && git log -1 --format='%h %d %cs'` and
   `curl -s localhost:8081/api/version`. Note the tag, or the date when it has none.
2. **First-start-only secrets.** The vault must carry the values the running install was
   created with, not new ones: Postgres, osixia and Authentik read them only on an empty
   volume. Copy them from the host's `deploy/dev/.env`:

   | `.env` key | vault key |
   |---|---|
   | `POSTGRES_PASSWORD` | `postgres_password` |
   | `LDAP_ADMIN_PASSWORD` | `ldap_admin_password` (and `ldap_bind_pw` while it binds as `cn=admin`) |
   | `AUTHENTIK_PG_PASS` | `authentik_pg_pass` |
   | `AUTHENTIK_SECRET_KEY` | `authentik_secret_key` (a new one breaks every stored session and secret) |
   | `AUTHENTIK_BOOTSTRAP_PASSWORD`, `AUTHENTIK_BOOTSTRAP_TOKEN` | `authentik_bootstrap_password`, `authentik_bootstrap_token` |

3. **Directory suffix.** `docker exec azblink-openldap ldapsearch -x -LLL -s base -b ''
   namingContexts` must print `dc=azblink,dc=com`; preflight refuses any other.
4. **Duplicates.** `docker exec azblink-openldap ldapsearch -Y EXTERNAL -H ldapi:/// -LLL -b
   dc=azblink,dc=com '(uidNumber=*)' uidNumber | sort | uniq -d` prints nothing on a clean
   directory. The converge checks this too (and uids under `ou=people`) and refuses before
   it enables the `unique` overlay, but finding them now saves a stopped converge.
5. **The schema plan, read-only.** With the new release checked out next to the old one
   (`git -C /opt/azblink-directory worktree add /tmp/azb-next <tag>`), run the dry run
   against the live database. `.env` is `0640 root:root`, so root reads it; the password
   goes into a mode-600 env file, never onto a command line:

   ```bash
   cd /opt/azblink-directory/deploy/dev
   sudo sh -c 'umask 077; printf "DATABASE_URL=postgresql+psycopg2://azblink_directory:%s@postgres:5432/azblink_directory\n" \
     "$(sed -n "s/^POSTGRES_PASSWORD=//p" .env)" > /root/azb-migrate.env'
   sudo docker run --rm --network dev_azblink-net -w /app --env-file /root/azb-migrate.env \
     -v /tmp/azb-next/src/backend:/app:ro -v /tmp/azb-next/migrations:/migrations:ro \
     dev-directory-api python -m db.migrate /migrations --dry-run
   sudo rm /root/azb-migrate.env
   ```

   The last line is the plan: `"state": "baseline"` and `"ran"` listing `030`, `031` is a
   normal first upgrade. Remove the worktree afterwards (`git worktree remove /tmp/azb-next`).
6. **A backup.** `sudo systemctl start azblink-backup` where the backup role is already
   installed; otherwise `sudo sh -c 'docker exec azblink-postgres pg_dump -U azblink_directory
   -Fc azblink_directory > /root/pre-upgrade.dump'` and `sudo sh -c 'docker exec
   azblink-openldap slapcat -n1 > /root/pre-upgrade.ldif'`.

If the runner refuses, the message names what it found:

- `missing column`, `unknown column`, `column ... is ...`, `missing index`, or
  `table ... should be gone`: the install is older than v0.5.0 (v0.2.0/v0.3.0 still hold
  SIP/XMPP settings in `config_templates` columns and `provision_tokens`, which `024`/`025`
  move; v0.4.0 lacks `device_provisions.app_name`), or its schema was changed by hand.
  Baselining it would skip those files and strand the data, so the runner will not. Either
  apply the matching `migrations/0*.sql` files by hand with `psql` until the dry run passes,
  or install fresh on an empty volume and import the LDAP data (`slapcat -n1` from the old
  box, then `ldapadd` of `ou=people`/`ou=groups`); the directory's own Postgres data
  (profiles, audit) does not carry over that way.
- `the database has migrations this release lacks`: the target release is older than the
  one that last migrated this database. Converge a release at least that new.
- `... controls its own transaction`: a migration file after `029` has `BEGIN`/`COMMIT`;
  fix the file.

Restore after a bad migration. Recreate the database first: `pg_restore --clean` drops
only what the dump holds, so `schema_migrations` and tables the migration created would
survive, and the ledger would still list the bad file as run. The dump is on the host
(root-only directory), so root pipes it in:

```bash
# The dump must read back before anything is dropped: stop here unless this prints "dump OK".
sudo sh -c 'docker exec -i azblink-postgres pg_restore --list \
  < /var/backups/azblink/pre-migrate-<UTC>.dump > /dev/null' && echo "dump OK"
sudo docker stop azblink-directory-api
sudo docker exec azblink-postgres dropdb -U azblink_directory --force azblink_directory
sudo docker exec azblink-postgres createdb -U azblink_directory azblink_directory
sudo sh -c 'docker exec -i azblink-postgres pg_restore -U azblink_directory -d azblink_directory \
  < /var/backups/azblink/pre-migrate-<UTC>.dump'
```

Then converge a release whose migration is fixed; the restored database has the ledger
it had before the bad run (none on a first upgrade).

## Authentik LDAP source (ARD-007) — one-time prod provisioning

Prod runs with `dev_auth_token: ""`, so the seed cannot self-provision the
`authentik-sync` LDAP bind client the way dev does. Before the first converge
that expects LDAP-backed web SSO, provision the sync client once out-of-band:

1. Provision the sync client via the UI (`/configuration/ldap-clients`) or an
   admin-token API call to `POST /api/settings/ldap/clients/provisioned`
   (`client_id: authentik-sync`) — this mints the bind secret **show-once**.
2. Copy that secret into `inventories/prod/group_vars/all/vault.yml` as
   `authentik_ldap_sync_password`.
3. `ansible-vault encrypt inventories/prod/group_vars/all/vault.yml`.
4. Converge (`ansible-playbook -i inventories/prod site.yml --ask-vault-pass -K`).
   The seed reads `AUTHENTIK_LDAP_SYNC_PASSWORD` from the rendered `.env` and
   configures the `azblink-ldap` source with it; the `ldap_source` role tasks
   idempotently (re-)apply the `ou=clients` read-minus-secrets ACL on every
   converge, which is required for already-initialized LDAP volumes since the
   bootstrap ldif only runs at osixia's fresh init.

If the client is ever rotated (`POST .../provisioned/authentik-sync/rotate`),
repeat steps 2-4 with the new secret.

## Headless first-party clients (ARD-018)

To register a client app box (for SafeNest, one per building) in prod:

1. Add it to `authentik_first_party_clients` in `inventories/prod/group_vars/all/main.yml`:
   `safenest-a1: ["https://a1.example.com/auth/callback"]`, and its relay box's static IP on
   the private path to `authentik_relay_ips`: `safenest-a1: 192.0.2.10` (ARD-021). Preflight
   refuses a client without one, and two clients on one address. A client onboarded through
   `POST /api/clients/onboard` (ARD-022) instead goes in `authentik_onboarded_clients` plus
   `authentik_relay_ips`, only if its box relays sign-ins: the onboard response's
   `relay.operatorStep` says so.
2. Converge. The changed `.env` recreates `authentik-seed`, which creates the
   provider, application, access policy and the shared `headless-first-party-auth`
   flow; `verify.yml` waits for the provider.
3. Read the provider's `client_secret` once from the Authentik Admin API
   (`GET /api/v3/providers/oauth2/?client_id=<client_id>`) into the client's own vault.

Role groups (`<client_id>-<role>`) are created through the directory API
(`/api/groups/*`), not here. Spec: `docs/architecture/spec/08-integration-points.md`.

## API-to-API service clients (ARD-017)

To let another backend call this API with `client_credentials` in prod:

1. Add it to `authentik_service_clients` in `inventories/prod/group_vars/all/main.yml`,
   with the RBAC permissions it holds: `building-sync: ["audit_log_access"]`.
   If it reaches Authentik through a public host, add that issuer
   (`https://<host>/application/o/<client_id>/`) to `oidc_extra_issuers`.
2. Converge. `env.j2` renders the client into `AUTHENTIK_SERVICE_CLIENTS` (seed),
   `OIDC_ACCEPTED_AUDIENCES`, `OIDC_SERVICE_PERMISSIONS` and `OIDC_ACCEPTED_ISSUERS`
   (API); `verify.yml` waits for its `client_credentials`-only provider.
3. Read the provider's `client_secret` once from the Authentik Admin API
   (`GET /api/v3/providers/oauth2/?client_id=<client_id>`) into the caller's vault.

## Backups

The `azblink_backup` role (tag `backup`) installs a nightly backup of LDAP, both
Postgres databases and Redis: 14 dailies plus 12 weeklies, and a push-only off-host
copy encrypted to a public key whose private half never touches the host. Set
`backup_offhost_target` and `backup_offhost_ssh_key` in `vault.yml` and
`backup_encryption_public_key` in `main.yml`, restrict the target's key to
`rrsync -wo -no-del`, then `ansible-playbook -i inventories/prod site.yml --tags backup --ask-vault-pass -K`.
A prod converge's preflight refuses to run without those three values, unless
`backup_local_only_accepted` records who accepted backups on the host alone, when and why.
Restore and drill: [`docs/runbooks/backup-restore.md`](../../docs/runbooks/backup-restore.md).
