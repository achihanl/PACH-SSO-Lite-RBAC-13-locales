#!/usr/bin/env bash
# Install/uninstall the Azblink auto-deploy LaunchAgent. Run in a real terminal,
# as YOUR user — NOT sudo. macOS only.
#   bash install.sh            # install + load the 10-min poll agent
#   bash install.sh uninstall  # unload + remove it
set -euo pipefail

# Guardrails: this is macOS-only (launchctl / security / osascript) and MUST run
# as your user — it installs a per-user LaunchAgent and uses your login Keychain.
if [ "$(uname -s)" != "Darwin" ]; then
  echo "azb-autodeploy install is macOS-only (LaunchAgent + Keychain); this is $(uname -s)." >&2
  echo "The Linux VM app installer is deploy/install.sh — not this one." >&2
  exit 1
fi
if [ "${EUID:-$(id -u)}" -eq 0 ]; then
  echo "Do NOT run this with sudo. It installs under \$HOME and uses your login" >&2
  echo "Keychain; as root those go to /var/root. Re-run as yourself:" >&2
  echo "  bash $0 ${1:-}" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BRAIN="$SCRIPT_DIR/azb-autodeploy.sh"
LABEL="com.azblink.autodeploy"
PLIST_DEST="$HOME/Library/LaunchAgents/$LABEL.plist"
LAUNCHD_LOG="$HOME/Library/Logs/azb-autodeploy.launchd.log"
BIN_LINK="$HOME/.local/bin/azb-autodeploy"
DOMAIN="gui/$(id -u)"

uninstall(){
  launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || launchctl unload "$PLIST_DEST" 2>/dev/null || true
  rm -f "$PLIST_DEST" "$BIN_LINK"
  echo "Uninstalled $LABEL (state in ~/.config/azb-autodeploy and logs kept)."
}

if [ "${1:-}" = "uninstall" ]; then uninstall; exit 0; fi

chmod +x "$BRAIN"

# Convenience command: `azb-autodeploy approve|status|...`
mkdir -p "$(dirname "$BIN_LINK")"
ln -sf "$BRAIN" "$BIN_LINK"

# Render the plist from the template.
mkdir -p "$(dirname "$PLIST_DEST")" "$(dirname "$LAUNCHD_LOG")"
sed -e "s#__SCRIPT__#$BRAIN#g" -e "s#__LAUNCHD_LOG__#$LAUNCHD_LOG#g" \
  "$SCRIPT_DIR/com.azblink.autodeploy.plist.template" > "$PLIST_DEST"

# Ensure the VM sudo password is in the Keychain (needed at approve time).
if ! security find-generic-password -s "azb-ad-become" -a "$USER" -w >/dev/null 2>&1; then
  echo "VM sudo password not stored yet."
  "$BRAIN" set-password
fi

# (Re)load the agent.
launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
launchctl bootstrap "$DOMAIN" "$PLIST_DEST" 2>/dev/null || launchctl load -w "$PLIST_DEST"

echo "Installed $LABEL (polls every 5 min)."
echo "  command:  azb-autodeploy {status|approve|deploy <ref>|seed <tag>}"
echo "  log:      ~/Library/Logs/azb-autodeploy.log"
echo
echo "Next: seed the currently-deployed tag so you aren't prompted to redeploy it,"
echo "      e.g.  azb-autodeploy seed v0.5.1   (or just approve the pending one)."
