#!/usr/bin/env bash
# =============================================================================
# azb-autodeploy.sh — pull-based, tag-triggered deployer for the VPN dev VM.
#
# This laptop is the deploy controller. `safenest` only develops + cuts tags.
# Run `azb-autodeploy help` for full usage (humans) or `help --json` (agents).
#
# Design: poll/notify (no webhook — laptops have no inbound URL); notify-then-
# approve (health gate runs post-compose, no auto-rollback); control plane
# tracks origin/main, app pinned to the released tag via -e azblink_branch.
# Lock is a DEPLOY mutex only (so `watch` never holds it while idle).
# =============================================================================
set -uo pipefail   # NOTE: no -e; we handle exit codes explicitly (watch loops).

export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"

# Resolve symlinks so path derivation is correct when invoked via
# ~/.local/bin/azb-autodeploy (the installed symlink into the repo).
_src="${BASH_SOURCE[0]}"
while [ -L "$_src" ]; do
  _dir="$(cd -P "$(dirname "$_src")" && pwd)"
  _src="$(readlink "$_src")"; case "$_src" in /*) ;; *) _src="$_dir/$_src";; esac
done
SCRIPT_DIR="$(cd -P "$(dirname "$_src")" && pwd)"; unset _src _dir
ANSIBLE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"        # deploy/ansible
REPO_ROOT="$(cd "$ANSIBLE_DIR/../.." && pwd)"      # repo root

# --- config ------------------------------------------------------------------
REPO_SSH="git@github.com:KeithMoc/azb-azblink-directory-and-identity-stack.git"
SSH_KEY="$HOME/.ssh/id_rsa"
KC_SERVICE="azb-ad-become"
INVENTORY="inventories/dev/hosts.ini"     # relative to ANSIBLE_DIR; source of the target address
COUNTDOWN=120                              # approval window (seconds) for `watch`
WATCH_DEFAULT=30                           # default recheck interval for `watch`
STATE_DIR="$HOME/.config/azb-autodeploy"
LOCK_DIR="$STATE_DIR/lock"
DEPLOYED_F="$STATE_DIR/deployed.tag"
PENDING_F="$STATE_DIR/pending.tag"
PENDING_TS_F="$STATE_DIR/pending.ts"
REJECTED_F="$STATE_DIR/rejected.list"
LOGFILE="$HOME/Library/Logs/azb-autodeploy.log"
GIT_SSH_RO="ssh -i $SSH_KEY -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new"

# --- exit codes (stable contract; documented in `help`) ----------------------
EX_OK=0; EX_USAGE=2; EX_NOOP=5; EX_DEPLOYFAIL=6; EX_LOCK=7; EX_VPN=8; EX_NOPASS=9

mkdir -p "$STATE_DIR" "$(dirname "$LOGFILE")"

# --- helpers -----------------------------------------------------------------
ts(){ date '+%Y-%m-%d %H:%M:%S'; }
now(){ date '+%s'; }
log(){ printf '%s %s\n' "$(ts)" "$*" | tee -a "$LOGFILE" >&2; }
notify(){ /usr/bin/osascript -e "display notification \"${2//\"/\\\"}\" with title \"${1//\"/\\\"}\"" >/dev/null 2>&1 || true; }
read_state(){ [ -f "$1" ] && cat "$1" || true; }
# The address the inventory actually targets, so this check follows a VM rebuild
# instead of asserting a stale one.
target_host(){ sed -n 's/^azb-ad .*ansible_host=\([0-9.][0-9.]*\).*/\1/p' "$ANSIBLE_DIR/$INVENTORY" 2>/dev/null | head -1; }

# Reachable over a tunnel iff the target's route egresses a tunnel interface.
# Naming a fixed utun was wrong in two independent ways: macOS assigns utunN per
# connection (this was utun6, then utun7 after a reconnect), and the tunnel can
# carry only an inet6 address on the interface while still routing the v4 subnet
# — which `ifconfig | grep 'inet '` reports as down while Ansible connects fine.
# Asking the routing table which interface serves the target answers the question
# the deploy actually depends on.
vpn_up(){
  local ip iface
  ip="$(target_host)" || return 1
  [ -n "$ip" ] || return 1
  iface="$(/sbin/route -n get "$ip" 2>/dev/null | awk '/interface:/{print $2; exit}')"
  case "$iface" in utun*|ipsec*|tun*|tap*) return 0 ;; *) return 1 ;; esac
}
ensure_agent(){ ssh-add -l >/dev/null 2>&1 || ssh-add "$SSH_KEY" >/dev/null 2>&1 || true; }
jstr(){ if [ -z "${1:-}" ]; then printf 'null'; else printf '"%s"' "$1"; fi; }   # JSON string or null

all_tags(){
  GIT_SSH_COMMAND="$GIT_SSH_RO" git ls-remote --tags --sort=-v:refname "$REPO_SSH" 'v*' 2>/dev/null \
    | grep -v '\^{}' | sed -E 's#.*refs/tags/##'
}
latest_tag(){ all_tags | head -1; }

rejected_has(){ [ -f "$REJECTED_F" ] && grep -qxF "$1" "$REJECTED_F"; }
rejected_add(){ rejected_has "$1" || printf '%s\n' "$1" >> "$REJECTED_F"; }
rejected_del(){ [ -f "$REJECTED_F" ] || return 0; grep -vxF "$1" "$REJECTED_F" > "$REJECTED_F.tmp" 2>/dev/null || true; mv -f "$REJECTED_F.tmp" "$REJECTED_F" 2>/dev/null || true; }

set_pending(){ printf '%s' "$1" > "$PENDING_F"; now > "$PENDING_TS_F"; }
clear_pending(){ rm -f "$PENDING_F" "$PENDING_TS_F"; }
set_deployed(){ printf '%s' "$1" > "$DEPLOYED_F"; rejected_del "$1"; clear_pending; }

acquire_lock(){
  if [ -d "$LOCK_DIR" ] && [ -n "$(find "$LOCK_DIR" -maxdepth 0 -mmin +60 2>/dev/null)" ]; then
    rmdir "$LOCK_DIR" 2>/dev/null || true
  fi
  local waited=0 max="${1:-0}"
  until mkdir "$LOCK_DIR" 2>/dev/null; do
    [ "$waited" -ge "$max" ] && return 1
    sleep 1; waited=$((waited + 1))
  done
  return 0
}
release_lock(){ rmdir "$LOCK_DIR" 2>/dev/null || true; }
WATCH_SLEEP_PID=""
# EXIT cleans up on any exit. INT/TERM must ALSO exit AND kill the watch sleep:
# a trapped SIGINT whose handler just returns would resume the `watch` loop, and
# the sleep runs via `& wait` so the handler fires promptly. 130 = 128 + SIGINT.
trap 'release_lock' EXIT
trap 'release_lock; [ -n "$WATCH_SLEEP_PID" ] && kill "$WATCH_SLEEP_PID" 2>/dev/null; exit 130' INT TERM

become_helper(){
  local h; h="$(mktemp -t azb-become-helper.XXXXXX)"; chmod 700 "$h"
  cat > "$h" <<EOF
#!/usr/bin/env bash
security find-generic-password -s "$KC_SERVICE" -a "\$USER" -w
EOF
  printf '%s' "$h"
}

# Run the playbook for a git ref. Returns: 0 ok, EX_VPN, EX_NOPASS, else ansible rc.
_run_deploy(){
  local ref="$1" helper rc
  vpn_up || { echo "ERROR: $(target_host) does not route over a tunnel — bring the VPN up, then retry." >&2; log "deploy $ref: VPN down"; return "$EX_VPN"; }
  if ! security find-generic-password -s "$KC_SERVICE" -a "$USER" -w >/dev/null 2>&1; then
    echo "ERROR: VM sudo password not in Keychain. Run: $0 set-password" >&2; log "deploy $ref: no become pw"; return "$EX_NOPASS"
  fi
  ensure_agent
  log "deploy $ref: ff-only origin/main (control plane)"
  git -C "$REPO_ROOT" fetch --quiet origin main 2>/dev/null || true
  git -C "$REPO_ROOT" merge --ff-only --quiet origin/main 2>/dev/null || log "deploy $ref: main not ff — using current role"
  helper="$(become_helper)"
  log "deploy $ref: ansible (azblink_branch=$ref)"
  ( cd "$ANSIBLE_DIR" && ansible-playbook site.yml -e "azblink_branch=$ref" --become-password-file "$helper" )
  rc=$?
  rm -f "$helper"
  return "$rc"
}

# Deploy under the lock, updating state + notifying. Distinguishes a bad tag
# (Ansible failed → auto-reject) from a precondition failure (VPN/Keychain →
# do NOT reject; it's not the tag's fault).
deploy_with_lock(){
  local ref="$1" rc
  acquire_lock 20 || { echo "Another deploy is running — try again in a moment." >&2; return "$EX_LOCK"; }
  _run_deploy "$ref"; rc=$?
  if [ "$rc" -eq 0 ]; then
    set_deployed "$ref"; log "SUCCESS $ref"; notify "Azblink deployed $ref" "VM is live on $ref."; echo "Deployed $ref."
    release_lock; return 0
  elif [ "$rc" -eq "$EX_VPN" ] || [ "$rc" -eq "$EX_NOPASS" ]; then
    release_lock; return "$rc"                     # precondition failure — tag not rejected
  else
    rejected_add "$ref"; clear_pending
    log "FAILED $ref"; notify "Azblink deploy FAILED" "$ref failed — VM may be degraded. Check the log."
    echo "Deploy FAILED for $ref. See $LOGFILE" >&2
    release_lock; return "$EX_DEPLOYFAIL"
  fi
}

# --- subcommands -------------------------------------------------------------
cmd_poll(){
  local latest deployed pending
  latest="$(latest_tag)"; [ -z "$latest" ] && { log "poll: no tag (offline?)"; return 0; }
  deployed="$(read_state "$DEPLOYED_F")"; pending="$(read_state "$PENDING_F")"
  [ "$latest" = "$deployed" ] && { log "poll: up to date ($latest)"; return 0; }
  rejected_has "$latest" && { log "poll: $latest rejected; skipping"; return 0; }
  [ "$latest" = "$pending" ] && { log "poll: $latest already pending"; return 0; }
  set_pending "$latest"
  log "poll: NEW release $latest pending (deployed=${deployed:-none})"
  notify "Azblink: new release $latest" "Run 'azb-autodeploy approve' (or 'watch') to deploy."
}

# 120s live countdown for one tag. 0 = approved+deployed, 1 = rejected/expired.
_countdown_approve(){
  local tag="$1" i key
  set_pending "$tag"
  for (( i=COUNTDOWN; i>0; i-- )); do
    printf "\r\033[K  NEW %s — press 'y' to deploy, 'n' to reject (auto-reject in %3ds) " "$tag" "$i"
    if read -r -s -n 1 -t 1 key 2>/dev/null; then
      case "$key" in
        y|Y) printf "\n"; deploy_with_lock "$tag"; return $? ;;
        n|N) printf "\n  Rejected %s.\n" "$tag"; rejected_add "$tag"; clear_pending; return 1 ;;
      esac
    fi
  done
  printf "\n  No approval in %ss — rejected %s.\n" "$COUNTDOWN" "$tag"
  rejected_add "$tag"; clear_pending; return 1
}

cmd_watch(){
  local interval="${1:-$WATCH_DEFAULT}"
  case "$interval" in (*[!0-9]*|"") interval="$WATCH_DEFAULT";; esac
  echo "Watching ${REPO_SSH##*/} — recheck ${interval}s, ${COUNTDOWN}s approve window. Ctrl-C to stop."
  while true; do
    local latest deployed
    latest="$(latest_tag)"; deployed="$(read_state "$DEPLOYED_F")"
    if [ -n "$latest" ] && [ "$latest" != "$deployed" ] && ! rejected_has "$latest"; then
      _countdown_approve "$latest"
    else
      printf "\r\033[K  %s  latest=%s deployed=%s  (idle) " "$(date '+%H:%M:%S')" "${latest:-?}" "${deployed:-none}"
    fi
    # Interruptible sleep: `wait` returns immediately when INT/TERM is trapped,
    # so Ctrl-C stops watch mid-interval instead of after the full interval.
    sleep "$interval" & WATCH_SLEEP_PID=$!
    wait "$WATCH_SLEEP_PID" 2>/dev/null || true
    WATCH_SLEEP_PID=""
  done
}

cmd_approve(){
  local pending; pending="$(read_state "$PENDING_F")"
  [ -n "${1:-}" ] && pending="$1"
  [ -z "$pending" ] && { echo "Nothing pending. Use 'pick' to choose a version."; return "$EX_NOOP"; }
  echo "Deploying ${pending}…"; deploy_with_lock "$pending"
}

cmd_deploy(){ [ -z "${1:-}" ] && { echo "usage: azb-autodeploy deploy <branch-or-tag>"; return "$EX_USAGE"; }; echo "Deploying ref '$1'…"; deploy_with_lock "$1"; }

cmd_pick(){
  echo "Fetching versions…"
  local i=0 t; tags=()
  while IFS= read -r t; do [ -n "$t" ] && { tags[$i]="$t"; i=$((i+1)); }; done < <(all_tags | head -15)
  [ "$i" -eq 0 ] && { echo "No tags found (offline?)."; return 1; }
  local deployed; deployed="$(read_state "$DEPLOYED_F")"
  echo "Versions (newest first):"
  local n=0 mark
  while [ "$n" -lt "$i" ]; do
    t="${tags[$n]}"; mark=""
    [ "$t" = "$deployed" ] && mark="$mark [deployed]"
    rejected_has "$t" && mark="$mark [rejected]"
    printf "  %2d) %s%s\n" "$((n+1))" "$t" "$mark"; n=$((n+1))
  done
  printf "Select a version to deploy [1-%d], or q to cancel: " "$i"
  local sel; read -r sel
  { [ "$sel" = "q" ] || [ -z "$sel" ]; } && { echo "Cancelled."; return 0; }
  case "$sel" in (*[!0-9]*) echo "Invalid."; return "$EX_USAGE";; esac
  { [ "$sel" -ge 1 ] && [ "$sel" -le "$i" ]; } || { echo "Out of range."; return "$EX_USAGE"; }
  local chosen="${tags[$((sel-1))]}"
  echo "Deploying ${chosen}…"; deploy_with_lock "$chosen"
}

json_array_file(){ [ -f "$1" ] || return 0; awk 'NF{ printf "%s\"%s\"", sep, $0; sep="," }' "$1"; }

json_status(){
  local d p pts l age vpn lock rej
  d="$(read_state "$DEPLOYED_F")"; p="$(read_state "$PENDING_F")"; pts="$(read_state "$PENDING_TS_F")"
  l="$(latest_tag 2>/dev/null || true)"
  if [ -n "$p" ] && [ -n "$pts" ]; then age="$(( $(now) - pts ))"; else age="null"; fi
  vpn_up && vpn=true || vpn=false
  [ -d "$LOCK_DIR" ] && lock=true || lock=false
  rej="$(json_array_file "$REJECTED_F")"
  printf '{"repo":%s,"latest":%s,"deployed":%s,"pending":%s,"pending_age_s":%s,"rejected":[%s],"vpn_up":%s,"lock_held":%s,"log":%s}\n' \
    "$(jstr "$REPO_ROOT")" "$(jstr "$l")" "$(jstr "$d")" "$(jstr "$p")" "$age" "$rej" "$vpn" "$lock" "$(jstr "$LOGFILE")"
}

cmd_status(){
  [ "${1:-}" = "--json" ] && { json_status; return 0; }
  local d p pts l age=""; d="$(read_state "$DEPLOYED_F")"; p="$(read_state "$PENDING_F")"
  pts="$(read_state "$PENDING_TS_F")"; l="$(latest_tag 2>/dev/null || true)"
  if [ -n "$p" ] && [ -n "$pts" ]; then age=" ($(( $(now) - pts ))s ago)"; fi
  echo "repo:     $REPO_ROOT"
  echo "latest:   ${l:-? (offline)}"
  echo "deployed: ${d:-none}"
  echo "pending:  ${p:-none}${age}"
  echo "rejected: $( [ -f "$REJECTED_F" ] && tr '\n' ' ' < "$REJECTED_F" || echo none )"
  if vpn_up; then echo "vpn:      up"; else echo "vpn:      DOWN"; fi
  echo "log:      $LOGFILE"
}

cmd_seed(){ [ -z "${1:-}" ] && { echo "usage: azb-autodeploy seed <tag>"; return "$EX_USAGE"; }; set_deployed "$1"; echo "Seeded deployed=$1"; }
cmd_unreject(){ [ -z "${1:-}" ] && { echo "usage: azb-autodeploy unreject <tag>"; return "$EX_USAGE"; }; rejected_del "$1"; echo "Un-rejected $1"; }

cmd_set_password(){
  [ -t 0 ] || { echo "Run in a real terminal to enter the password." >&2; return "$EX_USAGE"; }
  local _p; read -rsp "VM sudo password (Keychain '$KC_SERVICE'): " _p; echo
  security add-generic-password -s "$KC_SERVICE" -a "$USER" -w "$_p" -T /usr/bin/security -U
  unset _p; echo "Stored."
}

cmd_help(){
  cat <<EOF
azb-autodeploy — pull-based, tag-triggered deployer for the Azblink VM (azb-ad).

SYNOPSIS
  azb-autodeploy <command> [args]

DESCRIPTION
  This laptop is the deploy controller. It polls GitHub for new semver tags and
  deploys a chosen tag to the VPN-only VM via Ansible. Notify-then-approve:
  nothing deploys without you. The health gate runs post-\`compose up\` and there
  is NO auto-rollback — recover with \`deploy <previous-tag>\`.

COMMANDS
  status [--json]   Show latest/deployed/pending/rejected/vpn. --json = machine-readable.
  watch [secs]      Active loop (TTY): new tag → 120s countdown; 'y' deploys, 'n'/timeout
                    rejects. Rechecks every [secs] (default ${WATCH_DEFAULT}). Ctrl-C stops.
  approve [tag]     Deploy the pending tag (or an explicit one). Non-interactive.
  deploy <ref>      Deploy any branch/tag now, e.g. rollback. Non-interactive.
  pick              Interactive menu (TTY): choose a version from history to deploy.
  poll              One detection cycle (the launchd agent runs this). Non-interactive.
  seed <tag>        Record <tag> as already-deployed (and un-reject it).
  unreject <tag>    Re-allow prompting for a previously rejected tag.
  set-password      Store the VM sudo password in the macOS Keychain (TTY).
  help [--json]     This help. --json emits a machine-readable command manifest.

EXAMPLES
  azb-autodeploy status --json | jq .      # agent: read current state
  azb-autodeploy deploy v0.6.0             # scriptable: deploy a specific tag
  azb-autodeploy approve                   # deploy whatever is pending
  azb-autodeploy watch 15                  # babysit releases, recheck every 15s

FOR AI AGENTS / AUTOMATION
  Non-interactive (safe to call unattended):
    status, poll, approve <tag>, deploy <ref>, seed, unreject, help
  Interactive — need a TTY, do NOT call from an agent:
    watch, pick, set-password
  Read state with \`status --json\`; act with \`deploy <ref>\` / \`approve <tag>\`;
  discover commands with \`help --json\`. Branch on the exit codes below.

EXIT CODES
  0  success (or benign no-op)     6  deploy failed (Ansible error; tag auto-rejected)
  2  usage error                   7  lock held (another deploy running)
  5  nothing to do (e.g. nothing pending to approve)
  8  VPN down (target not routed over a tunnel)
  9  VM sudo password missing from Keychain

FILES
  State: ~/.config/azb-autodeploy/{deployed,pending,pending.ts}.tag, rejected.list
  Log:   ~/Library/Logs/azb-autodeploy.log
EOF
}

help_json(){
  cat <<'EOF'
{
  "tool": "azb-autodeploy",
  "description": "Pull-based, tag-triggered deployer for the Azblink VM (azb-ad) over VPN. Notify-then-approve; no auto-rollback.",
  "read_state": "azb-autodeploy status --json",
  "commands": [
    {"name": "status",       "args": ["--json"], "interactive": false, "description": "Show latest/deployed/pending/rejected/vpn. --json for machine-readable state."},
    {"name": "poll",         "args": [],         "interactive": false, "description": "One detection cycle; sets pending + notifies on a new tag (used by launchd)."},
    {"name": "approve",      "args": ["[tag]"],  "interactive": false, "description": "Deploy the pending tag, or an explicit tag."},
    {"name": "deploy",       "args": ["<ref>"],  "interactive": false, "description": "Deploy any branch/tag now (rollback or redeploy)."},
    {"name": "watch",        "args": ["[secs]"], "interactive": true,  "description": "Active loop with a 120s keypress approval countdown. Requires a TTY."},
    {"name": "pick",         "args": [],         "interactive": true,  "description": "Interactive history menu to select a version. Requires a TTY."},
    {"name": "seed",         "args": ["<tag>"],  "interactive": false, "description": "Record a tag as already-deployed (un-reject it)."},
    {"name": "unreject",     "args": ["<tag>"],  "interactive": false, "description": "Re-allow prompting for a rejected tag."},
    {"name": "set-password", "args": [],         "interactive": true,  "description": "Store the VM sudo password in the Keychain. Requires a TTY."},
    {"name": "help",         "args": ["--json"], "interactive": false, "description": "Usage. --json emits this manifest."}
  ],
  "exit_codes": {
    "0": "success or benign no-op",
    "2": "usage error",
    "5": "nothing to do (e.g. nothing pending)",
    "6": "deploy failed (Ansible error; tag auto-rejected)",
    "7": "lock held (another deploy running)",
    "8": "VPN down (target not routed over a tunnel)",
    "9": "VM sudo password missing from Keychain"
  },
  "state_files": {
    "deployed": "~/.config/azb-autodeploy/deployed.tag",
    "pending":  "~/.config/azb-autodeploy/pending.tag",
    "rejected": "~/.config/azb-autodeploy/rejected.list"
  },
  "log": "~/Library/Logs/azb-autodeploy.log"
}
EOF
}

case "${1:-}" in
  ""|help|-h|--help|--json)
    if [ "${1:-}" = "--json" ] || [ "${2:-}" = "--json" ]; then help_json; else cmd_help; fi ;;
  poll)         cmd_poll ;;
  watch|auto)   shift; cmd_watch "${1:-}" ;;
  approve)      shift; cmd_approve "${1:-}" ;;
  deploy)       shift; cmd_deploy "${1:-}" ;;
  pick|history) cmd_pick ;;
  status)       shift; cmd_status "${1:-}" ;;
  seed)         shift; cmd_seed "${1:-}" ;;
  unreject)     shift; cmd_unreject "${1:-}" ;;
  set-password) cmd_set_password ;;
  *) echo "azb-autodeploy: unknown command '$1'" >&2; echo "Run 'azb-autodeploy help' for usage." >&2; exit "$EX_USAGE" ;;
esac
