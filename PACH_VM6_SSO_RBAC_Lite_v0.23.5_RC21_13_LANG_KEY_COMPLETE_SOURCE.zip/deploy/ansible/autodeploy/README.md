# AZBlink auto-deploy (laptop → VM)

Pull-based, **tag-triggered, notify-then-approve** deployer. This laptop is the
deploy controller; `safenest` only develops + cuts releases.

```
safenest (dev) ── git push tag vX.Y.Z ──▶ GitHub
                                            │  (laptop polls tags)
this laptop ◀───────────────────────────────┘
   │  passive: launchd poll (10 min) → notification
   │  active:  `azb-autodeploy watch` → live 120s approve countdown
   ▼
VM azb-ad (192.168.11.136, over the VPN tunnel)  ← deployed at the released tag
```

## Two ways to approve
- **Passive (launchd, every 10 min):** detects a new tag, posts a notification,
  leaves it `pending`. You deploy with `approve` (or `pick`) when you choose.
- **Active (`watch`):** a foreground loop you run in a terminal. On a new tag it
  shows a **120-second countdown**; press `y` to deploy, `n` to reject; if the
  window elapses it **auto-rejects** and keeps looping. A rejected tag is
  **suppressed** — never re-prompted (poll *or* watch) until a newer tag appears
  or you `unreject` it. Deploy any past version anytime with `pick`.

## Why this shape
- **Poll, not webhook** — a laptop has no reliable inbound URL. Poll uses
  `git ls-remote --tags` over SSH (your existing key); **no GitHub PAT**.
- **Notify-then-approve, not full-auto** — the Ansible health gate runs *after*
  `compose up`, so a bad tag can leave the VM degraded with **no auto-rollback**.
- **Control plane on `main`, data plane on the tag** — each deploy fast-forwards
  this repo to `origin/main` (current Ansible role incl. the agent-forwarding
  fix) and deploys the app pinned via `-e azblink_branch=<tag>`.

## Install (run in a real terminal — as your user, NOT sudo; macOS only)
> This installs a per-user LaunchAgent and uses your login Keychain, so it must
> run as you, not root. This is only the macOS autodeploy *trigger* — the actual
> VM app deploy is `deploy/ansible/` (`site.yml`). The installer here is
> `deploy/ansible/autodeploy/install.sh`.
```bash
cd deploy/ansible/autodeploy
bash install.sh                 # renders plist, loads the 10-min agent, stores
                                # the VM sudo password in Keychain if not set
azb-autodeploy seed v0.5.1      # mark what's already live → no redeploy prompt
```
Prereqs: VPN up at deploy time — the preflight asks the routing table whether the
inventory's `ansible_host` egresses a tunnel interface, so a reconnect that renames
`utunN` does not matter; `~/.ssh/id_rsa` is the GitHub-accepted key
(auto-loaded into the agent, forwarded to the VM); `community.docker` installed
(`ansible-galaxy collection install -r ../requirements.yml`).

## Commands
```bash
azb-autodeploy status            # latest / deployed / pending(+age) / rejected / vpn
azb-autodeploy watch [secs]      # active loop, 120s countdown (default recheck 30s)
azb-autodeploy approve [tag]     # deploy the pending tag (or a specific one)
azb-autodeploy pick              # interactive history: list versions → select → deploy
azb-autodeploy deploy <ref>      # ad-hoc deploy of any branch/tag (e.g. rollback)
azb-autodeploy seed <tag>        # record as deployed (and un-reject it)
azb-autodeploy unreject <tag>    # re-allow prompting for a rejected tag
azb-autodeploy set-password      # (re)store the VM sudo password in the Keychain
```

## Idempotent by design
Every command is safe to re-run: deploying a tag reconverges (Ansible is
idempotent), `seed`/`unreject`/reject are set operations, and `poll` is a no-op
when already current. `pick` can redeploy any version, including the current one.

## State & logs
- State: `~/.config/azb-autodeploy/{deployed,pending,pending.ts}.tag`, `rejected.list`
- Log:   `~/Library/Logs/azb-autodeploy.log` (launchd crashes: `…launchd.log`)

## Uninstall
```bash
bash install.sh uninstall        # unload + remove agent + convenience link (state kept)
```

## Known limits (by design, v1)
- The laptop must be awake + on VPN to *deploy* (it can *detect* releases offline).
- Schedule is a 10-min poll. For a **Friday-only** cadence instead, swap the
  plist's `StartInterval` for a `StartCalendarInterval` (`Weekday=5`).
- No blue/green, no auto-rollback. Recovery is `azb-autodeploy deploy <prev-tag>`
  (or `pick` an older version).
- An unattended daemon that can `sudo` on the VM is a standing privilege; it
  lives in your user session (Keychain + SSH agent), gone when you log out.
