"""Checks the directory API's Authentik token the way the API uses it (verify.yml).

verify.yml pipes this into `python3 -` inside the API container, so it reads the
container's own AUTHENTIK_API_URL and AUTHENTIK_API_TOKEN. Exit 0 only when Authentik
accepts the token and it belongs to an admin: suspend and terminate need admin rights,
and a token Authentik does not know makes them revoke nothing (partial=true).

With `own` as the first argument (the vault's API token differs from the bootstrap
token, as in prod), the token must also be the key of the seed's `azblink-directory-api`
token: the bootstrap token belongs to akadmin too, so `users/me` alone cannot tell them apart.
"""
import hmac
import json
import os
import sys
import urllib.request

IDENTIFIER = "azblink-directory-api"  # seed_authentik.py API_TOKEN_IDENTIFIER

url = os.environ.get("AUTHENTIK_API_URL", "").rstrip("/")
token = os.environ.get("AUTHENTIK_API_TOKEN", "")
if not (url and token):
    sys.exit("AUTHENTIK_API_URL or AUTHENTIK_API_TOKEN is unset in the API container")


def get(path: str) -> dict:
    req = urllib.request.Request(f"{url}/api/v3/{path}", headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.load(resp)


try:
    user = get("core/users/me/")["user"]
except Exception as exc:  # the message never carries the token
    sys.exit(f"Authentik refused AUTHENTIK_API_TOKEN: {exc}")
if not user.get("is_superuser"):
    sys.exit(f"AUTHENTIK_API_TOKEN belongs to {user.get('username')!r}, not an Authentik admin")
if sys.argv[1:2] == ["own"]:
    try:
        key = get(f"core/tokens/{IDENTIFIER}/view_key/")["key"]
    except Exception as exc:  # a 404 means the seed never created the token
        sys.exit(f"cannot read the key of Authentik token {IDENTIFIER!r}: {exc}")
    if not hmac.compare_digest(key.encode(), token.encode()):
        sys.exit(f"AUTHENTIK_API_TOKEN is not the key of Authentik token {IDENTIFIER!r}")
    print(f"AUTHENTIK_API_TOKEN is {IDENTIFIER!r} and works as {user['username']}")
else:
    print(f"AUTHENTIK_API_TOKEN works as {user['username']}")
