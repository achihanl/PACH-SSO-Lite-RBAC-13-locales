"""Relay-path inventory checks for preflight.yml (ARD-021 amendment 2026-10-22).

`relay_preflight_errors` returns one message per problem; preflight asserts the
list is empty. Stdlib `ipaddress` does the parsing, so the checks are per address
family and strict: a trailing newline, a leading zero or a host bit set below the
prefix is an error, not a silent pass. Unit-tested in tests/unit/test_preflight_relay.py,
and the real preflight task runs there too.
"""
from __future__ import annotations

import ipaddress

# Host-only prefix per family: anything wider trusts more than one box.
_HOST_PREFIX = {4: 32, 6: 128}


def _unusable(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> str | None:
    if ip.is_unspecified:
        return "unspecified"
    if ip.is_loopback:
        return "loopback (already trusted)"
    if ip.is_multicast:
        return "multicast"
    return None


def relay_preflight_errors(relay_ips, first_party_clients, private_ip, trusted_cidrs, edge_net=None,
                           onboarded_clients=None) -> list[str]:
    """Problems with authentik_relay_ips and authentik_trusted_proxy_cidrs; [] when the inventory is sound.

    - relay_ips: {client_id: IPv4}. One per first-party client, none for any other id,
      each a canonical IPv4 host that is not unspecified, loopback, multicast or the box's own
      private IP, not inside the browser edge (edge_net, a /24 prefix whose hops are trusted for
      X-Forwarded-For), and no two clients on one address. env.j2 renders each as a /32.
    - onboarded_clients: [client_id]. Clients onboarded through the API (ARD-022) whose relay
      box uses the relay path. Each needs a relay IP like an env client; an onboarded client
      that does not relay is simply not listed, and nothing is asked of it.
    - trusted_cidrs: [cidr]. Each a single host: IPv4 /32 or IPv6 /128, a valid network,
      not unspecified, loopback or multicast.
    """
    errors: list[str] = []
    relay_ips = relay_ips if relay_ips is not None else {}
    clients = first_party_clients if first_party_clients is not None else {}
    onboarded = onboarded_clients if onboarded_clients is not None else []
    if not isinstance(relay_ips, dict):
        return ["authentik_relay_ips must be a mapping {client_id: IPv4}"]
    if not isinstance(clients, dict):
        return ["authentik_first_party_clients must be a mapping"]
    if not isinstance(onboarded, list) or not all(isinstance(c, str) for c in onboarded):
        return ["authentik_onboarded_clients must be a list of client ids"]
    for client in sorted(set(onboarded) & set(clients)):
        errors.append(f"{client}: in both authentik_first_party_clients and authentik_onboarded_clients")

    relaying = set(clients) | set(onboarded)
    for client in sorted(relaying - set(relay_ips)):
        errors.append(f"{client}: relays sign-ins but has no relay IP in authentik_relay_ips")
    for client in sorted(set(relay_ips) - relaying):
        errors.append(f"{client}: relay IP set but not in authentik_first_party_clients or authentik_onboarded_clients")

    edge = None
    if edge_net:
        try:
            edge = ipaddress.IPv4Network(f"{edge_net}.0/24")
        except ValueError:
            errors.append(f"azblink_edge_net {edge_net!r} is not a /24 prefix")

    seen: dict[str, str] = {}
    for client, value in sorted(relay_ips.items()):
        if not isinstance(value, str):
            errors.append(f"{client}: relay IP must be a string, got {type(value).__name__}")
            continue
        try:
            ip = ipaddress.IPv4Address(value)
        except ValueError:
            errors.append(f"{client}: relay IP {value!r} is not a bare IPv4 address")
            continue
        if str(ip) != value:
            errors.append(f"{client}: relay IP {value!r} is not in canonical form ({ip})")
            continue
        if why := _unusable(ip):
            errors.append(f"{client}: relay IP {value} is {why}")
        if value == (private_ip or ""):
            errors.append(f"{client}: relay IP {value} is this box's own azblink_private_ip")
        if edge is not None and ip in edge:
            errors.append(f"{client}: relay IP {value} is inside the browser edge {edge} (azblink_edge_net)")
        if value in seen:
            errors.append(f"{client}: relay IP {value} is also {seen[value]}'s; each box needs its own")
        seen.setdefault(value, client)

    cidrs = trusted_cidrs if trusted_cidrs is not None else []
    if not isinstance(cidrs, list):
        return errors + ["authentik_trusted_proxy_cidrs must be a list"]
    for value in cidrs:
        if not isinstance(value, str):
            errors.append(f"trusted CIDR {value!r} must be a string")
            continue
        try:
            net = ipaddress.ip_network(value, strict=True)
        except ValueError:
            errors.append(f"trusted CIDR {value!r} is not a valid network")
            continue
        if "/" not in value or str(net) != value:
            errors.append(f"trusted CIDR {value!r} must be written as {net.network_address}/{_HOST_PREFIX[net.version]}")
            continue
        if net.prefixlen != _HOST_PREFIX[net.version]:
            errors.append(f"trusted CIDR {value} is wider than one host (IPv{net.version} needs /{_HOST_PREFIX[net.version]})")
            continue
        if why := _unusable(net.network_address):
            errors.append(f"trusted CIDR {value} is {why}")
    return errors


class FilterModule:
    def filters(self):
        return {"relay_preflight_errors": relay_preflight_errors}
