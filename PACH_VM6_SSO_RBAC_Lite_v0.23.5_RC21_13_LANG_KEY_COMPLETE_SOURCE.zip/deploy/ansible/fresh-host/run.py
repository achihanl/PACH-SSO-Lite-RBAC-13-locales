#!/usr/bin/env python3
"""Deploy the whole stack onto a throwaway VM with the production playbook, check it, destroy it.

    python3 deploy/ansible/fresh-host/run.py            # boot, converge, check, destroy
    python3 deploy/ansible/fresh-host/run.py --keep     # leave the VM running afterwards

The VM is a stock Ubuntu 24.04 cloud image under qemu/KVM: a host that only has
SSH, a sudo user and Python 3, which is what an ARD-015 bootstrap-ISO box gives
deploy/ansible. It uses qemu's user-mode network, so this box's networks, Docker
daemon and volumes are never touched; the stack runs on the VM's own Docker.

The inventory is the production one: inventories/prod/group_vars/all/main.yml.example
copied verbatim, a vault with every key in vault.yml.example set to a random
value, and zz_fresh_host.yml filling in the REPLACE_* fields (a test public host
and private IP, a throwaway CA and certificate). So the run covers what a real
first prod converge runs: preflight, host_prep, the ARD-021 relay path, the prod
LDAP admin, alert routing and the backup role. The deployed tree is HEAD, shipped
to the VM as a bare repo (azblink_repo_mirror): uncommitted changes are not deployed.

After site.yml (whose verify.yml is the health gate) the run checks that
Grafana provisioned the alert contact point, that one backup completes, and
that no container is restarting. cloudflared is the one container left out of
that check: no Cloudflare tunnel exists for the test token.

Needs qemu-system-x86_64, qemu-img, xorriso, openssl, ssh, /dev/kvm access and
ansible-playbook with community.docker (deploy/ansible/requirements.yml). The
cloud image is cached in ~/.cache/azb/cloud-img and checked against Ubuntu's
SHA256SUMS on download.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import secrets
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ANSIBLE_DIR = Path(__file__).resolve().parent.parent
REPO = ANSIBLE_DIR.parent.parent
PROD_VARS = ANSIBLE_DIR / "inventories/prod/group_vars/all"
IMAGE_URL = "https://cloud-images.ubuntu.com/releases/24.04/release"
IMAGE_NAME = "ubuntu-24.04-server-cloudimg-amd64.img"
CACHE = Path(os.environ.get("AZB_CLOUD_IMAGE_CACHE", Path.home() / ".cache/azb/cloud-img"))
PUBLIC_HOST = "id.fresh-host.test"
USER = "azb"
# The CI runner unit caps the runner and every step at MemoryHigh=5G, and the guest's
# page cache counts against it. 3.5 GB plus 6 GB of swap on the guest's own disk.
DEFAULT_MEMORY_MB = 3584
GUEST_SWAP_BYTES = 6 << 30


def log(msg: str) -> None:
    print(f"==> {msg}", flush=True)


def exit_on_signals() -> None:
    """SIGTERM (a CI cancel, `kill`) exits through main's finally, which destroys the VM.
    SIGINT already does, as KeyboardInterrupt."""
    signal.signal(signal.SIGTERM, lambda signum, _frame: sys.exit(128 + signum))


def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, check=True, **kw)


def ensure_image() -> Path:
    image = CACHE / IMAGE_NAME
    if image.exists():
        return image
    CACHE.mkdir(parents=True, exist_ok=True)
    sums = urllib.request.urlopen(f"{IMAGE_URL}/SHA256SUMS", timeout=60).read().decode()
    want = next(line.split()[0] for line in sums.splitlines() if line.endswith(IMAGE_NAME))
    part = image.with_suffix(".part")
    log(f"downloading {IMAGE_NAME} into {CACHE}")
    run(["curl", "-fsSL", "--retry", "3", "-o", str(part), f"{IMAGE_URL}/{IMAGE_NAME}"])
    digest = hashlib.sha256()
    with part.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            digest.update(chunk)
    if digest.hexdigest() != want:
        part.unlink()
        sys.exit(f"sha256 mismatch for {IMAGE_NAME}: deleted the download")
    part.rename(image)
    return image


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class VM:
    def __init__(self, work: Path, memory_mb: int, cpus: int) -> None:
        self.work, self.memory_mb, self.cpus = work, memory_mb, cpus
        self.port = free_port()
        self.key = work / "id_ed25519"
        self.pidfile = work / "qemu.pid"

    def boot(self, image: Path) -> None:
        run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-f", str(self.key)])
        seed = self.work / "seed"
        seed.mkdir()
        # The swap lives on the guest disk, so build peaks (npm, vite) do not count
        # against this process's memory (the CI runner's unit caps it at 6G).
        (seed / "user-data").write_text(
            "#cloud-config\n"
            + json.dumps({
                "users": [{
                    "name": USER, "shell": "/bin/bash", "sudo": "ALL=(ALL) NOPASSWD:ALL",
                    "ssh_authorized_keys": [(self.key.with_suffix(".pub")).read_text().strip()],
                }],
                "swap": {"filename": "/swap.img", "size": GUEST_SWAP_BYTES},
            })
            + "\n"
        )
        (seed / "meta-data").write_text("instance-id: azb-fresh-host\nlocal-hostname: azb-fresh-host\n")
        iso = self.work / "seed.iso"
        run(["xorriso", "-as", "mkisofs", "-quiet", "-o", str(iso), "-V", "cidata", "-J", "-r",
             str(seed / "user-data"), str(seed / "meta-data")], capture_output=True)
        disk = self.work / "disk.qcow2"
        run(["qemu-img", "create", "-q", "-f", "qcow2", "-F", "qcow2", "-b", str(image), str(disk), "60G"])
        log(f"booting the VM (ssh on 127.0.0.1:{self.port}, console log {self.work / 'console.log'})")
        run([
            "qemu-system-x86_64", "-name", "azb-fresh-host",
            "-machine", "q35,accel=kvm", "-cpu", "host",
            "-m", str(self.memory_mb), "-smp", str(self.cpus),
            "-drive", f"file={disk},if=virtio,format=qcow2",
            "-drive", f"file={iso},if=virtio,format=raw,readonly=on",
            "-netdev", f"user,id=n0,hostfwd=tcp:127.0.0.1:{self.port}-:22",
            "-device", "virtio-net-pci,netdev=n0",
            "-display", "none", "-serial", f"file:{self.work / 'console.log'}",
            "-daemonize", "-pidfile", str(self.pidfile),
        ])
        for _ in range(60):
            if self.ssh("true", check=False, quiet=True).returncode == 0:
                break
            time.sleep(5)
        else:
            sys.exit("the VM did not answer SSH within 5 minutes; see console.log")
        self.ssh("cloud-init status --wait >/dev/null")

    def ssh_args(self) -> list[str]:
        return ["-p", str(self.port), "-i", str(self.key), "-o", "BatchMode=yes", "-o", "ConnectTimeout=5",
                "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null", "-o", "LogLevel=ERROR"]

    def ssh(self, command: str, check: bool = True, quiet: bool = False) -> subprocess.CompletedProcess:
        return subprocess.run(["ssh", *self.ssh_args(), f"{USER}@127.0.0.1", command], check=check,
                              capture_output=quiet, text=True)

    def output(self, command: str, input_: str | None = None) -> str:
        return subprocess.run(["ssh", *self.ssh_args(), f"{USER}@127.0.0.1", command], check=True,
                              capture_output=True, text=True, input=input_).stdout

    def destroy(self) -> None:
        if self.pidfile.exists():
            pid = int(self.pidfile.read_text())
            try:
                os.kill(pid, 15)
            except ProcessLookupError:
                pass


def make_tls(work: Path) -> dict[str, str]:
    """A throwaway CA and a certificate for PUBLIC_HOST, as relays would trust."""
    tls = work / "tls"
    tls.mkdir()
    run(["openssl", "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:P-256", "-nodes",
         "-keyout", str(tls / "ca.key"), "-out", str(tls / "ca.pem"), "-days", "2",
         "-subj", "/CN=fresh-host test CA"], capture_output=True)
    run(["openssl", "req", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:P-256", "-nodes",
         "-keyout", str(tls / "privkey.pem"), "-out", str(tls / "server.csr"), "-subj", f"/CN={PUBLIC_HOST}"],
        capture_output=True)
    (tls / "ext").write_text(f"subjectAltName=DNS:{PUBLIC_HOST}\nextendedKeyUsage=serverAuth\n")
    run(["openssl", "x509", "-req", "-in", str(tls / "server.csr"), "-CA", str(tls / "ca.pem"),
         "-CAkey", str(tls / "ca.key"), "-CAcreateserial", "-days", "2", "-extfile", str(tls / "ext"),
         "-out", str(tls / "fullchain.pem")], capture_output=True)
    return {name: (tls / f"{name}.pem").read_text() for name in ("fullchain", "ca", "privkey")}


def vault(tls: dict[str, str]) -> dict[str, str]:
    """Every key of vault.yml.example, filled with a random value (refused if one is missing)."""
    def token(n: int = 24) -> str:
        return secrets.token_urlsafe(n)

    values = {
        "postgres_password": token(), "ldap_admin_password": token(), "ldap_bind_pw": token(),
        "org_qr_signing_secret": token(), "authentik_pg_pass": token(), "authentik_secret_key": token(48),
        "authentik_bootstrap_password": token(), "authentik_bootstrap_token": token(),
        "authentik_api_token": token(), "dev_auth_token": "", "redis_password": token(),
        "grafana_admin_password": token(), "authentik_ldap_sync_password": token(),
        "ldap_admin_bootstrap_password": token(),
        # verify.yml sends a test notification through each channel and needs a 2xx:
        # Alloy's reload endpoint answers any POST with 200 (and only reloads its config).
        "alert_webhook_url": "http://alloy:12345/-/reload",
        "alert_heartbeat_url": "http://alloy:12345/-/reload?heartbeat",
        "alert_smtp_password": "", "backup_offhost_target": "", "backup_offhost_ssh_key": "",
        "cf_tunnel_token": "fresh-host-test-no-tunnel", "azblink_tls_privkey": tls["privkey"],
    }
    # authentik_api_token stays separate from the bootstrap token, as in prod: the seed
    # creates it in Authentik and verify.yml checks it from inside the API container.
    # The API binds as cn=admin (preflight refuses a mismatch).
    values["ldap_bind_pw"] = values["ldap_admin_password"]
    keys = re.findall(r"^(\w+):", (PROD_VARS / "vault.yml.example").read_text(), re.M)
    missing = sorted(set(keys) - set(values))
    if missing:
        sys.exit(f"vault.yml.example has keys this test does not fill: {', '.join(missing)}")
    return values


def write_inventory(work: Path, vm: VM, private_ip: str, tls: dict[str, str], mirror: Path) -> Path:
    inv = work / "inventory"
    gv = inv / "group_vars/all"
    gv.mkdir(parents=True)
    (inv / "hosts.ini").write_text(
        "[azblink]\n"
        f"azb-fresh-host ansible_host=127.0.0.1 ansible_port={vm.port} ansible_user={USER} "
        f"ansible_ssh_private_key_file={vm.key} "
        "ansible_ssh_common_args='-o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no'\n"
    )
    shutil.copy(PROD_VARS / "main.yml.example", gv / "main.yml")
    # JSON is YAML: no PyYAML needed to write these.
    (gv / "vault.yml").write_text(json.dumps(vault(tls), indent=2) + "\n")
    # Loaded after main.yml (same directory, lexical order), so these win.
    (gv / "zz_fresh_host.yml").write_text(json.dumps({
        "azblink_repo_mirror": str(mirror),
        "azblink_branch": "fresh-host",
        "server_host": "azb-fresh-host",
        "docker_user": USER,
        "azblink_public_host": PUBLIC_HOST,
        "azblink_private_ip": private_ip,
        "azblink_tls_fullchain": tls["fullchain"],
        "azblink_tls_ca": tls["ca"],
        "alert_single_channel_accepted": "fresh-host test: a throwaway VM pages nobody",
        "backup_local_only_accepted": "fresh-host test: a throwaway VM has nothing to keep",
        "ldap_admin_bootstrap_uid": "admin",
        "ldap_admin_bootstrap_cn": "Fresh Host Admin",
        "ldap_organisation": "AZBlink",
        "ldap_domain": "azblink.com",
        "ucchat_xmpp_domain": "xmpp.fresh-host.test",
        "ucchat_xmpp_ws_url": "wss://xmpp.fresh-host.test/ws",
        "ucchat_sip_domain": "sip.fresh-host.test",
        "ucchat_sip_wss_url": "wss://sip.fresh-host.test/ws",
    }, indent=2) + "\n")
    filled = set(json.loads((gv / "zz_fresh_host.yml").read_text()))
    unfilled = [line for line in (gv / "main.yml").read_text().splitlines()
                if re.match(r"\w+:.*REPLACE", line) and line.split(":")[0] not in filled]
    if unfilled:
        sys.exit("main.yml.example has REPLACE fields this test does not fill:\n" + "\n".join(unfilled))
    return inv


def post_checks(vm: VM, secrets_: dict[str, str]) -> None:
    log("check: Grafana provisioned the alert contact point")
    # The password goes in on stdin (curl -K -): never in an argv a failure would print.
    body = vm.output(
        "curl -sf -K - http://127.0.0.1:3001/api/v1/provisioning/contact-points",
        input_=f"user = \"admin:{secrets_['grafana_admin_password']}\"\n",
    )
    names = {cp.get("name") for cp in json.loads(body)}
    if not {"azb-oncall", "azb-heartbeat"} <= names:
        sys.exit(f"azb-oncall or azb-heartbeat contact point missing in Grafana: {body}")

    log("check: one backup run completes")
    vm.ssh("sudo systemctl start azblink-backup.service")
    archives = vm.output("sudo find /var/backups/azblink -name 'azblink-*' -type f")
    if not archives.strip():
        sys.exit("azblink-backup ran but left no archive in /var/backups/azblink")
    print(archives.strip())

    log("check: no container is restarting (cloudflared excepted: no tunnel exists)")
    states = vm.output("sudo docker ps -a --format '{{.Names}} {{.State}} {{.Status}}'")
    print(states)
    bad = [line for line in states.splitlines()
           if not line.startswith("azblink-cloudflared")
           and ("restarting" in line or "unhealthy" in line
                or (" exited " in line and "Exited (0)" not in line))]
    if bad:
        sys.exit("containers not running cleanly:\n" + "\n".join(bad))


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--keep", action="store_true", help="leave the VM and its work dir after the run")
    p.add_argument("--memory", type=int, default=int(os.environ.get("AZB_FRESH_MEMORY_MB", DEFAULT_MEMORY_MB)),
                   help=f"VM memory in MB (default {DEFAULT_MEMORY_MB}, under the CI runner's MemoryHigh=5G)")
    p.add_argument("--cpus", type=int, default=4)
    args = p.parse_args()
    exit_on_signals()

    if subprocess.run(["git", "-C", str(REPO), "diff", "--quiet", "HEAD"]).returncode != 0:
        print("note: the working tree has uncommitted changes; the VM gets HEAD only", file=sys.stderr)

    # A run killed mid-way (CI timeout) leaves a multi-GB disk behind; its qemu is gone.
    for stale in Path(tempfile.gettempdir()).glob("azb-fresh-host-*"):
        pid = stale / "qemu.pid"
        alive = pid.exists() and Path(f"/proc/{pid.read_text().strip()}").exists()
        if not alive and time.time() - stale.stat().st_mtime > 3600:
            shutil.rmtree(stale, ignore_errors=True)

    image = ensure_image()
    work = Path(tempfile.mkdtemp(prefix="azb-fresh-host-"))
    vm = VM(work, args.memory, args.cpus)
    ok = False
    try:
        vm.boot(image)
        private_ip = vm.output("ip -4 route get 1.1.1.1 | sed -n 's/.* src \\([0-9.]*\\).*/\\1/p'").strip()
        mirror = work / "repo.git"
        run(["git", "init", "-q", "--bare", str(mirror)])
        # CI checks out at depth 1, and a bare repo refuses a push from a shallow clone.
        run(["git", "-C", str(mirror), "config", "receive.shallowUpdate", "true"])
        run(["git", "-C", str(REPO), "push", "-q", str(mirror), "HEAD:refs/heads/fresh-host"])
        tls = make_tls(work)
        inv = write_inventory(work, vm, private_ip, tls, mirror)
        secrets_ = json.loads((inv / "group_vars/all/vault.yml").read_text())

        log("converge: ansible-playbook site.yml (the production playbook)")
        started = time.monotonic()
        run(["ansible-playbook", "-i", str(inv), "site.yml"], cwd=ANSIBLE_DIR)
        log(f"converged in {int(time.monotonic() - started)} s")

        post_checks(vm, secrets_)
        ok = True
        log("PASS: fresh host converged and is healthy")
    except subprocess.CalledProcessError as e:
        print(f"FAILED: {shlex.join(map(str, e.cmd))} exited {e.returncode}", file=sys.stderr)
    finally:
        if not ok and vm.pidfile.exists():
            vm.ssh("sudo docker ps -a --format 'table {{.Names}}\\t{{.Status}}'", check=False)
            vm.ssh("cd /opt/azblink-directory/deploy/dev 2>/dev/null && sudo docker compose logs --tail 40 "
                   "authentik-seed directory-api authentik-server 2>&1 | tail -150", check=False)
        if args.keep:
            print(f"kept: ssh {shlex.join(vm.ssh_args())} {USER}@127.0.0.1   (work dir {work}, "
                  f"stop with: kill $(cat {vm.pidfile}))")
        else:
            vm.destroy()
            shutil.rmtree(work, ignore_errors=True)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
