# PACH VM6 v0.22.9_RC15 — Cumulative localization development release

Baseline: v0.22.8 RC14.

Added 35 Settings translations per added language (350 entries), including LDAP connectivity, system information, reset/warning controls, and settings navigation. Prior locale entries were not overwritten.

Terminology: PACH Master Terminology v25.9 was the reference; these newly drafted strings are NOT certified or newly approved glossary decisions. Existing glossary traceability is preserved.

Validation: all source keys and interpolation placeholders compared against English; full locale coverage detailed in JSON report. No auth/RBAC/source code changes. Native review, browser/RTL tests, and live application tests remain pending.
