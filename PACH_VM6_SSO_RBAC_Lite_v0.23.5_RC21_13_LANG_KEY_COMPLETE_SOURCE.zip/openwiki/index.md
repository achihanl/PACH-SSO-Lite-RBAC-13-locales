---
okf_version: "0.1"
---

# Files

- [Architecture Decisions (ARDs) and Spec](architecture.md) - Index of the full ARD inventory (ARD-001..015), the spec documents (01-08), the SOP, and surfaces.yaml, with cross-references to the wiki pages that expand each decision.
- [Directory Control CLI (directoryctl)](cli.md) - The AZBlink Directory CLI utility - status display and LDAP client credential lifecycle (provision/list/rotate/revoke) via the backend API using the dev auth token.
- [Testing Strategy](tests.md) - The layered test strategy - unit tests (nostack), stack-free contract gates (OpenAPI snapshot, auth matrix, middleware order), integration tests against the real Docker stack, arch-guard governance tests, and the QA manifest.

# Directories

- [backend](backend/)
- [deploy](deploy/)
- [frontend](frontend/)
- [tools](tools/)
