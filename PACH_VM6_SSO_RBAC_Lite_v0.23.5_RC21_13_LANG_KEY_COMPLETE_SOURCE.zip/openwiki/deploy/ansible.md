---
type: deployment
title: Production Deployment (Ansible + Bootstrap ISO)
description: Production provisioning - the VM bootstrap ISO (ARD-015), Ansible host_prep + azblink_app roles, autodeploy, preflight secret gates, Authentik LDAP source, prod admin reconciliation, and the deployment artifact (ARD-010).
tags: [deploy, ansible, production, bootstrap-iso, host-prep, autodeploy, ards]
---

# Production Deployment (Ansible + Bootstrap ISO)

Production provisioning is Ansible-on-VM target, covering `deploy/ansible/` and `deploy/bootstrap-iso/`.

## VM bootstrap ISO (`deploy/bootstrap-iso/`, ARD-015)

`build.py` turns a bare VM into a box Ansible can SSH into and converge, **with no keystrokes after "power on"**. The hypervisor's only input channel is an uploaded ISO (no cloud-init drive, no network at boot — the provisioner lives behind the VPN), so every per-VM fact (Ubuntu install, user, key, static address, guest agent) is baked in before upload; the ISO has zero network dependency during install.

- **Scope deliberately narrow:** it installs Ubuntu, a user, a key, a static address, and the guest agent. Docker, `just`, git, and the app are `deploy/ansible`'s job (`host_prep` + `azblink_app`) — avoiding a second source that defines what's on the box.
- **Handoff contract:** the ISO's only contract is *"SSH-reachable at a known address with a known key."* Then run `ansible-playbook site.yml`.
- **Usage:** fetch a source Ubuntu live-server ISO (24.04, ~3GB, gitignored), copy `hosts/example.env` → per-VM env, then `just bootstrap-iso-preview <name>` (render YAML), `just bootstrap-iso <name>` (→ `out/<name>.iso`), optional `just bootstrap-iso-test` (qemu/OVMF).
- `smoke-test.sh` post-build verification.

## Ansible (`deploy/ansible/`)

- `site.yml` — main entrypoint; `inventories/`, `ansible.cfg`, `requirements.yml`.
- **`roles/host_prep/`** — assert python3, install host utilities, Docker Engine + Compose v2 (only if absent), enable/start docker, verify compose plugin, install `just`, add deploy user to docker group.
- **`roles/azblink_app/`** — `main.yml` orchestrates in order:
  1. **preflight.yml** — prod secret-default gate (refuses to converge on shipped/placeholder/empty secrets): `ldap_admin_password`, `ldap_bind_pw`, `postgres_password`, `authentik_*`, `org_qr_signing_secret`, `dev_auth_token` **must be empty** in prod, `redis_password` non-empty, `grafana_admin_password != admin`, etc. Runs before fetch so a misconfigured prod converge fails fastest. No-op in dev/test/ci.
  2. `fetch.yml` (clone repo), `config.yml` (render `templates/env.j2` + `ldap_bootstrap.ldif.j2`), `deploy.yml` (bring up stack).
  3. `ldap_source.yml` — configure the Authentik LDAP source (ARD-007).
  4. `ldap_admin.yml` — prod-only: reconcile the real admin / OIDC admin group / Authentik sync bind account and **purge demo identities** left by a prior demo-seeded deploy (runtime tripwire in [System Router](../backend/routers/system.md)).
  5. `verify.yml` — post-deploy health verification.
  - `backup.yml` / `migrate.yml` are Bucket B deferred stubs (not wired active).

## Autodeploy (`deploy/ansible/autodeploy/`)

Launchd (`com.azblink.autodeploy.plist.template`) scheduled autodeploy: `azb-autodeploy.sh` runs periodic deploys; `install.sh` + `README.md`. Ties into the release flow (git tag → autodeploy picks it up).

## Deployment artifact (ARD-010)

Prod converges are owned by Ansible (not the Justfile). The compose topology, env rendering, and profiles are the deployment artifact ARD-010 codifies. See [Architecture ARD index](../architecture.md).

## Related pages

- [Dev Environment](dev.md) — the compose files Ansible deploys.
- [CI / Release](ci.md) — release + qa.
- [Web-Configure playbooks](web_configure.md) — downstream UC consumers.
- [Architecture](../architecture.md) — ARD-010/ARD-015/ARD-007.
