# Files

- [Production Deployment (Ansible + Bootstrap ISO)](ansible.md) - Production provisioning - the VM bootstrap ISO (ARD-015), Ansible host_prep + azblink_app roles, autodeploy, preflight secret gates, Authentik LDAP source, prod admin reconciliation, and the deployment artifact (ARD-010).
- [CI/CD Workflows](ci.md) - The GitHub Actions pipeline - fast PR gates (frontend lint/typecheck/test, python lint/mypy, stack-free backend unit + contract gates, diff-scoped Docker-stack backend tests + UC journey client), QA (Playwright e2e), dead-code scan, arch-guard, docs-lint, release, and openwiki updates.
- [Development Environment (Docker Compose)](dev.md) - The dev stack - services (API, UI, OpenLDAP, PostgreSQL, Redis, Authentik, Traefik, Prometheus/Loki/Grafana/Alloy), seed data, Justfile development recipes, and hot-reload wiring.
- [Web-Configure Playbooks](web_configure.md) - Operational Ansible playbooks (playbooks/web-configure) that configure relying-party UC servers consuming the directory - LDAP client, LDAP search, and SIP config per spec §08.
