---
type: deployment
title: Development Environment (Docker Compose)
description: The dev stack - services (API, UI, OpenLDAP, PostgreSQL, Redis, Authentik, Traefik, Prometheus/Loki/Grafana/Alloy), seed data, Justfile development recipes, and hot-reload wiring.
tags: [deploy, dev, docker-compose, stack, ldap, postgres, authentik, just]
---

# Development Environment (Docker Compose)

`deploy/dev/` is the local development stack. The `Justfile` composes it with `COMPOSE_FILE="docker-compose.yml:docker-compose.dev.yml"` and `COMPOSE_PROFILES="dev"`.

## Services (docker-compose.yml)

- **postgres** (postgres:16) — persistent, `azblink_directory` DB/user, healthcheck `pg_isready`.
- **redis** (redis:8-alpine) — rate limiting + caching + activity-bus fanout; password from `REDIS_PASSWORD` (empty in dev).
- **openldap** (osixia) — pre-seeded demo org structure; custom schema + config LDIFs from `deploy/dev/ldap/` (see [LDAP Client DIT](../backend/ldap_client.md)).
- **directory-api** — the [FastAPI backend](../backend/overview.md), `Dockerfile.api`, uvicorn.
- **directory-ui** — the [React UI](../frontend/overview.md); dev profile selects Vite HMR (`Dockerfile.ui-dev`) over prod nginx build.
- **traefik** — ingress/reverse proxy (also cloudflare-tunnel network).
- **authentik** — OIDC IdP + LDAP source (authentik-seed creates provider/app).
- **prometheus / loki / grafana / alloy** — observability stack (ARD-008).
- one-shot **seed** / **authentik-seed** services (exit 0 — why CI avoids `up --wait`).

`docker-compose.dev.yml` adds demo LDAP data + the seed service; `docker-compose.prod.yml`/`tls.yml` are prod-flavored variants.

## OpenLDAP config

`deploy/dev/ldap/` holds: `azblink.schema` (azblinkUser/azblinkOrganization AUXILIARY objectClasses), `asterisk-pjsip.schema`, `ppolicy-config.ldif` (pwdAccountLockedTime), `memberof-refint-config.ldif` (groupOfNames/member correction), `ldap-clients-acl.ldif` (ou=clients read-minus-secrets ACL), `logfile-config.ldif` (stats log), `bootstrap*.ldif`. Applied by osixia at first boot via `cn=config` (EXTERNAL). See [LDAP Client DIT](../backend/ldap_client.md).

## Justfile recipes

- `up` / `up-bg`, `down`, `reset` (`down -v`), `restart`.
- Hot reload: `ui`, `api-restart`, `api-rebuild`, `lock-backend` (regenerate `requirements.lock`, pip pinned to 25.3).
- Lint/test: `pr-checks`, `ui-lint`, `ui-format-check`, `ui-test-unit`, `ui-types`, `ui-routes`, `ui-build`.
- Health: `health`, `health-check`, `wait-healthy`, `recover`, `resync`, `connections` (host/port cheat sheet: PG localhost:5433, LDAP 1390, Redis 6380, API 8081).
- DB/LDAP: `psql`, `ldap-users`, `ldap-orgs`, `ldap-dump`.
- Release: `release`, `release-dry`, `cz-commit`.
- Bootstrap ISO: `bootstrap-iso-preview`, `bootstrap-iso`, `bootstrap-iso-test` (see [Ansible / Prod](ansible.md)).

## Focused validation

- Readiness gate used by CI: `just wait-healthy` (deep health: LDAP+PG+Redis+API) + Authentik OIDC discovery poll.

## Related pages

- [Backend Overview](../backend/overview.md), [CI](ci.md), [Ansible / Prod](ansible.md).
- `deploy/dev/.env.example` and `deploy/dev/README.md` / `DEPLOYMENT_SPEC.md` hold credentials + full spec.
