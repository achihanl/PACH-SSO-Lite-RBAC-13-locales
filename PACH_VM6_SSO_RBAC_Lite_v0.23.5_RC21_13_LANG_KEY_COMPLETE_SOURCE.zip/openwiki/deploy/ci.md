---
type: ci-cd
title: CI/CD Workflows
description: The GitHub Actions pipeline - fast PR gates (frontend lint/typecheck/test, python lint/mypy, stack-free backend unit + contract gates, diff-scoped Docker-stack backend tests + UC journey client), QA (Playwright e2e), dead-code scan, arch-guard, docs-lint, release, and openwiki updates.
tags: [ci, cd, github-actions, workflows, pr-checks, qa, release, arch-guard]
---

# CI/CD Workflows

All workflows live in `.github/workflows/`. PRs target `main`.

## pr-checks.yml — fast PR gate (< 5 min target)

- **frontend** — eslint (diff-scoped, `--max-warnings 0`), prettier `--check` (diff-scoped), `tsc` + vite build (full), vitest unit.
- **python-lint** — ruff `F,E,W,B --ignore E501` (diff-scoped), mypy lenient baseline (diff-scoped).
- **backend-unit** — `pytest tests/unit` + the **stack-free contract gates** (`-m nostack`): OpenAPI snapshot, auth-guard inventory, middleware order. Docker-free, ~30s. **Scoped to contract/ + unit/ deliberately** — the wider `tests/` pulls optional deps not installed here.
  - Sets dummy `UCCHAT_*` and `LDAP_BASE_DN=dc=azblink,dc=com` — the OpenAPI baseline was captured with the real value, so leaving it unset fails the snapshot gate on three schemas.
- **backend-tests** — full pytest against the real Docker stack, **diff-scoped** (triggers only on `src/backend tests migrations deploy Justfile tools/uc-journey-client tools/dev-seed-uc-user.py` changes). Starts the stack (no `--wait` because one-shot seeders exit 0), `just wait-healthy`, then polls Authentik OIDC discovery. Runs `pytest tests/ -m "not external_network"` + the **UC journey client** suite (unit + Tier-1 SSO→provision smoke) on the same stack. ~10–15 min when it runs.

## qa.yml — Playwright e2e

Playwright moved off PR to **tag push (`v*`) + nightly (04:00 UTC) + manual dispatch**. Installs workspace deps from root (openapi-typescript is a root devDependency), starts the Docker stack, waits for Authentik SSO, runs `playwright test --project=full`. SSO logs in via `QA_SSO_USER`/`QA_SSO_PASSWORD` secrets.

## dead-code.yml

PR fast scan (diff-scoped) + weekly full scan (Monday 06:00 UTC). `DEAD_CODE_STRICT=1` repo var makes PR fail on Tier-1 findings. SARIF upload removed (GHAS requires Advanced Security).

## arch-guard.yml + arch-guard-post-merge.yml

Architecture governance. The PR guard sparce-checks trusted guard sources (code **and** `surfaces.yaml`) from `main`, so a PR can't decide which of its own paths are governed (asserted by `test_ci_trusted_sources.py`). Triggers on `src/**, migrations/**, deploy/**, docs/architecture/**, CLAUDE.md, .github/workflows/**, Justfile, tools/arch_guard*`. Post-merge re-runs on `main` to catch squash-merge trailer loss.

## docs-lint.yml

Stdlib-only doc linter (`lint_docs.py`) with **no `paths:` filter** deliberately, so deleting/renaming a non-.md link target still triggers it.

## release.yml

On `v*` tag: git-cliff changelog (`cliff.toml`, `--latest --strip header`) + GitHub Release. Third-party actions SHA-pinned; needs `pull-requests: read`.

## openwiki-update.yml

Regenerates the OpenWiki wiki (this wiki).

## Related pages

- [Dev Environment](dev.md) — the stack CI boots.
- [Testing](../tests.md) — the suites the workflows run.
- [Tools: UC Journey client](../tools/uc_journey_client.md) — the CI-run journey gate.
