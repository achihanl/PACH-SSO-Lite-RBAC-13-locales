---
type: deployment
title: Web-Configure Playbooks
description: Operational Ansible playbooks (playbooks/web-configure) that configure relying-party UC servers consuming the directory - LDAP client, LDAP search, and SIP config per spec §08.
tags: [deploy, ansible, playbooks, uc, sip, ldap, integration]
---

# Web-Configure Playbooks

`playbooks/web-configure/` contains operational playbooks (a `schemaVersion` playbook format) that configure **relying-party UC servers** consuming the directory — the integration surface documented in [spec §08](../architecture.md).

## Playbooks

- **`azblink-server-ldap-client.yml`** — configure the LDAP client on the Azblink UC server (PED80 legacy PHP admin panel): variables for `SERVER_URL`, `ADMIN_USER/PASS`, `LDAP_HOST`, `LDAP_BASE_DN`, `LDAP_BIND_DN/PW`.
- **`azblink-server-ldap-search.yml`** — LDAP search config against the directory.
- **`azblink-server-sip-config.yml`** — SIP configuration (largest, 15KB) against the same target.

## Format

Each YAML has a header (`schemaVersion`, `id`, `title`, `created`, `lastRun`, `status`), a `target` (server-rendered admin panel, `tlsVerify: false` for legacy HTTP), `variables` (with `default`/`secret`/`pattern`), and steps. `templates/` hold rendered config; `screenshots/` document UI flows.

These playbooks are **external to the main AWS deploy stack** — they configure downstream UC consumers, and are referenced when [Provisioning](../backend/provisioning.md) credentials are consumed by UED/Asterisk (SIP) and XMPP servers.

## Related pages

- [Ansible / Production](ansible.md) — the main deploy roles.
- [Provisioning](../backend/provisioning.md) — credentials the consumers use.
- [LDAP Client / server DIT](../backend/ldap_client.md) — the data the consumers bind to.
