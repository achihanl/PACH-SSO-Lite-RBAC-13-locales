---
type: tool
title: Directory Control CLI (directoryctl)
description: The AZBlink Directory CLI utility - status display and LDAP client credential lifecycle (provision/list/rotate/revoke) via the backend API using the dev auth token.
tags: [cli, tool, ldap-client, directoryctl]
---

# Directory Control CLI (`directoryctl`)

`src/cli/directoryctl.py` is a small Python CLI for directory operations, invoked as `directoryctl`.

## Commands

- **`status`** — print a service/configuration summary from environment (LDAP URI/base DN, database URL, OIDC issuer/audience, Authentik API, auth mode).
- **`ldap-client provision <client_id>`** (`--label`, `--password`) — `POST /api/settings/ldap/clients/provisioned`.
- **`ldap-client list`** — `GET /api/settings/ldap/clients/provisioned`.
- **`ldap-client rotate <client_id>`** — `POST /api/settings/ldap/clients/provisioned/{client_id}/rotate`.
- **`ldap-client revoke <client_id>`** — `DELETE /api/settings/ldap/clients/provisioned/{client_id}`.

## How it talks to the backend

`api(method, path, body)` issues HTTP against `API_BASE` (default `http://localhost:8081`) using `DEV_AUTH_TOKEN` (default `dev-test-token`) as a Bearer token — the dev auth bypass (never enabled in prod; see [Backend Overview](backend/overview.md)). `_print` returns exit 0 on 2xx, 1 otherwise.

The LDAP-client operations delegate to [Settings Router LDAP client admin](backend/routers/settings.md) → [LDAP Provisioning](backend/provisioning.md).

## Related pages

- [Backend Overview](backend/overview.md) — DEV_AUTH_TOKEN bypass.
- [Settings Router](backend/routers/settings.md) — the endpoints the CLI drives.
- [Tools](tools/uc_journey_client.md) — the separate UC journey tooling.
