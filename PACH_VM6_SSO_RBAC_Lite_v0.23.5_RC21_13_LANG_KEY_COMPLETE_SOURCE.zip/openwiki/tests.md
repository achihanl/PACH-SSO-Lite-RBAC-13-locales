---
type: testing
title: Testing Strategy
description: The layered test strategy - unit tests (nostack), stack-free contract gates (OpenAPI snapshot, auth matrix, middleware order), integration tests against the real Docker stack, arch-guard governance tests, and the QA manifest.
tags: [testing, pytest, contract, unit, integration, arch-guard, qa]
---

# Testing Strategy

Tests live under `tests/`, with three marker/layer classes run differently in [CI](deploy/ci.md).

## Unit tests (`tests/unit`) — no stack, always on

Marked `-m nostack` where applicable; Docker-free, ~30s. Cover importable components (`test_smoke`, `test_ldap_errors_unit`, `test_ldap_conn_lifecycle`, `test_ldap_mapping_unit`, `test_auth_fail_open`, `test_oidc_verify_unit`, `test_activity_bus_fanout`, `test_ldap_activity_parser/classify`, `test_client_ip_unit`, `test_provisioning_unit`, `test_config_guard`, `test_response_utils`, `test_uc_validation_unit`, `test_version_cache_unit`, `test_account_lock_mirror`, `test_error_hygiene`, `test_authentik_seed_app_lookup`). Run by the `backend-unit` CI job without Docker.

## Contract gates (`tests/contract`) — the refactor guardrails

These enforce that the value refactor (single-file `main.py` → router/mixin modules) kept wire behavior identical:

- **`test_openapi_snapshot.py`** — backend OpenAPI is byte-identical to the committed baseline (`tools/openapi_baseline.py`).
- **`test_auth_matrix.py`** — every guarded route rejects anonymous callers + the declared guard is snapshotted (`tools/guard_inventory.py`). `INTENTIONALLY_PUBLIC` routes each need a reason.
- **`test_middleware_order.py`** — pins CORS-outermost nesting (see [Backend Overview](backend/overview.md)).
- **`test_response_shapes.py`**, **`test_db_surface.py`**, **`test_unschematised_routes.py`** — response/DB/surface contracts.
- `tests/contract` + `tests/unit` run `-m nostack` in CI with `LDAP_BASE_DN=dc=azblink,dc=com` so the OpenAPI baseline schema defaults match.

## Integration tests (`tests/` root) — real Docker stack

`pytest tests/ --ignore=tests/unit -m "not external_network"` against the dev stack: `test_users`, `test_org_groups` (incl. `TestMemberOfOverlay`), `test_provisioning*`, `test_device_provisioning`, `test_config_templates`, `test_rbac` (incl. `TestC1DirectoryReadAuthz`), `test_suspend`/`test_suspension_events`, `test_ldap_provisioning`, `test_security`/`test_ip_blocking`/`test_account_lock`, `test_health*`, `test_dashboard_api`, `test_self_service`, `test_audit*`, `test_settings*`, `test_uc_validation`, `test_sip_ring_e2e`, `test_xmpp_e2e`, etc. Diff-scoped trigger in `pr-checks.yml`.

## Arch-guard tests (`tests/arch_guard`)

Governance tests driven by `tools/arch_guard.py` + `docs/architecture/surfaces.yaml` — `test_backend_module_governance` (ARD-014), `test_ci_trusted_sources`, `test_guard_rules`, `test_real_surfaces`, `test_sop_section_lane`, `test_trailers`, `test_yaml_errors`, `test_ard_meta`.

## QA manifest (`qa/manifest.yml`)

Declares each UI page's path/assertions (visible, element counts, interactive, no-console-errors) used by Playwright + patrol in [qa.yml](deploy/ci.md).

## Related pages

- [CI / Release](deploy/ci.md) — which job runs which layer.
- [Backend Overview](backend/overview.md) — middleware-order contract.
- [OrgDB](backend/orgdb.md) — `test_db_surface`.
