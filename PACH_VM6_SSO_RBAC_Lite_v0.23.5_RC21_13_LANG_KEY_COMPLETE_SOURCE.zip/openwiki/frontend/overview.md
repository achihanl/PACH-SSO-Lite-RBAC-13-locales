---
type: application
title: Frontend Overview
description: The React admin UI - Vite + TanStack Router/Query + azblink-ui, OIDC PKCE Authentik login, Zustand auth/ui stores, typed API client, and the route tree.
tags: [frontend, react, vite, tanstack, oidc, overview]
---

# Frontend Overview

`src/frontend/` is the React admin UI (Vite + TypeScript). Entry: `src/main.tsx`.

## App composition

`main.tsx` wires the stack:

- `initializeApi(...)` configures the [API client](api_client.md) with auth handlers (`getAuthToken`, `onTokenRefreshed`, `onUnauthorized` → session-expired modal or `/login?redirect=`).
- React Query `QueryClient` (staleTime 30s, retry 1) + `RouterProvider` (TanStack Router) with `context: { queryClient }`.
- `useAuthStore`/`useUIStore` (Zustand, persisted) — see [Stores](#stores) below.
- `import '@/i18n'` initializes i18next; `<ThemeProvider>/<TooltipProvider>` from [azblink-ui](azblink_ui.md).

## OIDC PKCE login (`lib/oidc.ts`)

- RFC 7636 S256 code verifier/challenge via Web Crypto (`crypto.subtle`), with a pure-JS SHA-256 fallback for insecure LAN contexts.
- Builds authorize URL from OIDC discovery; token exchange; userinfo fetch; end-session URL. Backend only validates access tokens (no refresh-token storage — FIRA SEC-04).

## Stores

- `stores/auth-store.ts` — token/user/expiresAt; localStorage persistence; logout → Authentik end-session. `isAdmin` derived from `OIDC_ADMIN_GROUP` membership in claims.
- `stores/ui-store.ts` — session-expired modal, sidebar collapse, etc.

## Design system

UI components come from the [azblink-ui](azblink_ui.md) package, with layout (`layout/sidebar.tsx` 256px/64px responsive, `header.tsx`, `breadcrumb.tsx`) and feature components.

## Routes

See [Routes](routes.md) for the route tree (users, orgs, groups, provisioning, configuration, audit-log, my-profile, login).

## Key files

- `src/main.tsx`, `src/routeTree.gen.ts` (generated), `src/lib/oidc.ts`, `src/lib/api-client.ts`, `src/stores/*`, `src/components/layout/*`, `vite.config.ts`, `vitest.config.ts`, `package.json`.

## Related pages

- [API Client](api_client.md), [Routes](routes.md), [azblink-ui](azblink_ui.md).
- [Backend Overview](../backend/overview.md) — the API it calls.
