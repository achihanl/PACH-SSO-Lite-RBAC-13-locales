---
type: component
title: Frontend API Client
description: The typed fetch wrapper for the AZBlink backend - auth token injection, 401 refresh-token rotation, session-expired handling, and rate-limit retry-after.
tags: [frontend, api-client, fetch, auth, refresh-token]
---

# Frontend API Client

`src/frontend/src/lib/api-client.ts` is the shared HTTP layer for the frontend.

## Configuration

`initializeApi({ baseUrl, getAuthToken, getRefreshToken, onTokenRefreshed, onUnauthorized, onRateLimited })` sets a module-level client. `main.tsx` wires it to the Zustand [auth store](overview.md). `baseUrl` defaults to `import.meta.env.VITE_API_BASE || '/api'`.

## Behavior

- **Auth**: injects `Authorization: Bearer <token>` from `getAuthToken()`.
- **401 -> refresh rotation**: concurrent 401s are deduplicated (`_isRefreshing`); on refresh success, `onTokenRefreshed` updates the store; on failure calls `onUnauthorized(hadToken)`.
- **Unauthorized handling**: if a token was present → `showSessionExpiredModal()`; if not → redirect to `/login?redirect=<path>` (skipping public routes `/login`, `/auth/callback`, `/qr/` to avoid loops).
- **Rate limit**: `onRateLimited(retryAfter)`.
- Errors via `extractError` (`lib/errors.ts`).

## Typed requests

The client is generic `request<T>(method, path, body?, params?)`. Domain query hooks in `lib/queries/` wrap it with TanStack Query; types come from `lib/types/api.gen.ts` plus hand-authored domain types.

## Focused tests

- `src/lib/__tests__/` — API client + error handling unit tests.

## Related pages

- [Frontend Overview](overview.md) — app wiring.
- [Backend Overview](../backend/overview.md) — the API surface.
