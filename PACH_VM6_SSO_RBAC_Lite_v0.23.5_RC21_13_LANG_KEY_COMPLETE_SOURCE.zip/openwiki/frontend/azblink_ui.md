---
type: library
title: azblink-ui Design System
description: The Azblink React component library built on Base UI + CSS Modules - design tokens, primitives (Button, Input, Table, Card, Toggle, etc.), providers, and tree-shakeable exports.
tags: [frontend, ui, design-system, library, components, tokens]
---

# azblink-ui Design System

`src/frontend/packages/azblink-ui/` is the Azblink design system: a headless-first, accessibility-focused React component library built on Base UI + CSS Modules, with CSS-design-token theming.

## Features

- **Design tokens** — CSS custom properties for colors/typography/spacing (`tokens/`, imported as `@azblink/ui/tokens.css`).
- **Accessible** — Base UI, WCAG 2.1 AA.
- **Dark-mode-first**, tree-shakeable, full TypeScript.
- **Zero runtime styling** — CSS Modules, no CSS-in-JS.

## Exports (`index.ts`)

- **Primitives**: `Button`, `Toggle`, `ToggleCard`, `Badge`, `Input`, `Label`, `Skeleton`, `Card` + subcomponents (`CardHeader/CardTitle/CardDescription/CardAction/CardContent/CardFooter`), `ContentArea`, `Table` + subcomponents (`TableHeader/TableBody/TableFooter/TableRow/TableHead/TableCell/TableCaption`), `Pagination`, `Checkbox`, `AlertDialog` (+ `AlertDialogTrigger/...`), and more.
- **Providers**: `ThemeProvider`, `TooltipProvider`, `TooltipTrigger`, `TooltipContent`.
- **Utilities**: `cn` (classname merge), etc.
- All have exported `*Props`/`*Variant`/`*Size` types.

## Build

Bundled with `tsup` (`tsup.config.ts`); browser dev HMR aliases the package to source in `vite.config.ts`. Workspace-scoped in the root `package.json` (`@azblink/ui`).

## Focused tests / consumers

- Consumed throughout `src/frontend/src/components/` (layout + feature components).
- The library README documents setup (`@azblink/ui/tokens.css` + `@azblink/ui/styles.css`).

## Related pages

- [Frontend Overview](overview.md) — how the app consumes the design system.
