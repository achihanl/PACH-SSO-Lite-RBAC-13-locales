# Files

- [Frontend API Client](api_client.md) - The typed fetch wrapper for the AZBlink backend - auth token injection, 401 refresh-token rotation, session-expired handling, and rate-limit retry-after.
- [azblink-ui Design System](azblink_ui.md) - The Azblink React component library built on Base UI + CSS Modules - design tokens, primitives (Button, Input, Table, Card, Toggle, etc.), providers, and tree-shakeable exports.
- [Frontend Overview](overview.md) - The React admin UI - Vite + TanStack Router/Query + azblink-ui, OIDC PKCE Authentik login, Zustand auth/ui stores, typed API client, and the route tree.
- [Frontend Routes and Pages](routes.md) - The TanStack Router route tree of the admin UI - directory (users, orgs, groups), provisioning, configuration (org-profiles, settings, ldap-clients), audit-log, auth/login, and my-profile.
