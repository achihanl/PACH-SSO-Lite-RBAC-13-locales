---
type: tool
title: UC Journey Client
description: A single Python tool walking the whole UC onboarding journey end-to-end (SSO -> device provision -> credential unseal -> XMPP connect -> SIP register -> verdict), with headless and --gui modes, plus sibling tools web-sso-provision-ref and dev-seed-uc-user.
tags: [tools, uc, journey, xmpp, sip, provisioning, reference, ci]
---

# UC Journey Client

`tools/uc-journey-client/` is a single launchable Python tool that walks the **entire UC onboarding journey end-to-end**:

```
SSO login → device provision → credential unseal → XMPP connect → SIP register → verdict
```

It is the reference implementation that future clients (mobile, desktop, other services speaking XMPP/SIP) can diff against. Full design rationale: `docs/superpowers/specs/2026-07-04-uc-journey-client-design.md`.

## Headless vs `--gui`

- **Headless (`cli.py`, default)** — CI-usable; non-zero exit if any *attempted* leg fails.
- **`--gui` (`server.py` + `web/`)** — serves the unmodified `web-sso-provision-ref` page and extends it with the transport legs (it does not fork/duplicate it).

## Tier 1 vs Tier 2 (read this first)

The dev Docker stack has **no XMPP or SIP server** (those only exist on lab hardware), so success is split:

- **Tier 1 — stack-only (`--legs provision`, default):** SSO token acquisition + `POST /api/provision/device` + sealed-box unseal. Needs only the dev stack (`just up`). **This is the CI-runnable gate.**
- **Tier 2 — transport (`--legs xmpp|sip|all`):** actually connects to the lab XMPP host (`192.168.122.89:5222`, domain `private.z`) and/or lab SIP/UED host (`192.168.122.220:5060`). Without `--xmpp-host`/`--sip-host` pointing at a reachable lab host, the xmpp/sip leg reports **`SKIP`** (not `FAIL`); pass `--require-transport` to turn skips into failures.

Exit code is non-zero if any **attempted** leg fails; `SKIP` alone never fails the run.

## Modules

- `journey/runner.py` — orchestrates the steps; `oidc.py` (SSO auth), `provision.py` (device provision + unseal), `sip_leg.py` (MD5-digest REGISTER to SIP/UED), `xmpp_leg.py` (SASL PLAIN bind to XMPP), `report.py`, `config.py`, `models.py`.
- `server.py`, `web/` — the `--gui` server.

## How it differs from web-sso-provision-ref

`tools/web-sso-provision-ref/` is a browser-only debugger that stops at the credential handoff (SSO → provision → unseal) and explicitly hands the displayed credentials off for someone else to verify. The UC journey client **is** that "someone else": it takes the unsealed credential kit and actually connects.

## CI role

`.github/workflows/pr-checks.yml` (the `backend-tests` job, diff-scoped) runs this tool's pytest suite on the live Docker stack: unit tests + the Tier-1 SSO→provision smoke. `tools/dev-seed-uc-user.py` seeds UC users for these journeys.

## Focused tests

- `tools/uc-journey-client/tests/` — its own suite (run by CI).

## Related pages

- [Provisioning](../backend/provisioning.md) — the workflow this tool walks.
- [Provisioning Router](../backend/routers/provisioning.md) — the HTTP surface it consumes.
- [CI / Release](../deploy/ci.md) — where it gates.
- [Dev Environment](../deploy/dev.md) — the Tier-1 stack.
