# Files

- [UC Journey Client](uc_journey_client.md) - A single Python tool walking the whole UC onboarding journey end-to-end (SSO -> device provision -> credential unseal -> XMPP connect -> SIP register -> verdict), with headless and --gui modes, plus sibling tools web-sso-provision-ref and dev-seed-uc-user.
