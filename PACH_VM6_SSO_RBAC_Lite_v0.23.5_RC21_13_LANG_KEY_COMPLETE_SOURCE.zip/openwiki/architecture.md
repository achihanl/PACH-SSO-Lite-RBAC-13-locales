---
type: reference
title: Architecture Decisions (ARDs) and Spec
description: Index of the full ARD inventory (ARD-001..015), the spec documents (01-08), the SOP, and surfaces.yaml, with cross-references to the wiki pages that expand each decision.
tags: [architecture, ard, spec, decisions, sop, reference]
---

# Architecture, ARDs, and Spec

The canonical architecture source of truth lives under `docs/architecture/` (spec per `docs/architecture/SOP.md`). This page indexes it and maps decisions to the wiki pages that expand them.

## ARD inventory (ARD-001 .. ARD-015)

Status is not reproduced below and drifts; read the `status` frontmatter in `docs/architecture/decisions/`. As of 2026-08-11, ARD-007, 008, 010 and 015 are `proposed` — the rest are `accepted`.

| ARD | Title | Expands |
|-----|-------|---------|
| ARD-001 | Single LDAP architecture | [LDAP Client + DIT](backend/ldap_client.md) |
| ARD-002 | Authentik-only auth (no breakglass) | [Auth Ladder](backend/auth.md) |
| ARD-003 | Authentik dev stack | [Dev Environment](deploy/dev.md) |
| ARD-004 | Profile services | [Config Templates](backend/config_templates.md) |
| ARD-005 | Spec governance hardening | ([tests/arch_guard](tests.md)) |
| ARD-006 | LDAP client-provisioning reconciliation | [Provisioning](backend/provisioning.md), [Settings](backend/routers/settings.md) |
| ARD-007 | Authentik LDAP source | [Ansible / Prod](deploy/ansible.md), [LDAP DIT](backend/ldap_client.md) |
| ARD-008 | Observability stack | [Observability](backend/observability.md) |
| ARD-009 | Directory-read authorization | [Auth Ladder](backend/auth.md), [Tests](tests.md) |
| ARD-010 | Production deployment artifact | [Ansible / Prod](deploy/ansible.md) |
| ARD-011 | Redis fanout + middleware order | [Activity Bus](backend/activity_bus.md), [Backend Overview](backend/overview.md) |
| ARD-012 | Auth degraded-store posture | [Auth Ladder](backend/auth.md), [Security](backend/security.md) |
| ARD-013 | LDAP connection lifecycle | [LDAP Client](backend/ldap_client.md) |
| ARD-014 | Backend module governance | [Backend Overview](backend/overview.md), [Tests](tests.md) |
| ARD-015 | VM host bootstrap ISO | [Ansible / Prod](deploy/ansible.md) |

## Spec documents

`docs/architecture/spec/`: `01-system-overview`, `02-component-architecture`, `03-data-architecture`, `04-authentication`, `05-provisioning`, `06-deployment`, `07-security`, `08-integration-points`.

## SOP & surfaces

- `docs/architecture/SOP.md` — how the spec and ARDs are versioned.
- `docs/architecture/surfaces.yaml` — the governed module/device surfaces arch-guard enforces (incl. the `ldap_schema` surface grouping `ldap_client.py`/`ldap_provisioning.py`/`ldap_activity.py` with `deploy/dev/ldap/**` as the two halves of ARD-006).
- `docs/architecture/README.md`, `docs/architecture/decisions/_TEMPLATE.md`.

## Related pages

- [Backend Overview](backend/overview.md)
- [Testing](tests.md) — arch-guard enforcement.
