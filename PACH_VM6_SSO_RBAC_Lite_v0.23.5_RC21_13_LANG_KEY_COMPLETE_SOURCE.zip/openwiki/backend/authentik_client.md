---
type: component
title: Authentik Admin API Client
description: The Authentik Admin API v3 client for session/token revocation and user lookup on termination, plus app seeding.
tags: [backend, authentik, client, session-revocation, oidc, termination]
---

# Authentik Admin API Client

`src/backend/authentik_client.py` is a stateless client for the Authentik Admin API v3, used for admin operations (revocation), not authentication.

## Surface

- **`_api_request(method, path, body=None)`** — authenticated request with `Authorization: Bearer <api_token>`; 204 → None, else JSON. Raises `AuthentikError` on HTTP/URL errors.
- **`_find_user_pk(username)`** — resolve a user's Authentik primary key.
- **Session/token revocation**: revoke user sessions and revoke OAuth2 access/refresh tokens on termination. Documented gotcha: `end_session` does NOT revoke tokens — must explicitly DELETE.
- **App seeding** (used by the deploy/seed tooling): `tools/dev-seed-uc-user.py` and tests exercise seed app lookup (`unit/test_authentik_seed_app_lookup.py`).

Configured only when `AUTHENTIK_API_URL` and `AUTHENTIK_API_TOKEN` are set (`deps.authentik_client` is `None` otherwise; callers check `.configured`).

## Usage

In the [Users Router](routers/users.md) termination flow, after disabling the LDAP user, the backend revokes Authentik sessions and tokens via this client. Under the ARD-012 fail-open posture, a revocation write failure should not fail the request (logged, surfaced as a warning in the termination summary).

## Focused tests

- `tests/test_authentik_client.py` — revocation/revoke behavior.
- `tests/unit/test_authentik_seed_app_lookup.py` — app seeding lookup.

## Related pages

- [Auth Ladder](auth.md) — the OIDC verification side (token validation).
- [Users Router](routers/users.md) — termination orchestration.
- [UC Client](uc_client.md) — the parallel stub pattern for UC session termination.
