---
type: subsystem
title: OIDC Auth Ladder and Authorization
description: The Authentik OIDC auth ladder (require_user, require_admin, require_permission, require_directory_read), account-lock/auto-IP-block enforcement, RBAC, auth-failure dedup, degraded-store posture, and WebSocket token verification.
tags: [backend, auth, oidc, authentication, rbac, authorization, account-lock, degraded]
---

# OIDC Auth Ladder and Authorization

`src/backend/auth.py` implements the Authentik OIDC auth ladder plus the enforcement that rides on it. `oidc_verify.py` does token verification.

## The ladder (weakest → strongest)

- **`require_user`** — valid OIDC bearer token. `_claims_from_auth_header` verifies via `verify_bearer_token`. On invalid token (non-infra), it records an auth failure, may auto-block the IP (DS-2), and returns 401. After successful verification, `_enforce_account_lock(uid)` runs.
- **`require_admin`** — `require_user` + membership of `OIDC_ADMIN_GROUP`. Intentionally used only for bootstrap/UC-validation endpoints needing admin access without granular RBAC (FIRA ARCH-01).
- **`require_permission(p)`** — `require_user` + RBAC permission p with **admin group as fallback**. `uid = preferred_username or uid or sub` (note: OIDC sub is a hashed ID in Authentik hashed_user_id mode — not usable as LDAP uid). On RBAC lookup failure it logs through `DegradedSite` and falls through to the OIDC admin-group check (see posture).
- **`require_directory_read`** — `require_user` + ANY of `_MANAGEMENT_PERMISSIONS = {user_management, org_management, device_provisioning, audit_log_access, system_configuration}` or admin. Gates directory-wide / arbitrary-target reads so a self-service user cannot enumerate the directory; does NOT gate `/api/me*` (scoped to caller). C1, Model A — one deployment per tenant (ARD-009).

## Account-lock & IP-block enforcement (DS-1/DS-2)

- After valid token: `_enforce_account_lock(uid)` — `ORGDB.check_account_locked`; on PG read failure it fails **closed** via the Redis mirror (`account_lock_mirror.read_lock`): LOCKED → 403; UNKNOWN (both stores down / sentinel absent) → **503**; NOT_LOCKED → pass. Per ARD-012 this is the deliberate change from the old swallow-and-continue that let a locked account with the admin-group claim regain admin during a PG outage.
- Auto-lock/auto-block thresholds: `AUTH_FAILURE_WINDOW_MINUTES=15`, `IP_BLOCK_FAILURE_THRESHOLD=20`, `IP_BLOCK_DURATION_HOURS=1`.
- **Auth-failure dedup** (`AUTH_FAILURE_DEDUP_SECONDS=10`): same bad token fingerprint within the window counts once — fixes parallel-fanout lockout (a dashboard mount firing 5 requests with one stale token would otherwise record 5 failures and trip the lock instantly) while preserving brute-force defense (distinct tokens each counted). Prefers Redis for worker-independence; falls back to an in-memory dict (correct for single-worker dev/test).
- `_locked_response` → 403 `{error: ACCOUNT_LOCKED, locked_until}`.

## Degraded-store posture (ARD-012)

Six store-backed authorization reads are wrapped; `DegradedSite` logs one WARNING entering / one INFO on recovery (never per-request):

- Account-lock check — **fails CLOSED** (503) when both stores unreachable.
- RBAC lookup (`get_user_permissions`) — falls through to admin-group check (deliberate; group membership rides in the verified token, keeping outage recoverable under ARD-002's no-breakglass).
- Directory-read RBAC — same fall-through.
- Audit + IP-auto-block write paths — **fail open** deliberately (failing a request because a write failed turns a degraded audit trail into a DoS).

`tests/unit/test_auth_fail_open.py` pins all of it.

## WebSocket token verification

`verify_ws_token(token)` — the WebSocket carries its token as a query param, not a header, so it can't reuse the `Depends()` ladder. Shares `DEV_AUTH_CLAIMS` with REST so the two can't drift. `DEV_AUTH_CLAIMS` = the dev/test bypass (`DEV_AUTH_TOKEN`), single-sourced here since both the WS handler and REST ladder use the same principal.

## OIDC verification (`oidc_verify.py`)

- `verify_bearer_token` — fetches OIDC discovery + JWKS (cached 600s), verifies Bearer access tokens. `OIDCInfraError` (Authentik down / JWKS unreachable) is an infrastructure fault → HTTP 503, **not** counted toward account-lock/IP-block thresholds. `InvalidConfigurationError` (e.g. no issuer allow-list) is a misconfiguration → 503, not blamed on the token.
- Refresh is frontend-only (PKCE silent-refresh); backend only validates access tokens — does not store/rotate/revoke refresh tokens (FIRA SEC-04).
- `OIDC_ACCEPTED_ISSUERS` allows trailing-slash variants (Authentik includes a trailing slash in `iss`).

## Focused tests

- `tests/contract/test_auth_matrix.py` — static + runtime guard matrix (63 routes require_permission, 16 require_directory_read, 8 require_admin, 7 require_user); snapshots the declared guard on every route and verifies anonymous rejection.
- `tests/test_rbac.py` (incl. `TestC1DirectoryReadAuthz`), `tests/unit/test_auth_fail_open.py`, `tests/unit/test_oidc_verify_unit.py`.

## Related pages

- [Security](security.md) — lock/IP machinery + mirror + DegradedSite.
- [OrgDB](orgdb.md) — RBAC/audit storage.
- [Backend Overview](overview.md) — middleware order.
- [Architecture](../architecture.md) — ARD-002, ARD-009, ARD-012.
