---
type: subsystem
title: LDAP Activity - Stats-Log Collector and Session Correlator
description: Parses slapd's stats log, correlates ACCEPT/BIND/closed lines into sessions, classifies clients by bind DN + source IP, and yields connected-now snapshots.
tags: [backend, ldap-activity, stats-log, collector, sessions, classify, inventory]
---

# LDAP Activity — Stats-Log Collector and Session Correlator

`ldap_activity.py` reads OpenLDAP's stats log (produced by `logfile-config.ldif`, see [LDAP Client](ldap_client.md)) to observe real LDAP client sessions and feed the inventory.

## Pipeline

- `parse_line(line)` → `LineEvent{conn, kind, ip?, dn?, mech?}` where `kind ∈ {accept, bind, closed}`. Grammar verified against `osixia/openldap:1.5.0` (`-d 256`): `_CONN_RE` (conn=N), `_ACCEPT_RE` (ACCEPT from IP=…), `_BIND_RE` + `_MECH_RE`, `_CLOSED_RE`. `_strip_port` handles `host:port` / `[v6]:port`.
- `SessionTracker` — correlates `conn=N` across lines into a completed `Session{source_ip, bind_dn, mech}` + a live open-conn snapshot.
- `classify(bind_dn, source_ip)` → service string: `healthcheck` | `<cidr-svc>` (from `LDAP_KNOWN_SERVICE_CIDRS`) | `xmpp` | `provisioned_client` | `unknown`.
- `run_ldap_activity_collector` — lifespan-managed async task: tails the log, upserts completed sessions into OrgDB (`LdapInventoryMixin.upsert_ldap_session`).
- `get_connected_now()` — `(dn, ip)` of currently-open connections for the API layer (LDAP client inventory view, see [Settings Router](routers/settings.md)).

## Data flow

```
slapd stats log => parse_line => SessionTracker => classify => upsert_ldap_session (OrgDB ldap_clients)
```

`upsert_ldap_session` (db/ldap_inventory.py) INSERTS a new `(bind_dn, source_ip)` row with `session_count=1` or ON CONFLICT bumps `last_seen`/`session_count`; admin-set status/label/acknowledged fields are NOT in `set_` → preserved. `provisioned_client` sessions are auto-acknowledged; others start `unknown`.

## Focused tests

- `tests/unit/test_ldap_activity_parser.py`, `tests/unit/test_ldap_activity_classify.py`.

## Related pages

- [LDAP Client](ldap_client.md) — logfile-config + ACL.
- [Settings](routers/settings.md) — LDAP client inventory listing.
- [OrgDB](orgdb.md) — LdapInventoryMixin.
- [Provisioning](provisioning.md) — provisioned-client reconciliation (ARD-006/007).
