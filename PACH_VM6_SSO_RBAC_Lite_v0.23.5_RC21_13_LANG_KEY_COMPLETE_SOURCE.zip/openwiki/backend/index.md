# Files

- [Activity Bus (Real-Time Event Fan-Out)](activity_bus.md) - The pub/sub event bus for real-time activity delivery - per-subscriber asyncio queues, Redis cross-worker fan-out, fallback to local delivery, and the multi-worker failure it fixes.
- [OIDC Auth Ladder and Authorization](auth.md) - The Authentik OIDC auth ladder (require_user, require_admin, require_permission, require_directory_read), account-lock/auto-IP-block enforcement, RBAC, auth-failure dedup, degraded-store posture, and WebSocket token verification.
- [Authentik Admin API Client](authentik_client.md) - The Authentik Admin API v3 client for session/token revocation and user lookup on termination, plus app seeding.
- [Config Templates, Profile Services, and UC Resource Allocation](config_templates.md) - Config template CRUD, org assignment, profile services (XMPP/SIP), uidNumber/SIP-extension allocation, endpoint validation (DNS SRV + WS), history, and cloning.
- [LDAP Activity - Stats-Log Collector and Session Correlator](ldap_activity.md) - Parses slapd's stats log, correlates ACCEPT/BIND/closed lines into sessions, classifies clients by bind DN + source IP, and yields connected-now snapshots.
- [LDAP Client + OpenLDAP Server DIT](ldap_client.md) - The LDAP abstraction layer (all directory operations, connection lifecycle, user/group/org lifecycle, UC attribute builder) plus the OpenLDAP server-side DIT: custom schema, ppolicy/memberOf overlays, client ACL, and stats-log config.
- [Observability - Metrics, Logging, Probes, Version Cache](observability.md) - Prometheus metrics, structured JSON logging with request-ID correlation, the service-reachability probe, and the version-cache freeze/retry logic.
- [OrgDB - PostgreSQL Storage and Schema Migration Lane](orgdb.md) - PostgreSQL storage composed from per-domain mixins, the two-schema-authority invariant (create_all adds-only vs migrations ALTERs), table-to-mixin ownership, and seeding.
- [Backend Overview - Application Composition](overview.md) - The FastAPI app composition - lifespan init/teardown, middleware order, router registration, process-wide singletons in deps.py, and startup configuration guards.
- [Device Provisioning and UC Credential Delivery](provisioning.md) - One-time provision tokens, E2E-encrypted UC credential delivery (Curve25519 + libsodium sealed box), device caps, SSO device provisioning, LDAP client provisioning, compliance alerts, and provisioning audit.
- [Rate Limiting, IP Blocking, and Request Audit](rate_limiting.md) - Redis-backed slowapi rate limiting, the IP-blocking middleware, the trusted-proxy X-Forwarded-For resolution, per-route limits, and the optional API request audit.
- [Security - Account Locks, IP Blocking, and the Degraded-Store Mirror](security.md) - Account lock mechanism (DS-1), IP blocking (DS-2), auth-failure accounting, the Redis account-lock mirror with completeness sentinel (ARD-012), and the DegradedSite log-once helpers.
- [UC Server Client (Stub)](uc_client.md) - The UC Server (SIP/XMPP session management) client — currently a stub for terminate_user_sessions with graceful degradation.

# Directories

- [routers](routers/)
