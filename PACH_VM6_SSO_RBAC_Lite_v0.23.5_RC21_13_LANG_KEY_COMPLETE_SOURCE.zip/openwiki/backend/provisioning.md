---
type: system
title: Device Provisioning and UC Credential Delivery
description: One-time provision tokens, E2E-encrypted UC credential delivery (Curve25519 + libsodium sealed box), device caps, SSO device provisioning, LDAP client provisioning, compliance alerts, and provisioning audit.
tags: [backend, provisioning, devices, tokens, curve25519, libsodium, qr, e2e, compliance]
---

# Device Provisioning and UC Credential Delivery

This page covers the whole provisioning surface: the token issue/validate/consume flow, the SSO device-provision flow that seals UC credentials, provisioning ops (bulk revoke/extend/list/compliance), the LDAP client-credential provisioning service, and the audit trail.

## One-time token flow (`routers/provisioning.py`)

- `POST /api/provision/validate` (`TokenValidateReq`) — hashes token (`sha256`), `ORGDB.validate_and_consume_token`, consumes single-use. Errors: TOKEN_NOT_FOUND→404, TOKEN_EXPIRED→410, TOKEN_ALREADY_CONSUMED→409, else 400. Records a `provisioning` audit (`action=consumed`).
- `POST /api/provision/consume` (`ProvisionConsumeReq`) — same token validation, then builds Phase-1 UC config (Plane A LDAP bind): `config.xmpp.jid = uid@UCCHAT_XMPP_DOMAIN`, `config.sip.uri = sip:uid@UCCHAT_SIP_DOMAIN`, `authMethod: ldap_bind`, with optional `wsUrl`/`wssUrl`. No passwords returned — client uses LDAP bind with its own credentials. Records device info best-effort + audit.

Both are **intentionally public** (authenticated by the token itself), declared in the auth matrix.

## SSO device provisioning (`POST /api/provision/device`, `DELETE /api/provision/device/{device_id}`)

`api_provision_device` (rate-limited per-user via `_device_provision_key`):

1. `require_user` → `uid = preferred_username or sub`.
2. Validate the Curve25519 public key (base64, exactly 32 bytes; `nacl.public.PublicKey`); consult [Auth](auth.md).
3. Resolve user in LDAP (`get_user`); 403 NOT_UC_PROVISIONED if absent.
4. Resolve config template via `azblinkProfileId` → profile services → xmpp/sip enablement, domains/URLs, `max_devices`.
5. **Device cap**: `ORGDB.count_active_device_provisions(uid, exclude_device_id=req.deviceId)` ≥ max → 409 DEVICE_CAP_REACHED (re-provision aware).
6. Read UC credentials from LDAP (`get_uc_credentials`) — XMPP `azbXmppBindPassword`, SIP `AstAuthPassword`; 500 if enabled-but-missing.
7. **Seal** the credential payload (`{xmppPassword, sipPassword, sipUsername=uid}`) with `nacl.public.SealedBox(client_pk)` → base64.
8. Compute `pk_hash = sha256(pk_bytes)`, `expires_at = now + DEVICE_PROVISION_TTL_SEC`; upsert the device provision (token_hash generated internally), record audit with `device_cap_used/cap_max`.
9. Return `{sealedCredentials, endpoints{xmpp:sip}, provisioned{xmppEnabled,sipEnabled}, expiresAt}`.

`DELETE /api/provision/device/{device_id}` — user revokes their own device (sets status=revoked, frees a cap slot); 404 if not found/not-owner.

## Provisioning ops (`/api/provisioning/*`, `require_permission("device_provisioning")`)

- `POST /api/provisioning/tokens/bulk-revoke` (`BulkRevokeReq`, max 100) — revoke active/non-expired; per-token skip reasons; audit `bulk-revoked`.
- `POST /api/provisioning/tokens/{token_hash}/extend` (`ExtendTokenReq`) — capped at `DEVICE_PROVISION_MAX_EXTEND_SEC`; error mapping NOT_FOUND/NOT_ACTIVE/EXPIRED/EXCEEDS_MAX_TTL → 404/400/422.
- `GET /api/provisioning/devices` — paginated list (limit/offset/search/date_range/platform).
- `GET /api/provisioning/devices/{device_id}/history` — per-device token history.
- `GET /api/provisioning/compliance` — compliance alerts, **60s cached** (`_compliance_cache`), `?refresh=1` recomputes (30/min limit to cap PG recompute pressure).
- `GET /api/provisions/pending` (`require_admin`) — pending tokens + user details for the dashboard card; uses `get_users_batch` (N+1 fix); when LDAP is down it returns the raw list so the stat count and list stay consistent (matches dashboard fallback); skips "orphan" tokens whose uid has no LDAP user.

## UC resource allocation (`provisioning.py`)

`allocate_uc_resources(orgdb, profile_id, services)` — inspects services for enabled xmpp/sip; `allocate_uid_number(profile_id)` (all UC schemas), `allocate_extension(profile_id)` + `generate_sip_password()` when SIP enabled (24 chars from `_SIP_PW_ALPHABET` = letters+digits+`!@#%^&*-_=+`, no ambiguous chars). Returns `ProvisioningResult{uid_number, extension, sip_password}` or None. `ExtensionRangeExhausted` raised out of TemplatesMixin and caught in users.py.

## LDAP client provisioning (`ldap_provisioning.py`)

Provision/rotate/revoke platform **LDAP client credentials** (ARD-006):

- Client entry: `cn=<client_id>,ou=clients,<base>` (`organizationalRole` + `simpleSecurityObject`); read granted by the static bootstrap ACL (`ldap-clients-acl.ldif`).
- `provision(client_id, label, created_by, password?)` — validate slug (`^[a-z0-9][a-z0-9-]{1,30}$`); strong secret via `secrets.token_urlsafe(18)` or operator-supplied (≥12 chars, upper+lower+digit); creates LDAP entry + registry row (`ldap_provisioned_clients`); **compensating rollback** deletes the LDAP entry if the registry write fails (never leaves an unattributed orphan).
- `rotate(client_id, password?)` — new secret on existing non-revoked client.
- `revoke(client_id)` — delete LDAP entry + mark registry revoked.
- `list_clients()` — non-revoked registry rows (no secrets); secret is never persisted (only the DN reference).

## Provisioning audit

`record_provisioning_audit(action, actor, target_uid, device_id?, token_hash?, auth_method?, platform?, client_ip?, detail?)` — every issue/consume/revoke/extend/bulk-revoke records to `provisioning_audit`, published to the activity bus.

## Focused tests

- `tests/test_device_provisioning.py`, `tests/test_provisioning.py`, `tests/test_provision_consume.py`, `tests/test_provisioning_ops.py`, `tests/test_provisioning_audit.py`, `tests/unit/test_provisioning_unit.py`, `tests/test_ldap_provisioning.py`, `tests/test_orgdb_device.py`.
- End-to-end credential journey: `tools/uc-journey-client` (see [Tools](../tools/uc_journey_client.md)).

## Related pages

- [LDAP Client](ldap_client.md) — UC attrs, `get_uc_credentials`, OU clients.
- [OrgDB](orgdb.md) — DevicesMixin, TemplatesMixin, LdapInventoryMixin.
- [Config Templates](config_templates.md) — profile services driving enablement.
- [Auth](auth.md) — guards.
- [Deploy](../deploy/dev.md) / [Architecture](../architecture.md) — ARD-006, ARD-007.
