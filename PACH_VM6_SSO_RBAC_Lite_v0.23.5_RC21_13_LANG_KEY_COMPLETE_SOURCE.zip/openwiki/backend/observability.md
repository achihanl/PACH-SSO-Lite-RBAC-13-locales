---
type: subsystem
title: Observability - Metrics, Logging, Probes, Version Cache
description: Prometheus metrics, structured JSON logging with request-ID correlation, the service-reachability probe, and the version-cache freeze/retry logic.
tags: [backend, observability, prometheus, metrics, logging, health-probe, version-cache]
---

# Observability — Metrics, Logging, Probes, Version Cache

`observability.py` provides metrics, request correlation, and service probes (ARD-008). Middleware ordering is decided in `main.py` (see [Backend Overview](overview.md)).

## Prometheus metrics (scraped via `GET /metrics`)

- `azblink_http_requests_total{method,path,status}`, `azblink_http_request_duration_seconds{method,path}`, `azblink_http_requests_in_flight`. **Path label = matched route TEMPLATE, never the raw URL** (unmatched routes label `unmatched`) — bounded cardinality.
- `azblink_service_up{service}` — service reachability, probed every 20s (see probes).
- `azblink_rate_limit_rejections_total` (defined in rate_limit.py).

## Middleware

- `MetricsMiddleware` — records per-request metrics; sits outside IPBlocking so rejections are counted.
- `RequestIDMiddleware` — injects a per-request X-Request-ID and correlates log lines.
- Middleware order relative to CORS/IPBlocking is pinned by `tests/contract/test_middleware_order.py`.

## Logging (ARD-008)

`config.setup_logging()` — structured JSON stdout logging + request-id injection, configured before any module logger emits.

## Service-reachability probes (ARD-008)

cadvisor can't produce per-container metrics on this host's containerd-snapshotter, so a lifespan task (`run_service_health_probe` in main.py) polls each platform service and exports `azblink_service_up` 1/0. Fixed Docker-network DNS targets (hardcoded, mirrors compose service names): TCP — authentik-server:9000, traefik:80, directory-ui:5173; HTTP — prometheus:9090/-/healthy, loki:3100/ready, grafana:3000/api/health, alloy:12345/-/ready.

## Version cache (`version_cache.py`)

Backs `GET /api/system/versions`. Each probe is **frozen once it SUCCEEDS** (source != "unknown"); a failed probe is left uncached so the next request retries it (self-heals a cold dependency, no restart). PG/Redis versions freeze permanently (`ttl=None`); Authentik's probe carries a short TTL (its version_latest/outdated is recomputed by Authentik's upstream update-check). Extracted from main.py so the freeze/retry/ttl logic is unit-testable without a live stack.

## Focused tests

- `tests/test_observability.py`.
- `tests/unit/test_version_cache_unit.py` — freeze/retry/ttl.
- `tests/contract/test_middleware_order.py`, `tests/test_health_deep_services.py`.

## Related pages

- [Backend Overview](overview.md) — middleware order + lifespan tasks.
- [System Router](routers/system.md) — /metrics, /api/system/versions, health.
- [Rate Limiting](rate_limiting.md) — rejection metric.
- [Architecture](../architecture.md) — ARD-008.
