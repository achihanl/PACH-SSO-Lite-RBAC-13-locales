---
type: system
title: Backend Overview - Application Composition
description: The FastAPI app composition - lifespan init/teardown, middleware order, router registration, process-wide singletons in deps.py, and startup configuration guards.
tags: [backend, fastapi, overview, main, lifespan, middleware, config]
---

# Backend Overview — Application Composition

`src/backend/` is the FastAPI backend for the directory. `main.py` builds the app and nothing else: lifespan, middleware order, exception handlers, router registration. The ~100 route handlers live in `routers/`, request models in `schemas/`, the auth ladder in `auth.py`, process-wide singletons in `deps.py`, and metrics/probes in `observability.py`.

## Lifespan (`main.py` `asynccontextmanager`)

1. `init_database()` — schema creation + default-profile-service seeding (idempotent; see [OrgDB](orgdb.md)). Lives in lifespan so importing the module doesn't require a reachable PostgreSQL.
2. `init_activity_bus(redis_client=ip_block_redis)` — cross-worker event bus (see [Activity Bus](activity_bus.md)); falls back to local delivery without Redis.
3. `ldap_client.ensure_clients_ou()` — ensure `ou=clients` subtree (non-fatal).
4. **Prod demo-identity tripwire** (`NON-BRICKING`): `assert_no_demo_identities(ENVIRONMENT, conn)` detects a prior demo-seeded deploy polluting the volume with bind-authenticatable demo identities; logs CRITICAL + sets `demo_identities_present` health flag, but KEEPS SERVING (crash-looping would brick an in-place prod upgrade). Enforcing layers are the Ansible preflight + `ldap_admin` purge.
5. Background tasks: LDAP activity collector, service health probe, activity listener, account-lock mirror re-sync. All catch their own errors so they can't block startup; all cancelled at shutdown.

## Middleware order (pinned by `tests/contract/test_middleware_order.py`)

`add_middleware()` INSERTS at position 0, so the LAST added is OUTERMOST. main.py adds: IPBlocking → RequestAudit → Metrics → RequestID → CORS, producing runtime nesting outermost-first:

```
CORS -> RequestID -> Metrics -> RequestAudit -> IPBlocking -> routes
```

CORS being outermost is deliberate: a 403 from IPBlockingMiddleware passes back through CORS so a blocked admin sees the real status instead of an opaque browser network error. Trade-off: CORS answers preflights itself without RequestID (no X-Request-ID on those) — acceptable since CORSMiddleware emits no logs.

## Exception handlers

`RateLimitExceeded` → `rate_limit_exceeded_handler` (JSON 429); `LdapUnavailableError` → `ldap_unavailable_handler` (503 retryable `directory_unavailable`).

## Router registration (`routers/__init__.py`)

`ROUTER_ORDER = [system, orgs, groups, users, selfservice, provisioning, orgprofiles, dashboard, realtime, audit, templates, settings, admin]`. Order matters: Starlette matches in registration order, so `/api/users/search` must be registered before `/api/users/{uid}` or the literal path is swallowed by the parameterized one.

## Process-wide singletons (`deps.py`)

Constructed **without I/O** (importable with no DB running, which is what lets the auth ladder + contract gates test without Docker):
- `ORGDB = OrgDB(DATABASE_URL)` — lazy engine init via `.connect()`; `create_all` moved to `init_database()`.
- `settings_db = SettingsDB(ORGDB.connect())` — shares ORGDB's engine.
- `ip_block_redis` — `None` unless configured; every caller degrades.
- `authentik_client`, `uc_client` — `None` unless fully configured; callers check `.configured`.

## Config guards (`config.py`)

Pydantic-free `os.getenv` at import. `assert_dev_token_safe` refuses startup when `DEV_AUTH_TOKEN` is set outside dev environments (default-deny: any env not in {development, dev, test, ci}). `assert_production_config_safe` refuses non-dev startup on known-insecure defaults (LDAP bind pw `adminpassword`, default DB credentials, dev Authentik token, shipped QR secret, plaintext LDAP to non-loopback). `assert_no_demo_identities` checks the canonical demo uids. `setup_logging()` configures structured JSON stdout logging (ARD-008).

## Focused tests

- `tests/contract/test_middleware_order.py`, `tests/contract/test_openapi_snapshot.py`, `tests/contract/test_db_surface.py`, `tests/contract/test_auth_matrix.py`, `tests/contract/test_response_shapes.py`, `tests/contract/test_unschematised_routes.py`.
- `tests/unit/test_config_guard.py`, `tests/unit/test_smoke.py`.

## Related pages

- Router pages: [users](routers/users.md), [orgs](routers/orgs.md), [groups](routers/groups.md), [selfservice](routers/selfservice.md), [provisioning](routers/provisioning.md), [dashboard](routers/dashboard.md), [audit](routers/audit.md), [realtime](routers/realtime.md), [settings](routers/settings.md), [orgprofiles](routers/orgprofiles.md), [admin](routers/admin.md), [system](routers/system.md).
- [OrgDB](orgdb.md), [Auth](auth.md), [Observability](observability.md), [Activity Bus](activity_bus.md), [Rate Limiting](rate_limiting.md), [Architecture](../architecture.md).
