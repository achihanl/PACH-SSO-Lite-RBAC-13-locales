---
type: subsystem
title: Security - Account Locks, IP Blocking, and the Degraded-Store Mirror
description: Account lock mechanism (DS-1), IP blocking (DS-2), auth-failure accounting, the Redis account-lock mirror with completeness sentinel (ARD-012), and the DegradedSite log-once helpers.
tags: [backend, security, account-lock, ip-blocking, redis, mirror, degraded, ard-012]
---

# Security — Account Locks, IP Blocking, and the Degraded-Store Mirror

This page covers the security data + degraded-state machinery. The enforcement happens in [Auth](auth.md) and [Rate Limiting](rate_limiting.md).

## Account locks (DS-1)

`SecurityMixin` (`db/security.py`):

- `record_auth_failure(client_ip, endpoint, failure_reason, username?, user_agent?)` — inserts into `auth_failure_audit` + publishes an `auth-failure` activity event.
- `check_account_locked(username)` — reads `account_locks` (`locked_until > NOW()`), returns `(is_locked, locked_until_iso)`.
- Auto-lock counting per IP (see [Auth](auth.md) thresholds). ⚠️ Note (ARD-012 / ARD-009 §H4): `OrgDB.lock_account()` has **no production caller** — the auto-lock path was deliberately removed (it let an attacker lock any victim by naming them in a forged token) and no admin lock endpoint replaced it, so the only way a row enters `account_locks` is out-of-band SQL. This is why the mirror uses a completeness sentinel (below).

## IP blocking (DS-2)

`block_ip(ip, duration_hours, reason, blocked_by=...)`, `unblock_ip(ip)`, `list_blocked_ips()` on the `blocked_ips` table + Redis `blocked_ip:<ip>` cache. Auto-block after `IP_BLOCK_FAILURE_THRESHOLD` failures in the window; manual block/unblock via [Admin Router](routers/admin.md).

## Redis account-lock mirror (`account_lock_mirror.py`, ARD-012 §1–§2)

PG stays authoritative; each active lock is additionally held in Redis under `azblink:account_lock:<uid>` with a TTL covering the lock duration, so lock enforcement survives a PG outage. `check_account_locked` reads through to the mirror when the PG read raises.

**The completeness sentinel is the load-bearing part.** `SENTINEL_KEY = azblink:account_lock_mirror:synced` (deliberately OUTSIDE the lock-key prefix so it isn't scanned as a lock). A positive-only cache may be treated as authoritative only if every lock reached it. Because `lock_account()` has no caller, dual-write can never observe the out-of-band-SQL locks, so the sentinel carries a TTL refreshed by each successful full re-sync:

- re-sync succeeds → `SET sentinel EX (2 × interval)` (interval = `RESYNC_INTERVAL_SECONDS`=60, so sentinel outlives two slow passes without flapping).
- re-sync stops → sentinel expires → mirror untrusted → **fail closed**.
- mirror write fails → sentinel deleted immediately.

`read_lock(uid)` returns `LOCKED` | `NOT_LOCKED` | `UNKNOWN` (UNKNOWN when the sentinel is absent → the auth layer 503s). `mirror_lock`/`mirror_unlock` write/delete; both invalidate the sentinel on failure. `run_resync_loop(ORGDB)` is a lifespan task (main.py) that keeps the mirror complete and refreshes the sentinel.

## DegradedSite (`degraded.py`)

Log-once-per-transition helper for the six store-backed authorization reads (see [Auth](auth.md)). One WARNING on entering degraded, one INFO on recovery, nothing per-request. Not thread-safe beyond a bool assign (a duplicated warning under a race is harmless; a lock on every auth read is not worth it).

## Focused tests

- `tests/test_account_lock.py`, `tests/test_security.py`, `tests/test_ip_blocking.py`, `tests/test_lifecycle_audit.py`.
- `tests/unit/test_account_lock_mirror.py` — sentinel/completeness.

## Related pages

- [Auth](auth.md) — enforcement + fail-open posture.
- [Rate Limiting](rate_limiting.md) — IP block middleware.
- [Admin Router](routers/admin.md) — manual blocking.
- [OrgDB](orgdb.md) — SecurityMixin.
- [Architecture](../architecture.md) — ARD-009, ARD-012.
