---
type: service
title: OrgDB - PostgreSQL Storage and Schema Migration Lane
description: PostgreSQL storage composed from per-domain mixins, the two-schema-authority invariant (create_all adds-only vs migrations ALTERs), table-to-mixin ownership, and seeding.
tags: [backend, orgdb, postgresql, sqlalchemy, schema, migrations, mixins]
---

# OrgDB — PostgreSQL Storage and Schema Migration Lane

`src/backend/orgdb.py` is the PostgreSQL storage, composed from the `db/` package (one mixin per bounded context). **Single-engine policy: PostgreSQL everywhere.**

## Composition

The original 2,723-line `OrgDB` class (~90 methods over 19 tables) is now a `@dataclass` composed from `DbMixin` slices:

```python
class OrgDB(ProfilesMixin, DevicesMixin, AuditMixin, SecurityMixin,
            RbacMixin, TemplatesMixin, LdapInventoryMixin, DashboardMixin):
```

Composition (not a delegating facade) is deliberate: the ~150 `ORGDB.<method>()` call sites resolve exactly as before, there is no forwarding layer to keep in sync, and no second way to reach the same table. The mixins are **not independently instantiable** — they are slices of one object (typing contract in `db/_base.py.DbMixin`, body under `TYPE_CHECKING` so the runtime MRO is unchanged).

## Engine lifecycle

- `OrgDB(database_url)` stores only the URL; `connect()` lazily `create_engine(pool_pre_ping=True)`. Importing the module performs **no I/O** (critical for importable-without-Docker testing).
- `init()` → `metadata.create_all(eng)` + `_seed_default_profile_services()` (called from main.py lifespan). `create_all` only adds missing tables; it never alters existing ones.

## Table → mixin ownership

All 19 SQLAlchemy `Table` objects + the shared `MetaData` live in `db/tables.py` (kept together so `create_all()` sees the whole metadata and `settingsdb` reaches `app_settings`). `orgdb.py` re-exports every name. Ownership:

- `ProfilesMixin` (`db/profiles.py`) — `org_profiles` (legacy profile_json/nonce), profile CRUD, org-DN remap/delete.
- `DevicesMixin` (`db/devices.py`) — `device_provisions`: one-time tokens, device records, cap counting, compliance, bulk revoke, extend.
- `AuditMixin` (`db/audit.py`) — `termination_events`, `auth_failure_audit`, `user_lifecycle_audit`, `provisioning_audit`, `admin_action_audit`, `suspension_events` (append-only); each write publishes an activity event.
- `SecurityMixin` (`db/security.py`) — `account_locks`, `blocked_ips` + auth-failure accounting (DS-1/DS-2); dual-writes to the Redis mirror.
- `RbacMixin` (`db/rbac.py`) — `group_profiles`, `group_member_roles`; `get_user_permissions` backs authorization.
- `TemplatesMixin` (`db/templates.py`) — `config_templates`, `config_template_assignments`, `config_template_history`, `profile_services`; uidNumber/SIP-extension allocators.
- `LdapInventoryMixin` (`db/ldap_inventory.py`) — `ldap_clients`, `ldap_provisioned_clients` (observed sessions + provisioned credentials).
- `DashboardMixin` (`db/dashboard.py`) — read-only aggregates (user stats, compliance alerts).

`settingsdb.py` (`SettingsDB`) shares ORGDB's engine; stores app_settings key/value (ldap/email/security/audit/branding), defaults + 60s security cache.

## Seeding

`_seed_default_profile_services` — idempotent: creates the default template ("Standard Profile", `template_type=default`) if absent, then ensures xmpp+sip service rows exist (inserts only what's missing, never overwrites operator/GUI edits or counters). UCCHAT_* is mandatory (enforced at startup by `config._validate_uc_config`), so both services seed enabled from real domain/URL config.

## ⚠️ The two-schema-authority invariant

> `metadata.create_all()` only ever **ADDS** tables; it never alters an existing one. A column change must therefore also land in `migrations/`, or a fresh deploy and an upgraded deploy silently diverge.

This is **the** rule to respect when touching schema: `db/tables.py` is the fresh-deploy authority, `migrations/*.sql` (the canonical home of ALTERs) is the upgraded-deploy authority, and both must be kept in sync. `tests/contract/test_db_surface.py` guards the surface.

## Migration lane (`migrations/`)

Ordered 004→029 SQL migrations encoding the data lifecycle: phase-1 UC QR (004), groups management (005), org management (006), provisioning ops indexes (007), config templates (008), settings (009), UED sync (010–014), single-LDAP (017), drop API keys (018), suspension events (019), account locks (020), blocked IPs (021), device provisioning (022), drop UED sync tables (023), remove SSO QR (024), profile services (025), provisioning audit (026), device app name (027), LDAP clients (028), ldap provisioned clients (029).

## Focused tests

- `tests/contract/test_db_surface.py` — schema/table surface contract.
- `tests/orgdb_device.py` (in suite), `tests/test_config_templates.py`, `tests/test_profile_services.py`, `tests/test_security.py`, `tests/test_audit.py`.

## Related pages

- [Backend Overview](overview.md) — deps singleton + lifespan.
- [Auth](auth.md) — RBAC/audit reads.
- [Provisioning](provisioning.md) — DevicesMixin/LdapInventoryMixin.
- [Security](security.md) — SecurityMixin + mirror.
- [Config Templates](config_templates.md) — TemplatesMixin.
- [Architecture](../architecture.md) — ARD-014 (module governance).
