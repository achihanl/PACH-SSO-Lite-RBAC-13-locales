---
type: service
title: Org Profiles Router
description: Legacy org app profile CRUD - list, create, get, patch, delete of the profile_json + nonce system keyed by org DN.
tags: [backend, orgprofiles, router, profile, legacy]
---

# Org Profiles Router

`routers/orgprofiles.py` implements the legacy org app profile CRUD (the `org_profiles` table: `profile_json` + `nonce` keyed by org DN). This is the older profile system; newer configuration lives in [Config Templates](../config_templates.md).

## Routes (guarded by `require_directory_read`/`require_permission`)

- `GET /api/orgprofiles` — list profiles (optional `tenant`).
- `POST /api/orgprofiles` (201, `OrgProfileUpsert`).
- `GET /api/orgprofiles/{profile_id}`.
- `PATCH /api/orgprofiles/{profile_id}` (`OrgProfilePatchReq`).
- `DELETE /api/orgprofiles/{profile_id}`.

## Data

`ProfilesMixin` (`db/profiles.py`) — `list_profiles`, `get_profile`, `upsert_profile`, `update_org_profile`, `delete_profile`, `get_profile_by_org_dn`, `update_profile_org_dn`, `delete_profile_by_org_dn`. The profiled link to config templates is resolved in the config-templates path instead.

## Focused tests

- `tests/test_orgprofiles.py`, `tests/test_orgprofile_patch.py`.

## Related pages

- [OrgDB](../orgdb.md) — ProfilesMixin.
- [Config Templates](../config_templates.md) — the newer profile/services model.
