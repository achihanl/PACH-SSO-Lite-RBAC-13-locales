---
type: service
title: Admin Security Router
description: IP-blocking administration - list, block, and unblock IPs (DS-2) plus Redis cache invalidation.
tags: [backend, admin, router, security, ip-blocking]
---

# Admin Security Router

`routers/admin.py` administers the IP-blocking feature (DS-2), guarded by `require_permission("system_configuration")`. (Note: the `orgprofiles` page is separate; this router only covers IP blocking.)

## Routes

- `GET /api/security/blocked-ips` — list currently blocked IPs from the `blocked_ips` table (`list_blocked_ips`).
- `POST /api/security/blocked-ips` (`IPBlockRequest`) — block an IP (`block_ip` with duration/reason/actor).
- `DELETE /api/security/blocked-ips/{ip}` — unblock (404 if absent); also deletes the `blocked_ip:{ip}` Redis cache key so unblock takes effect immediately.

## Data

`SecurityMixin` (`db/security.py`) — `block_ip`, `unblock_ip`, `list_blocked_ips`, plus auth-failure accounting. Redis caching via [IP blocking / rate limiting](../rate_limiting.md).

## Focused tests

- `tests/test_security.py`, `tests/test_ip_blocking.py`.

## Related pages

- [Security](../security.md) — account locks + IP blocking.
- [Rate Limiting](../rate_limiting.md) — middleware that consults the block list.
