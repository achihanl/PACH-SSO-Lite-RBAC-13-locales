---
type: service
title: Realtime Activity Router
description: Real-time activity feed over WebSocket - recent events and the WebSocket handler with per-user connection limiting.
tags: [backend, realtime, router, websocket, activity, events]
---

# Realtime Activity Router

`routers/realtime.py` delivers the real-time activity feed over WebSocket, backed by the [Activity Bus](../activity_bus.md).

## Routes

- `GET /api/activity/recent` — recent events.
- `WEBSOCKET /api/activity/ws` — WebSocket feed; auth via `?token=` query param verified by `verify_ws_token` (the WebSocket cannot reuse the `Depends()` ladder; shares `DEV_AUTH_CLAIMS` with REST). Registered as intentionally public in the auth matrix because auth happens in the handler. The socket closes at the token's `exp`.

The SSE feed `GET /api/activity/stream` was removed (review 2, M1): it checked the token once and never again, and no UI read it.

## Behavior

- Per-user connection cap `MAX_WS_CONNECTIONS_PER_USER` enforced via an in-process `_ws_connections` dict (`_acquire_ws_slot`/release).
- `_recv_until_disconnect` observes client closes so the connection slot is released promptly (server-push only; inbound frames discarded) — #236.
- Subscribes to the activity bus; events fan out to all connected clients. The bus uses Redis pub/sub for cross-worker delivery (see [Activity Bus](../activity_bus.md)).

## Focused tests

- `tests/test_activity_realtime.py`.

## Related pages

- [Activity Bus](../activity_bus.md) — delivery across workers.
- [Auth Ladder](../auth.md) — `verify_ws_token`.
- [Activity Types](../activity_bus.md#activity-types-activity_typespy) — event type mapping.
