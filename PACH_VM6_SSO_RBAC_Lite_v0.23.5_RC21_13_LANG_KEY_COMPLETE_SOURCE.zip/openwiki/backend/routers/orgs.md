---
type: service
title: Orgs Router
description: Org tree CRUD — create (with profile/QR), rename, delete (cascading), tree queries, per-org user listings, and org detail with profile resolution.
tags: [backend, orgs, router, tree, ou, profile]
---

# Orgs Router

`routers/orgs.py` implements organisational tree CRUD and per-org user listings.

## Routes

- `GET /api/org/tree` — org tree.
- `GET /api/org/users` — users for an org (alias).
- `POST /api/org/create` (201, `OrgCreateReq`) — create an org OU.
- `POST /api/org/rename` (`OrgRenameReq`).
- `DELETE /api/org/{dn:path}` — recursive delete.
- `GET /api/orgs/tree`, `GET /api/orgs/detail` — aggregated org tree/detail.
- `GET /api/orgs/users` — per-org user listings with profile resolution.

## Behavior

- `_infer_org_type(depth)` — root/org/dept/team from tree depth when no profile exists.
- Org creation uses [LDAP Client](../ldap_client.md) `create_org_ou` (with `_ensure_chain`, mirrored people OU) and may generate a profile + QR. Org routing is guarded by `require_directory_read`/`require_permission("org_management")`.
- Endpoint resolution via `_resolve_service_endpoints(org_dn)` (profile services → env fallback).
- Org user counts use `count_users_by_people_base` (N+1-safe).

## LDAP primitives

`create_org_ou`, `rename_org_ou` (mirrors OU rename), `delete_org_ou` (cascading OU tree delete), `get_org_tree`, `org_dn_to_people_dn`/`count_users_by_people_base`, `list_users_for_org`.

## Focused tests

- `tests/test_org_groups.py` — org tree CRUD + memberOf overlay (`TestMemberOfOverlay`).
- `tests/test_orgprofiles.py` — profile linkage on org detail.

## Related pages

- [LDAP Client](../ldap_client.md) — org/OU primitives.
- [Org Profiles Router](orgprofiles.md) — legacy profile_json.
- [Groups Router](groups.md) — group membership within orgs.
