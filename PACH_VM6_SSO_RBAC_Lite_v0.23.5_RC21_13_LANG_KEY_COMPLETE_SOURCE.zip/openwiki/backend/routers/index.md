# Files

- [Admin Security Router](admin.md) - IP-blocking administration - list, block, and unblock IPs (DS-2) plus Redis cache invalidation.
- [Audit Router](audit.md) - Append-only audit trail query endpoints - terminations, auth failures, user lifecycle, unified events, and CSV export - plus management audit queries.
- [Dashboard Router](dashboard.md) - Dashboard aggregate endpoints - stats, chart data, and health card, combining LDAP counts with PostgreSQL provisioning aggregates.
- [Groups Router](groups.md) - Group CRUD, membership, member roles, and RBAC permission management backed by LDAP groupOfNames + PostgreSQL group_profiles.
- [Org Profiles Router](orgprofiles.md) - Legacy org app profile CRUD - list, create, get, patch, delete of the profile_json + nonce system keyed by org DN.
- [Orgs Router](orgs.md) - Org tree CRUD — create (with profile/QR), rename, delete (cascading), tree queries, per-org user listings, and org detail with profile resolution.
- [Provisioning Router](provisioning.md) - The device-provisioning HTTP surface - one-time token validate/consume, SSO device provisioning with E2E sealed credential delivery, token/bulk operations, device listings, compliance, and pending provisions.
- [Realtime Activity Router](realtime.md) - Real-time activity feed over WebSocket and SSE - recent events, streaming endpoint, and the WebSocket handler with per-user connection limiting.
- [Self-Service Router](selfservice.md) - The /api/me endpoints - a user acting on their own identity: profile update, password change, device listing, and the unprovisioned profile for SSO-only principals.
- [Settings Router](settings.md) - Application settings (get/patch/reset/security), LDAP client administration (inventory, provisioned clients create/rotate/revoke), and LDAP/email test endpoints.
- [System Router](system.md) - System endpoints - liveness/deep health, version, tenant info, bootstrap, system version probes, and the Prometheus /metrics scrape endpoint.
- [Users Router and Lifecycle](users.md) - User CRUD, search, export, CSV import, and lifecycle endpoints (create with UC allocation, terminate, suspend/unsuspend, move org, reset password, lock-status).
