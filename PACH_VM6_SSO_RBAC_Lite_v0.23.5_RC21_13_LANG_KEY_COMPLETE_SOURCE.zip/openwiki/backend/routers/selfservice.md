---
type: service
title: Self-Service Router
description: "The /api/me endpoints - a user acting on their own identity: profile update, password change, device listing, and the unprovisioned profile for SSO-only principals."
tags: [backend, selfservice, router, me, profile, password]
---

# Self-Service Router

`routers/selfservice.py` implements the `/api/me*` surface scoped to the caller's own identity (guarded by `require_user`). These endpoints are explicitly NOT gated by `require_directory_read` — a self-service user without a management permission may still act on their own identity.

## Routes

- `GET /api/me` — own profile.
- `PATCH /api/me` — update own profile (displayName/mail/mobile/preferredLanguage).
- `POST /api/me/password` — change own password (verifies current via `verify_user_password`, then `reset_user_password`).
- `GET /api/me/devices` — own provisioned devices.

## Important behaviors

- `_unprovisioned_profile(uid, claims)` — returns a profile for an authenticated principal with no LDAP entry, with the same key set as `ldap_client.get_user` so callers need no shape-awareness (e.g. an SSO-only user before LDAP provisioning).
- `SUPPORTED_UI_LANGUAGES = {en, zh-Hant, zh-Hans}` for `preferredLanguage`, mirroring the frontend i18n languages.
- `<POST> /api/me/password` shares `reset_user_password` semantics (LDAP SSHA + XMPP bind password sync) from [LDAP Client](../ldap_client.md)/[Users Router](users.md).

## Focused tests

- `tests/test_self_service.py` — the /api/me surface + unprovisioned profiles.
- `tests/test_rbac.py::TestC1DirectoryReadAuthz` — confirms /api/me* is not gated by directory-read.

## Related pages

- [Auth Ladder](../auth.md) — `require_user`.
- [LDAP Client](../ldap_client.md) — `get_user`, `verify_user_password`, `reset_user_password`.
