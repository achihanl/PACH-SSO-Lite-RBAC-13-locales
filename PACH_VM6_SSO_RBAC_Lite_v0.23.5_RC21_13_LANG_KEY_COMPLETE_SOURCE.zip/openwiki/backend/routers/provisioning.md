---
type: service
title: Provisioning Router
description: The device-provisioning HTTP surface - one-time token validate/consume, SSO device provisioning with E2E sealed credential delivery, token/bulk operations, device listings, compliance, and pending provisions.
tags: [backend, provisioning, router, device, tokens, curve25519, qr]
---

# Provisioning Router

`routers/provisioning.py` is the device-provisioning HTTP surface. It is the runtime entrypoint for [the provisioning system](../provisioning.md). Requests are rate-limited by authenticated user via `_device_provision_key`.

## Routes

Public (token-authenticated, registered in `INTENTIONALLY_PUBLIC` in the auth matrix):
- `POST /api/provision/validate` — hash token, `validate_and_consume_token`, return uid/profile_id/consumed_at.
- `POST /api/provision/consume` — Phase 1 "Plane A" (LDAP bind, no passwords returned): returns `config` with `authMethod: ldap_bind` + XMPP/SIP JID/URI.
- `POST /api/provision/device` — SSO device provisioning (see below).

Operator-gated (`require_permission("device_provisioning")`):
- `POST /api/provisioning/tokens/bulk-revoke`, `POST /api/provisioning/tokens/{token_hash}/extend`.
- `GET /api/provisioning/devices`, `GET /api/provisioning/devices/{device_id}/history`, `GET /api/provisioning/compliance`.
- `GET /api/provisions/pending` (`require_admin`).
`DELETE /api/provision/device/{device_id}` (self-service revoke via `require_user`).

## SSO device provisioning (`POST /api/provision/device`)

1. Validate the Curve25519 public key (base64, 32 bytes, `nacl.public.PublicKey`).
2. Resolve user in LDAP via `get_user` (403 `NOT_UC_PROVISIONED` if absent).
3. Resolve config template/profile + enabled XMPP/SIP services (403 if neither enabled).
4. Enforce device cap (`count_active_device_provisions`, excluding the current device for re-provision; 409 `DEVICE_CAP_REACHED`).
5. Read UC credentials from LDAP (`get_uc_credentials`: `azbXmppBindPassword`, `AstAuthPassword`).
6. Build + seal credential payload with `nacl.public.SealedBox(client_pk)` → base64 `sealedCredentials`; return endpoints + `expiresAt`.
7. Upsert a `device_provisions` row; record provisioning audit.

`DEVICE_PROVISION_TTL_SEC` controls expiry; `DEVICE_PROVISION_MAX_DEFAULT` the default cap; `DEVICE_PROVISION_MAX_EXTEND_SEC` bounds extend.

## Compliance + pending cards

`GET /api/provisioning/compliance` computes alerts from `compute_compliance_alerts`, cached 60s with `?refresh=1`. `GET /api/provisions/pending` lists pending tokens using `get_users_batch` (single-roundtrip LDAP batch); when LDAP is down it surfaces all rows rather than emptying the card (orphans — leftover `upsert-*`/`rvk-own-*` fixtures whose uid has no LDAP user — are skipped when `ldap_ok`).

## Focused tests

- `tests/test_device_provisioning.py`, `tests/test_provisioning.py`, `tests/test_provision_consume.py`.
- `tests/test_provisioning_ops.py`, `tests/test_provisioning_audit.py`, `tests/unit/test_provisioning_unit.py`.

## Related pages

- [Provisioning](../provisioning.md) — tokens, E2E sealing, allocation.
- [LDAP Client](../ldap_client.md) — `get_user`, `get_users_batch`, `get_uc_credentials`.
- [Config Templates](../config_templates.md) — profile/services resolution.
- [OrgDB](../orgdb.md) — `device_provisions` tables.
