---
type: service
title: System Router
description: System endpoints - liveness/deep health, version, tenant info, bootstrap, system version probes, and the Prometheus /metrics scrape endpoint.
tags: [backend, system, router, health, metrics, version, bootstrap]
---

# System Router

`routers/system.py` provides system-level endpoints, including the health and observability surface.

## Routes

- `GET /api/health` — liveness; always 200 if the app runs; returns `{ok, status, version}`.
- `GET /api/health/deep` — deep health (LDAP/PostgreSQL/Redis probes). **Public** — it never returns raw exception text (leak guard M6); returns generic `unavailable` markers. Includes `_default_profile_services_ok()` and the `demo_identities_present` prod tripwire flag.
- `GET /api/version` — build metadata (`_version.__version__`), surfaced in the UI footer.
- `GET /metrics` (`include_in_schema=False`) — Prometheus scrape; in-network only (Traefik does not route it).
- `GET /api/tenant` — tenant info.
- `POST /api/bootstrap` — bootstrap seeding (rate-limited; see [Rate Limiting](../rate_limiting.md)).
- `GET /api/system/versions` — version probes of PG/Redis/Authentik via the version cache covered in [Observability](../observability.md).

## Health probes

The deep health check verifies LDAP (`ldap_conn()`), PostgreSQL (`SELECT 1`), and Redis (`ping`), returning 503 overall when degraded. Service reachability probing runs as a lifespan background task (see [Observability](../observability.md)).

## Focused tests

- `tests/test_health.py`, `tests/test_health_deep_services.py`, `tests/test_bootstrap.py`.

## Related pages

- [Observability](../observability.md) — metrics + probes.
- [Version Cache](../observability.md#version-cache-version_cachepy) — system/versions freeze/retry.
- [Backend Overview](../overview.md) — lifespan wiring.
