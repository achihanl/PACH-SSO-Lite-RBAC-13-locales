---
type: service
title: Users Router and Lifecycle
description: User CRUD, search, export, CSV import, and lifecycle endpoints (create with UC allocation, terminate, suspend/unsuspend, move org, reset password, lock-status).
tags: [backend, users, router, lifecycle, termination, csv-import, export]
---

# Users Router and Lifecycle

`routers/users.py` implements user CRUD and the lifecycle surface. Routes are guarded by `require_permission`/`require_directory_read`, with terminate/suspend/unsuspend/reset requiring management permissions.

## Routes

- `GET /api/users` — list users (pagination, search, filter).
- `GET /api/users/search` — search (registered before `/api/users/{uid}` so the literal path wins).
- `GET /api/users/export` — streaming export.
- `GET /api/users/{uid}` — user detail.
- `PATCH /api/users/{uid}` — update (displayName, mail, mobile, preferredLanguage → LDAP `cn`/mail/mobile/preferredLanguage via `update_user`).
- `GET /api/users/{uid}/groups`, `/devices`, `/stats`, `/lock-status`.
- `POST /api/users/create` (201) — create user.
- `POST /api/users/{uid}/reset_password`, `/move_org`, `/terminate`, `/suspend`, `/unsuspend`, `/unlock`.
- `POST /api/users/import_csv`.

## Create user (with UC allocation)

`_ensure_org_path(path)` walks an org path like `Sales/TeamA`, creating each OU (`create_org_ou`). `create_user(uid, display_name, mail, mobile, org_dn, password, title, employee_number, manager_dn)` builds the `inetOrgPerson` under the mirrored people OU and returns `created`|`exists`. When a profile is assigned, `allocate_uc_resources` allocates uidNumber/extension/sip_password and `build_uc_attrs`/`add_uc_attrs_to_user` add the UC objectClasses/attrs (posixAccount, azblinkUser, AsteriskAccount + AsteriskPjsip* for SIP).

**UC provisioning completeness** is validated at startup (`config._validate_uc_config`); `UCCHAT_*` mandatory.

## Terminate

`disable_user` in [LDAP Client](../ldap_client.md) is the LDAP half (three writes: `pwdAccountLockedTime` sentinel, group membership removal, password/description markers). The terminate route additionally: revokes Authentik sessions/tokens (`authentik_client`), calls `uc_client.terminate_user_sessions` (stub), and records a `termination_events` audit row with a step-accumulator. `response_utils.summarize_termination` derives `partial`/`warnings` from `*_error` keys; `uc_termination_actions` maps the UC stub result (writes `not_implemented`/None rather than a fabricated zero — TD-8). Terminal actions are best-effort under ARD-012 fail-open.

## Suspend / unsuspend

`suspend_user` clears password (`{SUSPENDED}`) + description marker (entry preserved, unsuspendable). `unsuspend_user` sets a new SSHA password + clears description. See [LDAP Client](../ldap_client.md).

## CSV import / export

`POST /api/users/import_csv`, `GET /api/users/export` — bulk user operations with per-row validation error reporting.

## Focused tests

- `tests/test_users.py` — CRUD + lifecycle.
- `tests/test_suspend.py`, `tests/test_suspension_events.py`, `tests/test_lifecycle_audit.py`.
- `tests/test_import_csv.py`, `tests/test_export.py`.
- `tests/test_device_provisioning.py` — device/stats endpoints.

## Related pages

- [LDAP Client](../ldap_client.md) — user lifecycle primitives.
- [Provisioning](../provisioning.md) — UC resource allocation.
- [Authentik Client](../authentik_client.md), [UC Client](../uc_client.md) — termination side effects.
- [Audit Router](audit.md) — audit queries.
