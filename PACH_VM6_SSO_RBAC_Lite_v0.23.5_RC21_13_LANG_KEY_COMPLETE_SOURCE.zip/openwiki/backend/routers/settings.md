---
type: service
title: Settings Router
description: Application settings (get/patch/reset/security), LDAP client administration (inventory, provisioned clients create/rotate/revoke), and LDAP/email test endpoints.
tags: [backend, settings, router, configuration, ldap-clients, provisioning]
---

# Settings Router

`routers/settings.py` handles application settings and LDAP client administration, guarded by `require_permission("system_configuration")`.

## Application settings

- `GET /api/settings` — all settings grouped by section (`settingsdb.get_all_settings`), masking `ldap.bindPassword` and `email.password`.
- `GET /api/settings/security` — public before login (session timeout etc.).
- `PATCH /api/settings` (`SettingsPatchRequest`), `PUT /api/settings/reset`.

Settings storage in `settingsdb.py` (shares ORGDB engine): key/value by section (ldap/email/security/audit/branding), `SETTINGS_DEFAULTS`, 60s security cache.

## LDAP client administration

- **Inventory**: `GET /api/settings/ldap/clients` — observed LDAP client sessions; `PATCH .../{client_id}` (status/label/ack), `DELETE .../{client_id}`.
- **Provisioned clients** (ARD-006, delegated to ldap_provisioning): `POST /api/settings/ldap/clients/provisioned`, `GET .../provisioned`, `POST .../provisioned/{client_id}/rotate`, `DELETE .../provisioned/{client_id}`.

## Test endpoints

- `POST /api/settings/ldap/test`, `POST /api/settings/email/test`.

## Focused tests

- `tests/test_settings.py`, `tests/test_settings_enforcement.py`, `tests/test_ldap_provisioning.py`.
- LDAP inventory classification covered by [LDAP Activity](../ldap_activity.md) unit tests.

## Related pages

- [LDAP Activity](../ldap_activity.md) — inventory collector feeding list_ldap_clients.
- [Provisioning](../provisioning.md) — ldap_provisioning create/rotate/revoke.
- [OrgDB](../orgdb.md) — SettingsDB + LdapInventoryMixin.
