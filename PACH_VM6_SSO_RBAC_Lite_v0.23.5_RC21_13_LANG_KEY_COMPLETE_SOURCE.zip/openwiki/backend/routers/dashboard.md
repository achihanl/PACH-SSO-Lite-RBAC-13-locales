---
type: service
title: Dashboard Router
description: Dashboard aggregate endpoints - stats, chart data, and health card, combining LDAP counts with PostgreSQL provisioning aggregates.
tags: [backend, dashboard, router, stats, admin]
---

# Dashboard Router

`routers/dashboard.py` provides admin dashboard aggregates.

## Routes (all `Depends(require_admin)`)

- `GET /api/dashboard/stats` — flat numeric response combining LDAP user counts with PostgreSQL provisioning aggregates (devices, pending, compliance).
- `GET /api/dashboard/chart` — trend chart data.
- `GET /api/dashboard/health` — health card.

## Data source

- LDAP via [LDAP Client](../ldap_client.md) `list_users` / `get_users_batch`.
- PostgreSQL via [OrgDB](../orgdb.md) `DashboardMixin` aggregates (`db/dashboard.py`) and pending provisions.

## Focused tests

- `tests/test_dashboard_api.py`.

## Related pages

- [Backend Overview](../overview.md)
- [Provisioning](../provisioning.md) — pending/compliance feeds dashboard cards.
- [LDAP Activity](../ldap_activity.md) — session inventory.
