---
type: service
title: Groups Router
description: Group CRUD, membership, member roles, and RBAC permission management backed by LDAP groupOfNames + PostgreSQL group_profiles.
tags: [backend, groups, router, membership, rbac, permissions]
---

# Groups Router

`routers/groups.py` implements group CRUD, membership, member roles, and permission management.

## Routes

- `GET /api/groups` — list groups (filter by `type`/`search`/pagination/sort).
- `GET /api/groups/{cn}` — group detail.
- `POST /api/groups/create` (201, `GroupCreateReq`).
- `POST /api/groups/{cn}/members` (`GroupMemberAddReq`).
- `DELETE /api/groups/{cn}/members/{uid}`, `PATCH /api/groups/{cn}/members/{uid}/role` (`GroupMemberRoleReq`).
- `GET /api/groups/{cn}/members`.
- `DELETE /api/groups/{cn}`, `PATCH /api/groups/{cn}` (`GroupUpdateReq`), `PATCH /api/groups/{cn}/permissions` (`GroupPermissionsReq`).

## Constants

`VALID_GROUP_TYPES = {security, distribution, department, project}`; `VALID_PERMISSIONS = {user_management, org_management, device_provisioning, audit_log_access, system_configuration}`.

## LDAP + RBAC backing

- LDAP: groups are `groupOfNames` carrying `member`. `create_group`, `delete_group`, `group_add_member`, `group_remove_member`, `get_group_members`, `get_group`, `update_group_description`, `list_groups`, `find_group_dn`. **Invariant:** because groups are `groupOfNames`/`member`, the memberOf overlay must be mounted for that pair — see [LDAP Client](../ldap_client.md) and `memberof-refint-config.ldif`.
- RBAC: `RbacMixin` (`db/rbac.py`) stores `group_profiles` (cn, group_type, permissions) and `group_member_roles`; `get_user_permissions` powers the auth ladder. `groupOfNames` requires ≥1 member — `create_group` adds the service DN (`LDAP_BIND_DN`) as a placeholder, same as `disable_user` does before removing a sole member.

## Focused tests

- `tests/test_org_groups.py` — group CRUD, membership, memberOf overlay.
- `tests/test_rbac.py` — permission resolution + directory-read authz.

## Related pages

- [LDAP Client](../ldap_client.md) — group primitives + memberOf invariant.
- [Auth Ladder](../auth.md) — RBAC consumption.
- [Orgs Router](orgs.md) — org tree.
