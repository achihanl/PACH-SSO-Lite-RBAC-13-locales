---
type: service
title: Audit Router
description: Append-only audit trail query endpoints - terminations, auth failures, user lifecycle, unified events, and CSV export - plus management audit queries.
tags: [backend, audit, router, trails, export, lifecycle]
---

# Audit Router

`routers/audit.py` exposes the append-only audit trails as query endpoints, guarded by `require_permission("audit_log_access")`.

## Routes

- `GET /api/audit/terminations` — termination events (`list_terminations`).
- `GET /api/audit/auth_failures` — auth-failure records.
- `GET /api/audit/user_lifecycle` — user lifecycle events.
- `GET /api/audit/events` — unified audit events (frontend activity feed; mapped via [activity_types](../activity_bus.md#activity-types-activity_typespy)).
- `GET /api/audit/export` — CSV export (streaming).

## Data

All trails are appended in [OrgDB AuditMixin](../orgdb.md) (`db/audit.py`): `termination_events`, `auth_failure_audit`, `user_lifecycle_audit`, `provisioning_audit`, `admin_action_audit`, `suspension_events`. Each write also publishes an activity event via `_publish_activity_event`.

## Focused tests

- `tests/test_audit.py`, `tests/test_admin_audit.py`, `tests/test_lifecycle_audit.py`, `tests/test_provisioning_audit.py`.

## Related pages

- [OrgDB](../orgdb.md) — AuditMixin + tables.
- [Activity Bus](../activity_bus.md) — event publication.
- [Users Router](users.md) — termination/suspension writes.
