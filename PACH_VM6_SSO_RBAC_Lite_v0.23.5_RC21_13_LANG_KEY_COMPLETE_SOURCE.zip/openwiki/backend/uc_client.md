---
type: component
title: UC Server Client (Stub)
description: The UC Server (SIP/XMPP session management) client — currently a stub for terminate_user_sessions with graceful degradation.
tags: [backend, uc, sip, xmpp, client, stub]
---

# UC Server Client (Stub)

`src/backend/uc_client.py` is the client for the UC Server's SIP/XMPP session management. It is currently a **STUB** — the real Asterisk ARI (SIP) and ejabberd/Prosody admin API (XMPP) calls are not implemented.

## Surface

- **`UCClient(api_url, api_token)`** — stateless (no session caching); `configured` returns `api_url and api_token` truthy.
- **`terminate_user_sessions(uid)`** — intended to kill active SIP registrations + XMPP sessions. Currently returns placeholder results with an `implemented: False` flag; raises `UCClientError` when not configured.
- Mirrors `authentik_client.py`: stateless, fire-and-forget, graceful degradation.

## Important semantics

`terminate_user_sessions` returns `sip_sessions`/`xmpp_sessions` counts plus an `implemented` flag. **Callers MUST check `implemented`** before treating the counts as a result. The counts are `None` (not `0`) so "not implemented" stays distinguishable from "no live sessions found" — previously they were `0`, which the caller wrote straight into the termination audit record, positively asserting zero UC sessions were killed when it was really unimplemented (TD-8, #233). `response_utils.uc_termination_actions` encodes this: when `implemented` is False it writes `_total=None` and `uc_sessions="not_implemented"` rather than fabricating a zero.

## Focused tests

- `tests/test_uc_client.py` — configured guard, `implemented` flag, error behavior.

## Related pages

- [Users Router](routers/users.md) — termination flow uses `terminate_user_sessions`.
- [Authentik Client](authentik_client.md) — the pattern this mirrors.
