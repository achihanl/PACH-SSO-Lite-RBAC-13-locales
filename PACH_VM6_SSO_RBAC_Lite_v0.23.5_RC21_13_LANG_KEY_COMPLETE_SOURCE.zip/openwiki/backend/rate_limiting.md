---
type: subsystem
title: Rate Limiting, IP Blocking, and Request Audit
description: Redis-backed slowapi rate limiting, the IP-blocking middleware, the trusted-proxy X-Forwarded-For resolution, per-route limits, and the optional API request audit.
tags: [backend, rate-limiting, ip-blocking, slowapi, redis, middleware, x-forwarded-for]
---

# Rate Limiting, IP Blocking, and Request Audit

`rate_limit.py` provides the rate limits, IP blocking, and request audit used across routers.

## Client IP resolution (trusted proxies)

`resolve_client_ip(peer_ip, xff_header, trusted_nets)` implements H5: **X-Forwarded-For is attacker-controlled** — honor it only when the direct socket peer is a configured trusted proxy; then walk the XFF chain from the right, returning the first address that is NOT a trusted proxy (the client as seen by the outermost trusted hop). If the peer is not trusted (or no proxies configured), ignore XFF entirely and use the socket peer — so a client cannot spoof its way past rate limiting / IP blocking. `_TRUSTED_PROXY_NETS` parsed from `TRUSTED_PROXIES` at import. `get_client_ip(request)` feeds the rate-limit key.

## Rate limiting (slowapi)

- Redis-backed `Limiter` (falls back to in-process when Redis absent); `rate_limit_exceeded_handler` returns a JSON 429. Rejections counted via `azblink_rate_limit_rejections_total`.
- Per-spec limits (bootstrap 5/hour, user create 20/min, device provision `LIMIT_DEVICE_PROVISION`, compliance 30/min, etc.). Device provisioning is rate-limited **by authenticated user** via `_device_provision_key` (see [Provisioning Router](routers/provisioning.md)).

## IP-blocking middleware (`IPBlockingMiddleware`)

- Wraps every request; a request from a blocked IP → 403. Redis cache (`blocked_ip:<ip>`); the `blocked_ips` table is authoritative (populated by [Security](security.md) + [Admin Router](routers/admin.md)). `settings_db` enables the ipAllowlist bypass (DS-5).
- Positioned **inside** CORS/RequestID/Metrics but outermost of the app logic, so a blocked-IP 403 passes back through CORS (pinned by `tests/contract/test_middleware_order.py`).

## Request audit middleware (`RequestAuditMiddleware`)

DS-5 `auditApiRequests` toggle — optional audit logging of API requests (also IP-blocked-site logging via `DegradedSite`).

## Focused tests

- `tests/test_rate_limit.py`, `tests/test_ip_blocking.py`, `tests/unit/test_client_ip_unit.py`.

## Related pages

- [Security](security.md) — block list + auto-block.
- [Admin Router](routers/admin.md) — manual block/unblock.
- [Backend Overview](overview.md) — middleware order.
- [Provisioning](provisioning.md) — per-user device rate key.
- [Architecture](../architecture.md) — ARD-011 (middleware order), ARD-012 (IP block degrade).
