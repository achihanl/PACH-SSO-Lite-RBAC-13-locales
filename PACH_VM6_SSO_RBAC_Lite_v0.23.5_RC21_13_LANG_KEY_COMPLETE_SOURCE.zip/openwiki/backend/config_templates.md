---
type: subsystem
title: Config Templates, Profile Services, and UC Resource Allocation
description: Config template CRUD, org assignment, profile services (XMPP/SIP), uidNumber/SIP-extension allocation, endpoint validation (DNS SRV + WS), history, and cloning.
tags: [backend, config-templates, profiles, services, uidNumber, extension, endpoint-validation]
---

# Config Templates, Profile Services, and UC Resource Allocation

Config templates define what UC services a user/org gets and hold the uidNumber / SIP-extension allocators. This is the modern configuration model (the legacy `org_profiles` `profile_json`/nonce system lives in [Org Profiles Router](routers/orgprofiles.md)).

## Data model (`db/templates.py` TemplatesMixin)

- `config_templates` — id, name, description, `template_type` (default/custom), status (draft/active), `uid_range_start`(5000)/`uid_range_end`(65533), `next_uid_number`, `max_devices_per_user`(5), created/updated by.
- `config_template_assignments` — org_dn → template_id (assigned_at).
- `config_template_history` — append-only change log (actor, description, field, old/new value).
- `profile_services` — per-template service rows (`service_type` xmpp/sip, `enabled`, `config` JSON).

## Allocation counters (UID only — single-LDAP row)

- `allocate_uid_number(template_id)` / `allocate_extension(template_id)` — consume from `next_uid_number` / extension counters; raise `ExtensionRangeExhausted` when a range is exhausted (caught in [Users Router](routers/users.md)). Extension counters live on profile services (not the template `update_config_template` UID-only loop).

## Resolution

- `get_default_template()` — `template_type='default'`, else name "Standard Profile", ordered by `created_at` (deterministic under a first-boot race).
- `resolve_template_for_org(org_dn)` — JOIN assignments→templates.
- `list_config_templates()` — LEFT JOIN for per-template org count (no N+1).
- CRUD: `create_config_template`, `get_config_template_by_name`, `update_config_template` (name/description/status + UID alloc counters), `delete_config_template` (refuses to delete the default type), `clone_config_template` (always custom), `add_template_history`/`list_template_history`/`list_template_assignments`, `assign_template_to_org`/`remove_template_assignment`.
- Profile services: `get_profile_services(template_id)`, `add_profile_service`, `update_profile_service`, `delete_profile_service`.

## Router surface (`routers/templates.py`, `require_permission("system_configuration")`)

`GET /api/config-templates`, `GET/POST/PUT/DELETE /api/config-templates[/{id}]`, `POST .../clone`, `POST .../assign`, `DELETE .../assignments/{assignment_id}`, `POST .../validate-endpoints`, `POST/PUT/DELETE .../services[/{service_id}]`.

## Endpoint validation (`uc_validation.py`)

Validates DNS SRV + WebSocket connectivity for XMPP/SIP endpoints in config templates:
- DNS SRV: `_xmpp-client._tcp`, `_sip._tcp`, `_sips._tcp` (dns.resolver; NXDOMAIN/NoAnswer/LifetimeTimeout → failed CheckResult).
- WebSocket: WS/WSS upgrade handshake test (`WS_CONNECT_TIMEOUT=5`).
- Returns `CheckResult{name, passed, latency_ms, detail, error}`.

## Service-endpoint resolution (`routers/_shared.py`)

`_resolve_service_endpoints(org_dn)` — template → profile services xmpp/sip config `{domain, ws_url/wss_url}`; falls back to `UCCHAT_*` env vars if no profile or no endpoints (backwards compat). `_parse_service_config` handles dict or JSON-string config.

## Focused tests

- `tests/test_config_templates.py`, `tests/test_profile_services.py`, `tests/test_uc_validation.py`, `tests/test_profile_provisioning.py`, `tests/test_profile_seed.py`.

## Related pages

- [Provisioning](provisioning.md) — delivery uses templates/services + allocation.
- [OrgDB](orgdb.md) — TemplatesMixin + tables.
- [Users Router](routers/users.md) — allocation on user create.
- [Org Profiles Router](routers/orgprofiles.md) — legacy vs this system.
