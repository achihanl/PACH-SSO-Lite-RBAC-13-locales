---
type: service
title: LDAP Client + OpenLDAP Server DIT
description: "The LDAP abstraction layer (all directory operations, connection lifecycle, user/group/org lifecycle, UC attribute builder) plus the OpenLDAP server-side DIT: custom schema, ppolicy/memberOf overlays, client ACL, and stats-log config."
tags: [backend, ldap, directory, schema, ppolicy, memberof, acl]
---

# LDAP Client + OpenLDAP Server DIT

This page documents two coordinated halves (ARD-006): the Python **LDAP client** (`ldap_client.py`) that all backend operations use, and the **OpenLDAP server-side DIT** (`deploy/dev/ldap/**`) that defines the schema and overlays the client depends on.

## Connection lifecycle (`safe_ldap`, `get_conn`, `ldap_conn`)

- No pooling: `get_conn()` dials a fresh TCP connection and performs a bind every call (`Server(LDAP_URI, use_ssl=LDAP_USE_SSL)` + `Connection(..., auto_bind=True)`).
- `safe_ldap(op_fn)` wraps every operation: each connection opened during the op is registered on a **ContextVar-scoped bucket** and released in a `finally`, whatever the outcome. This fixes a per-request socket/file-descriptor leak when an exception hit between connect and `conn.unbind()`. **ContextVar (not a module global)** because FastAPI runs these sync handlers in a threadpool — a plain global would let concurrent requests release each other's connections. `get_conn()` maps `LDAPException` → `LdapUnavailableError` (→ HTTP 503).
- `ldap_conn()` context manager for callers outside `safe_ldap` (main.py direct sites) with guaranteed release.
- `ssha_password(plain)` — SSHA (salt + SHA1) for `userPassword`.

## UC attribute builder (`build_uc_attrs` / `add_uc_attrs_to_user` / `get_uc_credentials`)

- `build_uc_attrs(services|flags, uid_number, extension, sip_password, username, xmpp_password?, profile_id?)` → `(attrs, objectClasses)`. Derives xmpp/sip enablement from services; adds `posixAccount` (AUXILIARY) + `homeDirectory`/`loginShell`/`gidNumber=1000`; adds `azblinkUser` objectClass when `azbXmppBindPassword`/`azblinkProfileId` present; when SIP is enabled adds `AsteriskAccount` + `AsteriskPjsipEndpoint/Auth/Aor` + `AstAccountName`, `AstAuthPassword`, `AstAuthRealm`, `AstEndpointContext=from-internal`, etc. (`AstAccountName` non-empty is required for UED's SIP-in-LDAP enumeration sfilter `(AstAccountName=*)` — without it asterisk produces no SIP endpoints → REGISTER 401, proven 2026-04-17.)
- `get_uc_credentials(uid)` → `{xmpp_password, sip_password}` from `azbXmppBindPassword`/`AstAuthPassword` (empty/"[]" → None).
- Password sync: `_set_user_passwords` updates `userPassword` (SSHA) + `azbXmppBindPassword` (plaintext) in one MODIFY — XMPP bind password only when the entry has `azblinkUser`.

## Users

- **create** `create_user(uid, display_name, mail, mobile, org_dn, password, title?, employee_number?, manager_dn?)` → `inetOrgPerson` under the mirrored people OU (`_ensure_people_ou_for_org`); returns `{status: created|exists}`. Only non-empty optional attrs set (LDAP rejects empty strings). Optional inetOrgPerson attrs: title, employeeNumber, manager.
- **update** `update_user(uid, updates)` — FIELD_MAP: displayName→cn, mail, mobile, preferredLanguage; empty string → delete attr.
- **read** `get_user(uid)` — resolves manager display name, `createTimestamp`; `list_users`, `list_users_for_org` (incl. sub), `get_users_batch(uids)` (single OR-filter roundtrip `(|(uid=a)(uid=b))`, missing silently omitted — the batch N+1 fix), `count_users_by_people_base` (per-base counting), `verify_user_password`.
- **lifecycle**: `reset_user_password(uid, new_password)` (LDAP + XMPP sync); `move_user_to_org(uid, org_dn)` (modify_dn to mirrored people OU); `disable_user(uid)` (**termination** — three writes, all matter to consumers: `pwdAccountLockedTime=000001010000Z` ppolicy sentinel so ppolicy denies the bind + an LDAP-backed consumer stops filtering the entry as enabled; group-membership removal — removed from every `groupOfNames`, adding the service DN `LDAP_BIND_DN` placeholder when the user is the sole member (groupOfNames requires ≥1 member, same convention as create_group); `userPassword={DISABLED}` + `description=TERMINATED`); `suspend_user(uid)` (clear password `{SUSPENDED}` + description, entry preserved, reversible); `unsuspend_user(uid, new_password)`.
- account status derivation `_derive_account_status(entry)` (drives display).
- Org DN inference `_infer_org_dn_from_user_dn` / `_infer_org_dn_from_group_dn` / `_ensure_people_ou_for_org`.

## Groups

`create_group(org_dn, cn, description)` returns a **groupOfNames** under the mirrored groups OU (service DN `LDAP_BIND_DN` placeholder added when first member, since groupOfNames requires ≥1 member); `get_group`, `list_groups`, `update_group_description`, `group_add_member`, `group_remove_member`, `get_group_members`, `get_user_groups`, `find_group_dn`, `delete_group`. AZBlink groups are **groupOfNames carrying `member`** — which is why the memberOf overlay must be configured for that pair (server DIT below).

## Orgs (OU tree)

`get_org_tree` (mirrored OU tree with sorting), `create_org_ou(parent_dn, name)` (ensures chain + mirrored people/groups OUs), `rename_org_ou` (mirrors rename into people/groups), `delete_org_ou` (recursive), `_ensure_people_ou_for_org`, `bootstrap_base_ous`, `ensure_clients_ou`. DN safety: `dn_escape_ou` uses ldap3 `escape_rdn` (full RFC 4514 special set, not just commas — fixes DN-injection/malformed-DN surface for org names/group CNs/user UIDs).

---

# OpenLDAP Server DIT (`deploy/dev/ldap/**`)

## Custom schema: `azblink.schema`

OID arc `1.3.6.1.3.99.1` (experimental, dev/test): `.1` attributes, `.2` objectClasses. All AZBlink objectClasses are **AUXILIARY** (overlay inetOrgPerson). Attributes: `azblinkAccountStatus`, `azblinkProfileId`, `azblinkProvisionedAt`, org attributes, etc. `azblinkUser` (track profile linkage + XMPP bind password) and `azblinkOrganization` are the primary classes (see `build_uc_attrs`).

## Asterisk schema: `asterisk-pjsip.schema`

AUXILIARY `AsteriskAccount`/`AsteriskPjsipEndpoint`/`AsteriskPjsipAuth`/`AsteriskPjsipAor` classes the UC SIP provisioning writes (AstAccountName/AstAuthPassword/…). Requires the matching UED/sippy schema.

## Overlay configs

- **`ppolicy-config.ldif`** — loads the ppolicy module and configures it on the main db (`olcPPolicyDefault: cn=default,ou=policies,…`). This is what makes `pwdAccountLockedTime` meaningful (used by `disable_user` and by external relying parties filtering on it).
- **`memberof-refint-config.ldif`** — **corrects osixia's built-in default.** osixia/openldap:1.5.0 ships `04-refint.ldif` creating memberof with `olcMemberOfGroupOC: groupOfUniqueNames`/`olcMemberOfMemberAD: uniqueMember`. AZBlink groups are `groupOfNames` carrying `member`, so the built-in overlay watched a pair this directory never writes → `memberOf` was **never populated on any entry** — silently (a consumer filtering on memberOf got empty results, not an error; 2026-08-07 VM7 integration report G4). This file `modify`s the two values to `groupOfNames`/`member` (deliberately a modify, not add — the overlay already exists, and an add silently did nothing for months). **Ordering:** osixia applies bootstrap LDIFs lexically; digits sort before letters so this lands after `04-refint.ldif`. Changing overlay config does NOT recompute existing entries; memberships written before the fix must be rewritten (verify with `tests/test_org_groups.py::TestMemberOfOverlay`).
- **`ldap-clients-acl.ldif`** — the static bootstrap ACL referenced by `ldap_provisioning.py`. Rule {1} protects login/bind secrets, rule {2} protects UC secrets (`azbXmppBindPassword`, `AstAuthPassword`, `AstAuthMd5Cred`), rule {3} grants `ou=clients` **children read on everything else**; no secret is ever readable by a provisioned client.
- **`logfile-config.ldif`** — enables slapd's stats log (`olcLogFile`), which produces the log that [LDAP Activity](ldap_activity.md) parses.
- **`bootstrap.ldif` / `bootstrap.demo.ldif`** — base OU tree (org/people/groups), admin, bootstrap users; demo variant gated behind dev compose (see [Dev deployment](../deploy/dev.md)).

## Focused tests

- `tests/test_ldap_clients.py`, `tests/test_org_groups.py::TestMemberOfOverlay`, `tests/unit/test_ldap_conn_lifecycle.py`, `tests/unit/test_ldap_errors_unit.py`, `tests/unit/test_ldap_mapping_unit.py`, `tests/test_ldap_injection.py`.

## Related pages

- [OrgDB](orgdb.md), [Auth](auth.md), [Provisioning](provisioning.md), [LDAP Activity](ldap_activity.md), [Settings Router](routers/settings.md), [Deploy](../deploy/dev.md), [Architecture](../architecture.md) (ARD-006, ARD-007, ARD-013).
