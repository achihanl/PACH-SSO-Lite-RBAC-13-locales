---
type: subsystem
title: Activity Bus (Real-Time Event Fan-Out)
description: The pub/sub event bus for real-time activity delivery - per-subscriber asyncio queues, Redis cross-worker fan-out, fallback to local delivery, and the multi-worker failure it fixes.
tags: [backend, activity-bus, events, websocket, redis, pubsub, realtime]
---

# Activity Bus (Real-Time Event Fan-Out)

`activity_bus.py` is the event bus that broadcasts activity events to connected WebSocket/SSE clients, delivered by the [Realtime Router](routers/realtime.md).

## Model

- Per-subscriber **bounded asyncio.Queue** (drop-on-full, default max 100).
- `subscribe()` / `unsubscribe()` (idempotent discard) — safe to call concurrently.
- `deliver_local(event)` — fan out to this process's subscriber queues via `put_nowait` (safe from sync code: orgdb audit methods run in FastAPI's threadpool, not the async event loop). Drops on full with a warning.
- `publish_sync(event)` — broadcast to every worker. With Redis: `Redis.publish(ACTIVITY_CHANNEL="azblink:activity", json)`, returns; the publishing worker's own listener delivers locally too → exactly one delivery per subscriber. Without/when publish fails: falls back to `deliver_local` and sets `_redis_degraded` (logged once on transition, one INFO on recovery).
- Singleton lifecycle via `init_activity_bus(redis_client=...)` (called in main.py lifespan) + `get_activity_bus()`.

## Why Redis fan-out exists (multi-worker delivery)

Subscriber queues hold live WebSocket/SSE connections owned by one uvicorn worker, so fan-out between workers must go through something shared. `deploy/dev/Dockerfile.api` runs `--workers ${UVICORN_WORKERS:-2}` on the non-reload path. Before this, an admin's WebSocket lived on worker A but a user created on worker B published to B's in-process bus only — the admin never saw it, no error/log, ~half the events gone. Redis PUBLISH now delivers to every worker's listener, which fans into its local queues. When Redis is absent/fails, delivery falls back to local queues (correct for single-worker dev and for a Redis outage).

## Activity types (`activity_types.py`)

Pure data, zero side-effect imports (importable in-process for unit tests without main.py's DB setup). Maps unified-audit `event_type` → frontend-friendly type (`qr-consumed/generated/expired/revoked`, `user-terminated/created`, `sso-enrolled`, `login`, `config-change`, `admin-action`, `device-provisioned/revoked/extended`, …). Non-QR events never collapse onto a `qr-*` type; unrecognized → `ACTIVITY_TYPE_DEFAULT` ("activity").

## Focused tests

- `tests/test_activity_realtime.py`, `tests/unit/test_activity_bus_fanout.py`, `tests/unit/test_ldap_activity_classify.py`.

## Related pages

- [Realtime Router](routers/realtime.md) — subscriber surface.
- [Backend Overview](overview.md) — lifespan init + listener task.
- [Audit Router](routers/audit.md) — events published on audit writes.
- [Architecture](../architecture.md) — ARD-011.
